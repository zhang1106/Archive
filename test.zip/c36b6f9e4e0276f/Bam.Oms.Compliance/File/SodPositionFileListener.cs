﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Oms.Data.Positions;
using CsvHelper;

namespace Bam.Oms.Compliance.File
{
    public class SodPositionFileListener : FileListener, IFileListener
    {
        public event Action<IList<IPosition>> SodPositionLoaded;

        public SodPositionFileListener(string watchPath, string archivePath, string errorPath)
            : base(watchPath, archivePath, errorPath)
        {
        }

        protected override void ProcessFile(string path, string entryUser)
        {
            var positions = new List<IPosition>();
            using (var reader = new CsvReader(System.IO.File.OpenText(path)))
            {
                reader.Configuration.RegisterClassMap<SodPositionMap>();

                while (reader.Read())
                {
                    var sodPosition = reader.GetRecord<Position>();
                    
                    positions.Add(sodPosition);
                }

                // This event needs to be raised on a different thread
                Task.Factory.StartNew(() => RaisePositionEvent(positions, SodPositionLoaded));
            }
        }

        /// <summary>
        /// Executes the SodPositionUpdated. In case one of the handler fails,
        /// the execution of other handlers doesn't get impacted
        /// </summary>
        /// <param name="positions"></param>
        /// <param name="action">Event to trigger</param>
        private static void RaisePositionEvent(IList<IPosition> positions, Action<IList<IPosition>> action)
        {
            if (action == null) return;

            foreach (var handler in action.GetInvocationList().Cast<Action<IList<IPosition>>>())
            {
               handler(positions);
            }
        }
    }
}
