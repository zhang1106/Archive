﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.Persistence.Trades
{
    public interface IAllocationDBRepository : IDBRepository<IBlockTrade>
    {       
    }
}
