﻿namespace Bam.EventQ.SignalR
{
    public interface ISignalRHub
    {
        void Ping();
        void AddFilter(ParameterString[] criteria);
        void RemoveFilter();
    }

    public class ParameterString
    {
        public string Property { get; set; }
        public string Value { get; set; }
        public string Type { get; set; }
    }
}