﻿using System;
using System.Threading.Tasks;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using Bam.Oms.OrderRouting.Contracts;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Ft;
using Grpc.Core;
using Grpc.Core.Utils;
using static System.String;

namespace Bam.Oms.OrderRouting.Flex
{
    public class SystemSubscriptionHost : SubscriptionHost<SystemNotificationResponse>, ISystemSubscriptionHost
    {
        private readonly SystemNotificationService.ISystemNotificationServiceClient _systemNotificationServiceClient;
        private readonly ILogger _logger;
        
        public event Action<string> RollStarted;
        public event Action<string> RollCompleted;        

        public SystemSubscriptionHost(SystemNotificationService.ISystemNotificationServiceClient systemNotificationServiceClient, ILogger logger, IGrpcChannel channel, ISettings settings, ILoggingAgent eventLogger)
            : base(eventLogger, logger, channel, settings)
        {
            if (systemNotificationServiceClient == null) throw new ArgumentNullException(nameof(systemNotificationServiceClient));
            if (logger == null) throw new ArgumentNullException(nameof(logger));                       

            _systemNotificationServiceClient = systemNotificationServiceClient;
            _logger = logger;

            Task.Run(() => Subscribe());
        }

        protected override void NewItemHandler(SystemNotificationResponse response)
        {
            _logger.Debug($"Flex System Notification event {response}");
            Task.Run(() =>
            {
                try
                {
                    switch (response.EventType)
                    {
                        case EventType.BLOTTER_ROLL_STARTED:
                            Utility.RaiseEvent(response.Data, RollStarted);                            
                            return;
                        case EventType.BLOTTER_ROLL_COMPLETE:                            
                            Utility.RaiseEvent(response.Data, RollCompleted);
                            return;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Exception processing System Notification.", ex);
                }
            });
        }

        protected override void Unsubscribe()
        {
            var request = new SubscriptionRequest { Name = SubscriptionId };
            //this will cause the unsubscribe to block
            //the call option of 1min will allow this to timeout if it doesn't unsubscribe
            var asyncServerStreamingCall = _systemNotificationServiceClient.Unsubscribe(request, new CallOptions(null, DateTime.UtcNow.AddSeconds(15)));

            if (asyncServerStreamingCall != null)
            {
                try
                {
                    var result = asyncServerStreamingCall.ResponseStream.ToListAsync().Result;
                }
                catch (AggregateException aex)
                {
                    _logger.Warn($"Unsubscribe timeed out for type  {SubscriptionType}");
                }
            }
        }

        protected override void Resubscribe()
        {
            Unsubscribe(); //not going to wait for the unsubscribe to return as this connection may have dropped anyways.
            Subscribe();
        }

        private void Subscribe()
        {
            try
            {
                SubscriptionId = Guid.NewGuid().ToString();
                var request = new SubscriptionRequest() { Name = SubscriptionId };

                var subscribeResponse = _systemNotificationServiceClient.Subscribe(request);

                _logger.InfoFormat($"Returned subscription stream for id {SubscriptionId}, stream created and passed to polling task");

                //this is a limitation of the Grpc not allowing you to created or inherit from the AsyncServerStreamingCall, so for the unit test we want to check for null
                if (subscribeResponse != null)
                    Subscribe(subscribeResponse.ResponseStream);
            }
            catch (Exception ex)
            {
                _logger.Error($"Exception subscribing to System Notification Service. The service may need to be restarted.", ex);
            }            
        }        
    }
}
