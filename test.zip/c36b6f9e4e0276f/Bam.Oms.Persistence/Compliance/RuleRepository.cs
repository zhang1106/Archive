﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Persistence.Compliance
{
    public class RuleRepository<T> : DBRepository<Rule<T>>, IRuleRepository<T> 
    {
        internal static readonly Func<Rule<T>, dynamic> ParamMap = item => new
        {
            Id = item.Id,
            Name = item.Name,
            Type = item.Type,
            Description = item.Description,
            IsActive = item.IsActive,
            StartDate = item.StartDate,
            EndDate = item.EndDate,
            ParamsInJson = item.ParamsInJson,
        };

        public RuleRepository(ISettings settings, ILogger logger) : base(settings, logger, "cp", $"[{settings.RuleTable}]", null, ParamMap)
        {
        }

        public IEnumerable<Rule<T>> GetRules(int policyId )
        {
            string filter = $"[{_settings.RuleTable}].IsActive = 1 And [{_settings.RuleTable}].Id in (Select ruleId From cp.{_settings.PolicyRuleTable} WHERE PolicyId = @policyId)";

            return Get(filter, new { PolicyId = policyId });
        } 
    }
}
