﻿using System;
using Bam.EventQ.Lookup;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class AggUnitPosition : ModelBase<object>, ICloneable
    {
        public long PositionId { get; set; }
        public string BamSymbol { get; set; }
        public string AggregationUnit { get; set; }
        public long ShortMarkingQuantity { get; set; }

        public object Clone()
        {
            return new AggUnitPosition
            {
                PositionId = PositionId,
                BamSymbol = BamSymbol,
                AggregationUnit = AggregationUnit,
                ShortMarkingQuantity = ShortMarkingQuantity
            };
        }
    }
}
