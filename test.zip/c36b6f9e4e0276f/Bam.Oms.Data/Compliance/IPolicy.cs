﻿using System.Collections.Generic;
using System;
using Bam.Oms.Filtering;

namespace Bam.Oms.Data.Compliance
{
    /// <summary>
    /// Compliance policy is a set of compliance rules that will be applied together. 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IPolicy<T> : IPersistentItem, IExtensible
    {
        int Id { get;  }
        string Name { get;  }
        string Description { get; }
        bool IsActive { get;  }   //turn on/off a rule
        DateTime StartDate { get;  }
        DateTime EndDate { get;  }
        void AddRule(IRule<T> t);
        IList<IRule<T>> Rules { get; }
        /// <summary>
        /// one way to deal with filter is specify the filter property (which is a property of T and the value to filter on and operator.
        /// This requires reflection and can become performance issue. we need to look into delegate approach and see what's the performance hit
        /// here is one example http://stackoverflow.com/questions/6430835/example-speeding-up-reflection-api-with-delegate-in-net-c
        /// this can be used in multiple places so we can abstract it if it the performance is good. (the link says it's 300 tiems faster than reflection in the example
        /// </summary>
        /// <param name="filterProptery"></param>
        /// <param name="filterValue"></param>
        /// <param name="criteria"> can be one of the values: "Equal", "Contains" etc</param>
        void AddFilter(IFilter<T> filter);
       /// <summary>
       /// check for violations, filtering will be applied first, then check the rules.
       /// </summary>
       /// <param name="input"></param>
       /// <param name="isPreCheck"></param>
       /// <returns></returns>
        IPolicyResult CheckViolations(T input, bool isPreCheck);
    }
}
