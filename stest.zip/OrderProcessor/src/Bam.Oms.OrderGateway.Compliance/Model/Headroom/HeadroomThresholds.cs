﻿using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    public struct HeadroomThreshold
    {
        public HeadroomThreshold(ComplianceViolationLevel violationLevel, 
            decimal threshold, long quantity, bool fireOnce)
        {
            ViolationLevel = violationLevel;
            Threshold = threshold;
            Quantity = quantity;
            FireOnce = fireOnce;
        }

        public decimal Threshold { get; }
        public long Quantity { get; }
        public bool FireOnce { get; }
        public ComplianceViolationLevel ViolationLevel { get; }
    }
}
