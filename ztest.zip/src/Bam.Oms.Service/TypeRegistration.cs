﻿using System;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Service.Orders;
using Bam.Oms.Service.Security;
using Bam.Oms.Service.StateMachine;
using Bam.Oms.Service.Trades;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Service
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            try
            {
                container.RegisterType<IFlowManager, FlowManager>(RegistrationType.Singleton, "", new InjectionMethod("Initialize"));
                container.RegisterType<IOrderGateway, OrderGateway>(RegistrationType.Singleton);
                container.RegisterType<ISecurityProcessor, SecurityProcessor>(RegistrationType.Singleton);
                container.RegisterType<ITradeProcessor, TradeProcessor>(RegistrationType.Singleton);

                container.RegisterType<IStripedProcessor, StripedProcessor>(RegistrationType.Transient);
            }
            catch (Exception ex)
            {
                var aggEx = ex as AggregateException;

                if (aggEx == null) throw;

                // try to get the logger from the container
                var logger = Container.Instance.Resolve<ILogger>();
                var flattenedExceptions = aggEx.Flatten();
                foreach (var innerException in flattenedExceptions.InnerExceptions)
                {
                    const string typeRegMessage =
                        "\n" + "====================================================================" +
                        "\n" + "Exception thrown in TypeRegistration. See Console or Log for details" +
                        "\n" + "====================================================================";

                    logger?.Info(typeRegMessage);
                    logger?.Error(innerException.ToString());
                    Console.WriteLine(typeRegMessage);
                    Console.WriteLine(innerException.ToString());
                }

                throw;
            }
        }
    }
}