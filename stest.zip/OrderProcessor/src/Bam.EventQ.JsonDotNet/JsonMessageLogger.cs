﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Bam.EventQ.JsonDotNet
{
    public class JsonMessageLogger<TItem> : IQueueItemHandler<PipelineQueueItem<TItem>>
    {
        private readonly ILogger _logger;
        private readonly string _prefix;
        private readonly HashSet<Type> _excludedMessageTypes;
        private readonly JsonConverter[] _converters;

        public JsonMessageLogger(ILogger logger, string prefix, IEnumerable<Type> excludedMessageTypes)
        {
            _logger = logger;
            _prefix = prefix;
            _excludedMessageTypes = new HashSet<Type>(excludedMessageTypes);
            _converters = new JsonConverter[]
            {
                new StringEnumConverter()
            };
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            if (item.IsReplay || !item.IsValid)
                return;

            if (item.Payload != null && _excludedMessageTypes.Contains(item.Payload.GetType()))
                return;

            _logger.LogDebug("{0} | {1} | {2}",
                _prefix, item.Payload?.GetType().GetDisplayName() ?? "???",
                item.Payload == null 
                    ? "NULL" 
                    : JsonConvert.SerializeObject(item.Payload, Formatting.None, _converters));
        }
    }
}
