﻿using System;
using System.Collections.Generic;
using System.Security.Principal;

namespace Bam.EventQ.SignalR
{
    public interface ISignalRSessionRepository
    {
        void Add(string connectionId, IIdentity identity);
        void Remove(string connectionId);
        IIdentity TryGet(string connectionId);
        IReadOnlyList<string> GetAllConnectionIds();

        event Action<string> NewConnection;

        IDisposable AcquirePublishingToken();
    }
}
