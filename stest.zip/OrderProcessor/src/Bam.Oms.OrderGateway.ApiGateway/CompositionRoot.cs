using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http.Dependencies;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Journal;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Pooling;
using Bam.EventQ.Queue;
using Bam.EventQ.Recovery;
using Bam.EventQ.Sequencing;
using Bam.EventQ.SignalR;
using Bam.EventQ.Snapshot;
using Bam.EventQ.Solace;
using Bam.EventQ.Solace.Json;
using Bam.EventQ.Throttling;
using Bam.EventQ.Time;
using Bam.EventQ.Transport;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.File;
using Bam.Oms.OrderGateway.ApiGateway.Http;
using Bam.Oms.OrderGateway.ApiGateway.Http.SignalR;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.ApiGateway.Models.Solace;
using Bam.Oms.OrderGateway.ApiGateway.Producers;
using Bam.Oms.OrderGateway.ApiGateway.Services;
using Bam.Oms.OrderGateway.ApiGateway.Workflows;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;
using Bam.Oms.OrderGateway.Infrastructure.Roll;
using Bam.Oms.OrderGateway.Integrations.StructureMap;
using Bam.Oms.OrderGateway.Messages;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Infrastructure;
using StructureMap;
using StructureMap.Pipeline;
using IDependencyResolver = System.Web.Http.Dependencies.IDependencyResolver;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class CompositionRoot : StructureMapCompositionRoot<ApiGatewayService, ApiGatewaySettings>
    {
        protected override void Configure(ConfigurationExpression config, ApiGatewaySettings settings)
        {
            config.For<IOrderValidator>()
                .Use<OrderValidator>();

            config.ForConcreteType<SubmissionQueueItemProducer>()
                .Configure.Singleton()
                .AlsoKnownAs(config, typeof(IRouteSubmission))
                .AlsoKnownAs(config, typeof(IOrderSubmission))
                .AlsoKnownAs(config, typeof(IRollBlotterSubmission))
                .AlsoKnownAs(config, typeof(ISodSubmission))
                .AlsoKnownAs(config, typeof(IPositionSubmission))
                .AlsoKnownAs(config, typeof(ICancelSubmission))
                .AlsoKnownAs(config, typeof(ILocateSubmission))
                .AlsoKnownAs(config, typeof(IComplianceSubmission))
				.AlsoKnownAs(config, typeof(IAllocationSubmission))
                .AlsoKnownAs(config, typeof(ISecuritySubmission));

            config.For<ITradeSubmission>()
                .Use<TradeSubmission>()
                .Singleton();
            
            config.For<IOrderAggregator>().Use<OrderAggregator>().Singleton();

            config.For<IVersionGenerator>()
                .Use<VersionGenerator>()
                .Singleton()
                .AlsoKnownAs(config, typeof(ISnapshotRecoverable));

            config.For<ITradeStatusService>()
                .Use<TradeStatusService>()
                .Singleton()
                .AlsoKnownAs(config, typeof(ISnapshotRecoverable));

            config.For<IContingencyRecordRepository>()
                .Use<ContingencyRecordRepository>()
                .Ctor<string>().Is(settings.ContingencyConnectionString);

            ConfigureFileListeners(config, settings);
            ConfigureAuthorization(config, settings);
            ConfigureSharedModel(config);
            ConfigureRest(config, settings);
            ConfigureSignalR(config, settings);
            ConfigureSolace(config, settings);

            config
                .ForConcreteType<ApiGatewayService>().Configure
                .Ctor<string[]>().Is(settings.PermissionedApplications)
                .Ctor<IService>("orderFileListener").Is(ctx => ctx.GetInstance<IService>(nameof(OrderFileListener)))
                .Ctor<IService>("securityFileListener").Is(ctx => ctx.GetInstance<IService>(nameof(SecurityFileListener)))
                .Ctor<IService>("headroomFileListener").Is(ctx => ctx.GetInstance<IService>(nameof(HeadroomFileListener)))
                .Ctor<IService>("httpService").Is(ctx => ctx.GetInstance<IService>(nameof(HttpService)));
        }
        
        private static void ConfigureFileListeners(ConfigurationExpression config, ApiGatewaySettings settings)
        {
            config.For<IService>().Add<OrderFileListener>()
                .Named(nameof(OrderFileListener))
                .Ctor<string>("watchPath").Is(settings.OrderFileListener.Path)
                .Ctor<string>("archivePath").Is(settings.OrderFileListener.ArchivePath)
                .Ctor<string>("errorPath").Is(settings.OrderFileListener.ErrorPath);

            config.For<IService>().Add<SecurityFileListener>()
                .Named(nameof(SecurityFileListener))
                .Ctor<string>("watchPath").Is(settings.SecurityFileListener.Path)
                .Ctor<string>("archivePath").Is(settings.SecurityFileListener.ArchivePath)
                .Ctor<string>("errorPath").Is(settings.SecurityFileListener.ErrorPath);

            config.For<IService>().Add<HeadroomFileListener>()
                .Named(nameof(HeadroomFileListener))
                .Ctor<string>("watchPath").Is(settings.HeadroomFileListener.Path)
                .Ctor<string>("archivePath").Is(settings.HeadroomFileListener.ArchivePath)
                .Ctor<string>("errorPath").Is(settings.HeadroomFileListener.ErrorPath);
        }

        private void ConfigureSharedModel(ConfigurationExpression config)
        {
            config.For<ICache<string, Security>>().Use(new Cache<string, Security>());
            config.For<ICache<string, Order>>().Use(new Cache<string, Order>());
            config.For<ICache<string, Trade>>().Use(new Cache<string, Trade>());
            config.For<ICache<long, Position>>().Use(new Cache<long, Position>());
            config.For<ICache<long, DetailedPosition>>().Use(new Cache<long, DetailedPosition>());
            config.For<ICache<string, SodPosition>>().Use(new Cache<string, SodPosition>());
            config.For<ICache<long, AggUnitPosition>>().Use(new Cache<long, AggUnitPosition>());
            config.For<ICache<long, ComplianceGroupPosition>>().Use(new Cache<long, ComplianceGroupPosition>());
            config.For<ICache<int, OrderScalingRule>>().Use(new Cache<int, OrderScalingRule>());
            config.For<ICache<OwnershipHeadroomKey, OwnershipHeadroom>>().Use(new Cache<OwnershipHeadroomKey, OwnershipHeadroom>());

            config.ForConcreteType<SharedModelHydrationWorkflow>().Configure
                .Ctor<IClock>().IsNamedInstance("Replay");

            config.ForConcreteType<SharedCacheUpdater>().Configure.Singleton();
        }

        private void ConfigureRest(ConfigurationExpression config, ApiGatewaySettings settings)
        {
            var httpConfig = config.ForConcreteType<HttpServiceOptions>().Configure
                .Ctor<string>().Is(settings.Http.BaseUrl)
                .Setter(m => m.PermissionedApplications).Is(settings.PermissionedApplications)
                .Setter(m => m.SignalRConnectionTimeout).Is(settings.SignalR.ConnectionTimeout)
                .Setter(m => m.SignalRBufferSize).Is(settings.SignalR.BufferSize)
                .Setter(m => m.DependencyResolver).IsTheDefault()
                .Setter(m => m.DisableAuthorization).Is(settings.DisableAuthorization)
                .Setter(m => m.DefaultTokenExpiry).Is(settings.Http.DefaultTokenExpiry)
                .Setter(m => m.AllowTokenAsUrlParameter).Is(settings.Http.AllowTokenAsUrlParameter)
                .Setter(m => m.MaxPendingRequests).Is(settings.Http.MaxPendingRequests)
                .Setter(m => m.MaxActiveRequests).Is(settings.Http.MaxActiveRequests);

            config.For<IService>().Add<HttpService>()
                .Named(nameof(HttpService))
                .Ctor<HttpServiceOptions>().Is(httpConfig);

            config.For<IDetailedPositionImportExport>()
                .Use<CsvDetailedPositionImportExport>()
                .Singleton();

            config.ForConcreteType<Http.Controller.PermissionController>()
                .Configure
                .Ctor<string[]>().Is(settings.PermissionedApplications);
        }

        private void ConfigureSignalR(ConfigurationExpression config, ApiGatewaySettings settings)
        {
            config.For<OrderHub>().Use<OrderHub>();
            config.For<ISignalRSessionRepository>().Use<SignalRSessionRepository>().Singleton();

            config.ForConcreteType<FilteredSignalRPublisher<string, Order, OrderHub>>().Configure
                .Ctor<IConnectionManager>().Is(GlobalHost.ConnectionManager)
                .Ctor<Func<Order, string>>().Is(o => o.Portfolio.ToString())
                .Ctor<int>().Is(settings.SignalR.BatchSize)
                .Singleton();
        }

        protected override void ConfigureRollProcess(ConfigurationExpression config, ApiGatewaySettings settings)
        {
            base.ConfigureRollProcess(config, settings);

            config.For<IRollBlotterProcess>()
                .Add<PublishRollEventRollBlotterProcess>();

            config.For<IRollBlotterProcess>()
                .Add<FlushCacheRollProcess>()
                .Ctor<string[]>().Is(settings.Solace.TopicsToFlushOnRoll);
        }

        private void ConfigureSolace(ConfigurationExpression config, ApiGatewaySettings settings)
        {
            config.For<SolaceOptions>().Use(new SolaceOptions
            {
                Username = settings.Solace.Username,
                Password = settings.Solace.Password,
                Vpn = settings.Solace.Vpn,
                Host = settings.Solace.Host,
                CacheName = settings.Solace.Cache.CacheName,
                GenerateSequenceNumbers = settings.Solace.GenerateSequenceNumbers
            });

            config.For<ISolCache>()
                .Add<SolCache>()
                .Ctor<SolCacheOptions>()
                .Is(new SolCacheOptions
                {
                    VpnName = settings.Solace.Vpn,
                    Instance = settings.Solace.Cache.Instance,
                    CacheName = settings.Solace.Cache.CacheName,
                    Cluster = settings.Solace.Cache.Cluster,
                    SempUrl = settings.Solace.Cache.SempUrl,
                    Username = settings.Solace.Cache.SempUsername,
                    Password = settings.Solace.Cache.SempPassword
                });

            config.ForConcreteType<SolaceContextWrapper>().Configure.Singleton();

            config.For<ISolaceMessageSerializer<Position>>().Use(
                new KeyValuePairSolaceMessageSerializer<Position>(
                    new Dictionary<string, string>
                    {
                        {nameof(Position.Security), "sym"},
                        {nameof(Position.Portfolio), "port"},
                        {$"{nameof(Position.Portfolio)}.{nameof(Models.Shared.Portfolio.AggregationUnit)}", "aggUnit"},
                        {nameof(Position.ActualQuantity), "actual"},
                        {nameof(Position.TheoreticalQuantity), "theoretical"},
                        {nameof(Position.Version), "version"}
                    },
                    new Dictionary<string, string>
                    {
                        {"type", "POSITION"}
                    }));

            config.For<IThrottledBatchHandler<RollEvent>>()
                .Use<SolaceThrottledBatchHandler<RollEvent>>()
                .Ctor<ISolaceMessageSerializer<RollEvent>>().Is(
                    new KeyValuePairSolaceMessageSerializer<RollEvent>(
                        new Dictionary<string, string>
                        {
                            {nameof(RollEvent.RollTime), "timestamp"},
                            {nameof(RollEvent.BusinessDay), "prevBusinessDay"},
                        },
                        new Dictionary<string, string>
                        {
                            {"type", "ROLL"}
                        }))
                .Ctor<ISolaceTopicProvider<RollEvent>>()
                .Is<RollEventSolaceTopicProvider>(cfg => cfg
                    .Ctor<string>().Is(settings.Solace.SystemEventBaseTopic));
        }

        protected override void ConfigureAuthorization(ConfigurationExpression config, ApiGatewaySettings settings, TimeSpan permissionRefresh = new TimeSpan())
        {
            base.ConfigureAuthorization(config, settings, settings.PermissionRefreshInterval);

            if (settings.DisableAuthorization)
            {
                config.For<IPermissionedEntityFilter>()
                    .Use<NoAuthPermissionedEntityFilter>()
                    .Singleton();
            }
            else
            {
                config.For<IPermissionedEntityFilter>()
                    .Use<PermissionedEntityFilter>()
                    .Singleton();
            }
        }

        protected override IEnumerable<IProcessingPipeline> CreatePipelines(ApiGatewaySettings settings, IContainer container)
        {
            IConsumptionTrigger<object> oneSecTrigger = container.GetInstance<IntervalConsumptionTrigger>(
                new ExplicitArguments(new Dictionary<string, object>
                {
                    {"interval", TimeSpan.FromSeconds(1)}
                }));
            
            yield return ProcessingPipeline.New()
                .LogErrors(container.GetInstance<ILogger>())
                .UseObjectInitializer(ObjectInitializer)
                .UseObjectDecorator(new TelemetryObjectDecorator(container.GetInstance<ITelemetry>(), settings.TelemetryPublishInterval))
                .UseRecoveryInvoker(container.GetInstance<IRecoveryInvoker>())
                .UseRpcServer(container.GetInstance<IRpcServer>())
                .AddStep<IMessage>(step => step
                    .AddSequenceInfoAccessor()
                    .AddQueueMessageDispatcher(container.GetInstance<IQueueMessageDispatcher>())
                    .UseDisruptor(settings.Queue.InputRingSize, settings.Queue.BufferSize)
                    .ReplayFromJournal(container.GetInstance<IJournal>(), container.GetAllInstances<IJournalSeed>())
                    .AddExternalSource(container.GetInstance<SubmissionQueueItemProducer>())
                    .SubscribeWithZeroMq(settings.Endpoints.PubSubBySource, settings.MaximumMessageSize)
                    .SubscribeTo(Source.OrderProcessor, Topic.Allocation, Topic.Order, Topic.Locate)
                    .SubscribeTo(Source.Compliance, Topic.Position, Topic.Sod, Topic.Compliance)
                    .SubscribeTo(Source.RefDataGateway, Topic.RefData, Topic.Security)
                    .SubscribeTo(Source.FlexGateway, Topic.Security)
                    .SendHeartbeats(WallClock, settings.HeartbeatInterval, settings.SelfSource, Topic.Order, Topic.Position, Topic.Enrichment, Topic.Sod, Topic.Admin)
                    .AddHandlerChain(chain => chain
                        .ValidateSequenceNumbers(container.GetInstance<IClock>(), settings.RecoveryTimeout, settings.SelfSource)
                        .Journal(container.GetInstance<IJournal>())
                        .Deserialize()
                        .LogMessagesTo("IN", settings.LogAllMessages, container.GetInstance<ILogger>())
                        .DispatchToWorkflow(container.GetInstance<IWorkflowDispatcher<IMessage, object>>())
                        .ReleasePayload(container.GetInstance<IObjectPool>())))
                .AddStep<object>(step => step
                    .UseDisruptor(settings.Queue.InputRingSize, 1)
                    .ReceiveFromPreviousStep<IMessage>()
                    .AddProducer((IQueueItemProducer<PipelineQueueItem<object>>) container.GetInstance<ITradeSubmission>())
                    .AddHandlerChain(chain => chain
                        .Throttle(oneSecTrigger)
                            .Conflate<Security, string>(o => o.Key, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<Order, string>(o => o.Key, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<Trade, string>(o => o.Key, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<Position, long>(o => o.PositionId, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<SodPosition, string>(o => o.Id, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<AggUnitPosition, long>(o => o.PositionId, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<ComplianceGroupPosition, long>(o => o.PositionId, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<DetailedPosition, long>(o => o.PositionId, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<OrderScalingRule, int>(o => o.Id, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate<OwnershipHeadroom, OwnershipHeadroomKey>(o => o.Key, container.GetInstance<SharedCacheUpdater>(), false)
                            .Conflate(o => o.Key, container.GetInstance<FilteredSignalRPublisher<string, Order, OrderHub>>())
                            .If(settings.RabbitMq.PublishTrades, then => then
                                .ConflatedPublishToRabbitMq<object, string, Trade>(t => t.TradeId,
                                    settings.RabbitMq.Endpoint, settings.RabbitMq.IntradayTradesExchange, 
                                    settings.RabbitMq.RetryInterval, i => i.GetRoutingKey(), true))
                            .If(settings.RabbitMq.PublishOrders, then => then
                                .ConflatedPublishToRabbitMq<object, string, Order>(o => o.ClientOrderId,
                                    settings.RabbitMq.Endpoint, settings.RabbitMq.IntradayOrdersExchange,
                                    settings.RabbitMq.RetryInterval, i => i.GetRoutingKey(), true))
                            .If(settings.Solace.PublishTrades, then => then
                                .ConflatedPublishToSolace(t => t.TradeId,
                                    container.GetInstance<SolaceContextWrapper>(),
                                    new TradeSolaceTopicProvider(settings.Solace.TradeBaseTopic),
                                    new JsonSolaceSerializer(), true))
                            .If(settings.Solace.PublishOrders, then => then
                                .ConflatedPublishToSolace(o => o.ClientOrderId,
                                    container.GetInstance<SolaceContextWrapper>(),
                                    new OrderSolaceTopicProvider(settings.Solace.OrderBaseTopic),
                                    new JsonSolaceSerializer(), true))
                            .Build()
                        .Throttle(container.GetInstance<EndOfBatchTrigger>())
                            .If(settings.Solace.PublishPositions, then => then
                                .ConflatedPublishToSolace(t => t.PositionId,
                                    container.GetInstance<SolaceContextWrapper>(),
                                    new PositionSolaceTopicProvider(settings.Solace.PositionBaseTopic),
                                    container.GetInstance<ISolaceMessageSerializer<Position>>(),
                                    false))
                            .Build()
                        .ForwardToNextStep<IMessage>()))
                .AddStep<IMessage>(step => step
                    .AddSequenceInfoAccessor()
                    .UseDisruptor(settings.Queue.OutputRingSize, settings.Queue.BufferSize)
                    .ReceiveFromPreviousStep<object>()
                    .PublishWithZeroMq()
                    .AddHandlerChain(chain => chain
                        .Serialize(settings.SelfSource, settings.MaximumMessageSize, WallClock)
                        .LogMessagesTo("OUT", settings.LogAllMessages, container.GetInstance<ILogger>())
                        .Publish(settings.SelfPubSub))
                    .UseReplayRecovery(settings.SelfPubSub))
                .Build();

            container.Inject(typeof(IDependencyResolver), new StructureMapDependencyResolver(container));
        }
        
        private class StructureMapDependencyResolver : IDependencyResolver
        {
            private readonly IContainer _container;

            public StructureMapDependencyResolver(IContainer container)
            {
                _container = container;
            }

            public void Dispose()
            {
                // nothing
            }

            public object GetService(Type serviceType)
            {
                return _container.TryGetInstance(serviceType);
            }

            public IEnumerable<object> GetServices(Type serviceType)
            {
                return _container.GetAllInstances(serviceType).Cast<object>();
            }

            public IDependencyScope BeginScope()
            {
                return new StructureMapDependencyScope(_container.GetNestedContainer());
            }

            private class StructureMapDependencyScope : IDependencyScope
            {
                private readonly IContainer _container;

                public StructureMapDependencyScope(IContainer container)
                {
                    _container = container;
                }

                public void Dispose()
                {
                    _container.Dispose();
                }

                public object GetService(Type serviceType)
                {
                    return _container.GetInstance(serviceType);
                }

                public IEnumerable<object> GetServices(Type serviceType)
                {
                    return _container.GetAllInstances(serviceType).Cast<object>();
                }
            }
        }
    }
}
