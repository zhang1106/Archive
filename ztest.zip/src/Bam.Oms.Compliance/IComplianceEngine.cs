﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Compliance
{
    public interface IComplianceEngine
    {
        void RegisterPolicy<T>(ICompliancePolicy<T> policy);

        /// <summary>
        /// check for violations against a policy by speicify policy ID or name
        /// </summary>
        ICompliancePolicyViolation CheckViolations<T>(int policyId, T input, bool isPreCheck);
        ICompliancePolicyViolation CheckViolations<T>(string policyName, T input, bool isPreCheck);
    }
}
