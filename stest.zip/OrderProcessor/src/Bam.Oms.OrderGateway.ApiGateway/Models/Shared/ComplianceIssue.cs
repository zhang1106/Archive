﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class ComplianceIssue : ICloneable
    {
        public string Description { get; set; }
        public string Level { get; set; }
        public string RuleName { get; set; }
        public bool IsOverridden { get; set; }

        public object Clone()
        {
            return new ComplianceIssue
            {
                Description = Description,
                Level = Level,
                RuleName = RuleName,
                IsOverridden = IsOverridden
            };
        }
    }
}
