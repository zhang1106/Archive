﻿using Bam.Oms.OrderGateway.Infrastructure;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public class SodPositionKey
    {
        private readonly string _key;
        private readonly int _hashCode;

        public SodPositionKey(Portfolio portfolio, string bamSymbol, string custodian, string fund)
        {
            Portfolio = portfolio;
            BamSymbol = bamSymbol;
            Custodian = custodian;
            Fund = fund;
            _key = string.Intern(portfolio + "_" + bamSymbol + "_" + custodian + "_" + fund);
            _hashCode = _key.GetHashCode();
        }

        public Portfolio Portfolio { get; }
        public string BamSymbol { get; }
        public string Custodian { get; }
        public string Fund { get; }

        public override bool Equals(object obj)
        {
            if (!(obj is SodPositionKey))
                return false;

            return Equals((SodPositionKey)obj);
        }

        public bool Equals(SodPositionKey other)
        {
            return ReferenceEquals(_key, other._key);
        }

        public override int GetHashCode()
        {
            return _hashCode;
        }

        public override string ToString()
        {
            return _key;
        }
    }
}
