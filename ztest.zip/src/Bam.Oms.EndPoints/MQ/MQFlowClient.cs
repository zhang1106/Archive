﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using BAM.Common.Messaging;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.MQ
{
    public class MQFlowClient : IFlowClient
    {
        private readonly ILogger _logger;
        private readonly IConnection _mqConnection;
        private readonly string _ezeTopic;
        private readonly ISettings _settings;

        private readonly CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();
        private readonly BlockingCollection<ITrade> _outgoingTrades;
        private readonly BlockingCollection<IOrder> _outgoingOrders;
        private readonly BlockingCollection<IPosition> _outgoingPositions;
        private readonly BlockingCollection<string> _ezeOutgoing;
        private readonly Thread _publishTradesThread, _ezePublishThread, _publishOrdersThread, _publishPositionsThread;

        public MQFlowClient(IConnection mqConnection, string tradeTopic, string orderTopic, string positionTopic, string ezeTopic, ISettings settings, ILogger logger)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            _logger = logger;
            _mqConnection = mqConnection;
            _ezeTopic = ezeTopic;
            _settings = settings;

            _mqConnection.OnError += MqConnectionOnOnError;
            _mqConnection.OnLog += MqConnectionOnOnLog;
            _outgoingTrades = new BlockingCollection<ITrade>();
                                   

            _publishTradesThread = new Thread(Publish<ITrade>) { IsBackground = true, Name = "RMQ Trades Publisher" };
                                   

            var tradeConfig = Tuple.Create(
                tradeTopic,
                new Func<ITrade, string>(t => $"{_settings.EmsName}.{t.Portfolio.Key}"),
                _outgoingTrades);

            _publishTradesThread.Start(tradeConfig);

            if (_settings.PublishOrdersToMq)
            {
                _outgoingOrders = new BlockingCollection<IOrder>();
                _publishOrdersThread = new Thread(Publish<IOrder>) { IsBackground = true, Name = "RMQ Orders Publisher" };
                var orderConfig = Tuple.Create(
                    orderTopic,
                    new Func<IOrder, string>(t => $"{_settings.EmsName}.{t.Portfolio.Key}"),
                    _outgoingOrders);

                _publishOrdersThread.Start(orderConfig);
            }

            if (_settings.PublishPositionsToMq)
            {
                _outgoingPositions = new BlockingCollection<IPosition>();
                _publishPositionsThread = new Thread(Publish<IPosition>) { IsBackground = true, Name = "RMQ Positions Publisher" };
                var positionConfig = Tuple.Create(
                    positionTopic,
                    new Func<IPosition, string>(t => $"{_settings.EmsName}.{t.Portfolio.Key}"),
                    _outgoingPositions);

                _publishPositionsThread.Start(positionConfig);
            }

            if (settings.PublishEzeToMq == "YES" && ezeTopic != null)
            {
                _ezeOutgoing = new BlockingCollection<string>();
                _ezePublishThread = new Thread(Publish<string>) { IsBackground = true, Name = "RMQ Eze Publisher" };
                var ezeConfig = Tuple.Create(
                    ezeTopic,
                    new Func<string, string>(t => "#"),
                    _ezeOutgoing);

                _ezePublishThread.Start(ezeConfig);
            }            
        }

        private void MqConnectionOnOnLog(string message)
        {
            _logger.Info(message);
        }

        private void MqConnectionOnOnError(string message)
        {
            _logger.Error("RabbitMQ error: " + message);
        }

        public void PublishOrders(IList<IOrder> orders)
        {
            if (_settings.PublishOrdersToMq)
                this.PublishObjects(orders, _outgoingOrders);
        }

        public void PublishPositions(IList<IPosition> positions, DateTime nextBusinessDay)
        {
            if (_settings.PublishPositionsToMq)
                this.PublishObjects(positions, _outgoingPositions);
        }        

        public virtual FlowClientScope Scope => FlowClientScope.Ems;

        public void PublishTrades(IList<IBlockTrade> trades)
        {
            this.PublishObjects(Utility.GetAllocations(trades), _outgoingTrades);
        }

        public void PublishEzeOrders(IList<string> ezeOrders, string route)
        {
            if (_settings.PublishEzeToMq == "NO" || _cancellationTokenSource.IsCancellationRequested)
                return;

            var token = _cancellationTokenSource.Token;
            foreach (var str in ezeOrders)
            {
                try
                {
                    _ezeOutgoing?.Add(str, token);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                catch (InvalidOperationException) // this includes ObjectDisposedException
                {
                    return;
                }
            }
        }

        private void Publish<T>(object state) where T : class
        {
            var t = (Tuple<string, Func<T, string>, BlockingCollection<T>>) state;
            string topic = t.Item1;
            var routingKeyFunc = t.Item2;
            var source = t.Item3;

            try
            {
                var ct = _cancellationTokenSource.Token;
                var publisher = _mqConnection.GetPublisher(topic);

                var consumer = source.GetConsumingEnumerable();
                foreach (var trade in consumer)
                {
                    var message = new Message<T>(trade)
                    {
                        RoutingKey = routingKeyFunc(trade)
                    };

                    bool sent = false;
                    while (!sent)
                    {
                        try
                        {
                            if (ct.IsCancellationRequested)
                                break;

                            publisher.SendMessage(message, Mode.Json);
                            sent = true;
                        }
                        catch (Exception ex)
                        {
                            _logger.Error("Unable to publish to RabbitMQ, retrying in 5 seconds", ex);
                            ct.WaitHandle.WaitOne(TimeSpan.FromSeconds(5));
                        }
                    }
                }
            }
            catch (Exception gex)
            {
                _logger.FatalFormat("RabbitMQ publisher thread died", gex);
            }
        }
        
        public void SubscribeEzeOrders()
        {
            SubscribeObject(_ezeTopic, "#");
        }
        
        private void SubscribeObject(string destination, string subject)
        {
            try
            {
                var subscriber = _mqConnection.GetSubscriber<string>(destination, subject);

                subscriber.Subscribe();
                subscriber.OnMessage += (message) =>
                {
                    //_logger.Info($"Received message from MQ....");
                    //_logger.Info($"{message.Data}");
                    ObjectUpdated?.Invoke(message);
                };
            }
            catch (Exception ex)
            {
                _logger.Error($"Exception while receiving from MQ.", ex);
            }
        }

        private void PublishObjects<T>(IList<T> objects, BlockingCollection<T> queue)
        {
            if (_cancellationTokenSource.IsCancellationRequested)
                return;

            var token = _cancellationTokenSource.Token;
            foreach (var obj in objects)
            {
                try
                {
                    queue?.Add(obj, token);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                catch (InvalidOperationException) // this includes ObjectDisposedException
                {
                    return;
                }
            }
        }
        public event Action<Message<string>> ObjectUpdated;

        public void Dispose()
        {
            _cancellationTokenSource.Cancel();
            _outgoingTrades?.CompleteAdding();
            _outgoingOrders?.CompleteAdding();
            _outgoingPositions?.CompleteAdding();
            _ezeOutgoing?.CompleteAdding();
            _publishTradesThread?.Join();

            if (_publishOrdersThread != null && _publishOrdersThread.IsAlive)
                _publishOrdersThread?.Join();

            if (_publishPositionsThread != null && _publishPositionsThread.IsAlive)
                _publishPositionsThread.Join();

            if (_ezePublishThread != null && _ezePublishThread.IsAlive)
                _ezePublishThread.Join();
            _cancellationTokenSource.Dispose();
            _outgoingTrades?.Dispose();
            _ezeOutgoing?.Dispose();
        }
    }
}
