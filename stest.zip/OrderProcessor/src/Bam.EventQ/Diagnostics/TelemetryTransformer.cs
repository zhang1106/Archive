﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Diagnostics
{
    public class TelemetryTransformer<TIn, TOut> : IQueueItemTransformer<TIn, TOut>
    {
        private readonly IQueueItemTransformer<TIn, TOut> _inner;
        private readonly TimeSpan _publishInterval;
        private readonly ITelemetry _telemetry;

        private readonly Dictionary<Type, List<TimeSpan>> _timings = new Dictionary<Type, List<TimeSpan>>();
        private readonly Stopwatch _stopwatch = new Stopwatch();
        
        private TimeSpan _elapsed = TimeSpan.Zero;

        public TelemetryTransformer(IQueueItemTransformer<TIn, TOut> inner, ITelemetry telemetry, TimeSpan publishInterval)
        {
            _inner = inner;
            _telemetry = telemetry;
            _publishInterval = publishInterval;
        }

        public IReadOnlyList<TOut> Transform(TIn item, long sequence, bool isReplay)
        {
            _stopwatch.Restart();
            try
            {
                return _inner.Transform(item, sequence, isReplay);
            }
            finally
            {
                _stopwatch.Stop();
                _elapsed += _stopwatch.Elapsed;

                List<TimeSpan> timings;
                var type = item.GetType();
                if (!_timings.TryGetValue(type, out timings))
                {
                    timings = _timings[type] = new List<TimeSpan>(1024);
                }

                timings.Add(_stopwatch.Elapsed);

                if (_elapsed > _publishInterval)
                {
                    _elapsed = TimeSpan.Zero;

                    foreach (var t in _timings.Keys)
                    {
                        timings = _timings[t];
                        if (!timings.Any()) continue;

                        if (timings.Count < 50)
                        {
                            foreach (var ts in timings)
                            {
                                _telemetry.Record(t.GetDisplayName(), ts.TotalMilliseconds);
                            }
                        }
                        else
                        {
                            _telemetry.Record(t.GetDisplayName() + "-Average", timings.Select(ts => ts.TotalMilliseconds).Average());
                        }

                        timings.Clear();
                    }
                }
            }
        }
    }
}
