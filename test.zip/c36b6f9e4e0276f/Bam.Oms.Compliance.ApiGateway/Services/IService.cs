﻿namespace Bam.Oms.Compliance.ApiGateway.Services
{
    public interface IService
    {
        string Name { get; }
        void Start();
        void Stop();
    }
}
