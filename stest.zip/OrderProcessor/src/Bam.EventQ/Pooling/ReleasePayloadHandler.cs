﻿using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Pooling
{
    public class ReleasePayloadHandler<TItem> : IQueueItemHandler<PipelineQueueItem<TItem>>
    {
        private readonly IObjectPool _pool;

        public ReleasePayloadHandler(IObjectPool pool)
        {
            _pool = pool;
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            _pool.Release(item.Payload);
            item.SetPayload(default(TItem));
        }
    }
}
