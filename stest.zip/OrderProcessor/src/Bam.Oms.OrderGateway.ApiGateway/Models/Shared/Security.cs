﻿using System;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class Security : ICloneable
    {
        public string Key => BamSymbol;
        public SecurityType SecurityType { get; set; }
        public string Currency { get; set; }
        public string Issuer { get; set; }
        public string BamSymbol { get; set; }
        public string Ticker { get; set; }
        public string Cusip { get; set; }
        public string Isin { get; set; }
        public string Sedol { get; set; }
        public string BloombergSymbol { get; set; }
        public string Country { get; set; }
        public string Industry { get; set; }
        public string UnderlyingSymbol { get; set; }
        public decimal? ContractSize { get; set; }
        public bool IsBilateral { get; set; }
        public string InvestmentType { get; set; }
        public string QuotingCurrency { get; set; }
        public DateTime Created { get; set; }
        public decimal PricingFactor { get; set; }
        public decimal TradingFactor { get; set; }
        public string UltimateUnderlyingSymbol { get; set; }

        public void Apply(CachedSecurity update)
        {
            SecurityType type;
            if (!Enum.TryParse(update.SecurityType, true, out type))
            {
                type = SecurityType.Other;
            }

            SecurityType = type;
            Currency = update.Currency;
            Issuer = update.Issuer;
            BamSymbol = update.Symbol;
            Ticker = update.Ticker;
            Cusip = update.Cusip;
            Isin = update.Isin;
            Sedol = update.Sedol;
            BloombergSymbol = update.BloombergSymbol;
            Country = update.Country;
            Industry = update.Industry;
            UnderlyingSymbol = update.UnderlyingSymbol;
            QuotingCurrency = update.QuotingCurrency;
            InvestmentType = update.InvestmentType;
            PricingFactor = update.PricingFactor;
            TradingFactor = update.TradingFactor;
            UltimateUnderlyingSymbol = update.FindUltimateUnderlying().Symbol;
        }

        public object Clone()
        {
            return new Security
            {
                SecurityType = SecurityType,
                BamSymbol = BamSymbol,
                Ticker = Ticker,
                BloombergSymbol = BloombergSymbol,
                Created = Created,
                Currency = Currency,
                Sedol = Sedol,
                Isin = Isin,
                Cusip = Cusip,
                UnderlyingSymbol = UnderlyingSymbol,
                Issuer = Issuer,
                Country = Country,
                ContractSize = ContractSize,
                Industry = Industry,
                InvestmentType = InvestmentType,
                IsBilateral = IsBilateral,
                QuotingCurrency = QuotingCurrency,
                PricingFactor = PricingFactor,
                TradingFactor = TradingFactor,
                UltimateUnderlyingSymbol = UltimateUnderlyingSymbol
            };
        }

        public override string ToString()
        {
            return Key;
        }
    }
}
