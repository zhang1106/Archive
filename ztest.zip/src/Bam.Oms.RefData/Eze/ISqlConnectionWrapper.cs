﻿using System;
using System.Collections.Generic;
using System.Data;

namespace Bam.Oms.RefData.Eze
{
    /// <summary>
    /// Interface for abstracting away the physical database connectivity
    /// </summary>
    public interface ISqlConnectionWrapper
    {
        IDbTransaction BeginTransaction();
        string ConnectionString { get; set; }
        void Open();
        IEnumerable<T> Execute<T>(string executeSql);
        void Close();
        void EnsureConnectionOpen();
        IDbConnection Connection { get; }
    }
}