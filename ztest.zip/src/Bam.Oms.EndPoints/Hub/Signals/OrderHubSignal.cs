﻿using Bam.Oms.Data.Orders;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Messaging;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;

namespace Bam.Oms.EndPoints.Hub.Signals
{
    public class OrderHubSignal : HubSignal<Order, IOrderRepository>
    {
        public OrderHubSignal(ISignalRSessions<Order> sessions, IFlowManager flowManager, ILogger logger, IOrderRepository orderRepository, ITradeRepository tradeRepository)
            : base(sessions, flowManager, logger, orderRepository, tradeRepository)
        {
        }

        protected override IHubContext<ISignalRClient<SignalRPacket<Order>>> GetHubContext()
        {
            return GlobalHost.ConnectionManager.GetHubContext<OrderHub, ISignalRClient<SignalRPacket<Order>>>();
        }
    }
}