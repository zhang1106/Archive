﻿namespace Bam.Oms.Compliance.DataProvider
{
    public interface ILongOwnershipRuleResultProvider : IRuleResultProvider
    {
        decimal? GetRatio(int policyId, int ruleId, string bamSymbol);
        decimal? GetLowLimit(int policyId, int ruleId, string bamSymbol);
        bool GetIsRuleOverriden(int policyId, int ruleId, string bamSymbol);
    }
}
