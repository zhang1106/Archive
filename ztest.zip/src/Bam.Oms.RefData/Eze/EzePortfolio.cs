﻿namespace Bam.Oms.RefData.Eze
{
    public class EzePortfolio
    {
        public string PortfolioDescription { get; set; }
        public string Broker { get; set; }
        public string ManagerCode { get; set; }
    }
}