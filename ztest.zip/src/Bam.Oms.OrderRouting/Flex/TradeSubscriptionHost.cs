﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.OrderRouting.Contracts;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Ft;
using Grpc.Core;
using Grpc.Core.Utils;
using Order = Bam.Oms.Data.Orders.Order;

namespace Bam.Oms.OrderRouting.Flex
{
    public class TradeSubscriptionHost : SubscriptionHost<OrderAndPositionUpdateResponse>, ITradeSubscriptionHost
    {
        private readonly OrderService.IOrderServiceClient _orderService;
        private readonly ILogger _logger;

        protected event Action<IEnumerable<IPosition>> PositionUpdatedHandler;
        protected event Action<IEnumerable<IBlockTrade>> TradeUpdatedHandler;

        public event Action<IEnumerable<IPosition>> PositionUpdated
        {
            add
            {
                PositionUpdatedHandler += value;
                Subscribe();
            }
            remove { PositionUpdatedHandler -= value; }
        }
        public event Action<IEnumerable<IBlockTrade>> TradeUpdated
        {
            add
            {
                TradeUpdatedHandler += value;
                Subscribe();
            }
            remove { TradeUpdatedHandler -= value; }
        }

        public event Action<IEnumerable<IOrder>> OrderStatusChanged;

        public TradeSubscriptionHost(OrderService.IOrderServiceClient orderService, ILogger logger, IGrpcChannel channel, ISettings settings, ILoggingAgent eventLogger)
            : base(eventLogger, logger, channel, settings)
        {
            if (orderService == null) throw new ArgumentNullException(nameof(orderService));
            if (logger == null) throw new ArgumentNullException(nameof(logger));

            _orderService = orderService;
            _logger = logger;
        }

        private void Subscribe()
        {
            SubscriptionId = Guid.NewGuid().ToString();
            var request = new SubscriptionRequest { Name = SubscriptionId };
            var subscribeResponse = _orderService.Subscribe(request);

            _logger.InfoFormat($"Returned subscription stream for id {SubscriptionId}");

            //this is a limitation of the Grpc not allowing you to create or inherit from the AsyncServerStreamingCall, so for the unit test we want to check for null
            if (subscribeResponse != null)
                Subscribe(subscribeResponse.ResponseStream);
        }

        protected override void NewItemHandler(OrderAndPositionUpdateResponse response)
        {
            if (response.Positions.Count > 0)
            {
                if (PositionUpdatedHandler != null)
                {
                    _logger.Debug($"Flex order update {response.Positions.Select(p => p).ToList()}");
                    PositionUpdatedHandler(response.Positions.Select(ParsePosition));
                }
            }

            if (response.Orders.Count > 0)
            {
                var changedOrders = new List<Order>();

                var logMessage = new StringBuilder();
                foreach (var order in response.Orders)
                {
                    logMessage.AppendLine("Flex order update " + order.OrderId + " Status=" + order.Status + " Fill=" + order.FilledQuantity + " Price=" + order.WeightedAvgPrice);
                }
                _logger.Debug(logMessage.ToString());

                var tradeList = new List<IBlockTrade>();
                foreach (var order in response.Orders)
                {
                    var originalOrder = new Order()
                    {
                        ClientOrderId = order.OrderId,
                    };

                    IBlockTrade blockTrade = Utilities.Parse(order); // This is to cater to busts.
                    if (blockTrade != null && blockTrade.Allocations != null && blockTrade.Allocations.Any()) // To prevent trades with 0 allocations being created. Busts will have allocations with 0 quantities.
                    {
                        tradeList.Add(blockTrade);
                    }

                    //set the order fill status
                    var newStatus = Utilities.ConvertStatus(order);
                    originalOrder.OrderStatus = newStatus;
                    originalOrder.StreetOrders = Utilities.ParseStreetOrders(order);
                    changedOrders.Add(originalOrder);
                }

                if (tradeList.Count > 0)
                {
                    Utility.RaiseEvent(tradeList, TradeUpdatedHandler);
                }

                if (changedOrders.Count > 0)
                {
                    Utility.RaiseEvent(changedOrders, OrderStatusChanged);
                }
            }
        }

        protected override void Unsubscribe()
        {
            var request = new SubscriptionRequest();
            request.Name = SubscriptionId;

            //this will cause the unsubscribe to block
            //the call option of 1min will allow this to timeout if it doesn't unsubscribe
            var asyncServerStreamingCall = _orderService.Unsubscribe(request, new CallOptions(null, DateTime.UtcNow.AddSeconds(15)));

            if (asyncServerStreamingCall != null)
            {
                try
                {
                    var result = asyncServerStreamingCall.ResponseStream.ToListAsync().Result;
                }
                catch (AggregateException aex)
                {
                    _logger.Warn($"Unsubscribe timeed out for type  {SubscriptionType}");
                }
            }
        }

        protected override void Resubscribe()
        {
            Unsubscribe(); //not going to wait for the unsubscribe to return as this connection may have dropped anyways.
            Subscribe();
        }

        public IBlockTrade Parse(OrderUpdateResponse response, IOrder order)
        {
            var trade = Utilities.Parse(response);
            trade.Security = order.Security;
            trade.Side = order.Side;
            trade.TradeDate = order.TradeDate;

            return trade;
        }

        private Position ParsePosition(PositionUpdateResponse flexPosition)
        {
            return new Position
            {
                //need figure out how these map
                Portfolio = (Portfolio)Portfolio.Parse(flexPosition.Account),
                Security = new Bam.Oms.Data.Securities.Security() { BamSymbol = flexPosition.Symbol },
                CustodianName = flexPosition.PrimeBroker,
                TheoreticalQuantity = (decimal)flexPosition.Quantity,
                ActualQuantity = (decimal)flexPosition.Quantity,
                ShortMarkingQuantity = (decimal)flexPosition.Quantity,
                LongMarkingQuantity = (decimal)flexPosition.Quantity
            };
        }
    }
}