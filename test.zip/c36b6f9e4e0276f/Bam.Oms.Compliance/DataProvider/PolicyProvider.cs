﻿using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Compliance.Filters;

namespace Bam.Oms.Compliance.DataProvider
{
    public class PolicyProvider : IPolicyProvider 
    {
        private readonly IPolicyRepository<ICompliancePosition>  _policyRepository;
        private IEnumerable<IPolicy<ICompliancePosition>> _policies;
        private readonly object _lock = new object();
        public PolicyProvider(IPolicyRepository<ICompliancePosition> policyRepository)
        {
            _policyRepository = policyRepository;
        }
        public void RefreshData()
        {
            var policies = _policyRepository.GetAll();
          _policies = policies;
            
        }
        public IPolicy<ICompliancePosition> Get(string name)
        {
            if (_policies == null)
            {
                RefreshData();
            }
            var policy = _policies?.SingleOrDefault(r => string.Compare(r.Name, name, true) == 0);
            return policy;
        }
        //get all policies
        public IEnumerable<IPolicy<ICompliancePosition>> Get(PolicyFilter filter)
        {
            var policies = _policyRepository.GetAll();
 
            return policies;
        }
    }
}
