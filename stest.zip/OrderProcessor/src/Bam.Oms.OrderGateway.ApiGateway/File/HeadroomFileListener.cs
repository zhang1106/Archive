﻿using System.Collections.Generic;
using Bam.EventQ.Hosting;
using Bam.EventQ.Time;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using Newtonsoft.Json;

namespace Bam.Oms.OrderGateway.ApiGateway.File
{
    public class HeadroomFileListener : FileListener, IService
    {
        private readonly IComplianceSubmission _complianceSubmission;
        private readonly JsonSerializer _jsonSerializer;

        public HeadroomFileListener(IClock clock, string watchPath, string archivePath, string errorPath, IComplianceSubmission complianceSubmission) 
            : base(clock, watchPath, archivePath, errorPath)
        {
            _complianceSubmission = complianceSubmission;
            _jsonSerializer = new JsonSerializer();
        }

        protected override void ProcessFile(string path, string entryUser)
        {
            using (var file = System.IO.File.OpenText(path))
            {
                var headRooms = (List<HeadroomLoaded.Item>) 
                    _jsonSerializer.Deserialize(file, typeof(List<HeadroomLoaded.Item>));

                int count = 0;
                var messages = new List<HeadroomLoaded>();
                HeadroomLoaded current = null;
                foreach (var item in headRooms)
                {
                    if (current == null || count > 5000)
                    {
                        if (current != null)
                        {
                            messages.Add(current);
                        }

                        current = new HeadroomLoaded
                        {
                            IsWipeAndLoad = true,
                            Chunk = messages.Count + 1
                        };
                        count = 0;
                    }

                    current.Items.Add(item);
                    count += item.Headrooms.Count;
                }

                if (current != null)
                {
                    messages.Add(current);
                }

                foreach (var msg in messages)
                {
                    msg.TotalChunks = messages.Count;
                    _complianceSubmission.SubmitHeadroom(msg);
                }
            }
        }
    }
}