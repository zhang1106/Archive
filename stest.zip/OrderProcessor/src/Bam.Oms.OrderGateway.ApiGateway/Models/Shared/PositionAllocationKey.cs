﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public struct PositionAllocationKey : IEquatable<PositionAllocationKey>
    {
        private readonly int _hashCode;

        public PositionAllocationKey(string fund, string custodian)
        {
            Fund = string.Intern(fund);
            Custodian = string.Intern(custodian);
            _hashCode = unchecked(Fund.GetHashCode()*Custodian.GetHashCode());
        }

        public string Fund { get; }
        public string Custodian { get; }

        public bool Equals(PositionAllocationKey other)
        {
            return ReferenceEquals(other.Fund, Fund) && 
                   ReferenceEquals(other.Custodian, Custodian);
        }

        public override bool Equals(object obj)
        {
            if (!(obj is PositionAllocationKey))
                return false;

            return Equals((PositionAllocationKey) obj);
        }

        public override int GetHashCode()
        {
            return _hashCode;
        }
    }
}
