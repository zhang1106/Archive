﻿using System;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public class SodPositionUpdate
    {
        public int PositionId { get; set; }

        public string FundCode { get; set; }

        public string CustodianAccountCode { get; set; }

        public string Stream { get; set; }

        public DateTime EntryDate { get; set; }

        public int? ActionLogId { get; set; }

        public int AuditSequence { get; set; }

        public string LastModifiedBy { get; set; }

        public DateTime LastModifiedOn { get; set; }

        public DateTime CreatedOn { get; set; }

        public string CustodianName { get; set; }

        public decimal? Cost { get; set; }

        public Portfolio Portfolio { get; set; }

        public Security Security { get; set; }

        public decimal ActualQuantity { get; set; }

        public decimal TheoreticalQuantity { get; set; }

        public decimal LongMarkingQuantity { get; set; }

        public decimal ShortMarkingQuantity { get; set; }

        public int ActualSide => ActualQuantity < 0 ? 5 : 6; //enums from sod svc

        public decimal? Price { get; set; }

        public decimal? FXRate { get; set; }


    }
}
