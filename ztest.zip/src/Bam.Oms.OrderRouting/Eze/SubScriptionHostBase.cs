﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.Filtering;
using Bam.Oms.Data.Trades;
using Bam.Oms.Data.Orders;
using Eze.Common.Integration;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using Bam.Oms.Data.Configuration;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.OrderRouting.EZE
{
    public abstract class SubScriptionHostBase : IEmsSubscriptionAdapter
    {
        private readonly ISettings _settings;
        protected readonly ILogger _logger;

        protected bool StartSubscribe { get; set; }

        protected SubScriptionHostBase(ISettings settings, ILogger logger)
        {
            _settings = settings;
            _logger = logger;
        }

        public bool Subscribe(IFilter<EmsSubscription> filter = null)
        {
            StartSubscribe = true;
            
            return true;
        }

        public bool Unsubscribe()
        {
            StartSubscribe = false;
            return true;
        }

        /// <summary>
        /// Initiate connection to EMS
        /// </summary>
        /// <returns>Returns true if connection is successful. False otherwise.</returns>
        public bool Connect()
        {
            return true;
        }

        /// <summary>
        /// Disconnect from EMS
        /// </summary>
        public void Disconnect() { }

        /// <summary>
        /// Gets the current business date. This can also be used to determine if the EMS rolled.
        /// </summary>
        /// <returns></returns>
        public DateTime GetBusinessDate()
        {
            throw new NotImplementedException();
        }

        public bool RequestFullRefresh()
        {
            try
            {
                var url = _settings.EzeApiUrl;

                var factory =
                    new WebChannelFactory<IPublishSubscriber>(new Uri(url));
                factory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                var proxy = factory.CreateChannel();

                var req = new TradeSubscriptionRequest(new UserCredentials(string.Empty, string.Empty))
                {
                    IsFullRefreshRequired = _settings.IsFullRefreshRequired,
                    FullRefreshBatchSize = _settings.FullRefreshBatchSize,
                    FullRefreshTimeInSeconds = _settings.FullRefreshTimeInSeconds,
                    PublishTimeInSeconds = _settings.PublishTimeInSeconds,
                    PublishBatchSize = _settings.PublishBatchSize,
                };
                var result = proxy.Subscribe(req);
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
            }

            return true;
        }

        public event Action<string> Connected;

        public event Action<string> Disconnected;

        public event Action<string> RollStarted;

        public event Action<string> RollCompleted;

        public event Action<IEnumerable<IOrder>> OrderStatusChanged;

        public event Action<IEnumerable<IBlockTrade>> TradeUpdated;

        public event Action<Data.Securities.ISecurity> SecurityUpdated;

        public abstract void Dispose();
    }
}
