﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Orders;
using Bam.Oms.OrderRouting.Contracts;
using EzeEi = Eze.Common.Integration;

namespace Bam.Oms.OrderRouting.EZE
{
    public interface ISubscriptionHost : IEmsSubscriptionAdapter
    {
        void ProcessTradeUpdate(IReadOnlyList<EzeEi.Trade> trades);
        void ProcessTradeUpdateAsync(IReadOnlyList<EzeEi.Trade> trades);
        void ProcessAllocationUpdate(IReadOnlyList<EzeEi.Allocation> allocations);
        void ProcessAllocationUpdateAsync(IReadOnlyList<EzeEi.Allocation> allocations);
    }
}
