﻿using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Template
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            throw new System.NotImplementedException();
        }
    }
}