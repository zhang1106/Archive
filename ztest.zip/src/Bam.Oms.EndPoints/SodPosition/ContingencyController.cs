﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using Bam.Oms.Data.Configuration;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.EndPoints.PermissionService;
using Bam.Oms.Persistence.Contingency;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.SodPosition
{
    public class ContingencyController : BaseController
    {
        private readonly IContingencyDbRepository _contingencyRepository;
        private readonly IFlowManager _flowManager;

        public ContingencyController(IContingencyDbRepository contingencyDbRepository, IFlowManager flowManager, IHostConfiguration hostConfiguration, ILogger logger)
            : base(hostConfiguration, logger)
        {
            _contingencyRepository = contingencyDbRepository;
            _flowManager = flowManager;
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Contingency.Read, Function.OrderGateway.Contingency.Write")]
        public IList<ContingencyRecord> Get()
        {
            return Get(null);
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Contingency.Read, Function.OrderGateway.Contingency.Write")]
        public List<ContingencyRecord> Get(DateTime? cutoffTime)
        {
            cutoffTime = cutoffTime?.ToUniversalTime() ?? DateTime.Today.ToUniversalTime();
            var positions = _contingencyRepository.Get(cutoffTime.GetValueOrDefault()).ToList();
            return FilterPermissionedEntities(positions).ToList();
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Contingency.Write")]
        public void Refresh()
        {
            _logger.InfoFormat("Contingency position refresh request received.");
            Task.Factory.StartNew(() =>
            {
                _flowManager.RunContingency();
            });
            _logger.InfoFormat("Contingency position refresh request posted.");
        }

        protected IEnumerable<ContingencyRecord> FilterPermissionedEntities(IEnumerable<ContingencyRecord> orders)
        {
            if (!PermissionChecker.IsPermissionEnabled())
            {
                _logger.Warn("DEV or QA. Skipping permisions.");
                return orders;
            }
            StrategyInfo[] strategiesInfos = GetPermissionedStrategies(User.Identity);
            _logger.Debug($"The user {User.Identity.Name} is permissiond for {String.Concat(strategiesInfos, ",")}.");
            return orders.Where(
                    order => strategiesInfos.Any(s => order.Portfolio.ToString().Contains(s.StrategyCode)))
                    .ToList();
        }
    }
}
