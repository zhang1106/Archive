﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;
using NUnit;
using NUnit.Framework;
using Moq;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture()]
    public class HoldingProviderTest
    {
        private ISettings _settings ;
        private IHelper _helper;
        private Mock<IJsonDataProvider> _jsonDataProviderMock; 
        private Mock<ISecurityProvider> _securityProviderMock;
        private Mock<ICompositeDecomposer> _compositeDecomposerMock;
        private Mock<ICustomDataProvider> _customDataProviderMock;
        private Mock<IOgDataRepository> _customDataRepositoryMock;
        private ILogger _logger;

        [SetUp]
        public void Setup()
        {
           _settings = Factory.GetSettings();
           _helper = Factory.GetHelper(_settings);
           _jsonDataProviderMock = new Mock<IJsonDataProvider>();
           _securityProviderMock = new Mock<ISecurityProvider>();
           _compositeDecomposerMock = new Mock<ICompositeDecomposer>();
           _customDataProviderMock = new Mock<ICustomDataProvider>();
           _customDataRepositoryMock = new Mock<IOgDataRepository>();
           _logger = new Mock<ILogger>().Object;

        }

        [TestCase(false, true, "4-20-2017", "4-20-2017")]//no change if sod data is out of sync
        [TestCase(true, true, "4-20-2017", "4-19-2017")] //no change if current version is later
        [TestCase(true, false, "4-20-2017", "4-20-2017")]//change if current trade date is the same as the to-be-updated date
        [TestCase(true, false, "4-20-2017", "4-21-2017")]//change if current trade date is earlier than the to-be-updated date
        public void TestPopulateSodPositions(bool sodSynced, bool expected, string currTradeDate, string updateTradeDate)
        {
            //set up
            var sod = Factory.CreateSodPosition("AA", 100);
            sod.TradeDate = DateTime.Parse(updateTradeDate);
            var sods = new List<DtdPosition>() { sod };
            //
            _customDataRepositoryMock.Setup(c => c.IsSodPositionsSynced()).Returns(sodSynced);
            _customDataRepositoryMock.Setup(c => c.GetAllSodPositions()).Returns(sods);
            
            var holdingProvider = new HoldingProvider(_jsonDataProviderMock.Object, _securityProviderMock.Object, _compositeDecomposerMock.Object
                      , _customDataProviderMock.Object, _customDataRepositoryMock.Object, new Mock<IMarketDataProvider>().Object,
                      new Mock<IDwRepository>().Object, 
                      _settings, _helper, _logger
                      );
            //setup
            var pos = (Position)Factory.CreatePosition("IBM", "IBM", "IbmIsin", 1000);
            pos.Portfolio = (Portfolio)Portfolio.Parse("JACO-TECH");
            pos.EntryDate = DateTime.Parse(currTradeDate);
            var positions = new List<IPosition>(){pos,};
            holdingProvider.SodPositions = positions;
            
            //exe
            holdingProvider.LoadSodPositions();

            //verify
            Assert.IsTrue((holdingProvider.SodPositions == positions) == expected);
         }

        [TestCase(false, true, "4-20-2017", "4-20-2017")]//no change if sod data is out of sync
        [TestCase(true, true, "4-20-2017", "4-19-2017")] //no change if current version is later
        [TestCase(true, true, "4-20-2017", "4-20-2017")]//no change if current trade date is the same as the to-be-updated date
        [TestCase(true, false, "4-20-2017", "4-21-2017")]//change if current trade date is earlier than the to-be-updated date
        public void TestPopulateContingencyPositions(bool eodSynced, bool expected, string currTradeDate, string updateTradeDate)
        {
            //set up
            var eod = Factory.CreateSodPosition("AA", 100);
            eod.TradeDate = DateTime.Parse(updateTradeDate);
            var eods = new List<DtdPosition>() { eod };
            //
            _customDataRepositoryMock.Setup(c => c.IsContingencyPositionsSynced()).Returns(eodSynced);
            _customDataRepositoryMock.Setup(c => c.GetEodPositions()).Returns(eods);

            var holdingProvider = new HoldingProvider(_jsonDataProviderMock.Object, _securityProviderMock.Object, _compositeDecomposerMock.Object
                      , _customDataProviderMock.Object, _customDataRepositoryMock.Object, new Mock<IMarketDataProvider>().Object,
                      new Mock<IDwRepository>().Object,
                      _settings, _helper, _logger
                      );
            //setup
            var pos = (Position)Factory.CreatePosition("IBM", "IBM", "IbmIsin", 1000);
            pos.Portfolio = (Portfolio)Portfolio.Parse("JACO-TECH");
            pos.EntryDate = DateTime.Parse(currTradeDate);
            var positions = new List<IPosition>() { pos, };
            holdingProvider.SodPositions = positions;

            //exe
            holdingProvider.PopulateContingencyPositions();

            //verify
            Assert.IsTrue((holdingProvider.SodPositions == positions) == expected);
        }

        [TestCase("JACO-TECH", "IBM", 100, "JACO-TECH", "IBM", 200, 1 )]
        [TestCase("JACO-TECH", "IBM", 100, "JACO-TECH", "MS", 200, 2)]
        [TestCase("JACO-TECH", "IBM", 100, "JELL-TECH", "IBM", 200, 2)]
        public void TestUpdate(string currStrategy, string currSymbol, int currQty, string updateStrategy, string updateSymbol, int updateQty, int numboerOfPositions)
        {
            //set up
            var update = (Position)Factory.CreatePosition(updateSymbol, updateSymbol, updateSymbol+"ISIN", updateQty);
            update.Portfolio = (Portfolio)Portfolio.Parse(updateStrategy);
            var updates = new List<IPosition>() { update };
            //
            _customDataProviderMock.Setup(c => c.GetEntity(It.IsAny<string>())).Returns("BAM");
            _compositeDecomposerMock.Setup(c=>c.Decompose(It.IsAny<Position>())).Verifiable();
            
            var holdingProvider = new HoldingProvider(_jsonDataProviderMock.Object, _securityProviderMock.Object, _compositeDecomposerMock.Object
                      , _customDataProviderMock.Object, _customDataRepositoryMock.Object, new Mock<IMarketDataProvider>().Object,
                      new Mock<IDwRepository>().Object,
                      _settings, _helper, _logger
                      );
            //setup
            var pos = (Position)Factory.CreatePosition(currSymbol, currSymbol, currStrategy, 1000);
            pos.Portfolio = (Portfolio)Portfolio.Parse(currStrategy);
            var positions = new List<IPosition>() { pos, };
            var lookup = positions.ToLookup(p => p.Key);
            var dictionary = lookup.Select(l => l.Key)
                .ToDictionary<string, string, IList<IPosition>>(key => key, key => lookup[key].ToList());
            var sodPositionDictionary = new ConcurrentDictionary<string, IList<IPosition>>(dictionary);

            holdingProvider.SodPositions = positions;
            holdingProvider.SodPositionDictionary = sodPositionDictionary;

            //exe
            holdingProvider.Update(updates, PositionType.Sod);

            //verify
            Assert.IsTrue(holdingProvider.SodPositions.Count == numboerOfPositions);
        }
    }
}
