﻿using Bam.Oms.Data.Positions;
using Bam.Oms.Messaging;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;

namespace Bam.Oms.EndPoints.Hub
{
    public class PositionHub : PortfolioFilteredSignalRHub<Position>
    {
        public PositionHub(ISignalRSessions<Position> sessions, ILogger logger) : base(sessions, logger)
        {
        }

        public override IHubContext<ISignalRClient<SignalRPacket<Position>>> GetHubContext()
        {
            return GlobalHost.ConnectionManager.GetHubContext<PositionHub, ISignalRClient<SignalRPacket<Position>>>();
        }
    }
}