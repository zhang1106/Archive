﻿USE [OrderGateway]

GO
 
CREATE TABLE [cp].[FlatPosition](
	[BamSymbol] [VARCHAR](100) NULL,
	[UnderlyingSymbol] [VARCHAR](100) NULL,
	[Isin] [VARCHAR](100) NULL,
	[CompositeParent] [VARCHAR](100) NULL,
	[SecurityType] [VARCHAR](100) NULL,
	[Strategy] [VARCHAR](100) NULL,
	[CustodianAcct] [VARCHAR](100) NULL,
	[Entity] [VARCHAR](100) NULL,
	[Quantity] [DECIMAL](18, 0) NULL,
	[PositionType] VARCHAR(50) NULL,
	[TimeStamp] [DATETIME] NULL
) ON [PRIMARY]


GO
