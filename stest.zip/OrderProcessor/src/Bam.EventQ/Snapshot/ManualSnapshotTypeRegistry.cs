﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Bam.EventQ.Snapshot
{
    public class ManualSnapshotTypeRegistry : ISnapshotTypeRegistry
    {
        private readonly HashSet<ISnapshotRecoverable> _recoverables = new HashSet<ISnapshotRecoverable>();
        private readonly Dictionary<string, Type> _registryByName = new Dictionary<string, Type>();
        private readonly Dictionary<Type, string> _registryByType = new Dictionary<Type, string>();

        public IEnumerable<ISnapshotRecoverable> Recoverables => _recoverables;

        public void Register(ISnapshotRecoverable recoverable)
        {
            if (_recoverables.Add(recoverable))
            {
                foreach (var item in GetSnapshotTypes(recoverable))
                {
                    _registryByName[item.GetDisplayName()] = item;
                    _registryByType[item] = item.GetDisplayName();
                }
            }
        }

        public IEnumerable<Type> GetTypes(ISnapshotRecoverable recoverable)
        {
            return GetSnapshotTypes(recoverable);
        }

        public Type GetType(string snapshotName)
        {
            Type type;
            if (snapshotName == null || !_registryByName.TryGetValue(snapshotName, out type))
            {
                type = null;
            }

            return type;
        }

        public string GetName(ISnapshot snapshot)
        {
            string name;
            if (snapshot == null || !_registryByType.TryGetValue(snapshot.GetType(), out name))
            {
                name = null;
            }

            return name;
        }

        private IEnumerable<Type> GetSnapshotTypes(ISnapshotRecoverable recoverable)
        {
            return
                from i in recoverable.GetType().GetInterfaces()
                where i.IsGenericType &&
                      typeof(ISnapshotRecoverable<>) == i.GetGenericTypeDefinition()
                select i.GetGenericArguments()[0];
        }
    }
}