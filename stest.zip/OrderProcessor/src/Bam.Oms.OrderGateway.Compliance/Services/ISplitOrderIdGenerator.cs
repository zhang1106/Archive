﻿namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public interface ISplitOrderIdGenerator
    {
        long GetNextOrderId(long originalOrderId);
    }
}
