using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Bam.Locate.Hub.Data;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.EndPoints;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.Persistence.Contingency;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.PositionTracker;
using Bam.Oms.RefData;
using Bam.Oms.Service.Orders;
using Bam.Oms.ShortLocate;
using Bam.Oms.SodPosition.Svc;
using Bam.Oms.TradeMarker;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Microsoft.Practices.ObjectBuilder2;
using Newtonsoft.Json;
using Bam.Oms.EndPoints.Eze;
using Bam.Oms.OrderRouting.EZE;

namespace Bam.Oms.Service.StateMachine
{
    public class FlowManager : IFlowManager
    {
        private readonly ISettings _settings;
        private readonly ILogger _logger;
        private readonly ILoggingAgent _eventLogger;
        private readonly IPositionTracker _positionTracker;
        private readonly IPositionRepository _positionRepository;
        private readonly ILocateService _locateService;
        private readonly ISecurityMasterService _securityMasterService;
        private readonly IEmsRouter _emsRouter;
        private readonly ISodPositionEdit _sodPositionEdit;
        private readonly IOrderRepository _orderRepository;
        private readonly ITradeRepository _tradeRepository;
        private readonly IClientOrderIdRepository _clientOrderIdRepository;
        private readonly ISecurityRepository _securityRepository;
        private readonly IContingencyDbRepository _contingencyDbRepository;
        private readonly IFlowClient[] _flowClients;
        private readonly IRollClient[] _rollClients;
        private readonly IDateProvider _dateProvider;
        private readonly IMessageHandler _messageHandler;
        private readonly INotificationCache _notificationCache;
        private readonly IOrderNotifier _orderorNotifier;
        private readonly IStartOfDayPositionCalculator _startOfDayPositionCalculator;
        private readonly IAccountService _accountService;

        private readonly IOrderPrepUtility _orderPrepUtility;

        private CancellationTokenSource _contingencyCancellationTokenSource = new CancellationTokenSource();
        private int _publishInProgress;

        private readonly IDictionary<string, IStripedProcessor> _stripedProcessors = new Dictionary<string, IStripedProcessor>();
        private readonly ReaderWriterLockSlim _stripedProcessorLockSlim = new ReaderWriterLockSlim();

        public event Action FlowManagerInitialized;
        public event Action<IOrder> OrderStateChanged;
        public event Action<IList<IOrder>> OrdersStateChanged;
        public event Action<IBlockTrade> TradeStateChanged;
        public event Action<IList<IBlockTrade>> TradesStateChanged;
        public event Action<IList<Order>> OrdersOnEOD;
        public event Action<IList<BlockTrade>> TradesOnEOD;
        public event Action<IList<Position>> PositionsOnEOD;
        public event Action<DateTime> SODRolled;
        public event Action OnConnected;
        public event Action OnDisconnect;

        public FlowManager(IEmsRouter emsRouter, ILocateService locateService, ISecurityMasterService securityMasterService, 
            ISodPositionEdit sodPositionEdit, IOrderRepository orderRepository, ITradeRepository tradeRepository, ISecurityRepository securityRepository, 
            IClientOrderIdRepository clientOrderIdRepository, IContingencyDbRepository contingencyDbRepository, IFlowClient[] flowClients, IRollClient[] rollClients, 
            IDateProvider dateProvider, ISettings settings, ILogger logger, ILoggingAgent eventLogger, IPositionTracker positionTracker, 
            IPositionRepository positionRepository, IMessageHandler messageHandler, INotificationCache notificationCache, 
            IOrderNotifier orderorNotifier, IOrderPrepUtility orderPrepUtility, IStartOfDayPositionCalculator startOfDayPositionCalculator,
            IAccountService accountService)
        {
            if (locateService == null) throw new ArgumentNullException(nameof(locateService));
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));
            if (startOfDayPositionCalculator == null) throw new ArgumentNullException(nameof(startOfDayPositionCalculator));
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));

            _settings = settings;
            _logger = logger;
            _eventLogger = eventLogger;
            _positionTracker = positionTracker;
            _positionRepository = positionRepository;

            _locateService = locateService;
            _securityMasterService = securityMasterService;
            _emsRouter = emsRouter;
            _sodPositionEdit = sodPositionEdit;
            _orderRepository = orderRepository;
            _tradeRepository = tradeRepository;
            _securityRepository = securityRepository;
            _clientOrderIdRepository = clientOrderIdRepository;
            _contingencyDbRepository = contingencyDbRepository;
            _flowClients = flowClients;
            _rollClients = rollClients;
            _dateProvider = dateProvider;
            _messageHandler = messageHandler;
            _notificationCache = notificationCache;
            _orderorNotifier = orderorNotifier;
            _orderPrepUtility = orderPrepUtility;
            _startOfDayPositionCalculator = startOfDayPositionCalculator;
            _accountService = accountService;

            _sodPositionEdit.SodPositionLoad += SodPositionEditSodPositionLoad;
            _sodPositionEdit.SodPositionUpdated += SodPositionEditSodPositionUpdated;

            _emsRouter.OrderStatusChanged += EmsRouterOrderStatusChanged;
            _emsRouter.TradeUpdated += EmsRouterTradeUpdated;
            _emsRouter.RollStarted += EmsRouterRollStarted;
            _emsRouter.RollCompleted += EmsRouterRollCompleted;

            _locateService.LocateAssignmentUpdated += LocateAssignmentUpdated;
            _securityMasterService.SecurityUpdated += SecurityMasterServiceOnSecurityUpdated;
        }

        private void SecurityMasterServiceOnSecurityUpdated(IList<IUpdateSecurity> securities)
        {
            var groupedAssignments = securities.GroupBy(sec => GetOrAssignProcessor(sec.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());
            var tasks = new Task[groupedAssignments.Count];

            var i = 0;
            foreach (var kvp in groupedAssignments)
            {
                tasks[i] = kvp.Key.UpdateSecurityInfo(kvp.Value);
                i++;
            }

            Task.WaitAll(tasks);
        }

        private void LocateAssignmentUpdated(IList<TradeAssignment> assignments)
        {
            var groupedAssignments = assignments.GroupBy(assignment => GetOrAssignProcessor(assignment.Ticker)).ToDictionary(g => g.Key, g => g.ToList());
            foreach (var kvp in groupedAssignments)
            {
                foreach (var tradeAssignment in kvp.Value)
                {
                    kvp.Key.InvokeOnProcessor(() =>
                    {
                        try
                        {
                            var currentOrder = _orderRepository.Get(tradeAssignment.TradeId);

                            //not sure if this is possible
                            if (currentOrder == null)
                            {
                                _logger.Warn($"Received locate assignment for order id that does not exist in order repo {tradeAssignment.TradeId}");
                                return null;
                            }

                            //if the order is not waiting for a locate (such as a canceled order), we do not want to accept this locate
                            if (currentOrder.OrderStatus != BamOrderStatus.PendingLocate)
                            {
                                _logger.Info(
                                    $"Order:{currentOrder.ClientOrderId} not in PendingLocate, actual state {currentOrder.OrderStatus}.  Ignoring LocateAssignment:{JsonConvert.SerializeObject(tradeAssignment)}");
                                return currentOrder;
                            }

                            if (currentOrder.Locate != null && currentOrder.Locate.Count > 0 && tradeAssignment.Approvals != null && tradeAssignment.Approvals.Count > 0)
                            {
                                var currentLocateKey =
                                    $"{currentOrder.Locate.OrderBy(r => r.PrimeBroker).ThenBy(r => r.Size).Select(r => r.PrimeBroker + (int)r.Size).Aggregate((i, j) => i + j)}{currentOrder.LocateStatus}";

                                var newAssignmentKey =
                                    $"{tradeAssignment.Approvals.OrderBy(r => r.Broker).ThenBy(r => r.Size).Select(r => r.Broker + r.Size).Aggregate((i, j) => i + j)}{tradeAssignment.BrokerLocateStatus}";

                                _logger.Debug($"Order Id {tradeAssignment.TradeId}; new assignment {newAssignmentKey}, old assignment {currentLocateKey}");

                                if (currentLocateKey.Equals(newAssignmentKey))
                                {
                                    _logger.Warn($"Received duplicate assignment skipping; assignment {JsonConvert.SerializeObject(tradeAssignment)}, order {JsonConvert.SerializeObject(currentOrder)}");
                                    return currentOrder;
                                }
                            }

                            //if we make it here we're re-assigning 
                            _logger.Info($"Applying trade assignment to order id {tradeAssignment.TradeId}.  {JsonConvert.SerializeObject(tradeAssignment)}");

                            //clear any old assignments
                            if (currentOrder.Locate == null)
                                currentOrder.Locate = new List<Data.Orders.Locate>();
                            else
                                currentOrder.Locate.Clear();


                            currentOrder.OrderStatus = tradeAssignment.BrokerLocateStatus == BrokerLocateStatus.Approved
                                ? BamOrderStatus.PendingSend
                                : tradeAssignment.BrokerLocateStatus == BrokerLocateStatus.Pending ? BamOrderStatus.PendingLocate : BamOrderStatus.IncompleteLocate;

                            currentOrder.LocateStatus = (LocateStatus?)tradeAssignment.BrokerLocateStatus;

                            if (tradeAssignment.Approvals != null)
                            {
                                foreach (var requestItem in tradeAssignment.Approvals)
                                {
                                    if (requestItem.LocateId == null)
                                    {
                                        _logger.Warn("Locate approval item cannot have a null locateId");
                                        continue;
                                    }

                                    var assignment = new Data.Orders.Locate() { LocateId = requestItem.LocateId };
                                    currentOrder.Locate.Add(assignment);

                                    assignment.AssignmentId = requestItem.ApprovalId;
                                    assignment.Size = requestItem.Size;
                                    assignment.PrimeBroker = requestItem.Broker;
                                    assignment.Rate = requestItem.Rate;
                                    if (requestItem.RateType != null)
                                        assignment.RateType = requestItem.RateType == "R" ? RateType.Rebate : RateType.Fee;
                                    assignment.TimeReceived = requestItem.ResponseTime;
                                }

                                //if the order is now fully located, allow the OG to send it to flex based on routed size > 0
                                if (currentOrder.OrderStatus == BamOrderStatus.PendingSend)
                                    currentOrder.RoutedSize = currentOrder.Size;
                            }

                            return _orderRepository.Save(currentOrder);
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Failed to update trade assignment for order id {tradeAssignment.TradeId}{JsonConvert.SerializeObject(tradeAssignment)} \n  {ex.Message} {ex.StackTrace} \n");
                            return null;
                        }
                    });
                }
            }
        }

        public void Initialize()
        {
            Task.Run(() => InitializeInternal())
                .ContinueWith(t =>
                {
                    _logger.Error("Killing process due to initialization failure", t.Exception);
                    Process.GetCurrentProcess().Kill();
                }, TaskContinuationOptions.OnlyOnFaulted);
        }

        private void InitializeInternal()
        {
            var sw = new Stopwatch();
            sw.Start();

            _logger.Info("Connecting to EMS.....");
            //Connect to FLEX                
            while (!_emsRouter.Connect())
            {
                _logger.Error($"Failed connecting to EMS. Will retry in {_settings.ConnectionRetryInterval} seconds.");
                Thread.Sleep(_settings.ConnectionRetryInterval*1000);
            }
            _logger.Info("Successfully connected to EMS.");

            var bamSodPositions = _sodPositionEdit.GetPositions(asofdate: null,
                stream: null, fundCode: null, custodianAccountCode: null, strategyCode: null, securityType: null,
                    bamSymbol: null).ToList();

	        _logger.Info("Getting SOD positions...");
	        DateTime emsBusinessDate = _emsRouter.GetBusinessDate();
	        _logger.Info($"EMS Business date is {emsBusinessDate}.");
	                
	        IReadOnlyList<IPosition> sodPositions = bamSodPositions;
	        if (_settings.SeedSodPositionsFromEms)
            {
	            sodPositions = _startOfDayPositionCalculator.Pick(bamSodPositions, 
	                GetPositionsFromEms(), emsBusinessDate);
            }

            _logger.Info("************************BEGIN SOD Position dump*************************************");
            foreach (var position in sodPositions)
            {
                _logger.Info($"BAM_SOD_POSITION|Portfolio:{position.Portfolio};Security:{position.Security.BamSymbol};Actual:{position.ActualQuantity};Theo:{position.TheoreticalQuantity};LongMarking:{position.LongMarkingQuantity};ShortMarking:{position.ShortMarkingQuantity}.");
            }
            _logger.Info("************************END SOD Position dump*************************************");

            var positionSymGroups = sodPositions.GroupBy(position => position.Security.Key).Select(g => new
            {
                g.Key,
                RecordCount = g.Count()
            }).OrderBy(a => a.RecordCount).ToList();

            _logger.Info($"Finished getting SOD positions. Total Count {sodPositions.Count}");

            _logger.Info("Getting cached orders...");
            IList<Order> ordersInCache = _orderRepository.Get(_settings.SODDateTime.ToUniversalTime()).ToList();

            _logger.Info($"************************BEGIN Order dump*************************************");
            foreach (var order in ordersInCache)
            {
                _notificationCache.AddToOrderIdIndex(order, false);
                _logger.Info($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] Portfolio:{order.Portfolio.ToString()};Security:{order.Security.BamSymbol};Quantity:{order.Size}[{order.Side};Order Status:{order.OrderStatus}.");
            }

            _logger.Info($"************************END Order dump*************************************");

            var orderSymGroups = ordersInCache.GroupBy(order => order.Security.Key).Select(g => new
            {
                g.Key,
                RecordCount = g.Count()
            }).OrderBy(a => a.RecordCount).ToList();

            _logger.Info($"Finished getting orders from cache. Total Count {ordersInCache.Count}");

            var symbolGroups =
                positionSymGroups.Union(orderSymGroups).OrderByDescending(a => a.RecordCount).ToList();

            _logger.Info($"Setting up striped processors for {symbolGroups.Count} symbols...");
            foreach (var symbolGroup in symbolGroups)
            {
                _logger.Info($"Setting up {symbolGroup.Key}...");
                IStripedProcessor stripedProcessor = GetOrAssignProcessor(symbolGroup.Key);
                stripedProcessor.SetInitialized(false);
                stripedProcessor.TotalOrdersProcessed += symbolGroup.RecordCount;
                _logger.Info($"Finished setting up {symbolGroup.Key}.");
            }
            _logger.Info("Finished setting up striped processors.");

            _logger.Info("Beginning recovery process...");
            _logger.Info("Subscribing to EMS....");
            if (!_emsRouter.Subscribe())
            {
                _logger.Error("Subscription to EMS failed.");
                throw new ApplicationException("Subscription to EMS failed");
            }

            _logger.Info("Getting all orders and trades from EMS...");
            IReadOnlyList<IOrder> ordersFromEms;
            IReadOnlyList<IBlockTrade> tradesFromEms;
            _emsRouter.GetOpenOrders(out ordersFromEms, out tradesFromEms);
            _logger.Info($"Received {ordersFromEms.Count()} from EMS.");

            //Sync up order status and size from EMS
            if (ordersFromEms.Count > 0)
            {
                foreach (IOrder order in ordersInCache)
                {
                    IOrder orderFromEms = ordersFromEms.FirstOrDefault(o => o.ClientOrderId == order.ClientOrderId);
                    if (orderFromEms != null)
                    {
                        order.OrderStatus = orderFromEms.OrderStatus;
                        order.StatusMessages.AddRange(orderFromEms.StatusMessages);
                        order.StreetOrders = orderFromEms.StreetOrders;
                    }
                    else
                    {
                        _logger.Info($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}: Order is not in EMS. {order}.");
                        if (order.OrderStatus != BamOrderStatus.PendingValidation &&
                            order.OrderStatus != BamOrderStatus.Marked &&
                            order.OrderStatus != BamOrderStatus.Cancelled &&
                            order.OrderStatus != BamOrderStatus.Error &&
                            order.OrderStatus != BamOrderStatus.Deleted)
                        {
                            order.StatusMessages.Add($"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}:Unknown to EMS");
                        }
                    }
                    order.StreetOrders?.ForEach(so =>
                    {
                        so.Portfolio = order.Portfolio;
                        so.Security = order.Security;
                        so.PrimeBroker = order.Custodian;
                        so.TradeDate = order.TradeDate;
                        so.Side = order.Side;
                    });
                }

                var trades = new List<IBlockTrade>(tradesFromEms.Count);
                var orderLookup = ordersInCache.ToDictionary(o => o.ClientOrderId);
                foreach (IBlockTrade trade in tradesFromEms)
                {
                    Order order;
                    if (orderLookup.TryGetValue(trade.ClientOrderId, out order))
                    {
                        trade.Portfolio = order.Portfolio;
                        trade.Security = order.Security;
                        trade.TradeDate = order.TradeDate;
                        trade.Trader = order.Trader;
                        trade.Side = order.Side;
                        trades.Add(trade);
                    }
                }

                _tradeRepository.Clear(_settings.SODDateTime.ToUniversalTime());
                _tradeRepository.Save(trades.Cast<BlockTrade>());
            }

            _orderRepository.Clear(_settings.SODDateTime.ToUniversalTime());
            _orderRepository.Save(ordersInCache);

            _logger.Info("Finished recovery process.");

            _logger.Info("Initializing position trackers....");
            //Initialize the position tracker after orders have been reconciled
            _positionTracker.LoadSODPositions(sodPositions, _orderRepository.GetAllOrders(o => o.OrderStatus != BamOrderStatus.Error), _tradeRepository.GetAllTrades());
            _logger.Info("Finished initializing position trackers.");

            //Signal all processors to continue processing events
            _stripedProcessors.Values.ForEach(sp => sp.SetInitialized(true));

            _logger.Info($"Order Handler initialized. Took {sw.Elapsed} to initialize handler.");

            _logger.Info("Loading initial securities.");
            _securityMasterService.LoadSecurityCache(sodPositions.ToList());

            PublishOrders(false, FlowClientScope.Both);
            PublishTrades(false, FlowClientScope.Both);

            FlowManagerInitialized?.Invoke();
            _locateService.SubscribeToLocates();
            _messageHandler.SubscribeMqMessages();

            _logger.Info("Start receiving full refresh request");
            _emsRouter.RequestFullRefresh();
        }

        private int Flush()
        {
            _logger.InfoFormat("Flush request received.");
            var count = _orderRepository.ClearAll();
            count += _tradeRepository.ClearAll();
            count += _securityRepository.ClearAll();
            count += _clientOrderIdRepository.ClearAll();

            IList<IPosition> sodPositions = _sodPositionEdit.GetPositions(asofdate: null, stream: null, fundCode: null, custodianAccountCode: null, strategyCode: null, securityType: null, bamSymbol: null);
            SodPositionEditSodPositionLoad(sodPositions.Cast<Position>().ToList());
            _logger.InfoFormat("Flush request completed.");
            return count;
        }

        public IList<IOrder> ProcessOrders(List<IOrder> orders, string batchId = null, bool fromFile = false)
        {
            var sw = new Stopwatch();
            var sw0 = new Stopwatch();

            string msg = $"[BatchId:{batchId}] begin processing {orders.Count} orders...";
            _logger.Info(msg);
            sw.Start();

            List<IOrder> markedOrders = new List<IOrder>();
            try
            {
                //Mark and Position Track
                sw0.Start();

                var ordersWithErrors = orders.Where(r => r.OrderStatus == BamOrderStatus.Error).ToList();
                orders = orders.Where(r => r.OrderStatus != BamOrderStatus.Error).ToList();

                Task<IOrder>[] saveTasks = SaveState(ordersWithErrors, batchId);

                IList<IOrder> markedOrdersAll = MarkAndTrack(orders, batchId);
                _logger.Info($"[BatchId:{batchId}] Took {sw0.Elapsed} to mark {orders.Count} orders, resulted in {markedOrdersAll.Count} marked orders");
                sw0.Restart();
                markedOrders = GroupOrdersToProcess(markedOrdersAll, batchId);
                _logger.Info($"[BatchId:{batchId}] Took {sw0.Elapsed} to group orders");

                //Save State for the first time after marking and grouping for duplicates
                //ensure the initial state of all short order is pending locate (which has not happened yet....LocateShorts)                
                foreach (var markedOrder in markedOrders.Where(o => o.Side == SideType.SellShort))
                    markedOrder.OrderStatus = BamOrderStatus.PendingLocate;

                foreach (var markedOrder in markedOrders.Where(o => o.Side != SideType.SellShort))
                    markedOrder.OrderStatus = BamOrderStatus.PendingSend;

                saveTasks = saveTasks.Concat(SaveState(markedOrders, batchId)).ToArray();

                if (markedOrders.Any(o => o.Side == SideType.SellShort))
                {
                    sw0.Restart();
                    //Locate shorts
                    markedOrders = LocateShorts(markedOrders, batchId);

                    _logger.Info(
                        $"[BatchId:{batchId}] Took {sw0.Elapsed} to get locate {markedOrders.Count(o => o.Side == SideType.SellShort)} sell short orders.");
                    sw0.Restart();

                }

                //exclude any pending locate orders
                var markedOrdersSansPendingLocate = markedOrders.Where(r => r.OrderStatus != BamOrderStatus.PendingLocate).ToList();

                //Submit for execution
                if (markedOrdersSansPendingLocate.Any())
                {
                    //Save State, but only orders with no pending locate, those will be updated 
                    saveTasks = saveTasks.Concat(SaveState(markedOrdersSansPendingLocate, batchId)).ToArray();

                    Task.WaitAll(saveTasks);
                    
                    //remove any strategies that should not be automatically sent
                    var sendableOrders = markedOrdersSansPendingLocate.Where(r =>
                            (r.Portfolio.AutoSendToEms == AutoSendToEms.Always) ||
                            (r.Portfolio.AutoSendToEms == AutoSendToEms.FromTraderFileOrApi && _accountService.IsValidTrader(r.CreatedUser)) ||
                            (r.Portfolio.AutoSendToEms == AutoSendToEms.FromTraderApiOnly && _accountService.IsValidTrader(r.CreatedUser) && !fromFile)
                    ).ToList();                    

                    //EMS-196: Sort before submit
                    sendableOrders.Sort();
                    sw0.Restart();
                    SubmitOrders(sendableOrders, batchId);

                    //No need to save order state. Submit order publishes the state at the end to striped processors which saves the final state. 

                    _logger.Info($"[BatchId:{batchId}] Took {sw0.Elapsed} to submit {sendableOrders.Count} orders.");
                    sw0.Restart();
                    Task.WaitAll(saveTasks);
                    msg = $"[BatchId:{batchId}] completed processing {markedOrders.Count} orders.";
                    _logger.Info(msg);
                    return markedOrders;
                }

                //if you get here and the order is just pending locate, it's a valid order, otherwise mark as an error
                var ordersNotPendingLocate = markedOrders.Where(r => r.OrderStatus != BamOrderStatus.PendingLocate).ToList();

                if (ordersNotPendingLocate.Any())
                {
                    //We should never get here.
                    _logger.Error($"[BatchId:{batchId}] No orders to submit for batch."); // Should never get here.

                    //Set all orders to Rejected.
                    ordersNotPendingLocate.ForEach(o => o.OrderStatus = BamOrderStatus.Error);

                    //Save State
                    saveTasks = saveTasks.Concat(SaveState((List<IOrder>)orders, batchId)).ToArray();
                    Task.WaitAll(saveTasks);
                }

                return markedOrders;
            }
            catch (AggregateException exceptions)
            {
                HandleError(orders, batchId, markedOrders, "Error while processing orders.");

                foreach (var ex in exceptions.InnerExceptions)
                {
                    _logger.Error($"[BatchId:{batchId}] Error processing orders, {JsonConvert.SerializeObject(orders.ToList())} {0}-{1}", ex);
                }
                return orders;
            }
            catch (Exception ex)
            {
                HandleError(orders, batchId, markedOrders, "Unknown to EMS");
                _logger.Error($"[BatchId:{batchId}] Error processing orders, {JsonConvert.SerializeObject(orders.ToList())} {0}-{1}", ex);
                return orders;
            }
            finally
            {
                sw.Stop();
                msg = $"[BatchId:{batchId}] took {sw.Elapsed} to process {orders.Count} orders.";
                _logger.Info(msg);
            }
        }

        private List<IOrder> GroupOrdersToProcess(IList<IOrder> orders, string batchId = null)
        {
            List<IOrder> ordersToProcess = orders.GroupBy(
                order =>
                    new
                    {
                        order.TradeDate,
                        order.SettleDate,
                        order.BatchId,
                        order.Portfolio,
                        order.Security,
                        order.Side,
                        order.Custodian,
                        order.Trader,
                        order.Urgency,
                        order.TraderLogin,
                        order.TraderId,
                        LimitOrder = order.Price.HasValue,
                        order.CreatedUser,
                    })
                .Select(
                    g => (IOrder)
                        new Order
                        {
                            TraderId = g.Key.TraderId,
                            TraderLogin = g.Key.TraderLogin,
                            Trader = g.Key.Trader,
                            TradeDate = g.Key.TradeDate,
                            SettleDate = g.Key.SettleDate,
                            BatchId = g.Key.BatchId,
                            Portfolio = g.Key.Portfolio,
                            Security = g.Key.Security,
                            Side = g.Key.Side,
                            Custodian = g.Key.Custodian,
                            Urgency = g.Key.Urgency,
                            ExecutionInstructions =
                                new List<ExecutionInstruction>(g.SelectMany(o => o.ExecutionInstructions)),
                            Note = string.Join(",", g.Select(o => o.Note)),
                            ClientOrderId = g.Min(o => o.ClientOrderId),
                            RoutedSize = g.Sum(o => o.RoutedSize),
                            Size = g.Sum(o => o.Size),
                            Price = g.Key.LimitOrder ? g.Sum(o => o.Size * o.Price) / g.Sum(o => o.Size) : null,
                            TradeCurrency = (g.Key.Security as IUpdateSecurity)?.TradingCurrency,
                            SettlementCurrency = (g.Key.Security as IUpdateSecurity)?.SettlementCurrency,
                            CreatedUser =  g.Key.CreatedUser,
                        }).ToList();

            List<IOrder> collapsedOrders = orders.Except(ordersToProcess).ToList();
            _logger.Info($"[BatchId:{batchId} collapsed {collapsedOrders.Count} orders into others on the same side. Collapsed Orders: {JsonConvert.SerializeObject(collapsedOrders.ToList())}.");
            Task<IOrder>[] deleteTasks =
                collapsedOrders.ConvertAll(order => (IOrder)order.Clone()).AsParallel().Select(async order => await GetOrAssignProcessor(order.Security.Key).DeleteOrderAsync(order, batchId))
                    .ToArray();
            _logger.Info($"[BatchId:{batchId}] processing {orders.Count} unique orders.");
            return ordersToProcess;
        }
        
        public IList<IOrder> RouteOrders(IList<string> orderIds, string entryUser)
        {
            _logger.Info($"Routing {orderIds.Count} orders.");
            List<IOrder> ordersToRoute = new List<IOrder>();
            foreach (string orderId in orderIds)
            {
                IOrder ordertoRoute = _orderRepository.Get(orderId);
                if (ordertoRoute != null)
                {
                    _logger.Info($"[OrderId:{ordertoRoute.ClientOrderId}] will be routed to EMS...");
                    ordersToRoute.Add(ordertoRoute);
                }
                else
                {
                    _logger.Error($"[OrderId:{orderId}] cannot be rerouted. It is no longer found in the cache.");
                    continue;
                }
            }

            if (!ordersToRoute.Any())
            {
                _logger.Warn($"No orders in cache that can be routed.");
                return ordersToRoute;
            }
       
            _orderPrepUtility.SetTrader(ordersToRoute, entryUser);
            foreach (IOrder order in ordersToRoute)
            {
                _logger.Info($"[OrderId:{order.ClientOrderId}] Set trader to {order.Trader} from routing user {entryUser}");
            }

            ordersToRoute.Sort();
            var groupedOrders = ordersToRoute.GroupBy(order => GetOrAssignProcessor(order.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());
            try
            {
                //TODO: Parallel aggregation
                ConcurrentQueue<Task<IList<IOrder>>> routedOrdersTasks = new ConcurrentQueue<Task<IList<IOrder>>>();
                Parallel.ForEach(groupedOrders, processorGroup =>
                {
                    Task<IList<IOrder>> routeTask = processorGroup.Key.RouteOrdersAsync(processorGroup.Value);
                    routedOrdersTasks.Enqueue(routeTask);
                });
               
                List<IOrder> routedOrders = new List<IOrder>();
                foreach (Task<IList<IOrder>> routeTask in routedOrdersTasks)
                {
                    routedOrders.AddRange(routeTask.Result);
                }
                return routedOrders;
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    string msg = $"Exception while routing orders {String.Join(",", orderIds)}.";
                    _logger.Error(msg, aex.Flatten());
                    return false;
                });
            }
            return new List<IOrder>();
        }

        public IList<IOrder> ProcessDeleteOrders(IList<string> orderIds)
        {
            var cancelled = ProcessCancelOrders(orderIds).Where(o => o.OrderStatus == BamOrderStatus.Cancelled).ToList();
            cancelled.ForEach(o => o.OrderStatus = BamOrderStatus.Deleted);
            var groupedOrders = cancelled.GroupBy(order => GetOrAssignProcessor(order.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());
            Parallel.ForEach(groupedOrders, processorGroup =>
            {
                processorGroup.Key.ProcessOrderUpdate(processorGroup.Value);
            });
            return cancelled;
        }

        public IList<IOrder> ProcessCancelOrders(IList<string> orderIds)
        {
            _logger.Info($"Cancelling {orderIds.Count} orders.");
            IList<IOrder> ordersToCancel = new List<IOrder>();
            foreach (string orderId in orderIds)
            {
                IOrder ordertoCancel = _orderRepository.Get(orderId);
                if (ordertoCancel != null)
                {
                    _logger.Info($"[OrderId:{ordertoCancel.ClientOrderId}] will be cancelled...");
                    ordersToCancel.Add(ordertoCancel);
                }
            }

            if (!ordersToCancel.Any())
            {
                _logger.Warn($"No orders in cache that can be cancelled.");
                return ordersToCancel;
            }
            var groupedOrders = ordersToCancel.GroupBy(order => GetOrAssignProcessor(order.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());
            try
            {
                //TODO: Parallel aggregation
                ConcurrentQueue<Task<IList<IOrder>>> cancelledOrdersTasks = new ConcurrentQueue<Task<IList<IOrder>>>();
                Parallel.ForEach(groupedOrders, processorGroup =>
                {
                    Task<IList<IOrder>> cancelTask = processorGroup.Key.CancelOrderAsync(processorGroup.Value);
                    cancelledOrdersTasks.Enqueue(cancelTask);
                });

                _emsRouter.CancelOrders(orderIds);
                List<IOrder> cancelledOrders = new List<IOrder>();
                foreach (Task<IList<IOrder>> cancelTask in cancelledOrdersTasks)
                {
                    cancelledOrders.AddRange(cancelTask.Result);
                }
                return cancelledOrders;
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    string msg = $"Exception while cancelling orders {String.Join(",", orderIds)}.";
                    _logger.Error(msg, aex.Flatten());
                    return false;
                });
            }

            return new List<IOrder>();
        }

        private void SubmitOrders(List<IOrder> ordersToSubmit, string batchId)
        {
            string msg = $"[BatchId:{batchId}] submitting {ordersToSubmit.Count} orders to {_settings.EmsName}...";
            _logger.Info(msg);

            var groupedOrders = ordersToSubmit.GroupBy(order => GetOrAssignProcessor(order.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());

            Parallel.ForEach(groupedOrders, processorGroup =>
            {
                processorGroup.Key.RouteOrders(processorGroup.Value, batchId);
            });
        }
        
        public DateTime RollSod(DateTime? dateTimeToRollTo)
        {
            string msg = "OG Roll Started";
            _logger.Info(msg);
            var logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, null, BamSystem.OMS_GATEWAY);
            _eventLogger.SendPendingEvent(logEvent);


            #region Publish to Listeners
            _rollClients?.ForEach(fc => fc.PublishOrders(_orderRepository.Get(_settings.SODDateTime.ToUniversalTime()).Cast<IOrder>().ToList()));

            _rollClients?.ForEach(fc => fc.PublishTrades(_tradeRepository.Get(_settings.SODDateTime.ToUniversalTime()).Cast<IBlockTrade>().ToList()));
            var eodPositions = _positionTracker.GetCurrentPositions().ToList();

            var now = DateTime.Now;
            var sodDate = GetSodDateTime(dateTimeToRollTo);
            var nextBusinessDay = now.TimeOfDay.CompareTo(sodDate.TimeOfDay) >= 0 ? now.Date.AddDays(1) : now.Date;
            _rollClients?.ForEach(fc => fc.PublishPositions(eodPositions, nextBusinessDay));
            #endregion Publish to Listeners      

            int flushedItems = Flush();
            SetSodDateTime(dateTimeToRollTo);

            _logger.Info($"{flushedItems} items flushed from cache.  New SOD DateTime {_settings.SODDateTime:MM/dd/yy H:mm:ss zzz}");

            if (_settings.SeedSodPositionsFromEms)
            {
                #region Reinitialize Position Trackers

                IList<IPosition> positions = GetPositionsFromEms(); //This shd give SOD positions after roll accordning to Rohit Pandey
                SodPositionEditSodPositionLoad(positions.Cast<Position>().ToList());

                #endregion Reinitialize Position Trackers
            }

            try
            {
                _logger.Info("Deleting contingency position records.");
                _contingencyDbRepository.Clear(_settings.SODDateTime.ToUniversalTime());
            }
            catch (Exception ex)
            {
                _logger.Error("Error deleting contingency records.", ex);
            }

            msg = "OG Roll Completed";
            _logger.Info(msg);
            logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, _settings.SODDateTime.ToShortDateString(), BamSystem.OMS_GATEWAY);
            _eventLogger.SendSuccessEvent(logEvent);
            Utility.RaiseEvent(_settings.SODDateTime, SODRolled);
            return _settings.SODDateTime;
        }

        public void RequestLocates(IList<string> orderIds)
        {
            foreach (var orderId in orderIds)
            {
                var order = _orderRepository.Get(orderId);
                if (order == null) continue;

                var processor = GetOrAssignProcessor(order.Security.BamSymbol);
                processor.RequestLocate(order);
            }
        }

        public IList<Position> ReplacePositions(IList<Position> positions)
        {
            List<Position> updatedPositions = new List<Position>();
            try
            {
                //TODO: Parallel aggregaation
                ConcurrentQueue<Task<IList<Position>>> updateTasks = new ConcurrentQueue<Task<IList<Position>>>();
                var groupedPositions = positions.GroupBy(pos => GetOrAssignProcessor(pos.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());

                Parallel.ForEach(groupedPositions, processorGroup =>
                {
                    Task<IList<Position>> updateTask = processorGroup.Key.UpdatePositionsAsync(processorGroup.Value);
                    updateTasks.Enqueue(updateTask);
                });

                foreach (Task<IList<Position>> updateTask in updateTasks)
                {
                    updatedPositions.AddRange(updateTask.Result);
                }
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error($"Error updating positions.", ex);
                    return false;
                });
            }
            return updatedPositions;
        }

        public void RunContingency()
        {
            DateTime cutOffTime = _settings.SODDateTime.ToUniversalTime();

            try
            {
                _logger.InfoFormat("Saving contingency positions since {0}.", cutOffTime.ToString("o"));
                List<Position> all = _positionTracker.GetCurrentPositions().ToList().ConvertAll(pos => (Position)pos);
                var invalid = all.Where(p => p?.Portfolio == null).ToList();
                var positions = all.Where(p => p?.Portfolio != null).ToList();

                foreach (var p in invalid)
                {
                    _logger.FatalFormat($"Detected invalid position {p}");
                }

                _contingencyDbRepository.Save(positions);
                _logger.InfoFormat("Saved {0} contingency positions since {1}.", positions.Count,
                    cutOffTime.ToString("o"));

                PublishOrders(false, FlowClientScope.Contingency);
                PublishTrades(false, FlowClientScope.Contingency);
            }
            catch (Exception ex)
            {
                _logger.Error("Error publishing cache.", ex);
            }
        }

        public void PublishOrders(bool eod, FlowClientScope scope)
        {
            DateTime cutOffTime = _settings.SODDateTime.ToUniversalTime();

            try
            {
                var clients = _flowClients;
                if (eod)
                {
                    clients = _rollClients.Cast<IFlowClient>().ToArray();
                }

                var orders = _orderRepository.Get(cutOffTime).Cast<IOrder>().ToList();
                clients.OfScope(scope).ForEach(fc => fc.PublishOrders(orders));
            }
            catch (Exception ex)
            {
                _logger.Error("Error publishing cache.", ex);
            }
        }

        public void PublishTrades(bool eod, FlowClientScope scope)
        {
            DateTime cutOffTime = _settings.SODDateTime.ToUniversalTime();

            try
            {
                var clients = _flowClients;
                if (eod)
                {
                    clients = _rollClients.Cast<IFlowClient>().ToArray();
                }

                var trades = _tradeRepository.Get(cutOffTime).Cast<IBlockTrade>().ToList();
                clients.OfScope(scope).ForEach(fc => fc.PublishTrades(trades));

                if (!eod)
                {
                    var finalized = trades.Where(t => t.isFinalized).ToList();
                    if (finalized.Any())
                    {
                        _rollClients.OfScope(scope).ForEach(rc => rc.PublishTrades(finalized));
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Error publishing cache.", ex);
            }
        }

        private Task<IOrder>[] SaveState(List<IOrder> orders, string batchId)
        {
            _logger.Info($"[BatchId:{batchId}] Saving state for orders in batch.");
            List<IOrder> ordersToPublish = orders.ConvertAll(order => (IOrder)order.Clone());

            Task<IOrder>[] saveTasks =
                ordersToPublish.ConvertAll(order => (IOrder)order.Clone()).AsParallel().Select(async order => await GetOrAssignProcessor(order.Security.Key).SaveOrderAsync(order, batchId))
                    .ToArray();
            _logger.Info($"[BatchId:{batchId}] Completed submitting saving state for orders in batch.");
            return saveTasks;
        }

        private IList<IOrder> MarkAndTrack(IList<IOrder> orders, string batchId = null)
        {
            string msg = $"[BatchId:{batchId}] begin marking and position tracking...";
            _logger.Info(msg);

            var groupedOrders = orders.GroupBy(order => GetOrAssignProcessor(order.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());

            List<IOrder> markedOrders = new List<IOrder>();
            try
            {
                //TODO: Parallel aggregaation
                ConcurrentQueue<Task<IList<IOrder>>> markingTasks = new ConcurrentQueue<Task<IList<IOrder>>>();

                Parallel.ForEach(groupedOrders, processorGroup =>
                {
                    Task<IList<IOrder>> markingTask = processorGroup.Key.MarkOrderAsync(processorGroup.Value, batchId);
                    markingTasks.Enqueue(markingTask);
                });

                foreach (Task<IList<IOrder>> markingTask in markingTasks)
                {
                    markedOrders.AddRange(markingTask.Result);
                }

                msg = $"[BatchId:{batchId}] marking and position tracking complete.";
                _logger.Info(msg);
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    msg = $"[BatchId:{batchId}] exception while marking and position tracking.";
                    _logger.Error(msg, aex.Flatten());
                    var logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, batchId, BamSystem.OMS_GATEWAY);
                    _eventLogger.SendFailedEvent(logEvent);
                    return false;
                });
            }
            return markedOrders;
        }

        //TODO: Move this to the striped processor if shortlocate service supports concurrent requests from multiple threads.
        private List<IOrder> LocateShorts(List<IOrder> markedOrders, string batchId = null)
        {
            string msg = $"[BatchId:{batchId}] begin short locate...";
            _logger.Info(msg);
            try
            {
                //make a sync call to get shorts
                var shortOrders = markedOrders.Where(o => o.Side == SideType.SellShort);
                shortOrders.ForEach(o => o.RoutedSize = 0);

                msg = $"[BatchId:{ batchId}] requesting locate for {shortOrders.Count()} short orders.";
                _logger.Info(msg);

                var fullyLocatedShortOrders = LocateShortForOrdersWrap(shortOrders);

                //set the routed size for all these trades
                foreach (var orderToSubmit in fullyLocatedShortOrders.Where(r => r.LocateStatus == LocateStatus.Approved))
                {
                    orderToSubmit.RoutedSize = orderToSubmit.Size;
                    orderToSubmit.OrderStatus = BamOrderStatus.PendingSend;
                }

                shortOrders.Where(so => so.LocateStatus != LocateStatus.Approved)
                    .ForEach(o => { o.OrderStatus = BamOrderStatus.PendingLocate; });


               msg = $"[BatchId:{batchId}] completed short locate. {fullyLocatedShortOrders.Where(r => r.LocateStatus == LocateStatus.Approved).Count()} got full locates";
                _logger.Info(msg);
                return markedOrders;
            }
            catch (Exception ex)
            {
                msg = $"[BatchId:{batchId}] exception while getting locates.";
                _logger.Error(msg, ex);
                var logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, batchId, BamSystem.OMS_GATEWAY);
                _eventLogger.SendFailedEvent(logEvent);
                throw;
            }
        }

        //TODO: Move this to Short locate proxy/facade
        private IEnumerable<IOrder> LocateShortForOrdersWrap(IEnumerable<IOrder> shortOrders)
        {
            //request short locate, completely filled orders will go downstream
            var shortLocateRequests = shortOrders.Select(s => new LocateRequest(s, s.Custodian));

            if (!shortLocateRequests.Any()) return new List<IOrder>(); //return an empty list

            var locateResponses = _locateService.RequestForInventory(shortLocateRequests);
            return locateResponses;
        }

        private void LogAndRevert(IList<IOrder> markedOrders, string batchId)
        {
            string msg;
            DataFlowEvent logEvent;
            var failedOrders =
                markedOrders.Where(
                    o =>
                        o.OrderStatus == BamOrderStatus.Error || o.OrderStatus == BamOrderStatus.Marked || o.OrderStatus == BamOrderStatus.PendingSend)
                    .ToList();
            msg = $"[BatchId:{batchId}] {failedOrders.Count} orders failed submitting to {_settings.EmsName}.";
            _logger.Info(msg);
            logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY,
                DateTime.Now, msg,
                null, batchId, BamSystem.OMS_GATEWAY);
            _eventLogger.SendFailedEvent(logEvent);
            RevertMarkedOrders(markedOrders, batchId);
        }

        private void RevertMarkedOrders(IList<IOrder> markedOrders, string batchId)
        {
            string msg = $"[BatchId:{batchId}] reverting marking for {markedOrders.Count} orders...";
            _logger.Info(msg);
            try
            {
                var revertTasks =
                    markedOrders.Select(
                        async order =>
                            await GetOrAssignProcessor(order.Security.Key).RevertOrderAsync(order, batchId))
                        .ToList();
                Task.WaitAll(revertTasks?.ToArray());
                msg = $"[BatchId:{batchId}] completed reverting marking for {markedOrders.Count} orders.";
                _logger.Info(msg);
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    msg = $"[BatchId:{batchId}] exception while reverting marking.";
                    _logger.Error(msg, aex.Flatten());
                    var logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, batchId, BamSystem.OMS_GATEWAY);
                    _eventLogger.SendFailedEvent(logEvent);
                    return true; // mark as handled
                });
            }
        }

        private IStripedProcessor GetOrAssignProcessor(string symbol)
        {
            IStripedProcessor stripedProcessor = null;
            _stripedProcessorLockSlim.EnterUpgradeableReadLock();
            try
            {
                if (!_stripedProcessors.TryGetValue(symbol, out stripedProcessor))
                {
                    try
                    {
                        _stripedProcessorLockSlim.EnterWriteLock();
                        if (!_stripedProcessors.TryGetValue(symbol, out stripedProcessor))
                        {
                            if (_stripedProcessors.Count >= _settings.MaxStripedProcessors)
                            {
                                stripedProcessor =
                                    _stripedProcessors.Values.Aggregate(
                                        (holder, x) => (x.TotalOrdersProcessed < holder.TotalOrdersProcessed ? x : holder));
                            }
                            else
                            {
                                stripedProcessor = CreateStripedProcessor(symbol);
                            }

                            stripedProcessor.AddSubscribedSymbol(symbol);
                            _stripedProcessors.Add(symbol, stripedProcessor);
                        }
                    }
                    finally
                    {
                        _stripedProcessorLockSlim.ExitWriteLock();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Error assigning striped processor for {symbol}.", ex);
                throw;
            }
            finally
            {
                _stripedProcessorLockSlim.ExitUpgradeableReadLock();
            }

            return stripedProcessor;

        }

        private IStripedProcessor CreateStripedProcessor(string symbol)
        {
            _logger.Info($"Creating and assigning processor for symbol {symbol}.");
            var orderRepository = Container.Instance.Resolve<IOrderRepository>();
            var tradeRepository = Container.Instance.Resolve<ITradeRepository>();
            var orderMarker = Container.Instance.Resolve<IOrderMarker>();
            var emsRouter = Container.Instance.Resolve<IEmsRouter>();
            var locateService = Container.Instance.Resolve<ILocateService>();
            var orderUtil = Container.Instance.Resolve<IOrderPrepUtility>();
            var secMaster = Container.Instance.Resolve<ISecurityMasterService>();
            var accountMaster = Container.Instance.Resolve<IAccountService>();

            var stripedProcessor = new StripedProcessor(emsRouter, locateService, _positionTracker,
                orderMarker, orderRepository, tradeRepository, _logger, _positionRepository, _settings, 
                orderUtil, secMaster, accountMaster);

            stripedProcessor.OrderStatusChanged += StripedProcessorOrderStatusChanged;
            stripedProcessor.OrdersStatusChanged += StripedProcessorOrdersStatusChanged;
            stripedProcessor.TradeStatusChanged += StripedProcessorTradeStatusChanged;
            stripedProcessor.TradesStatusChanged += StripedProcessorTradesStatusChanged;

            _logger.Info($"Completed creating and assigning processor for symbol {symbol}.");

            return stripedProcessor;
        }

        private DateTime GetSodDateTime(DateTime? dateTimeToRollTo)
        {
            if (!dateTimeToRollTo.HasValue)
            {
                dateTimeToRollTo = _dateProvider.SetSodTime();
                _logger.Info($"Rolldate set to {dateTimeToRollTo:MM/dd/yy H:mm:ss zzz}");
            }
            else
            {
                dateTimeToRollTo = _dateProvider.SetSodTime(null, dateTimeToRollTo.Value);
            }

            return dateTimeToRollTo.Value.ToLocalTime();
        }

        private void SetSodDateTime(DateTime? dateTimeToRollTo)
        {
            _settings.SODDateTime = GetSodDateTime(dateTimeToRollTo);
            _logger.Info($"Sod Date time is set to {_settings.SODDateTime:MM/dd/yy H:mm:ss zzz}.");
        }

        private void SodPositionUpdate(IList<Position> sodPositions, Func<IStripedProcessor, IList<Position>, Task<IList<Position>>> func)
        {
            try
            {
                //TODO: Parallel aggregation
                ConcurrentQueue<Task<IList<Position>>> sodUpdateTasks = new ConcurrentQueue<Task<IList<Position>>>();
                var groupedPositions = sodPositions.GroupBy(pos => GetOrAssignProcessor(pos.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());

                Parallel.ForEach(groupedPositions, processorGroup =>
                {
                    Task<IList<Position>> sodUpdateTask = func(processorGroup.Key, processorGroup.Value);
                    sodUpdateTasks.Enqueue(sodUpdateTask);
                });

                Task.WaitAll(sodUpdateTasks.ToArray());
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    string msg = $"[Exception while loading SOD Positions.";
                    _logger.Error(msg, aex.Flatten());
                    var logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, JsonConvert.SerializeObject(sodPositions), BamSystem.OMS_GATEWAY);
                    _eventLogger.SendFailedEvent(logEvent);
                    return false;
                });
            }
        }

        private List<IPosition> GetPositionsFromEms()
        {
            _logger.Info("Loading positions from EMS.");
            IList<IPosition> sodPositions = _emsRouter.GetSodPositions();
            if (sodPositions == null || !sodPositions.Any())
            {
                _logger.Warn("No SOD positions from EMS.");
            }

            sodPositions = sodPositions.GroupBy(position =>
                new
                {
                    position.Portfolio,
                    position.Security,
                    position.CustodianName,
                    position.FundCode
                })
                .Select(
                    g => (IPosition)
                        new Position
                        {
                            Portfolio = g.Key.Portfolio,
                            Security = g.Key.Security,
                            CustodianName = g.Key.CustodianName,
                            FundCode = g.Key.FundCode,
                            TheoreticalQuantity = g.Sum(pos => pos.TheoreticalQuantity),
                            ActualQuantity = g.Sum(pos => pos.ActualQuantity),
                            ShortMarkingQuantity = g.Sum(pos => pos.ShortMarkingQuantity),
                            LongMarkingQuantity = g.Sum(pos => pos.LongMarkingQuantity),
                            Stream = g.Key.Portfolio.OmsStream,
                            EntryDate = g.Min(p => p.EntryDate),
                            CreatedOn = g.Min(p => p.EntryDate)
                        }).ToList();
            return sodPositions.ToList();
        }

        private void HandleError(List<IOrder> orders, string batchId, List<IOrder> markedOrders, string errorMessage)
        {
            LogAndRevert(markedOrders, batchId);

            foreach (var o in orders)
            {
                o.OrderStatus = BamOrderStatus.Error;
                o.StatusMessages.Add($"{DateTime.UtcNow:yyyyMMddHHmmss}:{errorMessage}.");
            }

            foreach (var o in markedOrders)
            {
                o.OrderStatus = BamOrderStatus.Error;
                o.StatusMessages.Add($"{DateTime.UtcNow:yyyyMMddHHmmss}:{errorMessage}.");
            }

            var saveTasks = SaveState(orders, batchId);
            saveTasks = saveTasks.Concat(SaveState(markedOrders, batchId)).ToArray();

            Task.WaitAll(saveTasks);
        }

        #region Event Handlers
        private void SodPositionEditSodPositionLoad(IList<Position> sodPositions)
        {
            if (!sodPositions.Any()) return;
           
            SodPositionUpdate(sodPositions,
                (stripedProcessor, positions) => stripedProcessor.LoadSODPositionsAsync(positions));
        }

        private void SodPositionEditSodPositionUpdated(IList<Position> sodPositions)
        {
            SodPositionUpdate(sodPositions,
                (stripedProcessor, positions) => stripedProcessor.UpdateSODPositionsAsync(positions));
        }

        public void StripedProcessorTradesStatusChanged(IList<IBlockTrade> trades)
        {
            Utility.RaiseEvent(trades, TradesStateChanged);
            Task.Run(() =>
            {
                _flowClients?.ForEach(fc => fc.PublishTrades(trades));
                var finalized = trades.Where(t => t.isFinalized).ToList();
                if (finalized.Any())
                {
                    _rollClients?.ForEach(rc => rc.PublishTrades(finalized));
                }
            });
        }

        private void StripedProcessorTradeStatusChanged(IBlockTrade trade)
        {
            StripedProcessorTradesStatusChanged(new List<IBlockTrade>() { trade });
        }

        public void StripedProcessorOrdersStatusChanged(IList<IOrder> orders)
        {
            Utility.RaiseEvent(orders, OrdersStateChanged);
            Task.Run(() => _flowClients?.ForEach(fc => fc.PublishOrders(orders)));
        }

        private void StripedProcessorOrderStatusChanged(IOrder order)
        {
            StripedProcessorOrdersStatusChanged(new List<IOrder>() { order });
        }

        private void EmsRouterRollCompleted(string data)
        {
            _logger.InfoFormat($"{_settings.EmsName} Roll completed. {data}");
            var logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, $"{_settings.EmsName} Roll Completed", null, data, BamSystem.OMS_GATEWAY);
            _eventLogger.SendSuccessEvent(logEvent);
            Task.Run(() => this.RollSod(null));
        }

        private void EmsRouterRollStarted(string data)
        {
            _logger.InfoFormat($"{_settings.EmsName} Roll started. {data}");
            var logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, $"{_settings.EmsName} Roll Started", null, data, BamSystem.OMS_GATEWAY);
            _eventLogger.SendPendingEvent(logEvent);
        }

        private void EmsRouterTradeUpdated(IEnumerable<IBlockTrade> trades)
        {
            if (trades == null || !trades.Any()) return;

            var delay = DateTime.UtcNow - trades.Min(t => t.TradeTimeStamp);
            if (delay.TotalMilliseconds > 50)
            {
                _logger.Warn($"Took {delay.TotalMilliseconds}ms to trigger trade updated event on EMS router.");
            }

            foreach (IBlockTrade trade in trades)
            {
                try
                {
                    IOrder updatedOrder = _orderRepository.Get(trade.ClientOrderId);
                    if (updatedOrder != null)
                    {
                        if (updatedOrder?.Security == null) continue;
                        trade.Security = updatedOrder.Security;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Error finding security for trade {trade}.", ex);
                }
            }

            var groupedTrades = trades.Where(r=>!string.IsNullOrWhiteSpace(r.Security?.BamSymbol)).GroupBy(trade => GetOrAssignProcessor(trade.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());

            try
            {
                Parallel.ForEach(groupedTrades, processorGroup =>
                {
                    processorGroup.Key.ProcessTradeUpdate(processorGroup.Value);
                });
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error($"Error while processing trade updates. {trades}.");
                    return false;
                });
            }
        }

        private void EmsRouterOrderStatusChanged(IEnumerable<IOrder> orders)
        {
            if (orders == null || !orders.Any()) return;

            var delay = DateTime.UtcNow - orders.Min(t => t.OrderTimeStamp);
            if (delay.TotalMilliseconds > 50)
            {
                _logger.Warn($"Took {delay.TotalMilliseconds}ms to trigger order status changed event on EMS router.");
            }

            foreach (IOrder order in orders)
            {
                try
                {
                    IOrder updatedOrder = _orderRepository.Get(order.ClientOrderId);
                    if (updatedOrder == null)
                    {
                        _logger.Info($"From {_settings.EmsName}-> [OrderId{order.ClientOrderId};{order.Security?.BamSymbol};{order.ExternalId}] Order not in cache.");
                        //make sure there is a processor assigned
                    }
                    else
                    {
                        // set invariant properties from original order
                        order.Security = updatedOrder.Security;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Error finding security for order {order}.", ex);
                }
            }

            try
            {
                var toBeProcessedOrders = orders.Where(o => !string.IsNullOrEmpty(o.Security?.BamSymbol));
                var groupedOrders = toBeProcessedOrders.GroupBy(order => GetOrAssignProcessor(order.Security.BamSymbol)).ToDictionary(g => g.Key, g => g.ToList());

                var missedOrderIds = orders.Where(o => string.IsNullOrEmpty(o.Security?.BamSymbol)).Select(r=>r.ClientOrderId);

                if (missedOrderIds.Any())
                {
                    _logger.Info($"Orders with no security, unable to find corresponding stripe; {JsonConvert.SerializeObject(missedOrderIds)}");
                }
                    
                Parallel.ForEach(groupedOrders, processorGroup =>
                {
                    processorGroup.Key.ProcessOrderUpdate(processorGroup.Value);
                });
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error($"Error while processing order updates. {orders}.");
                    return false;
                });
            }
        }

        #endregion Event Handlers

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _emsRouter.Disconnect();
                    _emsRouter.OrderStatusChanged -= EmsRouterOrderStatusChanged;
                    _emsRouter.TradeUpdated -= EmsRouterTradeUpdated;
                    _stripedProcessorLockSlim.EnterWriteLock();
                    try
                    {
                        _stripedProcessors.Values.ForEach(sp =>
                        {
                            sp.OrderStatusChanged -= StripedProcessorOrderStatusChanged;
                            sp.OrdersStatusChanged -= StripedProcessorOrdersStatusChanged;
                            sp.TradeStatusChanged -= StripedProcessorTradeStatusChanged;
                            sp.TradesStatusChanged -= StripedProcessorTradesStatusChanged;
                        });
                    }
                    finally
                    {
                        _stripedProcessorLockSlim.ExitWriteLock();
                    }
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~flowManager() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion

    }
}
