﻿ 

namespace Bam.Oms.Data.Enumerators
{
    public enum AssetType
    {
        [Enum(StringValue = "NOT SPECIFIED")]
        NotSpecified,
        [Enum(StringValue = "Spread")]
        Spread,
        [Enum(StringValue = "Other")]
        Other,
        [Enum(StringValue = "Option")]
        Option,
        [Enum(StringValue = "Equity")]
        Equity,
        [Enum(StringValue = "Fixed Income")]
        FixedIncome,
        [Enum(StringValue = "Swap")]
        Swap,
        [Enum(StringValue = "Cash")]
        Cash,
        [Enum(StringValue = "Forward")]
        Forward,
        [Enum(StringValue = "Rates and Indexes")]
        RatesAndIndexes,
        [Enum(StringValue = "Swap Leg")]
        SwapLeg,
        [Enum(StringValue = "Future")]
        Future,
        [Enum(StringValue = "FX")]
        Fx
    }
}
