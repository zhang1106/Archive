﻿using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public struct AllocationInfo
    {
        public bool IsLive;
        public bool IsDead;
        public Side Side;
        public long TotalQuantity;
        public long FillQuantity;
        public int FundId;
    }
}