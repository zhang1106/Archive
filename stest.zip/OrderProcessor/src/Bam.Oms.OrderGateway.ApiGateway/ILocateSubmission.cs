﻿namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface ILocateSubmission
    {
        void AcquireLocate(long[] orderIds, string user);
    }
}