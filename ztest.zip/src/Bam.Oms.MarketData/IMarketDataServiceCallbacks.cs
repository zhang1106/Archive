﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.MarketData
{
    public interface IMarketDataServiceCallbacks
    {
        void ProcessRequestReject(IRequestReject reject);
        void ProcessData(List<QuoteData> data);

        void ProcessData(QuoteData data);

        void HandleEvent(IAvailabilityEvent evt);
    }
}
