﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Data.Configuration
{
    public interface ISettings
    {
        void Initialize();

        string BaseUrl { get; set; }
        string BasePort { get; set; }

        DateTime SODDateTime { get; set; }

        DateTime DefaultSODDateTime { get; set; }
        string OrderGatewayConnectionString { get; set; }
        string ContingencyConnectionString { get; set; }
        string BamCoreLiteConnectionString { get; set; }
        int ContingencyTimerInterval { get; set; }
        int MaxResubscribeAttempt { get; set; }        
        int MaxStripedProcessors { get; set; }
        int EmsResubscribeWaitInterval { get; set; }

        string MqConnectionString { get; set; }
        string MqAmConnectionString { get; set; }
        string MqEODTradeTopic { get; set; }

        string MqEODOrderTopic { get; set; }

        string MqEODPositionTopic { get; set; }

        string MqTradeTopic { get; set; }

        string MqOrderTopic { get; set; }

        string MqPositionTopic { get; set; }

        string MqAccountTopic { get; set; }

        string MqMarketDataTopic { get; set; }

        string MqMarketDataSubscribeQueue { get; set; }

        string MqEzeOrderTopic { get; set; }

        

        IDictionary<string, string> ManagerCodeMap { get; }

        IDictionary<string, string> PortfolioToComplianceGroup { get; }

        IDictionary<string, string> PortfolioToAggUnit { get; }

        string FlexHost { get; set; }
        string FlexPort { get; set; }

        int ConnectionRetryInterval { get; set; }

        int EMSPingInterval { get; set; }

        string PermissionedApplications { get; set; }


        EmsSystem EmsName { get; }

        string EzeUserName { get;  }

        string EzePassword { get;  }

        string EnablePermission { get; }

        string CoverageServiceHost { get; }

        string CoverageServicePort { get; }

        string EzeApiUrl { get; }
        string PublishEzeToMq { get; }

        bool IsFullRefreshRequired { get; }
        int FullRefreshBatchSize { get; }
        int FullRefreshTimeInSeconds { get; }
        int PublishTimeInSeconds { get;}
        int PublishBatchSize { get; }
        IList<SecurityType> SupportedSecurityTypes { get; } 

        IList<string> AnonymousUrls { get; }

        string OrderFileLocation { get; }

        bool SeedSodPositionsFromEms { get; }

        bool IsSecurityTypeSupported(SecurityType type);

        bool PublishOrdersToMq { get; }

        bool PublishPositionsToMq { get; }
        int EzeSubmissionRetryCount { get; }

        IDictionary<string, string> LocateBrokerMpidOverrides { get; }
    }
}
