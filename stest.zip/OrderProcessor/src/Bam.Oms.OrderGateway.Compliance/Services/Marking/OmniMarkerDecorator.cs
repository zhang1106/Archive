﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;

namespace Bam.Oms.OrderGateway.Compliance.Services.Marking
{
    public class OmniMarkerDecorator : IOrderMarker
    {
        private readonly List<Mark> _originalOrderMark = new List<Mark>(1);
        private readonly IOrderMarker _actualOrderMarker;

        public ISet<string> SupportedSecurityTypes => _actualOrderMarker.SupportedSecurityTypes;

        public OmniMarkerDecorator(IOrderMarker actualOrderMarker)
        {
            _actualOrderMarker = actualOrderMarker;
        }

        public IDisposable Scoped()
        {
            return _actualOrderMarker.Scoped();
        }
        
        public List<Mark> MarkOrder(MarkingEntity entity, PositionSet set)
        {
            if (!entity.IsOmni)
            {
                return _actualOrderMarker.MarkOrder(entity, set);
            }

            _originalOrderMark.Clear();
            _originalOrderMark.Add(new Mark
            {
                Quantity = entity.Size,
                Side = entity.Side
            });

            return _originalOrderMark;
        }
    }
}