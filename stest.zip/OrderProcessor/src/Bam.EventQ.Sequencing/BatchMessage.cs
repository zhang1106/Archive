﻿using System.Collections.Generic;

namespace Bam.EventQ.Sequencing
{
    public class BatchMessage<TItem> : Message, IBatchMessage<TItem>
    {
        public List<TItem> Items { get; } = new List<TItem>();
    }
}
