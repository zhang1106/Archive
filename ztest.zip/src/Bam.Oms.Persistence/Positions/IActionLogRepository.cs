﻿using Bam.Oms.Data.Positions;

namespace Bam.Oms.Persistence.Positions
{
    public interface IActionLogRepository : IDBRepository<SodActionLog>
    {
    }
}