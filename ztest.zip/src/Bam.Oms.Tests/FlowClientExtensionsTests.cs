﻿using Bam.Oms.EndPoints;
using FluentAssertions;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    public class FlowClientExtensionsTests
    {
        [TestCase(FlowClientScope.Contingency, FlowClientScope.Contingency, true)]
        [TestCase(FlowClientScope.Ems, FlowClientScope.Contingency, false)]
        [TestCase(FlowClientScope.Ems, FlowClientScope.Ems, true)]
        [TestCase(FlowClientScope.Contingency, FlowClientScope.Ems, false)]
        [TestCase(FlowClientScope.Both, FlowClientScope.Ems, true)]
        [TestCase(FlowClientScope.Both, FlowClientScope.Contingency, true)]
        [TestCase(FlowClientScope.Ems, FlowClientScope.Both, true)]
        [TestCase(FlowClientScope.Contingency, FlowClientScope.Both, true)]
        public void VerifySelection(FlowClientScope clientScope, FlowClientScope requestedScope, bool match)
        {
            var fc = new Mock<IFlowClient>();
            fc.Setup(m => m.Scope).Returns(clientScope);

            var list = new[] { fc.Object };
            var actual = list.OfScope(requestedScope);

            if (match)
            {
                actual.Should().NotBeEmpty();
            }
            else
            {
                actual.Should().BeEmpty();
            }
        }
    }
}
