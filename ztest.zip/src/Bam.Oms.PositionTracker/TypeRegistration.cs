﻿using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.SodPosition.Svc;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.PositionTracker
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            var eventLogger = LoggingAgentFactory.Instance.GetLoggingAgent(BamSystem.POSITION_TRACKER);
            container.RegisterInstance(eventLogger);

            container.RegisterType<IStartOfDayPositionCalculator, StartOfDayPositionCalculator>(RegistrationType.Singleton);
            container.RegisterType<IPositionEffectCalculator, PositionEffectCalculator>(RegistrationType.Singleton);
            container.RegisterType<IPositionTracker, PositionTracker>(RegistrationType.Singleton);

//#if _BAM_WITH_LOGGING_INTERCEPTOR
//            container.RegisterTypeWithLoggingInterfaceInterceptor<IPositionTracker, PositionTracker>(RegistrationType.Singleton, "", new InjectionMethod("StartContingencyTask"));
//#else
//            container.RegisterType<IPositionTracker, PositionTracker>(RegistrationType.Singleton, "", new InjectionMethod("Initialize"), new InjectionMethod("StartContingencyTask"));
//#endif
        }
    }
}