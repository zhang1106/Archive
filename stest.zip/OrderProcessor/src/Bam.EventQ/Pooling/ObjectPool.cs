﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;

namespace Bam.EventQ.Pooling
{
    public class ObjectPool : IObjectPool
    {
        private const int BatchSize = 1024;
        private readonly CasLock _releaseLock = new CasLock();

        private readonly Dictionary<Type, Action<object>> _releaseInvoker = 
            new Dictionary<Type, Action<object>>();

        public T Get<T>()
        {
            while (true)
            {
                var instance = Pool<T>.Get();
                if (!ReferenceEquals(instance, default(T)))
                    return instance;

                if (Pool<T>.TrySwap())
                    continue;

                Pool<T>.CreateInventory();
            }
        }

        public void Release(object instance)
        {
            if (ReferenceEquals(instance, null))
                return;

            Action<object> invoker;
            using (_releaseLock.Acquire())
            {
                if (!_releaseInvoker.TryGetValue(instance.GetType(), out invoker))
                {
                    var mi = GetType().GetMethod(nameof(ReleaseInstance))
                        .MakeGenericMethod(instance.GetType());

                    var param = Expression.Parameter(typeof(object));
                    var castParam = Expression.Convert(param, instance.GetType());
                    var thisConst = Expression.Constant(this);
                    var invoke = Expression.Call(thisConst, mi, castParam);
                    var lambda = Expression.Lambda<Action<object>>(invoke, param);
                    invoker = _releaseInvoker[instance.GetType()] = lambda.Compile();
                }
            }

            invoker(instance);
        }

        public void ReleaseInstance<T>(T instance)
        {
            if (ReferenceEquals(instance, null))
                return;

            Pool<T>.Release(this, instance);
        }

        internal void ReleaseList(IEnumerable items)
        {
            if (items != null)
            {
                foreach (var item in items)
                {
                    Release(item);
                }
            }
        }

        private static class Pool<T>
        {
            // ReSharper disable StaticMemberInGenericType
            private static readonly CasLock GetLock = new CasLock();
            private static readonly CasLock ReleaseLock = new CasLock();

            private static readonly Func<T> Factory;
            private static readonly Action<ObjectPool, T> RecursiveRelease;

            private static List<T> _inventory = new List<T>(BatchSize * 4);
            private static List<T> _released = new List<T>(BatchSize * 4);
            // ReSharper restore StaticMemberInGenericType

            static Pool()
            {
                Factory = Expression.Lambda<Func<T>>(Expression.New(typeof(T))).Compile();
                RecursiveRelease = BuildReleaseHandler();
            }

            public static T Get()
            {
                using (GetLock.Acquire())
                {
                    var list = _inventory;
                    if (list.Count > 0)
                    {
                        var instance = list[list.Count - 1];
                        list.RemoveAt(list.Count - 1);
                        return instance;
                    }

                    return default(T);
                }
            }

            public static void Release(ObjectPool pool, T instance)
            {
                RecursiveRelease(pool, instance);
                using (ReleaseLock.Acquire())
                {
                    var list = _released;
                    if (list.Count < BatchSize * 8)
                    {
                        list.Add(instance);
                    }
                }
            }

            public static bool TrySwap()
            {
                if (_released.Count > BatchSize / 2)
                {
                    using (GetLock.Acquire())
                    using (ReleaseLock.Acquire())
                    {
                        var tmp = _inventory;
                        _inventory = _released;
                        _released = tmp;
                        return true;
                    }
                }

                return false;
            }

            public static void CreateInventory()
            {
                using (GetLock.Acquire())
                {
                    var list = _inventory;
                    for (int i = 0; i < BatchSize; i++)
                    {
                        list.Add(Factory());
                    }
                }
            }
            
            private static Action<ObjectPool, T> BuildReleaseHandler()
            {
                var type = typeof(T);
                var instanceParameter = Expression.Parameter(typeof(T), "instance");
                var poolParameter = Expression.Parameter(typeof(ObjectPool), "pool");

                var blockExpr = new List<Expression>();
                var props = type.GetProperties();
                foreach (var prop in props)
                {
                    var propExpr = Expression.Property(instanceParameter, prop);
                    if (prop.PropertyType == typeof(string) && prop.CanWrite)
                    {
                        blockExpr.Add(Expression.Assign(propExpr, Expression.Constant(null, typeof(string))));
                    }
                    else if (!prop.PropertyType.IsValueType && prop.CanWrite && 
                             !typeof(IEnumerable).IsAssignableFrom(prop.PropertyType))
                    {
                        blockExpr.Add(Expression.Call(poolParameter, typeof(ObjectPool).GetMethod(nameof(Release)), propExpr));
                        blockExpr.Add(Expression.Assign(propExpr, Expression.Constant(null, prop.PropertyType)));
                    }
                    else if (prop.PropertyType.IsValueType && prop.CanWrite)
                    {
                        blockExpr.Add(Expression.Assign(propExpr, Expression.Default(prop.PropertyType)));
                    }
                    else if (typeof(IEnumerable).IsAssignableFrom(prop.PropertyType))
                    {
                        if (prop.PropertyType.IsGenericType && !prop.CanWrite)
                        {
                            var typeArgs = prop.PropertyType.GetGenericArguments();
                            if (typeArgs.Length == 2)
                            {
                                blockExpr.Add(Expression.Call(propExpr,
                                    typeof(ICollection<>).MakeGenericType(
                                        typeof(KeyValuePair<,>).MakeGenericType(typeArgs))
                                        .GetMethod(nameof(ICollection<int>.Clear))));
                            }
                            else
                            {
                                if (typeArgs[0] != typeof(string) && !typeArgs[0].IsValueType)
                                {
                                    blockExpr.Add(Expression.Call(poolParameter,
                                        typeof(ObjectPool).GetMethod(nameof(ReleaseList),
                                            BindingFlags.Instance | BindingFlags.NonPublic), propExpr));
                                }

                                blockExpr.Add(Expression.Call(propExpr,
                                    typeof(ICollection<>).MakeGenericType(typeArgs)
                                        .GetMethod(nameof(ICollection<int>.Clear))));
                            }
                        }
                        else if (prop.CanWrite)
                        {
                            blockExpr.Add(Expression.Assign(propExpr, Expression.Constant(null, prop.PropertyType)));
                        }
                    }
                }

                if (blockExpr.Count == 0)
                {
                    blockExpr.Add(Expression.Empty());
                }

                var lambda = Expression.Lambda<Action<ObjectPool, T>>(
                    Expression.Block(blockExpr), poolParameter, instanceParameter);
                return lambda.Compile();
            }
        }
    }
}
