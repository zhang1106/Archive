﻿namespace Bam.Oms.Compliance.Actions
{
    public interface IAction
    {
    }
}

