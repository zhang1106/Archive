﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Contingency;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.PositionTracker;
using Bam.Oms.SodPosition.Svc;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class PositionTrackerTests
    {
        [TestCase(SideType.Long, 100d, 1.0d, SideType.Buy, 50, 1.0d, SideType.Long, 150, 1.0d)]
        [TestCase(SideType.Long, 100d, 1.0d, SideType.Buy, 150, 1.0d, SideType.Long, 250, 1.0d)]
        [TestCase(SideType.Long, 100d, 1.0d, SideType.Cover, 50, 1.0d, SideType.Long, 150, 1.0d)]
        [TestCase(SideType.Long, 100d, 1.0d, SideType.Cover, 150, 1.0d, SideType.Long, 250, 1.0d)]
        [TestCase(SideType.Long, 100d, 1.0d, SideType.Sell, 50.0, 1.0d, SideType.Long, 50.0, 1.0d)]
        [TestCase(SideType.Long, 100d, 1.0d, SideType.Sell, 150.0, 1.0d, SideType.Short, -50.0, 1.0d)]
        [TestCase(SideType.Long, 100, 1.0d, SideType.SellShort, 50.0, 1.0d, SideType.Long, 50.0, 1.0d)]
        [TestCase(SideType.Long, 100, 1.0d, SideType.SellShort, 150.0, 1.0d, SideType.Short, -50.0, 1.0d)]
        [TestCase(SideType.Short, -100, 1.0d, SideType.Buy, 50, 1.0d, SideType.Short, -50, 1.0d)]
        [TestCase(SideType.Short, -100, 1.0d, SideType.Buy, 150, 1.0d, SideType.Long, 50, 1.0d)]
        [TestCase(SideType.Short, -100, 1.0d, SideType.Cover, 50, 1.0d, SideType.Short, -50, 1.0d)]
        [TestCase(SideType.Short, -100, 1.0d, SideType.Cover, 150, 1.0d, SideType.Long, 50, 1.0d)]
        [TestCase(SideType.Short, -100, 1.0d, SideType.Sell, 50.0, 1.0d, SideType.Short, -150.0, 1.0d)]
        [TestCase(SideType.Short, -100, 1.0d, SideType.Sell, 150.0, 1.0d, SideType.Short, -250.0, 1.0d)]
        [TestCase(SideType.Short, -100, 1.0d, SideType.SellShort, 50.0, 1.0d, SideType.Short, -150.0, 1.0d)]
        [TestCase(SideType.Short, -100, 1.0d, SideType.SellShort, 150.0, 1.0d, SideType.Short, -250.0, 1.0d)]
        [TestCase(SideType.Long, 0, 1.0d, SideType.Buy, 6000, 1.0d, SideType.Long, 6000, 1.0d)]
        public void TestApplyPositionUpdateWithTrade(SideType positionSide, double positionQuantity, double currentPrice, SideType fillSide, double fillQuantity, double fillPrice, SideType expectedSide, double expectedQuantity, double expectedPrice)
        {
            IPortfolio portfolio = Portfolio.Parse("MYPORT-MYSTRATEGY-MYSUBSTRATEGY");
            portfolio.ComplianceGroup = "MYP";
            portfolio.AggregationUnit = "AQTF";
            ISecurity security = new Security() { BamSymbol = "IBM Equity" };
            string primeBroker = "CSFB";
            Allocation allocation = new Allocation();
            allocation.PrimeBroker = primeBroker;

            var prevOrder = new Order();
            prevOrder.Portfolio = (Portfolio)portfolio;
            prevOrder.Security = (Security)security;
            prevOrder.Size = Convert.ToDecimal(fillQuantity * 2);
            prevOrder.Side = fillSide;
            prevOrder.Custodian = primeBroker;
            prevOrder.OrderStatus = BamOrderStatus.Working;

            List<Allocation> allocations = new List<Allocation>() { allocation };

            Mock<IBlockTrade> trade = new Mock<IBlockTrade>();
            trade.SetupGet(pos => pos.Portfolio).Returns((Portfolio)portfolio);
            trade.SetupGet(pos => pos.Security).Returns((Security)security);
            trade.SetupGet(pos => pos.TradedQuantity).Returns(Convert.ToDecimal(fillQuantity));
            trade.SetupGet(pos => pos.AveragePrice).Returns(Convert.ToDecimal(fillPrice));
            trade.SetupGet(pos => pos.Side).Returns(fillSide);
            trade.SetupGet(pos => pos.Allocations).Returns(allocations);

            IPosition expected = new Position(portfolio, security, primeBroker);
            expected.ActualQuantity = Convert.ToDecimal(expectedQuantity);
            expected.TheoreticalQuantity = Convert.ToDecimal(positionQuantity);
            expected.ShortMarkingQuantity = fillSide == SideType.Buy || fillSide == SideType.Cover ? Convert.ToDecimal(expectedQuantity) : Convert.ToDecimal(positionQuantity);
            expected.LongMarkingQuantity = fillSide == SideType.Buy || fillSide == SideType.Cover ? Convert.ToDecimal(positionQuantity) : Convert.ToDecimal(expectedQuantity);
            expected.Price = Convert.ToDecimal(expectedPrice);

            Position sodPosition = new Position(portfolio, security, primeBroker)
            {
                TheoreticalQuantity = Convert.ToDecimal(positionQuantity),
                ActualQuantity = Convert.ToDecimal(positionQuantity),
                ShortMarkingQuantity = Convert.ToDecimal(positionQuantity),
                LongMarkingQuantity = Convert.ToDecimal(positionQuantity),
                Price = Convert.ToDecimal(currentPrice)
            };

            IList<IPosition> sodPositions = new List<IPosition>();
            sodPositions.Add(sodPosition);

            var tradeList = new Dictionary<IPositionKey, IList<IBlockTrade>>();
            Mock<ITradeRepository> tradeRepository = new Mock<ITradeRepository>();
            tradeRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IBlockTrade>(null);
            tradeRepository.Setup(rep => rep.GetAllTrades(null)).Returns(tradeList);

            var orderList = new Dictionary<IPositionKey, IList<IOrder>>();
            Mock<IOrderRepository> orderRepository = new Mock<IOrderRepository>();
            orderRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns(prevOrder);
            orderRepository.Setup(rep => rep.GetAllOrders(null)).Returns(orderList);

            Mock<ISodPositionEdit> sodLoader = new Mock<ISodPositionEdit>();
            sodLoader.Setup(rep => rep.GetPositions(It.IsAny<DateTime?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(sodPositions);

            var effectsCalculator = new PositionEffectCalculator();
            var sodCalculator = new StartOfDayPositionCalculator(effectsCalculator, new Mock<ILogger>().Object);

            var positionRepository = new PositionRepository();

            using (PositionTracker.PositionTracker positionTracker =
                    new PositionTracker.PositionTracker(effectsCalculator, sodCalculator,
                        positionRepository,
                        tradeRepository.Object, orderRepository.Object,
                        new Mock<IContingencyDbRepository>().Object,
                        new Mock<ILogger>().Object))
            {
                positionTracker.LoadSODPositions(sodPositions, orderList, tradeList);
                IPosition actual = positionTracker.ApplyPositionUpdate(trade.Object);

                Assert.True(expected.Equals(actual));
            }
        }

        [TestCase(SideType.Long, 100d, SideType.Buy, 50d, SideType.Long, 150d)]
        [TestCase(SideType.Long, 100d, SideType.Buy, 150d, SideType.Long, 250d)]
        [TestCase(SideType.Long, 100d, SideType.Sell, 50.0, SideType.Long, 50.0)]
        [TestCase(SideType.Long, 100d, SideType.Sell, 150.0, SideType.Short, -50.0)]
        [TestCase(SideType.Short, -100d, SideType.Buy, 50d, SideType.Short, -50d)]
        [TestCase(SideType.Short, -100d, SideType.Buy, 150d, SideType.Long, 50d)]
        [TestCase(SideType.Short, -100d, SideType.Sell, 50.0, SideType.Short, -150.0)]
        [TestCase(SideType.Short, -100d, SideType.Sell, 150.0, SideType.Short, -250.0)]
        [TestCase(SideType.Short, -11745, SideType.Buy, 300.0, SideType.Short, -11445.0)]
        public void TestApplyPositionUpdateWithOrder(SideType positionSide, double positionQuantity, SideType orderSide, double orderQuantity, SideType expectedSide, double expectedQuantity)
        {
            var portfolio = new Portfolio("MYPORT-MYSTRATEGY-MYSUBSTRATEGY");
            portfolio.ComplianceGroup = "MYP";
            portfolio.AggregationUnit = "AQTF";
            var security = new Security() { BamSymbol = "IBM Equity" };
            string primeBroker = "CSFB";

            var order = new Order
            {
                ClientOrderId = "1",
                Portfolio = portfolio,
                Security = security,
                Size = Convert.ToDecimal(orderQuantity),
                Side = orderSide,
                Custodian = primeBroker,
                OrderStatus = BamOrderStatus.New
            };

            IPosition expected = new Position(portfolio, security, primeBroker);
            expected.TheoreticalQuantity = Convert.ToDecimal(expectedQuantity);
            expected.ActualQuantity = Convert.ToDecimal(positionQuantity);
            expected.ShortMarkingQuantity = orderSide == SideType.Buy || orderSide == SideType.Cover ? Convert.ToDecimal(positionQuantity) : Convert.ToDecimal(expectedQuantity);
            expected.LongMarkingQuantity = orderSide == SideType.Buy || orderSide == SideType.Cover ? Convert.ToDecimal(expectedQuantity) : Convert.ToDecimal(positionQuantity);

            Position sodPosition = new Position(portfolio, security, primeBroker)
            {
                TheoreticalQuantity = Convert.ToDecimal(positionQuantity),
                ActualQuantity = Convert.ToDecimal(positionQuantity),
                ShortMarkingQuantity = Convert.ToDecimal(positionQuantity),
                LongMarkingQuantity = Convert.ToDecimal(positionQuantity)
            };

            IList<IPosition> sodPositions = new List<IPosition>();
            sodPositions.Add(sodPosition);

            var tradeList = new Dictionary<IPositionKey, IList<IBlockTrade>>();
            Mock<ITradeRepository> tradeRepository = new Mock<ITradeRepository>();
            tradeRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IBlockTrade>(null);
            tradeRepository.Setup(rep => rep.GetAllTrades(null)).Returns(tradeList);
            tradeRepository.Setup(rep => rep.GetByClientOrderId(It.IsAny<string>()))
                .Returns(Enumerable.Empty<BlockTrade>());

            var orderList = new Dictionary<IPositionKey, IList<IOrder>>();
            Mock<IOrderRepository> orderRepository = new Mock<IOrderRepository>();
            orderRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IOrder>(null);
            orderRepository.Setup(rep => rep.GetAllOrders(null)).Returns(orderList);

            Mock<ISodPositionEdit> sodLoader = new Mock<ISodPositionEdit>();
            sodLoader.Setup(rep => rep.GetPositions(It.IsAny<DateTime?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(sodPositions);

            var effectsCalculator = new PositionEffectCalculator();
            var sodCalculator = new StartOfDayPositionCalculator(effectsCalculator, new Mock<ILogger>().Object);

            var positionRepository = new PositionRepository();

            using (PositionTracker.PositionTracker positionTracker =
                    new PositionTracker.PositionTracker(effectsCalculator, sodCalculator,
                        positionRepository,
                        tradeRepository.Object, orderRepository.Object,
                        new Mock<IContingencyDbRepository>().Object,
                        new Mock<ILogger>().Object))
            {
                positionTracker.LoadSODPositions(sodPositions, orderList, tradeList);
                IPosition actual = positionTracker.ApplyOrderUpdate(order);

                Assert.True(expected.Equals(actual));
            }
        }

        [TestCase(SideType.Long, 100d, SideType.Buy, 50d, SideType.Long, 50d)]
        [TestCase(SideType.Long, 100d, SideType.Buy, 150d, SideType.Short, -50d)]
        [TestCase(SideType.Long, 100d, SideType.Cover, 50d, SideType.Long, 50d)]
        [TestCase(SideType.Long, 100d, SideType.Cover, 150d, SideType.Short, -50d)]
        [TestCase(SideType.Long, 100d, SideType.Sell, 50.0, SideType.Long, 150.0)]
        [TestCase(SideType.Long, 100d, SideType.Sell, 150.0, SideType.Long, 250.0)]
        [TestCase(SideType.Long, 100d, SideType.SellShort, 50.0, SideType.Long, 150.0)]
        [TestCase(SideType.Long, 100d, SideType.SellShort, 150.0, SideType.Long, 250.0)]
        [TestCase(SideType.Short, -100d, SideType.Buy, 50d, SideType.Short, -150d)]
        [TestCase(SideType.Short, -100d, SideType.Buy, 150d, SideType.Short, -250d)]
        [TestCase(SideType.Short, -100d, SideType.Cover, 50d, SideType.Short, -150d)]
        [TestCase(SideType.Short, -100d, SideType.Cover, 150, SideType.Short, -250d)]
        [TestCase(SideType.Short, -100d, SideType.Sell, 50.0, SideType.Short, -50.0)]
        [TestCase(SideType.Short, -100d, SideType.Sell, 150.0, SideType.Long, 50.0)]
        [TestCase(SideType.Short, -100d, SideType.SellShort, 50.0, SideType.Short, -50.0)]
        [TestCase(SideType.Short, -100d, SideType.SellShort, 150.0, SideType.Long, 50.0)]
        public void TestCancelOrder(SideType positionSide, double positionQuantity, SideType orderSide, double orderQuantity, SideType expectedSide, double expectedQuantity)
        {
            var portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            portfolio.ComplianceGroup = "MYP";
            portfolio.AggregationUnit= "AQTF";

            var security = new Security();
            security.BamSymbol = "IBM Equity";
            string primeBroker = "CSFB";

            var prevOrder = new Order();
            prevOrder.ClientOrderId = "1";
            prevOrder.Portfolio = portfolio;
            prevOrder.Security = security;
            prevOrder.Size = Convert.ToDecimal(orderQuantity);
            prevOrder.Side = orderSide;
            prevOrder.Custodian = primeBroker;
            prevOrder.OrderStatus = BamOrderStatus.New;

            Mock<IOrder> order = new Mock<IOrder>();
            order.SetupGet(pos => pos.ClientOrderId).Returns("1");
            order.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            order.SetupGet(pos => pos.Security).Returns(security);
            order.SetupGet(pos => pos.Size).Returns(Convert.ToDecimal(orderQuantity));
            order.SetupGet(pos => pos.Side).Returns(orderSide);
            order.SetupGet(pos => pos.Custodian).Returns(primeBroker);
            order.SetupGet(pos => pos.OrderStatus).Returns(BamOrderStatus.Cancelled);

            IPosition expected = new Position(portfolio, security, primeBroker);
            expected.TheoreticalQuantity = Convert.ToDecimal(expectedQuantity);
            expected.ActualQuantity = Convert.ToDecimal(positionQuantity);
            expected.ShortMarkingQuantity = orderSide == SideType.Buy || orderSide == SideType.Cover ? Convert.ToDecimal(positionQuantity) : Convert.ToDecimal(expectedQuantity);
            expected.LongMarkingQuantity = orderSide == SideType.Buy || orderSide == SideType.Cover ? Convert.ToDecimal(expectedQuantity) : Convert.ToDecimal(positionQuantity);

            Position sodPosition = new Position(portfolio, security, primeBroker)
            {
                TheoreticalQuantity = Convert.ToDecimal(positionQuantity),
                ActualQuantity = Convert.ToDecimal(positionQuantity),
                ShortMarkingQuantity = Convert.ToDecimal(positionQuantity),
                LongMarkingQuantity = Convert.ToDecimal(positionQuantity)
            };

            IList<IPosition> sodPositions = new List<IPosition>();
            sodPositions.Add(sodPosition);

            var tradeList = new Dictionary<IPositionKey, IList<IBlockTrade>>();
            Mock<ITradeRepository> tradeRepository = new Mock<ITradeRepository>();
            tradeRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IBlockTrade>(null);
            tradeRepository.Setup(rep => rep.GetAllTrades(null)).Returns(tradeList);
            tradeRepository.Setup(rep => rep.GetByClientOrderId(It.IsAny<string>())).Returns(Enumerable.Empty<BlockTrade>());


            var orderList = new Dictionary<IPositionKey, IList<IOrder>>();
            orderList.Add(new PositionKey(prevOrder.Portfolio, prevOrder.Security), new List<IOrder> { prevOrder });
            Mock<IOrderRepository> orderRepository = new Mock<IOrderRepository>();
            orderRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IOrder>(null);
            orderRepository.Setup(rep => rep.GetAllOrders(null)).Returns(orderList);
            orderRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns(prevOrder);
            orderRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns(prevOrder);

            Mock<ISodPositionEdit> sodLoader = new Mock<ISodPositionEdit>();
            sodLoader.Setup(rep => rep.GetPositions(It.IsAny<DateTime?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(sodPositions);

            var effectsCalculator = new PositionEffectCalculator();
            var sodCalculator = new StartOfDayPositionCalculator(effectsCalculator, new Mock<ILogger>().Object);

            var positionRepository = new PositionRepository();

            using (
                PositionTracker.PositionTracker positionTracker =
                    new PositionTracker.PositionTracker(effectsCalculator, sodCalculator,
                        positionRepository,
                        tradeRepository.Object, orderRepository.Object,
                        new Mock<IContingencyDbRepository>().Object,
                        new Mock<ILogger>().Object))
            {
                positionTracker.LoadSODPositions(sodPositions, new Dictionary<IPositionKey, IList<IOrder>>(), tradeList);
                IPosition actual = positionTracker.ApplyOrderUpdate(order.Object);

                var unit = expected.Equals(actual);

                Assert.That(unit, Is.True);
            }
        }

        [Test]
        public void TestUpdateSODPosition()
        {
            var portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            portfolio.ComplianceGroup = "MYP";
            portfolio.AggregationUnit = "AQTF";

            var security = new Security();
            security.BamSymbol = "IBM Equity";
            string primeBroker = "CSFB";

            IPosition expected = new Position(portfolio, security, primeBroker);
            expected.TheoreticalQuantity = 100;
            expected.ActualQuantity = 100;
            expected.LongMarkingQuantity = 100;
            expected.ShortMarkingQuantity = 100;

            Position sodPosition = new Position(portfolio, security, primeBroker)
            {
                TheoreticalQuantity = -200,
                ActualQuantity = -200
            };

            Position newSODPosition = new Position(portfolio, security, primeBroker)
            {
                TheoreticalQuantity = 100,
                ActualQuantity = 100
            };

            IList<IPosition> sodPositions = new List<IPosition>();
            sodPositions.Add(sodPosition);

            var tradeList = new Dictionary<IPositionKey, IList<IBlockTrade>>();
            Mock<ITradeRepository> tradeRepository = new Mock<ITradeRepository>();
            tradeRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IBlockTrade>(null);
            tradeRepository.Setup(rep => rep.GetAllTrades(null)).Returns(tradeList);

            var orderList = new Dictionary<IPositionKey, IList<IOrder>>();
            Mock<IOrderRepository> orderRepository = new Mock<IOrderRepository>();
            orderRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IOrder>(null);
            orderRepository.Setup(rep => rep.GetAllOrders(It.IsAny<Func<IOrder, bool>>())).Returns(orderList);

            Mock<ISodPositionEdit> sodLoader = new Mock<ISodPositionEdit>();
            sodLoader.Setup(rep => rep.GetPositions(It.IsAny<DateTime?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(sodPositions);

            var effectsCalculator = new PositionEffectCalculator();
            var sodCalculator = new StartOfDayPositionCalculator(effectsCalculator, new Mock<ILogger>().Object);

            var positionRepository = new PositionRepository();

            using (
                PositionTracker.PositionTracker positionTracker =
                    new PositionTracker.PositionTracker(effectsCalculator, sodCalculator,
                        positionRepository,
                        tradeRepository.Object, orderRepository.Object,
                        new Mock<IContingencyDbRepository>().Object,
                        new Mock<ILogger>().Object))
            {
                positionTracker.LoadSODPositions(sodPositions, orderList, tradeList);
                IPosition actual = positionTracker.UpdateSODPositions(new [] { newSODPosition }).First();

                var unit = expected.Equals(actual);

                Assert.That(unit, Is.True);
            }
        }
    }
}
