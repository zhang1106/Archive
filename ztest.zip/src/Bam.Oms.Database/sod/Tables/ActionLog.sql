﻿CREATE TABLE [sod].[ActionLog]
(
	[ActionLogId] INT IDENTITY(1, 1) NOT NULL PRIMARY KEY, 
    [ActionId] INT NOT NULL, 
    [ActionDetails] varchar(500),
    [CreatedBy] VARCHAR(50) NULL, 
    [CreatedOn] DATETIME NOT NULL DEFAULT getdate()
)
