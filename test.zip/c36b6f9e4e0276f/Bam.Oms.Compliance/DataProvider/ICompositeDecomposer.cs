﻿using System.Collections.Generic;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface ICompositeDecomposer
    {
        IEnumerable<IPosition> Decompose(IPosition position);
    }
}
