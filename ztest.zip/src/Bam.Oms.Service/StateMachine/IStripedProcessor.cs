﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.RefData;

namespace Bam.Oms.Service
{
    public interface IStripedProcessor
    {
        long TotalOrdersProcessed { get; set; }

        Task RequestLocate(IOrder order);

        Task<T> InvokeOnProcessor<T>(Func<T> action);

        bool SetInitialized(bool bInitialized);        

        Task<IOrder> GetOrderAsync(string orderId);

        Task<IList<IOrder>> MarkOrderAsync(IOrder order, string batchId = null);

        Task<IList<IOrder>> MarkOrderAsync(IList<IOrder> order, string batchId = null);

        Task<IPosition> TrackTradeAsync(IBlockTrade trade);

        Task RevertOrderAsync(IOrder order, string batchId);

        Task<IOrder> SaveOrderAsync(IOrder order, string batchId = null);

        Task<IBlockTrade> SaveTradeAsync(IBlockTrade trade, string batchId = null);        

        Task<IOrder> DeleteOrderAsync(IOrder order, string batchId = null);        
        
        IList<IOrder> RouteOrders(IList<IOrder> orders, string batchId = null);

        Task<IList<IOrder>> RouteOrdersAsync(IList<IOrder> orders, string batchId = null);

        Task<IList<IOrder>> SetStateAsync(IEnumerable<string> orderIds, BamOrderStatus orderStatus);

        Task<IOrder> CancelOrderAsync(IOrder order);

        Task<IList<IOrder>> CancelOrderAsync(IList<IOrder> orders);

        Task<IList<Position>> LoadSODPositionsAsync(IList<Position> sodPositions);
        Task<IList<Position>> UpdateSODPositionsAsync(IList<Position> sodPositions);

        Task<IList<Position>> UpdatePositionsAsync(IList<Position> sodPositions);

        void ProcessOrderUpdate(IReadOnlyList<IOrder> orders);
        void ProcessTradeUpdate(IReadOnlyList<IBlockTrade> trades);

        HashSet<string> SubscribedSymbols { get; }

        void AddSubscribedSymbol(string symbol);

        Task<IList<IOrder>> UpdateSecurityInfo(IList<IUpdateSecurity> securities);

        event Action<IOrder> OrderStatusChanged;
        event Action<IList<IOrder>> OrdersStatusChanged;
        event Action<IBlockTrade> TradeStatusChanged;
        event Action<IList<IBlockTrade>> TradesStatusChanged;
    }

}