using System;
using System.IO;
using System.Threading;
using Bam.Compliance.Infrastructure.Logger;
using Bam.Compliance.Infrastructure.Threading;

namespace Bam.Oms.Compliance.File
{
    public abstract class FileListener
    {
        private readonly string _watchPath;
        private readonly string _archivePath;
        private readonly string _errorPath;
        private readonly IBackgroundWorker _fileMonitorWorker;

        public string Name { get; set; }
        public ILogger Logger { get; set; }
       

        protected FileListener(  string watchPath, string archivePath, string errorPath)
        {
            
            _watchPath = watchPath;
            _archivePath = archivePath;
            _errorPath = errorPath;
            _fileMonitorWorker = BackgroundWorkerFactory.Current.Create($"Watching {_watchPath}");
        }

        public void Start()
        {
            _fileMonitorWorker.Start(MonitorDirectory);
        }

        public void Stop()
        {
            _fileMonitorWorker.Stop();
        }

        private void MonitorDirectory(CancellationToken cancellationToken)
        {
            while (!cancellationToken.WaitHandle.WaitOne(TimeSpan.FromSeconds(1)))
            {
                try
                {
                    if (!Directory.Exists(_watchPath))
                    {
                        Directory.CreateDirectory(_watchPath);
                    }

                    foreach (var path in Directory.EnumerateFiles(_watchPath, "*.csv", SearchOption.TopDirectoryOnly))
                    {
                        Logger?.LogInformation($"Processing {path}");
                        try
                        {
                            var entryUser = System.IO.File.GetAccessControl(path)?.GetOwner(typeof(System.Security.Principal.NTAccount))?.ToString().Replace("FOUNTAINHEAD\\", "");
                            ProcessFile(path, entryUser);
                            ArchiveFile(path, _archivePath);
                        }
                        catch (Exception ex)
                        {
                            Logger?.LogError("Error processing file", ex);
                            ArchiveFile(path, _errorPath);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger?.LogError("Error scanning files", ex);
                }
            }
        }

        private void ArchiveFile(string path, string folderLocation)
        {
            // ReSharper disable once AssignNullToNotNullAttribute
            string folder = Path.Combine(folderLocation, DateTime.Today.ToString("yyyyMMdd"));
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string suffix = string.Empty;
            string archivePath = Path.Combine(folder, Path.GetFileName(path) + $".{DateTime.Now:yyyyMMddHHmmss}");

            while (System.IO.File.Exists(archivePath + suffix))
            {
                suffix = suffix == string.Empty ? "2" : Convert.ToString(Convert.ToInt32(suffix) + 1);
            }

            System.IO.File.Move(path, archivePath + suffix);
        }

        protected abstract void ProcessFile(string path, string entryUser);
    }
}
