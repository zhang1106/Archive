﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.ServiceModel;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.DataProvider
{
    public class BbMarketDataProvider : IBbMarketDataProvider
    {
        public const string Fields =
            "TICKER,NAME,EQY_SH_OUT,EQY_SH_OUT_REAL,CNTRY_OF_DOMICILE,ULT_PARENT_CNTRY_OF_RISK,SEDOL1_COUNTRY_ISO,CNTRY_ISSUE_ISO,PX_LAST,ID_ISIN,GICS_INDUSTRY_NAME,SECURITY_TYP";

        private readonly ISettings _settings;
        private readonly ILogger _logger;

        public BbMarketDataProvider( ISettings settings, ILogger logger)
        {
           
            _settings = settings;
            _logger = logger;
        }

        public MarketData GetMarketData(string symbol)
        {
            var list = GetMarketDataList(new[] {symbol})?.ToList();
            return list == null || !list.Any() ? null : list[0];
        }

        public IEnumerable<MarketData> GetMarketDataList(string[] symbols)
        {
            using (var service = new BbMarketData.QuoteServiceClient("MarketDataServiceEP1"))
            {
                var result = new List<MarketData>();

                var batches = Batch<string>.Partition(symbols, _settings.BbBatchSize);

                foreach (var b in batches)
                {
                    
                        if (service.State != CommunicationState.Opened) service.ReCreateSessions();

                        var fields = Fields.Split(',');

                        _logger.Info("BB: Try to get data from Bb for " + string.Join(",", b.Data));

                        var ds = service.GetReferenceQuote("Equity Process", b.Data.ToArray(), fields, null, null);

                        if (ds == null || ds.Tables.Count <= 0) return null;

                        var refdata = ds.Tables[0];
                        if (refdata.Rows.Count <= 0) return null;

                        foreach (DataRow r in refdata.Rows)
                        {
                            try
                            {
                                var marketData = new MarketData()
                                {
                                    Symbol = GetBamSymbol(r),
                                    SharesOutstanding = GetLong(r,"EQY_SH_OUT_REAL"),
                                    PriceInDollar = GetDecimal(r, "PX_LAST"),
                                    CountryOfDomicile = GetString(r, "CNTRY_OF_DOMICILE"),
                                    CountryOfRisk = GetString(r, "ULT_PARENT_CNTRY_OF_RISK"),
                                    CountryOfSedo1 = GetString(r, "SEDOL1_COUNTRY_ISO"),
                                    ISIN = GetString(r, "ID_ISIN"),
                                    GicIndustry = GetString(r,"GICS_INDUSTRY_NAME"),
                                    SecurityType = GetString(r, "SECURITY_TYP"),
                                };

                                _logger.Info($"BB: Data returned from BB {marketData.ToString()}");
                                if (!string.IsNullOrEmpty(marketData.Symbol) && marketData.SharesOutstanding != null)
                                {
                                    result.Add(marketData);
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.Warn("BB:" + ex.Message);
                            }
                        }
                   
                }

                return result;
            }
        }

        protected decimal? GetDecimal(DataRow r, string field)
        {
            if (r[field] is DBNull) return (decimal?) null;
            return Convert.ToDecimal(r[field]);
        }

        protected long? GetLong(DataRow r, string field)
        {
            if (r[field] is DBNull) return (Int64?)null;
            return Convert.ToInt64(r[field]);
        }


        protected string GetString(DataRow r, string field)
        {
            if (r[field] is DBNull) return string.Empty;
            return r[field].ToString();
        }

        protected string GetBamSymbol(DataRow r)
        {
            var sym = r[0].ToString();
            return sym.Replace("\"", "").Substring(0, sym.LastIndexOf(" ")).Trim(); ;
        }
    }
   
}
