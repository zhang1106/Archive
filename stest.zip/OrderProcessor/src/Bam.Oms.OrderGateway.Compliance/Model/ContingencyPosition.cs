﻿namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public class ContingencyPosition
    {
        public string BamSymbol { get; set; }
        public long Quantity { get; set; }
        public string Portfolio { get; set; }
        public string Fund { get; set; }
        public string Custodian { get; set; }
        public string Stream { get; set; }
    }
}