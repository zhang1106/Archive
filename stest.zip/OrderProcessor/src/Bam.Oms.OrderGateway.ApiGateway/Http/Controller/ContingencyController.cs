﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.ApiGateway.Services;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class ContingencyController : BaseController
    {
        private readonly ICache<long, Position> _positionCache;
        private readonly IContingencyRecordRepository _repository;

        public ContingencyController(
            IPermissionedEntityFilter entityFilter,
            ICache<long, Position> positionCache,
            IContingencyRecordRepository repository) 
            : base(entityFilter)
        {
            _positionCache = positionCache;
            _repository = repository;
        }

        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public async Task<List<ContingencyRecord>> Get()
        {
            var records = await _repository.Load();
            var filtered = await FilterEntitiesAsync(records, r => r.Portfolio);
            return filtered.ToList();
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public async Task<string> Refresh()
        {
            var records = new List<ContingencyRecord>();
            using (_positionCache.AcquireReadAccess())
            {
                foreach (var p in _positionCache.GetItems())
                    records.Add(new ContingencyRecord(p));
            }

            await _repository.Save(records);
            return $"Persisted {records.Count} positions";
        }
    }
}
