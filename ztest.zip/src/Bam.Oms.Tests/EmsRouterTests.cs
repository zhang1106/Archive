﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.EMSAdapters.Contracts;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.OrderRouting.Flex;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.RefData;
using Bam.Oms.ReferenceDataGateway.Api.Model;
using BAM.Infrastructure.Ioc;
using Ft;
using Grpc.Core;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using Order = Bam.Oms.Data.Orders.Order;
using Portfolio = Bam.Oms.Data.Portfolios.Portfolio;
using Security = Bam.Oms.Data.Securities.Security;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class EmsRouterTests
    {
        private IAccountService accountService;

        [SetUp]
        public void Setup()
        {
            var serviceMock = new Mock<IAccountService>();
            serviceMock.Setup(r => r.GetFlexTraderCode(It.IsAny<int>())).Returns("MQI");

            accountService = serviceMock.Object;
        }

        [TestCase(SideType.Buy, MarketSide.BUY, false)]
        [TestCase(SideType.Sell, MarketSide.SELL, false)]
        [TestCase(SideType.SellShort, MarketSide.SHORT, false)]
        [TestCase(SideType.Cover, MarketSide.COVER, false)]
        [TestCase(SideType.Buy, MarketSide.BUY, true)]
        [TestCase(SideType.Sell, MarketSide.SELL, true)]
        [TestCase(SideType.SellShort, MarketSide.SHORT, true)]
        [TestCase(SideType.Cover, MarketSide.COVER, true)]
        public void VerifySubmitFlexTradeRequest(SideType side, MarketSide flexSide, bool isStaged)
        {
            // arrange
            CreateOrdersRequest generatedRequest = null;

            Coverage coverage = new Coverage()
            {
                AssetType = AssetType.Equity,
                Currency = "USD",
                EzeId = "MQI",
                FlexId = "MQI",
            };
            var coverageService = new Mock<ReferenceDataGateway.Api.Http.ICoverageController>();
            coverageService.Setup(a => a.GetTraderCoverage(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<AssetType>())).Returns(coverage);

            //mocks/test data
            var flexOrderSvc = new Mock<IGrpcServices>();
            var orderSvc = new Mock<OrderService.IOrderServiceClient>();

            var response = new CreateOrdersResponse();
            var status = new ResponseStatus();
            response.BatchId = "batch";
            status.Success = true;
            response.Status = status;

            var order = CreateOrder(side);

            orderSvc.Setup(f => f.CreateOrders(It.IsAny<CreateOrdersRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<CreateOrdersRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => generatedRequest = request);

            flexOrderSvc.Setup(r => r.OrderServiceClient).Returns(orderSvc.Object);

            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CreateOrdersResponse>>()))
                .Returns(response);

            var router = new EmsRouter(flexOrderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            // act
            router.SubmitOrders(new List<IOrder> { order }, isStaged);

            // assert
            Assert.IsNotNull(generatedRequest);
            Assert.That(generatedRequest.Orders.Count, Is.EqualTo(1));

            Assert.That(generatedRequest.Orders[0].Symbol, Is.EqualTo("IBM Equity"));
            Assert.That(generatedRequest.Orders[0].User, Is.EqualTo("MQI"));
            Assert.That(generatedRequest.Orders[0].Quantity, Is.EqualTo(100));
            Assert.That(generatedRequest.Orders[0].Strategy, Is.EqualTo("COBI-GENERALIST-EMR"));
            Assert.That(generatedRequest.Orders[0].Side, Is.EqualTo(flexSide));
            Assert.That(generatedRequest.Orders[0].OverridePrimeBrokerAllocations[0].Name, Is.EqualTo("CSFB"));
            Assert.That(generatedRequest.Orders[0].OverridePrimeBrokerAllocations[0].Ratio, Is.EqualTo(1.0D));
            Assert.That(generatedRequest.SendToEms, Is.EqualTo(!isStaged));
        }

        private Order GenerateMinOrder(string clientOrderId)
        {
            return new Order
            {
                ClientOrderId = clientOrderId,
                Trader = "trader",
                Security = new Security { BamSymbol = "bamSymbol" },
                Side = SideType.Buy,
                Portfolio = new Portfolio("pmCode", "strategy", "subStrategy"),
                RoutedSize = 1m,
                Custodian = "custodian",
                Locate = new List<Data.Orders.Locate>()
            };
        }

        private IOrder CreateOrder(SideType side)
        {
            var security = new Security { BamSymbol = "IBM Equity" };


            var port = new Portfolio("COBI", "GENERALIST", "EMR");

            var order = new Order
            {
                Security = security,
                Portfolio = port,
                ClientOrderId = "ID123",
                Custodian = "CSFB",
                Side = side,
                Size = 100,
                RoutedSize = 100,
                Trader = "MQI",
                OrderStatus = BamOrderStatus.PendingValidation
            };

            return order;
        }

        [Test]
        public void VerifyAmendBadResponseThrows()
        {
            // arrange
            var response = new ReplaceOrderResponse { Success = false, OrderId = "123" };


            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);
            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<ReplaceOrderResponse>>())).Returns(response);

            var orderRepo = new Mock<IOrderRepository>();
            orderRepo.Setup(r => r.Get("123")).Returns(new Order());

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            //act
            var unit = router.AmendOrder(CreateOrder(SideType.Buy), "123");

            // assert
            Assert.AreEqual(BamOrderStatus.Error, unit.OrderStatus);
        }

        [TestCase(SideType.Buy, MarketSide.BUY, false)]
        [TestCase(SideType.Sell, MarketSide.SELL, false)]
        [TestCase(SideType.SellShort, MarketSide.SHORT, false)]
        [TestCase(SideType.Cover, MarketSide.COVER, false)]
        [TestCase(SideType.Buy, MarketSide.BUY, true)]
        [TestCase(SideType.Sell, MarketSide.SELL, true)]
        [TestCase(SideType.SellShort, MarketSide.SHORT, true)]
        [TestCase(SideType.Cover, MarketSide.COVER, true)]
        [Test]
        public void VerifyAmendOrderFlexRequest(SideType side, MarketSide flexSide, bool isStaged)
        {
            // arrange
            var orderId = "ID123";

            ReplaceOrderRequest generatedRequest = null;

            //mocks/test data

            var response = new ReplaceOrderResponse
            {
                OrderId = orderId,
                Success = true
            };

            var order = CreateOrder(side);
            order.RoutedSize = order.Size; // this normally is done in the process order call, but here we aren't testing that

            var replace = CreateOrder(side);
            replace.ClientOrderId = orderId;

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get("originalOrder")).Returns((Order)order);
            repo.Setup(r => r.Get("ID123")).Returns((Order)replace);

            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            flexOrderSvc.Setup(f => f.ReplaceOrder(It.IsAny<ReplaceOrderRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<ReplaceOrderRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => generatedRequest = request);

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);


            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<ReplaceOrderResponse>>()))
                .Returns(response);

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            // act
            var amendOrder = router.AmendOrder(order, "originalOrder", isStaged);

            // assert
            Assert.IsNotNull(generatedRequest);

            Assert.That(generatedRequest.OriginalOrderId, Is.EqualTo("originalOrder"));
            Assert.That(generatedRequest.Order.Symbol, Is.EqualTo("IBM Equity"));
            Assert.That(generatedRequest.Order.Quantity, Is.EqualTo(100));
            Assert.That(generatedRequest.Order.Strategy, Is.EqualTo("COBI-GENERALIST-EMR"));
            Assert.That(generatedRequest.Order.User, Is.EqualTo("MQI"));
            Assert.That(generatedRequest.Order.Side, Is.EqualTo(flexSide));
            Assert.That(generatedRequest.SendToEms, Is.EqualTo(!isStaged));
            Assert.That(amendOrder.ClientOrderId, Is.EqualTo(orderId));
            Assert.That(amendOrder.OrderStatus, Is.EqualTo(BamOrderStatus.New));
            Assert.That(amendOrder.RoutedSize, Is.EqualTo(100));
        }

        [Test]
        public void VerifyAmendOrderMissingValuesThrows()
        {
            // arrange
            var router = new EmsRouter(new Mock<IGrpcServices>().Object, new Mock<IStreamParser>().Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object, accountService, new Mock<ISecurityMasterService>().Object);

            // assert
            Assert.Throws<ArgumentNullException>(() => router.AmendOrder(null, "test"));
            Assert.Throws<ArgumentNullException>(() => router.AmendOrder(new Mock<IOrder>().Object, null));
        }

        [Ignore]
        [Test]
        public void VerifyAmendSetsOriginalToPending()
        {
            // arrange
            var response = new ReplaceOrderResponse { Success = false, OrderId = "123" };


            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);
            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<ReplaceOrderResponse>>())).Returns(response);

            var original = new Order();

            var orderRepo = new Mock<IOrderRepository>();
            orderRepo.Setup(r => r.Get("123")).Returns(original);

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            //act
            var unit = router.AmendOrder(CreateOrder(SideType.Buy), "123");

            // assert
            Assert.AreEqual(original.OrderStatus, unit.OrderStatus);
        }

        [Test]
        public void VerifyAmendSetsOriginalToReplacedAndNewToPendingRouted()
        {
            // arrange
            var response = new ReplaceOrderResponse { Success = true, OrderId = "123" };

            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);
            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<ReplaceOrderResponse>>())).Returns(response);

            var newOrder = (Order)CreateOrder(SideType.Buy);
            var replacedOrder = (Order)CreateOrder(SideType.Buy);
            replacedOrder.ClientOrderId = "456";


            var orderRepo = new Mock<IOrderRepository>();
            orderRepo.Setup(r => r.Get("123")).Returns(newOrder);
            orderRepo.Setup(r => r.Get("456")).Returns(replacedOrder);

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            //act
            router.AmendOrder(newOrder, "456");

            // assert
            Assert.That(newOrder.OrderStatus, Is.EqualTo(BamOrderStatus.New));
        }

        [Test]
        public void VerifyCancelOrderBadResponseReturnsEmptyList()
        {
            // arrange
            var response = new CancelOrdersResponse();
            var status = new ResponseStatus { Success = false };
            response.Status = status;

            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);
            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CancelOrdersResponse>>())).Returns(response);

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get(It.IsAny<string>())).Returns((Order)CreateOrder(SideType.Buy));

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);
            //act
            var unit = router.CancelOrders(new List<string> { "123" });

            // assert
            Assert.That(unit, Is.Empty);
        }

        [Test]
        public void VerifyEmsRouterCtorMissingValuesThrows()
        {
            // assert            
            // ReSharper disable ObjectCreationAsStatement
            Assert.Throws<ArgumentNullException>(() => new EmsRouter(null, new Mock<IStreamParser>().Object, new Mock<ILogger>().Object, new Mock<IInstructionToEmsTagMapper>().Object, accountService, new Mock<ISecurityMasterService>().Object));
            Assert.Throws<ArgumentNullException>(() => new EmsRouter(new Mock<IGrpcServices>().Object, null, new Mock<ILogger>().Object, new Mock<IInstructionToEmsTagMapper>().Object, accountService, new Mock<ISecurityMasterService>().Object));
            Assert.Throws<ArgumentNullException>(() => new EmsRouter(new Mock<IGrpcServices>().Object, new Mock<IStreamParser>().Object, null, new Mock<IInstructionToEmsTagMapper>().Object, accountService, new Mock<ISecurityMasterService>().Object));
            Assert.Throws<ArgumentNullException>(() => new EmsRouter(new Mock<IGrpcServices>().Object, new Mock<IStreamParser>().Object, new Logger(), null, accountService, new Mock<ISecurityMasterService>().Object));
            Assert.Throws<ArgumentNullException>(() => new EmsRouter(new Mock<IGrpcServices>().Object, new Mock<IStreamParser>().Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object, null, new Mock<ISecurityMasterService>().Object));
            // ReSharper restore ObjectCreationAsStatement
        }

        [Test]
        public void VerifyFlexCancelOrdersRequest()
        {
            // arrange
            CancelOrdersRequest generatedRequest = null;

            var responseBuilder = new CancelOrdersResponse { Status = new ResponseStatus { Success = true } };
            responseBuilder.Results.Add(new CancelOrderResult { OrderId = "ibm_123", Success = true });
            responseBuilder.Results.Add(new CancelOrderResult { OrderId = "aapl_456", Success = true });

            var orderSvc = new Mock<IGrpcServices>();

            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            flexOrderSvc.Setup(f => f.CancelOrders(It.IsAny<CancelOrdersRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<CancelOrdersRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => generatedRequest = request);

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);

            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CancelOrdersResponse>>()))
                .Returns(responseBuilder);

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get(It.IsAny<string>())).Returns((Order)CreateOrder(SideType.Buy));

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            // act
            var responseList = router.CancelOrders(new List<string> { "ibm_123", "aapl_456" });

            // assert
            Assert.IsNotNull(generatedRequest);
            Assert.That(generatedRequest.OrderIds.Count, Is.EqualTo(2));
            Assert.That(generatedRequest.OrderIds, Contains.Item("ibm_123"));
            Assert.That(generatedRequest.OrderIds, Contains.Item("aapl_456"));
            Assert.That(responseList.Count, Is.EqualTo(2));
            Assert.That(responseList, Contains.Item("ibm_123"));
            Assert.That(responseList, Contains.Item("aapl_456"));
        }

        [Test]
        public void VerifyFlexCancelOrdersRequestWithFailedCancel()
        {
            // arrange
            CancelOrdersRequest generatedRequest = null;

            var responseBuilder = new CancelOrdersResponse { Status = new ResponseStatus { Success = true } };
            responseBuilder.Results.Add(new CancelOrderResult { OrderId = "ibm_123", Success = true });
            responseBuilder.Results.Add(new CancelOrderResult { OrderId = "aapl_456", Success = false });

            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            flexOrderSvc.Setup(f => f.CancelOrders(It.IsAny<CancelOrdersRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<CancelOrdersRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => generatedRequest = request);

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);


            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CancelOrdersResponse>>()))
                .Returns(responseBuilder);

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get(It.IsAny<string>())).Returns((Order)CreateOrder(SideType.Buy));

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            // act
            var responseList = router.CancelOrders(new List<string> { "ibm_123", "aapl_456" });

            // assert
            Assert.IsNotNull(generatedRequest);
            Assert.That(generatedRequest.OrderIds.Count, Is.EqualTo(2));
            Assert.That(generatedRequest.OrderIds, Contains.Item("ibm_123"));
            Assert.That(generatedRequest.OrderIds, Contains.Item("aapl_456"));
            Assert.That(responseList.Count, Is.EqualTo(1));
            Assert.That(responseList, Contains.Item("ibm_123"));
            Assert.That(responseList, !Contains.Item("aapl_456"));
        }

        [Ignore]
        [Test]
        public void VerifyFlexCancelOrdersSetsOrderStatus()
        {
            // arrange
            CancelOrdersRequest generatedRequest = null;
            var order = new Order { Trader = "MQI" };

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get(It.IsAny<string>())).Returns(order);

            var responseBuilder = new CancelOrdersResponse { Status = new ResponseStatus { Success = true } };
            responseBuilder.Results.Add(new CancelOrderResult { OrderId = "ibm_123", Success = true });


            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            flexOrderSvc.Setup(f => f.CancelOrders(It.IsAny<CancelOrdersRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<CancelOrdersRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => generatedRequest = request);

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);

            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CancelOrdersResponse>>()))
                .Returns(responseBuilder);

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            // act
            router.CancelOrders(new List<string> { "ibm_123", "aapl_456" });

            // assert

            Assert.That(order.OrderStatus, Is.EqualTo(BamOrderStatus.PendingCancel));
            Assert.That(generatedRequest.User, Is.EqualTo("MQI"));
        }


        [Test]
        public void VerifyOrderReplay()
        {
            // arrange
            // ReSharper disable NotAccessedVariable
            ReplayOrdersRequest generateRequest;
            // ReSharper restore NotAccessedVariable

            //status, filledQuantity, weightedAvgPrice
            var responseBuilder = new OrderUpdateResponse { OrderId = "123", Status = OrderStatus.TRADABLE, FilledQuantity = 0, WeightedAvgPrice = 0 };
            var responseBuilder2 = new OrderUpdateResponse { OrderId = "456", Status = OrderStatus.TRADABLE, FilledQuantity = 0, WeightedAvgPrice = 0 };

            //mocks/test data
            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);

            //in case they ever enrich this 
            flexOrderSvc.Setup(f => f.ReplayOrders(It.IsAny<ReplayOrdersRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<ReplayOrdersRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => generateRequest = request);

            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStream(It.IsAny<AsyncServerStreamingCall<OrderUpdateResponse>>()))
                .Returns(new[] { responseBuilder, responseBuilder2 });

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object, accountService, new Mock<ISecurityMasterService>().Object);

            // act
            IReadOnlyList<IOrder> orders;
            IReadOnlyList<IBlockTrade> trades;
            router.GetOpenOrders(out orders, out trades);

            // assert
            Assert.IsNotNull(orders);
            Assert.That(orders.Count, Is.EqualTo(2));
            Assert.That(orders.First().ClientOrderId, Is.EqualTo("123"));
        }

        [Test]
        public void VerifySubmitOrderWithComplianceIssue()
        {
            // arrange
            var order = CreateOrder(SideType.Buy);
            order.ClientOrderId = "123";

            Coverage coverage = new Coverage()
            {
                AssetType = AssetType.Equity,
                Currency = "USD",
                EzeId = "MQI",
                FlexId = "MQI",
            };
            var coverageService = new Mock<ReferenceDataGateway.Api.Http.ICoverageController>();
            coverageService.Setup(a => a.GetTraderCoverage(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<AssetType>())).Returns(coverage);

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get(It.IsAny<string>())).Returns((Order)order);

            var response = new CreateOrdersResponse();
            var status = new ResponseStatus { Success = true };
            response.Status = status;
            response.BatchId = "batch";

            var orderResult = new CreateOrderResult
            {
                SettleDate = new DateTime(2015, 10, 28).ToString("o"),
                Success = false,
                OrderId = "123"
            };
            // success, orderId, settleDate

            var complianceIssue = new ComplianceIssue
            {
                OrderId = "123",
                IssueType = ComplianceIssueType.FAILURE,
                Description = "RESTRICTED LIST ITEM",
                RuleName = "RESTRTICTED"
            };

            orderResult.ComplianceIssues.Add(complianceIssue);

            response.Results.Add(orderResult);

            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);

            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CreateOrdersResponse>>())).Returns(response);

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            //act
            var unit = router.SubmitOrders(new[] { order }).ToList();

            // assert
            Assert.That(unit.Count, Is.EqualTo(1));
            Assert.That(unit[0].ClientOrderId, Is.EqualTo("123"));
            Assert.That(unit[0].StatusMessages.Count, Is.EqualTo(1));

            int pos = unit[0].StatusMessages[0].IndexOf(":");
            Bam.Oms.Data.ComplianceIssue ci = JsonConvert.DeserializeObject<Bam.Oms.Data.ComplianceIssue>(unit[0].StatusMessages[0].Substring(pos + 1));
            Assert.That(ci.IssueType, Is.EqualTo(ComplianceIssueType.FAILURE.ToString()));
            Assert.That(ci.Description, Is.EqualTo("RESTRICTED LIST ITEM"));
            Assert.That(ci.RuleName, Is.EqualTo("RESTRTICTED"));
        }

        [Test]
        public void VerifySubmitOrderWithExecutionInstructions()
        {
            // arrange
            CreateOrdersRequest unit = null;
            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            Coverage coverage = new Coverage()
            {
                AssetType = AssetType.Equity,
                Currency = "USD",
                EzeId = "MQI",
                FlexId = "MQI",
            };
            var coverageService = new Mock<ReferenceDataGateway.Api.Http.ICoverageController>();
            coverageService.Setup(a => a.GetTraderCoverage(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<AssetType>())).Returns(coverage);

            var orderSvc = new Mock<IGrpcServices>();

            flexOrderSvc.Setup(f => f.CreateOrders(It.IsAny<CreateOrdersRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<CreateOrdersRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => unit = request);

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);


            var mapper = new Mock<IInstructionToEmsTagMapper>();
            mapper.Setup(r => r.GetTag(It.IsAny<string>())).Returns("9000");

            var router = new EmsRouter(orderSvc.Object, new Mock<IStreamParser>().Object, new Logger(), mapper.Object, accountService, new Mock<ISecurityMasterService>().Object);

            var order = CreateOrder(SideType.Buy); //side is irrelevant for this test
            order.ExecutionInstructions.Add(new ExecutionInstruction("vol", "0.2"));

            // act
            router.SubmitOrders(new[] { order });

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.Orders[0].FixTags, Is.EqualTo("9000=0.2"));
        }

        [Test]
        public void VerifySubmitOrderWithNoIssues()
        {
            // arrange
            var order = CreateOrder(SideType.Buy);
            order.ClientOrderId = "123";
            order.RoutedSize = order.Size;


            Coverage coverage = new Coverage()
            {
                AssetType = AssetType.Equity,
                Currency = "USD",
                EzeId = "MQI",
                FlexId = "MQI",
            };
            var coverageService = new Mock<ReferenceDataGateway.Api.Http.ICoverageController>();
            coverageService.Setup(a => a.GetTraderCoverage(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<AssetType>())).Returns(coverage);

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get(It.IsAny<string>())).Returns((Order)order);

            var response = new CreateOrdersResponse();
            var status = new ResponseStatus { Success = true };
            response.BatchId = "batch";
            response.Status = status;

            var orderResult = new CreateOrderResult
            {
                SettleDate = new DateTime(2015, 10, 28).ToString("o"),
                Success = true,
                OrderId = "123"
            };
            // success, orderId, settleDate

            response.Results.Add(orderResult);

            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);
            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CreateOrdersResponse>>())).Returns(response);

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            //act
            var unit = router.SubmitOrders(new[] { order }).ToList();

            // assert
            Assert.That(unit.Count, Is.EqualTo(1));
            Assert.That(unit[0].ClientOrderId, Is.EqualTo("123"));
            Assert.That(unit[0].OrderStatus, Is.EqualTo(BamOrderStatus.New));
            Assert.That(unit[0].RoutedSize, Is.EqualTo(100));
            Assert.AreEqual(unit[0].SettleDate, new DateTime(2015, 10, 28));
        }

        [Test]
        public void VerifyThatCancelOrdersRaiseTheOrderStatusChangedWithSuccessAndFailedCancelOrders()
        {
            // arrange
            CancelOrdersRequest generatedRequest = null;

            var responseBuilder = new CancelOrdersResponse { Status = new ResponseStatus { Success = true } };
            responseBuilder.Results.Add(new CancelOrderResult { OrderId = "ibm_123", Success = true });
            responseBuilder.Results.Add(new CancelOrderResult { OrderId = "aapl_456", Success = false });

            var flexOrderSvc = new Mock<OrderService.IOrderServiceClient>();

            var orderSvc = new Mock<IGrpcServices>();

            flexOrderSvc.Setup(f => f.CancelOrders(It.IsAny<CancelOrdersRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<CancelOrdersRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => generatedRequest = request);

            orderSvc.Setup(r => r.OrderServiceClient).Returns(flexOrderSvc.Object);


            var streamer = new Mock<IStreamParser>();
            streamer.Setup(r => r.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CancelOrdersResponse>>()))
                .Returns(responseBuilder);

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get(It.IsAny<string>())).Returns((Order)CreateOrder(SideType.Buy));

            var router = new EmsRouter(orderSvc.Object, streamer.Object, new Logger(), new Mock<IInstructionToEmsTagMapper>().Object,
                accountService, new Mock<ISecurityMasterService>().Object);

            // act
            var responseList = router.CancelOrders(new List<string> { "ibm_123", "aapl_456" });

            router.OrderStatusChanged += orders =>
            {
                var ordersList = orders as IList<IOrder> ?? orders.ToList();
                Assert.That(ordersList.Count, Is.EqualTo(2));

                var ibmOrder = ordersList.FirstOrDefault(o => o.ClientOrderId == "ibm_123");
                Assert.That(ibmOrder, Is.Not.Null);
                if (ibmOrder != null)
                    Assert.That(ibmOrder.StatusMessages.Count, Is.EqualTo(0));

                var appleOrder = ordersList.FirstOrDefault(o => o.ClientOrderId == "aapl_456");
                Assert.That(appleOrder, Is.Not.Null);
                if (appleOrder != null)
                    Assert.That(appleOrder.StatusMessages.Count, Is.EqualTo(1));
            };


            // assert
            Assert.IsNotNull(generatedRequest);
            Assert.That(generatedRequest.OrderIds.Count, Is.EqualTo(2));
            Assert.That(generatedRequest.OrderIds, Contains.Item("ibm_123"));
            Assert.That(generatedRequest.OrderIds, Contains.Item("aapl_456"));
            Assert.That(responseList.Count, Is.EqualTo(1));
            Assert.That(responseList, Contains.Item("ibm_123"));
            Assert.That(responseList, !Contains.Item("aapl_456"));
        }

        [Test]
        public void VerifyThatSubmitOrdersAddErrorToTheOrder()
        {
            // arrange
            var grpcServices = new Mock<IGrpcServices>();
            var streamParser = new Mock<IStreamParser>();
            var logger = new Mock<ILogger>();
            var instructionToFixMapper = new Mock<IInstructionToEmsTagMapper>();
            var orderServiceClient = new Mock<OrderService.IOrderServiceClient>();
            var asyncStreamReader = new Mock<IAsyncStreamReader<CreateOrdersResponse>>();

            var response = new CreateOrdersResponse
            {
                Status = new ResponseStatus { Success = false, Code = ResponseStatusCode.OPERATION_ABORTED, Description = "bad stuff happened" }
            };

            asyncStreamReader.Setup(a => a.Current).Returns(response);

            orderServiceClient.Setup(o => o.CreateOrders(It.IsAny<CreateOrdersRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()))
                .Callback<CreateOrdersRequest, Metadata, DateTime?, CancellationToken>((request, meta, dt, token) => { });

            grpcServices.SetupGet(g => g.OrderServiceClient).Returns(orderServiceClient.Object);

            streamParser.Setup(sp => sp.ParseStreamReturnFirst(It.IsAny<AsyncServerStreamingCall<CreateOrdersResponse>>())).Returns(response);

            var unit = new EmsRouter(grpcServices.Object, streamParser.Object, logger.Object, instructionToFixMapper.Object, this.accountService, new Mock<ISecurityMasterService>().Object);

            // act
            var order1 = GenerateMinOrder("clientOrderId1");
            var order2 = GenerateMinOrder("clientOrderId2");
            var result = unit.SubmitOrders(new[] { order1, order2 });

            // assert
            Assert.That(unit, Is.Not.Null);
            var resultList = result as IList<IOrder> ?? result.ToList();
            Assert.That(resultList.Count, Is.EqualTo(2));
            Assert.That(resultList.All(r => r.OrderStatus == BamOrderStatus.Error), Is.True);
            Assert.That(resultList.All(r => r.StatusMessages.Count == 1), Is.True);
            Assert.That(resultList.All(r => r.StatusMessages.All(e => e.Contains("bad stuff"))), Is.True);
        }
    }
}