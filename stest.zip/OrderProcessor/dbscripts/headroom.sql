USE [OrderGatewayMain]
GO

/****** Object:  Table [og].[EodHeadroom]    Script Date: 4/6/2017 9:14:07 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [og].[EodHeadroom](
	[RuleId] [int] NOT NULL,
	[Identifier] [varchar](50) NOT NULL,
	[BusinessDate] [date] NOT NULL,
	[RuleName] [varchar](50) NOT NULL,
	[IdentifierType] [varchar](50) NOT NULL,
	[IsExempt] [bit] NOT NULL,
	[Direction] [varchar](50) NOT NULL,
	[ReportingEntity] [varchar](50) NOT NULL,
	[Threshold] [decimal](18, 6) NOT NULL,
	[Headroom] [bigint] NOT NULL,
	[AlertLevel] [varchar](50) NOT NULL,
	[FireOnce] [bit] NOT NULL,
	[IntradayQuantity] [bigint] NOT NULL,
 CONSTRAINT [PK_EodHeadroom] PRIMARY KEY CLUSTERED 
(
	[RuleId] ASC,
	[Identifier] ASC,
	[BusinessDate] ASC,
	[Threshold] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE TABLE [og].[EodHeadroomRatio](
	[RuleId] [INT] NOT NULL,
	[AggregationUnit] [VARCHAR](50) NULL,
	[Ratio] [DECIMAL](18, 6) NULL,
	[BusinessDate] [DATETIME] NULL
) ON [PRIMARY]

SET ANSI_PADDING OFF
GO


