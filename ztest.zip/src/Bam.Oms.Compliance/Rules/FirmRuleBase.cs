﻿using Newtonsoft.Json;
using System;

using System.Collections.Generic;
using Bam.Oms.Compliance.Filters;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Filtering;
using Bam.Oms.Data.Securities;
using Bam.Oms.Compliance.DataProvider;
using BAM.Infrastructure.Ioc;
using BAM.Infrastructure.DataFlowLogging.Client;

namespace Bam.Oms.Compliance.Rules
{
    public class FirmRuleBase : Rule<CompliancePosition>
    {
        protected readonly ILogger _logger;
        protected readonly ILoggingAgent _eventLogger;
        protected readonly IFactProvider _factProvider;
        [JsonProperty]
        public IEnumerable<Parameter> FilterParams { get; set; }
        public Filter<ISecurity> SecurityFilter { get; set; }

        public FirmRuleBase(IFactProvider factProvider, ILogger logger, ILoggingAgent eventLogger)
        {
            _factProvider = factProvider;
            _logger = logger;
            _eventLogger = eventLogger;
        }
        /// <summary>
        /// popudate json and convert filter or compliance filter
        /// </summary>
        public virtual void Init()
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(ParamsInJson))
                {
                    JsonConvert.PopulateObject(ParamsInJson, this);
                }
                if (FilterParams != null)
                {
                    foreach (var p in FilterParams)
                    {
                        p.Operator = new ComplianceOperator(_factProvider) { OperatorType = p.Operator.OperatorType };
                    }
                    SecurityFilter = new Filter<ISecurity>();
                    SecurityFilter.AddToFilter(this.GetType().FullName, FilterParams);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"{Name}:{ex.Message}");
            }
           
        }
        protected void LogEvent(string resultKey, string context)
        {
#if DEBUG
#else
            var logEvent = new DataFlowEvent(EventCategory.Position, resultKey, BamSystem.COMPLIANCE, DateTime.Now, "Validate", null,  $"{ToString()}|{context}" , BamSystem.UNDEFINED);
            _eventLogger.SendSuccessEvent(logEvent);
#endif
        }
        protected void LogErrorEvent(string resultKey, string context)
        {
#if DEBUG
#else
            var logEvent = new DataFlowEvent(EventCategory.Position, resultKey, BamSystem.COMPLIANCE, DateTime.Now, "Validate", null, $"{ToString()}|{context}", BamSystem.UNDEFINED);
            _eventLogger.SendFailedEvent(logEvent);
#endif
        }

    }
}
