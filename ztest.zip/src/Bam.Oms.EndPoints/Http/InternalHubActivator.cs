using Microsoft.AspNet.SignalR.Hubs;

namespace Bam.Oms.EndPoints.Http
{
    /// <summary>
    /// Hub activator that uses the internal dependency injector
    /// </summary>
    public class InternalHubActivator : IHubActivator
    {
        private readonly System.Web.Http.Dependencies.IDependencyResolver container;

        public InternalHubActivator(System.Web.Http.Dependencies.IDependencyResolver container)
        {
            this.container = container;
        }

        public IHub Create(HubDescriptor descriptor)
        {
            return (IHub) container.GetService(descriptor.HubType);
        }
    }
}