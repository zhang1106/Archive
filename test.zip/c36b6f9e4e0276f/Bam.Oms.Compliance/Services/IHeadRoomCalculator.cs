﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Services
{
    public interface IHeadRoomCalculator
    {
        IEnumerable<HeadRoom> GetHeadRooms(IEnumerable<string> symbols, bool sod);
        IEnumerable<HeadRoom> GetNewHeadRooms(IEnumerable<string> symbols, bool dump);

        IEnumerable<HeadRoom> CheckEodPosition(string symbol);

        void RefreshRefData();
    }
}
