﻿using System;
using System.Configuration;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Data.Configuration
{
    public class Settings : ISettings
    {
        private readonly ILogger _logger;

        public Settings(ILogger logger)
        {
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            _logger = logger;
            Config();
        }

        public void Config()
        {
            try
            {
                BaseUrl = ConfigurationManager.AppSettings["base_url"];
                if (string.IsNullOrWhiteSpace(BaseUrl))
                {
                    BaseUrl = "localhost:9177";
                }

                BasePort = ConfigurationManager.AppSettings["base_port"];
                if (string.IsNullOrWhiteSpace(BasePort))
                {
                    BasePort = "8080";
                }

                var defaultSodTimeString = ConfigurationManager.AppSettings["SODTime"];
                SODDateTime = Utility.SetSodTime(defaultSodTimeString);

                HeadRoomFilePath = ConfigurationManager.AppSettings["HeadRoomFilePath"];
                if (string.IsNullOrWhiteSpace(HeadRoomFilePath))
                {
                    throw new ApplicationException("HeadRoomFilePath is required in the app.config.");
                }

                ConstituentsFilePath = ConfigurationManager.AppSettings["ConstituentsFilePath"];
                if (string.IsNullOrWhiteSpace(ConstituentsFilePath))
                {
                    throw new ApplicationException("ConstituentsFilePath is required in the app.config.");
                }

                DebugFilePath = ConfigurationManager.AppSettings["DebugFilePath"];
                if (string.IsNullOrWhiteSpace(DebugFilePath))
                {
                    throw new ApplicationException("DebugFilePath is required in the app.config.");
                }

                HeadRoomRuleName = ConfigurationManager.AppSettings["HeadRoomRuleName"];
                if (string.IsNullOrWhiteSpace(HeadRoomRuleName))
                {
                    HeadRoomRuleName = "*";
                }

                HeadRoomSymbol = ConfigurationManager.AppSettings["HeadRoomSymbol"];
                if (string.IsNullOrWhiteSpace(HeadRoomSymbol))
                {
                    HeadRoomRuleName = "*";
                }

                var headRoomRatioAQTF = ConfigurationManager.AppSettings["HeadRoomRatioAQTF"];
                if (string.IsNullOrWhiteSpace(headRoomRatioAQTF))
                {
                    headRoomRatioAQTF = "20";
                }
                HeadRoomRatioAQTF = int.Parse(headRoomRatioAQTF);

                var headRoomRatioMain = ConfigurationManager.AppSettings["headRoomRatioMain"];
                if (string.IsNullOrWhiteSpace(headRoomRatioMain))
                {
                    headRoomRatioMain = "80";
                }
                HeadRoomRatioMAIN = int.Parse(headRoomRatioMain);


                PomoUrl = ConfigurationManager.AppSettings["PomoUrl"];
                if (string.IsNullOrWhiteSpace(PomoUrl))
                {
                    throw new ApplicationException("PomoUrl is required in the app.config.");
                }

                PomoHoldingUrl = ConfigurationManager.AppSettings["PomoHoldingUrl"];
                if (string.IsNullOrWhiteSpace(PomoHoldingUrl))
                {
                    throw new ApplicationException("PomoHoldingUrl is required in the app.config.");
                }

                OrderGatewayConnectionString = ConfigurationManager.AppSettings["OrderGateway"];
                if (string.IsNullOrWhiteSpace(OrderGatewayConnectionString))
                {
                    throw new ApplicationException("Order Gateway connection string is required in the app.config.");
                }

                OrderGatewayMainConnectionString = ConfigurationManager.AppSettings["OrderGatewayMain"];
                if (string.IsNullOrWhiteSpace(OrderGatewayMainConnectionString))
                {
                    throw new ApplicationException("Order Gateway Main connection string is required in the app.config.");
                }

                BamCoreLiteConnectionString = ConfigurationManager.AppSettings["BamCoreLite"];
                if (string.IsNullOrWhiteSpace(BamCoreLiteConnectionString))
                {
                    throw new ApplicationException("BamCoreLite connection string is required in the app.config.");
                }

                //sod
                SodWatchPath = ConfigurationManager.AppSettings["SodWatchPath"];
                if (string.IsNullOrWhiteSpace(SodWatchPath))
                {
                    throw new ApplicationException("SodWatchPath is required in the app.config.");
                }

                SodArchivePath = ConfigurationManager.AppSettings["SodArchivePath"];
                if (string.IsNullOrWhiteSpace(SodWatchPath))
                {
                    throw new ApplicationException("SodArchivePath is required in the app.config.");
                }

                SodErrorPath = ConfigurationManager.AppSettings["SodErrorPath"];
                if (string.IsNullOrWhiteSpace(SodErrorPath))
                {
                    throw new ApplicationException("SodErrorPath is required in the app.config.");
                }

                MQConnectionString = ConfigurationManager.AppSettings["MQConnectionString"];
                if (string.IsNullOrWhiteSpace(MQConnectionString))
                {
                    throw new ApplicationException("MQConnectionString is required in the app.config.");
                }

                MQExchange = ConfigurationManager.AppSettings["MQExchange"];
                if (string.IsNullOrWhiteSpace(MQExchange))
                {
                    throw new ApplicationException("MQExchange is required in the app.config.");
                }

                BrokerServiceQueue = ConfigurationManager.AppSettings["BrokerServiceQueue"];
                if (string.IsNullOrWhiteSpace(BrokerServiceQueue))
                {
                    throw new ApplicationException("BrokerServiceQueue is required in the app.config.");
                }

                ComplianceStart = int.Parse(ConfigurationManager.AppSettings["compliance_start"]);

                ComplianceEnd = int.Parse(ConfigurationManager.AppSettings["compliance_end"]);

                ComplianceSpan = int.Parse(ConfigurationManager.AppSettings["compliance_span"]);

                DeployEnvironment = ConfigurationManager.AppSettings["DEPLOYMNT_ENV"];

                BbBatchSize = int.Parse(ConfigurationManager.AppSettings["BbBatchSize"]);

                EodStartTime = int.Parse(ConfigurationManager.AppSettings["EodStartTime"]);

                EodEndTime = int.Parse(ConfigurationManager.AppSettings["EodEndTime"]);

                WarningOnly =  string.Compare(ConfigurationManager.AppSettings["WarningOnly"], "true", StringComparison.InvariantCultureIgnoreCase)==0;

                SecurityRefreshRequency = int.Parse(ConfigurationManager.AppSettings["SecurityRefreshRequency"]);

                UseBloombBergData = string.Compare(ConfigurationManager.AppSettings["UseBloombBergData"], "true", StringComparison.InvariantCultureIgnoreCase) == 0;

                EnableSqlMonitoring = string.Compare(ConfigurationManager.AppSettings["EnableSqlMonitoring"], "true", StringComparison.InvariantCultureIgnoreCase) == 0;
            }
            catch (Exception ex)
            {
                _logger.Fatal($"Unable to perform settings initialization {ex.Message} {ex.StackTrace}");
            }
        }

        public virtual void Initialize()
        {
            Config();
        }

        public bool WarningOnly { get; set; }
        public int EodEndTime { get; set; }

        public int EodStartTime { get; set; }
        public int BbBatchSize { get; set; }
        public bool UseBloombBergData { get; set; }
        public string MQConnectionString { get; set; }
        public string MQExchange { get; set; }

        public string BaseUrl { get; set; }
        public string BasePort { get; set; }
        public string OrderGatewayConnectionString { get; set; }
        public string OrderGatewayMainConnectionString { get; set; }
        public string ContingencyConnectionString { get; set; }
        public string BamCoreLiteConnectionString { get; set; }
        public string HeadRoomFilePath { get; set; }
        public string HeadRoomRuleName { get; set; }
        public string HeadRoomSymbol { get; set; }
        public string PomoHoldingUrl { get; set; }
        public string PomoUrl { get; set; }
        public TimeSpan DefaultTokenExpiry => TimeSpan.FromDays(1);
        public bool AllowTokenAsUrlParameter => true;
        public string ConstituentsFilePath { get; set; }
        public string DebugFilePath { get; set; }
        public int HeadRoomRatioAQTF { get; set; }
        public int HeadRoomRatioMAIN { get; set; }

        public string SodWatchPath { get; set; }
        public string SodArchivePath { get; set; }
        public string SodErrorPath { get; set; }
        public DateTime SODDateTime { get; set; }
        public string BrokerServiceQueue { get; set; }
        public int ComplianceStart { get; set; }
        public int ComplianceEnd { get; set; }
        public int ComplianceSpan { get; set; }
        public string DeployEnvironment { get; set; }
        public int SecurityRefreshRequency { get; set; }
        public bool EnableSqlMonitoring { get; set; }
        public string FactTable => DeployEnvironment == "SOFT" ? "Fact2" : "Fact";
        public string PolicyTable => DeployEnvironment == "SOFT" ? "Policy2" : "Policy";
        public string RuleTable => DeployEnvironment == "SOFT" ? "Rule2" : "Rule";
        public string PolicyRuleTable => DeployEnvironment == "SOFT" ? "PolicyRule2" : "PolicyRule";
    }
}
