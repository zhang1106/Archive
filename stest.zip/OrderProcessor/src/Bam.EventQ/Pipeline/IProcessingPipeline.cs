﻿namespace Bam.EventQ.Pipeline
{
    public interface IProcessingPipeline
    {
        void Start();
        void Stop();
    }
}
