﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Dapper;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class DbPositionLookup : IDbPositionLookup
    {
        private readonly SqlConnection _connection;

        public DbPositionLookup(SqlConnection connection)
        {
            if (connection == null) throw new ArgumentNullException(nameof(connection));
            _connection = connection;
        }

        public IList<T> Get<T>(out DateTime businessDay)
        {
            businessDay = _connection.QueryFirstOrDefault<DateTime>("SELECT ISNULL(MAX(TradeDate), '1/1/1900') FROM [og].[EodPosition2]");
            if (businessDay.Year == 1900)
            {
                return new List<T>();
            }

            return _connection.Query<T>("SELECT * FROM [og].[EodPosition2] WHERE TradeDate = @TradeDate", 
                new { TradeDate = businessDay }).ToList();
        }
    }
}