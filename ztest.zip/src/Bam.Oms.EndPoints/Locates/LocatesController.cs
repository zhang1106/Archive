﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.RestApi;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.Orders;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.Locates
{
    public class LocatesController : BaseController, ILocatesController
    {
        private readonly IOrderNotifier _orderNotifier;

        public LocatesController(IHostConfiguration hostConfiguration, ILogger logger, IOrderNotifier orderNotifier) : base(hostConfiguration, logger)
        {
            if (orderNotifier == null) throw new ArgumentNullException(nameof(orderNotifier));
            _orderNotifier = orderNotifier;
        }

        public int PostLocateRequest(IList<string> orderIds)
        {
            _orderNotifier.NotifyLocateRequestReceived(orderIds); //since is async, we don't have much 
            return orderIds.Count;
        }
    }
}