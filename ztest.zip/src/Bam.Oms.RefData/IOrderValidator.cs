﻿using System.Collections.Generic;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.RefData
{
    public interface IOrderValidator
    {
        /// <summary>
        /// Takes a list of orders and returns whether or not that order are all validate (valid strategies/securities)
        /// </summary>
        /// <param name="orders"></param>
        /// <returns></returns>
        bool IsValidOrder(IList<IOrder> orders);
    }
}