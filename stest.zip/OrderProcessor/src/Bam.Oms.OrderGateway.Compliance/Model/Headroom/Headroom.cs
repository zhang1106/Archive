﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    [DebuggerDisplay("{Key.Identifier,nq} {IntradayQuantity}")]
    public class Headroom : ModelBase<IMessage>
    {
        public Headroom(HeadroomKey key, HeadroomDirection direction, bool isContingency, bool isExempt)
        {
            Key = key;
            Direction = direction;
            IsContingency = isContingency;
            IsExempt = isExempt;
            Thresholds = new List<HeadroomThreshold>();
            AggregationUnitRatios = new Dictionary<string, double>();
        }

        public HeadroomKey Key { get; }
        public HeadroomDirection Direction { get; }
        public long IntradayQuantity { get; private set; }
        public long MaxIntradayQuantity { get; private set; }
        public List<HeadroomThreshold> Thresholds { get; }
        public Dictionary<string, double> AggregationUnitRatios { get; }
        public bool IsContingency { get; }
        public bool IsExempt { get; }

        public void ApplyStartOfDay(List<HeadroomThreshold> thresholds, Dictionary<string, double> ratios)
        {
            Thresholds.Clear();
            Thresholds.AddRange(thresholds);
            Thresholds.Sort(HeadroomThresholdComparer.Instance);

            AggregationUnitRatios.Clear();
            ratios.CopyTo(AggregationUnitRatios);
        }

        public void AdjustRatios(Dictionary<string, double> ratios)
        {
            AggregationUnitRatios.Clear();
            ratios.CopyTo(AggregationUnitRatios);

            var msg = new OwnershipHeadroomRatiosAdjusted
            {
                RuleId = Key.RuleId,
                Identifier = Key.Identifier
            };

            AggregationUnitRatios.CopyTo(msg.Ratios);
            Publish(msg);
        }

        public void ApplyEffect(long effect)
        {
            if (effect == 0)
                return;

            IntradayQuantity += effect;
            MaxIntradayQuantity = Math.Min(MaxIntradayQuantity, IntradayQuantity);

            Publish(new OwnershipIntradayQuantityChanged
            {
                Items =
                {
                    new OwnershipIntradayQuantityChanged.Item()
                    {
                        RuleId = Key.RuleId,
                        Identifier = Key.Identifier,
                        Quantity = IntradayQuantity,
                        MaxQuantity = MaxIntradayQuantity
                    }
                }
            });
        }

        public void UpdateIntradayQuantities(long intraday, long maxIntraday)
        {
            IntradayQuantity = intraday;
            MaxIntradayQuantity = maxIntraday;
        }
        
        public bool WouldBreach(string aggUnit, long quantity, long currentOrderEffect, 
            decimal? suppressedThreshold, out HeadroomCheck result)
        {
            double ratio;
            if (!AggregationUnitRatios.TryGetValue(aggUnit, out ratio))
            {
                ratio = 0;
            }

            long intraday = IntradayQuantity - currentOrderEffect;
            long maximum = MaxIntradayQuantity - currentOrderEffect;
            long theoretical = intraday - quantity;

            result = new HeadroomCheck
            {
                IsContingency = IsContingency,
                IntradayQuantity = intraday
            };

            // the 99 % case
            if (Thresholds.Count == 0 || Thresholds[0].Quantity * ratio + theoretical > 0)
            {
                if (Thresholds.Count > 0)
                {
                    result.StartOfDayQuantity = (long) Math.Floor(Thresholds[0].Quantity * ratio);
                }
                return false;
            }

            int beforeIndex = -1, afterIndex = -1, maxIndex = -1, suppressedIndex = -1;
            for (int i = Thresholds.Count - 1; i >= 0; i--)
            {
                long qty = (long) Math.Floor(Thresholds[i].Quantity * ratio);

                if (beforeIndex == -1 && qty + intraday <= 0)
                {
                    beforeIndex = i;
                }

                if (afterIndex == -1 && qty + theoretical <= 0)
                {
                    afterIndex = i;
                }

                if (maxIndex == -1 && qty + maximum <= 0)
                {
                    maxIndex = i;
                }

                if (suppressedIndex == -1 && suppressedThreshold != null &&
                    Thresholds[i].Threshold == suppressedThreshold.Value)
                {
                    suppressedIndex = i;
                }

                if (afterIndex != -1 && beforeIndex != -1 && maxIndex != -1 &&
                    (suppressedThreshold == null || suppressedIndex != -1))
                    break;
            }

            int auditIndex = afterIndex;
            if (auditIndex + 1 < Thresholds.Count) auditIndex++;
            result.StartOfDayQuantity = (long)Math.Floor(Thresholds[auditIndex].Quantity * ratio);

            // we dropped a level on the ladder, no need to trigger anything
            if (afterIndex < beforeIndex)
            {
                return false;
            }

            // nothing is violated -> nothing to worry about
            if (afterIndex == -1)
            {
                return false;
            }

            // new order doesn't make things better nor does it make things worse
            if (afterIndex == beforeIndex)
            {
                // since we are already in the threshold that means somebody has
                // manually overridden the compliance rule before ... so we only
                // need to fire here if it's a fire always rule
                if (!Thresholds[afterIndex].FireOnce && afterIndex != suppressedIndex)
                {
                    result.ViolationLevel = Thresholds[afterIndex].ViolationLevel;
                    result.Threshold = Thresholds[afterIndex].Threshold;
                    return true;
                }
            }

            // the order brings us to a new level, so we def have to
            // trigger a compliance violation here ... unless we have already
            // been in this exact level and that level is fire once
            if (afterIndex > beforeIndex && afterIndex != suppressedIndex &&
                !(afterIndex == maxIndex && Thresholds[maxIndex].FireOnce))
            {
                result.ViolationLevel = Thresholds[afterIndex].ViolationLevel;
                result.Threshold = Thresholds[afterIndex].Threshold;
                return true;
            }

            // we should only get here for suppressed rules
            return false;
        }
    }
}
