﻿using System;
using System.Collections.Concurrent;
using System.Threading;

namespace Bam.EventQ.Diagnostics
{
    public class ConsoleTelemetry : ITelemetry
    {
        private int _nextIndex;
        private readonly ConcurrentDictionary<string, int> _keys;

        public ConsoleTelemetry()
        {
            _keys = new ConcurrentDictionary<string, int>();
        }

        public void Record<T>(string key, T value)
        {
            int row = _keys.GetOrAdd(key, _ => Interlocked.Increment(ref _nextIndex));
            lock (this)
            {
                Console.SetCursorPosition(0, row);
                Console.Write(new string(' ', Console.BufferWidth));
                Console.SetCursorPosition(0, row);
                Console.WriteLine("{0} = {1:N2}", key, value);
            }
        }
    }
}
