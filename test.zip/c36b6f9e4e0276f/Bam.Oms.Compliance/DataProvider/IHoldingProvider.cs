﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IHoldingProvider
    {
        //sod
        IList<IPosition> SodPositions { get; set; }
        IList<IPosition> DecomposedSodPositions { get; set; }
        ILookup<string, IPosition> DecomposedSodByIsin { get; set; }
        ILookup<string, IPosition> DecomposedSodByUnderlying { get; set; }
        ILookup<string, IPosition> SodByUnderlying { get; set; }
        ConcurrentDictionary<string, IList<IPosition>> SodPositionDictionary { get; set; }

        //intraday
        IList<IPosition> IntradayPositions { get; set; }
        IList<IPosition> DecomposedIntradayPositions { get; set; }
        ILookup<string, IPosition> DecomposedIntradayByIsin { get; set; }
        ILookup<string, IPosition> DecomposedIntradayByUnderlying { get; set; }
        ILookup<string, IPosition> IntradayByUnderlying { get; set; }

        //eod
        IList<IPosition> EodPositions { get; set; }
        IList<IPosition> DecomposedEodPositions { get; set; }
        ILookup<string, IPosition> DecomposedEodByIsin { get; set; }
        ILookup<string, IPosition> DecomposedEodByUnderlying { get; set; }
        ILookup<string, IPosition> EodByUnderlying { get; set; }

        void RefreshData(PositionType pType);
       
        void Update(IEnumerable<IPosition> position, PositionType pType);
       
        void PopuldateEodPositions(DateTime date);
        
        ILookup<string, IPosition> GetData(PositionType pType, PositionIndex pIndex);
        IEnumerable<string> GetUnderlyingSecurities(PositionType pType);
    }

}
