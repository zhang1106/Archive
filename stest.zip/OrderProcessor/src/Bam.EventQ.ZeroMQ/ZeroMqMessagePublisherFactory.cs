﻿using System.Collections.Generic;
using Bam.EventQ.Transport;

namespace Bam.EventQ.ZeroMQ
{
    public class ZeroMqMessagePublisherFactory : IMessagePublisherFactory
    {
        private readonly Dictionary<string, IMessagePublisher> _cache = 
            new Dictionary<string, IMessagePublisher>();

        public IMessagePublisher Create(string endpoint)
        {
            lock (_cache)
            {
                IMessagePublisher publisher;
                if (!_cache.TryGetValue(endpoint, out publisher))
                {
                    publisher = _cache[endpoint] = new ZeroMqMessagePublisher(endpoint);
                }

                return publisher;
            }
        }
    }
}
