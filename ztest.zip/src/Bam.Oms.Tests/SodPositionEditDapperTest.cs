using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.SodPosition.Svc;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using Bam.Oms.Persistence.DBContext;
using BAM.Infrastructure.Ioc;
using Bam.Oms.SodPosition.Svc.File;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Persistence.Positions;
using System.Configuration;
using Bam.Oms.RefData;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class SodPositionEditDapperTest
    {
        IList<SodAction> _actionRepository = null;

        IList<Position> _positionRepository = null;

        List<PositionAudit> _auditRepository = null;

        private DateTime _now;

        private DateTime _yesterday;


        public SodPositionEditDapperTest()
        {
            var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings.Remove("streams");
            config.AppSettings.Settings.Add("streams", "US;AS;EU");
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(config.AppSettings.SectionInformation.Name);
        }

        [SetUp]
        public void SetUp()
        {
            _now = DateTime.Now;
            _yesterday = _now.AddDays(-1);
            RefreshRepositories();
        }

        [Test]
        public void TestGetSodPositions()
        {
            var accountSvcMock = new Mock<IAccountService>();
            accountSvcMock.Setup(r => r.SetAccountAttributes(It.IsAny<IEnumerable<IContainsPortfolio>>())).Returns(_positionRepository);

            var mockedPositionRepo = new Mock<IPositionDBRepository>();
            mockedPositionRepo.Setup(x => x.GetPositions(It.IsAny<DateTime?>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(_positionRepository);
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepo.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, 
                dbContext, accountSvcMock.Object, new Mock<ISecurityMasterService>().Object);
            var pos = sEdit.GetSodPositions(null, null, null, null, null, null, null);
            Assert.IsTrue(pos.Count == _positionRepository.Count());
            foreach (var p in pos)
            {
                Assert.IsTrue(IsSamePosition(p, _positionRepository.First(x => x.PositionId == p.PositionId)));
            }
        }

        [Test]
        public void TestGetAudits()
        {
            var mockedAuditRepo = new Mock<IPositionAuditRepository>();
            mockedAuditRepo.Setup(x => x.Get(It.IsAny<object>())).Returns(_auditRepository);

            var dbContext = GetMockedDBContext(positionAuditRepository: mockedAuditRepo.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            var audits = sEdit.GetAudits(0, _now);
            var expected = _auditRepository;
            Assert.IsTrue(expected.Count() > 0);
            Assert.IsTrue(audits.Count == expected.Count());
            foreach (var audit in audits)
            {
                Assert.IsTrue(IsSameAuditInfo(audit, expected.Find(x => x.PositionAuditId == audit.PositionAuditId)));
            }
        }

        [Test]
        public void TestUpdatePositionForInsertion()
        {
            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionLog = new Mock<IActionLogRepository>();
            mockedActionLog.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });

            //Test insert
            var mockedPositionRepository = new Mock<IPositionDBRepository>();
            mockedPositionRepository.Setup(x => x.GetAll()).Returns(_positionRepository);
            int positionId = rnd.Next(int.MinValue, int.MaxValue);
            mockedPositionRepository.Setup(x => x.Save(It.IsAny<IEnumerable<Position>>()))
                .Returns<IEnumerable<Position>>(x =>
                {
                    IList<Position> positions = x.ToList();
                    positions.Single().PositionId = positionId;
                    return positions;
                });
            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.POSITION_UPDATE_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepository.Object,
                actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLog.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object );
            sEdit.Start();

            var positionToInsert = new Position
            {
                Security = new Security
                {
                    BamSymbol = "DAILMER",
                    Currency = "USD",
                    SecurityType = SecurityType.Equity
                },
                Price = 75.45M,
                CustodianName = "GOLDMAN",
                FXRate = 65.5M,
                ActualQuantity = 200.54M,
                Portfolio = (Portfolio)Portfolio.Parse("QIAN-GENERALIST"),
                Stream = "AS",
                FundCode = "Fund1",
                LastModifiedBy = "kishore",
                TheoreticalQuantity = 200.54M
            };
            var insertedPosition = sEdit.UpdatePosition(positionToInsert);
            Assert.AreEqual(insertedPosition.PositionId, positionId);
            Assert.GreaterOrEqual(insertedPosition.CreatedOn, _now);
            Assert.LessOrEqual(insertedPosition.CreatedOn, DateTime.Now);
            Assert.AreEqual(insertedPosition.ActionLogId, actLogId);
            Assert.AreEqual(insertedPosition.AuditSequence, 1);
            Assert.GreaterOrEqual(insertedPosition.LastModifiedOn, _now);
            Assert.LessOrEqual(insertedPosition.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(insertedPosition.EntryDate, _yesterday.Date);
            Assert.AreEqual(insertedPosition.Security.BamSymbol, "DAILMER");
            Assert.AreEqual(insertedPosition.Security.Currency, "USD");
            Assert.AreEqual(insertedPosition.Security.SecurityType, SecurityType.Equity);
            Assert.AreEqual(insertedPosition.Price, 75.45M);
            Assert.AreEqual(insertedPosition.CustodianName, "GOLDMAN");
            Assert.AreEqual(insertedPosition.FXRate, 65.5M);
            Assert.AreEqual(insertedPosition.ActualQuantity, 200.54M);
            Assert.AreEqual(insertedPosition.Portfolio, Portfolio.Parse("QIAN-GENERALIST"));
            Assert.AreEqual(insertedPosition.Stream, "AS");
            Assert.AreEqual(insertedPosition.FundCode, "Fund1");
            Assert.AreEqual(insertedPosition.LastModifiedBy, "kishore");
            Assert.AreEqual(insertedPosition.TheoreticalQuantity, 200.54M);
        }

        [Test]
        public void TestUpdatePositionForInsertWithQty0()
        {
            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionLog = new Mock<IActionLogRepository>();
            mockedActionLog.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });

            //Test insert
            var mockedPositionRepository = new Mock<IPositionDBRepository>();
            mockedPositionRepository.Setup(x => x.GetAll()).Returns(_positionRepository);
            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.POSITION_UPDATE_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepository.Object,
                actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLog.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();

            var positionToInsert = new Position
            {
                Security = new Security { BamSymbol = "ARC", Currency = "INR", SecurityType = SecurityType.EquitySwap },
                Price = 11M,
                CustodianName = "DB",
                FXRate = 14.75M,
                ActualQuantity = 15M,
                Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"),
                Stream = "EU",
                FundCode = "Fund2",
                LastModifiedBy = "CORP\\kishore",
                TheoreticalQuantity = 15M
            };
            var insertedPosition = sEdit.UpdatePosition(positionToInsert);
            // The updatedPosition is the one which gets updated
            var updatedPosition = _positionRepository.Single(x => x.PositionId == 5);
            Assert.AreEqual(insertedPosition.PositionId, updatedPosition.PositionId);
            Assert.AreEqual(insertedPosition.CreatedOn, updatedPosition.CreatedOn);
            Assert.AreEqual(insertedPosition.ActionLogId, actLogId);
            Assert.AreEqual(insertedPosition.AuditSequence, updatedPosition.AuditSequence + 1);
            Assert.GreaterOrEqual(insertedPosition.LastModifiedOn, _now);
            Assert.LessOrEqual(insertedPosition.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(insertedPosition.EntryDate, updatedPosition.EntryDate);
            Assert.AreEqual(insertedPosition.Security.BamSymbol, updatedPosition.Security.BamSymbol);
            Assert.AreEqual(insertedPosition.Security.Currency, "INR");
            Assert.AreEqual(insertedPosition.Security.SecurityType, updatedPosition.Security.SecurityType);
            Assert.AreEqual(insertedPosition.Price, 11M);
            Assert.AreEqual(insertedPosition.CustodianName, updatedPosition.CustodianName);
            Assert.AreEqual(insertedPosition.FXRate, 14.75M);
            Assert.AreEqual(insertedPosition.ActualQuantity, 15M);
            Assert.AreEqual(insertedPosition.Portfolio, updatedPosition.Portfolio);
            Assert.AreEqual(insertedPosition.Stream, "EU");
            Assert.AreEqual(insertedPosition.FundCode, updatedPosition.FundCode);
            Assert.AreEqual(insertedPosition.LastModifiedBy, updatedPosition.LastModifiedBy);
            Assert.AreEqual(insertedPosition.TheoreticalQuantity, 15M);
        }

        [Test]
        public void TestUpdatePositionForUpdate()
        {
            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionLog = new Mock<IActionLogRepository>();
            mockedActionLog.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });

            //Test insert
            var mockedPositionRepository = new Mock<IPositionDBRepository>();
            mockedPositionRepository.Setup(x => x.GetAll()).Returns(_positionRepository);
            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.POSITION_UPDATE_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepository.Object,
                actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLog.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();

            var positionToUpdate = new Position
            {
                PositionId = 4,
                Security = new Security { BamSymbol = "DELL", Currency = "USD", SecurityType = SecurityType.EquitySwap },
                Price = 21.45M,
                EntryDate = _yesterday.Date, // This won't be honored
                CustodianName = "GM",
                FXRate = 12.75M,
                ActualQuantity = 21.54M,
                Portfolio = (Portfolio)Portfolio.Parse("Luke-Skywalker"),
                Stream = "AS",
                FundCode = "Fund3",
                AuditSequence = 4,
                LastModifiedBy = "CORP\\Devinder",
                TheoreticalQuantity = 21.54M
            };
            var updatedPosition = sEdit.UpdatePosition(positionToUpdate);
            // The updatedPosition is the one which gets updated
            var existingPosition = _positionRepository.Single(x => x.PositionId == 4);
            Assert.AreEqual(updatedPosition.PositionId, existingPosition.PositionId);
            Assert.AreEqual(updatedPosition.CreatedOn, existingPosition.CreatedOn);
            Assert.AreEqual(updatedPosition.ActionLogId, actLogId);
            Assert.AreEqual(updatedPosition.AuditSequence, existingPosition.AuditSequence + 1);
            Assert.GreaterOrEqual(updatedPosition.LastModifiedOn, _now);
            Assert.LessOrEqual(updatedPosition.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(updatedPosition.EntryDate, existingPosition.EntryDate);
            Assert.AreEqual(updatedPosition.Security.BamSymbol, positionToUpdate.Security.BamSymbol);
            Assert.AreEqual(updatedPosition.Security.Currency, positionToUpdate.Security.Currency);
            Assert.AreEqual(updatedPosition.Security.SecurityType, positionToUpdate.Security.SecurityType);
            Assert.AreEqual(updatedPosition.Price, positionToUpdate.Price);
            Assert.AreEqual(updatedPosition.CustodianName, positionToUpdate.CustodianName);
            Assert.AreEqual(updatedPosition.FXRate, positionToUpdate.FXRate);
            Assert.AreEqual(updatedPosition.ActualQuantity, positionToUpdate.ActualQuantity);
            Assert.AreEqual(updatedPosition.Portfolio, positionToUpdate.Portfolio);
            Assert.AreEqual(updatedPosition.Stream, positionToUpdate.Stream);
            Assert.AreEqual(updatedPosition.FundCode, positionToUpdate.FundCode);
            Assert.AreEqual(updatedPosition.LastModifiedBy, positionToUpdate.LastModifiedBy);
            Assert.AreEqual(updatedPosition.TheoreticalQuantity, positionToUpdate.TheoreticalQuantity);
        }


        [Test]
        public void TestUpdatePositionForConcurrencyException()
        {
            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionLog = new Mock<IActionLogRepository>();
            mockedActionLog.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });

            var mockedPositionRepository = new Mock<IPositionDBRepository>();
            mockedPositionRepository.Setup(x => x.GetAll()).Returns(_positionRepository);
            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.POSITION_UPDATE_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepository.Object,
                actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLog.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();

            var positionToUpdate = new Position
            {
                PositionId = 4,
                Security = new Security { BamSymbol = "DELL", Currency = "USD", SecurityType = SecurityType.EquitySwap },
                Price = 21.45M,
                EntryDate = _yesterday.Date,
                CustodianName = "GM",
                FXRate = 12.75M,
                ActualQuantity = 21.54M,
                Portfolio = (Portfolio)Portfolio.Parse("Luke-Skywalker"),
                Stream = "AS",
                FundCode = "Fund3",
                AuditSequence = 3,
                LastModifiedBy = "CORP\\Devinder",
                TheoreticalQuantity = 21.54M
            };
            Assert.Throws<Exception>(() => sEdit.UpdatePosition(positionToUpdate));
        }

        [Test]
        public void TestBulkUpdatePosition()
        {
            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionLog = new Mock<IActionLogRepository>();
            mockedActionLog.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });
            var mockedPositionRepository = new Mock<IPositionDBRepository>();
            mockedPositionRepository.Setup(x => x.GetAll()).Returns(_positionRepository);
            
            var positionIds = new List<int>();
            
            mockedPositionRepository.Setup(x => x.Save(It.IsAny<IEnumerable<Position>>()))
                .Returns<IEnumerable<Position>>(x =>
                {
                    IList<Position> positions = x.ToList();
                    foreach (var position in positions)
                    {
                        int positionId = rnd.Next(int.MinValue, int.MaxValue);
                        positionIds.Add(positionId);
                        position.PositionId = positionId;
                    }
                    return positions;
                });
             
            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.POSITION_BULK_UPDATE_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepository.Object,
                actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLog.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();

            var positionToUpdate1 = new Position
            {
                Security = new Security
                {
                    BamSymbol = "DAILMER",
                    Currency = "USD",
                    SecurityType = SecurityType.Equity
                },
                Price = 75.45M,
                CustodianName = "GOLDMAN",
                FXRate = 65.5M,
                ActualQuantity = 200.54M,
                Portfolio = (Portfolio)Portfolio.Parse("QIAN-GENERALIST"),
                Stream = "AS",
                FundCode = "Fund1",
                LastModifiedBy = "kishore",
                TheoreticalQuantity = 200.54M
            };

            var positionToInsert2 = new Position
            {
                Security = new Security { BamSymbol = "ARC", Currency = "INR", SecurityType = SecurityType.EquitySwap },
                Price = 11M,
                CustodianName = "DB",
                FXRate = 14.75M,
                ActualQuantity = 15M,
                Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"),
                Stream = "EU",
                FundCode = "Fund2",
                LastModifiedBy = "CORP\\kishore",
                TheoreticalQuantity = 15M
            };


            var positionToUpdate3 = new Position
            {
                PositionId = 4,
                Security = new Security { BamSymbol = "DELL", Currency = "USD", SecurityType = SecurityType.EquitySwap },
                Price = 21.45M,
                EntryDate = _yesterday.Date, // This won't be honored
                CustodianName = "GM",
                FXRate = 12.75M,
                ActualQuantity = 21.54M,
                Portfolio = (Portfolio)Portfolio.Parse("Luke-Skywalker"),
                Stream = "AS",
                FundCode = "Fund3",
                AuditSequence = 4,
                LastModifiedBy = "CORP\\Devinder",
                TheoreticalQuantity = 21.54M
            };

            var positionsToUpdate = new List<Position>{
                positionToUpdate1, positionToInsert2, positionToUpdate3
            };

            var updatedPositions = sEdit.BulkUpdatePosition(positionsToUpdate);
            
            Assert.IsTrue(positionIds.Contains(positionToUpdate1.PositionId));
            var insertedPosition = updatedPositions.FirstOrDefault(x => positionIds.Contains(x.PositionId));
            var updatedPosition2 = updatedPositions.FirstOrDefault(x => x.PositionId == 5);
            var updatedPosition3 = updatedPositions.FirstOrDefault(x => x.PositionId == 4);
            Assert.IsTrue(insertedPosition != null && updatedPosition2 != null && updatedPosition3 != null);

            Assert.GreaterOrEqual(insertedPosition.CreatedOn, _now);
            Assert.LessOrEqual(insertedPosition.CreatedOn, DateTime.Now);
            Assert.AreEqual(insertedPosition.ActionLogId, actLogId);
            Assert.AreEqual(insertedPosition.AuditSequence, 1);
            Assert.GreaterOrEqual(insertedPosition.LastModifiedOn, _now);
            Assert.LessOrEqual(insertedPosition.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(insertedPosition.EntryDate, _yesterday.Date);
            Assert.AreEqual(insertedPosition.Security.BamSymbol, "DAILMER");
            Assert.AreEqual(insertedPosition.Security.Currency, "USD");
            Assert.AreEqual(insertedPosition.Security.SecurityType, SecurityType.Equity);
            Assert.AreEqual(insertedPosition.Price, 75.45M);
            Assert.AreEqual(insertedPosition.CustodianName, "GOLDMAN");
            Assert.AreEqual(insertedPosition.FXRate, 65.5M);
            Assert.AreEqual(insertedPosition.ActualQuantity, 200.54M);
            Assert.AreEqual(insertedPosition.Portfolio, Portfolio.Parse("QIAN-GENERALIST"));
            Assert.AreEqual(insertedPosition.Stream, "AS");
            Assert.AreEqual(insertedPosition.FundCode, "Fund1");
            Assert.AreEqual(insertedPosition.LastModifiedBy, "kishore");
            Assert.AreEqual(insertedPosition.TheoreticalQuantity, 200.54M);
            
            // The updatedPosition is the one which gets updated
            var updatedPosition = _positionRepository.Single(x => x.PositionId == 5);
            Assert.AreEqual(updatedPosition2.PositionId, updatedPosition.PositionId);
            Assert.AreEqual(updatedPosition2.CreatedOn, updatedPosition.CreatedOn);
            Assert.AreEqual(updatedPosition2.ActionLogId, actLogId);
            Assert.AreEqual(updatedPosition2.AuditSequence, updatedPosition.AuditSequence + 1);
            Assert.GreaterOrEqual(updatedPosition2.LastModifiedOn, _now);
            Assert.LessOrEqual(updatedPosition2.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(updatedPosition2.EntryDate, updatedPosition.EntryDate);
            Assert.AreEqual(updatedPosition2.Security.BamSymbol, updatedPosition.Security.BamSymbol);
            Assert.AreEqual(updatedPosition2.Security.Currency, "INR");
            Assert.AreEqual(updatedPosition2.Security.SecurityType, updatedPosition.Security.SecurityType);
            Assert.AreEqual(updatedPosition2.Price, 11M);
            Assert.AreEqual(updatedPosition2.CustodianName, updatedPosition.CustodianName);
            Assert.AreEqual(updatedPosition2.FXRate, 14.75M);
            Assert.AreEqual(updatedPosition2.ActualQuantity, 15M);
            Assert.AreEqual(updatedPosition2.Portfolio, updatedPosition.Portfolio);
            Assert.AreEqual(updatedPosition2.Stream, "EU");
            Assert.AreEqual(updatedPosition2.FundCode, updatedPosition.FundCode);
            Assert.AreEqual(updatedPosition2.LastModifiedBy, updatedPosition.LastModifiedBy);
            Assert.AreEqual(updatedPosition2.TheoreticalQuantity, 15M);
            
            // The updatedPosition is the one which gets updated
            var existingPosition = _positionRepository.Single(x => x.PositionId == 4);
            Assert.AreEqual(updatedPosition3.PositionId, existingPosition.PositionId);
            Assert.AreEqual(updatedPosition3.CreatedOn, existingPosition.CreatedOn);
            Assert.AreEqual(updatedPosition3.ActionLogId, actLogId);
            Assert.AreEqual(updatedPosition3.AuditSequence, existingPosition.AuditSequence + 1);
            Assert.GreaterOrEqual(updatedPosition3.LastModifiedOn, _now);
            Assert.LessOrEqual(updatedPosition3.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(updatedPosition3.EntryDate, existingPosition.EntryDate);
            Assert.AreEqual(updatedPosition3.Security.BamSymbol, positionToUpdate3.Security.BamSymbol);
            Assert.AreEqual(updatedPosition3.Security.Currency, positionToUpdate3.Security.Currency);
            Assert.AreEqual(updatedPosition3.Security.SecurityType, positionToUpdate3.Security.SecurityType);
            Assert.AreEqual(updatedPosition3.Price, positionToUpdate3.Price);
            Assert.AreEqual(updatedPosition3.CustodianName, positionToUpdate3.CustodianName);
            Assert.AreEqual(updatedPosition3.FXRate, positionToUpdate3.FXRate);
            Assert.AreEqual(updatedPosition3.ActualQuantity, positionToUpdate3.ActualQuantity);
            Assert.AreEqual(updatedPosition3.Portfolio, positionToUpdate3.Portfolio);
            Assert.AreEqual(updatedPosition3.Stream, positionToUpdate3.Stream);
            Assert.AreEqual(updatedPosition3.FundCode, positionToUpdate3.FundCode);
            Assert.AreEqual(updatedPosition3.LastModifiedBy, positionToUpdate3.LastModifiedBy);
            Assert.AreEqual(updatedPosition3.TheoreticalQuantity, positionToUpdate3.TheoreticalQuantity);
        }

        [Test]
        public void TestInsertPosition()
        {
            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionLog = new Mock<IActionLogRepository>();
            mockedActionLog.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });

            //Test insert
            var mockedPositionRepository = new Mock<IPositionDBRepository>();
            mockedPositionRepository.Setup(x => x.GetAll()).Returns(_positionRepository);
            int positionId = rnd.Next(int.MinValue, int.MaxValue);
            mockedPositionRepository.Setup(x => x.Save(It.IsAny<IEnumerable<Position>>()))
                .Returns<IEnumerable<Position>>(x =>
                {
                    IList<Position> positions = x.ToList();
                    positions.Single().PositionId = positionId;
                    return positions;
                });
            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.POSITION_UPDATE_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepository.Object,
                actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLog.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();

            var positionToInsert = new Position
            {
                Security = new Security
                {
                    BamSymbol = "DAILMER",
                    Currency = "USD",
                    SecurityType = SecurityType.Equity
                },
                Price = 75.45M,
                CustodianName = "GOLDMAN",
                FXRate = 65.5M,
                ActualQuantity = 200.54M,
                Portfolio = (Portfolio)Portfolio.Parse("QIAN-GENERALIST"),
                Stream = "AS",
                FundCode = "Fund1",
                LastModifiedBy = "kishore",
                TheoreticalQuantity = 200.54M
            };
            var insertedPosition = sEdit.InsertPosition(positionToInsert);
            Assert.AreEqual(insertedPosition.PositionId, positionId);
            Assert.GreaterOrEqual(insertedPosition.CreatedOn, _now);
            Assert.LessOrEqual(insertedPosition.CreatedOn, DateTime.Now);
            Assert.AreEqual(insertedPosition.ActionLogId, actLogId);
            Assert.AreEqual(insertedPosition.AuditSequence, 1);
            Assert.GreaterOrEqual(insertedPosition.LastModifiedOn, _now);
            Assert.LessOrEqual(insertedPosition.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(insertedPosition.EntryDate, _yesterday.Date);
            Assert.AreEqual(insertedPosition.Security.BamSymbol, "DAILMER");
            Assert.AreEqual(insertedPosition.Security.Currency, "USD");
            Assert.AreEqual(insertedPosition.Security.SecurityType, SecurityType.Equity);
            Assert.AreEqual(insertedPosition.Price, 75.45M);
            Assert.AreEqual(insertedPosition.CustodianName, "GOLDMAN");
            Assert.AreEqual(insertedPosition.FXRate, 65.5M);
            Assert.AreEqual(insertedPosition.ActualQuantity, 200.54M);
            Assert.AreEqual(insertedPosition.Portfolio, Portfolio.Parse("QIAN-GENERALIST"));
            Assert.AreEqual(insertedPosition.Stream, "AS");
            Assert.AreEqual(insertedPosition.FundCode, "Fund1");
            Assert.AreEqual(insertedPosition.LastModifiedBy, "kishore");
            Assert.AreEqual(insertedPosition.TheoreticalQuantity, 200.54M);
        }

        [Test]
        public void TestBulkInsertPosition()
        {
            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionLog = new Mock<IActionLogRepository>();
            mockedActionLog.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });
            var mockedPositionRepository = new Mock<IPositionDBRepository>();
            mockedPositionRepository.Setup(x => x.GetAll()).Returns(_positionRepository);

            var positionIds = new List<int>();

            mockedPositionRepository.Setup(x => x.Save(It.IsAny<IEnumerable<Position>>()))
                .Returns<IEnumerable<Position>>(x =>
                {
                    IList<Position> positions = x.ToList();
                    foreach (var position in positions)
                    {
                        int positionId = rnd.Next(int.MinValue, int.MaxValue);
                        positionIds.Add(positionId);
                        position.PositionId = positionId;
                    }
                    return positions;
                });

            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.POSITION_BULK_UPDATE_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepository.Object,
                actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLog.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();

            var positionToInsert1 = new Position
            {
                Security = new Security
                {
                    BamSymbol = "DAILMER",
                    Currency = "USD",
                    SecurityType = SecurityType.Equity
                },
                Price = 75.45M,
                CustodianName = "GOLDMAN",
                FXRate = 65.5M,
                ActualQuantity = 200.54M,
                Portfolio = (Portfolio)Portfolio.Parse("QIAN-GENERALIST"),
                Stream = "AS",
                FundCode = "Fund1",
                LastModifiedBy = "kishore",
                TheoreticalQuantity = 200.54M
            };

            var positionToInsert2 = new Position
            {
                Security = new Security { BamSymbol = "ARC", Currency = "INR", SecurityType = SecurityType.EquitySwap },
                Price = 11M,
                CustodianName = "DBS",
                FXRate = 14.75M,
                ActualQuantity = 15M,
                Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"),
                Stream = "EU",
                FundCode = "Fund2",
                LastModifiedBy = "CORP\\kishore",
                TheoreticalQuantity = 15M
            };

            var positionsToInsert = new List<Position>{
                positionToInsert1, positionToInsert2
            };

            var insertedPositions = sEdit.BulkInsertPosition(positionsToInsert);

            Assert.IsTrue(positionIds.Contains(positionToInsert1.PositionId));
            Assert.IsTrue(positionIds.Contains(positionToInsert2.PositionId));
            Assert.IsTrue(insertedPositions != null && insertedPositions.Count == 2);

            Assert.GreaterOrEqual(positionToInsert1.CreatedOn, _now);
            Assert.LessOrEqual(positionToInsert1.CreatedOn, DateTime.Now);
            Assert.AreEqual(positionToInsert1.ActionLogId, actLogId);
            Assert.AreEqual(positionToInsert1.AuditSequence, 1);
            Assert.GreaterOrEqual(positionToInsert1.LastModifiedOn, _now);
            Assert.LessOrEqual(positionToInsert1.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(positionToInsert1.EntryDate, _yesterday.Date);
            Assert.AreEqual(positionToInsert1.Security.BamSymbol, "DAILMER");
            Assert.AreEqual(positionToInsert1.Security.Currency, "USD");
            Assert.AreEqual(positionToInsert1.Security.SecurityType, SecurityType.Equity);
            Assert.AreEqual(positionToInsert1.Price, 75.45M);
            Assert.AreEqual(positionToInsert1.CustodianName, "GOLDMAN");
            Assert.AreEqual(positionToInsert1.FXRate, 65.5M);
            Assert.AreEqual(positionToInsert1.ActualQuantity, 200.54M);
            Assert.AreEqual(positionToInsert1.Portfolio, Portfolio.Parse("QIAN-GENERALIST"));
            Assert.AreEqual(positionToInsert1.Stream, "AS");
            Assert.AreEqual(positionToInsert1.FundCode, "Fund1");
            Assert.AreEqual(positionToInsert1.LastModifiedBy, "kishore");
            Assert.AreEqual(positionToInsert1.TheoreticalQuantity, 200.54M);

            Assert.GreaterOrEqual(positionToInsert2.CreatedOn, _now);
            Assert.LessOrEqual(positionToInsert2.CreatedOn, DateTime.Now);
            Assert.AreEqual(positionToInsert2.ActionLogId, actLogId);
            Assert.AreEqual(positionToInsert2.AuditSequence, 1);
            Assert.GreaterOrEqual(positionToInsert2.LastModifiedOn, _now);
            Assert.LessOrEqual(positionToInsert2.LastModifiedOn, DateTime.Now);
            Assert.AreEqual(positionToInsert2.EntryDate, _now.Date);
            Assert.AreEqual(positionToInsert2.Security.BamSymbol, "ARC");
            Assert.AreEqual(positionToInsert2.Security.Currency, "INR");
            Assert.AreEqual(positionToInsert2.Security.SecurityType, SecurityType.EquitySwap);
            Assert.AreEqual(positionToInsert2.Price, 11M);
            Assert.AreEqual(positionToInsert2.CustodianName, "DBS");
            Assert.AreEqual(positionToInsert2.FXRate, 14.75M);
            Assert.AreEqual(positionToInsert2.ActualQuantity, 15M);
            Assert.AreEqual(positionToInsert2.Portfolio, Portfolio.Parse("Darth-Vader"));
            Assert.AreEqual(positionToInsert2.Stream, "EU");
            Assert.AreEqual(positionToInsert2.FundCode, "Fund2");
            Assert.AreEqual(positionToInsert2.LastModifiedBy, "CORP\\kishore");
            Assert.AreEqual(positionToInsert2.TheoreticalQuantity, 15M);
        }

        [Test]
        public void TestGetUndoChanges()
        {
            var mockedPositionRepo = new Mock<IPositionDBRepository>();
            mockedPositionRepo.Setup(x => x.GetById(It.IsAny<int>())).Returns<int>(x => _positionRepository.Single(t => t.PositionId == x));
            mockedPositionRepo.Setup(x => x.Get(It.IsAny<object>())).Returns<object>(x => _positionRepository.Where(t => t.ActionLogId == ((dynamic)x).ActionLogId));
            var mockedPositionAuditRepo = new Mock<IPositionAuditRepository>();
            mockedPositionAuditRepo.Setup(x => x.Get(It.IsAny<object>())).Returns<object>(
                x => _auditRepository.Where(t => t.Position.ActionLogId == ((dynamic)x).ActionLogId));
            mockedPositionAuditRepo.Setup(x => x.GetOlderAudits(It.IsAny<int>())).Returns<int>(
                x =>
                {
                    var positions = _positionRepository.Where(t => t.ActionLogId == x);
                    var _audits = from pos in _positionRepository
                                  join audit in _auditRepository
                                  on pos.PositionId equals audit.Position.PositionId
                                  where pos.ActionLogId == x
                                  && pos.AuditSequence == audit.Position.AuditSequence + 1
                                  select audit;
                    return _audits.ToList();
                }
                );
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepo.Object, positionAuditRepository: mockedPositionAuditRepo.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            var undoChanges = sEdit.GetUndoChanges(2);
            IList<Position> expectedPositions = new List<Position>{
                new Position { PositionId = 4, Security = new Security { BamSymbol = "IBM", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 12.5M, EntryDate = _now.Date, CustodianName = "DB", FXRate = 1M, ActualQuantity = 55.24M, Portfolio = (Portfolio)Portfolio.Parse("Princess-Leia"), Stream = "US", FundCode = "Fund3", CreatedOn = _now, ActionLogId = 33, AuditSequence = 4, LastModifiedOn = _now, LastModifiedBy = "CORP\\kishore", TheoreticalQuantity = 55.24M},
                new Position { PositionId = 2, Security = new Security { BamSymbol = "GOOGLE", Currency = "INR", SecurityType = SecurityType.Equity }, Price = 12.3M, EntryDate = _now.Date, CustodianName = "DB", FXRate = 1M, ActualQuantity = 13.5M, Portfolio = (Portfolio)Portfolio.Parse("Luke-Skywalker"), Stream = "US", FundCode = "Fund3", CreatedOn = _now, ActionLogId = 12, AuditSequence = 5, LastModifiedOn = _now, LastModifiedBy = "kishore", TheoreticalQuantity = 13.5M},
                new Position { PositionId= 6, Security=new Security {BamSymbol = "FORD", Currency="GBP", SecurityType = SecurityType.Equity }, Price = 0M, EntryDate=_now.Date, CustodianName="KOTAK", FXRate=1.75M, ActualQuantity=0M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=36, AuditSequence=1, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 0M}
            };

            Assert.AreEqual(undoChanges.Count, expectedPositions.Count);
            foreach (var p in undoChanges)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }


        [Test]
        public void TestExecuteUndo()
        {
            var mockedPositionRepo = new Mock<IPositionDBRepository>();
            mockedPositionRepo.Setup(x => x.GetById(It.IsAny<int>())).Returns<int>(x => { RefreshRepositories(); return _positionRepository.Single(t => t.PositionId == x); });
            mockedPositionRepo.Setup(x => x.Get(It.IsAny<object>())).Returns<object>(x => {RefreshRepositories(); return _positionRepository.Where(t => t.ActionLogId == ((dynamic)x).ActionLogId);});
            mockedPositionRepo.Setup(x => x.GetAll()).Returns(() => { RefreshRepositories(); return _positionRepository; });
            var mockedPositionAuditRepo = new Mock<IPositionAuditRepository>();
            mockedPositionAuditRepo.Setup(x => x.Get(It.IsAny<object>())).Returns<object>(
                x => _auditRepository.Where(t => t.Position.ActionLogId == ((dynamic)x).ActionLogId));
            mockedPositionAuditRepo.Setup(x => x.GetOlderAudits(It.IsAny<int>())).Returns<int>(
                x =>
                {
                    var positions = _positionRepository.Where(t => t.ActionLogId == x);
                    var _audits = from pos in _positionRepository
                                  join audit in _auditRepository
                                  on pos.PositionId equals audit.Position.PositionId
                                  where pos.ActionLogId == x
                                  && pos.AuditSequence == audit.Position.AuditSequence + 1
                                  select audit;
                    return _audits.ToList();
                }
                );

            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.UNDO_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));

            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionLogRepository = new Mock<IActionLogRepository>();
            mockedActionLogRepository.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });

            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepo.Object, positionAuditRepository: mockedPositionAuditRepo.Object, actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLogRepository.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();
            var undoChanges = sEdit.GetUndoChanges(2);
            RefreshRepositories();
            var undoneChanges = sEdit.ExecuteUndo(2, undoChanges);
            IList<Position> expectedPositions = new List<Position>{
                new Position { PositionId = 4, Security = new Security { BamSymbol = "IBM", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 12.5M, EntryDate = _now.Date, CustodianName = "DB", FXRate = 1M, ActualQuantity = 55.24M, Portfolio = (Portfolio)Portfolio.Parse("Princess-Leia"), Stream = "US", FundCode = "Fund3", CreatedOn = _now, ActionLogId = actLogId, AuditSequence = 5, LastModifiedOn = _now, LastModifiedBy = "CORP\\kishore", TheoreticalQuantity = 55.24M },
                new Position { PositionId = 2, Security = new Security { BamSymbol = "GOOGLE", Currency = "INR", SecurityType = SecurityType.Equity }, Price = 12.3M, EntryDate = _now.Date, CustodianName = "DB", FXRate = 1M, ActualQuantity = 13.5M, Portfolio = (Portfolio)Portfolio.Parse("Luke-Skywalker"), Stream = "US", FundCode = "Fund3", CreatedOn = _now, ActionLogId = actLogId, AuditSequence = 6, LastModifiedOn = _now, LastModifiedBy = "kishore", TheoreticalQuantity = 13.5M },
                new Position { PositionId= 6, Security=new Security {BamSymbol = "FORD", Currency="GBP", SecurityType = SecurityType.Equity }, Price = 0M, EntryDate=_now.Date, CustodianName="KOTAK", FXRate=1.75M, ActualQuantity=0M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=actLogId, AuditSequence=2, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 0M }
            };

            Assert.AreEqual(undoneChanges.Count, expectedPositions.Count);
            foreach (var p in undoneChanges)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [Test]
        public void TestGetBulkActions()
        {
            var mockedActionRepository = new Mock<IActionRepository>();
            
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns<object>(x => _actionRepository.Where(t => (string)(((dynamic)t).Type) == Constants.CORP_ACTION_TYPE));

            var dbContext = GetMockedDBContext(actionRepository: mockedActionRepository.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            var bulkActions = sEdit.GetBulkActions();
            var expectedActions = _actionRepository.Where(x => x.Type == Constants.CORP_ACTION_TYPE).ToList();
            Assert.True(bulkActions.Count == expectedActions.Count);
            foreach (var action in expectedActions)
            {
                var matchingAction = bulkActions.Single(x => x.ActionId == action.ActionId);
                Assert.AreEqual(action, matchingAction);
            }
        }


        private volatile int _publishFlag = 0;
        // This test case involves threads and locking. I don't want other tests to
        // keep on waiting endlessly if there are any issues with the logic.
        // Hence, I am having this timeout attribute
        [Test, Timeout(10000)]
        public void TestPublishLoadedPositions()
        {
            var rnd = new Random((int)DateTime.Now.Ticks);
            int actLogId = rnd.Next(int.MinValue, int.MaxValue);
            var mockedActionRepository = new Mock<IActionRepository>();
            mockedActionRepository.Setup(x => x.Get(It.IsAny<object>())).Returns(
                _actionRepository.Where(p => p.Name == Constants.PUBLISH_LOADED_POSITIONS_ACTION_NAME
                    && p.Type == Constants.BAM_ACTION_TYPE));

            var mockedActionLogRepository = new Mock<IActionLogRepository>();
            mockedActionLogRepository.Setup(x => x.Save(It.IsAny<SodActionLog>())).Returns<SodActionLog>(x => { x.ActionLogId = actLogId; return x; });

            var mockedPositionRepository = new Mock<IPositionDBRepository>();
            mockedPositionRepository.Setup(x => x.Get(It.IsAny<string>(), It.IsAny<object>())).Returns(_positionRepository);

            var mockFileLoading = new Mock<IFileLoading>();
            var dbContext = GetMockedDBContext(positionDBRepository: mockedPositionRepository.Object, actionRepository: mockedActionRepository.Object, actionLogRepository: mockedActionLogRepository.Object);
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, mockFileLoading.Object, dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();
            IList<Position> publishedPositions = null;
            Action<IList<Position>> posListener = (IList<Position> positions) =>
            {
                publishedPositions = positions;
                ++_publishFlag;

            };
            sEdit.SodPositionLoad += posListener;
            mockFileLoading.Raise(x => x.SodPositionLoaded += null);

            while (_publishFlag == 0) ;
            _publishFlag = 0;

            foreach (var p in publishedPositions)
            {
                Assert.IsTrue(_positionRepository.Contains(p));
            }
        }

        [Test]
        public void TestGetStreams()
        {
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, GetMockedDBContext(), new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            var streams = sEdit.GetStreams();
            Assert.True(streams.Count == 3);
            Assert.True(streams.Contains("US"));
            Assert.True(streams.Contains("AS"));
            Assert.True(streams.Contains("EU"));
        }

        private SodPositionDBContext GetMockedDBContext(
            IPositionDBRepository positionDBRepository = null,
            IPositionAuditRepository positionAuditRepository = null,
            IPositionArchiveRepository positionArchiveRepository = null,
            IActionRepository actionRepository = null,
            IActionLogRepository actionLogRepository = null,
            IExceptionRepository exceptionRepository = null)
        {
            var sodPositionDBContext = new SodPositionDBContext(positionDBRepository ?? new Mock<IPositionDBRepository>().Object,
                positionAuditRepository ?? new Mock<IPositionAuditRepository>().Object,
                positionArchiveRepository ?? new Mock<IPositionArchiveRepository>().Object,
                actionRepository ?? new Mock<IActionRepository>().Object,
                actionLogRepository ?? new Mock<IActionLogRepository>().Object,
                exceptionRepository ?? new Mock<IExceptionRepository>().Object);
            return sodPositionDBContext;

        }

        private bool IsSamePosition(Position p1, Position p2)
        {
            if (p2 == p1)
                return true;

            IPosition other = p2 as IPosition;
            if (other == null)
                return false;
            return p1.Portfolio.Equals(p2.Portfolio)
                   && p1.Security.Equals(p2.Security)
                   && p1.ActualQuantity.Equals(p2.ActualQuantity)
                   && p1.TheoreticalQuantity.Equals(p2.TheoreticalQuantity)
                   && p1.PositionId == p2.PositionId
                   && p1.Price == p2.Price
                   && p1.Stream == p2.Stream
                   && p1.ActionLogId == p2.ActionLogId
                   && p1.AuditSequence == p2.AuditSequence
                   && p1.CustodianName == p2.CustodianName
                   && p1.EntryDate == p2.EntryDate
                   && p1.FundCode == p2.FundCode
                   && p1.FXRate == p2.FXRate
                   && p1.LastModifiedBy == p2.LastModifiedBy
                   && p1.CustodianAccountCode == p2.CustodianAccountCode
                   && p1.Cost == p2.Cost;
        }

        private bool IsSameAuditInfo(PositionAudit p1, PositionAudit p2)
        {
            if (p1 == p2)
            {
                return true;
            }
            return p1.PositionAuditId == p2.PositionAuditId
                && IsSamePosition(p1.Position, p2.Position);
        }

        private void RefreshRepositories()
        {
            _actionRepository = new List<SodAction>()
            {
                new SodAction {ActionId = 1, Name="US_PUBLISH_UPDATED_POSITIONS", Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 2, Name="POSITION_INSERT", Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 3, Name="POSITION_UPDATE", Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 4, Name="POSITION_BULK_INSERT", Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 6, Name="EU_PUBLISH_UPDATED_POSITIONS", Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 7, Name="AS_PUBLISH_UPDATED_POSITIONS", Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 8, Name="UNDO", Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 9, Name="Split", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 10, Name="Dividend", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 11, Name="Spinoff", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
                new SodAction {ActionId = 12, Name=Constants.PUBLISH_LOADED_POSITIONS_ACTION_NAME, Type = Constants.BAM_ACTION_TYPE, LastModifiedBy = "kishore", LastModifiedOn = _yesterday },
            };
            _positionRepository = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=_yesterday.Date, CustodianName="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, Portfolio=(Portfolio)Portfolio.Parse("QIAN-GENERALIST"), Stream="AS", FundCode="Fund1", CreatedOn=_yesterday, ActionLogId=25, AuditSequence=0, LastModifiedOn=_now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M},
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=_now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=-201.54M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=36, AuditSequence=5, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = -201.54M},
                new Position { PositionId= 3, Security=new Security {BamSymbol = "REL", Currency="INR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=_now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=-201.54M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="EU", FundCode="Fund2", CreatedOn=_now, ActionLogId=35, AuditSequence=5, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = -1201.54M},
                new Position { PositionId= 4, Security=new Security {BamSymbol = "IBM", Currency="INR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=_now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=-201.54M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=36, AuditSequence=4, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = -2201.54M},
                new Position { PositionId= 5, Security=new Security {BamSymbol = "ARC", Currency="INR", SecurityType = SecurityType.EquitySwap }, Price = 12M, EntryDate=_now.Date, CustodianName="DB", FXRate=104.75M, ActualQuantity=0M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=35, AuditSequence=5, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 0M},
                new Position { PositionId= 6, Security=new Security {BamSymbol = "FORD", Currency="GBP", SecurityType = SecurityType.Equity }, Price = 15M, EntryDate=_now.Date, CustodianName="KOTAK", FXRate=1.75M, ActualQuantity=2500M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=36, AuditSequence=1, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 2500M},
            };

            _auditRepository = new List<PositionAudit>()
            {
                new PositionAudit {PositionAuditId = 11, Position =
                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=_yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, Portfolio=(Portfolio)Portfolio.Parse("QIAN-GENERALIST"), Stream="US", FundCode="Fund1", CreatedOn=_now, ActionLogId=1, AuditSequence=1, LastModifiedOn=_yesterday, LastModifiedBy="kishore", TheoreticalQuantity = 200000M}
                },

                new PositionAudit {PositionAuditId = 22, Position =
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=_now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=-201.54M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=36, AuditSequence=5, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = -201.54M}},

                new PositionAudit {PositionAuditId = 33, Position =
                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = _yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = -4000M, Portfolio = (Portfolio)Portfolio.Parse("QIAN-GENERALIST"), Stream = "EU", FundCode = "Fund2", CreatedOn = _now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = _yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = -4000M}
                },

                new PositionAudit {PositionAuditId = 44, Position =
                new Position {PositionId = 1, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = _yesterday.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = -200000M, Portfolio = (Portfolio)Portfolio.Parse("QIAN-GENERALIST"), Stream = "US", FundCode = "Fund2", CreatedOn = _now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = _yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = -200000M}
                },

                new PositionAudit {PositionAuditId = 55, Position =
                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = _now.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "AS", FundCode = "Fund1", CreatedOn = _now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = _now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M}
                },

                new PositionAudit {PositionAuditId = 66, Position =
                 new Position {PositionId = 1, Security = new Security {BamSymbol = "GOOG", Currency = "USD", SecurityType = SecurityType.EquityOption }, Price = 2.5M, EntryDate = _now.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "US", FundCode = "Fund1", CreatedOn = _now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = _now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M}
                },
                new PositionAudit {PositionAuditId = 18, Position =
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOGLE", Currency="INR", SecurityType = SecurityType.Equity }, Price = 12.3M, EntryDate=_now.Date, CustodianName="DB", FXRate=1M, ActualQuantity=13.5M, Portfolio=(Portfolio)Portfolio.Parse("Luke-Skywalker"), Stream="US", FundCode="Fund3", CreatedOn=_now, ActionLogId=12, AuditSequence=4, LastModifiedOn=_now, LastModifiedBy="kishore", TheoreticalQuantity = 13.5M}},

                new PositionAudit{PositionAuditId = 19, Position = 
                new Position { PositionId= 4, Security=new Security {BamSymbol = "IBM", Currency="USD", SecurityType = SecurityType.Equity }, Price = 12.5M, EntryDate=_now.Date, CustodianName="DB", FXRate=1M, ActualQuantity=55.24M, Portfolio=(Portfolio)Portfolio.Parse("Princess-Leia"), Stream="US", FundCode="Fund3", CreatedOn=_now, ActionLogId=33, AuditSequence=3, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 55.24M}},
                new PositionAudit{PositionAuditId = 88, Position =
                new Position { PositionId= 4, Security=new Security {BamSymbol = "IBM", Currency="INR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=_now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=-201.54M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=36, AuditSequence=4, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = -2201.54M}},

                new PositionAudit{PositionAuditId = 99, Position =
                    new Position { PositionId= 6, Security=new Security {BamSymbol = "FORD", Currency="GBP", SecurityType = SecurityType.Equity }, Price = 15M, EntryDate=_now.Date, CustodianName="KOTAK", FXRate=1.75M, ActualQuantity=2500M, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=_now, ActionLogId=36, AuditSequence=1, LastModifiedOn=_now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 2500M}}
                
            };
        }
    }
}
