﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.Compliance
{
    public class InitialSodPositionLoad : QueueItemProducerBase<PipelineQueueItem<IMessage>>, IPipelineStepInitializer<IMessage>
    {
        private readonly IQueueMessageDispatcher _dispatcher;
        private static readonly TimeSpan RetryInterval = TimeSpan.FromSeconds(5);

        private readonly ISodPositionServiceClient _client;
        private readonly IDbPositionLookup _dbPositionLookup;
        private readonly IBackgroundWorker _sodPositionWorker;

        private volatile bool _contigencyLoaded, _sodLoaded;

        public InitialSodPositionLoad(
            ISodPositionServiceClient client,
            IDbPositionLookup dbPositionLookup,
            IQueueMessageDispatcher dispatcher)
        {
            _client = client;
            _dbPositionLookup = dbPositionLookup;
            _dispatcher = dispatcher;
            _sodPositionWorker = BackgroundWorkerFactory.Current.Create("Initial SOD");
        }
        
        public override void Start()
        {
            _sodPositionWorker.Start(LoadPositions);
        }

        public override void Stop()
        {
            _sodPositionWorker.Stop();
        }

        public void Execute(IQueue<PipelineQueueItem<IMessage>> queue, CancellationToken cancellationToken)
        {
            // try once on startup ...
            TryLoad(queue);
        }

        private void LoadPositions(CancellationToken cancellationToken)
        {
            // ... keep trying in background if initial try failed
            do
            {
                if (_sodLoaded && _contigencyLoaded)
                    break;

                TryLoad(Queue);
            } while (!cancellationToken.WaitHandle.WaitOne(RetryInterval));
        }

        private void TryLoad(IQueue<PipelineQueueItem<IMessage>> queue)
        {
            if (!_contigencyLoaded)
            {
                try
                {
                    foreach (var msg in LoadLatestContingencyPositions().ToList())
                    {
                        _dispatcher.Dispatch(queue, msg);
                    }
                    _contigencyLoaded = true;
                }
                catch (Exception ex)
                {
                    Logger?.LogWarning($"Unable to retrieve contingency positions, retrying in {RetryInterval}", ex);
                }
            }

            if (!_sodLoaded)
            {
                try
                {
                    foreach (var msg in LoadSodPositions().ToList())
                    {
                        _dispatcher.Dispatch(queue, msg);
                    }
                    _sodLoaded = true;
                }
                catch (Exception ex)
                {
                    Logger?.LogWarning($"Unable to retrieve SOD positions, retrying in {RetryInterval}", ex);
                }
            }
        }

        private IEnumerable<LoadSodPositions> LoadSodPositions()
        {
            var all = _client.Get().GetAwaiter().GetResult();
            foreach (var positions in all.GroupBy(p => p.Stream))
            {
                var asOf = positions.Select(p => p.EntryDate).Distinct().Single();
                var sodItems = positions.Select(s => new LoadSodPositions.SodItem
                {
                    Symbol = s.Security.BamSymbol,
                    Quantity = (long)s.ActualQuantity,
                    Strategy = s.Portfolio.Key,
                    Custodian = s.CustodianName,
                    Fund = s.FundCode
                }).ToArray();

                yield return new LoadSodPositions(sodItems)
                {
                    AsOf = asOf,
                };
            }
        }

        private IEnumerable<LoadSodPositions> LoadLatestContingencyPositions()
        {
            DateTime businessDay;
            var contingency = _dbPositionLookup.Get<ContingencyPosition>(out businessDay);

            var loadPositions = new LoadSodPositions
            {
                AsOf = businessDay,
                IsContingency = true
            };

            foreach (var pos in contingency)
            {
                loadPositions.SodPositions.Add(new LoadSodPositions.SodItem
                {
                    Symbol = pos.BamSymbol,
                    Strategy = pos.Portfolio,
                    Custodian = pos.Custodian,
                    Fund = pos.Fund,
                    Quantity = pos.Quantity
                });
            }

            yield return loadPositions;
        }
    }
}
