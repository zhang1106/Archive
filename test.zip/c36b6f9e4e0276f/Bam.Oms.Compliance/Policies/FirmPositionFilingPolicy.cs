﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Positions;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Filtering;

namespace Bam.Oms.Compliance
{
    public class FirmPositionFilingPolicy<T> : Policy<T> where T :  IFirmPositionFilingTraget
    {
        private IResultResultRepository _resultResultRepository;
      

        public FirmPositionFilingPolicy(IResultResultRepository resultResultRepository)
        {
            _resultResultRepository = resultResultRepository;
        }
        
        override public IPolicyResult CheckViolations(T input, bool isPreCheck)
        {
           PolicyResult result = new PolicyResult() { PolicyId = Id, PolicyName = Name };

           foreach(var rule in Rules)
           {
               var histResult = new RuleResult() { PolicyId = Id, RuleId = rule.Id, TargetKey = input.Position.Security.Key };

               input.LastCheckResult = _resultResultRepository.Get(histResult.Key);
                
               var ruleResult = rule.CheckViolation(input, false);

               ruleResult.PolicyId = this.Id;

               result.Violations.Add(ruleResult);

               //save result to persistent cache
               _resultResultRepository.Save(ruleResult as RuleResult);
           }

            return result;
        }
    }
}
