﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Throttling
{
    public class ThrottlingQueueItemHandler<TItem> : IQueueItemHandler<PipelineQueueItem<TItem>>
    {
        private class Entry
        {
            public Action<TItem, long, bool> Throttle { get; set; }
            public Action Flush { get; set; }
            public bool SkipReplay { get; set; }
        }

        private readonly IConsumptionTrigger<TItem> _trigger;
        private readonly CasLock _lock = new CasLock();
        private readonly Dictionary<Type, List<Entry>> _entries;
        private readonly List<Action> _consumers;

        public ThrottlingQueueItemHandler(IConsumptionTrigger<TItem> trigger)
        {
            _entries = new Dictionary<Type, List<Entry>>();
            _consumers = new List<Action>();
            _trigger = trigger;
            _trigger.Consume += TriggerOnConsume;
        }

        public ILogger Logger { get; set; }

        private void TriggerOnConsume(object sender, EventArgs e)
        {
            _consumers.Clear();
            using (_lock.Acquire())
            {
                foreach (var item in _entries)
                {
                    foreach (var entry in item.Value)
                    {
                        _consumers.Add(entry.Flush);
                    }
                }
            }

            foreach (var action in _consumers)
            {
                try
                {
                    action();
                }
                catch (Exception ex)
                {
                    Logger?.LogError("Failed to flush strategy", ex);
                }
            }
        }

        public void Add<T>(IThrottlingStrategy<T> strategy, IThrottledBatchHandler<T> handler, bool skipReplay)
            where T : TItem
        {
            var stratExpr = Expression.Constant(strategy);
            var handlerExpr = Expression.Constant(handler);

            var throttleMethod = strategy.GetType().GetMethod(nameof(IThrottlingStrategy<T>.Throttle));
            var flushMethod = strategy.GetType().GetMethod(nameof(IThrottlingStrategy<T>.Flush));

            var item = Expression.Parameter(typeof(TItem), "item");
            var sequence = Expression.Parameter(typeof(long), "sequence");
            var eob = Expression.Parameter(typeof(bool), "endOfBatch");
            var castItem = Expression.Convert(item, typeof(T));
            var throttle = Expression.Call(stratExpr, throttleMethod, castItem, sequence, eob);
            var flush = Expression.Call(stratExpr, flushMethod, handlerExpr);

            var throttleAction = Expression.Lambda<Action<TItem, long, bool>>(throttle, item, sequence, eob).Compile();
            var flushAction = Expression.Lambda<Action>(flush).Compile();

            using (_lock.Acquire())
            {
                List<Entry> entries;
                if (!_entries.TryGetValue(typeof(T), out entries))
                {
                    _entries[typeof(T)] = entries = new List<Entry>();
                }

                entries.Add(new Entry
                {
                    SkipReplay = skipReplay,
                    Throttle = throttleAction,
                    Flush = flushAction
                });
            }
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            try
            {
                if (!item.IsValid)
                    return;

                using (_lock.Acquire())
                {
                    List<Entry> entries;
                    if (!_entries.TryGetValue(item.Payload.GetType(), out entries))
                        return;

                    foreach (var entry in entries)
                    {
                        if (entry.SkipReplay && item.IsReplay)
                            continue;

                        entry.Throttle(item.Payload, sequence, endOfBatch);
                    }
                }
            }
            finally
            {
                _trigger.Throttled(item.Payload, sequence, endOfBatch);
            }
        }
    }
}
