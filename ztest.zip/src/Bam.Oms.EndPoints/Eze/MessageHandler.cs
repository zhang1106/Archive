﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Configuration;
using Bam.Oms.OrderRouting.EZE;
using Eze.Common.Integration;
using BAM.Common.Messaging;
using Microsoft.Practices.Unity;
using BAM.Infrastructure.Ioc;
using System.ServiceModel.Description;
using System.ServiceModel.Web;

namespace Bam.Oms.EndPoints.Eze
{
    public class MessageHandler : IMessageHandler
    {
        private readonly IFlowClient _flowClient;
        private readonly ISubscriptionHost _subscriptionHost;
        private readonly ITranslator _translator;
        private readonly ISettings _settings;
        private readonly ILogger _logger;

    
        public MessageHandler(
            [Dependency("mq")]IFlowClient flowClient,
            ITranslator translator, 
            ISubscriptionHost subscriptionHost,
            ISettings settings,
            ILogger logger
            ) 
        {
            if (flowClient == null) throw new ArgumentNullException(nameof(flowClient));
            if (subscriptionHost == null) throw new ArgumentNullException(nameof(subscriptionHost));
            if (flowClient == null) throw new ArgumentNullException(nameof(translator));
            if (logger == null) throw new ArgumentNullException(nameof(logger));

            _flowClient = flowClient;
            _subscriptionHost = subscriptionHost;
            _translator = translator;
            _logger = logger;
            _settings = settings;
        }
        
        public void ProcessMessage(string message, string route)
        {
            if (UseMq())
            {
                _flowClient.PublishEzeOrders(new List<string>() {message}, route);
            }
            else
            {
                ProcessMqMessage(new Message<string>(message){RoutingKey=route});
            }
        }

      
        public void SubscribeMqMessages()
        {
            if (UseMq())
            {
                _logger.Debug("Start subscribing MQ message");
                _flowClient.ObjectUpdated += ProcessMqMessage;
                _flowClient.SubscribeEzeOrders();
            }
            else
            {
                _logger.Debug("wont subscribe MQ message");
            }
        }

        private bool UseMq()
        {
            return (_settings.PublishEzeToMq == "YES");
        }

        //we only get trade message now
        private void ProcessMqMessage(Message<string> message)
        {
                ProcessMqOrders(message.Data);
        }

        private void ProcessMqOrders(string message)
        {
            var trades = _translator.GetTrades(message) as IReadOnlyList<Trade>;
            _subscriptionHost.ProcessTradeUpdateAsync(trades);
        }

        private void ProcessMqAllocations(string message)
        {
            var allocations = _translator.GetAllocations(message) as IReadOnlyList<Allocation>;
            _subscriptionHost.ProcessAllocationUpdateAsync(allocations);
        }

        public const string EzeOrders = "EzeOrders";
        public const string EzeAllocations = "EzeAllocations";
    }
}
