﻿using System;
using System.Linq.Expressions;

namespace Bam.EventQ.Sequencing
{
    public class MessageFactory
    {
        static MessageFactory()
        {
            Current = Default = new MessageFactory();
        }

        protected MessageFactory()
        {

        }

        public virtual T Create<T>()
        {
            return FastActivator<T>.Factory();
        }

        public static MessageFactory Default { get; }
        public static MessageFactory Current { get; set; }

        private static class FastActivator<T>
        {
            public static readonly Func<T> Factory;

            static FastActivator()
            {
                var body = Expression.New(typeof(T));
                var lambda = Expression.Lambda<Func<T>>(body);
                Factory = lambda.Compile();
            }
        }
    }
}
