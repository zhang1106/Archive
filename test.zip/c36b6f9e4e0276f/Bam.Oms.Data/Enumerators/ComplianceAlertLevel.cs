﻿
namespace Bam.Oms.Data.Enumerators
{
    public enum ComplianceAlertLevel
    {
        NotApplicable,
        NoViolation,
        Warning,
        FallBelowWarning,
        ExceedWarning,
        Overrideable,
        ComplianceOverrideable,
        Reportable,
        Violated,
        Restricted,
        NoDataAvaiable,
        SubWarning,
        Error,
        NoAlertLevelChange
    }
}
