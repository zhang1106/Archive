﻿namespace Bam.Oms.OrderGateway.Compliance.Services.Marking
{
    public interface IOrderMarkerFactory
    {
        IOrderMarker Create(string securityType);
    }
}
