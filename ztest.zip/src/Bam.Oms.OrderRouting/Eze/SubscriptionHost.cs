﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Schedulers;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Trades;
using EzeEi = Eze.Common.Integration;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using BAM.Infrastructure.Ioc;
using Order = Bam.Oms.Data.Orders.Order;
 

namespace Bam.Oms.OrderRouting.EZE
{
    public class SubscriptionHost : SubScriptionHostBase, ISubscriptionHost
    {
        public new event Action<IEnumerable<IBlockTrade>> TradeUpdated;

        public override void Dispose()
        {
            _cancellationTokenSource.Cancel();
        }

        public new event Action<IEnumerable<IOrder>> OrderStatusChanged;
        private readonly IMappingAgent _processor;
        private readonly INotificationCache _notificationCache;
        private readonly CancellationTokenSource _cancellationTokenSource;
        private readonly OrderedTaskScheduler _orderedTaskScheduler;

        public SubscriptionHost(IMappingAgent processor, INotificationCache notificationCache, ISettings settings,  ILogger logger) : base(settings, logger)
        {
            if (processor == null) throw new ArgumentNullException(nameof(processor));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if(settings==null) throw new ArgumentException(nameof(settings));
            if (logger == null) throw new ArgumentNullException(nameof(notificationCache));

            _notificationCache = notificationCache;
            _processor = processor;
            _cancellationTokenSource = new CancellationTokenSource();
            _orderedTaskScheduler = new OrderedTaskScheduler();
        }
 
        public void ProcessTradeUpdate(IReadOnlyList<EzeEi.Trade> trades)
        {
            if (!StartSubscribe) return;

            var orderList = new List<Order>();
            var tradeList = new List<BlockTrade>();

            //mapping trade by trade
            foreach (var trade in trades)
            {
                var cTrade = _notificationCache.GetTrade(trade.TradeId);
                //do not process aged notifications
                if (cTrade != null && cTrade.RTBlotterTimeStamp > trade.RTBlotterTimeStamp) continue;

                IList<Order> ogOrders;
                IList<BlockTrade> ogTrades;

                _processor.Translate(trade, out ogOrders, out ogTrades);
                
                //collect og updates
                orderList.AddRange(ogOrders);
                tradeList.AddRange(ogTrades);
            }

            //add to cache
            if (trades.Any())
            {
                _notificationCache.AddEzeTrades(trades);
            }

            //notify orders updates
            if (orderList.Any())
            {
                _logger.Debug($"Mapped {orderList.Count} orders from EZ");
                Utility.RaiseEvent(orderList, OrderStatusChanged);
            }

            if (!tradeList.Any()) return;
            //notify trade updates
            _logger.Debug($"Mapped {tradeList.Count} trades from EZ");
            Utility.RaiseEvent(tradeList, TradeUpdated);
        }
 
        public void ProcessTradeUpdateAsync(IReadOnlyList<EzeEi.Trade> trades)
        {
            Task.Factory.StartNew(() => { ProcessTradeUpdate(trades); }, _cancellationTokenSource.Token, TaskCreationOptions.HideScheduler, _orderedTaskScheduler);
        }

        public void ProcessAllocationUpdate(IReadOnlyList<EzeEi.Allocation> allocations)
        {
            
            var tradeList = new List<EzeEi.Trade>();
            var tradeIds = allocations.Select(a => a.TradeID).Distinct();
            foreach (var id in tradeIds)
            {
                var tAllocations = allocations.Where(a => a.TradeID == id).ToList();
               
                var trade = _notificationCache.GetTrade(id);
                //ignore the updates without a trade for now
                if (trade == null)
                {
                    _logger.Warn($"Receive Notification without trade. Eze Trade {id} does not exist.");
                    continue;
                }

                var nTrade = new EzeEi.Trade();
                MappingAgent.CopyBasicEzeTrade(trade, nTrade); 
                nTrade.Allocations = tAllocations;
               
                tradeList.Add(nTrade);
            }

            var readonlyList = (IReadOnlyList< EzeEi.Trade >)tradeList;
            ProcessTradeUpdate(readonlyList);
        }

        public async void ProcessAllocationUpdateAsync(IReadOnlyList<EzeEi.Allocation> allocations)
        {
            await Task.Factory.StartNew(() =>
            {
                ProcessAllocationUpdate(allocations);
            });
        }
   }

}
