﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class OrderAllocation : ICloneable
    {
        public Portfolio Portfolio { get; set; }
        public string Custodian { get; set; }
        public string Fund { get; set; }
        public decimal Quantity { get; set; }

        public object Clone()
        {
            return new OrderAllocation
            {
                Portfolio = (Portfolio) Portfolio.Clone(),
                Quantity = Quantity,
                Custodian = Custodian,
                Fund = Fund
            };
        }
    }
}
