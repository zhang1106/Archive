﻿using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class UtilityTest
    {
        [Test]
        [TestCase("EquitySwap", InvestmentType.EquitySwap)]
        [TestCase("Equity", InvestmentType.Equity)]
        public void TestEnumConvert(string eType, InvestmentType expected)
        {
            var type = Utility.ConvertEnum<InvestmentType>(eType);

            Assert.IsTrue(type== expected);
        }

        [Test]
        [TestCase("Equity Swap", InvestmentType.EquitySwap)]
        [TestCase("Equity", InvestmentType.Equity)]
        public void TestEnumString(string eType, InvestmentType expected)
        {
            var type = Utility.GetEnumValue<InvestmentType>(eType);

            Assert.IsTrue(type == expected);
        }
    }
}
