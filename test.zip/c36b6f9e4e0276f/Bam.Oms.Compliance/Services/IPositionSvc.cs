﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Compliance.Services
{
    public interface IPositionSvc
    {
        IEnumerable<FlatPosition> GetPositionsByUnderlying(PositionType type, string underlying);
      
        IEnumerable<FlatPosition> GetDecomposedPositionsByIsin(string isin, PositionType type, bool dumpToDb);

        IEnumerable<Constituent> GetConstituents(string symbol);
    }
}
