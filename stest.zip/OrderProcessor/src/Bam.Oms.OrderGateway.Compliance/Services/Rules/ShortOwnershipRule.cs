﻿using Bam.EventQ.Lookup;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;
using Bam.Oms.OrderGateway.Compliance.Services.Headroom;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public class ShortOwnershipRule : OwnershipRule
    {
        public ShortOwnershipRule(
            IIndexFactory index, IHeadroomEffectCache effectCache, bool monitoringMode,
            params string[] coveredSecurityTypes)
            : base(index, effectCache, coveredSecurityTypes, monitoringMode)
        {
        }

        public override string Name => "Short Ownership";

        protected override bool ShouldExecute(HeadroomRule rule, Order order)
        {
            bool direction =
                rule.Direction == HeadroomDirection.NetShort ||
                rule.Direction == HeadroomDirection.Short;

            bool entity =
                rule.ReportingEntity == HeadroomRule.FirmReportingEntity ||
                rule.ReportingEntity == order.ReportingEntity;

            return direction && entity;
        }
        
        protected override bool CanSkip(Order order)
        {
            return
                base.CanSkip(order) ||
                order.Side == Side.Buy || order.Side == Side.Cover;
        }
    }
}