﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.Persistence.Orders
{
    public interface IOrderDBRepository : IDBRepository<IOrder>
    {
    }
}
