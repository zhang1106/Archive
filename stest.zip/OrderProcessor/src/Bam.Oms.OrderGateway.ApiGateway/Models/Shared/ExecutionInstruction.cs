﻿namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class ExecutionInstruction
    {
        public string Code { get; set; }
        public string Value { get; set; }
    }
}
