﻿using System;
using System.Collections;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Trades;
using FluentAssertions;
using NUnit.Framework;
using Ploeh.AutoFixture;

namespace Bam.Oms.Tests
{
    public class CloneTests
    {
        [TestCaseSource(nameof(Clonables))]
        public void VerifyFullClone<T>(T item) where T : ICloneable
        {
            var clone = (T)item.Clone();
            clone.Should().NotBeSameAs(item);
            clone.ShouldBeEquivalentTo(item);
        }

        public static IEnumerable Clonables
        {
            get
            {
                var fixture = new Fixture();
                yield return fixture.Create<Order>();
                yield return fixture.Create<BlockTrade>();
            }
        }
    }
}
