﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public class RuleContext
    {
        public long Quantity { get; set; }
        public Order Order { get; set; }
        public bool IsDryRun { get; set; }
        public HashSet<string> SuppressedRules { get; } = new HashSet<string>();
        public Dictionary<string, decimal> AuditTrail { get; } = new Dictionary<string, decimal>();
    }
}