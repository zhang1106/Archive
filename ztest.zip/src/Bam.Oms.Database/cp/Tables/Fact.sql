﻿CREATE TABLE [cp].[Fact] (
    [FactId]         INT           IDENTITY (1, 1) NOT NULL,
    [Name]           VARCHAR (50)  NOT NULL,
    [Value]          VARCHAR (300) NULL,
    [CreatedOn]      DATETIME      NOT NULL,
    [CreatedBy]      VARCHAR (50)  NULL,
    [LastModifiedOn] DATETIME      NOT NULL,
    [LastModifiedBy] VARCHAR (50)  NULL,
    CONSTRAINT [PK__Fact__74D3207D0E391C95] PRIMARY KEY CLUSTERED ([FactId] ASC)
);

