﻿using System;

namespace Bam.Oms.Service.Trades
{
    public interface ITradeProcessor : IDisposable
    {
         
    }
}