﻿using System.Collections.Generic;
using System.Linq;

// ReSharper disable once CheckNamespace
namespace System
{
    public static class TypeExtensions
    {
        public static string GetDisplayName(this Type type)
        {
            string name = type.Name;
            if (type.IsGenericType)
            {
                name = name.Substring(0, name.Length - 2); // remove `1
                string args = type.GetGenericArguments()
                    .Select(a => a.GetDisplayName()).Aggregate((s1, s2) => s1 + "," + s2);
                name += "<" + args + ">";
            }

            return name;
        }

        public static bool IsCollectionType(this Type type, out Type itemType)
        {
            itemType = null;

            if (!type.IsGenericType)
                return false;

            itemType = type.GetGenericArguments()[0];
            return typeof(ICollection<>).MakeGenericType(itemType).IsAssignableFrom(type);
        }

        public static bool IsDictionaryType(this Type type, out Type keyType, out Type valueType)
        {
            keyType = null;
            valueType = null;

            if (!type.IsGenericType || type.GetGenericArguments().Length < 2)
                return false;

            keyType = type.GetGenericArguments()[0];
            valueType = type.GetGenericArguments()[1];
            return typeof(IDictionary<,>).MakeGenericType(keyType, valueType).IsAssignableFrom(type);
        }
    }
}
