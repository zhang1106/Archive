﻿namespace Bam.EventQ.Recovery
{
    public struct SequenceInfo
    {
        public SequenceInfo(int sourceId, int topic, long sequence, int timestamp)
        {
            SourceId = sourceId;
            Topic = topic;
            Sequence = sequence;
            Timestamp = timestamp;
        }

        public int Timestamp { get; set; }
        public int SourceId { get; }
        public int Topic { get; }
        public long Sequence { get; }
    }
}
