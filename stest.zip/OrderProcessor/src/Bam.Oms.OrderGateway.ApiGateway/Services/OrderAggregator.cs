﻿using System.Collections.Generic;
using System.Linq;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public class OrderAggregator : IOrderAggregator
    {
        public IReadOnlyList<SubmitOrders.SubmitOrderLineItem> Collapse(IReadOnlyList<SubmitOrders.SubmitOrderLineItem> fullList)
        {
            var ordersToProcess = fullList.GroupBy(
                    order =>
                        new
                        {
                            order.ReplaceOrderId,
                            order.Portfolio,
                            Side = FlattenType(order.Side),
                            order.Custodian,
                            order.Symbol,
                            order.LimitPrice,
                            order.Urgency,
                            order.FundAllocationOverride
                        })
                .Select(
                    g =>
                        new SubmitOrders.SubmitOrderLineItem(g.SelectMany(r => r.ExecutionInstructions)) //assumes the exec inst are the same per group
                        {
                            ReplaceOrderId = g.Key.ReplaceOrderId,
                            Symbol = g.Key.Symbol,
                            Portfolio = g.Key.Portfolio,
                            Side = g.Key.Side,
                            Custodian = g.Key.Custodian,
                            LimitPrice = g.Key.LimitPrice,
                            FundAllocationOverride = g.Key.FundAllocationOverride,
                            Quantity = g.Sum(r => r.Quantity),
                            Notes = g.Select(i => i.Notes).Aggregate((i, j) => i + ";" + j),
                            Urgency = g.Key.Urgency,
                        }).ToList();

            return ordersToProcess;
        }

        private Side FlattenType(Side type)
        {
            switch (type)
            {
                case Side.Buy:
                case Side.Cover:
                    return Side.Buy;
                default:
                    return Side.Sell;
            }
        }
    }
}