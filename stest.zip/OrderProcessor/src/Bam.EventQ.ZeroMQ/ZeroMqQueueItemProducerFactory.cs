﻿using System;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.ZeroMQ
{
    public class ZeroMqQueueItemProducerFactory<TItem> : IQueueItemProducerFactory<PipelineQueueItem<TItem>>
    {
        private readonly Func<int, string> _sourceToEndpointFunc;
        private readonly int _bufferSize;

        public ZeroMqQueueItemProducerFactory(Func<int, string> sourceToEndpointFunc, int bufferSize)
        {
            _sourceToEndpointFunc = sourceToEndpointFunc;
            _bufferSize = bufferSize;
        }

        public IQueueItemProducer<PipelineQueueItem<TItem>> Create(int[] sources, int[] topics)
        {
            var subscriber = new ZeroMqMessageSubscriber();
            foreach (int source in sources)
            {
                string endpoint = _sourceToEndpointFunc(source);
                if (endpoint == null)
                {
                    throw new NotSupportedException($"No endpoint found for source {source}");
                }

                subscriber.Connect(endpoint);
            }

            foreach (int topic in topics)
            {
                subscriber.Subscribe(topic);
            }

            return new MessageSubscriberPipelineQueueItemProducer<TItem>(subscriber, _bufferSize);
        }
    }
}
