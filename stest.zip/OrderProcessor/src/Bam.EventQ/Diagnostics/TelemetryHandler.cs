﻿using System;
using System.Diagnostics;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Diagnostics
{
    public class TelemetryHandler<TItem> : IQueueItemHandler<TItem>
    {
        private readonly ITelemetry _telemetry;
        private readonly IQueueItemHandler<TItem> _inner;
        private readonly Stopwatch _itemStopwatch, _publishStopwatch;
        private readonly TimeSpan _publishInterval;
        private readonly string _handlerName;
        private TimeSpan _processingTime;
        private int _messagesHandled;
        private int _endOfBatches;

        public TelemetryHandler(IQueueItemHandler<TItem> inner, ITelemetry telemetry, TimeSpan publishInterval)
        {
            _telemetry = telemetry;
            _inner = inner;
            _publishInterval = publishInterval;
            _publishStopwatch = Stopwatch.StartNew();
            _itemStopwatch = new Stopwatch();
            _processingTime = TimeSpan.Zero;
            _handlerName = inner.GetType().GetDisplayName();
        }

        public void Handle(TItem item, long sequence, bool endOfBatch)
        {
            _itemStopwatch.Restart();
            try
            {
                _inner.Handle(item, sequence, endOfBatch);
            }
            finally
            {
                _itemStopwatch.Stop();
                _messagesHandled++;
                if (endOfBatch) _endOfBatches++;
                _processingTime += _itemStopwatch.Elapsed;
                
                if (_publishStopwatch.Elapsed > _publishInterval)
                {
                    double avg = _processingTime.TotalSeconds > 0 ? _messagesHandled /_processingTime.TotalSeconds : 0;
                    double batchSize = (double)_messagesHandled/_endOfBatches;

                    _telemetry.Record($"{_handlerName}-Capacity", avg);
                    _telemetry.Record($"{_handlerName}-BatchSize", batchSize);
                    _telemetry.Record($"{_handlerName}-Messages", _messagesHandled);
                    _telemetry.Record($"{_handlerName}-CpuTime", _processingTime.TotalMilliseconds);

                    _messagesHandled = 0;
                    _endOfBatches = 0;
                    _processingTime = TimeSpan.Zero;
                    _publishStopwatch.Restart();
                }
            }
        }
    }
}
