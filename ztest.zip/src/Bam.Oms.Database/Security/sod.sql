﻿CREATE SCHEMA [sod]
    AUTHORIZATION [dbo];



