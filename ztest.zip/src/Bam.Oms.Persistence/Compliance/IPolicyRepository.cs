﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Compliance;


namespace Bam.Oms.Persistence.Compliance
{
    public interface IPolicyRepository<T> :  IDBRepository<Policy<T>>
    {
    }
}
