﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Persistence.Positions
{
    public interface IEodPositionRepository
    {
        int Save(IReadOnlyList<IPosition> positions, DateTime businessDay);
        IReadOnlyList<IPosition> Load(DateTime businessDay);
    }
}
