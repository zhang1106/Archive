﻿using System;
using System.IO;
using System.Text;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Integration;
using Bam.EventQ.Transport;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Bam.EventQ.RabbitMQ
{
    public class RabbitMqExternalMessageSource<TIn> : IExternalMessageSource<TIn>
    {
        private readonly JsonSerializer _serializer;
        private readonly Encoding _encoding;
        private readonly IMessageSubscriber _subscriber;
        private readonly int _bufferSize;
        private readonly IBackgroundWorker _receiverWorker;
        private Action<TIn> _handler;

        public RabbitMqExternalMessageSource(IMessageSubscriber subscriber, int bufferSize)
        {
            _subscriber = subscriber;
            _bufferSize = bufferSize;
            _serializer = new JsonSerializer();
            _serializer.Converters.Add(new StringEnumConverter());
            _encoding = new UnicodeEncoding(false, false);
            _receiverWorker = BackgroundWorkerFactory.Current.Create($"RMQ {typeof(TIn).GetDisplayName()}");
        }

        public ILogger Logger { get; set; }

        public void Initialize(Action<TIn> handler)
        {
            _handler = handler;
        }

        public void Start()
        {
            _receiverWorker.Start(Receive);
        }

        public void Stop()
        {
            _receiverWorker.Stop();
        }

        private void Receive(CancellationToken cancellationToken)
        {
            var timeout = TimeSpan.FromMilliseconds(500);
            var buffer = new byte[_bufferSize];
            while (!cancellationToken.IsCancellationRequested)
            {
                int received, topic;
                if (_subscriber.TryReceive(buffer, 0, out received, out topic, timeout))
                {
                    try
                    {
                        var item = Deserialize<TIn>(buffer, received);
                        _handler?.Invoke(item);
                    }
                    catch (Exception ex)
                    {
                        Logger?.LogError("Failed to deserialize item from RabbitMQ", ex);
                    }
                }
            }
        }

        private T Deserialize<T>(byte[] buffer, int length)
        {
            using (var ms = new MemoryStream(buffer, 0, length))
            using (var reader = new StreamReader(ms, _encoding))
            using (var json = new JsonTextReader(reader))
            {
                return _serializer.Deserialize<T>(json);
            }
        }
    }
}
