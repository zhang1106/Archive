﻿using System;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.ServiceProcess;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Configuration;
using BAM.Infrastructure.Ioc;
using log4net;
using log4net.Config;
using Microsoft.Isam.Esent.Interop;

namespace Bam.Oms.Compliance.Service
{
    public partial class ComplianceGateway : ServiceBase, IComplianceGateway
    {
        private static readonly ILog Logger = LogManager.GetLogger("Bam.Oms.Compliance.Service");
        private readonly ISettings _settings;
        private static bool Stop = false;
      
        [Log]
        public ComplianceGateway(ISettings settings) 
        {
            InitializeComponent();
            _settings = settings;
        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        private static void Main(string[] args)
        {
            var currentDomain = AppDomain.CurrentDomain;
            Directory.SetCurrentDirectory(currentDomain.BaseDirectory);
            XmlConfigurator.Configure();

            var service = (ComplianceGateway)BAM.Infrastructure.Ioc.Container.Instance.Resolve<IComplianceGateway>();

            if (Environment.UserInteractive)
            {
                service.OnStart(args);
                Console.WriteLine("Press any key to stop program");
                Console.Read();
                service.OnStop();
            }
            else
            {
                Run(service);
            }
        }

        public static void SvcThread()
        {
            try
            {
                Logger.Info($"Starting...{Assembly.GetExecutingAssembly().FullName}");
                Logger.Info("Gateway Service Started...");
                Logger.Info("Init  Service, load rules...");
                var cService = (FirmPositionComplianceSvc)BAM.Infrastructure.Ioc.Container.Instance.Resolve<IFirmPositionComplianceSvc>();
                cService.Init();
                Logger.Info("validate positions agains rules...");
                var span = int.Parse(ConfigurationManager.AppSettings["compliance_span"]);
                var start = int.Parse(ConfigurationManager.AppSettings["compliance_start"]);
                var end = int.Parse(ConfigurationManager.AppSettings["compliance_end"]);
                var cleared = false;
                //mins
                var interval = span*1000*60;

                while (!Stop)
                {
                    try
                    {
                        if ("DEV".Equals(ConfigurationManager.AppSettings["DEPLOYMNT_ENV"]))
                        {
                            Logger.Info($"service wont run because no POMO access.");
                        }
                        else
                        {
                            if (DateTime.Now.DayOfWeek != DayOfWeek.Saturday && DateTime.Now.DayOfWeek != DayOfWeek.Sunday)
                            {
                                if (DateTime.Now.Hour >= start && DateTime.Now.Hour <= end)
                                {
                                    cleared = false;
                                    cService.Run();
                                    Logger.Info($"Next run will be - {DateTime.Now.AddMilliseconds(interval).ToLongTimeString()}");
                                }
                                else
                                {
                                    if (!cleared)
                                    {
                                        Logger.Info($"Service only runs between {start} and {end} during weekdays");
                                        //clear the repository
                                        cService.ClearRepository();
                                        cleared = true;
                                    }
                                }
                            }
                            else
                            {
                                    Logger.Info($"Wont run on weekends");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Error(ex);
                    }

                    Thread.Sleep(interval);
                }

                Logger.Info("done...");
            }
            catch (Exception ex)
            {
                Logger.FatalFormat("Unable to start service {0} - {1}", ex.Message, ex.StackTrace);
            }
        }
        
        [Log]
        protected override void OnStart(string[] args)
        {
           var t = new Thread(SvcThread) {IsBackground = true};
           t.Start();
        }

        protected override void OnStop()
        {
            Logger.Info("Stopping......");
            try
            {
                Stop = false;
                // This would call the dispose on all the injected disposable objects, including the persistence repositories. The persistence caches are flushed at dispose.
                BAM.Infrastructure.Ioc.Container.Instance.Dispose();
            }
            catch (Exception ex)
            {  
                Logger.Warn("Exception disposing IOC container.", ex); 
            }

            Logger.Info("Stopped service.");
        }
    }
}