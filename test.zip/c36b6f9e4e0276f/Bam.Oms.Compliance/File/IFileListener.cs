﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Compliance.File
{
    public interface IFileListener
    {
        void Start();
        void Stop();
        event Action<IList<IPosition>> SodPositionLoaded;
     }
}
