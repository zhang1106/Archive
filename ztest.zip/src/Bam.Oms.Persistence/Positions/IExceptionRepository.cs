﻿using Bam.Oms.Data.Positions;

namespace Bam.Oms.Persistence.Positions
{
    public interface IExceptionRepository : IDBRepository<SodException>
    {
    }
}