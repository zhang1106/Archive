﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using Bam.Infrastructure.Connectivity;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Messaging;
using Bam.Oms.RefData.Eze;
using Bam.Oms.ReferenceDataGateway.Api.Model;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR.Client;
using ILogger = BAM.Infrastructure.Ioc.ILogger;


namespace Bam.Oms.RefData
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            ISettings settings = container.Resolve<ISettings>();            
            container.RegisterType<IDbConnection, SqlConnection>(RegistrationType.Transient, new InjectionConstructor());
            container.RegisterType<ISqlConnectionWrapper, SqlConnectionWrapper>(RegistrationType.Singleton, new InjectionConstructor(typeof(IDbConnection), settings.OrderGatewayConnectionString));

            var host = ConfigurationManager.AppSettings["refData_svc_url"];
            var port = ConfigurationManager.AppSettings["refData_svc_port"];

            var accountProxy = new RestfulClientProxy<ReferenceDataGateway.Api.Http.IAccountController>(host, port);
            container.RegisterInstance(accountProxy.ProxyChannel);

            var securityProxy = new RestfulClientProxy<ReferenceDataGateway.Api.Http.ISecurityController>(host, port);
            container.RegisterInstance(securityProxy.ProxyChannel);

            var coverageProxy = new RestfulClientProxy<ReferenceDataGateway.Api.Http.ICoverageController>(host, port);
            container.RegisterInstance(coverageProxy.ProxyChannel);

            container.RegisterType<IOrderValidator, OrderValidator>(RegistrationType.Singleton);
            container.RegisterType<ISecurityMasterService, SecurityMasterService>(RegistrationType.Singleton);
            container.RegisterType<IAccountService, AccountService>(RegistrationType.Singleton);

            container.RegisterType<IConnection, HubConnection>(RegistrationType.Singleton, "ref", new InjectionConstructor($"http://{host}:{port}"));

            var hubConnection = (HubConnection)Container.Instance.Resolve<IConnection>("ref");

            var securityHub = hubConnection.CreateHubProxy<ISignalRHub, ISignalRClient<SignalRPacket<Security>>>("securityHub");
            container.RegisterInstance(securityHub);

            container.RegisterType<IMessagingClient<SignalRPacket<Security>>, SignalRClient<SignalRPacket<Security>>>(RegistrationType.Singleton, 
                new InjectionConstructor(hubConnection, securityHub));

            var logger = container.Resolve<ILogger>();
            try
            {
                hubConnection.Error += exception => logger.Error($"{exception.Message}\n{exception.StackTrace}");
                hubConnection.StateChanged += change => logger.Info($"Connection changes old state {change.OldState.ToString()}, new state {change.NewState.ToString()}");

                hubConnection.Credentials = CredentialCache.DefaultCredentials;
                hubConnection.EnsureReconnecting();
                hubConnection.Start().Wait();
            }
            catch (Exception ex)
            {
              logger.Error("Hub initalizatoion failed.", ex);
            }
        }
    }
}