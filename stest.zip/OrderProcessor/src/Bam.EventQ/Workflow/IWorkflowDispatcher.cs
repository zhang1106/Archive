﻿using System.Collections.Generic;

namespace Bam.EventQ.Workflow
{
    public interface IWorkflowDispatcher<in TIn, out TOut>
    {
        IReadOnlyList<TOut> Dispatch(TIn input, long sequence, bool isReplay);
    }
}