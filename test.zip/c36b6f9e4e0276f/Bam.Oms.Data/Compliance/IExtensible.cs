﻿namespace Bam.Oms.Data.Compliance
{
    public interface IExtensible
    {
        string Type { get; }
        string ParamsInJson { get; }
     }
}
