using System.Collections.Generic;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public interface IOrderValidator
    {
        void ValidateOrders(SubmitOrders orders);
        IList<string> PopulateReferenceData(SubmitOrders orders);
    }
}