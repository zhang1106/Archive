﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;

namespace Bam.Oms.OrderGateway.EzeGateway.Services
{
    public class EzeTradeComparer : IComparer<Trade>
    {
        public int Compare(Trade x, Trade y)
        {
            // sort by closing orders first, then opening orders

            if ((x.Action == TradeAction.Cover || x.Action == TradeAction.Sell) &&
                (y.Action != TradeAction.Cover && y.Action != TradeAction.Sell))
            {
                return -1;
            }

            if ((y.Action == TradeAction.Cover || y.Action == TradeAction.Sell) &&
                (x.Action != TradeAction.Cover && x.Action != TradeAction.Sell))
            {
                return 1;
            }

            return 0;
        }
    }
}