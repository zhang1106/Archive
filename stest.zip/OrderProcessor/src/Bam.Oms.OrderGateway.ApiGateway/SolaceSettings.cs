﻿using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class SolaceSettings : AppSettingsBase
    {
        public SolaceSettings() : base("ApiGateway.Solace.")
        {

        }

        public SolCacheSettings Cache { get; } = new SolCacheSettings();

        public string Vpn
        {
            get { return GetValue(() => Vpn); }
        }

        public string Username
        {
            get { return GetValue(() => Username); }
        }

        public string Password
        {
            get { return GetValue(() => Password); }
        }

        public string Host
        {
            get { return GetValue(() => Host); }
        }

        public bool GenerateSequenceNumbers
        {
            get { return GetValue(() => GenerateSequenceNumbers); }
        }

        public bool PublishPositions
        {
            get { return GetValue(() => PublishPositions, true); }
        }

        public bool PublishTrades
        {
            get { return GetValue(() => PublishTrades, true); }
        }

        public bool PublishOrders
        {
            get { return GetValue(() => PublishOrders, true); }
        }

        public string PositionBaseTopic
        {
            get { return GetValue(() => PositionBaseTopic); }
        }

        public string TradeBaseTopic
        {
            get { return GetValue(() => TradeBaseTopic); }
        }

        public string OrderBaseTopic
        {
            get { return GetValue(() => OrderBaseTopic); }
        }

        public string SystemEventBaseTopic
        {
            get { return GetValue(() => SystemEventBaseTopic); }
        }

        public string[] TopicsToFlushOnRoll
        {
            get { return GetValue(() => TopicsToFlushOnRoll); }
        }
    }
}
