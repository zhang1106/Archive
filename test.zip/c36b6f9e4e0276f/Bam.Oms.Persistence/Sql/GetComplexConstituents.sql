﻿Create PROCEDURE [compliance].[GetComplexConstituents]
   @AsOfDate	datetime = null
As

Begin

If @AsOfDate is null
select @AsOfDate=getdate()

SET NOCOUNT ON
DECLARE @MaxDate DATETIME = BamCore.[dbo].[MaxDate]()
	
SELECT  Parent = s.displaycode,
		Symbol = cs.displaycode,
		bc.Allocation 
FROM BamCore.sm.Security s WITH (NOLOCK) 
INNER JOIN BamCore.sm.BasketSecurity bs WITH (NOLOCK) ON  s.SecurityId = bs.SecurityId
INNER JOIN BamCore.sm.BasketSource bsc WITH (NOLOCK) ON bsc.BasketSourceId = bs.BasketSourceId
INNER JOIN BamCore.sm.BasketComponentTimeSeries bst WITH (NOLOCK) ON bst.BasketSecurityId = bs.BasketSecurityId AND 
			@AsOfDate BETWEEN bst.EffectiveStartDate AND bst.EffectiveEndDate AND KnowledgeEndDate = @MaxDate
INNER JOIN BamCore.sm.BasketComponent bc WITH (NOLOCK) ON bc.BasketComponentTimeSeriesId = bst.BasketComponentTimeSeriesId
INNER JOIN BamCore.sm.Security cs WITH (NOLOCK) ON cs.SecurityId = bc.SecurityId
 

End

	 
	 


 