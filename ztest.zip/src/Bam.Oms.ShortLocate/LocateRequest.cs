﻿using System;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.ShortLocate
{
    public class LocateRequest : ILocateRequest
    {
        public IOrder Order { get; private set; }

        public string Broker { get; private set; }

        public LocateRequest(IOrder order, string broker)
        {
            if (order == null) throw new ArgumentNullException("order");
            if (broker == null) throw new ArgumentNullException("broker");

            Order = order;
            Broker = broker;
        }

        public bool Equals(ILocateRequest other)
        {
            return other != null && other.Order.Equals(Order) && other.Broker.Equals(Broker);
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as ILocateRequest);
        }

        public override int GetHashCode()
        {
            return unchecked (Order.GetHashCode()*Broker.GetHashCode());
        }
    }
}