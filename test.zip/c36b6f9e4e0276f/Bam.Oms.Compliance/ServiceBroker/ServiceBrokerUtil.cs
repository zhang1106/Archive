﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Compliance.ServiceBroker
{
    public class ServiceBrokerUtil
    {
        public static byte[] GetMessage(string queueName, SqlConnection con, TimeSpan timeout)
        {
            using (var r = GetMessageBatch(queueName, con, timeout, 1))
            {
                if (r == null || !r.HasRows)  return null;
                r.Read();
                var body = r.GetSqlBinary(r.GetOrdinal("message_body"));
                return body.Value;
            }
        }

        internal static void EndConversation(Guid conversationHandle, SqlConnection con)
        {
            const string sql = "END CONVERSATION @ConversationHandle;";

            using (var cmd = new SqlCommand(sql, con))
            {
                var pConversation = cmd.Parameters.Add("@ConversationHandle", SqlDbType.UniqueIdentifier);
                pConversation.Value = conversationHandle;
                cmd.ExecuteNonQuery();
            }
            
        }


        private static SqlDataReader GetMessageBatch(string queueName, SqlConnection con, TimeSpan timeout, int maxMessages)
        {
            var sql = $@"
            waitfor( 
                RECEIVE top (@count) conversation_handle,service_name,message_type_name,message_body,message_sequence_number 
                FROM [{queueName}] 
                    ), timeout @timeout";
            var cmd = new SqlCommand(sql, con);

            var pCount = cmd.Parameters.Add("@count", SqlDbType.Int);
            pCount.Value = maxMessages;

            var pTimeout = cmd.Parameters.Add("@timeout", SqlDbType.Int);

            if (timeout == TimeSpan.MaxValue)
            {
                pTimeout.Value = -1;
            }
            else
            {
                pTimeout.Value = (int)timeout.TotalMilliseconds;
            }

            cmd.CommandTimeout = 0; //honor the RECIEVE timeout, whatever it is.


            return cmd.ExecuteReader();
        }

    }
}
