﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Bam.Locate.Hub.Data;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.EndPoints;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.Persistence.Contingency;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.PositionTracker;
using Bam.Oms.RefData;
using Bam.Oms.ShortLocate;
using Bam.Oms.SodPosition.Svc;
using Bam.Oms.TradeMarker;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Microsoft.Practices.ObjectBuilder2;
using Newtonsoft.Json;

namespace Bam.Oms.Service.Orders
{
    public class FlowManager : IFlowManager
    {
        private readonly ISettings _settings;
        private readonly ILogger _logger;
        private readonly ILoggingAgent _eventLogger;
        private readonly ILocateService _locateService;
        private readonly IEmsRouter _emsRouter;
        private readonly ISodPositionEdit _sodPositionEdit;
        private readonly IOrderRepository _orderRepository;
        private readonly ITradeRepository _tradeRepository;
        private readonly IClientOrderIdRepository _clientOrderIdRepository;
        private readonly ISecurityRepository _securityRepository;
        private readonly IFlowClient[] _flowClients;
        private readonly IRollClient[] _rollClients;
        private readonly IDateProvider _dateProvider;

        private readonly IDictionary<string, IStripedProcessor> _stripedProcessors = new Dictionary<string, IStripedProcessor>();
        private readonly ReaderWriterLockSlim _stripedProcessorLockSlim = new ReaderWriterLockSlim();

        public event Action FlowManagerInitialized;
        public event Action<IOrder> OrderStateChanged;
        public event Action<IList<IOrder>> OrdersStateChanged;
        public event Action<ITrade> TradeStateChanged;
        public event Action<IList<ITrade>> TradesStateChanged;
        public event Action<IList<Order>> OrdersOnEOD;
        public event Action<IList<Trade>> TradesOnEOD;
        public event Action<IList<Position>> PositionsOnEOD;
        public event Action<DateTime> SODRolled;

        public FlowManager(IEmsRouter emsRouter, ILocateService locateService, ISodPositionEdit sodPositionEdit, IOrderRepository orderRepository, ITradeRepository tradeRepository, ISecurityRepository securityRepository, IClientOrderIdRepository clientOrderIdRepository, IFlowClient[] flowClients, IRollClient[] rollClients, IDateProvider dateProvider, ISettings settings, ILogger logger, ILoggingAgent eventLogger)
        {
            if (locateService == null) throw new ArgumentNullException(nameof(locateService));
            _settings = settings;
            _logger = logger;
            _eventLogger = eventLogger;

            _locateService = locateService;
            _emsRouter = emsRouter;
            _sodPositionEdit = sodPositionEdit;
            _orderRepository = orderRepository;
            _tradeRepository = tradeRepository;
            _securityRepository = securityRepository;
            _clientOrderIdRepository = clientOrderIdRepository;
            _flowClients = flowClients;
            _rollClients = rollClients;
            _dateProvider = dateProvider;

            _sodPositionEdit.SodPositionLoad += SodPositionEditSodPositionLoad;
            _sodPositionEdit.SodPositionUpdated += SodPositionEditSodPositionUpdated;

            _emsRouter.RollStarted += EmsRouterRollStarted;
            _emsRouter.RollCompleted += EmsRouterRollCompleted;

            _locateService.LocateAssignmentUpdated += LocateAssignmentUpdated;
        }

        private void LocateAssignmentUpdated(IList<TradeAssignment> assignments)
        {
            var updatedOrders = new List<Order>();

            foreach (var tradeAssignment in assignments)
            {
                var currentOrder = _orderRepository.Get(tradeAssignment.TradeId);

                //not sure if this is possible
                if (currentOrder == null)
                {
                    _logger.Warn($"Received locate assignment for order id that does not exist in order repo {tradeAssignment.TradeId}");
                    continue;
                }

                currentOrder.OrderStatus = tradeAssignment.BrokerLocateStatus == BrokerLocateStatus.Approved
                    ? BamOrderStatus.PendingSend
                    : tradeAssignment.BrokerLocateStatus == BrokerLocateStatus.Pending ? BamOrderStatus.PendingLocate : BamOrderStatus.IncompleteLocate;

                currentOrder.LocateStatus = (LocateStatus?)tradeAssignment.BrokerLocateStatus;

                foreach (var requestItem in tradeAssignment.Approvals)
                {
                    if (requestItem.LocateId == null)
                    {
                        _logger.Warn("Locate approval item cannot have a null locateId");
                        continue;
                    }

                    if (currentOrder.Locate == null)
                        currentOrder.Locate = new List<Data.Orders.Locate>();

                    var existingLocate = currentOrder.Locate.FirstOrDefault(r => r.LocateId == requestItem.LocateId);
                    if (existingLocate == null)
                    {
                        existingLocate = new Data.Orders.Locate() { LocateId = requestItem.LocateId };
                        currentOrder.Locate.Add(existingLocate);
                    }

                    existingLocate.AssignmentId = requestItem.ApprovalId;
                    existingLocate.Size = requestItem.Size;
                    existingLocate.PrimeBroker = requestItem.Broker;
                    existingLocate.Rate = requestItem.Rate;
                    if (requestItem.RateType != null)
                        existingLocate.RateType = requestItem.RateType == "R" ? RateType.Rebate : RateType.Fee;
                    existingLocate.TimeReceived = requestItem.ResponseTime;
                }

                //if the order is now fully located, allow the OG to send it to flex based on routed size > 0
                if (currentOrder.OrderStatus == BamOrderStatus.PendingSend)
                    currentOrder.RoutedSize = currentOrder.Size;

                updatedOrders.Add(currentOrder);
            }

            _orderRepository.Save(updatedOrders);
        }

        public void Initialize()
        {
            Task.Factory.StartNew(() =>
            {
                var sw = new Stopwatch();
                sw.Start();

                _logger.Info("Connecting to EMS.....");
                //Connect to FLEX                
                while (!_emsRouter.Connect())
                {
                    _logger.Error($"Failed connecting to EMS. Will retry in {_settings.ConnectionRetryInterval} seconds.");
                    Thread.Sleep(_settings.ConnectionRetryInterval * 1000);
                }
                _logger.Info("Successfully connected to EMS.");

                IList<IPosition> sodPositions = _sodPositionEdit.GetPositions(userId: null, asofdate: null,
                        stream: null, fundCode: null, custodianAccountCode: null, strategyCode: null, securityType: null,
                        bamSymbol: null);
                _logger.Info($"************************BEGIN BAM SOD Position dump*************************************");

                foreach (var position in sodPositions)
                {
                    _logger.Info($"BAM_SOD_POSITION|Portfolio:{position.Portfolio.ToString()};Security:{position.Security.BamSymbol};Actual:{position.SignedActualQuantity};Theo:{position.SignedTheoreticalQuantity};LongMarking:{position.SignedLongMarkingQuantity};ShortMarking:{position.SignedShortMarkingQuantity}.");
                }

                _logger.Info($"************************END BAM SOD Position dump*************************************");


                _logger.Info("Getting SOD positions...");
                DateTime emsBusinessDate = _emsRouter.GetBusinessDate();
                DateTime sodPositionDate = sodPositions.First().EntryDate;
                _logger.Info(
                    $"EMS Business date is {emsBusinessDate}. SOD Position Date is {sodPositionDate}");
                if (!DateTime.MinValue.Equals(emsBusinessDate) && !emsBusinessDate.Equals(sodPositionDate))
                {
                    sodPositions = GetPositionsFromEms();
                }

                var positionSymGroups = sodPositions.GroupBy(position => position.Security.Key).Select(g => new
                {
                    g.Key,
                    RecordCount = g.Count()
                }).OrderBy(a => a.RecordCount).ToList();

                _logger.Info($"Finished getting SOD positions. Total Count {sodPositions.Count}");

                _logger.Info("Getting cached orders...");
                IList<Order> ordersInCache = _orderRepository.Get(_settings.SODDateTime).ToList();
                _logger.Info($"************************BEGIN Order dump*************************************");
                foreach (var order in ordersInCache)
                {
                    _logger.Info($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] Portfolio:{order.Portfolio.ToString()};Security:{order.Security.BamSymbol};Quantity:{order.Size}[{order.Side};Order Status:{order.OrderStatus}.");
                }
                _logger.Info($"************************END Order dump*************************************");

                var orderSymGroups = ordersInCache.GroupBy(order => order.Security.Key).Select(g => new
                {
                    g.Key,
                    RecordCount = g.Count()
                }).OrderBy(a => a.RecordCount).ToList();

                _logger.Info($"Finished getting orders from cache. Total Count {ordersInCache.Count}");

                _logger.Info("Getting cached trades...");
                IList<Trade> tradesInCache = _tradeRepository.Get(_settings.SODDateTime).ToList();
                var tradeSymGroups = tradesInCache.GroupBy(trade => trade.Security.Key).Select(g => new
                {
                    g.Key,
                    RecordCount = g.Count()
                }).OrderBy(a => a.RecordCount).ToList();

                _logger.Info($"Finished getting trades from cache. Total Count {tradesInCache.Count}");

                //Clear the trade cache. We get the latest trade image for the current trade date from Flex.
                _tradeRepository.ClearAll();
                _tradeRepository.Flush();

                var symbolGroups =
                    positionSymGroups.Union(orderSymGroups).Union(tradeSymGroups).OrderByDescending(a => a.RecordCount).ToList();


                _logger.Info($"Setting up striped processors for {symbolGroups.Count} symbols...");
                foreach (var symbolGroup in symbolGroups)
                {
                    _logger.Info($"Setting up {symbolGroup.Key}...");
                    IStripedProcessor stripedProcessor = GetOrAssignProcessor(symbolGroup.Key);
                    stripedProcessor.SetInitialized(false);
                    stripedProcessor.TotalOrdersProcessed += symbolGroup.RecordCount;
                    _logger.Info($"Finished setting up {symbolGroup.Key}.");
                }
                _logger.Info("Finished setting up striped processors.");

                _logger.Info("Beginning recovery process...");
                _logger.Info("Subscribing to EMS....");
                if (!_emsRouter.Subscribe())
                {
                    _logger.Error("Subscrition to EMS failed.");
                    throw new ApplicationException("Subscription to EMS failed");
                }

                _logger.Info("Getting all orders from EMS...");
                IEnumerable<IOrder> ordersFromEms = _emsRouter.GetOpenOrders().ToList();
                _logger.Info($"Received {ordersFromEms.Count()} from EMS.");

                //Sync up order status and size from EMS
                foreach (IOrder order in ordersInCache)
                {
                    IOrder orderFromEms = ordersFromEms.FirstOrDefault(o => o.ClientOrderId == order.ClientOrderId);
                    if (orderFromEms != null)
                    {
                        order.OrderStatus = orderFromEms.OrderStatus;
                        order.StatusMessages.AddRange(orderFromEms.StatusMessages);
                        if (order.OrderStatus == BamOrderStatus.Finalized || order.OrderStatus == BamOrderStatus.Cancelled)
                        {                            
                            _logger.Info($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}: Order is FINALIZED or CANCELLED. Setting size to filled quantity [{orderFromEms.Size}. {order}.");
                            order.Size = order.RoutedSize = orderFromEms.Size;
                        }
                    }
                    else
                    {
                        _logger.Info($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}: Order is not in EMS. {order}.");
                        if (order.OrderStatus != BamOrderStatus.PendingValidation &&
                            order.OrderStatus != BamOrderStatus.Marked && order.OrderStatus != BamOrderStatus.Cancelled &&
                            order.OrderStatus != BamOrderStatus.Error)
                        {
                            order.StatusMessages.Add($"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}:Uknown to EMS");
                        }
                    }
                }

                _orderRepository.Save(ordersInCache);

                _logger.Info("Finished recovery process.");

                _logger.Info("Initializing position trackers....");
                //Initialize the position tracker after orders have been reconciled
                Container.Instance.ResolveAll<IPositionTracker>().AsParallel().ForAll(pt => pt.LoadSODPositions(sodPositions.Where(pos => pt.SubscribedSymbols.Contains(pos.Security.BamSymbol)), _orderRepository.GetAllOrders(), new Dictionary<IPositionKey, IList<ITrade>>())); // No need to use trades from cache. The GetOpenOrders call above replays trades.
                _logger.Info("Finished initializing position trackers.");

                //Signal all processors to continue processing events
                _stripedProcessors.Values.ForEach(sp => sp.SetInitialized(true));

                _logger.Info($"Order Handler initialized. Took {sw.Elapsed} to initialize handler.");

                FlowManagerInitialized?.Invoke();
                _locateService.SubscribeToLocates();
            });
        }

        private int Flush()
        {
            _logger.InfoFormat("Flush request received.");
            var count = _orderRepository.ClearAll();
            count += _tradeRepository.ClearAll();
            count += _securityRepository.ClearAll();
            count += _clientOrderIdRepository.ClearAll();

            IList<IPosition> sodPositions = _sodPositionEdit.GetPositions(userId: null, asofdate: null, stream: null, fundCode: null, custodianAccountCode: null, strategyCode: null, securityType: null, bamSymbol: null);
            SodPositionEditSodPositionLoad(sodPositions.Cast<Position>().ToList());
            _logger.InfoFormat("Flush request completed.");
            return count;
        }

        public IList<IOrder> ProcessOrders(List<IOrder> orders, string batchId = null)
        {
            var sw = new Stopwatch();
            var sw0 = new Stopwatch();

            string msg = $"[BatchId:{batchId}] begin processing {orders.Count} orders...";
            _logger.Info(msg);
            sw.Start();

            List<IOrder> markedOrders = new List<IOrder>();
            try
            {
                //Mark and Position Track
                sw0.Start();
                IList<IOrder> markedOrdersAll = MarkAndTrack(orders, batchId);
                _logger.Info($"[BatchId:{batchId}] Took {sw0.Elapsed} to mark {orders.Count} orders, resulted in {markedOrdersAll.Count} marked orders");
                sw0.Restart();
                markedOrders = GroupOrdersToProcess(markedOrdersAll, batchId);
                _logger.Info($"[BatchId:{batchId}] Took {sw0.Elapsed} to group orders");

                //Save State for the first time after marking and grouping for duplicates
                Task<IOrder>[] saveTasks = SaveState(markedOrders, batchId);

                if (markedOrders.Any(o => o.Side == SideType.SellShort))
                {
                    sw0.Restart();
                    //Locate shorts
                    markedOrders = LocateShorts(markedOrders, batchId);

                    _logger.Info(
                        $"[BatchId:{batchId}] Took {sw0.Elapsed} to get locate {markedOrders.Count(o => o.Side == SideType.SellShort)} sell short orders.");
                    sw0.Restart();

                }

                //Set state to Pending Send

                //exclude any pending locate orders
                markedOrders.Where(o=>o.OrderStatus != BamOrderStatus.PendingLocate).ForEach(o => o.OrderStatus = BamOrderStatus.PendingSend);

                saveTasks = saveTasks.Concat(SaveState(markedOrders, batchId)).ToArray();

                //Submit for execution
                if (markedOrders.Any())
                {
                    IList<IOrder> zeroOrders = markedOrders.Where(o => o.RoutedSize <= 0).ToList();

                    //Save State
                    saveTasks = saveTasks.Concat(SaveState(markedOrders, batchId)).ToArray();
                    Task.WaitAll(saveTasks);
                    _orderRepository.Flush();

                    _logger.Info($"[BatchId:{batchId} ignoring {zeroOrders.Count} orders with RoutedSize <= 0. Ignored Orders: {JsonConvert.SerializeObject(zeroOrders.ToList())}.");
                    List<IOrder> ordersToSubmit = markedOrders.Except(zeroOrders).ToList();
                    if (ordersToSubmit.Any())
                    {
                        //EMS-196: Sort before submit
                        ordersToSubmit.Sort();
                        sw0.Restart();
                        markedOrders = SubmitOrders(ordersToSubmit, batchId);
                        //No need to save order state. Submit order publishes the state at the end to striped processors which saves the final state. 
                    }
                    else
                    {
                        _logger.Warn($"[BatchId:{batchId}] No orders to submit to FLEX.");
                    }

                    _logger.Info($"[BatchId:{batchId}] Took {sw0.Elapsed} to submit {ordersToSubmit.Count} orders.");
                    sw0.Restart();
                    Task.WaitAll(saveTasks);
                    msg = $"[BatchId:{batchId}] completed processing {markedOrders.Count} orders.";
                    _logger.Info(msg);
                    return markedOrders;
                }

                //We should never get here.
                _logger.Error($"[BatchId:{batchId}] No orders to submit for batch."); // Should never get here.
                //Set all orders to Rejected.
                orders.ForEach(o => o.OrderStatus = BamOrderStatus.Error);

                //Save State
                saveTasks = saveTasks.Concat(SaveState((List<IOrder>)orders, batchId)).ToArray();
                Task.WaitAll(saveTasks);
                return orders;
            }
            catch (AggregateException exceptions)
            {
                LogAndRevert(markedOrders, batchId);

                foreach (var ex in exceptions.InnerExceptions)
                {
                    _logger.Error($"[BatchId:{batchId}] Error processing orders, {JsonConvert.SerializeObject(orders.ToList())} {0}-{1}", ex);
                }
                orders.ForEach(o => o.OrderStatus = BamOrderStatus.Error);
                return orders;
            }
            catch (Exception ex)
            {
                LogAndRevert(markedOrders, batchId);

                _logger.Error($"[BatchId:{batchId}] Error processing orders, {JsonConvert.SerializeObject(orders.ToList())} {0}-{1}", ex);
                orders.ForEach(o => o.OrderStatus = BamOrderStatus.Error);
                return orders;
            }
            finally
            {
                _orderRepository.Flush(); // Flush at the end of processing
                sw.Stop();
                msg = $"[BatchId:{batchId}] took {sw.Elapsed} to process {orders.Count} orders.";
                _logger.Info(msg);
            }
        }

        private List<IOrder> GroupOrdersToProcess(IList<IOrder> orders, string batchId = null)
        {
            List<IOrder> ordersToProcess = orders.GroupBy(
                order =>
                    new
                    {
                        order.TradeDate,
                        order.SettleDate,
                        order.BatchId,
                        order.Portfolio,
                        order.Security,
                        order.Side,
                        order.Custodian,
                        order.Trader
                    })
                .Select(
                    g => (IOrder)
                        new Order
                        {
                            Trader = g.Key.Trader,
                            TradeDate = g.Key.TradeDate,
                            SettleDate = g.Key.SettleDate,
                            BatchId = g.Key.BatchId,
                            Portfolio = g.Key.Portfolio,
                            Security = g.Key.Security,
                            Side = g.Key.Side,
                            Custodian = g.Key.Custodian,
                            ExecutionInstructions =
                                new List<ExecutionInstruction>(g.SelectMany(o => o.ExecutionInstructions)),
                            Note = string.Join(",", g.Select(o => o.Note)),
                            ClientOrderId = g.Min(o => o.ClientOrderId),
                            RoutedSize = g.Sum(o => o.RoutedSize),
                            Size = g.Sum(o => o.Size),
                            Price = g.Sum(o => o.Size * o.Price) / g.Sum(o => o.Size),
                        }).ToList();

            List<IOrder> collapsedOrders = orders.Except(ordersToProcess).ToList();
            _logger.Info($"[BatchId:{batchId} collapsed {collapsedOrders.Count} orders into others on the same side. Collapsed Orders: {JsonConvert.SerializeObject(collapsedOrders.ToList())}.");
            Task<IOrder>[] deleteTasks =
                collapsedOrders.ConvertAll(order => (IOrder)order.Clone()).AsParallel().Select(async order => await GetOrAssignProcessor(order.Security.Key).DeleteOrderAsync(order, batchId))
                    .ToArray();
            _logger.Info($"[BatchId:{batchId}] processing {orders.Count} unique orders.");
            return ordersToProcess;
        }

        public IList<IOrder> ProcessOrder(string orderId)
        {
            try
            {
                IOrder orderToReRoute = _orderRepository.Get(orderId);
                if (orderToReRoute == null)
                {
                    _logger.Error($"[OrderId:{orderId}] cannot be rerouted. It is no longer found in the cache.");
                    return null;
                }
                _logger.Info($"[OrderId:{orderId}] Re-routing order with Id {orderId}.");
                Task<IList<IOrder>> ordersSent = GetOrAssignProcessor(orderToReRoute.Security.Key).ProcessOrderAsync(orderToReRoute, orderToReRoute.BatchId);

                return ordersSent.Result;
            }
            finally
            {
                _orderRepository.Flush();
            }
        }

        public IList<IOrder> ReplaceOrder(IOrder order)
        {
            try
            {
                _logger.Info($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] Replacing order {order}.");
                Task<IList<IOrder>> orderTasks = GetOrAssignProcessor(order.Security.Key).ReplaceOrderAsync(order);
                IList<IOrder> processedOrders = orderTasks.Result;
                return processedOrders;
            }
            finally
            {
                _orderRepository.Flush();
            }
        }

        public IList<IOrder> ProcessCancelOrders(IList<string> orderIds)
        {
            _logger.Info($"Cancelling {orderIds.Count} orders.");
            IList<IOrder> ordersToCancel = new List<IOrder>();
            foreach (string orderId in orderIds)
            {
                IOrder ordertoCancel = _orderRepository.Get(orderId);
                if (ordertoCancel != null)
                {
                    _logger.Info($"[OrderId:{ordertoCancel.ClientOrderId}] will be cancelled...");
                    ordersToCancel.Add(ordertoCancel);
                }
            }

            if (!ordersToCancel.Any())
            {
                _logger.Warn($"No orders in cache that can be cancelled.");
                return ordersToCancel;
            }
            try
            {
                //TODO: Parallel aggregation
                ConcurrentQueue<Task<IList<IOrder>>> cancelledOrdersTasks = new ConcurrentQueue<Task<IList<IOrder>>>();
                Parallel.ForEach(_stripedProcessors.Values.Distinct(), processor =>
                {
                    IList<IOrder> ordersForProcessor =
                        ordersToCancel.Where(o => processor.SubscribedSymbols.Contains(o.Security.BamSymbol)).ToList();
                    if (ordersForProcessor.Any())
                    {
                        Task<IList<IOrder>> cancelTask = processor.CancelOrderAsync(ordersForProcessor);
                        cancelledOrdersTasks.Enqueue(cancelTask);
                    }
                });

                _emsRouter.CancelOrders(orderIds);
                List<IOrder> cancelledOrders = new List<IOrder>();
                foreach (Task<IList<IOrder>> cancelTask in cancelledOrdersTasks)
                {
                    cancelledOrders.AddRange(cancelTask.Result);
                }
                return cancelledOrders;
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    string msg = $"Exception while cancelling orders {String.Join(",", orderIds)}.";
                    _logger.Error(msg, aex.Flatten());
                    return false;
                });
            }
            return new List<IOrder>();
        }

        private List<IOrder> SubmitOrders(List<IOrder> ordersToSubmit, string batchId)
        {
            string msg = $"[BatchId:{batchId}] submitting {ordersToSubmit.Count} orders to FLEX...";
            _logger.Info(msg);

            try
            {
                IEnumerable<IOrder> orderStatus = _emsRouter.SubmitOrders(ordersToSubmit);

                //Revert theoretical for any orders that were rejected or failed compliance
                int pendingOrderCount = ordersToSubmit.Count;
                if (orderStatus.Any())
                {
                    var failedOrders =
                        orderStatus.Where(
                            o =>
                                o.OrderStatus == BamOrderStatus.Error)
                            .ToList();
                    msg = $"[BatchId:{batchId}] {failedOrders.Count} orders failed submitting to FLEX.";
                    _logger.Info(msg);
                    pendingOrderCount -= failedOrders.Count;
                }

                msg = $"[BatchId:{batchId}] completed submitting {pendingOrderCount} orders to FLEX.";
                _logger.Info(msg);
            }
            catch (Exception ex)
            {
                msg = $"[BatchId:{batchId}] exception while submitting orders to FLEX.";
                ordersToSubmit.ForEach(o => o.OrderStatus = BamOrderStatus.Error);
                _logger.Error(msg, ex);
                var logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, batchId, BamSystem.OMS_GATEWAY);
                _eventLogger.SendFailedEvent(logEvent);
                throw;
            }

            //TODO: Write a "rejected" file or return rejects to the caller
            return ordersToSubmit;
        }
        public IList<IOrder> ProcessOrder(IOrder order, string batchId = null)
        {
            try
            {
                IStripedProcessor processor = this.GetOrAssignProcessor(order.Security.Key);
                return processor.ProcessOrder(order, batchId);
            }
            catch (Exception ex)
            {
                _logger.Error($"[BatchId:{batchId},[OrderId:{order.ClientOrderId}] Exception processing order. {order}", ex);
            }
            finally
            {
                _orderRepository.Flush();
            }
            return new List<IOrder>();
        }

        public DateTime RollSod(DateTime? dateTimeToRollTo)
        {
            string msg = "OG Roll Started";
            _logger.Info(msg);
            var logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, null, BamSystem.OMS_GATEWAY);
            _eventLogger.SendPendingEvent(logEvent);


            #region Publish to Listeners
            _rollClients?.ForEach(fc => fc.PublishOrders(_orderRepository.Get(_settings.SODDateTime).Cast<IOrder>().ToList()));

            _rollClients?.ForEach(fc => fc.PublishTrades(_tradeRepository.Get(_settings.SODDateTime).Cast<ITrade>().ToList()));
            List<IPosition> eodPositions = new List<IPosition>();
            foreach (IPositionTracker positionTracker in Container.Instance.ResolveAll<IPositionTracker>())
            {
                eodPositions.AddRange(positionTracker.GetCurrentPositions());
            }
            _rollClients?.ForEach(fc => fc.PublishPositions(eodPositions));
            #endregion Publish to Listeners      

            int flushedItems = Flush();
            SetSodDateTime(dateTimeToRollTo);

            _logger.Info($"{flushedItems} items flushed from cache.  New SOD DateTime {_settings.SODDateTime:MM/dd/yy H:mm:ss zzz}");

            #region Reinitialize Position Trackers
            IList<IPosition> positions = GetPositionsFromEms(); //This shd give SOD positions after roll accordning to Rohit Pandey
            SodPositionEditSodPositionLoad(positions.Cast<Position>().ToList());
            #endregion Reinitialize Position Trackers

            msg = "OG Roll Completed";
            _logger.Info(msg);
            logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, _settings.SODDateTime.ToShortDateString(), BamSystem.OMS_GATEWAY);
            _eventLogger.SendSuccessEvent(logEvent);
            Utility.RaiseEvent(_settings.SODDateTime, SODRolled);
            return _settings.SODDateTime;

        }

        public IList<Position> ReplacePositions(IList<Position> positions)
        {
            List<Position> updatedPositions = new List<Position>();
            try
            {
                //TODO: Parallel aggregaation
                ConcurrentQueue<Task<IList<Position>>> updateTasks = new ConcurrentQueue<Task<IList<Position>>>();

                Parallel.ForEach(_stripedProcessors.Values.Distinct(), processor =>
                {
                    IList<Position> positionsForProcessor =
                        positions.Where(o => processor.SubscribedSymbols.Contains(o.Security.BamSymbol)).ToList();
                    if (positionsForProcessor.Any())
                    {
                        Task<IList<Position>> updateTask = processor.UpdatePositionsAsync(positionsForProcessor);
                        updateTasks.Enqueue(updateTask);
                    }
                });
                
                foreach (Task<IList<Position>> updateTask in updateTasks)
                {
                    updatedPositions.AddRange(updateTask.Result);
                }
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error($"Error updating positions.", ex);
                    return false;
                });
            }
            return updatedPositions;
        }

        private Task<IOrder>[] SaveState(List<IOrder> orders, string batchId)
        {
            _logger.Info($"[BatchId:{batchId}] Saving state for orders in batch.");
            List<IOrder> ordersToPublish = orders.ConvertAll(order => (IOrder)order.Clone());

            Task<IOrder>[] saveTasks =
                ordersToPublish.ConvertAll(order => (IOrder)order.Clone()).AsParallel().Select(async order => await GetOrAssignProcessor(order.Security.Key).SaveOrderAsync(order, batchId))
                    .ToArray();
            _logger.Info($"[BatchId:{batchId}] Completed submitting saving state for orders in batch.");
            return saveTasks;
        }

        private IList<IOrder> MarkAndTrack(IList<IOrder> orders, string batchId = null)
        {
            string msg = $"[BatchId:{batchId}] begin marking and position tracking...";
            _logger.Info(msg);

            #region Symbols not in SOD
            //Cater to any symbols that are not part of the SOD positions.
            //NOTE: This could hit performance if we have symbols not in SOd position too often. We will deal with efficiency later.             
            List<string> orderSymbols = orders.Select(o => o.Security.BamSymbol).ToList();
            foreach (string symbol in orderSymbols.Except(_stripedProcessors.Keys))
            {
                _logger.Info($"No SOD position for symbol {symbol}. Creating and assigning processor for it.");
                IStripedProcessor processor = GetOrAssignProcessor(symbol);
                _logger.Info($"Completed  creating and assigning processor for symbol {symbol}.");
            }
            #endregion Symbols not in SOD

            List<IOrder> markedOrders = new List<IOrder>();
            try
            {
                //TODO: Parallel aggregaation
                ConcurrentQueue<Task<IList<IOrder>>> markingTasks = new ConcurrentQueue<Task<IList<IOrder>>>();

                Parallel.ForEach(_stripedProcessors.Values.Distinct(), processor =>
                {
                    IList<IOrder> ordersForProcessor =
                        orders.Where(o => processor.SubscribedSymbols.Contains(o.Security.BamSymbol)).ToList();
                    if (ordersForProcessor.Any())
                    {
                        Task<IList<IOrder>> markingTask = processor.MarkOrderAsync(ordersForProcessor, batchId);
                        markingTasks.Enqueue(markingTask);
                    }
                });

                foreach (Task<IList<IOrder>> markingTask in markingTasks)
                {
                    markedOrders.AddRange(markingTask.Result);
                }

                msg = $"[BatchId:{batchId}] marking and position tracking complete.";
                _logger.Info(msg);
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    msg = $"[BatchId:{batchId}] exception while marking and position tracking.";
                    _logger.Error(msg, aex.Flatten());
                    var logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, batchId, BamSystem.OMS_GATEWAY);
                    _eventLogger.SendFailedEvent(logEvent);
                    return false;
                });
            }
            return markedOrders;
        }

        //TODO: Move this to the striped processor if shortlocate service supports concurrent requests from multiple threads.
        private List<IOrder> LocateShorts(List<IOrder> markedOrders, string batchId = null)
        {
            string msg = $"[BatchId:{batchId}] begin short locate...";
            _logger.Info(msg);
            try
            {
                //make a sync call to get shorts
                var shortOrders = markedOrders.Where(o => o.Side == SideType.SellShort);
                shortOrders.ForEach(o => o.RoutedSize = 0);

                msg = $"[BatchId:{ batchId}] requesting locate for {shortOrders.Count()} short orders.";
                _logger.Info(msg);

                var fullyLocatedShortOrders = LocateShortForOrdersWrap(shortOrders);

                //set the routed size for all these trades
                foreach (var orderToSubmit in fullyLocatedShortOrders.Where(r => r.LocateStatus == LocateStatus.Approved))
                {
                    orderToSubmit.RoutedSize = orderToSubmit.Size;
                }

                shortOrders.Where(so => so.LocateStatus != LocateStatus.Approved).ForEach(o => { o.OrderStatus = BamOrderStatus.PendingLocate; });


                msg = $"[BatchId:{batchId}] completed short locate. {fullyLocatedShortOrders.Where(r => r.LocateStatus == LocateStatus.Approved).Count()} got full locates";
                _logger.Info(msg);
                return markedOrders;
            }
            catch (Exception ex)
            {
                msg = $"[BatchId:{batchId}] exception while getting locates.";
                _logger.Error(msg, ex);
                var logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, batchId, BamSystem.OMS_GATEWAY);
                _eventLogger.SendFailedEvent(logEvent);
                throw;
            }
        }

        //TODO: Move this to Short locate proxy/facade
        private IEnumerable<IOrder> LocateShortForOrdersWrap(IEnumerable<IOrder> shortOrders)
        {
            //request short locate, completely filled orders will go downstream
            var shortLocateRequests = shortOrders.Select(s => new LocateRequest(s, s.Custodian));

            if (!shortLocateRequests.Any()) return new List<IOrder>(); //return an empty list

            var locateResponses = _locateService.RequestForInventory(shortLocateRequests);
            return locateResponses;
        }

        private void LogAndRevert(IList<IOrder> markedOrders, string batchId)
        {
            string msg;
            DataFlowEvent logEvent;
            var failedOrders =
                markedOrders.Where(
                    o =>
                        o.OrderStatus == BamOrderStatus.Error || o.OrderStatus == BamOrderStatus.Marked || o.OrderStatus == BamOrderStatus.PendingSend)
                    .ToList();
            msg = $"[BatchId:{batchId}] {failedOrders.Count} orders failed submitting to FLEX.";
            _logger.Info(msg);
            logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY,
                DateTime.Now, msg,
                null, batchId, BamSystem.OMS_GATEWAY);
            _eventLogger.SendFailedEvent(logEvent);
            RevertMarkedOrders(markedOrders, batchId);
        }

        private void RevertMarkedOrders(IList<IOrder> markedOrders, string batchId)
        {
            string msg = $"[BatchId:{batchId}] reverting marking for {markedOrders.Count} orders...";
            _logger.Info(msg);
            try
            {
                var revertTasks =
                    markedOrders.Select(
                        async order =>
                            await GetOrAssignProcessor(order.Security.Key).RevertOrderAsync(order, batchId))
                        .ToList();
                Task.WaitAll(revertTasks?.ToArray());
                msg = $"[BatchId:{batchId}] completed reverting marking for {markedOrders.Count} orders.";
                _logger.Info(msg);
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    msg = $"[BatchId:{batchId}] exception while reverting marking.";
                    _logger.Error(msg, aex.Flatten());
                    var logEvent = new DataFlowEvent(EventCategory.Order, batchId, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, batchId, BamSystem.OMS_GATEWAY);
                    _eventLogger.SendFailedEvent(logEvent);
                    return true; // mark as handled
                });
            }
        }

        private IStripedProcessor GetOrAssignProcessor(string symbol)
        {
            IStripedProcessor stripedProcessor = null;
            _stripedProcessorLockSlim.EnterUpgradeableReadLock();
            try
            {
                if (!_stripedProcessors.TryGetValue(symbol, out stripedProcessor))
                {
                    if (_stripedProcessors.Count >= _settings.MaxStripedProcessors)
                    {
                        stripedProcessor =
                            _stripedProcessors.Values.Aggregate(
                                (holder, x) => (x.TotalOrdersProcessed < holder.TotalOrdersProcessed ? x : holder));
                    }
                    else
                    {
                        stripedProcessor = CreateStripedProcessor(symbol);
                    }
                    _stripedProcessorLockSlim.EnterWriteLock();
                    try
                    {
                        stripedProcessor.AddSubscribedSymbol(symbol);
                        _stripedProcessors.Add(symbol, stripedProcessor);
                    }
                    finally
                    {
                        _stripedProcessorLockSlim.ExitWriteLock();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Error assigning striped processor for {symbol}.", ex);
                throw;
            }
            finally
            {
                _stripedProcessorLockSlim.ExitUpgradeableReadLock();
            }

            return stripedProcessor;

        }

        private IStripedProcessor CreateStripedProcessor(string symbol)
        {

            IOrderRepository orderRepository =
                BAM.Infrastructure.Ioc.Container.Instance.Resolve<IOrderRepository>();
            ITradeRepository tradeRepository =
                BAM.Infrastructure.Ioc.Container.Instance.Resolve<ITradeRepository>();

            BAM.Infrastructure.Ioc.Container.Instance
                .RegisterType<IPositionTracker, PositionTracker.PositionTracker>(
                    RegistrationType.Singleton, symbol,
                    new InjectionConstructor(orderRepository, tradeRepository,
                        typeof(IContingencyDbRepository),
                        typeof(ISodPositionEdit), typeof(ILogger), typeof(ILoggingAgent),
                        typeof(ISettings)), new InjectionMethod("StartContingencyTask"));

            IPositionTracker positionTracker =
                BAM.Infrastructure.Ioc.Container.Instance.Resolve<IPositionTracker>(symbol);

            BAM.Infrastructure.Ioc.Container.Instance.RegisterType<IOrderMarker, OrderMarker>(RegistrationType.Singleton, symbol,
                new InjectionConstructor(positionTracker, typeof(ILogger), typeof(IClientOrderIdRepository),
                    typeof(ILoggingAgent)));

            IOrderMarker orderMarker =
                BAM.Infrastructure.Ioc.Container.Instance.Resolve<IOrderMarker>(symbol);

            IEmsRouter emsRouter =
                BAM.Infrastructure.Ioc.Container.Instance.Resolve<IEmsRouter>();
            ILocateService locateService =
                BAM.Infrastructure.Ioc.Container.Instance.Resolve<ILocateService>();

            IAccountService accountService = Container.Instance.Resolve<IAccountService>();
            IStripedProcessor stripedProcessor = new StripedProcessor(emsRouter, locateService, positionTracker,
                orderMarker, orderRepository, tradeRepository, accountService, _settings, _logger);

            stripedProcessor.OrderStatusChanged += StripedProcessorOrderStatusChanged;
            stripedProcessor.OrdersStatusChanged += StripedProcessorOrdersStatusChanged;
            stripedProcessor.TradeStatusChanged += StripedProcessorTradeStatusChanged;
            stripedProcessor.TradesStatusChanged += StripedProcessorTradesStatusChanged;

            return stripedProcessor;
        }

        private void SetSodDateTime(DateTime? dateTimeToRollTo)
        {
            if (!dateTimeToRollTo.HasValue)
            {
                dateTimeToRollTo = _dateProvider.SetSodTime();
                _logger.Info($"Rolldate set to {dateTimeToRollTo:MM/dd/yy H:mm:ss zzz}");
            }
            else
            {
                dateTimeToRollTo = _dateProvider.SetSodTime(null, dateTimeToRollTo.Value);
            }

            _settings.SODDateTime = dateTimeToRollTo.Value.ToLocalTime();
            _logger.Info($"Sod Date time is set to {_settings.SODDateTime:MM/dd/yy H:mm:ss zzz}.");
        }

        private void SodPositionUpdate(IList<Position> sodPositions, Func<IStripedProcessor, IList<Position>, Task<IList<Position>>> func)
        {
            #region Symbols not in SOD

            //Create and assign processors for all symbols in the SOD list.
            //NOTE: This could hit performance if we have symbols not in SOd position too often. We will deal with efficiency later.             
            List<string> sodSymbols = sodPositions.Select(o => o.Security.BamSymbol).ToList();
            foreach (string symbol in sodSymbols.Except(_stripedProcessors.Keys))
            {
                _logger.Info($"SOD position received for symbol {symbol}. Creating and assigning processor for it.");
                IStripedProcessor processor = GetOrAssignProcessor(symbol);
                _logger.Info($"Completed  creating and assigning processor for symbol {symbol}.");
            }

            #endregion Symbols not in SOD

            try
            {
                //TODO: Parallel aggregation
                ConcurrentQueue<Task<IList<Position>>> sodUpdateTasks = new ConcurrentQueue<Task<IList<Position>>>();

                Parallel.ForEach(_stripedProcessors.Values.Distinct(), processor =>
                {
                    IList<Position> positionsForProcessor =
                        sodPositions.Where(o => processor.SubscribedSymbols.Contains(o.Security.BamSymbol)).ToList();
                    if (positionsForProcessor.Any())
                    {
                        Task<IList<Position>> sodUpdateTask = func(processor, positionsForProcessor);
                        sodUpdateTasks.Enqueue(sodUpdateTask);
                    }
                });

                Task.WaitAll(sodUpdateTasks.ToArray());
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    string msg = $"[Exception while loading SOD Positions.";
                    _logger.Error(msg, aex.Flatten());
                    var logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, JsonConvert.SerializeObject(sodPositions), BamSystem.OMS_GATEWAY);
                    _eventLogger.SendFailedEvent(logEvent);
                    return false;
                });
            }
        }

        private IList<IPosition> GetPositionsFromEms()
        {
            _logger.Info("Loading positions from EMS.");
            IList<IPosition> sodPositions = _emsRouter.GetSodPositions();
            _logger.Info($"************************BEGIN EMS SOD Position dump*************************************");
            foreach (var position in sodPositions)
            {
                _logger.Info(
                    $"EMS_SOD_POSITION|Portfolio:{position.Portfolio.ToString()};Security:{position.Security.BamSymbol};Actual:{position.SignedActualQuantity};Theo:{position.SignedTheoreticalQuantity};LongMarking:{position.SignedLongMarkingQuantity};ShortMarking:{position.SignedShortMarkingQuantity}.");
            }
            _logger.Info($"************************END EMS SOD Position dump*************************************");

            sodPositions = sodPositions.GroupBy(position =>
                new
                {
                    position.Portfolio,
                    position.Security,
                    position.CustodianName
                })
                .Select(
                    g => (IPosition)
                        new Position
                        {
                            Portfolio = g.Key.Portfolio,
                            Security = g.Key.Security,
                            CustodianName = g.Key.CustodianName,
                            SignedTheoreticalQuantity = g.Sum(pos => pos.SignedTheoreticalQuantity.GetValueOrDefault()),
                            SignedActualQuantity = g.Sum(pos => pos.SignedActualQuantity.GetValueOrDefault()),
                            SignedShortMarkingQuantity = g.Sum(pos => pos.SignedShortMarkingQuantity.GetValueOrDefault()),
                            SignedLongMarkingQuantity = g.Sum(pos => pos.SignedLongMarkingQuantity.GetValueOrDefault()),
                        }).ToList();
            return sodPositions;
        }

        #region Event Handlers
        private void SodPositionEditSodPositionLoad(IList<Position> sodPositions)
        {
            SodPositionUpdate(sodPositions,
                (stripedProcessor, positions) => stripedProcessor.LoadSODPositionsAsync(positions));
        }

        private void SodPositionEditSodPositionUpdated(IList<Position> sodPositions)
        {
            SodPositionUpdate(sodPositions,
                (stripedProcessor, positions) => stripedProcessor.UpdateSODPositionsAsync(positions));
        }

        private void StripedProcessorTradesStatusChanged(IList<ITrade> trades)
        {
            Utility.RaiseEvent(trades, TradesStateChanged);
            Task.Run(() => _flowClients?.ForEach(fc => fc.PublishTrades(trades)));
        }

        private void StripedProcessorTradeStatusChanged(ITrade trade)
        {
            StripedProcessorTradesStatusChanged(new List<ITrade>() { trade });
        }

        private void StripedProcessorOrdersStatusChanged(IList<IOrder> orders)
        {
            Utility.RaiseEvent(orders, OrdersStateChanged);
            Task.Run(() => _flowClients?.ForEach(fc => fc.PublishOrders(orders)));
        }

        private void StripedProcessorOrderStatusChanged(IOrder order)
        {
            StripedProcessorOrdersStatusChanged(new List<IOrder>() { order });
        }

        private void EmsRouterRollCompleted(string data)
        {
            _logger.InfoFormat($"FLEX Roll completed. {data}");
            var logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, "FLEX Roll Completed", null, data, BamSystem.OMS_GATEWAY);
            _eventLogger.SendSuccessEvent(logEvent);
            Task.Run(() => this.RollSod(null));
        }

        private void EmsRouterRollStarted(string data)
        {
            _logger.InfoFormat($"FLEX Roll started. {data}");
            var logEvent = new DataFlowEvent(EventCategory.Position, null, BamSystem.OMS_GATEWAY, DateTime.Now, "FLEX Roll Started", null, data, BamSystem.OMS_GATEWAY);
            _eventLogger.SendPendingEvent(logEvent);
        }
        #endregion Event Handlers

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _emsRouter.Disconnect();
                    _stripedProcessorLockSlim.EnterWriteLock();
                    try
                    {
                        _stripedProcessors.Values.ForEach(sp =>
                        {
                            sp.OrderStatusChanged -= StripedProcessorOrderStatusChanged;
                            sp.OrdersStatusChanged -= StripedProcessorOrdersStatusChanged;
                            sp.TradeStatusChanged -= StripedProcessorTradeStatusChanged;
                            sp.TradesStatusChanged -= StripedProcessorTradesStatusChanged;
                        });
                    }
                    finally
                    {
                        _stripedProcessorLockSlim.ExitWriteLock();
                    }
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~flowManager() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
