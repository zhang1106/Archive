using System;
using Bam.Oms.Data;
using Bam.Oms.Data.Portfolios;
using CsvHelper;
using CsvHelper.TypeConversion;

namespace Bam.Oms.EndPoints.File
{
    public class PortfolioConverter : ITypeConverter
    {
        public string ConvertToString(TypeConverterOptions options, object value)
        {
            return value.ToString();
        }

        public object ConvertFromString(TypeConverterOptions options, string text)
        {
            if (String.IsNullOrWhiteSpace(text))
            {
                throw new CsvBadDataException("Portfolio is missing. Portfolio is a mandatory field for an order.");
            }
            return Portfolio.Parse(text);
        }

        public bool CanConvertFrom(Type type)
        {
            return true;
        }

        public bool CanConvertTo(Type type)
        {
            return true;
        }
    }
}