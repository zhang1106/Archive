﻿using System;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Data.Securities
{
    public interface ISecurity : IEquatable<ISecurity>, IPersistentItem, IComparable<ISecurity>, IComparable
    {
        #region Additional attributes of interest

        SecurityType SecurityType { get; }
        string Currency { get; }
        string Issuer { get; }

        #endregion Attributes

        //Other identifiers

        #region Identifiers

        string BamSymbol { get; }
        string Ticker { get; }
        string Cusip { get; }
        string Isin { get; }
        string Sedol { get; }
        string BloombergSymbol { get; }

        #endregion Identifiers  

        string Country { get; }
        string Industry { get; }
        string UnderlyingSymbol { get; } // BamSymbol    
        decimal? ContractSize { get; }
        bool ActiveInd { get; }
        //enum
        //could be refactored to another entity
        OptionType OptionType { get; }
        bool IsBilateral { get; }
        InvestmentType InvestmentType { get; }
        AssetType AssetType { get; }
        string AdrCode { get;  }
        decimal AdrRatio { get; }
        string TrackIndexCode { get; }
        bool IsComposite();
        bool IsEquityOption();
        bool IsAdr();
        bool IsEquity();
    }
}
