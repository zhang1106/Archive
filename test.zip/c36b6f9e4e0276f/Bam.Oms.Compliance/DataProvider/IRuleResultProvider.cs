﻿using System;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IRuleResultProvider 
    {
        IRuleResult GetRuleResult(int policyId, int ruleId, string bamSymbol);
        IRuleResult GetLastRuleResult(IRuleResult ruleResult, DateTime date);
        void Clear(DateTime utc);
    }
}
