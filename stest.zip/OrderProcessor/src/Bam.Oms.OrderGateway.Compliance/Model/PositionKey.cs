﻿using System;
using Bam.Oms.OrderGateway.Infrastructure;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public struct PositionKey : IEquatable<PositionKey>
    {
        private readonly int _hashCode;

        public PositionKey(Portfolio portfolio, string symbol)
        {
            Portfolio = portfolio;
            Symbol = string.Intern(symbol.ToUpper());

            unchecked
            {
                _hashCode = 
                    ((Portfolio?.GetHashCode() ?? 0) * 397) ^ 
                    (Symbol != null ? StringComparer.Ordinal.GetHashCode(Symbol) : 0);
            }
        }

        public Portfolio Portfolio { get; }
        public string Symbol { get; }

        public bool Equals(PositionKey other)
        {
            return ReferenceEquals(other.Symbol, Symbol) &&
                   Equals(Portfolio, other.Portfolio);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is PositionKey && Equals((PositionKey) obj);
        }

        public override int GetHashCode()
        {
            return _hashCode;
        }

        public static bool operator ==(PositionKey left, PositionKey right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(PositionKey left, PositionKey right)
        {
            return !left.Equals(right);
        }

        public override string ToString()
        {
            return $"{Symbol}@{Portfolio}";
        }
    }
}
