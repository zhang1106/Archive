﻿using Newtonsoft.Json;

namespace Bam.Oms.Data.Securities
{
    public class MarketData  
    {
        public string Symbol { get; set; }
        [JsonIgnore]
        public long? SharesOutstanding { get; set; }
        [JsonIgnore]
        public  decimal? Delta { get; set; }
        public decimal? PriceInDollar { get; set; }
        public string CountryOfRisk { get; set; }
   
        public string CountryOfSedo1 { get; set; }
        public string CountryOfDomicile { get; set; }
        public string ISIN { get; set; }
        public string GicIndustry { get; set; }
        public string SecurityType { get; set; }

        public override string ToString()
        {
            return $"Symbol:{Symbol} - Sharesoutstanding:{SharesOutstanding}";
        }
    }
}
