﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.Persistence.Trades
{
    public interface ITradeRepository : IPersistentRepository<BlockTrade>
    {
        IEnumerable<BlockTrade> GetByClientOrderId(string orderId);

        IDictionary<IPositionKey, IList<IBlockTrade>> GetAllTrades(Func<IBlockTrade, bool> predicate = null);
    }
}
