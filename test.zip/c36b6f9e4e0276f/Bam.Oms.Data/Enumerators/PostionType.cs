﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data.Enumerators
{
    public enum PositionType
    {
        [Enum(StringValue = "Sod")]
        Sod,
        [Enum(StringValue = "Intraday")]
        Intraday,
        [Enum(StringValue = "Eod")]
        Eod,
        [Enum(StringValue = "SodDecomposed")]
        SodDecomposed,
        [Enum(StringValue = "IntradayDecomposed")]
        IntradayDecomposed,
        [Enum(StringValue = "EodDecomposed")]
        EodDecomposed
    }
}
