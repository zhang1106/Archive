﻿namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface IRouteSubmission
    {
        void Route(long[] orderIds, string user);
    }
}