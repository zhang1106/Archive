﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Data.Orders
{
    public class Order
    {

        public Security Security { get; set; }

        public string OrderStatus { get; set; }

        public IList<ComplianceIssue> ComplianceFailures { get; set; }

        public bool IsNoHeadRoomOrder()
        {
            return OrderStatus=="ComplianceError" && ComplianceFailures != null && ComplianceFailures.Any(c => c.Description.Contains("No Headroom"));
        }
    }
}
