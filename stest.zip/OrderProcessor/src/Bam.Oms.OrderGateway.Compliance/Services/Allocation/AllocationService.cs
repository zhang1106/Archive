﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public class AllocationService : AllocationServiceBase, IAllocationService
    {
        private readonly IComplianceCache _complianceCache;
        private readonly StrategyAllocationService _strategyAllocationService;
        private readonly FundAllocationService _fundAllocationService;

        private readonly Dictionary<ProRataKey, long> _targetSums = new Dictionary<ProRataKey, long>();
        private readonly Dictionary<ProRataKey, long> _targetSumsSansOmni = new Dictionary<ProRataKey, long>();
        private readonly Dictionary<ProRataKey, long> _proRatedSums = new Dictionary<ProRataKey, long>();

        private readonly Dictionary<int, long> _remainder = new Dictionary<int, long>();
        private readonly List<int> _keys = new List<int>();

        private readonly Dictionary<int, FundAllocation> _openingMap = new Dictionary<int, FundAllocation>();
        private readonly Dictionary<int, FundAllocation> _closingMap = new Dictionary<int, FundAllocation>();

        private readonly Dictionary<int, long> _custodianMap = new Dictionary<int, long>();
        private readonly List<OrderAllocation> _openingAllocations = new List<OrderAllocation>();
        private readonly List<OrderAllocation> _closingAllocations = new List<OrderAllocation>();
        private readonly Dictionary<ProRataKey, OrderAllocation> _aggregateList = new Dictionary<ProRataKey, OrderAllocation>();

        public AllocationService(IReferenceDataService referenceDataService, IComplianceCache complianceCache)
        {
            _complianceCache = complianceCache;
            _strategyAllocationService = new StrategyAllocationService(
                referenceDataService, complianceCache);
            _fundAllocationService = new FundAllocationService(
                referenceDataService, complianceCache);
        }

        public bool TryAllocate(Order order,
            Dictionary<int, long> custodianAssignments,
            List<OrderAllocation> opening, List<OrderAllocation> closing, 
            out string message)
        {
            // Step 1: strategy allocation
            var strategyAllocations = new Dictionary<Portfolio, long>();
            if (!_strategyAllocationService.TryAllocate(order.TopLevelPortfolio,
                order.Security, order.Size, order.Side, strategyAllocations, out message))
            {
                return false;
            }

            // Step 2: fund allocation
            foreach (var portfolio in strategyAllocations.Keys)
            {
                _closingMap.Clear();
                _openingMap.Clear();

                if (!_fundAllocationService.TryAllocate(portfolio, order.Security,
                    strategyAllocations[portfolio], order.Side, order.FundAllocationOverride, 
                    _closingMap, _openingMap, out message))
                {
                    return false;
                }

                foreach (var item in _openingMap)
                {
                    opening.Add(new OrderAllocation
                    {
                        Portfolio = portfolio,
                        FundId = item.Key,
                        CustodianId = -1,
                        Quantity = item.Value.Quantity,
                        ClosingPortionSansOmni = item.Value.QuantitySansOmni,
                        Side = order.Side
                    });
                }

                foreach (var item in _closingMap)
                {
                    closing.Add(new OrderAllocation
                    {
                        Portfolio = portfolio,
                        FundId = item.Key,
                        CustodianId = -1,
                        Quantity = item.Value.Quantity,
                        ClosingPortionSansOmni = item.Value.QuantitySansOmni,
                        Side = order.Side
                    });
                }
            }

            // Step 3: custodian allocation
            AssignCustodians(order.Size, custodianAssignments, opening);
            AssignCustodians(order.Size, custodianAssignments, closing);
            
            message = null;
            return true;
        }


        public void SetOpeningClosingAllocation(Order order, List<OrderAllocation> orderAllocations)
        {
            if (order.ContainsClosingAllocations || order.ContainsOpeningAllocations)
                return;

            _openingAllocations.Clear();
            _closingAllocations.Clear();
            _custodianMap.Clear();

            foreach (var alloc in orderAllocations)
            {
                long current;
                if (!_custodianMap.TryGetValue(alloc.CustodianId, out current))
                {
                    _custodianMap[alloc.CustodianId] = alloc.Quantity;
                }
                else
                {
                    _custodianMap[alloc.CustodianId] = current + alloc.Quantity;
                }
            }

            foreach (var alloc in AggregateByFund(orderAllocations))
            {
                var key = new PositionKey(alloc.Portfolio, order.Security.Symbol);
                var buySide = !order.Side.IsSellSide();
                var pos = GetTheoreticalPosition(key, alloc.FundId);

                var opening = buySide && pos > 0 || !buySide && pos < 0 || pos == 0;

                if (opening)
                {
                    var openingPart = new OrderAllocation
                    {
                        FundId = alloc.FundId,
                        Portfolio = alloc.Portfolio,
                        Quantity = alloc.Quantity
                    };

                    _openingAllocations.Add(openingPart);
                }
                else
                {
                    pos = Math.Abs(pos);
                    var qty = Math.Abs(alloc.Quantity);
                    var diff = pos - qty;

                    //all closing, no need to split
                    if (diff >= 0)
                    {
                        var closingPart = new OrderAllocation
                        {
                            FundId = alloc.FundId,
                            Portfolio = alloc.Portfolio,
                            Quantity = alloc.Quantity
                        };

                        _closingAllocations.Add(closingPart);
                    }
                    else
                    {
                        var closingPart = new OrderAllocation
                        {
                            FundId = alloc.FundId,
                            Portfolio = alloc.Portfolio,
                            Quantity = pos
                        };

                        var openingPart = new OrderAllocation
                        {
                            FundId = alloc.FundId,
                            Portfolio = alloc.Portfolio,
                            Quantity = diff * -1
                        };

                        _closingAllocations.Add(closingPart);
                        _openingAllocations.Add(openingPart);
                    }
                }
            }

            AssignCustodians(order.Size, _custodianMap, _openingAllocations);
            AssignCustodians(order.Size, _custodianMap, _closingAllocations);

            order.SetOpeningAllocations(_openingAllocations);
            order.SetClosingAllocations(_closingAllocations);
        }

        private long GetTheoreticalPosition(PositionKey key, int fundId)
        {
            long qty = 0;
            var set = _complianceCache.GetPositionSet(key);
            foreach (var theoretical in set.Position.TheoreticalAllocations)
            {
                if (theoretical.Key.FundId == fundId)
                    qty += theoretical.Value.Quantity;
            }

            return qty;
        }

        private List<OrderAllocation> AggregateByFund(List<OrderAllocation> allocations)
        {
            _aggregateList.Clear();

            foreach (var allocation in allocations)
            {
                var key = new ProRataKey(allocation.Portfolio, allocation.FundId);
                OrderAllocation current;
                if (!_aggregateList.TryGetValue(key, out current))
                {
                    _aggregateList[key] = new OrderAllocation
                    {
                        FundId = allocation.FundId,
                        Portfolio = allocation.Portfolio,
                        Quantity = allocation.Quantity
                    };
                }
                else
                {
                    _aggregateList[key] = new OrderAllocation
                    {
                        FundId = allocation.FundId,
                        Portfolio = allocation.Portfolio,
                        Quantity = current.Quantity += allocation.Quantity
                    };
                }
            }

            return _aggregateList.Values.ToList();
        }

        private void AssignCustodians(long total,
            Dictionary<int, long> custodians, 
            List<OrderAllocation> allocations)
        {
            if (custodians.Count == 1)
            {
                int custodianId = custodians.First().Key;
                for (int i = 0; i < allocations.Count; i++)
                {
                    var alloc = allocations[i];
                    allocations[i] = new OrderAllocation
                    {
                        Portfolio = alloc.Portfolio,
                        Quantity = alloc.Quantity,
                        ClosingPortionSansOmni = alloc.ClosingPortionSansOmni,
                        CustodianId = custodianId,
                        FundId = alloc.FundId,
                        Side = alloc.Side
                    };
                }

                return;
            }

            _targetSums.Clear();
            _targetSumsSansOmni.Clear();
            _proRatedSums.Clear();

            int count = allocations.Count;
            for (int i = 0; i < count; i++)
            {
                var alloc = allocations[i];
                var key = new ProRataKey(alloc.Portfolio, alloc.FundId);
                
                long current;
                if (!_targetSums.TryGetValue(key, out current))
                {
                    _targetSums.Add(key, alloc.Quantity);
                }
                else
                {
                    _targetSums[key] = current + alloc.Quantity;
                }

                if (!_targetSumsSansOmni.TryGetValue(key, out current))
                {
                    _targetSumsSansOmni.Add(key, alloc.ClosingPortionSansOmni);
                }
                else
                {
                    _targetSumsSansOmni[key] = current + alloc.ClosingPortionSansOmni;
                }

                int j = 0;
                foreach (var assignment in custodians)
                {
                    var ratio = (double) assignment.Value / total;
                    long qty = (long) Math.Floor(alloc.Quantity * ratio);
                    long qtySansOmni = (long) Math.Floor(alloc.ClosingPortionSansOmni * ratio);
                    
                    var item = new OrderAllocation
                    {
                        Portfolio = alloc.Portfolio,
                        Quantity = qty,
                        ClosingPortionSansOmni = qtySansOmni,
                        CustodianId = assignment.Key,
                        FundId = alloc.FundId,
                        Side = alloc.Side
                    };

                    if (++j == custodians.Count)
                    {
                        allocations[i] = item;
                    }
                    else
                    {
                        allocations.Add(item);
                    }
                }
            }

            FixProRatedRoundingIssues(
                allocations, a => new ProRataKey(a.Portfolio, a.FundId),
                a => a.Quantity, _proRatedSums, _targetSums,
                QuantityDescendingComparer.Instance,
                (a,v) => new OrderAllocation
                {
                    Quantity = v,
                    Portfolio = a.Portfolio,
                    Side = a.Side,
                    CustodianId = a.CustodianId,
                    FundId = a.FundId,
                    ClosingPortionSansOmni = a.ClosingPortionSansOmni
                });

            FixProRatedRoundingIssues(
                allocations, a => new ProRataKey(a.Portfolio, a.FundId),
                a => a.ClosingPortionSansOmni, _proRatedSums, _targetSumsSansOmni,
                QuantityDescendingComparer.Instance,
                (a, v) => new OrderAllocation
                {
                    Quantity = a.Quantity,
                    Portfolio = a.Portfolio,
                    Side = a.Side,
                    CustodianId = a.CustodianId,
                    FundId = a.FundId,
                    ClosingPortionSansOmni = v
                });
        }
    }
}
