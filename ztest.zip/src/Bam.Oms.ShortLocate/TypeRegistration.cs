﻿using System.Configuration;
using System.Net;
using Bam.Locate.Hub.Data;
using Bam.Oms.Messaging;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR.Client;

namespace Bam.Oms.ShortLocate
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            var host = ConfigurationManager.AppSettings["locate_svc_url"];
            var port = ConfigurationManager.AppSettings["locate_svc_port"];

#if _BAM_WITH_LOGGING_INTERCEPTOR
            container.RegisterTypeWithLoggingInterfaceInterceptor<ILocateService, LocateService>(RegistrationType.Singleton);
#else
            container.RegisterType<ILocateService, LocateService>(RegistrationType.Singleton);
#endif
            container.RegisterType<IInventoryController, LocateHubProxy>(RegistrationType.Singleton, new InjectionConstructor(host, port));

            #region messaging connections    

            container.RegisterType<IConnection, HubConnection>(RegistrationType.Singleton,"excalibur", new InjectionConstructor($"http://{host}:{port}"));

            var hubConnection = (HubConnection) Container.Instance.Resolve<IConnection>("excalibur");

            var assignmentProxy = hubConnection.CreateHubProxy<ISignalRHub, ISignalRClient<SignalRPacket<TradeAssignment>>>("assignmentsHub");
            container.RegisterInstance(assignmentProxy);
            container.RegisterType<IMessagingClient<SignalRPacket<TradeAssignment>>, SignalRClient<SignalRPacket<TradeAssignment>>>(RegistrationType.Singleton,
                new InjectionConstructor(hubConnection, assignmentProxy));

            hubConnection.Credentials = CredentialCache.DefaultCredentials;
            hubConnection.EnsureReconnecting();
            hubConnection.Start().Wait();

            #endregion
        }
    }
}