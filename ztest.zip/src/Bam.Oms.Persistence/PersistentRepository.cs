﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data;
using Bam.Oms.Persistence.Journal;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Persistence
{
    public class PersistentRepository<T> : IPersistentRepository<T> where T : IPersistentItem
    {
        public string Name { get; }

        private readonly IEventJournal _eventJournal;
        private readonly ConcurrentDictionary<string, PersistentItem<T>> _cache = new ConcurrentDictionary<string, PersistentItem<T>>();

        //ONLY A PLACE HOLDER, TODO: REMOVE ONCE WE BREAK APART SAVE/GET INTERFACES
        //this is going to be refactored out, this is only for integrating the hub
        public event Action<IEnumerable<T>> ItemSaved;

        protected PersistentRepository(string name, ILogger log, IEventJournalFactory eventJournalFactory = null)
        {
            Name = name;

            if (eventJournalFactory != null)
            {
                _eventJournal = eventJournalFactory.Create(Name);
                foreach (var kvp in _eventJournal.RetrieveAsync().Result)
                {
                    var item = (IPersistentItem) kvp.Value;
                    if (item is T)
                    {
                        _cache[item.Key] = new PersistentItem<T> {Item = (T) item, LastUpdated = kvp.Key};
                    }
                }
            }
        }

        protected virtual IEnumerable<T> GetAll()
        {
            return Clone(_cache.Values.Select(pi => pi.Item).ToList());
        }

        //[Log]
        public virtual T Get(string key)
        {
            PersistentItem<T> value;
            if (_cache.TryGetValue(key, out value))
            {
                return Clone(value.Item);
            }

            return default(T);
        }

        //[Log]
        public virtual IEnumerable<T> Get(DateTime cutoffTimeUtc)
        {
            return
                Clone(_cache.Values
                    .Where(pi => pi.LastUpdated >= cutoffTimeUtc)
                    .Select(pi => pi.Item)
                    .ToArray());
        }

        public virtual IEnumerable<T> Save(IEnumerable<T> elements)
        {
            var items = elements.ToList();
            var cloned = Clone(items);

            foreach (var item in cloned)
            {
                var pi = new PersistentItem<T> {Item = item, LastUpdated = DateTime.UtcNow};
                _cache.AddOrUpdate(item.Key, key => pi, (key, old) => pi);
            }

            foreach (var item in items.Where(ShouldAppendToJournal))
            {
                _eventJournal.AppendAsync(item).Wait();
            }

            ItemSaved?.Invoke(Clone(cloned.ToList()));

            return items;
        }

        protected virtual bool ShouldAppendToJournal(T item)
        {
            return _eventJournal != null;
        }

        public T Save(T item)
        {
            return Save(new[] {item}).First();
        }

        public T Remove(T item)
        {
            return Remove(new[] {item}).FirstOrDefault();
        }

        public virtual IEnumerable<T> Remove(IEnumerable<T> items)
        {
            var removed = new List<T>();
            foreach (var item in items)
            {
                PersistentItem<T> tmp;
                if (_cache.TryRemove(item.Key, out tmp))
                {
                    removed.Add(item);
                }
            }

            return removed;
        }
        
        public virtual int Clear(DateTime cutOffTimeUtc)
        {
            _eventJournal?.TruncateAsync(cutOffTimeUtc)?.Wait();
            return Remove(_cache.Values
                    .Where(pi => pi.LastUpdated < cutOffTimeUtc)
                    .Select(pi => pi.Item)
                    .ToArray()).Count();
        }

        public virtual int ClearAll()
        {
            int count = _cache.Count;
            _eventJournal?.TruncateAsync()?.Wait();
            _cache.Clear();
            return count;
        }

        private T Clone(T item)
        {
            var cln = item as ICloneable;
            return cln != null ? (T) cln.Clone() : item;
        }

        private IReadOnlyList<T> Clone(IReadOnlyList<T> items)
        {
            var result = new T[items.Count];
            for (int i = 0; i < items.Count; i++)
            {
                result[i] = Clone(items[i]);
            }

            return result;
        }
        
        public void Dispose()
        {
            
        }
    }
}
