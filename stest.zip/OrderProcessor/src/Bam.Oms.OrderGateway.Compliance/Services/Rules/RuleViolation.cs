﻿using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public struct RuleViolation
    {
        public string RuleName { get; set; }
        public ComplianceViolationLevel Level { get; set; }
        public string Message { get; set; }
        public ComplianceStatus Status { get; set; }
    }
}