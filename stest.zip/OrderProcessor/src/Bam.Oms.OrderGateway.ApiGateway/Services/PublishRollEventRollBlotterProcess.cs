﻿using System;
using Bam.EventQ.Throttling;
using Bam.EventQ.Time;
using Bam.Oms.OrderGateway.ApiGateway.Models.Solace;
using Bam.Oms.OrderGateway.Infrastructure.Roll;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public class PublishRollEventRollBlotterProcess : IRollBlotterProcess
    {
        private readonly IClock _clock;
        private readonly IThrottledBatchHandler<RollEvent> _rollEventPublisher;

        public PublishRollEventRollBlotterProcess(IClock clock,
            IThrottledBatchHandler<RollEvent> rollEventPublisher)
        {
            _clock = clock;
            _rollEventPublisher = rollEventPublisher;
        }

        public void Roll(DateTime rolledAt, BusinessDayChanged msg)
        {
            _rollEventPublisher.Handle(new[]
            {
                new RollEvent
                {
                    BusinessDay = _clock.BusinessDate.ToString("yyyy-MM-dd"),
                    RollTime = _clock.Now
                }
            });
        }
    }
}
