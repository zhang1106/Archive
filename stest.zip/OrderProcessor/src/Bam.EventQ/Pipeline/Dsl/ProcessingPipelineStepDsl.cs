﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Journal;
using Bam.EventQ.Queue;
using Bam.EventQ.Recovery;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Pipeline.Dsl
{
    public abstract class ProcessingPipelineStepDsl
    {
        public abstract IProcessingPipelineStep Build();
    }

    public class ProcessingPipelineStepDsl<TItem> : ProcessingPipelineStepDsl
    {        
        private readonly List<PipelineQueueItemHandlerChainDsl<TItem>> _handlerChains;
        private readonly List<IQueueItemProducer<PipelineQueueItem<TItem>>> _producers;
        private readonly List<IPipelineStepInitializer<TItem>> _initializers;
        private readonly HashSet<SubscriptionInfo> _subscriptions = new HashSet<SubscriptionInfo>();
        private readonly List<Func<IProcessingPipelineStep<TItem>, IRecoveryProcess>> _recoveryProcessFuncs;
        private string _replayEndpoint;
        private IQueue<PipelineQueueItem<TItem>> _queue;        
        private IQueueItemProducerFactory<PipelineQueueItem<TItem>> _subscriptionQueueItemProducerFactory;
        private IMessagePublisherFactory _messagePublisherFactory;

        public ProcessingPipelineStepDsl(ProcessingPipelineDsl pipelineDsl)
        {
            Pipeline = pipelineDsl;
            _handlerChains = new List<PipelineQueueItemHandlerChainDsl<TItem>>();
            _producers = new List<IQueueItemProducer<PipelineQueueItem<TItem>>>();
            _recoveryProcessFuncs = new List<Func<IProcessingPipelineStep<TItem>, IRecoveryProcess>>();
            _initializers = new List<IPipelineStepInitializer<TItem>>();
        }

        public ProcessingPipelineDsl Pipeline { get; }
        public Func<PipelineQueueItem<TItem>, SequenceInfo> SequenceInfoAccessor { get; private set; }

        public IMessagePublisherFactory MessagePublisherFactory => _messagePublisherFactory;
        public IReadOnlyList<IQueueItemProducer<PipelineQueueItem<TItem>>> Producers => _producers;
        public IReadOnlyList<PipelineQueueItemHandlerChainDsl<TItem>> Chains => _handlerChains;

        public override IProcessingPipelineStep Build()
        {
            foreach (var chain in _handlerChains)
            {
                Pipeline.ObjectDecorator.Decorate(chain);
            }

            if (_subscriptions.Any())
            {
                int[] sources = _subscriptions.Select(s => s.Source).Distinct().ToArray();
                int[] topics = _subscriptions.Select(s => s.Topic).Distinct().ToArray();
                var p = _subscriptionQueueItemProducerFactory.Create(sources, topics);
                _producers.Add(p);
            }

            foreach (var prod in _producers)
            {
                Pipeline.ObjectInitializer(prod);
            }

            IQueueItemProducer<PipelineQueueItem<TItem>> producer;
            if (_producers.Count == 1)
            {
                producer = _producers[0];
            }
            else
            {
                var composite = new CompositeQueueItemProducer<PipelineQueueItem<TItem>>(
                    _producers.Select(p => Pipeline.ObjectDecorator.Decorate(p)).ToArray());
                Pipeline.ObjectInitializer(composite);
                producer = composite;
            }
            
            Pipeline.ObjectInitializer(_queue);
            _queue = Pipeline.ObjectDecorator.Decorate(_queue);
            Pipeline.ObjectInitializer(_queue);

            IPipelineStepInitializer<TItem> initializer;
            if (_initializers.Count == 1)
            {
                initializer = _initializers[0];
            }
            else
            {
                initializer = new CompositePipelineStepInitializer<TItem>(
                    _initializers.Select(i =>
                    {
                        Pipeline.ObjectInitializer(i);
                        return Pipeline.ObjectDecorator.Decorate(i);
                    }).ToArray());
            }

            Pipeline.ObjectInitializer(initializer);
            initializer = Pipeline.ObjectDecorator.Decorate(initializer);

            var step = new ProcessingPipelineStep<TItem>(_queue, initializer, producer);

            foreach (var chain in _handlerChains)
            {
                var handlers = chain.Build();
                foreach (var h in handlers)
                {
                    Pipeline.ObjectInitializer(h);
                }

                step.AddSubscriptionChain(handlers.Select(h => Pipeline.ObjectDecorator.Decorate(h)).ToArray());
            }

            foreach (var handler in Pipeline.ErrorHandlers)
            {
                Pipeline.ObjectInitializer(handler);
                step.AddErrorHandler(handler);
            }

            if (_replayEndpoint != null)
            {
                var process = new ReplayFromPipelineStepRecoveryProcess<TItem>(step, SequenceInfoAccessor,
                    new RecoveryMessagePublisher<TItem>(MessagePublisherFactory.Create(_replayEndpoint)));
                Pipeline.AddRecoveryProcess(process, 0);
            }

            foreach (var func in _recoveryProcessFuncs)
            {
                Pipeline.AddRecoveryProcess(func(step));
            }

            Pipeline.ObjectInitializer(step);
            return step;
        }

        public ProcessingPipelineStepDsl<TItem> AddInitializer(IPipelineStepInitializer<TItem> initializer)
        {
            _initializers.Add(initializer);
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> ReplayFromJournal(IJournal journal)
        {
            _initializers.Add(new ReplayJournalInitializer<TItem>(journal));
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> ReplayFromJournal(IJournal journal, IEnumerable<IJournalSeed> seeds)
        {
            _initializers.Add(new ReplayJournalInitializer<TItem>(journal, seeds.ToArray()));
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> AddProducer(IQueueItemProducer<PipelineQueueItem<TItem>> producer)
        {
            _producers.Add(producer);
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> AddHandlerChain(Action<PipelineQueueItemHandlerChainDsl<TItem>> handlerConfig)
        {
            var dsl = new PipelineQueueItemHandlerChainDsl<TItem>(this);
            _handlerChains.Add(dsl);
            handlerConfig(dsl);
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> UseQueue(IQueue<PipelineQueueItem<TItem>> queue)
        {
            _queue = queue;
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> UseSequenceInfoAccessor(Func<PipelineQueueItem<TItem>, SequenceInfo> seqInfoAccessor)
        {
            SequenceInfoAccessor = seqInfoAccessor;
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> ReceiveFromPreviousStep<TPrevious>()
        {
            var handlers = ((ProcessingPipelineStepDsl<TPrevious>) Pipeline.Steps.Last()).Chains.SelectMany(c => c.Handlers).ToList();
            // ReSharper disable SuspiciousTypeConversion.Global
            var fwd = (IQueueItemProducer<PipelineQueueItem<TItem>>) handlers.First(h => h is IQueueItemProducer<PipelineQueueItem<TItem>>);
            // ReSharper restore SuspiciousTypeConversion.Global
            _producers.Add(fwd);
            return this;
        }
        
        public ProcessingPipelineStepDsl<TItem> UseReplayRecovery(string endpoint)
        {
            _replayEndpoint = endpoint;
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> AddRecoveryProcess(Func<IProcessingPipelineStep<TItem>, IRecoveryProcess> recoveryProcessFunc)
        {
            _recoveryProcessFuncs.Add(recoveryProcessFunc);
            return this;
        }

        public ProcessingPipelineStepDsl<TItem> SubscribeTo(int source, int[] topics)
        {
            foreach (var t in topics)
            {
                SubscribeTo(new SubscriptionInfo(source, t));
            }

            return this;
        }

        public ProcessingPipelineStepDsl<TItem> SubscribeTo(params SubscriptionInfo[] subscriptions)
        {
            foreach (var s in subscriptions)
            {
                _subscriptions.Add(s);
            }

            return this;
        }

        public ProcessingPipelineStepDsl<TItem> SetSubscriptionQueueItemProducerFactory(IQueueItemProducerFactory<PipelineQueueItem<TItem>> factory)
        {
            _subscriptionQueueItemProducerFactory = factory;
            return this;
        }

        public void SetMessagePublisherFactory(IMessagePublisherFactory messagePublisherFactory)
        {
            _messagePublisherFactory = messagePublisherFactory;
        }
    }
}
