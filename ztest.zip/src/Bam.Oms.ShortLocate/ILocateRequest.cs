﻿using System;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.ShortLocate
{
    public interface ILocateRequest : IEquatable<ILocateRequest>
    {
        IOrder Order { get; }
        string Broker { get; }
    }
}