﻿using System;

namespace Bam.EventQ.Workflow
{
    public delegate IWorkflow WorkflowActivator(Type workflowType);
}
