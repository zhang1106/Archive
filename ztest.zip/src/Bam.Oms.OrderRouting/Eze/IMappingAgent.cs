﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EzeEi = Eze.Common.Integration;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.OrderRouting.EZE
{
    public interface IMappingAgent
    {
        void Translate(EzeEi.Trade trade, out IList<Order> ogOrders, out IList<BlockTrade> ogTrades);
    }
}
