﻿using System;

namespace Bam.Oms.MarketData
{
    internal class SymbolData
    {        
        public SymbolData(string symbol)
        {
            Symbol = symbol;
            Open = double.NaN;
            High = double.NaN;
            Low = double.NaN;
            Last = double.NaN;
            LastSize = double.NaN;
            Bid = double.NaN;
            BidSize = double.NaN;
            Ask = double.NaN;
            AskSize = double.NaN;
            Change = double.NaN;
            Change2D = double.NaN;
            PxClose1D = double.NaN;
            PxClose2D = double.NaN;
            AvgVolume90D = double.NaN;
            AvgVolume5D = double.NaN;
            PriorHigh = double.NaN;
            PriorLow = double.NaN;
        }

        public string Symbol { get; private set; }
        public double Open { get; set; }
        public double High { get; set; }
        public double Low { get; set; }
        public double Last { get; set; }
        public double LastSize { get; set; }
        public double Bid { get; set; }
        public double Ask { get; set; }
        public double BidSize { get; set; }
        public double AskSize { get; set; }
        public double Change { get; set; }
        public double Change2D { get; set; }
        public long Volume { get; set; }
        public double PxClose1D { get; set; }
        public double PxClose2D { get; set; }
        public double AvgVolume5D { get; set; }
        public double AvgVolume90D { get; set; }
        public DateTime LastUpdate { get; set; }
        public double PriorHigh { get; set; }
        public double PriorLow { get; set; }       

        public override string ToString()
        {
            return
                $"Symbol:{Symbol},O:{Open},H:{High},L:{Low},LA:{Last},V:{Volume},Px1D:{PxClose1D},Px2D{PxClose2D},Vol5D:{AvgVolume5D},Vol90D:{AvgVolume90D},Time:{LastUpdate},PH:{PriorHigh},PL:{PriorLow}";
        }


    }
}