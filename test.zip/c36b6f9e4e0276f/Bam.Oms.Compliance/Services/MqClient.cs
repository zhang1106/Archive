﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Configuration;
using BAM.Common.Messaging;
using RabbitMQ.Client;
using IConnection = RabbitMQ.Client.IConnection;

namespace Bam.Oms.Compliance.Services
{
    public class MqClient : IMqClient
    {
        private readonly ILogger _logger;
        private readonly ISettings _settings;
        private IConnection _mqConnection;

        private readonly CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();
        
        public MqClient(ISettings settings, ILogger logger)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            _logger = logger;
            _settings = settings;
        }
        public void Init()
        {
            var factory =  new ConnectionFactory() { Uri= _settings.MQConnectionString};
            _mqConnection = factory.CreateConnection();
        }

        public void SubscribeOgOrders()
        {
            SubscribeObject(_settings.MQExchange, "#");
        }
    
        private void MqConnectionOnOnLog(string message)
        {
            _logger.Info(message);
        }

        private void MqConnectionOnOnError(string message)
        {
            _logger.Error("RabbitMQ error: " + message);
        }
  
        private void SubscribeObject(string destination, string subject)
        {
            try
            {
               
            }
            catch (Exception ex)
            {
                _logger.Error($"Exception while receiving from MQ.", ex);
            }
        }

        private void PublishObjects<T>(IList<T> objects, BlockingCollection<T> queue)
        {
            if (_cancellationTokenSource.IsCancellationRequested)
                return;

            var token = _cancellationTokenSource.Token;
            foreach (var obj in objects)
            {
                try
                {
                    queue?.Add(obj, token);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                catch (InvalidOperationException) // this includes ObjectDisposedException
                {
                    return;
                }
            }
        }

        public event Action<Message<string>> ObjectUpdated;

        public void Dispose()
        {
            _cancellationTokenSource.Cancel();
            _cancellationTokenSource.Dispose();
        }

    }
}
