﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    public class HeadroomThresholdComparer : IComparer<HeadroomThreshold>
    {
        public int Compare(HeadroomThreshold x, HeadroomThreshold y)
        {
            return x.Threshold.CompareTo(y.Threshold);
        }

        public static readonly HeadroomThresholdComparer Instance = new HeadroomThresholdComparer();
    }
}
