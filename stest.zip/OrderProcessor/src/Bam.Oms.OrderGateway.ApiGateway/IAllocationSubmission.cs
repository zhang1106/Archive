﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface IAllocationSubmission
    {
        void RedirectPbAllocation(long orderId, string user, Dictionary<string, long> allocations);
    }
}