﻿using System;
using System.Collections.Generic;

namespace Bam.EventQ.Workflow
{
    public class CompositeWorkflowRepository : IWorkflowRepository
    {
        private readonly IWorkflowRepository[] _repositories;

        public CompositeWorkflowRepository(params IWorkflowRepository[] repositories)
        {
            _repositories = repositories;
        }

        public IReadOnlyList<KeyValuePair<Type, IWorkflow>> GetAll()
        {
            var result = new List<KeyValuePair<Type, IWorkflow>>();
            foreach (var repo in _repositories)
            {
                result.AddRange(repo.GetAll());
            }

            return result;
        }
    }
}
