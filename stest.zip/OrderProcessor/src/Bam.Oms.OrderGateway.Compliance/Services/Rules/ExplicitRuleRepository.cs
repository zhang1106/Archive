﻿using System.Collections.Generic;
using System.Linq;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public class ExplicitRuleRepository : IRuleRepository
    {
        private readonly List<IRule> _rules;

        public ExplicitRuleRepository(IEnumerable<IRule> rules)
        {
            _rules = rules.ToList();
        }

        public List<IRule> GetAll()
        {
            return _rules;
        }
    }
}
