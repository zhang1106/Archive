﻿namespace Bam.EventQ.Transport
{
    public interface IMessagePublisherFactory
    {
        IMessagePublisher Create(string endpoint);
    }
}
