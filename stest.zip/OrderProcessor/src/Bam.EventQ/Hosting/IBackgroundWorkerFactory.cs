﻿namespace Bam.EventQ.Hosting
{
    public interface IBackgroundWorkerFactory
    {
        IBackgroundWorker Create(string name);
        IBackgroundWorker<TState> Create<TState>(string name);
    }
}
