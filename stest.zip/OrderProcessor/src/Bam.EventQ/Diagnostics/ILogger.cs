﻿using System;

namespace Bam.EventQ.Diagnostics
{
    public interface ILogger
    {
        void Log(LogLevel logLevel, string message, Exception exception = null);
        void Archive();
    }
}
