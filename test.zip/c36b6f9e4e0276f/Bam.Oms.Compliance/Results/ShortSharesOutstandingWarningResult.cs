﻿using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Results
{
    public class ShortSharesOutstandingWarningResult : RuleResult
    {
        public decimal? Ratio { get; set; }
        public override string ToString()
        {
            return
                $"Policly:{PolicyId},RuleName:{RuleName},Limit:{Ratio}";
        }
    }
}
