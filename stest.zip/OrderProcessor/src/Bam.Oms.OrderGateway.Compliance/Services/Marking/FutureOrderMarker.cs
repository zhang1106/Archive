﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Marking
{
    public class FutureOrderMarker : OrderMarkerBase
    {
        private readonly List<Mark> _markedOrders = new List<Mark>(2);

        private readonly Dictionary<ComplianceGroupKey, long> _shortMarkingEffects
            = new Dictionary<ComplianceGroupKey, long>();
        private readonly Dictionary<ComplianceGroupKey, long> _longMarkingEffects
            = new Dictionary<ComplianceGroupKey, long>();

        public FutureOrderMarker()
        {
            SupportedSecurityTypes = new HashSet<string>(new[] { "Future" });
        }

        protected override void CompleteScope()
        {
            _shortMarkingEffects.Clear();
            _longMarkingEffects.Clear();
        }

        public override ISet<string> SupportedSecurityTypes { get; }

        public override List<Mark> MarkOrder(MarkingEntity entity, PositionSet set)
        {
            _markedOrders.Clear();

            var shortComplianceSize = set.CompliancePosition.ShortMarkingQuantity;
            var longComplianceSize = set.CompliancePosition.LongMarkingQuantity;

            long shortComplianceEffect;
            if (_shortMarkingEffects.TryGetValue(set.CompliancePosition.Key,
                out shortComplianceEffect))
            {
                shortComplianceSize += shortComplianceEffect;
            }

            long longComplianceEffect;
            if (_longMarkingEffects.TryGetValue(set.CompliancePosition.Key,
                out longComplianceEffect))
            {
                longComplianceSize += longComplianceEffect;
            }

            #region Marking sell/short Orders

            // Apply the Complaince Short/Sell
            if (entity.Side == Side.Short || entity.Side == Side.Sell)
            {
                //compliance group is flat or short. Mark entire trade as short
                if (shortComplianceSize <= 0)
                {
                    _markedOrders.Add(new Mark
                    {
                        Quantity = entity.Size,
                        Side = Side.Short
                    });

                    RecordShortMarkingEffect(set, -entity.Size);
                    return _markedOrders;
                }

                //both compliance group and firm net long
                if (entity.Size <= shortComplianceSize)
                {
                    _markedOrders.Add(new Mark
                    {
                        Quantity = entity.Size,
                        Side = Side.Sell
                    });

                    RecordShortMarkingEffect(set, -entity.Size);
                    return _markedOrders;
                }

                // Net firm position is long, but not enough to satisfy the sell. Split the trade into two
                _markedOrders.Add(new Mark
                {
                    Side = Side.Sell,
                    Quantity = shortComplianceSize
                });

                RecordShortMarkingEffect(set, -shortComplianceSize);

                _markedOrders.Add(new Mark
                {
                    Side = Side.Short,
                    Quantity = entity.Size - shortComplianceSize
                });

                RecordShortMarkingEffect(set, -(entity.Size - shortComplianceSize));

                return _markedOrders;
            }

            #endregion Marking sell/short Orders

            #region Marking Long/Buy orders

            //compliance group position >= 0, mark as BUY
            if (longComplianceSize >= 0)
            {
                _markedOrders.Add(new Mark
                {
                    Side = Side.Buy,
                    Quantity = entity.Size
                });

                RecordLongMarkingEffect(set, entity.Size);
                return _markedOrders;
            }

            //compliance group short and order size less than short position, mark as COVER
            var maxCover = Math.Abs(longComplianceSize);
            if (entity.Size <= maxCover)
            {
                _markedOrders.Add(new Mark
                {
                    Side = Side.Cover,
                    Quantity = entity.Size
                });

                RecordLongMarkingEffect(set, entity.Size);
                return _markedOrders;
            }

            //compliance group short and order size greater than short position, need to split
            _markedOrders.Add(new Mark
            {
                Side = Side.Cover,
                Quantity = maxCover
            });

            RecordLongMarkingEffect(set, maxCover);

            _markedOrders.Add(new Mark
            {
                Side = Side.Buy,
                Quantity = entity.Size - maxCover
            });

            RecordLongMarkingEffect(set, entity.Size - maxCover);
            return _markedOrders;

            #endregion Marking Long/Buy orders
        }

        private void RecordShortMarkingEffect(PositionSet set, long effect)
        {
            var compKey = set.CompliancePosition.Key;

            long current;
            if (!_shortMarkingEffects.TryGetValue(compKey, out current))
            {
                _shortMarkingEffects.Add(compKey, effect);
            }
            else
            {
                _shortMarkingEffects[compKey] = current + effect;
            }
        }

        private void RecordLongMarkingEffect(PositionSet set, long effect)
        {
            var compKey = set.CompliancePosition.Key;

            long current;
            if (!_longMarkingEffects.TryGetValue(compKey, out current))
            {
                _longMarkingEffects.Add(compKey, effect);
            }
            else
            {
                _longMarkingEffects[compKey] = current + effect;
            }
        }
    }
}
