﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using Bam.Oms.SodPosition.Svc;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.SodPosition.SvcHost
{
    public class SodPositionEditController : ApiController
    {
        private ISodPositionEdit sEdit = BAM.Infrastructure.Ioc.Container.Instance.Resolve<ISodPositionEdit>();

        public SodPositionEditController()
        {
            sEdit.Start();
        }

        [HttpGet]
        public IList<Position> Get(string userId, DateTime? asofdate, string stream, string fundCode, string custodianAccountCode, string strategyCode, string securityType, string bamSymbol)
        {
            return sEdit.GetSodPositions(userId, asofdate, stream, fundCode, custodianAccountCode,
                strategyCode, securityType, bamSymbol);
        }
        [HttpGet]
        public IList<Position> GetLastestUpdates(string userId, string stream)
        {
            return sEdit.GetLatestUpdatedPositions(userId, stream);
        }
        [HttpGet]
        public IList<PositionAudit> GetAudits(string userId, int positionId, DateTime entrydate)
        {
            return sEdit.GetAudits(userId, positionId, entrydate);
        }

        [HttpPost]
        public Position PutPosition(string userId, Position position)
        {
            return sEdit.UpdatePosition(userId, position);
        }
        [HttpPost]
        public Position PostPosition(string userId, Position position)
        {
            return sEdit.InsertPosition(userId, position);
        }
        [HttpPost]
        public IList<Position> PostPositions(string userId, IList<Position> positions)
        {
            return sEdit.BulkInsertPosition(userId, positions);
        }
        [HttpPost]
        public IList<Position> PutPositions(string userId, IList<Position> positions)
        {
            return sEdit.BulkUpdatePosition(userId, positions);
        }
        [HttpPost]
        public bool SaveToCSVFile(string userId, string completeFileName, IList<Position> positions)
        {
            return sEdit.SaveToCSVFile(userId, completeFileName, positions);
        }
        [HttpPost]
        public bool Publish(string userId, string stream)
        {
            return sEdit.PublishUpdatedPositions(userId, stream);
        }
        [HttpGet]
        public IList<SodAction> GetBulkActions(string userId)
        {
            return sEdit.GetBulkActions(userId);
        }

        [HttpPost]
        public IList<Position> ExecuteUndo(string userId, int positionId, IList<Position> undoList)
        {
            return sEdit.ExecuteUndo(userId, positionId, undoList);
        }

        [HttpGet]
        public IList<Position> GetUndoChanges(string userId, int positionId)
        {
            return sEdit.GetUndoChanges(userId, positionId);
        }

        [HttpGet]
        public IList<string> GetStreams(string userId)
        {
            return sEdit.GetStreams(userId);
        }

        [HttpGet]
        public string GetLatestLoadedStream(string userId)
        {
            return sEdit.GetLatestLoadedStream(userId);
        }
    }
}
