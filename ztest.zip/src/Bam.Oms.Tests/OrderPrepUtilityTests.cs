﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.ReferenceDataGateway.Api;
using Bam.Oms.ReferenceDataGateway.Api.Http;
using Bam.Oms.ReferenceDataGateway.Api.Model;
using BAM.Infrastructure.Ioc;
using FluentAssertions;
using Moq;
using NUnit.Framework;
using Ploeh.AutoFixture;
using IAccountService = Bam.Oms.RefData.IAccountService;
using ISecurityMasterService = Bam.Oms.RefData.ISecurityMasterService;
using SecurityType = Bam.Oms.Data.Enumerators.SecurityType;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class OrderPrepUtilityTests
    {
        [Test]
        public void TestAssignIds()
        {
            // arrange
            var repo = new Mock<IClientOrderIdRepository>();
            repo.Setup(r => r.GenerateOrderIds(It.IsAny<int>())).Returns(new List<string>() {"123"});

            var util = new OrderPrepUtility(repo.Object, new Mock<ILogger>().Object, new Mock<ISettings>().Object, new Mock<ISecurityMasterService>().Object, new Mock<IAccountService>().Object, new Mock<ReferenceDataGateway.Api.Http.ICoverageController>().Object);

            var order = new Order();

            // act
            var unit = util.AssignOrderIds(new []{order});

            // assert
            Assert.That(unit.Count, Is.EqualTo(1));
            Assert.That(order.ClientOrderId, Is.EqualTo("123"));
        }

        [Test]
        public void TestSetTradeDateOnWeekdayBeforeSod()
        {
            // arrange
            var now = new DateTime(2015, 12, 28, 17, 0, 0); //12/28 is a Monday
            var sod = new DateTime(2015, 12, 27, 18, 0, 0);

            var settings = new Mock<ISettings>();
            settings.SetupGet(s => s.SODDateTime).Returns(sod);

            var repo = new Mock<IClientOrderIdRepository>();
            repo.Setup(r => r.GenerateOrderIds(It.IsAny<int>())).Returns(new List<string>() { "123" });

            var util = new OrderPrepUtility(repo.Object, new Mock<ILogger>().Object, settings.Object, new Mock<ISecurityMasterService>().Object, new Mock<IAccountService>().Object, new Mock<ReferenceDataGateway.Api.Http.ICoverageController>().Object);

            var order = new Order();

            // act
            util.SetTradeDate(new[] { order }, now);

            // assert
            Assert.That(order.TradeDate.Date, Is.EqualTo(now.Date));
        }

        [Test]
        public void TestSetTradeDateOnWeekdayAfterSod()
        {
            // arrange
            var now = new DateTime(2015, 12, 28, 19, 0, 0); //12/28 is a Monday
            var sod = new DateTime(2015, 12, 27, 18, 0, 0);

            var settings = new Mock<ISettings>();
            settings.SetupGet(s => s.SODDateTime).Returns(sod);

            var repo = new Mock<IClientOrderIdRepository>();
            repo.Setup(r => r.GenerateOrderIds(It.IsAny<int>())).Returns(new List<string>() { "123" });

            var util = new OrderPrepUtility(repo.Object, new Mock<ILogger>().Object, new Mock<ISettings>().Object, new Mock<ISecurityMasterService>().Object, new Mock<IAccountService>().Object, new Mock<ReferenceDataGateway.Api.Http.ICoverageController>().Object);

            var order = new Order();

            // act
            util.SetTradeDate(new[] { order }, now);

            // assert
            Assert.That(order.TradeDate.Date, Is.EqualTo(now.AddDays(1).Date));
        }

        [Test]
        public void TestSetTradeDateLandsOnSatRollsToMonday()
        {
            // arrange
            var now = new DateTime(2015, 12, 25, 19, 0, 0);
            var sod = new DateTime(2015, 12, 24, 18, 0, 0);

            var settings = new Mock<ISettings>();
            settings.SetupGet(s => s.SODDateTime).Returns(sod);
            var repo = new Mock<IClientOrderIdRepository>();
            repo.Setup(r => r.GenerateOrderIds(It.IsAny<int>())).Returns(new List<string>() { "123" });

            var util = new OrderPrepUtility(repo.Object, new Mock<ILogger>().Object, new Mock<ISettings>().Object, new Mock<ISecurityMasterService>().Object, new Mock<IAccountService>().Object, new Mock<ReferenceDataGateway.Api.Http.ICoverageController>().Object);

            var order = new Order();

            // act
            util.SetTradeDate(new[] { order }, now);

            // assert
            Assert.That(order.TradeDate.Date, Is.EqualTo(now.AddDays(3).Date));
        }

        [Test]
        public void TestSetTradeDateLandsOnSunRollsToMonday()
        {
            // arrange
            var now = new DateTime(2015, 12, 26, 19, 0, 0);
            var sod = new DateTime(2015, 12, 24, 18, 0, 0);

            var settings = new Mock<ISettings>();
            settings.SetupGet(s => s.SODDateTime).Returns(sod);

            var repo = new Mock<IClientOrderIdRepository>();
            repo.Setup(r => r.GenerateOrderIds(It.IsAny<int>())).Returns(new List<string>() { "123" });

            var util = new OrderPrepUtility(repo.Object, new Mock<ILogger>().Object, new Mock<ISettings>().Object, new Mock<ISecurityMasterService>().Object, new Mock<IAccountService>().Object, new Mock<ReferenceDataGateway.Api.Http.ICoverageController>().Object);

            var order = new Order();

            // act
            util.SetTradeDate(new[] { order }, now);

            // assert
            Assert.That(order.TradeDate.Date, Is.EqualTo(now.AddDays(2).Date));
        }

        [Test]
        public void TestSetTraderWhenNoMatchingAdLogin()
        {
            // arrange
            var coverage = new Mock<ICoverageController>();
            coverage.Setup(r => r.GetTraderCoverage(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<AssetType>()))
                .Returns(new Coverage() {TradeId = 1});
            
            var fixture = new Fixture();
            var order = fixture.Create<Order>();
            order.Security.SecurityType = SecurityType.Equity;
            
            var util = new OrderPrepUtility(new Mock<IClientOrderIdRepository>().Object, new Mock<ILogger>().Object, new Mock<ISettings>().Object,
                new Mock<ISecurityMasterService>().Object, new Mock<IAccountService>().Object, coverage.Object);

            // act
            util.SetTrader(new List<IOrder>() {order}, "ryan");
            var unit = order.TraderId;

            // assert
            Assert.That(unit, Is.EqualTo(1));
        }


        [Test]
        [TestCase("PMX1", "2015/11/29 09:30:45.1234", "PMX1-20151129-0930451234")]
        [TestCase("PMX2", "2016/02/09 15:07:25.10", "PMX2-20160209-1507251000")]
        public void TestBatchIdCreation(string pm, string time, string expectedBatchId)
        {
            var repo = new Mock<IClientOrderIdRepository>();
            var util = new OrderPrepUtility(repo.Object, new Mock<ILogger>().Object, new Mock<ISettings>().Object, new Mock<ISecurityMasterService>().Object, new Mock<IAccountService>().Object, new Mock<ReferenceDataGateway.Api.Http.ICoverageController>().Object);
            var batchId = util.CreateBatchId(pm, DateTime.Parse(time));
            Assert.IsNotNull(batchId);
            Assert.That(batchId, Is.EqualTo(expectedBatchId));
        }

        [Test]
        [TestCase(SecurityType.Equity, null, "VOD LN SWAP")]
        [TestCase(SecurityType.EquitySwap, "VOD LN", "VOD LN SWAP")]
        public void TestCreatesSwapOrder(SecurityType sType, string underlying, string swap)
        {
            var securityMaster = new Mock<ISecurityMasterService>();
            securityMaster.Setup(m => m.GetSwapSecurity("VOD LN", "MSCO")).Returns(
                () => new Data.Securities.Security { BamSymbol = "VOD LN SWAP" });

            var sut = new OrderPrepUtility(
                new Mock<IClientOrderIdRepository>().Object,
                new Mock<ILogger>().Object,
                new Mock<ISettings>().Object,
                securityMaster.Object,
                new Mock<IAccountService>().Object,
                new Mock<ICoverageController>().Object);

            var portfolio = (Data.Portfolios.Portfolio)Data.Portfolios.Portfolio.Parse("QIAN-GENERALIST");
            var order = new Order
            {
                ClientOrderId = "1234",
                Portfolio = portfolio,
                Custodian = "CSPB",
                BatchId = "BATCH-1",
                Security = new Data.Securities.Security
                {
                    BamSymbol = "VOD LN",
                    SecurityType = sType,
                    UnderlyingSymbol = underlying
                },
                Price = 1.2m,
                Urgency = Urgency.Medium,
                TradeDate = DateTime.Today,
                Side = SideType.Buy,
                OrderStatus = BamOrderStatus.PendingSend,
                Size = 100
            };

            var actual = sut.CreateSwapOrder(order, "MSCO");
            actual.Should().NotBeNull();
            actual.Should().NotBeSameAs(order);

            actual.BatchId.Should().Be(order.BatchId);
            actual.Security.BamSymbol.Should().Be("VOD LN SWAP");
            actual.Size.Should().Be(order.Size);
            actual.Side.Should().Be(order.Side);
            actual.TradeDate.Should().Be(order.TradeDate);
            actual.Urgency.Should().Be(order.Urgency);
            actual.Price.Should().Be(order.Price);
            actual.Custodian.Should().Be("MSCO");

            actual.ClientOrderId.Should().NotBe(order.ClientOrderId);
            actual.OrderStatus.Should().NotBe(order.OrderStatus);
        }

        [Test]
        public void TestRejectsSwapOrderCreation()
        {
            var securityMaster = new Mock<ISecurityMasterService>();
            securityMaster.Setup(m => m.GetSwapSecurity("VOD LN", "MSCO")).Returns(
                () => new Data.Securities.Security { BamSymbol = "VOD LN SWAP" });

            var sut = new OrderPrepUtility(
                new Mock<IClientOrderIdRepository>().Object,
                new Mock<ILogger>().Object,
                new Mock<ISettings>().Object,
                securityMaster.Object,
                new Mock<IAccountService>().Object,
                new Mock<ICoverageController>().Object);

            var order = new Order
            {
                ClientOrderId = "1234",
                Portfolio = (Data.Portfolios.Portfolio)Data.Portfolios.Portfolio.Parse("QIAN-GENERALIST"),
                Custodian = "CSPB",
                BatchId = "BATCH-1",
                Security = new Data.Securities.Security
                {
                    BamSymbol = "VOD LN",
                    SecurityType = SecurityType.Equity
                },
                Price = 1.2m,
                Urgency = Urgency.Medium,
                TradeDate = DateTime.Today,
                Side = SideType.Buy,
                OrderStatus = BamOrderStatus.PendingSend,
                Size = 100
            };

            // wrong security type
            order.Security.SecurityType = SecurityType.Bond;
            sut.CreateSwapOrder(order, "MSCO").Should().BeNull();
            order.Security.SecurityType = SecurityType.Equity;

            // wrong status
            order.OrderStatus = BamOrderStatus.Working;
            sut.CreateSwapOrder(order, "MSCO").Should().BeNull();
            order.OrderStatus = BamOrderStatus.PendingSend;

            // swap security not setup
            securityMaster.Setup(m => m.GetSwapSecurity("VOD LN", "MSCO")).Returns(() => null);
            sut.CreateSwapOrder(order, "MSCO").Should().BeNull();
        }
    }
}