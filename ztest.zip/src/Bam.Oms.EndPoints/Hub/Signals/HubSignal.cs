﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Trades;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Messaging;
using Bam.Oms.Persistence;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;

namespace Bam.Oms.EndPoints.Hub.Signals
{
    /// <summary>
    ///     Base class used for listening to changes and "signaling" a change to the appropriate hub
    /// </summary>
    /// <typeparam name="TResult"></typeparam>
    /// <typeparam name="TRepository"></typeparam>
    public abstract class HubSignal<TResult, TRepository> : IHubSignal<TResult> where TResult : IPersistentItem
        where TRepository : IPersistentRepository<TResult>
    {
        private readonly object _lockobj = new object();
        private readonly ISignalRSessions<TResult> _sessions;
        private readonly ILogger _logger;
        // ReSharper disable PrivateFieldCanBeConvertedToLocalVariable
        private readonly IOrderRepository _orderRepository;
        private readonly ITradeRepository _tradeRepository;
        // ReSharper restore PrivateFieldCanBeConvertedToLocalVariable
        private Dictionary<string, Dictionary<string, TResult>> _items;
        private readonly IList<IPersistentRepository<TResult>> _repository;
        private Timer _timer;
        private bool _isGatewayFullyInitialized;

        protected HubSignal(ISignalRSessions<TResult> sessions, IFlowManager flowManager, ILogger logger, IOrderRepository orderRepository, ITradeRepository tradeRepository)
        {
            if (sessions == null) throw new ArgumentNullException(nameof(sessions));
            if (flowManager == null) throw new ArgumentNullException(nameof(flowManager));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (orderRepository == null) throw new ArgumentNullException(nameof(orderRepository));
            if (tradeRepository == null) throw new ArgumentNullException(nameof(tradeRepository));

            _sessions = sessions;
            _logger = logger;
            _orderRepository = orderRepository;
            _tradeRepository = tradeRepository;
            _repository = new List<IPersistentRepository<TResult>>();
            _isGatewayFullyInitialized = false;

            // absolute crappy way to deal with this but it was done to make some progress on the permission piece
            // http://dev-app:8080/browse/EMS-314
            // will need to be removed completely and refactored

            if (typeof(TResult) == typeof(Order))
                _repository.Add((IPersistentRepository<TResult>)_orderRepository);

            if (typeof(TResult) == typeof(BlockTrade))
                _repository.Add((IPersistentRepository<TResult>)_tradeRepository);

            flowManager.FlowManagerInitialized += HandleOnOrderHandlerInitialized;
            flowManager.SODRolled += HandleSodRolled;
            sessions.NewSession += SignalHub;
            InitializeThrotting();
        }

        private void HandleSodRolled(DateTime timeRolled)
        {
            _logger.Info($"Gateway performed SOD Roll. Preparing to notify clients...");
            NotifyClientsGatewayIsReady(timeRolled);
        }

        private static int ThrottlePacketSize
        {
            get
            {
                int size;
                return int.TryParse(ConfigurationManager.AppSettings["throttle-packetsize"], out size) ? size : 200;
            }
        }

        private static int ThrottleFrequency
        {
            get
            {
                int size;
                return int.TryParse(ConfigurationManager.AppSettings["throttle_frequency"], out size) ? size : 500;
            }
        }

        public void SignalHub(IEnumerable<TResult> items)
        {
            var interestedConnections = _sessions.Filter(items);

            lock (_lockobj)
            {
                foreach (var connection in interestedConnections.Keys)
                {
                    foreach (var item in interestedConnections[connection])
                    {
                        if (_items.ContainsKey(connection))
                        {
                            if (_items[connection].ContainsKey(item.Key))
                                _items[connection][item.Key] = item;
                            else
                                _items[connection].Add(item.Key, item);
                        }
                        else
                        {
                            var connectionItems = new Dictionary<string, TResult> { { item.Key, item } };
                            _items.Add(connection, connectionItems);
                        }
                    }
                }
            }
        }

        private void InitializeThrotting()
        {
            _logger.Info($"Throttling initialized at {DateTime.Now:HH:mm:ss.fff}");
            _timer = new Timer(Broadcast, null, 20000, ThrottleFrequency);
            _items = new Dictionary<string, Dictionary<string, TResult>>();
        }

        private void Broadcast(object source)
        {
            var hub = GetHubContext();
            Dictionary<string, Dictionary<string, TResult>> toBeSent;
            lock (_lockobj)
            {
                toBeSent = _items;
                _items = new Dictionary<string, Dictionary<string, TResult>>();

                foreach (var item in toBeSent)
                {
                    var client = hub.Clients.Client(item.Key);
                    SendPacketsToClient(client, item.Value.Values.ToList());
                }
            }
        }

        private void HandleOnOrderHandlerInitialized()
        {
            _logger.Info($"Gateway Initialized. Preparing to notify clients trying to reconnect...");
            if (!_isGatewayFullyInitialized)
                NotifyClientsGatewayIsReady(); // need to send this notification only once

            //TODO ResolveAll does not work if there is a single item in the container

            //_repository = Container.Instance.ResolveAll<TRepository>();

            foreach (var repository in _repository)
                repository.ItemSaved += SignalHub;

            _isGatewayFullyInitialized = true;
        }

        private void NotifyClientsGatewayIsReady(DateTime? timeRolled = null)
        {
            if (timeRolled == null)
            {
                // handle gateway initialized case
                //if the case where there are clients connected but the gateway has reinitialized
                lock (_lockobj)
                {
                    foreach (var connectionId in _sessions.ConnectionIds)
                        SignalHub(connectionId);
                }

                _logger.Info($"clients has been notified that the Order Gateway is ready to receive orders");
            }
            else
            {
                var hub = GetHubContext();
                // handle the SODRolled case
                hub.Clients.All.SodRolledMessage(timeRolled.Value);
                _logger.Info($"clients has been notified that the Order Gateway has rolled");
            }
        }

        protected abstract IHubContext<ISignalRClient<SignalRPacket<TResult>>> GetHubContext();

        private void SignalHub(string connectionId)
        {
            var hub = GetHubContext();
            var client = hub.Clients.Client(connectionId);
            var itemList = new List<TResult>();

            for (var i = 0; i < _repository.Count; i++)
            {
                var allItems = _repository[i].Get(DateTime.MinValue);
                itemList.AddRange(_sessions.Filter(allItems, connectionId));
            }

            _logger.Info($"Initally send to {connectionId} with {itemList.Count} items");
            SendPacketsToClient(client, itemList);
        }

        /// <summary>
        /// </summary>
        /// <param name="client"></param>
        /// <param name="items"></param>
        private static void SendPacketsToClient(ISignalRClient<SignalRPacket<TResult>> client, IList<TResult> items)
        {
            var enumerable = items as TResult[] ?? items.ToArray();
            var packets = enumerable.Count() == 0
                ? EmptyPacket
                : SignalRPacket<TResult>.Partition(enumerable, ThrottlePacketSize);

            foreach (var p in packets)
                client.ReceiveMessage(p);
        }

        private static SignalRPacket<TResult>[] EmptyPacket => new[] { new SignalRPacket<TResult> { Sequence = 0, TotalExpectedPackets = 0, Data = new List<TResult>() } };
    }
}