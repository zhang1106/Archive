﻿using System;
using SolaceSystems.Solclient.Messaging;

namespace Bam.EventQ.Solace
{
    public class NullMessageTransform : ISolaceMessageTransform
    {
        public void Transform(IMessage source, byte[] buffer, int index, out int received, out int topic)
        {
            Buffer.BlockCopy(source.BinaryAttachment, 0, buffer, index, source.UserData.Length);
            topic = 0;
            received = source.UserData.Length;
        }
    }
}
