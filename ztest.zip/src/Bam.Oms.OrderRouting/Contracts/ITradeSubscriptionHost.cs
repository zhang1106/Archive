﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.OrderRouting.Contracts
{
    public interface ITradeSubscriptionHost : ISubscriptionDisposable
    {
        event Action<IEnumerable<IPosition>> PositionUpdated;
        event Action<IEnumerable<IBlockTrade>> TradeUpdated;
        /// <summary>
        /// OrderId, OrderStaus
        /// </summary>
        event Action<IEnumerable<IOrder>> OrderStatusChanged;
    }
}