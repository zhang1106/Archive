﻿using Bam.Oms.Compliance.ApiGateway.Http;
using Bam.Oms.Compliance.ApiGateway.Permissions;
using Bam.Oms.Compliance.ApiGateway.Services;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.ApiGateway
{
    public class TypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            Container.Instance.RegisterType<IService, HttpService>(RegistrationType.Singleton, "HttpService");
            Container.Instance.RegisterType<IPermissionService, PermissionService>(RegistrationType.Singleton);
        }
    }
}
