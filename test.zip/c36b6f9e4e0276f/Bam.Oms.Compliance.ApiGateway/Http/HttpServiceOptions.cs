﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.Http.Dependencies;
using Bam.Oms.Data.Configuration;
using Microsoft.Owin.Hosting;
using  Ioc = BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.ApiGateway.Http
{
    public class HttpServiceOptions : StartOptions
    {
        private readonly ISettings _settings;
        public HttpServiceOptions(ISettings basesSettings)
            : base(basesSettings.BaseUrl)
        {
            _settings = basesSettings;
        }

        public string[] PermissionedApplications { get; set; }
        public IDependencyResolver DependencyResolver => new IocDependencyResolver(Ioc.Container.Instance);
        public TimeSpan DefaultTokenExpiry => _settings.DefaultTokenExpiry;
        public bool DisableAuthorization => true;
        public bool AllowTokenAsUrlParameter => _settings.AllowTokenAsUrlParameter;
    }

    public class IocDependencyResolver : IDependencyResolver
    {
        private readonly Ioc.Container _container;

        public IocDependencyResolver(Ioc.Container container)
        {
            _container = container;
        }


        public object GetService(Type serviceType)
        {
            return _container.Resolve(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return _container.ResolveAll(serviceType).Cast<object>();
        }

        public IDependencyScope BeginScope()
        {
            return null;
        }

        public void Dispose()
        {
            _container.Dispose();
        }
    }
}
