﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Securities;
using CsvHelper;
using CsvHelper.Configuration;

namespace Bam.Oms.EndPoints.File
{
    internal sealed class OrderRecordMapping : CsvClassMap<OrderRecord>
    {
        //Portfolio,Urgency,Security,Side,Amount,PrimeBroker,PrimeBrokerAccount,Fund,GroupingKey,ExecutionInstructions

        public OrderRecordMapping()
        {
            Map(m => m.Portfolio).Name("Portfolio").TypeConverter<PortfolioConverter>();
            Map(m => m.Security).ConvertUsing<ISecurity>(row =>
            {
                string bamSymbol = row.GetField("Security");
                if (string.IsNullOrWhiteSpace(bamSymbol))
                {
                    throw new CsvBadDataException("Security is missing. Security is a mandatory field for an order.");
                }
                return new Security { BamSymbol = bamSymbol };

            });

            Map(m => m.Side).ConvertUsing(row =>
            {
                string side = row.GetField("Side");
                if (string.IsNullOrWhiteSpace(side))
                {
                    throw new CsvBadDataException("Side is missing. Side is a mandatory field for an order.");
                }
                side = side.ToLower() == "short" ? "SellShort" : side == "cover" ? "Cover" : side;
                return Utility.ConvertEnum<SideType>(side);
            });

            Map(m => m.Urgency).ConvertUsing(row =>
            {
                string urgency = row.GetField("Urgency");
                return string.IsNullOrWhiteSpace(urgency) ? Urgency.Low : Utility.ConvertEnum<Urgency>(urgency);
            });

            Map(m => m.Quantity).ConvertUsing(row =>
            {
                decimal amount = row.GetField<decimal>("Amount");
                if (amount <= 0)
                {
                    throw new CsvBadDataException("Amount is missing or invalid. Amount is a mandatory field for an order and must be a positive non-zero number.");
                }
                return amount;
            });

            //TODO: Make this an optional field after Account service is modified to have a default
            Map(m => m.PrimeBroker).ConvertUsing(row =>
            {
                string primeBroker = row.GetField<string>("PrimeBroker");
                if (String.IsNullOrWhiteSpace(primeBroker))
                {
                    throw new CsvBadDataException("PrimeBroker is missing or invalid. PrimeBroker is a mandatory field for an order and must be a positive non-zero number.");
                }
                return primeBroker;
            });
            Map(m => m.PrimeBrokerAccount).Name("PrimeBrokerAccount");
            Map(m => m.Fund).Name("Fund");
            Map(m => m.GroupingKey).Name("GroupingKey");
            Map(m => m.ExecutionInstructions).Name("ExecutionInstructions");
        }        
    }
}
