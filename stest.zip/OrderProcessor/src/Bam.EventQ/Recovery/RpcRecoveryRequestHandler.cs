﻿using System;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Recovery
{
    public class RpcRecoveryRequestHandler : IRcpRequestHandler
    {
        private readonly IRecoveryProcess _recoveryProcess;
        private readonly object _syncRoot = new object();
        private int _counter;

        public RpcRecoveryRequestHandler(IRecoveryProcess recoveryProcess)
        {
            _recoveryProcess = recoveryProcess;
        }

        public ILogger Logger { get; set; }

        public byte[] Invoke(string inquiry, byte[] payload)
        {
            int topic = payload.ToInt32(0);
            long start = payload.ToInt64(4);
            int count = Interlocked.Increment(ref _counter);
            var worker = BackgroundWorkerFactory.Current.Create<Tuple<int, long>>($"Recovery #{count}");
            worker.State = Tuple.Create(topic, start);
            worker.Start(Recover);

            // recovery successfully started
            return new byte[] { 0x00 };
        }

        public bool CanHandle(string inquiry)
        {
            return inquiry == "recover";
        }

        private void Recover(Tuple<int, long> state, CancellationToken cancellationToken)
        {
            Monitor.Enter(_syncRoot);
            try
            {
                int? topic = state.Item1 == -1 ? (int?) null : state.Item1;
                long start = state.Item2;

                var range = topic == null
                    ? $"all topics from sequence {start}"
                    : $"topic {topic} from sequence {start}";

                Logger?.LogInformation($"Recovering {range}");
                if (_recoveryProcess.Execute(topic, start))
                {
                    Logger?.LogInformation($"Successfully recovered {range}");
                }
                else
                {
                    Logger?.LogError($"Recovery for {range} failed");
                }
            }
            catch (Exception ex)
            {
                Logger?.LogError("Unexpected error during recovery", ex);
            }
            finally
            {
                Monitor.Exit(_syncRoot);
            }
        }
    }
}
