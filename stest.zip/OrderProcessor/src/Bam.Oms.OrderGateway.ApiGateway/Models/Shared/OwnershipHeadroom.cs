﻿using System;
using System.Collections.Generic;
using Bam.EventQ;
using Bam.EventQ.Lookup;
using Bam.Oms.OrderGateway.ApiGateway.Cache;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class OwnershipHeadroom : ModelBase<object>, ICloneable, IMortal
    {
        private bool _isDeceased;

        public OwnershipHeadroom(OwnershipHeadroomKey key)
        {
            Key = key;
            HeadRoomThresholds = new List<HeadroomThreshold>(8);
            Ratios = new Dictionary<string, double>();
        }

        public OwnershipHeadroomKey Key { get; }
        public string RuleName { get; set; }
        public string IdentifierType { get; set; }
        public bool IsExempt { get; set; }
        public string Direction { get; set; }
        public long IntradayQuantity { get; set; }
        public long MaxIntradayQuantity { get; set; }
        public string ReportingEntity { get; set; }
        public bool IsContingency { get; set; }

        public Dictionary<string, double> Ratios { get; }
        public List<HeadroomThreshold> HeadRoomThresholds { get; }

        public object Clone()
        {
            var ownership = new OwnershipHeadroom(new OwnershipHeadroomKey(Key.RuleId, Key.Identifier))
            {
                RuleName = RuleName,
                IdentifierType = IdentifierType,
                IsExempt = IsExempt,
                Direction = Direction,
                IntradayQuantity =  IntradayQuantity,
                MaxIntradayQuantity = MaxIntradayQuantity,
                ReportingEntity = ReportingEntity,
                IsContingency = IsContingency
            };

            foreach (var headRoomThreshold in HeadRoomThresholds)
            {
                ownership.HeadRoomThresholds.Add(new HeadroomThreshold()
                {
                    AlertLevel = headRoomThreshold.AlertLevel,
                    HeadRoom = headRoomThreshold.HeadRoom,
                    FireOnce = headRoomThreshold.FireOnce,
                    Threshold = headRoomThreshold.Threshold,
                });
            }

            Ratios.CopyTo(ownership.Ratios);
            ownership._isDeceased = _isDeceased;
            return ownership;
        }

        public class HeadroomThreshold
        {
            public decimal Threshold { get; set; }
            public long HeadRoom { get; set; }
            public string AlertLevel { get; set; }
            public bool FireOnce { get; set; }
        }

        public bool IsDeceased()
        {
            return _isDeceased;
        }

        public void Kill()
        {
            _isDeceased = true;
        }
    }

    public struct OwnershipHeadroomKey : IEquatable<OwnershipHeadroomKey>
    {
        public OwnershipHeadroomKey(int ruleId, string identifier)
        {
            RuleId = ruleId;
            Identifier = identifier;
        }

        public int RuleId { get; set; }
        public string Identifier { get; set; }

        public bool Equals(OwnershipHeadroomKey other)
        {
            return RuleId == other.RuleId && string.Equals(Identifier, other.Identifier);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is OwnershipHeadroomKey && Equals((OwnershipHeadroomKey) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (RuleId * 397) ^ (Identifier?.GetHashCode() ?? 0);
            }
        }
    }
}