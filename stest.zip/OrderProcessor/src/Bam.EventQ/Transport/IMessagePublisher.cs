﻿namespace Bam.EventQ.Transport
{
    public interface IMessagePublisher
    {
        void Publish(int topic, byte[] data, int index, int count);
    }
}
