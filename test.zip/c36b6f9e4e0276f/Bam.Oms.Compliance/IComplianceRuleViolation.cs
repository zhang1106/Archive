﻿namespace Bam.Oms.Compliance
{
    public interface IComplianceRuleViolation
    {
        int RuleId { get; set; }
        string RuleName { get; set; }
        ComplianceViolationLevel ViolationLevel { get; set; }
        bool IsViolationOverriden { get; set; }
        /// <summary>
        /// custom data in json format that can be specific to rules
        /// </summary>
        string CustomData { get; set; }
    }
}
