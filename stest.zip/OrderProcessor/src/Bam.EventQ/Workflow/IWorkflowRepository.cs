﻿using System;
using System.Collections.Generic;

namespace Bam.EventQ.Workflow
{
    public interface IWorkflowRepository
    {
        IReadOnlyList<KeyValuePair<Type, IWorkflow>> GetAll();
    }
}
