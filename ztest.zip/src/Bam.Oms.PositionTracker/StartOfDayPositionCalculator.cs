﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data;

namespace Bam.Oms.PositionTracker
{
    public class StartOfDayPositionCalculator : IStartOfDayPositionCalculator
    {
        private readonly IPositionEffectCalculator _effectCalculator;
        private readonly ILogger _logger;

        public StartOfDayPositionCalculator(IPositionEffectCalculator effectCalculator, ILogger logger)
        {
            _effectCalculator = effectCalculator;
            _logger = logger;
        }

        private static IReadOnlyList<IPosition> CreatePositionsFromSod(IReadOnlyList<IPosition> sodPositions)
        {
            var poistions = from p in sodPositions
                            group p by new { p.Portfolio, p.Security, p.Stream }
                into grp
                            select new Position()
                            {
                                Portfolio = grp.Key.Portfolio,
                                Security = grp.Key.Security,
                                TheoreticalQuantity =  grp.Sum(t => t.ActualQuantity),
                                ActualQuantity = grp.Sum(t => t.ActualQuantity),
                                LongMarkingQuantity = grp.Where(p => !Utility.IsOmni(p.CustodianName)).Sum(t => t.ActualQuantity),
                                ShortMarkingQuantity = grp.Where(p => !Utility.IsOmni(p.CustodianName)).Sum(t => t.ActualQuantity),
                                Stream = grp.Key.Stream,
                                DistributedPositions =
                                    grp.Select(
                                        g =>
                                            new DistributedPosition()
                                            {
                                                FundCode = g.FundCode,
                                                CustodianName = g.CustodianName,
                                                Quantity = g.ActualQuantity,
                                            }).ToList()
                            } as IPosition;
            var iPositions = poistions.ToList<IPosition>();
            return iPositions;
        }
        
        public IReadOnlyList<IPositionSet> Adjust(
            IReadOnlyList<IPositionSet> positionSets,
            IReadOnlyList<IPosition> newSodPositions,
            IDictionary<IPositionKey, IList<IOrder>> orders,
            IDictionary<IPositionKey, IList<IBlockTrade>> trades)
        {
            //assume sod positions are at custodian&fund level
            var newPositions = CreatePositionsFromSod(newSodPositions);

            var lookup = newPositions.ToDictionary(p => new PositionKey(p.Portfolio, p.Security));

            var sets = new Dictionary<IPositionKey, IPositionSet>();
            foreach (var set in positionSets)
            {
                var pk = new PositionKey(set.Position.Portfolio, set.Position.Security);
                IPosition replacement;
                if (lookup.TryGetValue(pk, out replacement))
                {
                    _effectCalculator.ReplacePosition(set, replacement);
                    sets[pk] = set;
                }
            }

            Replay(sets, orders, trades);
            return sets.Values.ToList();
        }

        public IReadOnlyList<IPositionSet> Calculate(
            IReadOnlyList<IPosition> sodPositions,
            IDictionary<IPositionKey, IList<IOrder>> orders,
            IDictionary<IPositionKey, IList<IBlockTrade>> trades)
        {
            //assume sod positions are at custodian&fund level
            var positions = CreatePositionsFromSod(sodPositions);

            var sodPositionKeys =
                new HashSet<IPositionKey>(
                    positions.Select(p => new PositionKey(p.Portfolio, p.Security)));

            var newPositionKeys = orders.Keys.Except(sodPositionKeys).ToList();
            var newPositions = new List<IPosition>(newPositionKeys.Count);
            foreach (var pk in newPositionKeys)
            {
                newPositions.Add(new Position(pk.Portfolio, pk.Security)
                {
                    TheoreticalQuantity = 0,
                    ActualQuantity = 0,
                    LongMarkingQuantity = 0,
                    ShortMarkingQuantity = 0
                });
            }

            positions = positions.Concat(newPositions).ToList();            

            var aggUnits = (
                from p in positions
                let key = new AggUnitKey(p.Portfolio.AggregationUnit, p.Security)
                group p by key into g
                select new AggUnitPosition
                {
                    Key = g.Key,
                    ShortMarkingQuantity = g.Sum(i => i.ShortMarkingQuantity)
                }).ToDictionary(i => i.Key);

            var complianceGroups = (
                from p in positions
                let key = new ComplianceGroupKey(p.Portfolio.ComplianceGroup, p.Security)
                group p by key into g
                select new CompliancePosition
                {
                    Key = g.Key,
                    ShortMarkingQuantity = g.Sum(i => i.ShortMarkingQuantity),
                    LongMarkingQuantity = g.Sum(i => i.LongMarkingQuantity)
                }).ToDictionary(i => i.Key);

            var sets = positions.Select(
                p => (IPositionSet)new PositionSet
                {
                    Position = p,
                    CompliancePosition =
                        complianceGroups[new ComplianceGroupKey(p.Portfolio.ComplianceGroup, p.Security)],
                    AggUnitPosition = aggUnits[new AggUnitKey(p.Portfolio.AggregationUnit, p.Security)]
                })
                // ignore duplicate position keys here, this only really happens in DEV when the unit tests
                // insert trash data into the database table ...
                .GroupBy(s => (IPositionKey)new PositionKey(s.Position.Portfolio, s.Position.Security))
                .ToDictionary(g => g.Key, g => g.First());
            
            Replay(sets, orders, trades);
            return sets.Values.ToArray();
        }

        public IReadOnlyList<IPosition> Pick(
            IReadOnlyList<IPosition> officialSodPositions, 
            IReadOnlyList<IPosition> snapshotSodPositions,
            DateTime currentBusinessDay)
        {
            var officialByStream = officialSodPositions.GroupBy(p => p.Stream)
                .ToDictionary(k => k.Key, g => g.Max(p => p.EntryDate));
            var snapshotByStream = snapshotSodPositions.GroupBy(p => p.Stream)
                .ToDictionary(k => k.Key, g => g.Max(p => p.EntryDate));

            var positions = new List<IPosition>();
            foreach (var stream in officialByStream.Keys.Union(snapshotByStream.Keys))
            {
                if (officialByStream.ContainsKey(stream) &&
                    snapshotByStream.ContainsKey(stream))
                {
                    if (!DateTime.MinValue.Equals(currentBusinessDay) &&
                        !currentBusinessDay.Equals(officialByStream[stream]))
                    {
                        _logger.Info($"Using snapshot positions as SOD for stream '{stream}'");
                        positions.AddRange(snapshotSodPositions.Where(p => p.Stream == stream));
                    }
                    else
                    {
                        _logger.Info($"Using regular SOD positions for stream '{stream}'");
                        positions.AddRange(officialSodPositions.Where(p => p.Stream == stream));
                    }
                }
                else if (officialByStream.ContainsKey(stream))
                {
                    _logger.Info($"Using regular SOD positions for stream '{stream}'");
                    positions.AddRange(officialSodPositions.Where(p => p.Stream == stream));
                }
                else
                {
                    _logger.Info($"Using snapshot positions as SOD for stream '{stream}'");
                    positions.AddRange(snapshotSodPositions.Where(p => p.Stream == stream));
                }
            }

            return positions;
        }

        private void Replay(
            IDictionary<IPositionKey, IPositionSet> sets,
            IDictionary<IPositionKey, IList<IOrder>> orders,
            IDictionary<IPositionKey, IList<IBlockTrade>> trades)
        {
            foreach (var key in orders.Keys)
            {
                IPositionSet set;
                if (!sets.TryGetValue(key, out set))
                {
                    _logger.Error($"Missing position set for '{key}'");
                    continue;
                }

                foreach (var g in orders[key].GroupBy(o => o.ClientOrderId))
                {
                    IOrder current = null;
                    foreach (var order in g)
                    {
                        _logger.Debug($"Replaying order {order} on position set {set}");
                        _effectCalculator.ApplyEffects(set, current, null, order, null);
                        current = order;
                    }
                }
            }

            var lookup = orders.Values.SelectMany(l => l).ToLookup(o => o.ClientOrderId);

            foreach (var key in trades.Keys)
            {
                IPositionSet set;
                if (!sets.TryGetValue(key, out set))
                {
                    _logger.Error($"Missing position set for '{key}'");
                    continue;
                }

                foreach (var g in trades[key].GroupBy(t => t.TradeId))
                {
                    IBlockTrade current = null;
                    foreach (var trade in g)
                    {
                        var order = lookup[trade.ClientOrderId].Last();
                        _logger.Debug($"Replaying trade {trade} on position set {set}");
                        _effectCalculator.ApplyEffects(set, order, current, order, trade);
                        current = trade;
                    }
                }
            }
        }
    }
}
