﻿using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Filtering;
using Bam.Oms.Compliance.Filters;

namespace Bam.Oms.Compliance.DataProvider
{
    public class DWSecurityProvider : ISecurityProvider
    {
        private readonly ISecurityDBRepository _securityDbRepository;
        private readonly IFactProvider _factProvider;

        public IDictionary<string, ISecurity> DWSecurities
        {
            get; private set;
        }
        public DWSecurityProvider(ISecurityDBRepository securityDbRepository, IFactProvider factProvider)
        {
            _securityDbRepository = securityDbRepository;
            _factProvider = factProvider;
            DWSecurities = new Dictionary<string, ISecurity>();
        }
        public void RefreshData()
        {
            DWSecurities = new Dictionary<string, ISecurity>();
            var parameter = new Parameter()
            {
                Operator = new ComplianceOperator(_factProvider) {OperatorType = OperatorType.InTheList},
                Property = "SecurityType",
                Value = "SupportedSecurityTypes"
            };
            var filter = new Filter<ISecurity>();
            filter.AddToFilter(string.Empty, new Parameter[] {parameter});

            foreach (var s in _securityDbRepository.GetSecurities(filter).Where(s => !DWSecurities.ContainsKey(s.BamSymbol)))
            {
                DWSecurities.Add(s.BamSymbol, s);
            }
        }
        public ISecurity GetSecurity(string bamSymbol)
        {
            if (DWSecurities.ContainsKey(bamSymbol))
            {
                return DWSecurities[bamSymbol];
            }else
            {
                return null;
            }
        }
    }
}
