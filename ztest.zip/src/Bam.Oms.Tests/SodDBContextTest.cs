﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Bam.Oms.Persistence.DBContext;
using BAM.Infrastructure.Ioc;
using NUnit.Framework;
using Bam.Oms.Data.Positions;
using Bam.Oms.SodPosition.Svc;
using Moq;
using Bam.Oms.SodPosition.Svc.File;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.RefData;

namespace Bam.Oms.Tests
{
    [Category("Integration")]
    [TestFixture]
    public class SodDBContextTest
    {
        private readonly SodPositionDBContext _dbContext;
        private readonly DateTime _testDate;
        private readonly ILogger _logger;
        private readonly ISettings _settings;
        private string _connectionString = @"Data Source=bos-db-dev;Initial Catalog = OrderGateway; UID=BossApp;Pwd=BossApp1;Application Name = OrderGateway";

        public SodDBContextTest()
        {
            _testDate = DateTime.ParseExact("20151112", "yyyyMMdd", CultureInfo.InvariantCulture);
            _logger = new Mock<ILogger>().Object;
            Mock<ISettings> settings  = new Mock<ISettings>();
            settings.SetupGet(s => s.OrderGatewayConnectionString).Returns(_connectionString);
            _settings = settings.Object;
            _dbContext = new SodPositionDBContext(new PositionDBRepository(_settings, _logger), new PositionAuditRepository(_settings, _logger),
                new PositionArchiveRepository(_settings, _logger), new ActionRepository(_settings, _logger), new ActionLogRepository(_settings, _logger), new ExceptionRepository(_settings, _logger));

        }

        [Test]
        public void TestBulkInsert()
        {
            ISodPositionEdit sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, _dbContext, new Mock<IAccountService>().Object, new Mock<ISecurityMasterService>().Object);
            sEdit.Start();

            var testPositions = SodPositionTestDataProvider.SodPositions;
            var positions = _dbContext.Positions.GetAll().Where(p=>p.Stream==testPositions[0].Stream);

            foreach (var position in testPositions)
            {
                position.FundCode = $"TestCode{DateTime.Now.Ticks}";
                if (positions.Any())
                {
                    position.EntryDate = positions.First().EntryDate;
            }
            }
            
            var bPositions = sEdit.BulkInsertPosition(testPositions);

            Assert.IsTrue(bPositions.Count == 2);
            foreach (var p in bPositions)
            {
                _dbContext.Positions.Clear(p);
        }
        }

//        [Test]
//        public void TestBulkUpdate()
//        {
//            var accountSvcMock = new Mock<IAccountService>();
//            accountSvcMock.Setup(r => r.SetAccountAttributes(It.IsAny<IEnumerable<IContainsPortfolio>>()))
//                .Returns(new List<IContainsPortfolio>() {new Position()});
//
//            var sEdit = new SodPositionEditDapper(new Mock<ILogger>().Object, new Mock<IFileLoading>().Object, 
//                _dbContext, accountSvcMock.Object);
//            sEdit.Start();
//            var testPositions = sEdit.GetSodPositions(null, null, null, null, null, null, null);
//            
//            var positionsToUpdate = new List<Position>()
//            {
//                testPositions[0] ,
//            };
//
//            foreach(var p in positionsToUpdate)
//            {
//                p.ActualQuantity = 0;
//            }
//
//            var positions = sEdit.BulkUpdatePosition(positionsToUpdate);
//            Assert.IsTrue(positions[0].ActualQuantity == 0);
//        }

        [Test]
        public void TestAddUpdateException()
        {
            var inputException =
                new SodException()
                {
                    Source = "Source1",
                    Data = "Data1",
                    Description = "Description1",
                    CreatedOn = _testDate
                };

            var sodException = 
            _dbContext.Exceptions.Save(inputException);

            Assert.IsNotNull(sodException.ExceptionId);
            Assert.AreEqual(sodException.Source, inputException.Source);
            Assert.AreEqual(sodException.Data, inputException.Data);
            Assert.AreEqual(sodException.Description, inputException.Description);

            sodException.Data = "Test";
            _dbContext.Exceptions.Update(sodException);
            var updated = _dbContext.Exceptions.GetById(sodException.ExceptionId);
            Assert.IsTrue(updated.Data == "Test");

            _dbContext.Exceptions.Clear(sodException);
        }

        [Test]
        public void TestAddSodPosition()
        {
            var testPosition = SodPositionTestDataProvider.SodPositions[0];
            testPosition.FundCode = $"TestCode{DateTime.Now.Ticks}";
            var positions = _dbContext.Positions.GetAll().Where(p => p.Stream == testPosition.Stream);
            if (positions.Any()){ testPosition.EntryDate = positions.First().EntryDate; }
            var position = _dbContext.Positions.Save(testPosition);

            Assert.IsNotNull(position);
            Assert.IsNotNull(position.PositionId);
            Assert.IsNotNull(position.Portfolio.PMCode);

            _dbContext.Positions.Clear(position);
        }

        [Test]
        public void TestAddSodPositions()
        {
            var positions = SodPositionTestDataProvider.SodPositions;
            var currPositions = _dbContext.Positions.GetAll().Where(p => p.Stream == positions[0].Stream);

            foreach (var position in positions)
            {
                position.FundCode = string.Format("TestCode{0}", DateTime.Now.Ticks);
                if (currPositions.Any()) { position.EntryDate = currPositions.First().EntryDate; }
            }
           
            var saved = _dbContext.Positions.Save(positions).ToList();

            Assert.IsNotNull(saved);
            Assert.IsTrue(saved.Count == 2);

            foreach (var position in saved)
            {
                Assert.IsNotNull(position.PositionId);
                Assert.IsNotNull(position.Portfolio.PMCode);

                _dbContext.Positions.Clear(position);
            }
        }

        [Test]
        public void TestGetSodPositionById()
        {
            var testPosition = SodPositionTestDataProvider.SodPositions[0];
            testPosition.FundCode = $"TestCode{DateTime.Now.Ticks}";

            var position = _dbContext.Positions.Save(testPosition);

            var thisPosition = _dbContext.Positions.GetById(position.PositionId);
            Assert.IsNotNull(thisPosition);
        }

        [Test]
        public void TestGetSodPositionAudits()
            {
            var positionAudits = _dbContext.PositionAudits.GetAll().ToList();

            Assert.IsNotNull(positionAudits);
            Assert.IsTrue(positionAudits.Count > 0);
            Assert.IsNotNull(positionAudits[0].Position);
            Assert.IsNotNull(positionAudits[0].Position.Portfolio);
        }

        [Test]
        public void TestGetSodPositionAuditsByEntryDateAndId()
        {
            var testPosition = SodPositionTestDataProvider.SodPositions[0];
            testPosition.FundCode = $"TestCode{DateTime.Now.Ticks}";
            testPosition.EntryDate = DateTime.Now.Date;

            var positions = _dbContext.Positions.GetAll().Where(p => p.Stream == testPosition.Stream);
            if (positions.Any()) { testPosition.EntryDate = positions.First().EntryDate; }

            var position = _dbContext.Positions.Save(testPosition);
            var positionAudits = _dbContext.PositionAudits.Get(new {EntryDate = DateTime.Now.Date, PositionId = position.PositionId}).ToList();
            Assert.IsNotNull(positionAudits);
        }

        [Test]
        public void TestAddSodPositionAudits()
        {
            var positionAudits =
            _dbContext.PositionAudits.Save(
                SodPositionTestDataProvider.SodPositions.Select(p => new PositionAudit() {Position = p})).ToList();

            Assert.IsNotNull(positionAudits);
            Assert.IsTrue(positionAudits.Count > 0);
            Assert.IsNotNull(positionAudits[0].Position);

            foreach (var a in positionAudits)
            {
                _dbContext.PositionAudits.Clear(a);
        }

        }

        [Test]
        public void TestAddSodPositionArchive()
        {
            var archive = new PositionArchive()
            {
                Position = SodPositionTestDataProvider.SodPositions[0]
            };
            var insertedArchive = _dbContext.PositionArchives.Save(archive);

            Assert.IsNotNull(insertedArchive);
            Assert.IsTrue(insertedArchive.PositionArchiveId > 0);
            Assert.IsNotNull(insertedArchive.Position);
            Assert.IsNotNull(insertedArchive.Position.Portfolio);

            _dbContext.PositionArchives.Clear(insertedArchive);
        }

        [Test]
        public void TestGetSodPositionArchive()
        {
            var positionArchives  = _dbContext.PositionArchives.Get(new {CustodianName = "GOLDMAN"}).ToList();
            Assert.IsNotNull(positionArchives);
            Assert.IsTrue(positionArchives.Count > 0);
            Assert.IsNotNull(positionArchives[0].Position.Portfolio.PMCode);
        }

        [Test]
        public void TestFindById()
        {
            SodException exception = _dbContext.Exceptions.GetById(1);
            Assert.IsNotNull(exception);
            Assert.AreEqual(1, exception.ExceptionId);
        }

        [Test]
        public void TestFindAll()
        {
            IList<SodException> exceptions = _dbContext.Exceptions.GetAll().ToList();
            Assert.IsNotNull(exceptions);
            Assert.IsTrue(exceptions.Count > 0);
        }

        [Test]
        public void TestFindByFields()
        {
            IList<SodException> exceptions = _dbContext.Exceptions.Get(new { Source = "Source1", Description = "Description1" }).ToList();
            Assert.IsNotNull(exceptions);
            Assert.IsTrue(exceptions.Count > 0);
        }

        [Test]
        public void TestFindCustom()
        {
            IList<SodException> exceptions = _dbContext.Exceptions.Get("Source LIKE @SRC_PATTERN", new { SRC_PATTERN = "Source%" }).ToList();
            Assert.IsNotNull(exceptions);
            Assert.IsTrue(exceptions.Count > 0);
        }
    }
}
