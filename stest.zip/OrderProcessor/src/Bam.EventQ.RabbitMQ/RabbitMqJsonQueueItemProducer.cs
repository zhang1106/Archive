﻿using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Bam.EventQ.Transport;

namespace Bam.EventQ.RabbitMQ
{
    public class RabbitMqJsonQueueItemProducer<TBase, TItem> :
        QueueItemProducerBase<PipelineQueueItem<TBase>> where TItem : TBase
    {
        private readonly RabbitMqExternalMessageSource<TItem> _source;

        public RabbitMqJsonQueueItemProducer(IMessageSubscriber subscriber, int bufferSize)
        {
            _source = new RabbitMqExternalMessageSource<TItem>(subscriber, bufferSize);
            _source.Initialize(Handle);
        }

        public override void Start()
        {
            base.Start();
            _source.Start();
        }

        public override void Stop()
        {
            _source.Stop();

            if (Stopped)
            {
                base.Start();
            }

            base.Stop();
        }

        public override bool CanPause => true;

        public override void Pause()
        {
            base.Stop();
        }

        public override void Resume()
        {
            base.Start();
        }

        private void Handle(TItem item)
        {
            if (Stopped)
            {
                Started.WaitOne();
            }

            Queue.PublishPayload(item);
        }
    }
}
