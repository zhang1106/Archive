﻿using System;
using System.Collections.Generic;

namespace Bam.Oms.Data.Configuration
{
    public interface IDateProvider
    {
        
        DateTime SetSodTime(string sodTime = "17:00:00", DateTime now = default(DateTime));
    }
}