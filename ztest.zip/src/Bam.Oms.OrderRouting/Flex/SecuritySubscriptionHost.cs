﻿using System;
using System.Text.RegularExpressions;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using Bam.Oms.OrderRouting.Contracts;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Ft;
using Grpc.Core;
using Grpc.Core.Utils;
using static System.String;
using ISecurityServiceClient = Ft.SecurityService.ISecurityServiceClient;
using Security = Bam.Oms.Data.Securities.Security;

namespace Bam.Oms.OrderRouting.Flex
{
    public class SecuritySubscriptionHost : SubscriptionHost<SecuritySubscriptionResponse>, ISecuritySubscriptionHost
    {
        private readonly ISecurityServiceClient _securityServiceClient;
        private readonly ILogger _logger;
        private event Action<ISecurity> SecurityUpdatedHandler;

        private static readonly Regex BBG_YELLOWKEY_PATTERN = new Regex(@"(?i)\b(Govt|Corp|Mtge|Pfd|M-Mkt|Equity|Comdty|Index|Curncy|Client|Alpha)\b(?-i)\z");

        public event Action<ISecurity> SecurityUpdated
        {
            add
            {
                SecurityUpdatedHandler += value;
                Subscribe();
            }
            remove
            {
                SecurityUpdatedHandler -= value;
            }
        }

        public SecuritySubscriptionHost(ISecurityServiceClient securityServiceClient, ILogger logger, IGrpcChannel channel, ISettings settings, ILoggingAgent eventLogger) 
            : base(eventLogger, logger, channel, settings)
        {
            if (securityServiceClient == null) throw new ArgumentNullException(nameof(securityServiceClient));
            if (logger == null) throw new ArgumentNullException(nameof(logger));

            _securityServiceClient = securityServiceClient;
            _logger = logger;
        }

        protected override void NewItemHandler(SecuritySubscriptionResponse response)
        {
            _logger.Debug($"Flex security update {response}");

            if (SecurityUpdatedHandler != null)
                SecurityUpdatedHandler(Parse(response.Security));
        }

        protected override void Unsubscribe()
        {
            var request = new SubscriptionRequest { Name = SubscriptionId };
            //this will cause the unsubscribe to block
            //the call option of 1min will allow this to timeout if it doesn't unsubscribe
            var asyncServerStreamingCall = _securityServiceClient.Unsubscribe(request, new CallOptions(null, DateTime.UtcNow.AddSeconds(15)));

            if (asyncServerStreamingCall != null)
            {
                try
                {
                    var result = asyncServerStreamingCall.ResponseStream.ToListAsync().Result;
                }
                catch (AggregateException aex)
                {
                    _logger.Warn($"Unsubscribe timeed out for type  {SubscriptionType}");
                }
            }
        }

        protected override void Resubscribe()
        {
            Unsubscribe(); //not going to wait for the unsubscribe to return as this connection may have dropped anyways.
            Subscribe();
        }

        private void Subscribe()
        {
            SubscriptionId = Guid.NewGuid().ToString();
            var request = new SubscriptionRequest() { Name = SubscriptionId };

            var subscribeResponse = _securityServiceClient.Subscribe(request);

            _logger.InfoFormat($"Returned subscription stream for id {SubscriptionId}, stream created and passed to polling task");

            //this is a limitation of the Grpc not allowing you to created or inherit from the AsyncServerStreamingCall, so for the unit test we want to check for null
            if (subscribeResponse != null)
                Subscribe(subscribeResponse.ResponseStream);
        }

        public static Security Parse(Ft.Security flexSecurity)
        {
            var security = new Security();

            if (flexSecurity.CommonData != null)
            {
                security.BamSymbol = flexSecurity.CommonData.Symbol;
                security.Ticker = flexSecurity.CommonData.Ticker;
                security.BloombergSymbol = flexSecurity.CommonData.BloombergSymbol;
                security.Cusip = flexSecurity.CommonData.Cusip;
                security.Currency = flexSecurity.CommonData.Currency;
                security.Isin = flexSecurity.CommonData.Isin;
                security.Sedol = flexSecurity.CommonData.Sedol;
                security.Issuer = flexSecurity.CommonData.LegalEntityName;

                if (!IsNullOrWhiteSpace(flexSecurity.CommonData.SecurityType))
                {
                    security.SecurityType = Utility.GetEnumValue<SecurityType>(flexSecurity.CommonData.SecurityType);
                }                
                                    
                // Why would FLEX send w/o a BAM Symbol?
                if (string.IsNullOrWhiteSpace(security.BamSymbol) &&
                    !string.IsNullOrWhiteSpace(security.BloombergSymbol))
                {
                    security.BamSymbol = BBG_YELLOWKEY_PATTERN.Replace(security.BloombergSymbol, Empty);
                    if (security.SecurityType == SecurityType.EquitySwap)
                    {
                        security.BamSymbol += " SWAP";
                    }
                }                
            }

            return security;
        }
    }
}