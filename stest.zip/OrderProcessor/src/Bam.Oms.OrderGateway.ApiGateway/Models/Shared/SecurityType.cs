﻿namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public enum SecurityType
    {
        Unknown = 0,
        Equity,
        EquityOption,
        EquitySwap,
        ForwardFx,
        SpotFx,
        Future,
        FutureOption,
        FXOption,
        Bond,
        Repo,
        Other
    }
}
