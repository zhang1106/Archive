﻿namespace Bam.EventQ.Hosting
{
    public interface IService
    {
        string Name { get; }
        void Start();
        void Stop();
    }
}
