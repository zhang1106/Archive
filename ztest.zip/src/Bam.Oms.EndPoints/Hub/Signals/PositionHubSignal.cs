﻿using Bam.Oms.Data.Positions;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Filtering;
using Bam.Oms.Messaging;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;

namespace Bam.Oms.EndPoints.Hub.Signals
{
    public class PositionHubSignal : HubSignal<Position, IPositionRepository>
    {
        public PositionHubSignal(IFilter<Position> filter, IOrderHandler orderHandler, ILogger logger, IOrderRepository orderRepository, ITradeRepository tradeRepository) : base(filter, orderHandler, logger, orderRepository, tradeRepository)
        {
        }

        protected override IHubContext<ISignalRClient<SignalRPacket<Position>>> GetHubContext()
        {
            return GlobalHost.ConnectionManager.GetHubContext<PositionHub, ISignalRClient<SignalRPacket<Position>>>();
        }
    }
}