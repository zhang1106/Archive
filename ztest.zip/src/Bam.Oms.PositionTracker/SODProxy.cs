﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Positions;
using Bam.Oms.SodPosition.Svc;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.PositionTracker
{
    public class SODProxy : ISODProxy
    {
        private readonly ISodPositionEdit _sodService;
        private ISettings _settings;
        private ILoggingAgent _eventLogger;
        private ILogger _logger;

        private readonly ConcurrentDictionary<string, IList<IPosition>> _sodPositions = new ConcurrentDictionary<string, IList<IPosition>>();
        public event Action<IList<Position>> SodPositionUpdated;

        public SODProxy(ISodPositionEdit sodLoader, ILogger logger, ILoggingAgent eventLogger, ISettings settings)
        {
            if (sodLoader == null) throw new ArgumentNullException(nameof(sodLoader));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (eventLogger == null) throw new ArgumentNullException(nameof(eventLogger));
            if (settings == null) throw new ArgumentNullException(nameof(settings));

            _sodService = sodLoader;
            _settings = settings;
            _logger = logger;
            _eventLogger = eventLogger;

            _sodService.SodPositionUpdated += SodServiceOnSodPositionUpdated;
        }        

        public void Initialize()
        {
            IList<IPosition> sodPositions = _sodService.GetPositions(userId: string.Empty, asofdate: null,
                stream: null, fundCode: null, custodianAccountCode: null,
                strategyCode: null, securityType: null, bamSymbol: null);

            foreach (IPosition position in sodPositions)
            {
                _sodPositions.AddOrUpdate(position.Security.Key, new List<IPosition>() { position },
                    (k, pl) =>
                    {
                        pl.Add(position);
                        return pl;
                    })
            ;
            }
        }

        public IList<IPosition> GetPositions(string bamSymbol)
        {
            IList<IPosition> returnList;
            if (!string.IsNullOrWhiteSpace(bamSymbol))
            {
                if (_sodPositions.TryGetValue(bamSymbol, out returnList))
                {
                    return returnList;
                }
            }
            else
            {
                returnList = new List<IPosition>();
                foreach (var kvp in _sodPositions)
                {
                    ((List<IPosition>)returnList).AddRange(kvp.Value);
                }
                return returnList;
            }
            return new List<IPosition>();
        }

        private void SodServiceOnSodPositionUpdated(IList<Position> positions)
        {
            this.SodPositionUpdated?.Invoke(positions);
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~SODProxy() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
