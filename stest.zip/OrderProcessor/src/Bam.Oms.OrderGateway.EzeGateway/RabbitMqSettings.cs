﻿using System;
using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.EzeGateway
{
    public class RabbitMqSettings : AppSettingsBase
    {
        public RabbitMqSettings() : base("EzeGateway.RabbitMq.") 
        {

        }
        
        public string Endpoint
        {
            get { return GetValue(() => Endpoint); }
        }

        public string TradeUpdateExchange
        {
            get { return GetValue(() => TradeUpdateExchange); }
        }

        public string TradeUpdateQueue
        {
            get { return GetValue(() => TradeUpdateQueue); }
        }

        public bool Receive
        {
            get { return GetValue(() => Receive); }
        }
        public bool Publish
        {
            get { return GetValue(() => Publish); }
        }

        public TimeSpan RetryInterval
        {
            get { return GetValue(() => RetryInterval, TimeSpan.FromSeconds(5)); }
        }
    }
}
