﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public class StrategyAllocationService : AllocationServiceBase
    {
        private readonly IReferenceDataService _referenceDataService;
        private readonly IComplianceCache _complianceCache;

        private readonly List<KeyValuePair<Portfolio, double>> _positionRatios 
            = new List<KeyValuePair<Portfolio, double>>(8);
        private readonly List<KeyValuePair<Portfolio, double>> _ruleRatios 
            = new List<KeyValuePair<Portfolio, double>>(8);

        public StrategyAllocationService(
            IReferenceDataService referenceDataService,
            IComplianceCache complianceCache)
        {
            _referenceDataService = referenceDataService;
            _complianceCache = complianceCache;
        }

        public bool TryAllocate(Portfolio portfolio, CachedSecurity security, long quantity,
            Side side, Dictionary<Portfolio, long> allocations, out string message)
        {
            // 1. Base Case: it's not a split strategy
            StrategyAllocationRule rule;
            if (!_referenceDataService.TryGetStrategyAllocationRule(portfolio, out rule))
            {
                allocations[portfolio] = quantity;
                message = null;
                return true;
            }

            // 2. Split Case: Pro Rata for Closing orders, Rule Ratios for Opening orders (reject mix)
            _positionRatios.Clear();
            _ruleRatios.Clear();

            double total = 0;
            bool closing = false;
            bool opening = false;
            bool buying = side == Side.Buy || side == Side.Cover;

            foreach (var item in rule.Ratios)
            {
                _ruleRatios.Add(new KeyValuePair<Portfolio, double>(item.Key, (double) item.Value));

                double qty = GetTheoreticalQuantity(item.Key, security);
                closing |= qty < 0 && buying || qty > 0 && !buying;
                opening |= qty > 0 && buying || qty < 0 && !buying;
                qty = Math.Abs(qty);

                if (!qty.Equals(0))
                {
                    _positionRatios.Add(new KeyValuePair<Portfolio, double>(item.Key, qty));
                }

                total += qty;
            }

            if (!opening && !closing)
            {
                opening = true;
            }

            if (_ruleRatios.Count > 1 && (closing && total < quantity || closing && opening))
            {
                var error = total < quantity
                    ? "crossing zero for split strategy."
                    : "since constituent portfolios holdings are long and short.";

                message = $"Orders for portfolio '{portfolio}' not allowed {error}";
                return false;
            }

            if (closing && total.Equals(quantity))
            {
                foreach (var current in _positionRatios)
                {
                    allocations.Add(current.Key, (long) current.Value);
                }
            }
            else
            {
                if (closing)
                {
                    for (int i = 0; i < _positionRatios.Count; i++)
                    {
                        var current = _positionRatios[i];
                        _positionRatios[i] = new KeyValuePair<Portfolio, double>(
                            current.Key, current.Value/total);
                    }
                }

                Allocate(quantity, opening ? _ruleRatios : _positionRatios, allocations);
            }

            message = null;
            return true;
        }

        private long GetTheoreticalQuantity(Portfolio portfolio, CachedSecurity security)
        {
            var pk = new PositionKey(portfolio, security.Symbol);
            var set = _complianceCache.GetPositionSet(pk);
            return set.Position.TheoreticalQuantity;
        }
    }
}
