﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.PositionTracker;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.Compliance.Workflows
{
    public class SodPositionsWorkflow : Workflow, 
        IHandle<LoadSodPositions>,
        IHandle<UpdateSodPositions>
    {
        private readonly IComplianceCache _complianceCache;
        private readonly IPositionIdGenerator _positionIdGenerator;
        private readonly IReferenceDataService _referenceDataService;
        private readonly ISodPositionCalculator _sodPositionCalculator;
        private readonly HashSet<string> _existingSymbols;
        private readonly Dictionary<SodPositionKey, SodPosition> _publishSodPositions;

        public SodPositionsWorkflow(
            IComplianceCache complianceCache,
            ISodPositionCalculator sodPositionCalculator,
            IPositionIdGenerator positionIdGenerator,
            IReferenceDataService referenceDataService)
        {
            _complianceCache = complianceCache;
            _sodPositionCalculator = sodPositionCalculator;
            _positionIdGenerator = positionIdGenerator;
            _referenceDataService = referenceDataService;
            _existingSymbols = new HashSet<string>();
            _publishSodPositions = new Dictionary<SodPositionKey, SodPosition>();
        }

        public void Execute(LoadSodPositions input)
        {
            _existingSymbols.Clear();
            _publishSodPositions.Clear();

            using (Attach(_complianceCache))
            {
                foreach (var inputSodPosition in input.SodPositions)
                {
                    _existingSymbols.Add(inputSodPosition.Symbol);
                }

                // flatten sod allocations that are old
                foreach (var positionKey in _existingSymbols)
                {
                    var currentSodPositions = _complianceCache.GetSodPositions(positionKey);

                    foreach (var current in currentSodPositions)
                    {
                        if (IsInputNewer(input, current.AsOf))
                        {
                            current.ActualQuantity = 0;
                        }
                        
                        _publishSodPositions[current.Key] = current;
                    }
                }

                var newSodPositions = Convert(input);

                foreach (var replacement in newSodPositions)
                {
                    SodPosition current;
                    if (!_publishSodPositions.TryGetValue(replacement.Key, out current) ||
                        (current.ActualQuantity == 0 && IsInputNewer(input, current.AsOf)))
                    {
                        _publishSodPositions[replacement.Key] = replacement;
                    }
                }

                if (_publishSodPositions.Count == 0)
                {
                    Logger?.LogInformation($"Ignoring SOD position load because it does not contain any positions newer for ('{input.AsOf}', contingency = {input.IsContingency})");
                    return;
                }

                foreach (var positionKey in _existingSymbols)
                {
                    var currentSodPositions = _complianceCache.GetSodPositions(positionKey);

                    foreach (var current in currentSodPositions)
                    {
                        if (IsInputNewer(input, current.AsOf))
                        {
                            current.AsOf = input.AsOf;
                        }
                    }
                }

                var finalList = _publishSodPositions.Values.ToList();

                _complianceCache.UpdateSodPositions(finalList, input.IsContingency);
                var positions = Convert(finalList);
                var orders = _complianceCache.GetOrders(_existingSymbols);
                var sets = _sodPositionCalculator.Calculate(positions, orders);

                _complianceCache.Save(sets);
            }
        }

        public void Execute(UpdateSodPositions input)
        {
            using (Attach(_complianceCache))
            using (Attach(_sodPositionCalculator))
            {
                var updatedSods = Convert(input);
                _complianceCache.UpdateSodPositions(updatedSods, false);

                var sodPositions = Convert(updatedSods.ToArray()).ToList();
                var keys = sodPositions.Select(p => p.Key).ToList();
                var sets = _complianceCache.GetPositionSets(keys);
                var orders = _complianceCache.GetOrders(keys);

                var updated = _sodPositionCalculator.Adjust(sets, sodPositions, orders);
                _complianceCache.Save(updated);
            }
        }

        private bool IsInputNewer(LoadSodPositions input, DateTime compare)
        {
            return input.IsContingency && input.AsOf > compare ||
                   !input.IsContingency && input.AsOf >= compare;
        }

        private List<SodPosition> Convert(LoadSodPositions input)
        {
            var result = new List<SodPosition>(input.SodPositions.Count);
            foreach (var item in input.SodPositions)
            {
                var record = ValidateAndCreateSodPosition(
                    input.AsOf, item.Strategy,
                    item.Symbol, item.Fund, item.Custodian, item.Quantity);
                if (record != null)
                {
                    result.Add(record);
                }
            }

            return result;
        }

        private List<SodPosition> Convert(UpdateSodPositions input)
        {
            var result = new List<SodPosition>(input.Items.Count);
            foreach (var item in input.Items)
            {
                var record = ValidateAndCreateSodPosition(
                    input.AsOf, item.Strategy,
                    item.Symbol, item.Fund, item.Custodian, item.Quantity);
                if (record != null)
                {
                    result.Add(record);
                }
            }

            return result;
        }

        private SodPosition ValidateAndCreateSodPosition(
            DateTime asOf, string strategy, 
            string symbol, string fund, string custodian, long quantity)
        {
            Portfolio portfolio;
            if (!Portfolio.TryParse(strategy, out portfolio))
            {
                Logger?.LogError($"Received SOD position with invalid portfolio '{strategy}'");
                return null;
            }

            PortfolioDetails details;
            if (!_referenceDataService.TryGetPortfolioDetails(portfolio, out details))
            {
                Logger?.LogError($"Received SOD position with unknown portfolio '{strategy}'");
                return null;
            }

            int tmp;
            if (!_referenceDataService.TryGetFundId(fund, out tmp))
            {
                Logger?.LogError($"Received SOD position with unknown fund '{fund}'");
                return null;
            }

            if (!_referenceDataService.TryGetBrokerId(custodian, out tmp))
            {
                Logger?.LogError($"Received SOD position with unknown custodian '{custodian}', setting to 'UNKNOWN'");
                custodian = "UNKNOWN";
            }

            var key = new SodPositionKey(portfolio, symbol, custodian, fund);
            return new SodPosition(key)
            {
                ActualQuantity = quantity,
                AsOf = asOf
            };
        }

        private IReadOnlyList<Position> Convert(IReadOnlyList<SodPosition> items)
        {
            var positions = new List<Position>();
            foreach (var item in items.GroupBy(i => new { i.Key.BamSymbol, i.Key.Portfolio }))
            {
                var portfolio = item.Key.Portfolio;
                PortfolioDetails details;
                if (!_referenceDataService.TryGetPortfolioDetails(portfolio, out details))
                {
                    Logger?.LogError($"Received SOD position update for unknown portfolio '{portfolio}'");
                    continue;
                }

                var key = new PositionKey(portfolio, item.Key.BamSymbol);
                var position = new Position(_positionIdGenerator.GetNextPositionId(), key, 
                    details.AggregationUnit, details.ComplianceGroup);

                var qty = item.Where(i => !_referenceDataService.IsOmni(i.Key.Custodian)).Sum(i => i.ActualQuantity);

                position.ApplyLongMarkingEffect(qty);
                position.ApplyShortMarkingEffect(qty);

                var actualEffects = new Dictionary<PositionAllocationKey, long>();
                var theoreticalEffects = new Dictionary<PositionAllocationKey, long>();
                foreach (var subItem in item.GroupBy(i => new { i.Key.BamSymbol, i.Key.Portfolio, FundCode = i.Key.Fund, CustodianName = i.Key.Custodian }))
                {
                    int fundId, custodianId;
                    if (!_referenceDataService.TryGetFundId(subItem.Key.FundCode, out fundId))
                    {
                        Logger?.LogWarning($"Received SOD position update for unknown fund '{subItem.Key.FundCode}'");
                        continue;
                    }

                    if (!_referenceDataService.TryGetBrokerId(subItem.Key.CustodianName, out custodianId))
                    {
                        Logger?.LogWarning($"Received SOD position update for unknown broker '{subItem.Key.CustodianName}'");
                        continue;
                    }

                    var allocationKey = new PositionAllocationKey(fundId, custodianId);
                    actualEffects[allocationKey] = subItem.Sum(i => i.ActualQuantity);
                    theoreticalEffects[allocationKey] = subItem.Sum(i => i.ActualQuantity);
                }

                position.ApplyActualQuantityEffect(actualEffects);
                position.ApplyTheoreticalQuantityEffect(theoreticalEffects);

                positions.Add(position);
            }

            return positions;
        }
    }
}