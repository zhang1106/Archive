﻿namespace Bam.EventQ.Queue
{
    public interface IQueueItemProducerFactory<in TItem>
    {
        IQueueItemProducer<TItem> Create(int[] sources, int[] topics);
    }
}
