﻿using Bam.EventQ.Solace;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Solace
{
    public class PositionSolaceTopicProvider : ISolaceTopicProvider<Position>
    {
        private readonly string _baseTopic;

        public PositionSolaceTopicProvider(string baseTopic)
        {
            _baseTopic = baseTopic ?? string.Empty;
            if (_baseTopic.Length > 0 && !_baseTopic.EndsWith("/"))
            {
                _baseTopic += "/";
            }
        }

        public string GetTopic(Position item)
        {
           return $"{_baseTopic}{item.Portfolio.AggregationUnit}/{item.Portfolio}/{item.Security.Key}";
        }
    }
}
