﻿using System;
using Bam.Oms.Data.Configuration;
using Bam.Compliance.Infrastructure.Logger;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.ApiGateway.Http
{
    public class HttpSettings : Settings
    {
        public HttpSettings(ILogger logger) :base(logger) 
        {
        }
    }
}
