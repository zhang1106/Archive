﻿namespace Bam.Oms.EndPoints.File
{
    public interface IFileConfiguration
    {
        string Path { get; set; }
    }
}