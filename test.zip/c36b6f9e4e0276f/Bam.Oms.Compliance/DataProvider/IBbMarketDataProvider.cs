﻿using System.Collections.Generic;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IBbMarketDataProvider  
    {
        MarketData GetMarketData(string symbol);
        IEnumerable<MarketData> GetMarketDataList(string[] symbols);
    }
}
