﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data;

namespace Bam.Oms.OrderMarker
{
    public interface IOrderMarker
    {
        IList<IOrder> MarkOrder(IOrder order);
        IList<IOrder> MarkOrder(IEnumerable<IOrder> order);

        event Action<IOrder, String> NotifyError;
        event Action<IOrder, String> NotifyWarning;
        event Action<IOrder, String> NotifyLog;
    }
}
