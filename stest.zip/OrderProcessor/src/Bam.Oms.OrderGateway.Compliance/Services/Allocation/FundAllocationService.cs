﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public class FundAllocationService : AllocationServiceBase
    {
        private readonly IReferenceDataService _referenceDataService;
        private readonly IComplianceCache _complianceCache;

        private readonly List<KeyValuePair<int, double>> _positionRatios
            = new List<KeyValuePair<int, double>>(8);
        private readonly List<KeyValuePair<int, double>> _ruleRatios
            = new List<KeyValuePair<int, double>>(8);

        private readonly Dictionary<int, long> _allocations
            = new Dictionary<int, long>();

        public FundAllocationService(
            IReferenceDataService referenceDataService,
            IComplianceCache complianceCache)
        {
            _referenceDataService = referenceDataService;
            _complianceCache = complianceCache;
        }

        public bool TryAllocate(Portfolio portfolio, CachedSecurity security, long quantity,
            Side side, int? fundOverride, Dictionary<int, FundAllocation> closing,
            Dictionary<int, FundAllocation> opening, out string message)
        {
            long availableToClose = 0, openingQty, availableToCloseSansOmni = 0;
            bool buying = side == Side.Buy || side == Side.Cover;

            if (fundOverride != null)
            {
                var openingAlloc = new FundAllocation();
                var closingAlloc = new FundAllocation();
                var theoretical = GetTheoreticalQuantity(portfolio, fundOverride.Value, security);

                Split(quantity, theoretical.Quantity, buying, out availableToClose, out openingQty);
                openingAlloc.Quantity = openingQty;
                closingAlloc.Quantity = availableToClose;

                Split(quantity, theoretical.QuantitySansOmni, buying, out availableToClose, out openingQty);
                openingAlloc.QuantitySansOmni = openingQty;
                closingAlloc.QuantitySansOmni = availableToClose;

                if (openingAlloc.Quantity != 0 || openingAlloc.QuantitySansOmni != 0)
                {
                    opening.Add(fundOverride.Value, openingAlloc);
                }

                if (closingAlloc.Quantity != 0 || closingAlloc.QuantitySansOmni != 0)
                {
                    closing.Add(fundOverride.Value, closingAlloc);
                }

                message = null;
                return true;
            }

            FundAllocationRule rule;
            if (!_referenceDataService.TryGetFundAllocationRule(portfolio, out rule))
            {
                message = $"No fund allocation rule for portfolio '{portfolio}'";
                return false;
            }

            _positionRatios.Clear();
            _ruleRatios.Clear();

            foreach (var item in rule.Ratios)
            {
                _ruleRatios.Add(new KeyValuePair<int, double>(item.Key, (double)item.Value));

                var theoretical = GetTheoreticalQuantity(portfolio, item.Key, security);
                if (theoretical.Quantity < 0 && buying || theoretical.Quantity > 0 && !buying)
                {
                    long qty = Math.Abs(theoretical.Quantity);
                    _positionRatios.Add(new KeyValuePair<int, double>(item.Key, qty));
                    availableToClose += qty;
                }

                if (theoretical.QuantitySansOmni < 0 && buying || theoretical.QuantitySansOmni > 0 && !buying)
                {
                    long qty = Math.Abs(theoretical.QuantitySansOmni);
                    availableToCloseSansOmni += qty;
                }
            }

            //closing fund alloc
            if (availableToClose > 0 && availableToClose < quantity) //partial closing
            {
                foreach (var item in _positionRatios)
                {
                    closing.Add(item.Key, new FundAllocation { Quantity = (long)item.Value });
                }
            }
            else if (availableToClose >= quantity) //all closing alloc
            {
                for (int i = 0; i < _positionRatios.Count; i++)
                {
                    var current = _positionRatios[i];
                    _positionRatios[i] = new KeyValuePair<int, double>(
                        current.Key, current.Value / availableToClose);
                }

                _allocations.Clear();
                Allocate(Math.Min(availableToClose, quantity), _positionRatios, _allocations);
                foreach (var item in _allocations)
                {
                    closing.Add(item.Key, new FundAllocation { Quantity = item.Value });
                }
            }

            //opening fund alloc
            openingQty = quantity - Math.Min(availableToClose, quantity);
            if (openingQty > 0)
            {
                _allocations.Clear();
                Allocate(openingQty, _ruleRatios, _allocations);
                foreach (var item in _allocations)
                {
                    opening.Add(item.Key, new FundAllocation { Quantity = item.Value });
                }
            }

            //allocating closing sans OMNI to fund allocations
            var keys = closing.Keys.ToList();
            keys.Sort();
            foreach (var key in keys)
            {
                var val = closing[key];
                var allocatedNonOmniQty = Math.Min(val.Quantity, availableToCloseSansOmni);
                availableToCloseSansOmni -= allocatedNonOmniQty;

                closing[key] = new FundAllocation
                {
                    Quantity = val.Quantity,
                    QuantitySansOmni = allocatedNonOmniQty
                };
            }

            keys = opening.Keys.ToList();
            keys.Sort();
            foreach (var key in keys)
            {
                var val = opening[key];
                var allocatedNonOmniQty = Math.Min(val.Quantity, availableToCloseSansOmni);
                availableToCloseSansOmni -= allocatedNonOmniQty;

                opening[key] = new FundAllocation
                {
                    Quantity = val.Quantity,
                    QuantitySansOmni = allocatedNonOmniQty
                };
            }

            message = null;
            return true;
        }

        private static void Split(long quantity, long holding, bool buying, out long closing, out long opening)
        {
            long closingQty = 0;
            if (holding < 0 && buying || holding > 0 && !buying)
            {
                closingQty = Math.Min(Math.Abs(holding), quantity);
            }

            opening = 0;
            closing = 0;

            if (closingQty > 0)
            {
                closing = closingQty;
            }

            if (closingQty != quantity)
            {
                opening = quantity - closingQty;
            }
        }

        private FundAllocation GetTheoreticalQuantity(Portfolio portfolio, int fundId, CachedSecurity security)
        {
            var pk = new PositionKey(portfolio, security.Symbol);
            var set = _complianceCache.GetPositionSet(pk);

            var result = new FundAllocation();
            foreach (var alloc in set.Position.TheoreticalAllocations)
            {
                if (alloc.Key.FundId == fundId)
                {
                    result.Quantity += alloc.Value.Quantity;
                    if (!_referenceDataService.IsOmni(alloc.Key.CustodianId))
                    {
                        result.QuantitySansOmni += alloc.Value.Quantity;
                    }
                }
            }

            return result;
        }
    }
}
