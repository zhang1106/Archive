﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;

namespace Bam.Oms.OrderGateway.EzeGateway.Services
{
    public class EzeWcfTradingClient : ClientBase<IEzeTradingServiceSync>
    {
        public EzeWcfTradingClient(string url)
            : base(CreateBinding(), CreateEndpoint(url))
        {
            
        }

        private static Binding CreateBinding()
        {
            return new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                ReceiveTimeout = TimeSpan.FromMinutes(10),
                SendTimeout = TimeSpan.FromMinutes(10)
            };
        }

        private static EndpointAddress CreateEndpoint(string url)
        {
            return new EndpointAddress(url);
        }

        public IEzeTradingServiceSync GetChannel()
        {
            return Channel;
        }
    }
}
