﻿using System.Collections.Generic;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IFactProvider : IDataProvider 
    {
        HashSet<string> GetList(string name);
    }
}
