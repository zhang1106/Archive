﻿using System.Collections.Generic;
using System.Threading;

namespace Bam.EventQ.Journal
{
    public interface IJournalSeed
    {
        IEnumerable<byte[]> Retrieve(CancellationToken cancellationToken);
        int Marker { get; }
    }
}
