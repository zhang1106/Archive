﻿using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Recovery
{
    public class RecoveryMessagePublisher<TItem> : IQueueItemHandler<PipelineQueueItem<TItem>>
    {
        private readonly IMessagePublisher _publisher;

        public RecoveryMessagePublisher(IMessagePublisher publisher)
        {
            _publisher = publisher;
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            if (item.IsValid)
            {
                _publisher.Publish(item.Topic, item.Buffer.Array, item.Buffer.Offset, item.Length);
            }
        }
    }
}
