﻿namespace Bam.EventQ.Diagnostics
{
    public interface ITelemetry
    {
        void Record<T>(string key, T value);
    }
}
