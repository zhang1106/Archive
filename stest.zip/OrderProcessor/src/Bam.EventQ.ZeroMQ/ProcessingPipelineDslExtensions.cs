﻿using System;
using Bam.EventQ.Pipeline.Dsl;
using Bam.EventQ.ZeroMQ;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pipeline
{
    public static class ProcessingPipelineDslExtensions
    {
        public static ProcessingPipelineStepDsl<TItem> SubscribeWithZeroMq<TItem>(
            this ProcessingPipelineStepDsl<TItem> dsl, Func<int, string> sourceToEndpointFunc, int bufferSize)
        {
            return dsl.SetSubscriptionQueueItemProducerFactory(
                new ZeroMqQueueItemProducerFactory<TItem>(sourceToEndpointFunc, bufferSize));
        }

        public static ProcessingPipelineStepDsl<TItem> PublishWithZeroMq<TItem>(
            this ProcessingPipelineStepDsl<TItem> dsl)
        {
            dsl.SetMessagePublisherFactory(new ZeroMqMessagePublisherFactory());
            return dsl;
        }
    }
}
