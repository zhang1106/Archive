﻿using System;
using Bam.Oms.Data;

namespace Bam.Oms.Persistence.Positions
{
    public class EodPosition : IPersistentItem
    {
        public string BamSymbol { get; set; }
        public long Quantity { get; set; }
        public string Portfolio { get; set; }
        public string Fund { get; set; }
        public string Custodian { get; set; }
        public DateTime TradeDate { get; set; }
        public DateTime SysDate { get; set; }
        string IPersistentItem.Key => $"{BamSymbol}-{Portfolio}-{Fund}-{Custodian}";
    }
}
