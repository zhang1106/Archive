﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Compliance.Results;
using Newtonsoft.Json;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.Rules
{
    [JsonObject(MemberSerialization.OptIn)]
    public class OwnerShip : FirmRuleBase
    {
        [JsonProperty]
        public string CheckBy { get; set; }

        [JsonProperty]
        public string Entity { get; set; }

        [JsonProperty]
        public bool IncludeAdr { get; set; }

        [JsonProperty]
        public SideType OwnerShipType { get; set; }

        [JsonProperty]
        public SortedList<decimal, ThreshholdWarning> Threshholds { get; set; }

        public Tuple<string, decimal?> GetOwnership(ICompliancePosition pos)
        {
            var mapOwnership = GetMappedOwnership();
            var ptype = GetPositionType(pos);
            var symbol = pos.Security.IsAdr() ? pos.Security.AdrCode : pos.Security.BamSymbol;

            return CheckBy=="ISIN" ? pos.PositionProvider.GetEntityWideQuantityByIsin(symbol, ptype, Entity, mapOwnership)
                : IncludeAdr? pos.PositionProvider.GetFirmWideQuantityWithAdr(symbol, ptype, mapOwnership) : pos.PositionProvider.GetFirmWideQuantity(symbol, ptype, mapOwnership);
        }

        public PositionType GetPositionType(ICompliancePosition pos)
        {
            if (pos.PositionType == PositionType.Sod && IncludeConstituent)
            {
                return PositionType.SodDecomposed;
            }
            if (pos.PositionType == PositionType.Sod && !IncludeConstituent)
            {
                return PositionType.Sod;
            }
            if (pos.PositionType == PositionType.Intraday && IncludeConstituent)
            {
                return PositionType.IntradayDecomposed;
            }
            if (pos.PositionType == PositionType.Intraday && !IncludeConstituent)
            {
                return PositionType.Intraday;
            }
            if (pos.PositionType == PositionType.Eod && IncludeConstituent)
            {
                return PositionType.EodDecomposed;
            }
            if (pos.PositionType == PositionType.Eod && !IncludeConstituent)
            {
                return PositionType.Eod;
            }
            
            throw(new Exception($"Unrecognized PositionType {pos.BamSymbol} - {pos.PositionType}"));
        }
        
        public decimal? GetSharesOutstanding(ICompliancePosition pos)
        {
            if (pos.Security.ActiveInd)
            {
                //need change to rule check
                return pos.MarketDataProvider.GetCustomizedShareOutstanding(pos.UnderlyingSymbol);
            }

            var security = pos.SecurityProvider.SecuritiesByIsin[pos.Security.Isin]
                .FirstOrDefault(s => s.ActiveInd);

            return security==null? null : pos.MarketDataProvider.GetCustomizedShareOutstanding(security.UnderlyingSymbol);
        }

        public SideType GetMappedOwnership()
        {
            if (OwnerShipType == SideType.NetLong || OwnerShipType == SideType.NetShort) return SideType.Net;
            if(OwnerShipType==SideType.Long) return SideType.Long;
            if (OwnerShipType == SideType.Short) return SideType.Short;
            if (OwnerShipType == SideType.Unknown) return SideType.Long;
            throw (new Exception($"Not recognized ownershiptype in rule - {Name} - {OwnerShipType}"));
        }

        public SideType GetOwnership()
        {
            return OwnerShipType == SideType.Unknown ? SideType.Long : OwnerShipType;
        }

        public virtual string GetEntity()
        {
            return string.IsNullOrEmpty(Entity) ? "FIRM" : Entity;
        }

        public virtual string GetIdentityType()
        {
           return string.IsNullOrEmpty(CheckBy) ? "SYMBOL" : "ISIN";
        }

        protected bool IsActiveSeccurity(ICompliancePosition input)
        {
            if (GetIdentityType() == "SYMBOL")
            {
                return input.Security.ActiveInd;
            }

            var securites = input.SecurityProvider.SecuritiesByIsin[input.Security.Isin];

            return securites.Any(s => s.ActiveInd);
        }

        public OwnerShip()
        {
            Threshholds = new SortedList<decimal, ThreshholdWarning>(new DescendingComparer());
        }
        public IRuleResult CheckViolation(ICompliancePosition input, bool isPreCheck, OwnershipFilingResult result)
        {
            if (!IsActiveSeccurity(input))
            {
                 return  input.Helper.CreateNoRuleHeadRoomForAll(input.Security.BamSymbol, input.PolicyId);
            }

            var context = string.Empty;
            try
            {
                //headroom only run, assume holding is 0
                var currentHeld = GetOwnership(input);
                //positions for the calc
                context = currentHeld.Item1;
                var sharesOutstanding =  GetSharesOutstanding(input);

                var ratio = currentHeld.Item2 / sharesOutstanding;
                //set result
                result.PositionQty = currentHeld.Item2;
                result.HeadRoom.Holding = (long?)currentHeld.Item2;
                result.Ratio = ratio;
                result.SharesOutstanding = sharesOutstanding;

                //no data available
                if (!ratio.HasValue)
                {
                    result.AlertLevel = ComplianceAlertLevel.NoDataAvaiable;
                    result.Description = $"No {(currentHeld.Item2.HasValue ? "Sharesoutstanding" : "Position")} available";
                    result.HeadRoom.HeadRooms = input.Helper.CreateErrHeadRoomUnit(result, Threshholds.Values);

                    input.Logger.Info(result.Description + "for " + result.Key);
                    //if curruentholding is null or sharesoutstanding is null, headrooms is not populated.
                    return result;
                }
                //get history
                var lastRatio = input.RuleResultProvider.GetRatio(input.PolicyId, this.Id, input.BamSymbol);
                var lastLowLimit = input.RuleResultProvider.GetLowLimit(input.PolicyId, this.Id, input.BamSymbol);

                //use absolute value
                ratio = Math.Abs(ratio.Value);

                //waterfall checking
                foreach (var threshhold in Threshholds.Values)
                {
                    //calc head rooms
                    if (threshhold.LowLimit.HasValue && threshhold.AlertLevel != ComplianceAlertLevel.Reportable)
                    {
                        var headRoom = input.Helper.CreateHeadRoomUnit(this, result, threshhold,  GetOwnership());
                        result.HeadRoom.HeadRooms.Add(headRoom);
                        result.HeadRoom.SharesOutstanding = sharesOutstanding.Value;
                    }
                    
                    //position is opposite side of rule check
                    if (((GetOwnership() == SideType.Long || GetOwnership() == SideType.NetLong) &&
                         result.PositionQty <= 0)
                        ||
                        ((GetOwnership() == SideType.Short || GetOwnership() == SideType.NetShort) &&
                         result.PositionQty >= 0))
                    continue;

                    if (!threshhold.IsInCurentWarningArea(ratio.Value)) continue;

                    result.LowLimit = threshhold.LowLimit;
                    result.AlertLevel = threshhold.AlertLevel ?? ComplianceAlertLevel.NoViolation;


                    var moving = threshhold.GetAlertlevel(ratio, lastRatio, lastLowLimit);
                    switch (moving)
                    {
                        case ComplianceAlertLevel.ExceedWarning:
                            result.Description = $"Going above {threshhold.LowLimit * 100}% Ownership";
                            break;
                        case ComplianceAlertLevel.FallBelowWarning:
                            result.Description = $"Falling below {threshhold.UpLimit * 100}% Ownership ";
                            break;
                        case ComplianceAlertLevel.SubWarning:
                            result.Description =
                                $"Current ratio: {ratio.Value * 100:N2}% , last: {lastRatio.Value * 100:N2}% and its change exceeds: {threshhold.SubsequentChange.Value * 100:N2}%";
                            break;
                        case ComplianceAlertLevel.NoAlertLevelChange:
                            result.Description = $"Going above {threshhold.LowLimit * 100}% Ownership"; 
                            break;
                        default:
                            result.Description = $"Alert Status:{result.AlertLevel}";
                            break;
                    }
                }
                //log to dataflow
                context = $"POS:{input.PositionType} - {context}";
                input.Helper.LogEvent(result.Key, context);

            }
            catch (Exception ex)
            {
                result.AlertLevel = ComplianceAlertLevel.Error;
                result.Description = ex.Message;
                result.HeadRoom.HeadRooms = input.Helper.CreateErrHeadRoomUnit(result, Threshholds.Values);

                input.Logger.Error(ex.Message);
                //log to dataflow
                input.Helper.LogErrorEvent(result.Key, context);
            }
            if (result.AlertLevel == ComplianceAlertLevel.NotApplicable)
            {
                input.Logger.Info("No data available");
                input.Logger.Debug(input.ToString());
            }
            return result;
        }
    }
}
