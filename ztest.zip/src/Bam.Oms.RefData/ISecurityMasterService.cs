﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.RefData
{
    public interface ISecurityMasterService
    {
        string ExtractUnderlying(SecurityType type, string ticker);

        IDictionary<string, bool> IsValidSecurity(IList<string> tickers);

        void LoadSecurityCache(IList<IPosition> positions);

        IUpdateSecurity GetSecurity(string key);
        
        List<IUpdateSecurity> GetSecurities(IList<string> tickers);

        IEnumerable<IContainsSecurity> SetSecurityAttributes(IEnumerable<IContainsSecurity> items);

        ISecurity GetSwapSecurity(string symbol, string broker);

        event Action<IList<IUpdateSecurity>> SecurityUpdated;
    }
}