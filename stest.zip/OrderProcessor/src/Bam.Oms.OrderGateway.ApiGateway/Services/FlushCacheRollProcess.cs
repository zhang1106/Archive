﻿using System;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Solace;
using Bam.Oms.OrderGateway.Infrastructure.Roll;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public class FlushCacheRollProcess : IRollBlotterProcess
    {
        private readonly ISolCache _cache;
        private readonly string[] _topicsToFlush;

        public FlushCacheRollProcess(ISolCache cache, params string[] topicsToFlush)
        {
            _cache = cache;
            _topicsToFlush = topicsToFlush;
        }

        public ILogger Logger { get; set; }

        public void Roll(DateTime rolledAt, BusinessDayChanged msg)
        {
            foreach (string topic in _topicsToFlush)
            {
                try
                {
                    if (!_cache.FlushAsync(topic).GetAwaiter().GetResult())
                    {
                        Logger?.LogError($"Failed to flush topic '{topic}' from SolCache");
                    }
                }
                catch (Exception ex)
                {
                    Logger?.LogError($"Failed to flush topic '{topic}' from SolCache", ex);
                }
            }
        }
    }
}
