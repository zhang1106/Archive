﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Data.Orders;
using Bam.Oms.EndPoints.Orders;
using BAM.Infrastructure.Ioc;
using CsvHelper;
using Bam.Oms.Data.Configuration;
using Bam.Oms.RefData;
using Newtonsoft.Json;

namespace Bam.Oms.EndPoints.File
{
    public abstract class AbstractListener : IOrderSubmission, IDisposable
    {
        private readonly IFileConfiguration _fileConfiguration;
        protected readonly ILogger _logger;
        protected readonly IOrderPrepUtility _orderPrepUtility;
        private readonly IOrderValidator _orderValidator;
        private readonly IAccountService _accountService;
        private readonly FileSystemWatcher _systemWatcher;
        private const string ArchiveDateFormat = "yyyyMMdd";
        private const string ArchiveDateTimeFormat = "yyyyMMdd_HHmmssffff";

        private readonly CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();

        protected AbstractListener(IFileConfiguration fileConfiguration, ILogger logger, IOrderPrepUtility orderPrepUtility, 
            IOrderValidator orderValidator,ILoggingSerializer loggingSerializer, IAccountService accountService)
        {
            if (fileConfiguration == null) throw new ArgumentNullException(nameof(fileConfiguration));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (orderPrepUtility == null) throw new ArgumentNullException(nameof(orderPrepUtility));
            if (orderValidator == null) throw new ArgumentNullException(nameof(orderValidator));
            if (loggingSerializer == null) throw new ArgumentNullException(nameof(loggingSerializer));
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));

            _fileConfiguration = fileConfiguration;
            _logger = logger;
            _orderPrepUtility = orderPrepUtility;
            _orderValidator = orderValidator;
            _accountService = accountService;
            _systemWatcher = new FileSystemWatcher(_fileConfiguration.Path);
            _systemWatcher.Error += _systemWatcher_Error;
            _systemWatcher.Created += _systemWatcher_Created;
            _systemWatcher.Filter = "*.csv";
        }

        public event Action<IOrder> NewReplaceOrdersReady;
        public event Action<Tuple<string, string>> NewOrderToRouteReady;
        public event Action<Tuple<IList<string>, string>> NewOrdersToRouteReady;
        public event Action<IList<string>> NewCancelOrdersReady;
        public event Action<IList<string>> NewDeleteOrdersReady;
        public event Action<IList<string>> LocateRequestReceived;

        public void AcceptOrders()
        {
            foreach (string fullFilePath in Directory.GetFiles(_fileConfiguration.Path, "*.csv"))
            {
                Task.Run(() => ProcessFile(fullFilePath, Path.GetFileName(fullFilePath)));
            }
            _systemWatcher.EnableRaisingEvents = true;
        }

        public event Action<IList<IOrder>, string, bool> NewOrdersReady;


        private void _systemWatcher_Error(object sender, ErrorEventArgs errorEventArgs)
        {
            _logger.Error("Exception in file watcher", errorEventArgs.GetException());
        }

        private void _systemWatcher_Created(object sender, FileSystemEventArgs e)
        {
            try
            {
                ProcessFile(e.FullPath, e.Name);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error processing file {e.FullPath}.", ex);
            }            
        }

        private void ProcessFile(string fullFilePath, string fileName)
        {
            try
            {
                //standard format for orders
                ImportAndNotifyOfOrders(fullFilePath, fileName);

                var newFileLocation = Path.Combine(CreateSubFolder(_fileConfiguration.Path, "history"),
                    CreateArchiveName(fileName));

                _logger.Info($"Moving file {fullFilePath} to {newFileLocation}.");

                try
                {
                    System.IO.File.Move(fullFilePath, newFileLocation);
                }
                catch (Exception ex)
                {
                    _logger.Error($"Unable to move file {fullFilePath} to {newFileLocation}", ex);
                }

                _logger.Info($"Order file {fullFilePath} processed.");
            }
            catch (Exception ex)
            {
                _logger.Info($"Error while procsssing Order file {fullFilePath}.", ex);
                var errorFileLocation = Path.Combine(CreateSubFolder(_fileConfiguration.Path, "error"),
                    CreateArchiveName(fileName));
                System.IO.File.Move(fullFilePath, errorFileLocation);
            }

        }

        protected Task ImportAndNotifyOfOrders(string path, string name)
        {
            try
            {
                var orderList = ParseFile(path);
                var access = System.IO.File.GetAccessControl(path)?.GetOwner(typeof(System.Security.Principal.NTAccount))?.ToString().Replace("FOUNTAINHEAD\\", "");

                _logger.Info($"Order file dropped by user {access}");

                if (_orderValidator.IsValidOrder(orderList))
                {
                    // security details have to be set before the custodian is assigned
                    _orderPrepUtility.SetCreatedUser(orderList, access);
                    _orderPrepUtility.SetSecurityInformation(orderList);
                    _orderPrepUtility.SetCustodian(orderList);
                    _orderPrepUtility.SetTradeDate(orderList);
                    _orderPrepUtility.AssignOrderIds(orderList);
                    orderList = _accountService.SetAccountAttributes(orderList).Cast<IOrder>().ToList();
                    _orderPrepUtility.SetTrader(orderList, access);
                    orderList = _orderPrepUtility.ScaleOrders(orderList).ToList();
                    _orderPrepUtility.SetOrderStatus(orderList);

                    WriteOutOrderReceipt(orderList, name);

                    _logger.Info($"Order file {path} parsed {orderList.Count} order(s)");

                    if (NewOrdersReady != null && orderList.Count > 0)
                    {
                        return Task.Run(() =>
                        {
                            string batchId = null;
                            try
                            {
                                batchId = PopulateBatchId(orderList);
                                NewOrdersReady(orderList, batchId, true);
                            }
                            catch (Exception ex)
                            {
                                _logger.Error($"Unable process order list with batch {batchId}. {ex.Message} {ex.StackTrace}");
                            }
                        });
                    }
                }
                else
                {
                    _logger.Error($"Order list for {orderList.Count} orders failed validation");
                }
            }
            catch(Exception ex)
            {
                _logger.Error($"Failure to parse the file {path}.  {ex.Message} {ex.StackTrace}");
            }

            return Task.FromResult(false);
        }

        protected virtual string PopulateBatchId(List<IOrder> orderList)
        {
            string batchId;
            var firstOrder = orderList[0];
            batchId = _orderPrepUtility.CreateBatchId(firstOrder.Portfolio.PMCode, DateTime.Now);
            orderList.ForEach(o => o.BatchId = batchId);
            return batchId;
        }

        protected string CreateReceiptPathWithFileName(string path)
        {
            var parsed = path.Split('.');
            var stringbuilder = new StringBuilder();

            for (var i = 0; i < parsed.Length; i++)
            {
                if (i != 0)
                    stringbuilder.Append(".");

                if (i == parsed.Length - 1)
                    stringbuilder.Append("receipt");
                else
                    stringbuilder.Append(parsed[i]);
            }
            return stringbuilder.ToString();
        }

        protected void WriteOutOrderReceipt(IList<IOrder> orders, string fileName)
        {
            var newPath = Path.Combine(CreateSubFolder(_fileConfiguration.Path, "receipt"), CreateReceiptPathWithFileName(fileName));

            try
            {
                using (var stream = new StreamWriter(newPath))
                using (var writer = new CsvWriter(stream))
                {
                    writer.WriteHeader<IOrder>();

                    foreach (var order in orders)
                    {
                        writer.WriteRecord(order);
                    }
                }
            }
            catch (Exception ex)
            {
                //todo:
            }
        }

        protected abstract List<IOrder> ParseFile(string path);

        protected FileStream OpenFileStream(string path)
        {
            FileStream stream = null;
            int count = 0;
            int retries = 10;

            do
            {
                try
                {
                    stream = System.IO.File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                }
                catch (Exception)
                {
                    _logger.Info($"Attempting to open trade file before the copy is complete.  Retry count {count++}");
                    Thread.Sleep(1000);
                }
            } while (stream == null && count < retries);

            if (count >= retries)
                throw new Exception($"Unable to open file {path} after {count} attempts");

            return stream;
        }

        protected string CreateSubFolder(string path, string folderName)
        {
            var historyPath = Path.Combine(path, folderName);

            if (!Directory.Exists(historyPath))
                Directory.CreateDirectory(historyPath);

            var historyTodayPath = Path.Combine(historyPath, DateTime.Today.ToString(ArchiveDateFormat));

            if (!Directory.Exists(historyTodayPath))
                Directory.CreateDirectory(historyTodayPath);


            return historyTodayPath;
        }

        protected string CreateArchiveName(string fileName)
        {
            var split = fileName.Split('.');
            return split[0] + "_" + DateTime.Now.ToString(ArchiveDateTimeFormat) + "." + split[1];
        }


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _cancellationTokenSource.Cancel();
                    _systemWatcher?.Dispose();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~Listener() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}