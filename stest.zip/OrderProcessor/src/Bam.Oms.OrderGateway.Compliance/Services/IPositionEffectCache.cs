﻿using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.PositionTracker;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public interface IPositionEffectCache
    {
        ComplianceEffects GetComplianceEffects(EffectKey orderKey);
        void SetComplianceEffects(EffectKey orderKey, ComplianceEffects effects);

        ActualEffects GetActualEffects(EffectKey orderKey, PositionAllocationKey key);
        void SetActualEffects(EffectKey orderKey, PositionAllocationKey key, ActualEffects effects);

        TheoreticalEffects GetTheoreticalEffects(EffectKey orderKey, PositionAllocationKey key);
        void SetTheoreticalEffects(EffectKey orderKey, PositionAllocationKey key, TheoreticalEffects effects);
    }
}
