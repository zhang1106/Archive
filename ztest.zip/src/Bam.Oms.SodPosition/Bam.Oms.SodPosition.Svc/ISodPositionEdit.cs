﻿using System;
using System.ServiceModel;
using System.Collections.Generic;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.SodPosition.Svc
{
    [ServiceContract]
    public interface ISodPositionEdit : IDisposable
    {
        [OperationContract]
        string Whatsup();


        IList<IPosition> GetPositions(DateTime? asofdate, string stream, string fundCode, string custodianAccountCode, string strategyCode, string securityType, string bamSymbol);
      
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="asofdate"></param>
        /// <param name="stream"></param>
        /// <param name="fundCode"></param>
        /// <param name="custodianAccountCode"></param>
        /// <param name="strategyCode"></param>
        /// <param name="securityType"></param>
        /// <param name="bamSymbol"></param>
        /// <returns></returns>
        [OperationContract]
        IList<Position> GetSodPositions(DateTime? asofdate, string stream, string fundCode, string custodianAccountCode, string strategyCode, string securityType, string bamSymbol);


        /// <summary>
        /// get latest updated positions which have not been published
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [OperationContract]
        IList<Position> GetLatestUpdatedPositions(string stream);

        /// <summary>
        /// get list of audit trails for a poistion
        /// </summary>
        /// <param name="positionId"></param>
        /// <param name="entrydate"></param>
        /// <returns></returns>
        [OperationContract]
        IList<PositionAudit> GetAudits(int positionId, DateTime entrydate);

        /// <summary>
        /// update a position
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="position"></param>
        /// <returns></returns>
        [OperationContract]
        Position UpdatePosition(Position position);

        /// <summary>
        /// insert a position
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        [OperationContract]
        Position InsertPosition(Position position);

        /// <summary>
        /// bulk inert poistions
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        [OperationContract]
        IList<Position> BulkInsertPosition(IList<Position> positions);

        /// <summary>
        /// bulk update positions
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        [OperationContract]
        IList<Position> BulkUpdatePosition(IList<Position> positions);

        /// <summary>
        /// output a list of positions to a csv file
        /// </summary>
        /// <param name="positions"></param>
        /// <returns></returns>
        [OperationContract]
        bool SaveToCSVFile(string completeFileName, IList<Position> positions);

        /// <summary>
        /// broadcast updtes to intested parties through files, events
        /// In the future, the updates will be published to a Queue
        /// </summary>
        /// <param name="positions"></param>
        /// <returns></returns>
        [OperationContract]
        bool PublishUpdatedPositions(string stream);

        [OperationContract]
        IList<SodAction> GetBulkActions();

        [OperationContract]
        IList<Position> GetUndoChanges(int positionId);

        [OperationContract]
        IList<Position> ExecuteUndo(int positionId, IList<Position> undoList);

        [OperationContract]
        IList<string> GetStreams();

        [OperationContract]
        string GetLatestLoadedStream();

        /// <summary>
        /// publish updated positions
        /// </summary>
        event Action<IList<Position>> SodPositionUpdated;

        /// <summary>
        /// publish updated positions
        /// </summary>
        event Action<IList<Position>> SodPositionLoad;

        void Start();

    }
}
