﻿using Bam.Oms.OrderGateway.EzeGateway.EzeApi;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public class SubmissionQueueItem
    {
        private readonly TradeCreateRequest _request;
        private readonly int _index;

        public SubmissionQueueItem(TradeCreateRequest request, int index)
        {
            _request = request;
            _index = index;
        }

        public TradeCreateRequest Request => _request;
        public Trade Trade => _request.trades[_index];
    }
}
