﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Queue;
using Disruptor;
using Disruptor.Dsl;

namespace Bam.EventQ.Disruptor
{
    public class DisruptorQueue<TItem> : IQueue<TItem> where TItem : class
    {
        private readonly Disruptor<TItem> _disruptor;
        private readonly CompositeErrorHandler _errorHandler;
        private readonly Dictionary<IQueueItemHandler<TItem>, QueueItemHandlerAdapter<TItem>> _wrappers
            = new Dictionary<IQueueItemHandler<TItem>, QueueItemHandlerAdapter<TItem>>();

        public DisruptorQueue(IQueueItemFactory<TItem> itemFactory, int ringSize)
        {
            _errorHandler = new CompositeErrorHandler();
            _disruptor = new Disruptor<TItem>(
                itemFactory.Create,
                new MultiThreadedClaimStrategy(ringSize, ringSize),
                new BlockingWaitStrategy(),
                TaskScheduler.Default);

            // this has to be hooked up before any event handler gets assigned,
            // otherwise the error handler is ignored
            _disruptor.HandleExceptionsWith(new ErrorHandlerAdapter(_errorHandler));
        }

        public ILogger Logger { get; set; }

        public QueueSlotBatch AllocateBatch(int size)
        {
            var bd = _disruptor.RingBuffer.NewBatchDescriptor(size);
            bd = _disruptor.RingBuffer.Next(bd);
            return new QueueSlotBatch(bd.Start, bd.End);
        }

        public void PublishBatch(QueueSlotBatch batch)
        {
            var bd = _disruptor.RingBuffer.NewBatchDescriptor(unchecked ((int) (batch.End - batch.Start + 1)));
            bd.End = batch.End;
            _disruptor.RingBuffer.Publish(bd);
        }

        public bool IsAvailable(QueueSlotBatch range)
        {
            long max = _disruptor.RingBuffer.Cursor;
            long min = _disruptor.RingBuffer.Cursor - _disruptor.RingBuffer.BufferSize;
            return range.End <= max && range.Start >= min;
        }

        public bool HasBacklog()
        {
            var mi = _disruptor.GetType().GetMethod("HasBacklog", BindingFlags.Instance | BindingFlags.NonPublic);
            return Convert.ToBoolean(mi.Invoke(_disruptor, null));
        }

        public long Capacity => _disruptor.RingBuffer.BufferSize;
        public long Count => Capacity - _disruptor.RingBuffer.RemainingCapacity();
        public long MaxSequence => _disruptor.RingBuffer.Cursor;

        public TItem this[long sequence] => _disruptor.RingBuffer[sequence];

        public void AddErrorHandler(IQueueErrorHandler handler)
        {
            _errorHandler.Add(handler);
        }

        public void AddSubscriptionChain(params IQueueItemHandler<TItem>[] handlers)
        {
            EventHandlerGroup<TItem> handlerGroup = null;
            foreach (var handler in handlers)
            {
                _wrappers[handler] = new QueueItemHandlerAdapter<TItem>(handler);
                handlerGroup = handlerGroup == null 
                    ? _disruptor.HandleEventsWith(_wrappers[handler]) 
                    : handlerGroup.Then(_wrappers[handler]);
            }
        }

        public bool ReplayMessages(
            Predicate<TItem> startPredicate, 
            Predicate<TItem> filterPredicate, 
            IQueueItemHandler<TItem> replayHandler)
        {
            long end = _disruptor.RingBuffer.Cursor;
            if (end == -1)
                return true;

            long start = -1;
            bool matchFilter = false;
            for (long i = end; i >= Math.Max(end - Capacity, 0); i--)
            {
                if (startPredicate(this[i]))
                {
                    start = i;
                    break;
                }

                if (filterPredicate(this[i]))
                {
                    matchFilter = true;
                }
            }

            // there is nothing on the ring matching the criteria (yet),
            // so nothing needs to be replayed
            if (start == -1 && !matchFilter)
            {
                Logger?.LogInformation(
                    "No element matching start predicate found on ring buffer, there is nothing to replay");
                return true;
            }

            if (start == -1)
            {
                Logger?.LogInformation(
                    "No element matching start predicate found on ring buffer, but found elements matching filter criteria");
                return false;
            }

            Logger?.LogInformation($"Replaying matching ring buffer elements between {start}-{end}");
            for (long i = start; i <= end; i++)
            {
                if (filterPredicate(this[i]))
                {
                    replayHandler.Handle(this[i], i, i == end);
                }
            }
            Logger?.LogDebug($"Replayed matching ring buffer elements between {start}-{end}");

            return true;
        }

        public void Start()
        {
            _disruptor.Start();
        }

        public void Stop()
        {
            _disruptor.Shutdown();
            foreach (var handler in _wrappers.Keys)
            {
                (handler as IDisposable)?.Dispose();
            }
        }
    }
}
