﻿using System;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Positions;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class ComplianceKernelTest
    {
        IRule<CompliancePosition> _sampleRule;
        IPolicy<CompliancePosition> _samplePolicy;
       
        [SetUp]
        public void Setup()
        {
            _sampleRule = new Rule<CompliancePosition>() { Id = 0, Name = "Test", Type=typeof(Rule<CompliancePosition>).FullName,  Description = "Test", IsActive = true };
            _samplePolicy = new Policy<CompliancePosition>() { Id = 0, Name = "Test" };
        }

        [Test]
        public void TestPolicyAddRule()
        {
            //arr
            IPolicy <CompliancePosition> policy = _samplePolicy;
            IRule<CompliancePosition> rule = _sampleRule;
            
            //act
            policy.AddRule(rule);

            //ass
            Assert.IsTrue(policy.Rules.Count == 1);
            Assert.IsTrue(policy.Rules[0].Id == rule.Id);
        }

        [Test]
        [TestCase(true, Data.Enumerators.ComplianceAlertLevel.NoViolation)]
        [TestCase(false, Data.Enumerators.ComplianceAlertLevel.NoViolation)]
        public void TestRuleCheckViolation(bool isRuleActive, Data.Enumerators.ComplianceAlertLevel alertLevel)
        {
            //arrange
            IRule<IPosition> rule1 = new Rule<IPosition>() { Id = 0, Name = "Test", Description = "Test", IsActive = isRuleActive };
            
            //act
            IRuleResult result = rule1.CheckViolation(null, false);

            //assert
            Assert.IsTrue(result.AlertLevel == alertLevel);
        }

        /// <summary>
        /// if there is a need implementing the addFilter method, the test need changed.
        /// </summary>
        [Test]
        public void TestPolicyAddFilter()
        {
            IPolicy<CompliancePosition> policy = _samplePolicy;
            bool notImplemented = false;

            //act
            try
            {
                policy.AddFilter(null);
            }
            catch (Exception ex)
            {
                notImplemented = ex is NotImplementedException;
            }

            //ass
            Assert.IsTrue(notImplemented);
        }

        [Test]
        public void TestFactGetList()
        {
            Fact fact = new Fact() {Name = "T1", Value = "V1,V2"};
            Fact fact2 = new Fact() { Name = "T2"};

            var list = fact.GetList();
            var list2 = fact2.GetList();

            Assert.IsTrue(list.Count==2);
            Assert.IsTrue(list2 == null);
        }

    }
}
