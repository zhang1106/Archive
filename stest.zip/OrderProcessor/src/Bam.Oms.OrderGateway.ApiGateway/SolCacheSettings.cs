﻿using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class SolCacheSettings : AppSettingsBase
    {
        public SolCacheSettings() : base("ApiGateway.Solace.Cache.")
        {

        }

        public string SempUrl
        {
            get { return GetValue(() => SempUrl); }
        }

        public string SempUsername
        {
            get { return GetValue(() => SempUsername); }
        }

        public string SempPassword
        {
            get { return GetValue(() => SempPassword); }
        }

        public string CacheName
        {
            get { return GetValue(() => CacheName); }
        }

        public string Cluster
        {
            get { return GetValue(() => Cluster); }
        }

        public string Instance
        {
            get { return GetValue(() => Instance); }
        }
    }
}
