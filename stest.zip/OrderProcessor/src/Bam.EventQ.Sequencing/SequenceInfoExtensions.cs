﻿using System.Diagnostics;
using Bam.EventQ.Recovery;

namespace Bam.EventQ.Sequencing
{
    public static class SequenceInfoExtensions
    {
        public static void CopyTo(this SequenceInfo seqInfo, byte[] buffer, int index)
        {
            Debug.Assert(seqInfo.Topic <= 255 && seqInfo.Topic >= 0);
            Debug.Assert(seqInfo.SourceId <= 255 && seqInfo.SourceId >= 0);

            buffer[index++] = (byte)((seqInfo.SourceId >> 0) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Topic >> 0) & 0xFF);

            buffer[index++] = (byte)((seqInfo.Timestamp >> 24) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Timestamp >> 16) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Timestamp >> 8) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Timestamp >> 0) & 0xFF);

            buffer[index++] = (byte)((seqInfo.Sequence >> 56) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Sequence >> 48) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Sequence >> 40) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Sequence >> 32) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Sequence >> 24) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Sequence >> 16) & 0xFF);
            buffer[index++] = (byte)((seqInfo.Sequence >> 8) & 0xFF);
            buffer[index] = (byte)((seqInfo.Sequence >> 0) & 0xFF);
        }

        public static SequenceInfo ToMessageHeader(this byte[] buffer, int index)
        {
            int sourceId = buffer[index++] << 0;
            int topic = buffer[index++] << 0;

            int timestamp =
                buffer[index++] << 24 |
                buffer[index++] << 16 |
                buffer[index++] << 8 |
                buffer[index++] << 0;

            long sequence =
                (long)buffer[index++] << 56 |
                (long)buffer[index++] << 48 |
                (long)buffer[index++] << 40 |
                (long)buffer[index++] << 32 |
                (long)buffer[index++] << 24 |
                (long)buffer[index++] << 16 |
                (long)buffer[index++] << 8 |
                (long)buffer[index] << 0;

            return new SequenceInfo(sourceId, topic, sequence, timestamp);
        }
    }
}
