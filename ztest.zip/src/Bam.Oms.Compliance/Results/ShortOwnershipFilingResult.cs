﻿using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Results
{
    public class ShortOwnershipFilingResult : RuleResult 
    {
        public string Currency { get; set; }
        public override string ToString()
        {
            return
                $"Policly:{PolicyId},RuleName:{RuleName},Currency:{Currency}";
        }
    }
}
