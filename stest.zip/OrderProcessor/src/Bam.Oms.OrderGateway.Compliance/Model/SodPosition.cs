﻿using System;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public class SodPosition : ModelBase<IMessage>
    {
        public SodPosition(SodPositionKey key)
        {
            Key = key;
            PositionKey = new PositionKey(key.Portfolio, key.BamSymbol);
        }

        public SodPositionKey Key { get; }
        public PositionKey PositionKey { get; }
        public long ActualQuantity { get; set; }
        public DateTime AsOf { get; set; }
    }
}
