﻿/****** Script for SelectTopNRows command from SSMS  ******/
/* clear */
--truncate table [cp].[PolicyRule]
--delete from [cp].[Policy]
--delete from [cp].[Rule]

declare @ruleId int
declare @policyId int


/******  policy  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Policy] where Name = 'Firm Position Limit Policy'))
Begin
  Insert Into [OrderGateway].[cp].[Policy]
  Values ('Firm Position Limit Policy', 'Bam.Oms.Compliance.Policies.FirmPositionLimitPolicy', 'Firm level Ownership Limit', 1, '1-1-2015', '1-1-2020',  null, getdate(), 'dev', getdate(), 'dev')
  select @policyId=@@Identity
End
Else
Begin
  Select @policyId = (select Id from [OrderGateway].[cp].[Policy]  where Name = 'Firm Position Limit Policy')
End


/******  3  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Australia: Long Ownership Filing' or Name = 'Australia: Long Ownership Filing - NEW'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Australia: Long Ownership Filing', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Warning"}, "0.05":{"LowLimit":0.05,"UpLimit":null,"SubsequentChange":0.01,"AlertLevel":"Violated"}},"FilterParams":[{"Property":"Country","Value":"AU","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = Id from [OrderGateway].[cp].[Rule] where Name = 'Australia: Long Ownership Filing - NEW' or  Name = 'Australia: Long Ownership Filing'

 Update r
 Set Name = 'Australia: Long Ownership Filing',
 ParamsInJson = '{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Warning"}, "0.05":{"LowLimit":0.05,"UpLimit":null,"SubsequentChange":0.01,"AlertLevel":"Violated"}},"FilterParams":[{"Property":"Country","Value":"AU","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule] r
 where  Id = @ruleId
End

/******  4  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Austria: Long Ownership Filing' or  Name = 'Austria: Long Ownership Filing Requirements - NEW'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Austria: Long Ownership Filing', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required wheownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25} ,"0.25":{"LowLimit":0.25,"UpLimit":0.26},"0.26":{"LowLimit":0.26,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.35},"0.35":{"LowLimit":0.35,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.45},"0.45":{"LowLimit":0.45,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.75},"0.75":{"LowLimit":0.75,"UpLimit":0.90},"0.90":{"LowLimit":0.90}},"FilterParams":[{"Property":"Country","Value":"AT","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = Id from [OrderGateway].[cp].[Rule] where Name = 'Austria: Long Ownership Filing' or  Name = 'Austria: Long Ownership Filing Requirements - NEW'

 Update r
 Set Name = 'Austria: Long Ownership Filing',
 ParamsInJson = '{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25} ,"0.25":{"LowLimit":0.25,"UpLimit":0.26},"0.26":{"LowLimit":0.26,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.35},"0.35":{"LowLimit":0.35,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.45},"0.45":{"LowLimit":0.45,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.75},"0.75":{"LowLimit":0.75,"UpLimit":0.90},"0.90":{"LowLimit":0.90}},"FilterParams":[{"Property":"Country","Value":"AT","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule] r
 where  Id = @ruleId
End

/******  5  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Belgium: Long Ownership Filing Requirements - NEW' or Name = 'Belgium: Long Ownership Filing' ))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Belgium: Long Ownership Filing Requirements', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.1},"0.10":{"LowLimit":0.1,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.2},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.6666":{"LowLimit":0.6666,"UpLimit":null}},"FilterParams":[{"Property":"Country","Value":"BE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule] where Name = 'Belgium: Long Ownership Filing Requirements - NEW'  or Name = 'Belgium: Long Ownership Filing'

 Update r 
 Set 
 Name = 'Belgium: Long Ownership Filing',
 ParamsInJson = '{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.1},"0.10":{"LowLimit":0.1,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.2},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.6666":{"LowLimit":0.6666,"UpLimit":null}},"FilterParams":[{"Property":"Country","Value":"BE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule] r
 Where  Id = @ruleId
End

/******  6  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Brazil: Long Ownership Filing Requirements - NEW' or Name = 'Brazil: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Brazil: Long Ownership Filing', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05, "SubsequentChange":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"BR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule] where Name = 'Brazil: Long Ownership Filing Requirements - NEW' or Name = 'Brazil: Long Ownership Filing'

 Update r 
 Set 
 Name = 'Brazil: Long Ownership Filing',
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"BR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule] r
 Where  Id = @ruleId
End

/******  7  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Bulgaria: Long Ownership Filing Requirements - NEW' or Name = 'Bulgaria: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Bulgaria: Long Ownership Filing', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05, "SubsequentChange":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"BG","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule] where Name = 'Bulgaria: Long Ownership Filing Requirements - NEW' or Name = 'Bulgaria: Long Ownership Filing'

 Update r 
 Set 
 Name = 'Bulgaria: Long Ownership Filing',
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"BG","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule] r
 Where  Id = @ruleId
End

/******  8  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'BWP Ownership Limit Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('BWP Ownership Limit Filing', 'Bam.Oms.Compliance.Rules.LongOwnershipLimit', 'BWP Ownership Limit - 22 MM shares. please contact Matt S', 1, '1-1-2015', '1-1-2020', 
         '{"Threshhold":22000000.0,"BamSymbol":"BWP"}', getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End

End

/******  9  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Canada: Long Ownership Filing - NEW' or Name = 'Canada: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Canada: Long Ownership Filing - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.10, "SubsequentChange":0.02}, "0.10":{"LowLimit":0.10, "SubsequentChange":0.02}},"FilterParams":[{"Property":"Country","Value":"CA","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule] where Name = 'Canada: Long Ownership Filing - NEW' or Name = 'Canada: Long Ownership Filing'

 Update r 
 Set 
 Name = 'Canada: Long Ownership Filing',
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.09}, "0.09":{"LowLimit":0.09, "UpLimit":0.10}, "0.10":{"LowLimit":0.10, "SubsequentChange":0.025}},"FilterParams":[{"Property":"Country","Value":"CA","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule] r
 Where  Id = @ruleId
End

/******  10  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Canada: Long Ownership Filing - Takeover' or Name = 'Canada: Takeover Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Canada: Long Ownership Filing - Takeover', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.10, "SubsequentChange":0.02}, "0.10":{"LowLimit":0.10, "SubsequentChange":0.02}},"FilterParams":[{"Property":"Country","Value":"CA","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"CATakeoverOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule] where Name = 'Canada: Long Ownership Filing - Takeover' or Name = 'Canada: Takeover Filing'

 Update r 
 Set 
 Name = 'Canada: Takeover Filing',
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04}, "0.04":{"LowLimit":0.04, "UpLimit":0.05}, "0.50":{"LowLimit":0.50}},"FilterParams":[{"Property":"Country","Value":"CA","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeoverCAOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule] r
 Where  Id = @ruleId
End


/******  11  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Cayman Islands: Long Ownership Filing Requirements - NEW' or  Name = 'Cayman Islands: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Cayman Islands: Long Ownership Filing', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.15,"SubsequentChange":0.01}, "0.15":{"LowLimit":0.15, "SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"KY","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule] where Name = 'Cayman Islands: Long Ownership Filing Requirements - NEW' or  Name = 'Cayman Islands: Long Ownership Filing'

 Update r 
 Set 
 Name = 'Cayman Islands: Long Ownership Filing',
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.14}, "0.14":{"LowLimit":0.14, "UpLimit":0.15}, "0.15":{"LowLimit":0.15, "SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"KY","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule] r
 Where  Id = @ruleId

End

/******  12  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'CCL Ownership Limit'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('CCL Ownership Limit', 'Bam.Oms.Compliance.Rules.NetOwnershipLimit', 'CCL Ownership Limit. Check with Legal/Compliance before crossing 1.7%', 1, '1-1-2015', '1-1-2020', '{"Threshhold":10075000.0,"BamSymbol":"CCL"}', getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End

/******  13  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'CCXI - ownership alert' OR Name = 'CCXI Ownership Limit'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('CCXI - ownership alert', 'Bam.Oms.Compliance.Rules.NetOwnershipLimit', 'CCL Ownership Limit. Check with Legal/Compliance before crossing 1.7%', 1, '1-1-2015', '1-1-2020'
    , '{"Threshhold":2145355.0,"BamSymbol":"CCXL"}', getdate(), 'dev', getdate(), 'dev')

  Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule] where  Name = 'CCXI - ownership alert' OR Name = 'CCXI Ownership Limit'
Update r
Set
	Name = 'CCXI Ownership Limit'
	From [OrderGateway].[cp].[Rule] r
	Where r.Id = @ruleId
End

/******  14  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Denmark: Long Ownership Filing Requirements - NEW' or Name = 'Denmark: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Denmark: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05, "SubsequentChange":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"DK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule] where  Name = 'Denmark: Long Ownership Filing Requirements - NEW' or Name = 'Denmark: Long Ownership Filing'
Update r
Set
	Name = 'Denmark: Long Ownership Filing',
	ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04, "UpLimit":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"DK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
	From [OrderGateway].[cp].[Rule] r
	Where r.Id = @ruleId
End

/******  15  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'European Union: Short Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('European Union: Short Ownership Filing', 'Bam.Oms.Compliance.Rules.ShortOwnershipFiling', 'Ristricted', 1, '1-1-2015', '1-1-2020', 
  '{"FilterParams":[{"Property":"Country","Value":"EUShortCountries","Type":null,"Operator":{"OperatorType":"InTheList"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  , getdate(), 'dev', getdate(), 'dev')

  Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
  --declare @ruleId int
  Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'European Union: Short Ownership Filing')
  Update r
  Set 
  IsActive = 0,
  ParamsInJson =  '{"FilterParams":[{"Property":"Country","Value":"EUShortCountries","Type":null,"Operator":{"OperatorType":"InTheList"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  16  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Finland: Long Ownership Filing Requirements - NEW' or Name = 'Finland: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Finland: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"LowLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.66},"0.66":{"LowLimit":0.66}},"FilterParams":[{"Property":"Country","Value":"FI","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
	Select @ruleId = Id from [OrderGateway].[cp].[Rule] where  Name = 'Finland: Long Ownership Filing Requirements - NEW' or Name = 'Finland: Long Ownership Filing'
	Update r
	Set
		Name = 'Finland: Long Ownership Filing',
		ParamsInJson = '{"Threshholds":{"0":{"LowLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.66},"0.66":{"LowLimit":0.66}},"FilterParams":[{"Property":"Country","Value":"FI","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
		From [OrderGateway].[cp].[Rule] r
		Where r.Id = @ruleId
End

/******  17  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'France: Long Ownership Filing - Takeover' or Name = 'France:Takeover Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('France: Long Ownership Filing - Takeover', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05, "SubsequentChange":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"FR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"FranceTakeOverSecuritiesList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
    Select @ruleId = Id from [OrderGateway].[cp].[Rule] where  Name = 'France: Long Ownership Filing - Takeover' or Name = 'France:Takeover Filing'
	Update r
	Set
		Name = 'France:Takeover Filing',
		ParamsInJson = '{"Threshholds":{"0":{"LowLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"FR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeOverFROfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
		From [OrderGateway].[cp].[Rule] r
		Where r.Id = @ruleId
End

/******  18  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'France: Long Ownership Filing Requirements - NEW' or Name = 'France: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('France: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.6666":{"LowLimit":0.6666}},"FilterParams":[{"Property":"Country","Value":"FR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = Id from [OrderGateway].[cp].[Rule] where  Name = 'France: Long Ownership Filing Requirements - NEW' or Name = 'France: Long Ownership Filing'
  Update r
  Set 
  Name = 'France: Long Ownership Filing',
  ParamsInJson =  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.6666":{"LowLimit":0.6666,"UpLimit":0.90},"0.90":{"LowLimit":0.90,"UpLimit":0.95},"0.95":{"LowLimit":0.95}},"FilterParams":[{"Property":"Country","Value":"FR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End
/******  19  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Germany: Long Ownership Filing Requirements - NEW' or Name = 'Germany: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Germany: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666}},"FilterParams":[{"Property":"Country","Value":"DE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
  Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Germany: Long Ownership Filing Requirements - NEW' or Name = 'Germany: Long Ownership Filing')
  Update r
  Set 
  Name = 'Germany: Long Ownership Filing',
  IsActive = 0,
  ParamsInJson =  '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.39},"0.30":{"LowLimit":0.30,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.70},"0.70":{"LowLimit":0.70}},"FilterParams":[{"Property":"Country","Value":"DE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  20  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Greece: Long Ownership Filing Requirements - NEW' or Name = 'Greece: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Greece: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666}},"FilterParams":[{"Property":"Country","Value":"GR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
  Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Greece: Long Ownership Filing Requirements - NEW' or Name = 'Greece: Long Ownership Filing')
  Update r
  Set 
  Name = 'Greece: Long Ownership Filing',
  ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666}},"FilterParams":[{"Property":"Country","Value":"GR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  21  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Hong Kong: Long Ownership Filing - NEW' or Name = 'Hong Kong: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Hong Kong: Long Ownership Filing - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05,"SubsequentChange":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
  Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Hong Kong: Long Ownership Filing - NEW'or Name = 'Hong Kong: Long Ownership Filing')
  Update r
  Set 
  Name = 'Hong Kong: Long Ownership Filing',
  ParamsInJson =  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  22-1  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Hong Kong: Long Ownership Filing - Takeover-1' or Name='Hong Kong: Takeover Filing'  ))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Hong Kong: Long Ownership Filing - Takeover-1', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05, "SubsequentChange":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeOverHKOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
  Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Hong Kong: Long Ownership Filing - Takeover-1' or Name='Hong Kong: Takeover Filing')
  Update r
  Set 
  Name = 'Hong Kong: Takeover Filing',
  ParamsInJson =  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeOverHKOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  23-1  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Ireland: Long Ownership Filing - Takeover-1' or Name = 'Ireland: Takeover Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Ireland: Long Ownership Filing - Takeover-1', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.01, "SubsequentChange":0.01},"0.01":{"LowLimit":0.01, "SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"IE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeOverIEOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Ireland: Long Ownership Filing - Takeover-1' or Name = 'Ireland: Takeover Filing')
  Update r
  Set 
  Name = 'Ireland: Takeover Filing',
  ParamsInJson =  '{"Threshholds":{"0":{"UpLimit":0.007},"0.007":{"LowLimit":0.007,"UpLimit":0.01},"0.01":{"LowLimit":0.01}},"FilterParams":[{"Property":"Country","Value":"IE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeOverIEOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  24  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Italy: Long Ownership Filing - Takeover' or Name = 'Italy: Takeover Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Italy: Long Ownership Filing - Takeover', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05, "SubsequentChange":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05}},"FilterParams":[{"Property":"Country","Value":"IT","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"ItalyTakeOverSecuritiesList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Italy: Long Ownership Filing - Takeover' or Name = 'Italy: Takeover Filing')
  Update r
  Set 
  Name = 'Italy: Takeover Filing',
  ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.0125},"0.0125":{"LowLimit":0.0125,"UpLimit":0.02},"0.02":{"LowLimit":0.02,"UpLimit":0.03},"0.03":{"LowLimit":0.03}},"FilterParams":[{"Property":"Country","Value":"IT","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"ItalyTakeOverSecuritiesList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  25  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Italy: Long Ownership Filing Requirements - NEW' or Name = 'Italy: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Italy: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.02},"0.02":{"LowLimit":0.02,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.35},"0.35":{"LowLimit":0.35,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.45},"0.45":{"LowLimit":0.45,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666,"UpLimit":0.75},"0.75":{"LowLimit":0.75,"UpLimit":0.90},"0.90":{"LowLimit":0.90,"UpLimit":0.95},"0.95":{"LowLimit":0.95}},"FilterParams":[{"Property":"Country","Value":"IT","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Italy: Long Ownership Filing Requirements - NEW' or Name = 'Italy: Long Ownership Filing')
  Update r
  Set 
  Name = 'Italy: Long Ownership Filing',
  ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.0125},"0.0125":{"LowLimit":0.0125,"UpLimit":0.02},"0.02":{"LowLimit":0.02,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.35},"0.35":{"LowLimit":0.35,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.45},"0.45":{"LowLimit":0.45,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666,"UpLimit":0.75},"0.75":{"LowLimit":0.75,"UpLimit":0.90},"0.90":{"LowLimit":0.90,"UpLimit":0.95},"0.95":{"LowLimit":0.95}},"FilterParams":[{"Property":"Country","Value":"IT","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  26  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Japan: Long Ownership Filing - NEW' or Name = 'Japan: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Japan: Long Ownership Filing - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10}},"FilterParams":[{"Property":"Country","Value":"JP","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Japan: Long Ownership Filing - NEW' or Name = 'Japan: Long Ownership Filing')
  Update r
  Set 
  Name = 'Japan: Long Ownership Filing',
  ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05, "SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"JP","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  27  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Luxembourg: Long Ownership Filing Requirements - NEW' or Name = 'Luxembourg: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Luxembourg: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.3334},"0.33":{"LowLimit":0.3334,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6667},"0.66":{"LowLimit":0.6667}},"FilterParams":[{"Property":"Country","Value":"LU","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Begin
  Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Luxembourg: Long Ownership Filing Requirements - NEW' or Name = 'Luxembourg: Long Ownership Filing')
  Update r
  Set 
  Name = 'Luxembourg: Long Ownership Filing',
  ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.3334},"0.33":{"LowLimit":0.3334,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6667},"0.66":{"LowLimit":0.6667}},"FilterParams":[{"Property":"Country","Value":"LU","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  29-1  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Max 5% Shares Outstanding-HOK'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Max 5% Shares Outstanding-HOK', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"UpLimit":0.50, "AlertLevel":"Violated"}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
  Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Max 5% Shares Outstanding-HOK')
  Update r
  Set 
   ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.05},"0.05":{"UpLimit":0.05,"SubsequentChange":0.01,"AlertLevel":"Violated"}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  29-2  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Max 5% Shares Outstanding-CPS' or Name = 'Max 4.75% Shares Outstanding-CPS'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Max 5% Shares Outstanding-CPS', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"UpLimit":0.50, "AlertLevel":"Violated"}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
  Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Max 4.75% Shares Outstanding-CPS')
  Update r
  Set 
   Name = 'Max 4.75% Shares Outstanding-CPS',
   ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.0475},"0.0475":{"UpLimit":0.475, "AlertLevel":"Violated"}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/* 30 dup*/
/* 31 not posttrade*/

/******  32  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Netherlands: Long Ownership Filing Requirements - NEW' or Name = 'Netherlands: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Netherlands: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.60},"0.60":{"LowLimit":0.60,"UpLimit":0.75},"0.75":{"LowLimit":0.75,"UpLimit":0.95},"0.95":{"LowLimit":0.95}},"FilterParams":[{"Property":"Country","Value":"NL","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'Netherlands: Long Ownership Filing Requirements - NEW' or Name = 'Netherlands: Long Ownership Filing')
  Update r
  Set 
   Name = 'Netherlands: Long Ownership Filing',
   ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.60},"0.60":{"LowLimit":0.60,"UpLimit":0.75},"0.75":{"LowLimit":0.75,"UpLimit":0.95},"0.95":{"LowLimit":0.95}},"FilterParams":[{"Property":"Country","Value":"NL","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  33  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'New Zealand: Long Ownership Filing Requirements - NEW' or Name = 'New Zealand: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('New Zealand: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05,"SubsequentChange":0.01},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"NZ","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where Name = 'New Zealand: Long Ownership Filing Requirements - NEW' or Name = 'New Zealand: Long Ownership Filing')
  Update r
  Set 
   Name = 'New Zealand: Long Ownership Filing',
   ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"NZ","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  34  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Norway: Long Ownership Filing Requirements - NEW' or Name = 'Norway: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Norway: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666,"UpLimit":0.90},"0.90":{"LowLimit":0.90}},"FilterParams":[{"Property":"Country","Value":"NO","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where  Name = 'Norway: Long Ownership Filing Requirements - NEW' or Name = 'Norway: Long Ownership Filing')
  Update r
  Set 
   Name = 'Norway: Long Ownership Filing',
   ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666,"UpLimit":0.90},"0.90":{"LowLimit":0.90}},"FilterParams":[{"Property":"Country","Value":"NO","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
end

/******  35  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Singapore: Long Ownership Filing - NEW' or Name = 'Singapore: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Singapore: Long Ownership Filing - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05,"SubsequentChange":0.01},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"SG","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where  Name = 'Singapore: Long Ownership Filing - NEW' or Name = 'Singapore: Long Ownership Filing')
  Update r
  Set 
   Name = 'Singapore: Long Ownership Filing',
   ParamsInJson =  
  '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"SG","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  36  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'South Korea: Long Ownership Filing Requirements - NEW' or Name = 'South Korea: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('South Korea: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05,"SubsequentChange":0.01},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"KR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where  Name = 'South Korea: Long Ownership Filing Requirements - NEW' or Name = 'South Korea: Long Ownership Filing')
  Update r
  Set 
   Name = 'South Korea: Long Ownership Filing',
   ParamsInJson =  
 '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"KR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  37  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Spain: Long Ownership Filing - Takeover' or Name = 'Spain: Takeover Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Spain: Long Ownership Filing - Takeover', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.01},"0.01":{"LowLimit":0.01,"UpLimit":0.03},"0.03":{"LowLimit":0.03}},"FilterParams":[{"Property":"Country","Value":"ES","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeoverESOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where  Name = 'Spain: Long Ownership Filing - Takeover' or Name = 'Spain: Takeover Filing')
  Update r
  Set 
   Name = 'Spain: Takeover Filing',
   ParamsInJson =  
 '{"Threshholds":{"0":{"UpLimit":0.007},"0.01":{"LowLimit":0.007,"UpLimit":0.01},"0.01":{"LowLimit":0.01,"UpLimit":0.03},"0.03":{"LowLimit":0.03}},"FilterParams":[{"Property":"Country","Value":"ES","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeoverESOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End
/******  38  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Spain: Long Ownership Filing Requirements - NEW' or Name = 'Spain: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Spain: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.35},"0.35":{"LowLimit":0.35,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.45},"0.45":{"LowLimit":0.45,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.60},"0.60":{"LowLimit":0.60,"UpLimit":0.70},"0.70":{"LowLimit":0.70,"UpLimit":0.80},"0.80":{"LowLimit":0.80,"UpLimit":0.90},"0.90":{"LowLimit":0.90}},"FilterParams":[{"Property":"Country","Value":"ES","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
 Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where   Name = 'Spain: Long Ownership Filing Requirements - NEW' or Name = 'Spain: Long Ownership Filing')
  Update r
  Set 
   Name = 'Spain: Long Ownership Filing',
   ParamsInJson =  
 '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.35},"0.35":{"LowLimit":0.35,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.45},"0.45":{"LowLimit":0.45,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.60},"0.60":{"LowLimit":0.60,"UpLimit":0.70},"0.70":{"LowLimit":0.70,"UpLimit":0.75},"0.75":{"LowLimit":0.75,"UpLimit":0.80},"0.80":{"LowLimit":0.80,"UpLimit":0.90},"0.90":{"LowLimit":0.90}},"FilterParams":[{"Property":"Country","Value":"ES","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  39  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Sweden: Long Ownership Filing Requirements - NEW' or  Name = 'Sweden: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Sweden: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.35},"0.35":{"LowLimit":0.35,"UpLimit":0.40},"0.40":{"LowLimit":0.40,"UpLimit":0.45},"0.45":{"LowLimit":0.45,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666,"UpLimit":0.90},"0.90":{"LowLimit":0.90}},"FilterParams":[{"Property":"Country","Value":"SE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where   Name = 'Sweden: Long Ownership Filing Requirements - NEW' or  Name = 'Sweden: Long Ownership Filing')
  Update r
  Set 
   Name = 'Sweden: Long Ownership Filing',
   ParamsInJson =  
 '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.30},"0.30":{"LowLimit":0.30,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666,"UpLimit":0.90},"0.90":{"LowLimit":0.90}},"FilterParams":[{"Property":"Country","Value":"SE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  40  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Switzerland: Long Ownership Filing - Takeover' or Name = 'Switzerland: Takeover Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Switzerland: Long Ownership Filing - Takeover', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.03},"0.03":{"LowLimit":0.03}},"FilterParams":[{"Property":"Country","Value":"CH","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeoverCHOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where   Name = 'Switzerland: Long Ownership Filing - Takeover' or Name = 'Switzerland: Takeover Filing')
  Update r
  Set 
   Name = 'Switzerland: Takeover Filing',
   ParamsInJson =  
'{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03},"0.03":{"LowLimit":0.03}},"FilterParams":[{"Property":"Country","Value":"CH","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"TakeoverCHOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End
/******  41  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Switzerland: Long Ownership Filing Requirements - NEW' or Name='Switzerland: Long Ownership Filing' ))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Switzerland: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666}},"FilterParams":[{"Property":"Country","Value":"CH","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where  Name = 'Switzerland: Long Ownership Filing Requirements - NEW' or Name='Switzerland: Long Ownership Filing')
  Update r
  Set 
   Name = 'Switzerland: Long Ownership Filing',
   ParamsInJson =  
'{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.05},"0.05":{"LowLimit":0.05,"UpLimit":0.10},"0.10":{"LowLimit":0.10,"UpLimit":0.15},"0.15":{"LowLimit":0.15,"UpLimit":0.20},"0.20":{"LowLimit":0.20,"UpLimit":0.25},"0.25":{"LowLimit":0.25,"UpLimit":0.3333},"0.33":{"LowLimit":0.3333,"UpLimit":0.50},"0.50":{"LowLimit":0.50,"UpLimit":0.6666},"0.66":{"LowLimit":0.6666}},"FilterParams":[{"Property":"Country","Value":"CH","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  42  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'United Kingdom: Long Ownership Filing - Takeover' or Name = 'United Kingdom: Takeover Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('United Kingdom: Long Ownership Filing - Takeover', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.01},"0.01":{"LowLimit":0.01}},"FilterParams":[{"Property":"Country","Value":"GB","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"TakeoverUKOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where  Name = 'United Kingdom: Long Ownership Filing - Takeover' or Name = 'United Kingdom: Takeover Filing')
  Update r
  Set 
   Name = 'United Kingdom: Takeover Filing',
   ParamsInJson =  
'{"Threshholds":{"0":{"UpLimit":0.007},"0.007":{"LowLimit":0.007,"UpLimit":0.01},"0.01":{"LowLimit":0.01}},"FilterParams":[{"Property":"Country","Value":"GB","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"TakeoverUKOfferList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  43  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'United Kingdom: Long Ownership Filing Requirements - NEW' or Name = 'United Kingdom: Long Ownership Filing'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('United Kingdom: Long Ownership Filing Requirements - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.03,"SubsequentChange":0.03},"0.03":{"LowLimit":0.03,"SubsequentChange":0.03}},"FilterParams":[{"Property":"Country","Value":"GB","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where  Name = 'United Kingdom: Long Ownership Filing Requirements - NEW' or Name = 'United Kingdom: Long Ownership Filing')
  Update r
  Set 
   Name = 'United Kingdom: Long Ownership Filing',
   ParamsInJson =  
'{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"SubsequentChange":0.01}},"FilterParams":[{"Property":"Country","Value":"GB","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
  From [OrderGateway].[cp].[Rule] r
  where Id = @ruleId
End

/******  44  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'United States: Long Ownership Filing (13G) - NEW' or Name = 'United States: Long Ownership Filing (13G)' ))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('United States: Long Ownership Filing (13G) - NEW', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', 'Description: Filing required when ownership exceeds or falls below', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"LowLimit":0.05,"UpLimit":null,"SubsequentChange":null,"AlertLevel":null},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"SubsequentChange":null,"AlertLevel":null},"0.10":{"LowLimit":0.10,"UpLimit":0.20,"SubsequentChange":0.05,"AlertLevel":null},"0.20":{"LowLimit":0.20,"UpLimit":null,"SubsequentChange":0.01,"AlertLevel":null}},"FilterParams":[{"Property":"Country","Value":"US","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"BamSymbol","Value":"OIH","Type":null,"Operator":{"OperatorType":"NotEqual"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = (select Id from  [OrderGateway].[cp].[Rule] where  Name = 'United States: Long Ownership Filing (13G) - NEW' or Name = 'United States: Long Ownership Filing (13G)')

Update r
Set 
Name = 'United States: Long Ownership Filing (13G)',
ParamsInJson = 
'{"Threshholds":{"0":{"UpLimit":0.04,"SubsequentChange":null,"AlertLevel":null},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"SubsequentChange":null,"AlertLevel":null},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"SubsequentChange":null,"AlertLevel":null},"0.10":{"LowLimit":0.10,"UpLimit":0.20,"SubsequentChange":0.05,"AlertLevel":null},"0.20":{"LowLimit":0.20,"UpLimit":null,"SubsequentChange":0.01,"AlertLevel":null}},"FilterParams":[{"Property":"Country","Value":"US","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"BamSymbol","Value":"OIH","Type":null,"Operator":{"OperatorType":"NotEqual"}}]}'
From [OrderGateway].[cp].[Rule] r
Where Id = @ruleId

End

/******  45  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Warning: Min -0.10% Shares Outstanding (Net) - GRE'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Warning: Min -0.10% Shares Outstanding (Net) - GRE', 'Bam.Oms.Compliance.Rules.ShortSharesOutstandingWarning', 'GRE rule to check for less than -0.10% short net positions in GRE underlyer', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":-0.1,"FilterParams":[{"Property":"Country","Value":"GR","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Update r
Set
IsActive = 0
From [OrderGateway].[cp].[Rule] r
Where Name = 'Warning: Min -0.10% Shares Outstanding (Net) - GRE'
End

/******  46  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Warning: Min -0.20% Shares Outstanding (Net) - POR'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Warning: Min -0.20% Shares Outstanding (Net) - POR', 'Bam.Oms.Compliance.Rules.ShortSharesOutstandingWarning', 'Portugal rule to check for less than -0.20% short net positions in POR underlyer', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":-0.1,"FilterParams":[{"Property":"Country","Value":"PT","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Update r
Set
IsActive = 0
From [OrderGateway].[cp].[Rule] r
Where Name = 'Warning: Min -0.20% Shares Outstanding (Net) - POR'
End

/******  47  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Warning: Min -0.20% Shares Outstanding (Net) - UKM'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Warning: Min -0.20% Shares Outstanding (Net) - UKM', 'Bam.Oms.Compliance.Rules.ShortSharesOutstandingWarning', 'UK FSA Rights Offerings rule to check for less than -0.20% net Positions in a UKM underlyer', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":-0.2,"FilterParams":[{"Property":"Country","Value":"GB","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Update r
Set
IsActive = 0
From [OrderGateway].[cp].[Rule] r
Where Name = 'Warning: Min -0.20% Shares Outstanding (Net) - UKM'
End

/******  48  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Warning: Min -0.25% Shares Outstanding (Net) - ITA'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Warning: Min -0.25% Shares Outstanding (Net) - ITA', 'Bam.Oms.Compliance.Rules.ShortSharesOutstandingWarning', 'ITA rule to check for less than -0.25% short net positions in ITA underlyer', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":-0.25,"FilterParams":[{"Property":"Country","Value":"IT","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Update r
Set
IsActive = 0
From [OrderGateway].[cp].[Rule] r
Where Name = 'Warning: Min -0.25% Shares Outstanding (Net) - ITA'
End

/******  49  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Warning: Min -0.25% Shares Outstanding (Net) - JPN'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Warning: Min -0.25% Shares Outstanding (Net) - JPN', 'Bam.Oms.Compliance.Rules.ShortSharesOutstandingWarning', 'JPN rule to check for less than -0.25% short net positions in JPN underlyer', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":-0.25,"FilterParams":[{"Property":"Country","Value":"JP","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Update r
Set
IsActive = 0
From [OrderGateway].[cp].[Rule] r
Where Name = 'Warning: Min -0.25% Shares Outstanding (Net) - JPN'
End

/******  50  ******/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule] where Name = 'Warning: Short Shares Outstanding (Net) - Netherlands'))
Begin
  Insert Into [OrderGateway].[cp].[Rule]
  Values ('Warning: Short Shares Outstanding (Net) - Netherlands', 'Bam.Oms.Compliance.Rules.ShortSharesOutstandingWarning', 'Netherlands rule to check for short positions in NET underlyer', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":-0.00001,"FilterParams":[{"Property":"Country","Value":"NL","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Update r
Set
IsActive = 0
From [OrderGateway].[cp].[Rule] r
Where Name = 'Warning: Short Shares Outstanding (Net) - Netherlands'
End

/************** fact list ****************************************/
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'BeneficialOwnershipSecTypes'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('BeneficialOwnershipSecTypes', 'Equity,EquitySwap,EquityOption', getdate(), 'dev', getdate(), 'dev')
End

IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'EUShortCountries'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('EUShortCountries', 'CHF,CZK,DKK,EUR,GBP,HUF,NOK,PLN,SEK', getdate(), 'dev', getdate(), 'dev')
End

IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'SupportedSecurityTypes'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('SupportedSecurityTypes', 'Equity,Swap,Option', getdate(), 'dev', getdate(), 'dev')
End
Else
Begin
Update [OrderGateway].[cp].[Fact]
Set value = 'Equity,EquitySwap,EquityOption'
Where name = 'SupportedSecurityTypes'
End

IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'TakeoverUKOfferList'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('TakeoverUKOfferList', 'US8591521005,
US72766Q1058,
US29444UAH95,
US29444U7000,
US0584981064,
US04270V1061,
GB00BQ1XTV39,
GB00BMHTPY25,
GB00BFG1QM56,
GB00B8JG4R91,
GB00B6V9F139,
GB00B64FXD65,
GB00B60B6S45,
GB00B3KHXB36,
GB00B2QMX606,
GB00B282YM11,
GB00B1250X28,
GB00B081NX89,
GB00B064S565,
GB00B03MM408,
GB00B03MLX29,
GB00B01YQ796,
GB00B00LM737,
GB0034147388,
GB0033856740,
GB0033495515,
GB0030757263,
GB0008762899,
GB0008661166,
GB0006672785,
GB0004992003,
GB0003186409,
GB0002369352
', getdate(), 'dev', getdate(), 'dev')
End

IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'TakeOverIEOfferList'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('TakeOverIEOfferList', 
  'IE00BB0QZ876,AU000000ILU1,NL0011031208', getdate(), 'dev', getdate(), 'dev')
End


IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'TakeOverHKOfferList'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('TakeOverHKOfferList', 
  'BMG1068T1716,
BMG2150P2004,
BMG2157E1093,
BMG2625R1209,
BMG4975T2439,
BMG549601109,
BMG6977B1046,
BMG7312R1768,
BMG7713H1245,
BMG8114X1305,
BMG8571G1096,
BMG9321Z1086,
CNE100000155,
CNE1000001K7,
CNE100001QZ6,
HK0122000687,
HK0141000759,
HK0170000860,
HK0227001168,
JE00B3MW7P88,
KYG0621D1034,
KYG089091063,
KYG1132K1076,
KYG164391040,
KYG2115C1380,
KYG2116M1015,
KYG261411048,
KYG281741036,
KYG2953A1031,
KYG3932J1572,
KYG394081023,
KYG3940K1058,
KYG4288W1151,
KYG4812S1012,
KYG4935G1091,
KYG5726N1043,
KYG6493A1013,
KYG6752K1058,
KYG6976W1179,
KYG8169R1039,
KYG869171044,
BMG2751X1074,
BMG7147K1154,
CN0009099507,
CNE0000008V1,
CNE000001576,
CNE0000016L5,
CNE1000001W2,
CNE1000002N9,
FR0000120354,
HK0000203270,
TW0001102002
', getdate(), 'dev', getdate(), 'dev')
End

IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'TakeOverFROfferList'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('TakeOverFROfferList', 
  'FR0000060121,
FR0000064578,
FR0000121121,
FR0000127771,
QA000A0NBGK5,
US9297401088,FR0000053142,
FR0000060303,
FR0000062176,
FR0000079600,
FR0004038099,
FR0010474130,
FR0010501015,
FR0010678284
', getdate(), 'dev', getdate(), 'dev')
End

IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'TakeoverESOfferList'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('TakeoverESOfferList', 
  'ES0105025003,
ES0110480136,
ES0111845014,
ES0125690513,
ES0184140210,
FR0000133308,
AU000000SON9,
BMG6770K1291,
ES0125690513
', getdate(), 'dev', getdate(), 'dev')
End

IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'TakeoverCHOfferList'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('TakeoverCHOfferList', 
  'JP3538800008,
  CH0022268228,
  CH0012337421,
  CH0011037469,
  CH0005795668,
  CH0003504856
  ', getdate(), 'dev', getdate(), 'dev')
End

IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'TakeoverCAOfferList'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('TakeoverCAOfferList', 
  'CA12481A1003,
CA13643E1051,
CA41618M1095,
CA44985J2048,
CA4632221095,
CA7823061048,
CA8274671012
', getdate(), 'dev', getdate(), 'dev')
End


IF (Not Exists (select 1 from  [OrderGateway].[cp].[Fact] where Name = 'TakeoverBEOfferList'))
Begin
  Insert Into [OrderGateway].[cp].[Fact]
  Values ('TakeoverBEOfferList', 
  'BE0003771855', getdate(), 'dev', getdate(), 'dev')
End
