﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface IRollBlotterSubmission
    {
        void StartRoll(DateTime rollTime, string user, bool force, DateTime? nextBusinessDay);
        void ChangeBusinessDay(DateTime businessDay, string userId);
        void PrepareSnapshotRecovery(string userId);
    }
}