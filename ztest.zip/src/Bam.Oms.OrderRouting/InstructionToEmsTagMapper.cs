using System;
using System.Collections.Generic;
using System.Configuration;
using Bam.Oms.EMSAdapters.Contracts;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.OrderRouting
{
    public class InstructionToEmsTagMapper : IInstructionToEmsTagMapper
    {
        private readonly ILogger _logger;
        private readonly Dictionary<string, string> _mapping;

        public InstructionToEmsTagMapper(ILogger logger)
        {
            if (logger == null) throw new ArgumentNullException("logger");
            _logger = logger;
            _mapping = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);

            var config = (ExecutionInstructionConfigurationSection)ConfigurationManager.GetSection("executionInstructionsSection");

            foreach (InstructionElement instruction in config.ExecutionInstructions)
            {
                if (!_mapping.ContainsKey(instruction.ExecutionCode))
                {
                    _mapping[instruction.ExecutionCode] = instruction.Tag;
                }
                else
                {
                    logger.WarnFormat("Error loading fix tag/instruction mapping, duplicate code {0}", instruction.ExecutionCode);
                }
            }
        }

        public string GetTag(string instructionCode)
        {
            if (_mapping.ContainsKey(instructionCode))
                return _mapping[instructionCode];

            _logger.WarnFormat("No matching fix tag for execution instruction {0}", instructionCode);

            return null;
        }
    }
}