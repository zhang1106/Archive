﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IPositionProvider
    {
        ILookup<string, IPosition> GetData(PositionType pType, PositionIndex pIndex);
        IEnumerable<string> GetUnderlyingSecurities(PositionType pType);
        Tuple<string, decimal?> GetFirmWideQuantity(string underlying, PositionType pType, SideType side);
        Tuple<string, decimal?> GetFirmWideQuantityWithAdr(string underlying, PositionType pType, SideType side);
        Tuple<string, decimal?> GetEntityWideQuantityByIsin(string underlying, PositionType pType, string entity, SideType side);
        
    }
}
