﻿using System.Collections.Generic;
using System.IO;
using System.Text;
using Bam.EventQ.Snapshot;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;

namespace Bam.EventQ.JsonDotNet
{
    public class JsonSnapshotMarshaller : ISnapshotMarshaller
    {
        private readonly ISnapshotTypeRegistry _snapshotTypeRegistry;
        private readonly JsonSerializer _jsonSerializer;

        public JsonSnapshotMarshaller(ISnapshotTypeRegistry snapshotTypeRegistry)
        {
            _snapshotTypeRegistry = snapshotTypeRegistry;
            _jsonSerializer = new JsonSerializer();
            _jsonSerializer.Converters.Add(new StringEnumConverter());
        }

        public void Write(IEnumerable<ISnapshot> snapshots, Stream stream)
        {
            using (var sw = new StreamWriter(stream, Encoding.UTF8, 4096, true))
            using (var writer = new JsonTextWriter(sw))
            {
                writer.Formatting = Formatting.Indented;
                writer.WriteStartObject();
                foreach (var item in snapshots)
                {
                    string name = _snapshotTypeRegistry.GetName(item);
                    if (name == null)
                        continue;

                    var obj = JObject.FromObject(item, _jsonSerializer);
                    writer.WritePropertyName(name);
                    obj.WriteTo(writer);
                }
                writer.WriteEndObject();
            }
        }

        public IEnumerable<ISnapshot> Read(Stream stream)
        {
            using (var sr = new StreamReader(stream, Encoding.UTF8, false, 4096, true))
            using (var reader = new JsonTextReader(sr))
            {
                if (ReadToNext(reader, JsonToken.StartObject))
                {
                    while (ReadToNext(reader, JsonToken.PropertyName))
                    {
                        string name = reader.Value as string;
                        var type = _snapshotTypeRegistry.GetType(name);

                        ReadToNext(reader, JsonToken.StartObject);
                        var obj = JObject.Load(reader);

                        if (type != null)
                        {
                            yield return (ISnapshot)obj.ToObject(type, _jsonSerializer);
                        }
                    }
                }
            }
        }

        private bool ReadToNext(JsonTextReader reader, JsonToken token)
        {
            while (reader.Read() && reader.TokenType != token)
            {

            }

            return reader.TokenType == token;
        }
    }
}
