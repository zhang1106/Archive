﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class TradeSubmission : QueueItemProducerBase<PipelineQueueItem<object>>, ITradeSubmission
    {
        public bool Submit(List<Trade> trades)
        {
            if (Started.WaitOne(TimeSpan.FromSeconds(1)))
            {
                Queue.PublishPayloads(trades);
                return true;
            }

            return false;
        }
    }
}