﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Newtonsoft.Json;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class OrderTests
    {
        [Test]
        public void TestOrderClone()
        {
            // arrange
            var order = new Order()
            {
                BatchId = "batchid",
                Portfolio = new Portfolio("QIAN", "GENERALIST", "EMR"),
                Security = new Security() { BamSymbol = "IBM" },
                Side = SideType.SellShort,
                Size = 100,
                OrderStatus = BamOrderStatus.PendingValidation,
                Trader = Bam.Oms.Data.Constants.DefaultTrader,
                Custodian = "gsco",
                LocateStatus =  LocateStatus.Approved,
                Locate = new List<Data.Orders.Locate>() { new Data.Orders.Locate() { AssignmentId = "1234", PrimeBroker = "CSFB", Rate = 1.2m, RateType = RateType.Fee, Size = 100} },
                ClientOrderId = "2015110210",                
                RoutedSize = 100,
                SettleDate = new DateTime(2015, 11, 5),
                TradeDate = new DateTime(2015, 11, 3),
                StatusMessages = new List<string>(){(new ComplianceIssue(){Description = "des",IssueType = "type",RuleName = "ruelname"}).ToString()},
                ExecutionInstructions = new List<ExecutionInstruction>(){new ExecutionInstruction(){Code = "vol",Value = "0.2"}},
            };

            // act
            var unit = (Order)order.Clone();

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.ClientOrderId, Is.EqualTo("2015110210"));
            Assert.That(unit.BatchId, Is.EqualTo(order.BatchId));
            Assert.That(unit.Portfolio, Is.EqualTo(unit.Portfolio));
            Assert.That(unit.Security, Is.EqualTo(unit.Security));
            Assert.That(unit.Side, Is.EqualTo(unit.Side));
            Assert.That(unit.Size, Is.EqualTo(unit.Size));
            Assert.That(unit.OrderStatus, Is.EqualTo(unit.OrderStatus));
            Assert.That(unit.Trader, Is.EqualTo(unit.Trader));
            Assert.That(unit.Custodian, Is.EqualTo(unit.Custodian));
            Assert.That(unit.Locate, Is.EqualTo(unit.Locate));            
            Assert.That(unit.RoutedSize, Is.EqualTo(unit.RoutedSize));
            Assert.That(unit.SettleDate, Is.EqualTo(unit.SettleDate));
            Assert.That(unit.TradeDate, Is.EqualTo(unit.TradeDate));
            Assert.That(unit.StatusMessages, Is.EqualTo(unit.StatusMessages));
            Assert.That(unit.ExecutionInstructions, Is.EqualTo(unit.ExecutionInstructions));
        }
    }
}