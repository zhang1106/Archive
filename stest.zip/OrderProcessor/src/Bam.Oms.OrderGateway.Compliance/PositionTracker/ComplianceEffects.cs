﻿using Bam.Oms.OrderGateway.Compliance.Model;

namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public struct ComplianceEffects
    {
        public long ShortMarkingQuantity;
        public long LongMarkingQuantity;

        public void Apply(PositionSet set)
        {
            set.Position.ApplyShortMarkingEffect(ShortMarkingQuantity);
            set.Position.ApplyLongMarkingEffect(LongMarkingQuantity);

            set.CompliancePosition.ApplyShortMarkingEffect(ShortMarkingQuantity);
            set.CompliancePosition.ApplyLongMarkingEffect(LongMarkingQuantity);

            set.AggUnitPosition.ApplyShortMarkingEffect(ShortMarkingQuantity);
        }

        public static ComplianceEffects operator -(ComplianceEffects a, ComplianceEffects b)
        {
            return new ComplianceEffects
            {
                ShortMarkingQuantity = a.ShortMarkingQuantity - b.ShortMarkingQuantity,
                LongMarkingQuantity = a.LongMarkingQuantity - b.LongMarkingQuantity
            };
        }
    }
}
