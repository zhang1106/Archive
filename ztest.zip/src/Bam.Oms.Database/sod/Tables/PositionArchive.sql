﻿CREATE TABLE [sod].[PositionArchive] (
    [PositionArchiveId] INT IDENTITY(1, 1) Not NULL, 
	[PositionId] INT NOT NULL ,
    [FundCode]           VARCHAR (50)     NOT NULL,
    [CustodianName] VARCHAR (50)     NOT NULL,
    [StrategyCode]       VARCHAR (50)     NOT NULL,
    [AssetType]    VARCHAR (50)     NOT NULL,
    [BAMSymbol]      VARCHAR (100)    NOT NULL,
    [CustodianAccountCode] VARCHAR (50)      NULL,
	[Qty]            DECIMAL (28, 12) NOT NULL,
    [Price]          DECIMAL (28, 12) NOT NULL,
	[Cost]          DECIMAL (28, 12)  NULL,
    [Ccy]            VARCHAR (50)     NOT NULL,
    [FXRate]         DECIMAL (28, 12) NOT NULL,
	[Stream]          VARCHAR (50)     NULL,
    [EntryDate]      DATE             NOT NULL,
  	[AuditSequence] INT NOT NULL , 
	[ActionLogId] int,
	[CreatedOn] DATETIME NOT NULL , 
    [LastModifiedBy] VARCHAR (50)     NOT NULL,
    [LastModifiedOn] DATETIME         NOT NULL, 
    CONSTRAINT [PK_PositionArchive] PRIMARY KEY ([PositionArchiveId])
);

