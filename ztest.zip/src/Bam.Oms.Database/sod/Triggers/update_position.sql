﻿CREATE TRIGGER [sod].[update_position]
ON [sod].[position]
FOR UPDATE 
AS
INSERT INTO [PositionAudit] (
     [PositionId],
     [FundCode],
     [CustodianAccountCode],
	 [CustodianName],
     [StrategyCode],
     [AssetType],
     [BAMSymbol],
     [Qty],
     [Price],
	 [Cost],
     [Ccy],
     [FXRate],
     [Stream],
     [EntryDate],
     [AuditSequence],
     [ActionLogId],
     [CreatedOn],
	 [LastModifiedBy],
	 [LastModifiedOn]
    )
SELECT
    inserted.[PositionId],
    inserted.[FundCode],
    inserted.[CustodianAccountCode],
	inserted.[CustodianName],
    inserted.[StrategyCode],
    inserted.[AssetType],
    inserted.[BAMSymbol],
    inserted.[Qty],
    inserted.[Price],
	inserted.[Cost],
    inserted.[Ccy],
    inserted.[FXRate],
	inserted.[Stream],
    inserted.[EntryDate],
    inserted.[AuditSequence],
	inserted.[ActionLogId],
	inserted.[CreatedOn],
	inserted.[LastModifiedBy],
	inserted.[LastModifiedOn]
  FROM inserted