﻿using System.Collections.Generic;
using Eze.Common.Integration;

namespace Bam.Oms.EndPoints.Eze
{
    public interface ITranslator
    {
        IList<Trade> GetTrades(string jsonUpdate);
        IList<Allocation> GetAllocations(string jsonUpdate);
    }
}
