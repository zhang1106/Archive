﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Persistence.Compliance
{
    public class RuleRepository<T> : DBRepository<Rule<T>>, IRuleRepository<T> 
    {
        public RuleRepository(ISettings settings, ILogger logger) : base(settings, logger, "cp", "[Rule]")
        {
        }

        public IEnumerable<Rule<T>> GetRules(int policyId )
        {
            string filter = @"[Rule].IsActive = 1 And [Rule].Id in (Select ruleId From cp.PolicyRule WHERE PolicyId = @policyId)";

            return Get(filter, new { PolicyId = policyId });
        } 
    }
}
