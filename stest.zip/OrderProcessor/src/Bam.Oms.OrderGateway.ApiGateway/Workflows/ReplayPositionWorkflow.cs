﻿using System;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Workflows
{
    public class ReplayPositionWorkflow : Workflow, IHandle<DumpedReplacePositions>
    {
        private readonly IReferenceDataService _referenceDataService;
        public ReplayPositionWorkflow(IReferenceDataService referenceDataService)
        {
            if (referenceDataService == null) throw new ArgumentNullException(nameof(referenceDataService));
            _referenceDataService = referenceDataService;
        }

        public void Execute(DumpedReplacePositions input)
        {
            var message = new ReplacePositions();

            foreach (var p in input.Items)
            {
                var item = new ReplacePositions.LineItem
                {
                    PositionId = p.PositionId,
                    ShortMarkingQuantity = p.ShortMarkingQuantity,
                    LongMarkingQuantity = p.LongMarkingQuantity,
                    Portfolio = p.Portfolio,
                    Symbol = p.BamSymbol,
                    TheoreticalQuantity = p.TheoreticalQuantity
                };

                foreach (var a in p.ActualAllocations)
                {
                    int custodianId;
                    if (!_referenceDataService.TryGetBrokerId(a.Custodian, out custodianId))
                    {
                        Logger?.LogWarning($"Receive position allocation with unknown custodian {a.Custodian}");
                        return;
                    }

                    int fundId;
                    if (!_referenceDataService.TryGetFundId(a.Fund, out fundId))
                    {
                        Logger?.LogWarning($"Receive position allocation with unknown fund {a.Custodian}");
                        return;
                    }

                    item.Allocations.Add(new ReplacePositions.Allocation
                    {
                        Quantity = a.Quantity,
                        CustodianId = custodianId,
                        FundId = fundId
                    });
                }

                message.Items.Add(item);
            }

            Publish(message);
        }
    }
}