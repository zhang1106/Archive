﻿using Bam.EventQ.Diagnostics;

namespace Bam.EventQ.Hosting
{
    public static class BackgroundWorkerFactory
    {
        public static ILogger Logger { get; set; }
        public static IBackgroundWorkerFactory Default { get; } = new ThreadedBackgroundWorkerFactory();
        public static IBackgroundWorkerFactory Current { get; set; } = Default;
    }
}