﻿using Bam.EventQ.Snapshot;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Snapshot
{
    public class PositionVersionSnapshot : ISnapshot
    {
        public int MaxVersion { get; set; }
    }
}
