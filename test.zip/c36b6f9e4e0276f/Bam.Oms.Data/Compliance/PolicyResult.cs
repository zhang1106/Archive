﻿using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Data.Compliance
{
    public class PolicyResult : IPolicyResult
    {
        public PolicyResult()
        {
            Alerts = new List<IRuleResult>();
        }
        public string Key { get { return PolicyId.ToString(); } }
        public int PolicyId { get; set; }
        public string PolicyName { get; set; }
        public IList<IRuleResult> Alerts { get; set; }
        //highest violation level
        public ComplianceAlertLevel AlertLevel { get; }
    }
}
