﻿using System.Threading.Tasks;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.SignalR;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;
using Microsoft.AspNet.SignalR;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.SignalR
{
    public abstract class SignalRHub<TItem> : Hub<ISignalRClient<SignalRPacket<TItem>>>, ISignalRHub
    {
        private readonly ISignalRSessionRepository _connectionRepository;

        protected SignalRHub(ISignalRSessionRepository connectionRepository)
        {
            _connectionRepository = connectionRepository;
        }

        public ILogger Logger { get; set; }

        public void RemoveFilter()
        {
            
        }

        public void Ping()
        {
            
        }

        public void AddFilter(ParameterString[] criteria)
        {

        }

        public override Task OnConnected()
        {
            var identity = Context.User?.Identity;
            if (identity != null)
            {
                identity = new CachedIdentity(identity);
                Logger?.LogInformation($"User '{identity.Name}' connected to SignalR API");
                _connectionRepository.Add(Context.ConnectionId, identity);
            }

            return base.OnConnected();
        }

        public override Task OnDisconnected(bool stopCalled)
        {
            var identity = _connectionRepository.TryGet(Context.ConnectionId);
            if (identity != null)
            {
                Logger?.LogInformation($"User '{identity.Name}' disconnected from SignalR API");
                _connectionRepository.Remove(Context.ConnectionId);
            }

            return base.OnDisconnected(stopCalled);
        }

        public override Task OnReconnected()
        {
            var identity = _connectionRepository.TryGet(Context.ConnectionId);
            if (identity != null)
            {
                Logger?.LogInformation($"User '{identity.Name}' reconnected to SignalR API");
                _connectionRepository.Remove(Context.ConnectionId);
                _connectionRepository.Add(Context.ConnectionId, identity);
            }

            return base.OnReconnected();
        }
    }
}
