﻿CREATE SCHEMA [intg]
    AUTHORIZATION [dbo];



