﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Http;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.EndPoints.PermissionService;
using Bam.Oms.PositionTracker;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.SodPosition
{
    public class PositionController : BaseController
    {
        private readonly IPositionTracker _positionTracker;
        private readonly IFlowManager _flowManager;
        private readonly IPositionImportExport _importExport;

        public PositionController(IPositionTracker positionTracker, IFlowManager flowManager, IHostConfiguration hostConfiguration, IPositionImportExport importExport, ILogger logger)
            : base(hostConfiguration, logger)
        {
            _positionTracker = positionTracker;
            _flowManager = flowManager;
            _importExport = importExport;
        }

        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public IList<Position> Get()
        {
            return Get((DateTime?)null);
        }

        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public List<Position> Get(DateTime? cutoffTime)
        {
            if (PermissionChecker.IsPermissionEnabled())
                _logger.Info($"{User.Identity.Name} REQUESTED positions at: {DateTime.Now.ToLongTimeString()} ");

            var positions = new List<Position>();
            positions = _positionTracker.GetCurrentPositions().ToList().ConvertAll(pos => (Position)pos);
            var filteredPostions = FilterPermissionedEntities(positions).ToList();

            if (PermissionChecker.IsPermissionEnabled())
                _logger.Info($"{User.Identity.Name} GOT positions at: {DateTime.Now.ToLongTimeString()} ");

            return filteredPostions;
        }

        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public List<Position> Get(string bamSymbol)
        {
            if (string.IsNullOrWhiteSpace(bamSymbol))
                return new List<Position>();

            List<Position> positions = new List<Position>();
            positions = _positionTracker.GetCurrentPositions(bamSymbol).ToList().ConvertAll(pos => (Position)pos);
            return FilterPermissionedEntities(positions).ToList();
        }

        [AccessRequire("Function.OrderGateway.Admin")]
        public List<ICompliancePosition> GetCompliancePositions()
        {
            return _positionTracker.GetCompliancePositions().ToList();
        }

        [AccessRequire("Function.OrderGateway.Admin")]
        public List<ICompliancePosition> GetCompliancePositions(string bamSymbol)
        {
            return _positionTracker.GetCompliancePositions(bamSymbol).ToList();
        }

        [AccessRequire("Function.OrderGateway.Admin")]
        public List<IAggUnitPosition> GetAggUnitPositions()
        {
            return _positionTracker.GetAggUnitPositions().ToList();
        }

        [AccessRequire("Function.OrderGateway.Admin")]
        public List<IAggUnitPosition> GetAggUnitPositions(string bamSymbol)
        {
            return _positionTracker.GetAggUnitPositions(bamSymbol).ToList();
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Write")]
        public int Dump(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                fileName = @"positions." + DateTime.UtcNow.ToString("yyyyMMddHHmmddfff");
            }

            var positions = _positionTracker.GetCurrentPositions().ToList();
            _importExport.Export(positions, fileName);
            return positions.Count;
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Write")]
        public int Replace(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName) || !System.IO.File.Exists(fileName))
            {
                throw new FileNotFoundException(fileName);
            }

            var positions = _importExport.Import(fileName).Cast<Position>().ToList();
            _flowManager.ReplacePositions(positions);                

            string newFileLocation = fileName + ".processed";
            try
            {
                System.IO.File.Move(fileName, newFileLocation);
            }
            catch (Exception ex)
            {
                _logger.Error($"Unable to move file {fileName} to {newFileLocation}", ex);
            }

            return positions.Count;
        }

        protected IEnumerable<Position> FilterPermissionedEntities(IEnumerable<Position> positions)
        {
            if (!PermissionChecker.IsPermissionEnabled())
            {
                _logger.Warn("DEV or QA. Skipping permisions.");
                return positions;
            }
            StrategyInfo[] strategiesInfos = GetPermissionedStrategies(User.Identity);
            _logger.Debug($"The user {User.Identity.Name} is permissiond for {strategiesInfos.Select(s=>s.StrategyCode).Aggregate((i, j)=>i+"|"+j)}.");
            try
            {
                return positions.Where(
                    position => strategiesInfos.Any(s => position.Portfolio.ToString().Contains(s.StrategyCode)))
                    .ToList();
            }
            catch (NullReferenceException)
            {
                _logger.FatalFormat("Invalid position detected");
                foreach (var p in positions)
                    _logger.Fatal($"Position: {p}");

                throw;
            }
        }
    }
}