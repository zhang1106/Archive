﻿using System;
using Bam.Oms.Filtering;
using NUnit.Framework;
using System.Reflection;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class OperatorTest
    {
        [Test]
        [TestCase("test", "test", OperatorType.Equal, true)]
        [TestCase("test", "test1", OperatorType.NotEqual, true)]
        [TestCase("test0", "test",  OperatorType.StartsWith, true)]
        [TestCase("3tesst1", "test",  OperatorType.StartsWith, false)]
        [TestCase("stest0", "test", OperatorType.Contains, true)]
        [TestCase("3tesst1", "test", OperatorType.Contains, false)]
        [TestCase(100233, 100, OperatorType.StartsWith, true)]
        [TestCase(2100233, 100, OperatorType.Contains, true)]
        public void TestOperators(IComparable src, IComparable obj, OperatorType opType, bool result)
        {
            //arr
            Operator op = new Operator() { OperatorType = opType };

            // act
            MethodInfo method =  op.GetType().GetMethod(opType.ToString());
            var rslt = method.Invoke(op, new object[] { src, obj });
                       
            // assert
            Assert.IsTrue( (bool)rslt == result);
        }

        [Test]
        public void TestOperatorInList()
        {
            //arr
            Operator op = new Operator() { OperatorType =  OperatorType.InList };
            var list = new string[] { "test", "test1" };

            // act

            var rslt = op.InList("test", list);

            // assert
            Assert.IsTrue(rslt);
        }
    }
}
