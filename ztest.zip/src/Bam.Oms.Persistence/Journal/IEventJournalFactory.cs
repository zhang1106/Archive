﻿namespace Bam.Oms.Persistence.Journal
{
    public interface IEventJournalFactory
    {
        IEventJournal Create(string name);
    }
}
