﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public class EzeOrderBatch
    {
        private readonly HashSet<string> _knownSymbols = new HashSet<string>();
        public List<Trade> Trades { get; } = new List<Trade>();
        public bool IsComplianceOverride { get; }

        public EzeOrderBatch(bool isComplianceOverride)
        {
            IsComplianceOverride = isComplianceOverride;
        }

        public bool TryAddOrder(Trade trade, bool isComplianceOverride)
        {
            if (_knownSymbols.Add(trade.Symbol) && IsComplianceOverride == isComplianceOverride)
            {
                Trades.Add(trade);
                return true;
            }

            return false;
        }
    }
}