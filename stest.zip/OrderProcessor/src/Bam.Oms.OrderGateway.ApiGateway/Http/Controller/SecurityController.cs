﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class SecurityController : BaseController
    {
        private readonly ICache<string, Security> _securityCache;

        public SecurityController(ICache<string, Security> securityCache, IPermissionedEntityFilter entityFilter) 
            : base(entityFilter)
        {
            _securityCache = securityCache;
        }

        [RequiredPermissions("Function.OrderGateway.Security.Read, Function.OrderGateway.Security.Write")]
        public List<Security> Get()
        {
            using (_securityCache.AcquireReadAccess())
            {
                return _securityCache.GetItems().ToList();
            }
        }

        [RequiredPermissions("Function.OrderGateway.Security.Read, Function.OrderGateway.Security.Write")]
        public List<Security> Get([FromUri(Name = "cutoffTime")] DateTime createdSince)
        {
            using (_securityCache.AcquireReadAccess())
            {
                return _securityCache.GetItems().Where(s => s.Created >= createdSince).ToList();
            }
        }
    }
}
