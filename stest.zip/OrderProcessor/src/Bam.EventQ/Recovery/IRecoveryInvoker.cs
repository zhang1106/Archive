﻿namespace Bam.EventQ.Recovery
{
    public interface IRecoveryInvoker
    {
        bool TryInvoke(int sourceId, int? topic, long expectedSequence);
    }
}
