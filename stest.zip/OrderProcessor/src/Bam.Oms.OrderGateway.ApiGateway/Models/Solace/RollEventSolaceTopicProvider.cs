﻿using Bam.EventQ.Solace;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Solace
{
    public class RollEventSolaceTopicProvider : ISolaceTopicProvider<RollEvent>
    {
        private readonly string _baseTopic;

        public RollEventSolaceTopicProvider(string baseTopic)
        {
            _baseTopic = baseTopic ?? string.Empty;
            if (_baseTopic.Length > 0 && !_baseTopic.EndsWith("/"))
            {
                _baseTopic += "/";
            }
        }

        public string GetTopic(RollEvent item)
        {
            return $"{_baseTopic}ROLL";
        }
    }
}