﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.DataProvider
{
    public class PositionCalculator : IPositionCalculator
    {
        protected readonly ILogger _logger;
        private readonly ISecurityProvider _dwSecurityProvider;
        private readonly ICustomDataProvider _customDataProvider;

        public PositionCalculator(ISecurityProvider securityProvider, ICustomDataProvider customDataProvider,  ILogger logger)
        {
            _dwSecurityProvider = securityProvider;
            _customDataProvider = customDataProvider;
            _logger = logger;
        }
        
        public Tuple<string, decimal?> GetFirmWideQuantityByUnderlying(string underlying, SideType side, ILookup<string, IPosition> positionsByUnderlying)
        {
            //exclude option for ETF
            var underlyingSecurity = _dwSecurityProvider.GetSecurity(underlying);

            var eqPositions = from p in positionsByUnderlying[underlying]
                              where ((p.Security.IsEquity() || (p.Security.IsEquityOption() && underlyingSecurity.InvestmentType != InvestmentType.ETF))  
                              && (side == p.ActualSide || side == SideType.Net))
                              select new Tuple<string, IPosition>(Util.FormatPositionInfo(p), p);
            //get context
            return Util.Sum(eqPositions, false);
        }

        public Tuple<string, decimal?> GetFirmWideQuantityByUnderlyingWithAdr(string underlying, SideType side,
            ILookup<string, IPosition> positionsByUnderlying)
        {
            var underlyingPosition = GetFirmWideQuantityByUnderlying(underlying, side, positionsByUnderlying);

            var adrPosition = new Tuple<string, decimal?>("{\"position\":[\"empty\"]}", 0);

            var adrs = _dwSecurityProvider.GetADRs(underlying);

            if (adrs == null) return underlyingPosition;

            var checkedUnderlying = new HashSet<string>();

            foreach (var a in adrs)
            {
                if (checkedUnderlying.Contains(a.UnderlyingSymbol)) continue;

                var firmNet = GetFirmWideQuantityByUnderlying(a.BamSymbol, side, positionsByUnderlying);

                adrPosition = Tuple.Create($"{{\"position\":[{firmNet.Item1},{adrPosition.Item1}]}}", firmNet.Item2 * a.AdrRatio + adrPosition.Item2);

                checkedUnderlying.Add(a.UnderlyingSymbol);
            }
            
            return adrPosition.Item2.HasValue && adrPosition.Item2 != 0?  Tuple.Create($"{{\"position\":[{adrPosition.Item1},{underlyingPosition.Item1}]}}"
                , adrPosition.Item2 + underlyingPosition.Item2) : underlyingPosition;
        }
        //
        //on isin
        //
        public Tuple<string, decimal?> GetEntityWideQuantityByIsin(string symbol, SideType side, string entity, ILookup<string, IPosition> positionsByIsin)
        {
            var security = _dwSecurityProvider.GetSecurity(symbol);

            if(security == null) throw new Exception($"Cant find security for {symbol}");

            if (!_customDataProvider.LinkedSecurities.ContainsKey(symbol))
                return GetEnitityPositionIncludeAdrByIsin(security, side, entity, positionsByIsin);

            //for linked securities
            var checkedIsin = new HashSet<string>();
            var result = new Tuple<string, decimal?>(string.Empty, 0);
            foreach (var s in _customDataProvider.LinkedSecurities[symbol])
            {
                if (checkedIsin.Contains(s.Isin)) continue;
                var thisResult = GetEnitityPositionIncludeAdrByIsin(s, side, entity, positionsByIsin);
                result = Tuple.Create($"{{\"position\":[{thisResult.Item1},{result.Item1}]}}", thisResult.Item2 + result.Item2);
                checkedIsin.Add(s.Isin);
            }
            return result;
        }

        public Tuple<string, decimal?> GetEnitityPositionIncludeAdrByIsin(ISecurity security,  SideType side, string entity, ILookup<string, IPosition> data)
        {

            var adrPosition = GetADrsNetPositionByIsin(security, side, entity, data);
            var firmNet = GetFirmWideEquityQuantityByIsin(security.Isin, side, entity, data);

            return adrPosition == null ? firmNet : Tuple.Create($"{{\"position\":[{adrPosition.Item1},{firmNet.Item1}]}}", adrPosition.Item2 + firmNet.Item2);
        }

        public Tuple<string, decimal?> GetADrsNetPositionByIsin(ISecurity security, SideType side, string entity, ILookup<string, IPosition> decomposedbyIsin)
        {
            var adrPosition = new Tuple<string, decimal?>("{\"position\":[\"empty\"]}", 0);

            var adrs = _dwSecurityProvider.GetADRs(security.BamSymbol);
            if (adrs == null) return null;
            var checkedIsin = new HashSet<string>();
            foreach (var a in adrs)
            {
                if (checkedIsin.Contains(a.Isin)) continue;
                var firmNet = GetFirmWideEquityQuantityByIsin(a.Isin, side, entity, decomposedbyIsin);
                adrPosition = Tuple.Create($"{{\"position\":[{firmNet.Item1},{adrPosition.Item1}]}}", firmNet.Item2*a.AdrRatio + adrPosition.Item2);
                checkedIsin.Add(a.Isin);
            }

            return adrPosition;
        }
        
        /// <summary>
        /// get firm wide quantities given a symbol
        /// when side is null, it returns net position,otherwise side position.
        /// </summary>
        /// <param name="isin"></param>
        /// <param name="side"></param>
        /// <returns></returns>
        public Tuple<string, decimal?> GetFirmWideEquityQuantityByIsin(string isin, SideType side, string entity, ILookup<string, IPosition> decomposedbyIsin)
        {
            var eqPositions = from p in decomposedbyIsin[isin]
                              where
                                 string.Compare(p.Security.Isin, isin, StringComparison.OrdinalIgnoreCase) == 0 &&
                                string.Compare(p.Portfolio.AggregationUnit, entity, StringComparison.OrdinalIgnoreCase) == 0 &&
                                (p.Security.IsEquity() || p.Security.IsEquityOption()) && 
                                (side == p.ActualSide || side == SideType.Net)
                              select new Tuple<string, IPosition>(Util.FormatPositionInfo(p), p);
            //get context
            return Util.Sum(eqPositions, false);
        }

    }
}
