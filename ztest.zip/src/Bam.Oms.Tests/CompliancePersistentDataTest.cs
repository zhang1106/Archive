﻿using System;
using System.Collections.Generic;
using System.Linq;
using Moq;
using NUnit.Framework;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Compliance.Results;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class CompliancePersistentDataTest
    {
        RuleResultRepository _ruleResultRepository;

        [TestFixtureSetUp]
        public void Initialize()
        {
            _ruleResultRepository = new RuleResultRepository(new Mock<ILogger>().Object);
            _ruleResultRepository.ClearAll();
        }

        [Test]
        //test persistence usaage of  compliance result
        public void TestRuleResultPutGet()
        {
            //arragne
            DateTime currentTime = DateTime.UtcNow;
            RuleResult ruleResult = new RuleResult() { PolicyId = 1, RuleId = 1, BamSymbol = "IBM" };

            //act
            RuleResult savedRuleResult = _ruleResultRepository.Save(ruleResult);
            IEnumerable<RuleResult> ruleResultSet = _ruleResultRepository.Get(currentTime);
            RuleResult getRuleResult = _ruleResultRepository.Get(ruleResult.Key);

            //assert
            Assert.AreEqual(ruleResult.BamSymbol, savedRuleResult.BamSymbol);
            Assert.IsTrue(ruleResultSet.ToList().Count == 1);
            Assert.AreEqual(getRuleResult.Key, ruleResult.Key);
        }


        [Test]
        //test persistence usaage of  compliance result
        public void TestLongOwnershipFilingRuleResultPutGet()
        {
            //arragne
            DateTime currentTime = DateTime.UtcNow;
            LongOwnershipFilingResult lResult = new LongOwnershipFilingResult() {RuleId=1, PolicyId=1, BamSymbol = "IBM", Ratio = 0.05m, IsViolationOverriden = false, LowLimit = 0.05m};

            //act
            RuleResult result = _ruleResultRepository.Save(lResult);

            //assert
            Assert.AreEqual(result.BamSymbol, lResult.BamSymbol);
        }
    }
}
