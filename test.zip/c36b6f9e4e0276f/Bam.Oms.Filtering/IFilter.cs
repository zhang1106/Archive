﻿using System;
using System.Collections.Generic;

namespace Bam.Oms.Filtering
{
    public interface IFilter<in T>
    {
        /// <summary>
        /// Saves a list of filter subjects to be applied every update
        /// </summary>
        /// <param name="id"></param>
        /// <param name="criteria"></param>
        /// <returns></returns>
        void AddToFilter(string id, IEnumerable<Parameter> criteria);

        /// <summary>
        /// add a list of paramters to the filter
        /// </summary>
        /// <param name="id"></param>
        /// <param name="criteria"></param>
        /// <param name="isAndFilter"></param>
        void AddToFilter(string id, IEnumerable<Parameter> criteria, bool isAndFilter);

        /// <summary>
        /// Applies the saved filters to the item and indicates whether or not it should be filtered out
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        IEnumerable<string> ApplyFilter(T item);

        /// <summary>
        /// Checks to see a given item passes the filter for a given consumer
        /// </summary>
        /// <param name="id"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        bool ApplyFilter(string id, T item);

        /// <summary>
        /// get list of paramters  used in the filter
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        IEnumerable<Parameter> GetParameters(string id);
        
        /// <summary>
        /// Removes the filter list for a given caller/subscriber
        /// </summary>
        /// <param name="id"></param>
        void ClearFilter(string id);

        /// <summary>
        /// Raises an event one a user changes their hub filter.  This is used to signal any listener to potentially replay
        /// </summary>
        event Action<string> FilterChanged;


        /// <summary>
        /// Readonly list of ClientIds currently subscribing for messages from the Order Gateway
        /// </summary>
        IReadOnlyCollection<string> ClientConnectionIds { get; }
    }
}