﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data.Configuration
{
    public interface ISettings
    {
        void Initialize();

        void Config();

        string BaseUrl { get; set; }
        string BasePort { get; set; }

        string OrderGatewayConnectionString { get; set; }
        string OrderGatewayMainConnectionString { get; set; }
        string BamCoreLiteConnectionString { get; set; }

        string MQConnectionString { get; set; }
        string MQExchange { get; set; }

        string HeadRoomFilePath { get; set; }
        string ConstituentsFilePath { get; set; }
        string DebugFilePath { get; set; }
        string HeadRoomRuleName { get; set; }
        string HeadRoomSymbol { get; set; }

        string PomoHoldingUrl { get; set; }
        string PomoUrl { get; set; }
        TimeSpan DefaultTokenExpiry { get; }
        bool AllowTokenAsUrlParameter { get; }
        int HeadRoomRatioAQTF { get; }
        int HeadRoomRatioMAIN { get; }
        string SodWatchPath { get; }
        string SodArchivePath { get; }
        string SodErrorPath { get; }
        DateTime SODDateTime { get; }

        string BrokerServiceQueue { get; }
        int ComplianceStart { get; }
        int ComplianceEnd { get; }
        int ComplianceSpan { get; }

        string DeployEnvironment { get; }

        int BbBatchSize { get; }

        int EodStartTime { get; }
        int EodEndTime { get; }
        bool WarningOnly { get;}
        int SecurityRefreshRequency { get; }
        string FactTable { get; }
        string PolicyTable { get; }
        string PolicyRuleTable { get; }
        string RuleTable { get; }
        bool UseBloombBergData { get;}
        bool EnableSqlMonitoring { get; }
    }
}
