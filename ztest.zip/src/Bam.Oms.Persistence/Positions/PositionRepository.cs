﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Portfolios;
using Microsoft.Isam.Esent.Interop;

namespace Bam.Oms.Persistence.Positions
{
    public class PositionRepository : IPositionRepository
    {
        private readonly Dictionary<IPositionKey, IPosition> _positionCache 
            = new Dictionary<IPositionKey, IPosition>();
        private readonly Dictionary<IComplianceGroupKey, ICompliancePosition> _compliancePositionCache 
            = new Dictionary<IComplianceGroupKey, ICompliancePosition>();
        private readonly Dictionary<IAggUnitKey, IAggUnitPosition> _aggUnitPositionCache
            = new Dictionary<IAggUnitKey, IAggUnitPosition>();

        private readonly ReaderWriterLockSlim _rwLock = new ReaderWriterLockSlim(LockRecursionPolicy.SupportsRecursion);

        public IReadOnlyList<IAggUnitPosition> GetAggUnitPositions()
        {
            _rwLock.EnterReadLock();
            try
            {
                return _aggUnitPositionCache.Values.ToArray();
            }
            finally
            {
                _rwLock.ExitReadLock();
            }
        }

        public IReadOnlyList<ICompliancePosition> GetCompliancePositions()
        {
            _rwLock.EnterReadLock();
            try
            {
                return _compliancePositionCache.Values.ToArray();
            }
            finally
            {
                _rwLock.ExitReadLock();
            }
        }

        public IReadOnlyList<IPosition> GetAllPositions()
        {
            _rwLock.EnterReadLock();
            try
            {
                return _positionCache.Values.ToArray();
            }
            finally
            {
                _rwLock.ExitReadLock();
            }
        }

        public IReadOnlyList<IPosition> GetPositions(IReadOnlyList<IPositionKey> keys)
        {
            _rwLock.EnterReadLock();
            try
            {
                var result = new List<IPosition>(keys.Count);
                foreach (var key in keys)
                {
                    IPosition p;
                    if (_positionCache.TryGetValue(key, out p))
                    {
                        result.Add(p);
                    }
                }

                return result;
            }
            finally
            {
                _rwLock.ExitReadLock();
            }
        }

        public IReadOnlyList<IPositionSet> Get(IReadOnlyList<IPositionKey> keys)
        {
            _rwLock.EnterUpgradeableReadLock();
            try
            {
                var result = new List<IPositionSet>(keys.Count);
                foreach (var pk in keys)
                {
                    IPosition position;
                    if (!_positionCache.TryGetValue(pk, out position))
                    {
                        _rwLock.EnterWriteLock();
                        try
                        {
                            if (!_positionCache.TryGetValue(pk, out position))
                            {
                                position = _positionCache[pk] = CreateNewPosition(pk);
                            }
                        }
                        finally
                        {
                            _rwLock.ExitWriteLock();
                        }
                    }

                    IAggUnitPosition aggUnitPosition;
                    var aggUnitKey = new AggUnitKey(pk.Portfolio.AggregationUnit, pk.Security);
                    if (!_aggUnitPositionCache.TryGetValue(aggUnitKey, out aggUnitPosition))
                    {
                        _rwLock.EnterWriteLock();
                        try
                        {
                            if (!_aggUnitPositionCache.TryGetValue(aggUnitKey, out aggUnitPosition))
                            {
                                aggUnitPosition = _aggUnitPositionCache[aggUnitKey] = CreateNewAggUnitPosition(pk);
                            }
                        }
                        finally
                        {
                            _rwLock.ExitWriteLock();
                        }
                    }

                    ICompliancePosition compliancePosition;
                    var complianceKey = new ComplianceGroupKey(pk.Portfolio.ComplianceGroup, pk.Security);
                    if (!_compliancePositionCache.TryGetValue(complianceKey, out compliancePosition))
                    {
                        _rwLock.EnterWriteLock();
                        try
                        {
                            if (!_compliancePositionCache.TryGetValue(complianceKey, out compliancePosition))
                            {
                                compliancePosition =
                                    _compliancePositionCache[complianceKey] = CreateNewCompliancePosition(pk);
                            }
                        }
                        finally
                        {
                            _rwLock.ExitWriteLock();
                        }
                    }

                    result.Add(new PositionSet
                    {
                        Position = position,
                        AggUnitPosition = aggUnitPosition,
                        CompliancePosition = compliancePosition
                    });
                }

                return result;
            }
            finally
            {
                _rwLock.ExitUpgradeableReadLock();
            }
        }

        public void Save(IReadOnlyList<IPositionSet> sets)
        {
            _rwLock.EnterWriteLock();
            try
            {
                foreach (var set in sets)
                {
                    var pk = new PositionKey(set.Position.Portfolio, set.Position.Security);
                    if (set.Position != null)
                    {
                        _positionCache[pk] = set.Position;
                    }

                    var aggUnitKey = new AggUnitKey(pk.Portfolio.AggregationUnit, pk.Security);
                    if (set.AggUnitPosition != null)
                    {
                        _aggUnitPositionCache[aggUnitKey] = set.AggUnitPosition;
                    }

                    var complianceKey = new ComplianceGroupKey(pk.Portfolio.ComplianceGroup, pk.Security);
                    if (set.CompliancePosition != null)
                    {
                        _compliancePositionCache[complianceKey] = set.CompliancePosition;
                    }
                }
            }
            finally
            {
                _rwLock.ExitWriteLock();
            }
        }

        public void Clear()
        {
            _rwLock.EnterWriteLock();
            try
            {
                _positionCache.Clear();
                _aggUnitPositionCache.Clear();
                _compliancePositionCache.Clear();
            }
            finally
            {
                _rwLock.ExitWriteLock();
            }
        }

        public void Clear(IReadOnlyList<string> symbols)
        {
            _rwLock.EnterWriteLock();
            try
            {
                var lookup = new HashSet<string>(symbols);
                var pks = _positionCache.Keys.Where(k => lookup.Contains(k.Security.BamSymbol)).ToList();
                foreach (var pk in pks)
                {
                    _positionCache.Remove(pk);
                    _aggUnitPositionCache.Remove(new AggUnitKey
                    {
                        Security = pk.Security,
                        AggregationUnit = pk.Portfolio.AggregationUnit
                    });
                    _compliancePositionCache.Remove(new ComplianceGroupKey
                    {
                        Security = pk.Security,
                        ComplianceGroup = pk.Portfolio.ComplianceGroup
                    });
                }
            }
            finally
            {
                _rwLock.ExitWriteLock();
            }
        }

        public void Clear(string stream, IReadOnlyList<string> symbols)
        {
            _rwLock.EnterWriteLock();
            try
            {
                var lookup = new HashSet<string>(symbols);
                var pks = _positionCache.Where(k=>string.Equals(k.Value.Stream, stream, System.StringComparison.InvariantCultureIgnoreCase)
                                                && lookup.Contains(k.Key.Security.BamSymbol)).ToList();
                foreach (var p in pks)
                {
                    var pk = p.Key;
                    _positionCache.Remove(pk);
                    _aggUnitPositionCache.Remove(new AggUnitKey
                    {
                        Security = pk.Security,
                        AggregationUnit = pk.Portfolio.AggregationUnit
                    });
                    _compliancePositionCache.Remove(new ComplianceGroupKey
                    {
                        Security = pk.Security,
                        ComplianceGroup = pk.Portfolio.ComplianceGroup
                    });
                }
            }
            finally
            {
                _rwLock.ExitWriteLock();
            }
        }

        private IPosition CreateNewPosition(IPositionKey pk)
        {
            return new Position(pk.Portfolio, pk.Security)
            {
                TheoreticalQuantity = 0,
                ActualQuantity = 0,
                LongMarkingQuantity = 0,
                ShortMarkingQuantity = 0
            };
        }

        private ICompliancePosition CreateNewCompliancePosition(IPositionKey pk)
        {
            return new CompliancePosition
            {
                Key = new ComplianceGroupKey(pk.Portfolio.ComplianceGroup, pk.Security)
            };
        }

        private IAggUnitPosition CreateNewAggUnitPosition(IPositionKey pk)
        {
            return new AggUnitPosition
            {
                Key = new AggUnitKey(pk.Portfolio.AggregationUnit, pk.Security)
            };
        }
    }
}
