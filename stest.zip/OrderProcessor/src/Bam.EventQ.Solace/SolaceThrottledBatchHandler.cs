﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Throttling;
using SolaceSystems.Solclient.Messaging;

namespace Bam.EventQ.Solace
{
    public class SolaceThrottledBatchHandler<TItem> : IThrottledBatchHandler<TItem>, IDisposable
    {
        private readonly BlockingCollection<IMessage> _outgoing;
        private readonly ManualResetEvent _itemsAvailable;
        private readonly TimeSpan _retryInterval;
        private readonly ISolaceTopicProvider<TItem> _topicProvider;
        private readonly ISolaceMessageSerializer<TItem> _messageSerializer;
        private readonly SolacePublisher _publisher;
        private readonly IBackgroundWorker _publishWorker;

        private ILogger _logger;

        public SolaceThrottledBatchHandler(SolaceContextWrapper contextWrapper,
            ISolaceTopicProvider<TItem> topicProvider,
            ISolaceMessageSerializer<TItem> messageSerializer)
        {
            _outgoing = new BlockingCollection<IMessage>();
            _topicProvider = topicProvider;
            _messageSerializer = messageSerializer;
            _itemsAvailable = new ManualResetEvent(false);
            _retryInterval = TimeSpan.FromSeconds(5);
            _publishWorker = BackgroundWorkerFactory.Current.Create($"Solace {typeof(TItem).GetDisplayName()}");
            _publisher = new SolacePublisher(contextWrapper);

            _publisher.Connect();
            _publishWorker.Start(Publish);
        }

        public ILogger Logger
        {
            get { return _logger; }
            set
            {
                _logger = value;
                _publisher.Logger = value;
            }
        }

        public void Dispose()
        {
            _publishWorker.Dispose();
            _publisher.Dispose();
        }

        public void Handle(IReadOnlyList<TItem> batch)
        {
            foreach (var item in batch)
            {
                var msg = ContextFactory.Instance.CreateMessage();
                msg.Destination = ContextFactory.Instance.CreateTopic(
                    _topicProvider.GetTopic(item));
                _messageSerializer.Serialize(msg, item);
                _outgoing.Add(msg);
            }

            _itemsAvailable.Set();
        }

        private void Publish(CancellationToken cancellationToken)
        {
            var handles = new[] { cancellationToken.WaitHandle, _itemsAvailable };
            var batch = new List<IMessage>();

            while (_outgoing.Count > 0 && !cancellationToken.IsCancellationRequested ||
                   WaitHandle.WaitAny(handles) != 0)
            {
                IMessage message;
                while (batch.Count < SolacePublisher.MaxBatchSize &&
                       _outgoing.TryTake(out message))
                {
                    batch.Add(message);
                }

                _itemsAvailable.Reset();
                if (batch.Count == 0)
                    continue;

                retry:
                try
                {
                    int sent = _publisher.Publish(batch, 0, batch.Count);
                    if (sent < batch.Count)
                    {
                        if (sent > 0)
                        {
                            batch.RemoveRange(0, sent);
                        }
                    }
                    else
                    {
                        batch.Clear();
                    }
                }
                catch (Exception ex)
                {
                    Logger?.LogError("Error while publishing to Solace", ex);
                }

                if (batch.Count > 0)
                {
                    bool retry = !cancellationToken.IsCancellationRequested;
                    foreach (var msg in batch)
                    {
                        Logger?.LogError(
                            retry
                                ? $"Failed to send message with topic \"{msg.Destination.Name}\", retrying in {_retryInterval}"
                                : $"Failed to send message with topic \"{msg.Destination.Name}\"");
                    }

                    if (retry)
                    {
                        cancellationToken.WaitHandle.WaitOne(_retryInterval);
                        goto retry;
                    }
                }
            }
        }
    }
}
