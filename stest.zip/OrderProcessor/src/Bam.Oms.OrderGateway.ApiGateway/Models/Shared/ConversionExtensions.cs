﻿using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public static class ConversionExtensions
    {
        public static SideType ToSideType(this Side side)
        {
            switch (side)
            {
                case Side.Buy:
                    return SideType.Buy;
                case Side.Sell:
                    return SideType.Sell;
                case Side.Cover:
                    return SideType.Cover;
                case Side.Short:
                    return SideType.SellShort;
            }

            return SideType.Unknown;
        }

        public static Side ToSide(this SideType side)
        {
            switch (side)
            {
                case SideType.Buy:
                    return Side.Buy;
                case SideType.Sell:
                    return Side.Sell;
                case SideType.Cover:
                    return Side.Cover;
                case SideType.SellShort:
                    return Side.Short;
                case SideType.Short:
                    return Side.Short;
                case SideType.Long:
                    return Side.Buy;
            }

            return Side.Buy;
        }
    }
}
