﻿using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public interface IOrderFactory
    {
        Order Create(long id, string symbol, string securityType, Portfolio portfolio, long size, Side side);
        Order CreateSplit(long originalId, Order reference);
    }
}