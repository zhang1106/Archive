﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Locate.Hub.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Trades;
using Bam.Oms.Filtering;
using Bam.Oms.Messaging;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR.Client;
using Newtonsoft.Json;

namespace Bam.Oms.ShortLocate
{
    public class LocateService : ILocateService
    {
        private readonly IInventoryController _locateHub;
        private readonly ILogger _logger;
        private readonly IMessagingClient<SignalRPacket<TradeAssignment>> _messagingClient;
        private readonly IConnection _connection;
        private readonly ISecurityMasterService _securityMasterService;
        private bool _subscribed = false;

        public event Action<IList<TradeAssignment>> LocateAssignmentUpdated;
        public void SubscribeToLocates()
        {
            if (!_subscribed)
            {
                var hubConnection = _connection as HubConnection;
                if (hubConnection != null)
                {
                    if (hubConnection.State == ConnectionState.Connected)
                    {
                        _messagingClient.ApplyFilter(new List<ParameterString>()); //get everything
                        _subscribed = true;
                    }
                    else
                    {
                        _logger.Error("Unable to subscribe to locate updates because the hub connection is not connected");
                    }
                }
            }
        }

        public void CancelTrades(IDictionary<string, IList<IBlockTrade>> blockTrades)
        {
            var cancelRequest = new List<CancelTradeRequest>();
            foreach (var blockTrade in blockTrades)
            {
                var request = new CancelTradeRequest();
                request.TradeId = blockTrade.Key;
                request.ExecutedSize = (int)blockTrade.Value.Sum(r=>r.TradedQuantity); //todo: baby bonds as decimal?

                cancelRequest.Add(request);
            }

            _logger.Info($"Releasing unused locates for {cancelRequest.Count} orders");

            var releasedAllocations = _locateHub.PostCancelTrade(cancelRequest);

            _logger.Info($"Released {releasedAllocations} allocations");
        }

        public LocateService(IInventoryController locateHub, ILogger logger,
            IMessagingClient<SignalRPacket<TradeAssignment>> messagingClient, [NamedDependency("excalibur")]IConnection connection, ISecurityMasterService securityMasterService)
        {
            if (locateHub == null) throw new ArgumentNullException(nameof(locateHub));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (connection == null) throw new ArgumentNullException(nameof(connection));
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));

            _locateHub = locateHub;
            _logger = logger;
            _messagingClient = messagingClient;
            _connection = connection;
            _securityMasterService = securityMasterService;
            _messagingClient.ReceiveMessageCallback += HandleTradeAssignmentPacket;

            var hubConnection = _connection as HubConnection;
            if (hubConnection != null)
            {
                hubConnection.StateChanged += s =>
                {
                    if (hubConnection.State == ConnectionState.Connected && !_subscribed)
                        SubscribeToLocates();
                };
            }
        }

        public IEnumerable<IOrder> RequestForInventory(IEnumerable<ILocateRequest> requests)
        {
            var responses = _locateHub.PostInventoryAssignment(requests.Select(CreateShortServiceRequest).ToList());
            var orderList = new List<IOrder>();

            _logger.Info($"Short locate response {JsonConvert.SerializeObject(responses)}");

            if (responses == null)
                return orderList;

            foreach (var request in requests)
            {
                var response = responses.FirstOrDefault(r => r.TradeId == request.Order.ClientOrderId);
                var order = CreateResponse(response, request);
                orderList.Add(order);
            }

            return orderList;
        }

        public void Dispose()
        {
            var disposableProxy = _locateHub as IDisposable;
            disposableProxy?.Dispose();
        }

        private void HandleTradeAssignmentPacket(SignalRPacket<TradeAssignment> packet)
        {
            _logger.Info($"Received trade assignment; Sequence {packet.Sequence} of {packet.TotalExpectedPackets} for Id {packet.Id}");
            _logger.Debug($"TradeAssignment data {JsonConvert.SerializeObject(packet.Data)}");
            LocateAssignmentUpdated?.Invoke(packet.Data.ToList());
        }

        private TradeAssignmentRequest CreateShortServiceRequest(ILocateRequest request)
        {
            //set every initial request to generate 
            request.Order.LocateStatus = LocateStatus.Pending;

            return new TradeAssignmentRequest
            {
                Ticker = _securityMasterService.ExtractUnderlying(request.Order.Security.SecurityType, request.Order.Security.BamSymbol),
                QuantityRequested = (int) request.Order.Size,
                TradeId = request.Order.ClientOrderId,
                TradeDate = request.Order.TradeDate,
                Broker = request.Broker
            };
        }

        private IOrder CreateResponse(TradeAssignment assignment, ILocateRequest request)
        {
            if (request.Order.Locate == null)
                request.Order.Locate = new List<Data.Orders.Locate>();

            if (assignment != null)
            {
                if (assignment.BrokerLocateStatus == BrokerLocateStatus.Approved || assignment.BrokerLocateStatus == BrokerLocateStatus.Partial)
                {
                    foreach (var approval in assignment.Approvals)
                    {
                        if (approval.LocateId == null) continue;

                        var locate = new Data.Orders.Locate
                        {
                            TimeReceived = approval.ResponseTime,
                            LocateId = approval.LocateId,
                            Size = approval.Size,
                            AssignmentId = approval.ApprovalId,
                            PrimeBroker = approval.Broker,
                            Rate = approval.Rate,
                            RateType = ConvertShortLocateStringToRateType(approval.RateType)
                        };
                        request.Order.Locate.Add(locate);
                    }
                }

                request.Order.LocateStatus = (LocateStatus?)assignment.BrokerLocateStatus;
            }

            return request.Order;
        }

        private RateType ConvertShortLocateStringToRateType(string rateTypeString)
        {
            switch (rateTypeString)
            {
                case "F":
                    return RateType.Fee;
                default:
                case "R":
                    return RateType.Rebate;
            }
        }
    }
}