﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using Newtonsoft.Json;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;

namespace Bam.Oms.Compliance.DataProvider
{
    public class PomoDataProvider : IIntradayPositionProvider, IMarketDataProvider
    {
        readonly IJsonDataProvider _jsonDataProvider;
        readonly ISecurityProvider _dwSecurityProvider;
        public DateTime RefreshTime { get; private set; }
        public IEnumerable<IPosition> Positions { get; private set; }
        public IDictionary<string, IMarketData> MarketData { get; private set; }
        public string PomoUri
        {
            get
            {
                var uri = ConfigurationManager.AppSettings["compliance_pomoUri"];
                return string.IsNullOrWhiteSpace(uri) ? "http://pomo-app/PoMoWebServices/api/ContainerInfo?ACU=JELL" : uri;
            }
        }
        public PomoDataProvider(IJsonDataProvider jsonProvider, ISecurityProvider dwSecurityProvider)
        {
            _jsonDataProvider = jsonProvider;
            _dwSecurityProvider = dwSecurityProvider;
            Positions = new List<IPosition>();
            MarketData = new Dictionary<string, IMarketData>();
        }
        /// <summary>
        /// refresh source data before a compliance check
        /// </summary>
        public void RefreshData()
        {
            Positions = new List<IPosition>();
            MarketData = new Dictionary<string, IMarketData>();
            PopulatePomoData(_jsonDataProvider.GetDataInJson(PomoUri));
        }
        public Tuple<string, decimal?> GetFirmWideLongQuantity(string underlying)
        {
            var longEqInfo = GetFirmWideEquityQuantity(underlying, SideType.Long);
            var longOpInfo = GetFirmWideOptionLongQuantity(underlying);
            return Tuple.Create<string, decimal?>($"[{longEqInfo.Item1},{longOpInfo.Item1}]",
               longEqInfo.Item2 + longOpInfo.Item2);
        }

        public Tuple<string, decimal?> GetFirmWideShortQuantity(string underlying)
        {
            var shortEqInfo = GetFirmWideEquityQuantity(underlying, SideType.Short);
            var shortOpInfo = GetFirmWideOptionShortQuantity(underlying);
            return Tuple.Create<string, decimal?>($"[{shortEqInfo.Item1},{shortOpInfo.Item1}]",
                 shortEqInfo.Item2 + shortOpInfo.Item2);
        }
        public Tuple<string, decimal?> GetFirmWideNetQuantity(string underlying)
        {
            var longInfo = GetFirmWideLongQuantity(underlying);
            var shortInfo = GetFirmWideShortQuantity(underlying);
            return Tuple.Create<string, decimal?>($"[{longInfo.Item1},{shortInfo.Item1}]",
                longInfo.Item2 - shortInfo.Item2);
        }
        /// <summary>
        /// get firm wide quantities given a symbol
        /// when side is null, it returns net position,otherwise side position.
        /// </summary>
        /// <param name="underlying"></param>
        /// <param name="side"></param>
        /// <returns></returns>
        protected Tuple<string, decimal?> GetFirmWideEquityQuantity(string underlying, SideType side)
        {
            var eqPositions = from p in Positions
                              where String.Compare(p.Security.UnderlyingSymbol, underlying, StringComparison.OrdinalIgnoreCase) == 0 &&
                                (p.Security.SecurityType == SecurityType.Equity || p.Security.SecurityType == SecurityType.EquitySwap) &&
                                side == p.ActualSide
                              select new Tuple<string, IPosition>(FormatPositionInfo(p), p);
            //get context
            return Sum(eqPositions, false);
        }
        protected Tuple<string, decimal?> GetFirmWideOptionLongQuantity(string underlying)
        {
            var opPositions = from p in Positions
                              where String.Compare(p.Security.UnderlyingSymbol, underlying, StringComparison.OrdinalIgnoreCase) == 0 &&
                                  p.Security.SecurityType == SecurityType.EquityOption &&
                                  ((p.Security.OptionType == OptionType.Call && p.ActualSide == SideType.Long)
                                  ||
                                  (p.Security.OptionType == OptionType.Put && p.ActualSide == SideType.Short))
                              select new Tuple<string, IPosition>(FormatPositionInfo(p), p);
            return Sum(opPositions);
        }
        protected Tuple<string, decimal?> GetFirmWideOptionShortQuantity(string underlying)
        {
            var opPositions = from p in Positions
                              where String.Compare(p.Security.UnderlyingSymbol, underlying, StringComparison.OrdinalIgnoreCase) == 0 &&
                                  p.Security.SecurityType == SecurityType.EquityOption &&
                                  ((p.Security.OptionType == OptionType.Put && p.ActualSide == SideType.Long)
                                  ||
                                  (p.Security.OptionType == OptionType.Call && p.ActualSide == SideType.Short))
                              select new Tuple<string, IPosition>(FormatPositionInfo(p), p);
            return Sum(opPositions);
        }
        protected Tuple<string, decimal?> Sum(IEnumerable<Tuple<string, IPosition>> enumerable, bool isOption=true)
        {
            //get context
            var tuples = enumerable as Tuple<string, IPosition>[] ?? enumerable.ToArray();
            if (!tuples.Any()) return Tuple.Create(string.Empty, (decimal?)0m);
            var context = tuples.Aggregate((i, j) => new Tuple<string, IPosition>(i.Item1 + ',' + j.Item1, null)).Item1;
            var qty = tuples.Sum(p => Math.Abs(p.Item2.ActualQuantity) * (isOption?p.Item2.Security.ContractSize:1));
            return Tuple.Create<string, decimal?>(context, qty);
        }
        protected string FormatPositionInfo(IPosition position)
        {
            return $"{{\"AcuId\":\"{position.Portfolio.PMCode}\",\"BamSymbol\":\"{position.Security.BamSymbol}\",\"Qty\":{Math.Abs(position.ActualQuantity)},\"Side\":\"{position.ActualSide}\",\"SecurityType\":\"{position.Security.SecurityType}\",\"Optiontype\":\"{position.Security.OptionType}\"}}";
        }
        /// <summary>
        /// get all underling securities from the positions
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ISecurity> GetUnderlyingSecurities()
        {
            return Positions.Where(p=>((p.Security.BamSymbol== p.Security.UnderlyingSymbol 
                        && !(p.Security.InvestmentType=="Private" || p.Security.InvestmentType=="Restricted"))))
                        .GroupBy(p => p.Security.UnderlyingSymbol).Select(g => g.First().Security);
        }
        /// <summary>
        /// get shares outstanding by bamsymbol
        /// </summary>
        /// <param name="bamSymbol"></param>
        /// <returns></returns>
        public decimal? GetSharesOutstanding(string bamSymbol)
        {
            decimal? sharesOutstanding = MarketData.ContainsKey(bamSymbol) ? MarketData[bamSymbol].SharesOutstanding : null;
            return sharesOutstanding;
        }
        /// <summary>
        /// populate data from a json string which is generated from pomo svc
        /// </summary>
        /// <param name="jsonInput"></param>
        public void PopulatePomoData(string jsonInput)
        {
            dynamic pomodata = JsonConvert.DeserializeObject(jsonInput);
            RefreshTime = pomodata.RefreshTime;
            //pomo position linked by dw security id
            var pomoSecurities = new Dictionary<int, string>();
            foreach (var security in pomodata.Securities)
            {
                int securityId = security.SecurityId;
                string bamSymbol = security.DisplayCode;
               
                if (pomoSecurities.ContainsKey(securityId)) continue;
                //make sure displaycode is all in upcase
                pomoSecurities.Add(securityId, bamSymbol.ToUpper());
                var sharesoutstanding = security.MarketDataInfo.SharesOutstanding == null && security.MarketDataInfo.LastPrice != 0 ? (decimal?)security.MarketDataInfo.MarketCap / (decimal?)security.MarketDataInfo.LastPrice * 1000000 : security.MarketDataInfo.SharesOutstanding;
                var delta = security.MarketDataInfo.Delta;
                var marketData = new Data.Securities.MarketData() { BamSymbol = bamSymbol, SharesOutstanding = sharesoutstanding, Delta = delta};
                if (!MarketData.ContainsKey(bamSymbol)) { MarketData.Add(bamSymbol, marketData); }
            }
            foreach (var position in pomodata.Positions)
            {
                int securityId = position.SecurityId;
                if (!pomoSecurities.ContainsKey(securityId)) continue;
                var security = _dwSecurityProvider.GetSecurity(pomoSecurities[securityId]);
                if (security == null || security.SecurityType == SecurityType.Unknown) continue;
                decimal qty = position.Quantity;
                var side = qty > 0 ? SideType.Long : SideType.Short;
                var portfolio = new Portfolio() {PMCode = $"{position.AcuId}"};
                ((List<IPosition>) Positions).Add(item: new Position()
                {
                    LastModifiedOn = position.LastModified,
                    ActualQuantity = qty,
                    Security = (Security) security,
                    Portfolio = portfolio
                });
            }
        }
    }
}
