﻿using System.Collections.Generic;
using Bam.EventQ.Integration;
using Bam.EventQ.Pipeline.Dsl;
using Bam.EventQ.Sequencing;
using Bam.EventQ.Time;
using Bam.EventQ.Transport;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pipeline
{
    public static class PipelineDslExtensions
    {
        private static readonly Dictionary<ProcessingPipelineStepDsl<IMessage>, IQueueMessageDispatcher> Dispatchers
            = new Dictionary<ProcessingPipelineStepDsl<IMessage>, IQueueMessageDispatcher>();

        public static ProcessingPipelineStepDsl<IMessage> AddSequenceInfoAccessor(this ProcessingPipelineStepDsl<IMessage> dsl)
        {
            dsl.UseSequenceInfoAccessor(msg => msg.Buffer.Array.ToMessageHeader(msg.Buffer.Offset));
            return dsl;
        }

        public static ProcessingPipelineStepDsl<IMessage> AddQueueMessageDispatcher(this ProcessingPipelineStepDsl<IMessage> dsl, IQueueMessageDispatcher dispatcher)
        {
            Dispatchers[dsl] = dispatcher;
            return dsl;
        }

        public static IQueueMessageDispatcher GetQueueMessageDispatcher(this ProcessingPipelineStepDsl<IMessage> dsl)
        {
            return Dispatchers[dsl];
        }

        public static PipelineQueueItemHandlerChainDsl<IMessage> Serialize(
            this PipelineQueueItemHandlerChainDsl<IMessage> dsl, int sourceId, int bufferSize, 
            IMessageTopicProvider<IMessage> topicProvider, IClock clock)
        {
            dsl.AddHandler(new MessageSerializerHandler(sourceId, bufferSize, clock, topicProvider));
            return dsl;
        }

        public static PipelineQueueItemHandlerChainDsl<IMessage> Deserialize(
            this PipelineQueueItemHandlerChainDsl<IMessage> dsl)
        {
            dsl.AddHandler(new MessageDeserializerHandler());
            return dsl;
        }

        public static PipelineQueueItemHandlerChainDsl<IMessage> AsyncRpc<TIn>(
            this PipelineQueueItemHandlerChainDsl<IMessage> dsl,
            IAsyncMessageRpcClient<TIn> rpcClient, IQueueMessageDispatcher dispatcher,
            bool skipReplay = true) where TIn : class, IMessage
        {
            var handler = new AsyncRpcMessageHandler<TIn>(rpcClient, dispatcher, skipReplay);
            dsl.AddHandler(handler);
            dsl.Step.AddProducer(handler);
            return dsl;
        }
		
        public static ProcessingPipelineStepDsl<IMessage> AddExternalSource<TIn>(
            this ProcessingPipelineStepDsl<IMessage> dsl,
            IExternalMessageSource<TIn> source,
            IExternalMessageTransform<TIn, IMessage> transform)
        {
            dsl.AddProducer(new TransformingQueueItemProducer<TIn>(source, transform, dsl.GetQueueMessageDispatcher()));
            return dsl;
        }

        public static ProcessingPipelineStepDsl<IMessage> AddExternalSource(
            this ProcessingPipelineStepDsl<IMessage> dsl, IExternalMessageSource<IMessage> source)
        {
            dsl.AddProducer(new TransformingQueueItemProducer<IMessage>(source, 
                new NullMessageTransform<IMessage>(), dsl.GetQueueMessageDispatcher()));
            return dsl;
        }
    }
}
