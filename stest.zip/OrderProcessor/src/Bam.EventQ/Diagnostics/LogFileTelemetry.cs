﻿namespace Bam.EventQ.Diagnostics
{
    public class LogFileTelemetry : ITelemetry
    {
        private readonly ILogger _logger;

        public LogFileTelemetry(ILogger logger)
        {
            _logger = logger;
        }

        public void Record<T>(string key, T value)
        {
            _logger.LogInformation($"[Telemetry] {key}={value}");
        }
    }
}
