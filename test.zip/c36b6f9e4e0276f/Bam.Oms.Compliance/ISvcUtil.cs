﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Compliance
{
    public interface ISvcUtil
    {
        void ExportHeadRooms(IEnumerable<IRuleResult> ruleResults, string filename);
        void ExportHeadRoomsToCsv(IEnumerable<IRuleResult> ruleResults);
        void ExportSodReconToCsv(IEnumerable<IRuleResult> ruleResults);
        void EmailReport(IEnumerable<IRuleResult> ruleResults, PositionType type);
        void EmailEuShortReport(IEnumerable<IRuleResult> ruleResults, PositionType type);
        bool IsEod();
    }
}
