﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.Ioc;
using BAM.Common.Messaging;

namespace Bam.Oms.EndPoints.Database
{
    public class DBRollClient : IRollClient
    {
        private readonly ISettings _settings;
        private readonly ILogger _logger;
        private readonly IOrderDBRepository _orderDbRepository;
        private readonly IAllocationDBRepository _allocationDbRepository;
        private readonly IEodPositionRepository _eodPositionRepository;

        public DBRollClient(
            IOrderDBRepository orderDbRepository, IAllocationDBRepository allocationDbRepository, 
            IEodPositionRepository eodPositionRepository,
            ISettings settings, ILogger logger)
        {
            _settings = settings;
            _logger = logger;
            _allocationDbRepository = allocationDbRepository;
            _eodPositionRepository = eodPositionRepository;
            _orderDbRepository = orderDbRepository;
        }

        public void PublishOrders(IList<IOrder> orders)
        {
            //Saving PM Orders to DB
            _logger.Info($"Saving block orders to the database...");
            int savedOrderCount = _orderDbRepository.Save(orders).Count();
            _logger.Info($"Saved {savedOrderCount} block orders to the database.");
        }

        public void PublishPositions(IList<IPosition> positions, DateTime nextBusinessDay)
        {
            _logger.Info("Saving EOD positions to the database...");
            int count = _eodPositionRepository.Save(positions.ToList(), nextBusinessDay);
            _logger.Info($"Saved {count} EOD positions to the database...");
        }

        public void PublishTrades(IList<IBlockTrade> trades)
        {
            //Save Allocations to DB            
            _logger.Info($"Saving allocations to the database...");
            int savedTradeCount = _allocationDbRepository.Save(trades).Count();
            _logger.Info($"Saved {savedTradeCount} allocations to the database.");
        }

        public void PublishEzeOrders(IList<string> ezeOrders, string route)
        {
            //TODO: In place of contingency
        }

        public FlowClientScope Scope => FlowClientScope.Contingency;

        public void SubscribeEzeOrders() { }
        public event Action<Message<string>> ObjectUpdated;

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~DBFlowClient() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
