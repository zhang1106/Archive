﻿namespace Bam.EventQ.Lookup
{
    public interface IEventSource<TEvent>
    {
        IModelEventHandler<TEvent> EventHandler { get; set; }
    }
}