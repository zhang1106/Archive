﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence;
using Bam.Oms.Persistence.Journal;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Persistence.Trades;
using FluentAssertions;
using Moq;
using NUnit.Framework;
using Ploeh.AutoFixture;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class PersistentRepositoryTests
    {
        private ISecurityRepository _securityRepository;
        private ITradeRepository _tradeRepository;
        private IOrderRepository _orderRespository;
        private IClientOrderIdRepository _clientOrderIdRepository;
        private BRepository _bRepository;

        [TestFixtureSetUp]
        public void Initialize()
        {
            var journal = new Mock<IEventJournal>();
            journal.Setup(j => j.TruncateAsync()).Returns(Task.FromResult(0));
            journal.Setup(j => j.AppendAsync(It.IsAny<object>())).Returns(Task.FromResult(0));
            journal.Setup(j => j.RetrieveAsync()).Returns(Task.FromResult<IReadOnlyList<KeyValuePair<DateTime, object>>>(new KeyValuePair<DateTime, object>[] { }));

            var journalFactory = new Mock<IEventJournalFactory>();
            journalFactory.Setup(f => f.Create(It.IsAny<string>())).Returns(journal.Object);

            _securityRepository = new SecurityRepository(new Mock<ILogger>().Object, journalFactory.Object);
            _tradeRepository = new TradeRepository(new Mock<ILogger>().Object);
            _orderRespository = new OrderRepository(new Mock<ILogger>().Object, journalFactory.Object);
            _clientOrderIdRepository = new ClientOrderIdRepository(new Mock<ILogger>().Object, journalFactory.Object);            
            _bRepository = new BRepository("B", new Mock<ILogger>().Object);
        }

        [SetUp]
        public void Clear()
        {
            _securityRepository.ClearAll();
            _tradeRepository.ClearAll();
            _orderRespository.ClearAll();
            _clientOrderIdRepository.ResetOrderIdIndex();
        }

        [Test]
        [Category("Integration")]
        public void TestOrderInsertPerformance()
        {
            // arange
            var fixture = new Fixture();
            var sut = _orderRespository;
            var orders = new ConcurrentBag<Order>();
            Parallel.For(0, 1000, i => orders.Add(fixture.Create<Order>()));

            // act
            var sw = new Stopwatch();
            sw.Start();
            sut.Save(orders);
            sw.Stop();

            // assert
            var ordersPerSecond = orders.Count / sw.Elapsed.TotalSeconds;
            Console.Write($"{ordersPerSecond} order/s written");
            ordersPerSecond.Should().BeGreaterThan(10000);
        }

        [Test]
        public async Task TestClearWithCutoffDate()
        {
            // arrange
            var fixture = new Fixture();
            var sut = _securityRepository;
            var s1 = fixture.Create<Security>();
            var s2 = fixture.Create<Security>();

            sut.Save(s1); // <-- item before cutoff time
            await Task.Delay(TimeSpan.FromSeconds(1));

            DateTime cutoffDate = DateTime.UtcNow;
            await Task.Delay(TimeSpan.FromSeconds(1));

            sut.Save(s2); // <-- item after cutoff time            
            await Task.Delay(TimeSpan.FromSeconds(1));

            // act
            sut.Clear(cutoffDate);

            // assert
            var items = sut.Get(DateTime.MinValue);
            items.ShouldBeEquivalentTo(new[] { s2 }); // <-- only item after cutoff time
        }

        [Test]
        public void TestGetTradesByOrderId()
        {
            // arange
            var fixture = new Fixture();
            var sut = _tradeRepository;
            var t1 = fixture.Create<BlockTrade>();
            var t2 = fixture.Create<BlockTrade>();
            var t3 = fixture.Create<BlockTrade>();
            t1.ClientOrderId = t3.ClientOrderId;

            sut.Save(new[] { t1, t2, t3 });

            // act
            var actual = sut.GetByClientOrderId(t1.ClientOrderId);

            // assert
            var expected = new[] { t1, t3 };
            actual.ShouldAllBeEquivalentTo(expected);
        }

        [Test]
        public void TestRemoveTradeWithSharedClientOrderId()
        {
            // arange
            var fixture = new Fixture();
            var sut = _tradeRepository;
            var t1 = fixture.Create<BlockTrade>();
            var t2 = fixture.Create<BlockTrade>();
            var t3 = fixture.Create<BlockTrade>();
            t1.ClientOrderId = t3.ClientOrderId;

            sut.Save(new[] { t1, t2, t3 });
            sut.Remove(t3);

            // act
            var actual = sut.GetByClientOrderId(t1.ClientOrderId);

            // assert
            var expected = new[] { t1 };
            actual.ShouldAllBeEquivalentTo(expected);
        }

        [Test]
        public void TestGetAllTrades()
        {
            // arange
            var fixture = new Fixture();
            var sut = _tradeRepository;
            var t1 = fixture.Create<BlockTrade>();
            var t2 = fixture.Create<BlockTrade>();
            var t3 = fixture.Create<BlockTrade>();

            t1.Portfolio = t3.Portfolio;
            t1.Security = t3.Security;
            t1.Allocations[0].PrimeBroker = t3.Allocations[0].PrimeBroker;

            sut.Save(new[] { t1, t2, t3 });

            // act
            var actual = sut.GetAllTrades();

            // assert
            var expected = new Dictionary<IPositionKey, IList<IBlockTrade>>
            {
                [new PositionKey(t1.Portfolio, t1.Security)] = new List<IBlockTrade> { t1, t3 },
                [new PositionKey(t2.Portfolio, t2.Security)] = new List<IBlockTrade> { t2 }
            };
            actual.ShouldAllBeEquivalentTo(expected);
        }

        [Test]
        public void TestGetAllOrders()
        {
            // arange
            var fixture = new Fixture();
            var sut = _orderRespository;
            var o1 = fixture.Create<Order>();
            var o2 = fixture.Create<Order>();
            var o3 = fixture.Create<Order>();

            o1.Portfolio = o3.Portfolio;
            o1.Security = o3.Security;
            o1.Custodian = o3.Custodian;

            sut.Save(new[] { o1, o2, o3 });

            // act
            var actual = sut.GetAllOrders();

            // assert
            var expected = new Dictionary<IPositionKey, IList<IOrder>>
            {
                [new PositionKey(o1.Portfolio, o1.Security)] = new List<IOrder> { o1, o3 },
                [new PositionKey(o2.Portfolio, o2.Security)] = new List<IOrder> { o2 }
            };
            actual.ShouldAllBeEquivalentTo(expected);
        }

        [Test]
        public void TestFindOrderByPortfolioAndSecurity()
        {
            // arange
            var fixture = new Fixture();
            var sut = _orderRespository;
            var o1 = fixture.Create<Order>();
            var o2 = fixture.Create<Order>();
            var o3 = fixture.Create<Order>();

            sut.Save(new[] { o1, o2, o3 });

            // act
            var actual = sut.Find(o1.Portfolio, o1.Security);

            // assert
            var expected = new[] { o1 };
            actual.ShouldAllBeEquivalentTo(expected);
        }

        [Test]
        public void TestFindOrderByPortfolio()
        {
            // arange
            var fixture = new Fixture();
            var sut = _orderRespository;
            var o1 = fixture.Create<Order>();
            var o2 = fixture.Create<Order>();
            var o3 = fixture.Create<Order>();
            o3.Portfolio = o1.Portfolio;

            sut.Save(new[] { o1, o2, o3 });

            // act
            var actual = sut.Find(o1.Portfolio, null);

            // assert
            var expected = new[] { o1, o3 };
            actual.ShouldAllBeEquivalentTo(expected);
        }

        [Test]
        public async Task TestGetWithCutoffDate()
        {
            // arrange
            var fixture = new Fixture();
            var sut = _securityRepository;
            var s1 = fixture.Create<Security>();
            var s2 = fixture.Create<Security>();

            sut.Save(s1); // <-- item before cutoff time
            await Task.Delay(TimeSpan.FromSeconds(1));

            DateTime cutoffDate = DateTime.UtcNow;
            await Task.Delay(TimeSpan.FromSeconds(1));

            sut.Save(s2); // <-- item after cutoff time            
            await Task.Delay(TimeSpan.FromSeconds(1));

            // act
            var items = sut.Get(cutoffDate);

            // assert
            items.ShouldBeEquivalentTo(new[] { s2 }); // <-- only item after cutoff time
        }

        [Test]
        public void TestSecurityPutGet()
        {
            DateTime currentTime = DateTime.UtcNow;
            Security security = new Security() { BamSymbol = "IBM Equity" };
            Security savedSecurity = _securityRepository.Save(security);
            Assert.AreEqual(security, savedSecurity);

            IEnumerable<Security> securityList = _securityRepository.Get(currentTime);

            Assert.IsTrue(securityList.Any());
            Assert.IsTrue(securityList.ToList().Count == 1);
            Assert.AreEqual(security, securityList.First());
        }

        [Test]
        public void TestTradePutGet()
        {
            DateTime currentTime = DateTime.UtcNow;
            Portfolio portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            Security security = new Security() { BamSymbol = "IBM Equity" };
            BlockTrade blockTrade = new BlockTrade()
            {
                Portfolio = portfolio, Security = security, ClientOrderId = "ABCDEFGH", AveragePrice = 1.0m, TradedQuantity = 100.0m, Side = SideType.Buy, Status = "OPEN",
                TradeId = "ABCDEFGH" + "_" + "AMF" + "_" + "CSFB" + "_" + "123456"
            };
            BlockTrade savedBlockTrade = _tradeRepository.Save(blockTrade);
            Assert.AreEqual(blockTrade, savedBlockTrade);

            IEnumerable<BlockTrade> tradeList = _tradeRepository.Get(currentTime);

            Assert.IsTrue(tradeList.Any());
            Assert.IsTrue(tradeList.ToList().Count == 1);
            Assert.AreEqual(blockTrade, tradeList.First());
        }

        [Test]
        public void TestSecurityPutClear()
        {
            Security security = new Security() { BamSymbol = "IBM Equity" };
            Security savedSecurity = _securityRepository.Save(security);
            Thread.Sleep(10);
            Assert.AreEqual(security, savedSecurity);

            int count = _securityRepository.Clear(DateTime.UtcNow);
            Assert.AreEqual(1, count);
        }

        [Test]
        public void TestTradePutClear()
        {
            Portfolio portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            Security security = new Security() { BamSymbol = "IBM Equity" };
            BlockTrade blockTrade = new BlockTrade()
            {
                Portfolio = portfolio, Security = security, ClientOrderId = "ABCDEFGH", AveragePrice = 1.0m, TradedQuantity = 100.0m, Side = SideType.Buy, Status = "OPEN",
                TradeId = "ABCDEFGH" + "_" + "AMF" + "_" + "CSFB" + "_" + "123456"
            };
            BlockTrade savedBlockTrade = _tradeRepository.Save(blockTrade);
            Thread.Sleep(10);
            Assert.AreEqual(blockTrade, savedBlockTrade);

            int count = _tradeRepository.Clear(DateTime.UtcNow);
            Assert.AreEqual(1, count);
        }

        [Test]
        public void TestOrderPutGet()
        {
            // arrange
            var portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            var security = new Security() { BamSymbol = "IBM Equity" };
            var order = new Order()
            {
                ClientOrderId = "1234",
                Portfolio = portfolio,
                Security = security,
                StatusMessages = new List<string>() {(new ComplianceIssue() {Description = "desc", IssueType = "issuretype",RuleName = "rule"}).ToString()}
            };

            // act
            Order savedorder = _orderRespository.Save(order);
            var unit = _orderRespository.Get(DateTime.Today).ToList();

            // assert
            Assert.AreEqual(order, savedorder);
            Assert.That(unit[0].ClientOrderId, Is.EqualTo("1234"));
        }        

        [Test]
        public void TestOrderPutClear()
        {
            Security security = new Security() { BamSymbol = "IBM Equity" };
            var portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            var order = new Order() { ClientOrderId = "1234", Portfolio = portfolio, Security = security };
            Order savedOrder = _orderRespository.Save(order);
            Thread.Sleep(10);
            Assert.AreEqual(order, savedOrder);

            int count = _orderRespository.Clear(DateTime.UtcNow);
            Assert.AreEqual(1, count);
        }

        [Test]
        public void TestClientOrderGeneration()
        {
            // arrange
            _clientOrderIdRepository.ResetOrderIdIndex();
            var today = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
            string hostHash = Convert.ToString(Math.Abs(System.Environment.MachineName.GetHashCode()) % 100000, 16).ToUpper();


        // act
        var unit = _clientOrderIdRepository.GenerateOrderIds(2);

            // assert
            Assert.That(unit.Count, Is.EqualTo(2));
            Assert.That(unit[0], Is.EqualTo(today + hostHash + "0"));
            Assert.That(unit[1], Is.EqualTo(today + hostHash + "1"));
        }

        [Test]
        public void TestClientOrderIdVersion()
        {
            // arrange
            var orderId = "123";

            // act
            var unit = _clientOrderIdRepository.IncrementVersion(orderId);

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit, Is.EqualTo("123Z1"));
        }

        [Test]
        public void TestClientOrderIdMultipleVersion()
        {
            // arrange
            var orderId = "123";

            // act
            var orderId1 = _clientOrderIdRepository.IncrementVersion(orderId);
            var unit = _clientOrderIdRepository.IncrementVersion(orderId1);

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit, Is.EqualTo("123Z2"));
        }

        [Test]
        public void TestClientOrderReset()
        {
            // arrange
            _clientOrderIdRepository.ResetOrderIdIndex();
            var today = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
            string hostHash = Convert.ToString(Math.Abs(System.Environment.MachineName.GetHashCode()) % 100000, 16).ToUpper();

        // act
        _clientOrderIdRepository.GenerateOrderIds(10);
            var clear = _clientOrderIdRepository.ResetOrderIdIndex(0);
            var unit = _clientOrderIdRepository.GenerateOrderIds(1);

            // assert
            Assert.That(unit.Count, Is.EqualTo(1));
            Assert.That(unit[0], Is.EqualTo(today + hostHash + "0"));
            Assert.That(clear, Is.EqualTo(today + hostHash + "0"));
        }

        [Test]
        public void TestOrderPutFind()
        {
            // arrange
            var portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            var security = new Security() { BamSymbol = "IBM Equity" };
            var order = new Order()
            {
                ClientOrderId = "1234",
                Portfolio = portfolio,
                Security = security,
                StatusMessages = new List<string>() {(new ComplianceIssue() { Description = "desc", IssueType = "issuretype", RuleName = "rule" }).ToString() }
            };


            var portfolio1 = new Portfolio("MYPORT", "*", "MYSUB*Y");
            var security1 = new Security() { BamSymbol = "I?M Equity" };
            // act
            Order savedOrder = _orderRespository.Save(order);
            var unit = _orderRespository.Find(portfolio1, security1).ToList();

            // assert
            Assert.AreEqual(order, savedOrder);
            Assert.That(unit[0].ClientOrderId, Is.EqualTo("1234"));
        }

        [Test]
        public void TestTypeHierarchy()
        {
            // arrange
            var typeB = new B() {Ryan = "Rocks", Raj = "DoesNot", Key = "Key"};

            // act
            _bRepository.Save(typeB);
            var unit = _bRepository.Get("Key");

            // assert
            Assert.That(unit.Ryan, Is.EqualTo("Rocks"));
            Assert.That(unit.Raj, Is.EqualTo("DoesNot"));
        }

        [Test]
        public void TestTypeHierarchyWithUpCast()
        {
            // arrange
            var typeB = new B() { Ryan = "Rocks", Raj = "DoesNot", Key = "Key" };

            // act
            _bRepository.Save(typeB);
            var unit = _bRepository.Get("Key") as A;
            
            // assert
            Assert.That(unit, Is.Not.Null);
        }

        private class A : IPersistentItem
        {
            public string Key { get;set; }
            public string Ryan { get; set; }
        }

        private class B : A
        {
            public string Raj { get; set; }
        }

        private class BRepository : PersistentRepository<B>
        {
            public BRepository(string name, ILogger log)
                : base(name, log)
            {
            }
        }
    }
}
