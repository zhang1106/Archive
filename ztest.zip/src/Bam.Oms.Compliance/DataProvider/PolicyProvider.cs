﻿using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Compliance.Filters;

namespace Bam.Oms.Compliance.DataProvider
{
    public class PolicyProvider : IPolicyProvider 
    {
        IPolicyRepository<CompliancePosition> _policyRepository;
        IRuleRepository<CompliancePosition> _ruleRepository;
        IEnumerable<IPolicy<CompliancePosition>> _policies;
        public PolicyProvider(IPolicyRepository<CompliancePosition> policyRepository, IRuleRepository<CompliancePosition> ruleRepository)
        {
            _policyRepository = policyRepository;
            _ruleRepository = ruleRepository;
        }
        public void RefreshData()
        {
            _policies = _policyRepository.GetAll(); 
        }
        public IPolicy<CompliancePosition> Get(string name)
        {
            if (_policies == null)
            {
                RefreshData();
            }
            var policy = _policies.SingleOrDefault(r => string.Compare(r.Name, name, true) == 0);
            return policy;
        }
        //get all policies
        public IEnumerable<IPolicy<CompliancePosition>> Get(PolicyFilter filter)
        {
            var policies = _policyRepository.GetAll();
 
            return policies;
        }
    }
}
