﻿using System;
using Bam.Oms.Data.Securities;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Service.Security
{
    public class SecurityProcessor : ISecurityProcessor
    {
        private readonly IEmsRouter _emsRouter;
        private readonly ISecurityRepository _securityRepository;
        private readonly ISecurityMasterService _securityMasterService;
        private readonly ILogger _logger;

        public SecurityProcessor(IEmsRouter emsRouter, ISecurityMasterService securityMasterService, ISecurityRepository securityRepository, ILogger logger)
        {
            if (emsRouter == null) throw new ArgumentNullException(nameof(emsRouter));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (securityRepository == null) throw new ArgumentNullException(nameof(securityRepository));
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));

            _emsRouter = emsRouter;
            _securityRepository = securityRepository;
            _logger = logger;
            _securityMasterService = securityMasterService;
            _emsRouter.SecurityUpdated += SecuritySubscriptionHostOnSecurityUpdated;
        }

        private void SecuritySubscriptionHostOnSecurityUpdated(ISecurity security)
        {
            ((Data.Securities.Security)security).UnderlyingSymbol = _securityMasterService.ExtractUnderlying(security.SecurityType, security.BamSymbol);
            _securityRepository.Save((Bam.Oms.Data.Securities.Security)security);
        }

        public void Dispose()
        {
            _logger.Debug("Disposing security processor...");

            _emsRouter.SecurityUpdated -= SecuritySubscriptionHostOnSecurityUpdated;

            _logger.Debug("Disposed security processor...");
        }
    }
}