﻿using System;
using Bam.Oms.Persistence.Contingency;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Persistence.DBContext;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Persistence.Journal;
using Bam.Oms.Persistence.Serialization;
using ProtoBuf.Meta;

namespace Bam.Oms.Persistence
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
#if _BAM_WITH_LOGGING_INTERCEPTOR
            container.RegisterTypeWithLoggingInterfaceInterceptor<ISecurityRepository, SecurityRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<ITradeRepository, TradeRepository>(RegistrationType.Singleton, new InjectionConstructor("TradeCache", typeof(ILogger), typeof(ISettings)));
            container.RegisterTypeWithLoggingInterfaceInterceptor<IOrderRepository, OrderRepository>(RegistrationType.Singleton, new InjectionConstructor("OrderCache", typeof(ILogger), typeof(ISettings)));
            container.RegisterTypeWithLoggingInterfaceInterceptor<IClientOrderIdRepository, ClientOrderIdRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IContingencyDbRepository, ContingencyDbRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IAllocationDBRepository, AllocationDBRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IOrderDBRepository, OrderDBRepository>(RegistrationType.Singleton);            

            Container.Instance.RegisterType<IRuleResultRepository, RuleResultRepository>(RegistrationType.Singleton);
#else
            container.RegisterType<IEventJournalFactory, FlatFileEventJournalFactory>(RegistrationType.Singleton);
            container.RegisterType<ISerializer, ProtoBufSerializer>(RegistrationType.Singleton, new InjectionConstructor(new Action<RuntimeTypeModel>(m => { })));

            container.RegisterType<IEodPositionRepository, EodPositionRepository>(RegistrationType.Singleton);
            container.RegisterType<IPositionRepository, PositionRepository>(RegistrationType.Singleton);
            container.RegisterType<ISecurityRepository, SecurityRepository>(RegistrationType.Singleton);
            container.RegisterType<ITradeRepository, TradeRepository>(RegistrationType.Singleton);
            container.RegisterType<IOrderRepository, OrderRepository>(RegistrationType.Singleton);
            container.RegisterType<IClientOrderIdRepository, ClientOrderIdRepository>(RegistrationType.Singleton);
            container.RegisterType<IContingencyDbRepository, ContingencyDbRepository>(RegistrationType.Singleton);
            container.RegisterType<IAllocationDBRepository, AllocationDBRepository>(RegistrationType.Singleton);
            container.RegisterType<IOrderDBRepository, OrderDBRepository>(RegistrationType.Singleton);            

            Container.Instance.RegisterType<IRuleResultRepository, RuleResultRepository>(RegistrationType.Singleton);
#endif

            RegisterDBRepositories(container);
            RegisterDBContext(container);
        }

        private void RegisterDBContext(Container container)
        {
            container.RegisterType<SodPositionDBContext, SodPositionDBContext>(RegistrationType.Singleton);
        }

        private void RegisterDBRepositories(Container container)
        {
#if _BAM_WITH_LOGGING_INTERCEPTOR
            container.RegisterTypeWithLoggingInterfaceInterceptor<IPositionDBRepository, PositionDBRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IPositionAuditRepository, PositionAuditRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IPositionArchiveRepository, PositionArchiveRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IExceptionRepository, ExceptionRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IActionLogRepository, ActionLogRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IActionRepository, ActionRepository>(RegistrationType.Singleton);

            container.RegisterTypeWithLoggingInterfaceInterceptor<IFactRepository, FactRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<ISecurityDBRepository, SecurityDBRepository>(RegistrationType.Singleton);
#else
            container.RegisterType<IPositionDBRepository, PositionDBRepository>(RegistrationType.Singleton);
            container.RegisterType<IPositionAuditRepository, PositionAuditRepository>(RegistrationType.Singleton);
            container.RegisterType<IPositionArchiveRepository, PositionArchiveRepository>(RegistrationType.Singleton);
            container.RegisterType<IExceptionRepository, ExceptionRepository>(RegistrationType.Singleton);
            container.RegisterType<IActionLogRepository, ActionLogRepository>(RegistrationType.Singleton);
            container.RegisterType<IActionRepository, ActionRepository>(RegistrationType.Singleton);
            
            container.RegisterTypeWithLoggingInterfaceInterceptor<IFactRepository, FactRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<ISecurityDBRepository, SecurityDBRepository>(RegistrationType.Singleton);
#endif
        }
    }
}