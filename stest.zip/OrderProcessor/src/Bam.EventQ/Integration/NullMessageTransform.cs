﻿using System.Collections.Generic;

namespace Bam.EventQ.Integration
{
    public class NullMessageTransform<TItem> : IExternalMessageTransform<TItem, TItem>
    {
        public IEnumerable<TItem> Transform(TItem input)
        {
            yield return input;
        }
    }
}
