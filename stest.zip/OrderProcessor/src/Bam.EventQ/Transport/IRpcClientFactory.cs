﻿namespace Bam.EventQ.Transport
{
    public interface IRpcClientFactory
    {
        IRpcClient Create(int sourceId);
    }
}
