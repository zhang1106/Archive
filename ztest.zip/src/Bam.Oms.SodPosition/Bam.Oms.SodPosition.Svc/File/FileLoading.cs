﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using CsvHelper;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Collections.Specialized;
using BAM.Infrastructure.Ioc;
using System.Globalization;
using System.Transactions;
using Bam.Oms.Data.Positions;
using Bam.Oms.Persistence.DBContext;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.SodPosition.Svc.File
{
    public class FileLoading : IFileLoading
    {
        private readonly string _path;
        private readonly FileSystemWatcher _systemWatcher;
        private readonly ILogger _logger;
        private readonly SodPositionDBContext _sodPositionDBContext;
        private const string StringDateFormatter_yyyyMMdd = "yyyyMMdd";

        public FileLoading(string dirPath, ILogger logger, SodPositionDBContext sodPositionDBContext)
        {
            if (String.IsNullOrWhiteSpace(dirPath)) throw new ArgumentNullException("path");
            _path = dirPath;
            _logger = logger;
            _sodPositionDBContext = sodPositionDBContext;
            _systemWatcher = new FileSystemWatcher(_path);
            _systemWatcher.Created += OnFileCreated;
            _systemWatcher.Filter = "*.csv";
        }

        public virtual void Start()
        {
            _systemWatcher.EnableRaisingEvents = true;
        }

        public virtual event Action SodPositionLoaded;

        private void OnFileCreated(object sender, FileSystemEventArgs e)
        {
            Process(e.FullPath);
        }

        public virtual bool Process(string filePath)
        {
            try
            {
                //Wait for file to become readable
                WaitReady(filePath);
                var fName = Path.GetFileName(filePath);
                // Parse the file name to get the stream
                var stream = GetStream(fName);
                var entryDate = GetDate(fName);
                if (stream == null || entryDate == null)
                {
                    _logger.ErrorFormat($"'{fName}' is invalid, unable to extract stream and/or entry date from file name");
                    return false;
                }
                //parse positions from csv
                var positions = GetPositions(filePath).ToList();
                if (positions.Count == 0)
                {
                    // No records present
                    _logger.Warn("Couldn't find any records in the input file");
                    return false;
                }
                //preprocess, did not do much at this point?
                PreprocessPositions(positions, entryDate.Value, stream);
                //save position into database
                var loadPositions = LoadPositions(positions, stream);
                //archive file
                ArchiveFile(filePath);
                return loadPositions;
            }
            catch (Exception exception)
            {
                LogException(exception);
                return false;
            }
        }
        public string ArchiveFile(string filePath)
        {
            var historyPath = Path.Combine(_path, "history");
            if (!Directory.Exists(historyPath)) { Directory.CreateDirectory(historyPath);}
            var historyFileName = Path.Combine(historyPath, 
                               $"{Path.GetFileNameWithoutExtension(filePath)}_{DateTime.Now.Ticks}{Path.GetExtension(filePath)}");
            System.IO.File.Move(filePath, historyFileName);
            return historyFileName;
        }
        /// <summary>
        /// Logs a given exception by traversing through inner exceptions
        /// </summary>
        /// <param name="exception"></param>
        private void LogException(Exception exception)
        {
            // Log the exception
            string description = "File Loading Error: " + exception.Message;
            // If innerexception is present, append that information as well
            var innerException = exception.InnerException;
            int count = 5; //Don't go more than 5 level deep
            while (count-- != 0)
            {
                if (innerException != null)
                {
                    description += " InnerException: " + innerException.Message;
                    innerException = innerException.InnerException;
                }
                else
                {
                    break;
                }
            }
            //add error message to log file
            _logger.Error(description);
            //
            var dbException = new SodException { Source = "File Loading", Data = "SOD Position Load", Description = Utility.Truncate(description, 300), CreatedOn = DateTime.Now };
            _sodPositionDBContext.Exceptions.Save(dbException);
        }

        private bool LoadPositions(IList<Position> positions, string stream)
        {
            var actionName = stream + Constants.DAILY_LOADING_ACTION_NAME_SUFFIX;

            var action = _sodPositionDBContext.Actions.Get(new { Name = actionName, Type = Constants.BAM_ACTION_TYPE }).FirstOrDefault();
            if (action == null)
            {
                throw new Exception(
                    $"Couldn't find the action corresponding to name: {actionName} and type: {Constants.BAM_ACTION_TYPE}");
            }
            var actionLog = new SodActionLog
            {
                ActionId = action.ActionId,
                ActionDetails = $"{stream} SOD position loading",
                CreatedBy = Environment.UserName,
                CreatedOn = DateTime.Now
            };
            // Create action log
            actionLog = _sodPositionDBContext.ActionLogs.Save(actionLog);
            using (var tscope = new TransactionScope(TransactionScopeOption.Suppress, TimeSpan.FromMinutes(20)))
            {
                // Set action log id
                foreach (var pos in positions)
                {
                    pos.ActionLogId = actionLog.ActionLogId;
                }
                _sodPositionDBContext.PositionArchives.ArchivePositions(stream);
                _sodPositionDBContext.Positions.Save(positions);
                tscope.Complete();
            }
            SodPositionLoaded?.Invoke();
            return true;
        }

        private void PreprocessPositions(IList<Position> positions, DateTime entryDate, string stream)
        {
            DateTime now = DateTime.Now;
            foreach (var position in positions)
            {
                position.AuditSequence = 0;
                position.CreatedOn = now;
                position.EntryDate = entryDate;
                position.LastModifiedBy = Environment.UserName;
                position.LastModifiedOn = now;
                position.Stream = stream;
            }
        }

        private void WaitReady(string filePath, int retryCount = 10, int retryInterval = 500)
        {
            while (retryCount-- != 0)
            {
                try
                {
                    using (FileStream stream = System.IO.File.Open(filePath, FileMode.Open, FileAccess.Read))
                    {
                        return;
                    }
                }
                catch (Exception ex)
                {
                    _logger.Info($"File {filePath} not yet ready to read: {ex.Message}");
                }
                System.Threading.Thread.Sleep(retryInterval);
            }
        }

        private DateTime? GetDate(string fName)
        {
            var regex = new Regex("[0-9]{8}");
            var match = regex.Match(fName);
            if (match.Success)
            {
                string val = match.Value;
                var date = DateTime.ParseExact(val, StringDateFormatter_yyyyMMdd, CultureInfo.InvariantCulture);
                return date;
            }
            return null;
        }

        private string GetStream(string fileName)
        {
            var streamRegexMap = ConfigurationManager.GetSection("StreamRegexMap") as NameValueCollection;
            string selectedStream = null;
            foreach (var stream in streamRegexMap.Keys)
            {
                var regex = new Regex(streamRegexMap[(string)stream]);
                if (regex.IsMatch(fileName))
                {
                    if (selectedStream == null)
                    {
                        selectedStream = stream as string;
                    }
                    else
                    {
                        throw new Exception("The filename matches regex corresponding to multiple streams.");
                    }
                }
            }
            return selectedStream;
        }

        public IList<Position> GetPositions(string filePath)
        {
            using (var fStream = System.IO.File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var reader = new StreamReader(fStream))
            {
                var csvReader = new CsvReader(reader);
                csvReader.Configuration.RegisterClassMap(new PositionMap());
                csvReader.Configuration.WillThrowOnMissingField = false;
                csvReader.Configuration.HasHeaderRecord = true;
                csvReader.Configuration.IgnoreReadingExceptions = true;
                //add validation
                Dictionary<Tuple<string, string, string, string, string>, Position> mapped = new Dictionary<Tuple<string, string, string, string, string>, Position>();
                while (csvReader.Read())
                {
                    try
                    {
                        var p = csvReader.GetRecord<PositionRecord>();
                        //
                        if (string.IsNullOrEmpty(p.BAMSymbol) ||
                               string.IsNullOrEmpty(p.AssetType) ||
                               string.IsNullOrEmpty(p.CustodianName) ||
                               string.IsNullOrEmpty(p.StrategyCode) ||
                               string.IsNullOrEmpty(p.FundCode)
                               )
                        {
                            _logger.Error(csvReader.CurrentRecord.ToString() + "-" + p.ToString());
                            throw new InvalidDataException($"symbol, securitytype, custodian account or strategy cant be empty. - {p.ToString()}");
                        }
                        var key = Tuple.Create(p.FundCode, p.CustodianName, p.StrategyCode, p.AssetType, p.BAMSymbol);
                        if (mapped.ContainsKey(key))
                        {
                            _logger.Error($"Duplicated key - {key.ToString()}");
                            throw new InvalidDataException(
                                $"Duplicated key - {key.ToString()}");
                        }
                        mapped.Add(key, PositionRecordMap(p));
                    }
                    catch (Exception ex)
                    {
                        _logger.Error($"Invalid data error on {csvReader.CurrentRecord[0].ToString()} -{ex.Message}");
                        throw;
                    }
                }
                return mapped.Values.ToList();
             }
        }

        private static readonly Func<PositionRecord, Position> PositionRecordMap = positionRecord =>
        {
            bool success;
            var securityType = Data.Utility.TryConvertEnum<SecurityType>(positionRecord.AssetType, out success);
            if (!success)
            {
                securityType = SecurityType.Unknown;
            }
            return new Position
            {
                ActualQuantity = positionRecord.Qty,
                Cost = positionRecord.Cost,
                CustodianAccountCode = positionRecord.CustodianAccountCode,
                CustodianName = positionRecord.CustodianName,
                FundCode = positionRecord.FundCode,
                FXRate = positionRecord.FXRate,
                Portfolio = (Portfolio)Portfolio.Parse(positionRecord.StrategyCode),
                Price = positionRecord.Price,
                Security = new Security
                {
                    BamSymbol = positionRecord.BAMSymbol,
                    SecurityType = securityType,
                    Currency = positionRecord.Ccy
                },
                TheoreticalQuantity = positionRecord.Qty,
                ShortMarkingQuantity = positionRecord.Qty,
                LongMarkingQuantity = positionRecord.Qty
            };
        };
    }
}
