﻿using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Sequencing
{
    public interface IQueueMessageDispatcher
    {
        void Dispatch(IQueue<PipelineQueueItem<IMessage>> queue, IMessage message);
    }
}
