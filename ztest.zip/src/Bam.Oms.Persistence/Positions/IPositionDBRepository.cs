﻿using Bam.Oms.Data.Positions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Persistence.Positions
{
    public interface IPositionDBRepository : IDBRepository<Position>
    {
        // Any Position DB Repository related methods to go here.
        IList<Position> GetPositions(DateTime? asofdate, string stream, string fundCode, string custodianName, string strategyCode, string securityType, string bamSymbol);
    }
}
