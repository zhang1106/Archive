﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Transport;
using NetMQ;
using NetMQ.Sockets;

namespace Bam.EventQ.ZeroMQ
{
    public class ZeroMqRpcServer : IRpcServer, IDisposable
    {
        private readonly ResponseSocket _socket;
        private readonly IBackgroundWorker _rpcWorker;
        private readonly List<IRcpRequestHandler> _handlers;

        public ZeroMqRpcServer(string endpoint)
        {
            _socket = new ResponseSocket(endpoint);
            _handlers = new List<IRcpRequestHandler>();
            _rpcWorker = BackgroundWorkerFactory.Current.Create("RPC Server");
        }

        public ILogger Logger { get; set; }

        public void Start()
        {
            _rpcWorker.Start(ProcessMessages);
        }

        public void Stop()
        {
            _rpcWorker.Stop();
        }

        public void AddHandler(IRcpRequestHandler handler)
        {
            if (_rpcWorker.IsActive)
                throw new InvalidOperationException("Cannot add handler after RPC server was started.");

            _handlers.Add(handler);
        }

        public void Dispose()
        {
            Stop();
        }

        private void ProcessMessages(CancellationToken cancellationToken)
        {
            var emptyResponse = new byte[0];
            var timeout = TimeSpan.FromSeconds(1);
            while (!cancellationToken.IsCancellationRequested)
            {
                var request = new NetMQMessage(2);
                if (!_socket.TryReceiveMultipartMessage(timeout, ref request, 2))
                    continue;

                string inquiry = request[0].ConvertToString();
                byte[] payload = request[1].ToByteArray(true);

                byte[] response = emptyResponse;
                var handler = _handlers.FirstOrDefault(h => h.CanHandle(inquiry));
                if (handler != null)
                {
                    Logger?.LogInformation($"Processing RPC request '{inquiry}'");
                    response = handler.Invoke(inquiry, payload);
                }
                else
                {
                    Logger?.LogWarning($"No RPC handler defined for '{inquiry}'");
                }

                if (!_socket.TrySendFrame(timeout, response))
                    Logger?.LogWarning($"Unable to send response for inquiry '{inquiry}'");
            }
        }
    }
}
