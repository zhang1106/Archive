﻿using System;

namespace Bam.EventQ.Pooling
{
    public class NullObjectPool : IObjectPool
    {
        public T Get<T>()
        {
            return (T) Activator.CreateInstance(typeof(T));
        }

        public void Release(object instance)
        {
            
        }
    }
}
