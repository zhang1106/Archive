USE [OrderGatewayMain]
GO

/****** Object:  View [cov].[DefaultTradeCoverageAD]    Script Date: 11/10/2016 9:08:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [cov].[DefaultTradeCoverageAD] AS


SELECT	ccy.Currency, 
		t.Name Trader, 
		t.EzeId, 
		t.FlexId, 
		ISNULL(A.Login,'UND') ADLogin, 
		1 [Priority], 
		aa.id AssetTypeId

FROM  [cov].[DefaultTradeCoverage] C
INNER JOIN cov.Currency ccy ON ccy.RegionId = c.regionId
INNER JOIN cov.Trader t ON t.Id = c.traderid
LEFT JOIN cov.AssetType aa ON 1=1
LEFT JOIN [BOS-DB].[BossRef].[DBO].vu_ext_ADSUser A ON A.Name = t.Name



GO



CREATE VIEW [cov].[TraderActiveDirectoryLogin]
AS

SELECT DISTINCT t.id, t.EzeId, t.FlexId, a.Login ADLogin
FROM cov.Trader t 
LEFT JOIN [BOS-DB].[BossRef].[DBO].vu_ext_ADSUser A ON A.Name = t.Name



GO



CREATE VIEW [cov].[TraderCoverageByCurrencyAD]
AS

SELECT DISTINCT P.PortfolioName AS Portfolio, ccy.Currency, tc.AssetTypeId AssetType, a.Login AS ADLogin
FROM [cov].CoverageRule tc
INNER JOIN cov.Portfolio p ON p.Id = tc.PortfolioId
INNER JOIN cov.Trader t ON t.Id = tc.TradeId
INNER JOIN cov.Region r ON r.Id = tc.RegionId
INNER JOIN cov.Currency ccy ON ccy.RegionId = r.Id
LEFT JOIN [BOS-DB].[BossRef].[DBO].vu_ext_ADSUser A ON A.Name = t.Name



GO






go


DROP VIEW [cov].[TradeCoverage] 
go

CREATE VIEW [cov].[TradeCoverage] 
AS


SELECT 
		c.Id CoverageId,
		c.Priority,
		p.PortfolioName,
		t.EzeId,
		t.FlexId,
		Currency,
		RegionCode Region,
		AssetTypeId, 
		AssetType,
		mgr.ManagerCode,
		CASE WHEN t.Name = 'UNDEFINED' THEN -1 ELSE t.id END TradeId,
		ta.ADLogin,
		ds.Strategy DefaultStrategy
	  
FROM [cov].[CoverageRule] C
INNER JOIN cov.Portfolio p ON p.id = c.PortfolioId
INNER JOIN cov.Trader t ON t.Id = c.TradeId
INNER JOIN  cov.TraderActiveDirectoryLogin ta ON ta.id = t.Id
LEFT JOIN cov.AssetType a ON a.Id = c.AssetTypeId
LEFT JOIN cov.Region r ON r.id = c.RegionId
LEFT JOIN cov.Currency ccy ON ccy.RegionId = r.id AND ccy.id NOT IN (SELECT ccyId FROM [cov].[GetCurrenciesToExclude](c.PortfolioId,c.Priority,c.AssetTypeId))
LEFT JOIN cov.DefaultManagerCode mgr ON mgr.CoverageRuleId = c.Id
LEFT JOIN cov.DefaultStrategy ds ON ds.CoverageRuleId = c.id
WHERE  ccy.id IS NOT NULL 



UNION

SELECT 
		c.Id CoverageId,
		c.Priority,
		p.PortfolioName,
		t.EzeId,
		t.FlexId,
		Currency,
		RegionCode Region,
		AssetTypeId, 
		AssetType,
		mgr.ManagerCode,
		CASE WHEN t.Name = 'UNDEFINED' THEN -1 ELSE t.id END TradeId,
		ta.ADLogin,
		NULL DefaultStrategy
	  
FROM [cov].[CoverageRule] C
INNER JOIN cov.Portfolio p ON p.id = c.PortfolioId
INNER JOIN cov.Trader t ON t.Id = c.TradeId
INNER JOIN  cov.TraderActiveDirectoryLogin ta ON ta.id = t.Id
LEFT JOIN cov.AssetType a ON a.Id = c.AssetTypeId
LEFT JOIN cov.Currency ccy ON ccy.ID = c.CurrencyId AND ccy.id IN (SELECT ccyId FROM [cov].[GetCurrenciesToExclude](c.PortfolioId,c.Priority,c.AssetTypeId))
LEFT JOIN cov.Region r ON r.id = ccy.RegionId
LEFT JOIN cov.DefaultManagerCode mgr ON mgr.CoverageRuleId = c.Id
WHERE ccy.id IS NOT NULL 




GO

