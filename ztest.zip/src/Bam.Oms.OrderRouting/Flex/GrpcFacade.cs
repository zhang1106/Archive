﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.OrderRouting.Contracts;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Ft;
using Grpc.Core;

namespace Bam.Oms.OrderRouting.Flex
{
    public class GrpcFacade : IGrpcServices, IDisposable
    {
        private readonly ILogger _logger;
        private readonly ISettings _settings;
        private IGrpcChannel _channel;
        private UtilityService.IUtilityServiceClient _utilityServiceClient;
        private readonly ILoggingAgent _eventLogger;
        
        private readonly IStreamParser _streamParser;
        private CancellationTokenSource _tokenSource;
        private ManualResetEventSlim _resetEvent;

        public event Action<IEnumerable<IPosition>> PositionUpdated;
        public event Action<IEnumerable<IBlockTrade>> TradeUpdated;
        public event Action<IEnumerable<IOrder>> OrderStatusChanged;
        public event Action<ISecurity> SecurityChanged;
        public event Action<string> RollStarted;
        public event Action<string> RollCompleted;        

        public GrpcFacade(ILogger logger, IStreamParser streamParser, ISettings settings, ILoggingAgent eventLogger)
        {            
            if (logger == null) throw new ArgumentNullException(nameof(logger));            
            if (streamParser == null) throw new ArgumentNullException(nameof(streamParser));
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            if (eventLogger == null) throw new ArgumentNullException(nameof(eventLogger));

            _logger = logger;                        
            _streamParser = streamParser;
            _settings = settings;
            _eventLogger = eventLogger;

            GrpcEnvironment.SetLogger(new GrpcLogger(_logger));                        
        }

        public bool Connect()
        {
            try
            {
                //Connect to EMS
                _logger.Info($"Connecting to EMS at {_settings.FlexHost}:{_settings.FlexPort}.........");
                Channel channel = new Channel($"{_settings.FlexHost}:{_settings.FlexPort}", ChannelCredentials.Insecure);
                _channel = new GrpcChannel(channel);
                _utilityServiceClient = new UtilityService.UtilityServiceClient(channel);
                EnablePing();
                _logger.Info($"Successfully connected to EMS at {_settings.FlexHost}:{_settings.FlexPort}.");

                _logger.Info($"Subscribing for System Notification updates....");
                var systemNotificationServiceClient =
                    new SystemNotificationService.SystemNotificationServiceClient(channel);
                SystemSubscriptionHost = new SystemSubscriptionHost(systemNotificationServiceClient, _logger, _channel,
                    _settings, _eventLogger);
                SystemSubscriptionHost.RollCompleted += OnRollCompleted;
                SystemSubscriptionHost.RollStarted += OnRollStarted;                
                _logger.Info($"Successfully subscribed for System notifications.");

                OrderServiceClient = new OrderService.OrderServiceClient(_channel.Channel);
                return true;

            }
            catch (Exception ex)
            {
                _logger.Error($"Error connecting to EMS @ {_settings.FlexHost}:{_settings.FlexPort}.", ex);
                return false;
            }
        }       

        public bool Subscribe()
        { 
            try
            { 

            _logger.Info($"Subscribing for Security updates....");
                var securityServiceClient = new SecurityService.SecurityServiceClient(_channel.Channel);
                SecuritySubscriptionHost = new SecuritySubscriptionHost(securityServiceClient, _logger, _channel, _settings, _eventLogger );
                SecuritySubscriptionHost.SecurityUpdated += SecurityUpdated;
                _logger.Info($"Successfully subscribed for Security updates.");

                _logger.Info($"Subscribing for Order/Trade updates....");                
                TradeSubscriptionHost = new TradeSubscriptionHost(OrderServiceClient, _logger, _channel, _settings, _eventLogger);
                TradeSubscriptionHost.OrderStatusChanged += TradeSubscriptionHostOnOrderStatusChanged;
                TradeSubscriptionHost.TradeUpdated += TradeSubscriptionHostOnTradeUpdated;
                _logger.Info($"Successfully subscribed for Order/Trade updates.");

                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Error subscribing to EMS @ {_settings.FlexHost}:{_settings.FlexPort}.", ex);
                return false;
            }
        }

        public bool Unsubscribe()
        {
            try
            {
                if (TradeSubscriptionHost != null)
                {
                    _logger.Debug("Disposing trade subscription ...");
                    TradeSubscriptionHost.OrderStatusChanged -= TradeSubscriptionHostOnOrderStatusChanged;
                    TradeSubscriptionHost.TradeUpdated -= TradeSubscriptionHostOnTradeUpdated;
                    TradeSubscriptionHost?.DisposeSubscription();
                    OrderServiceClient = null;
                    TradeSubscriptionHost = null;
                    _logger.Debug("Disposed trade subscription.");
                }

                if (SecuritySubscriptionHost != null)
                {
                    _logger.Debug("Disposing security subscription ...");
                    SecuritySubscriptionHost.SecurityUpdated -= SecurityUpdated;
                    SecuritySubscriptionHost?.DisposeSubscription();
                    SecuritySubscriptionHost = null;
                    _logger.Debug("Disposed security subscription.");
                }
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Error while unsubscribing for Flex trade and security updates.", ex);
                return false;
            }
        }

        public void Stop()
        {
            try
            {
                if (TradeSubscriptionHost != null)
                {
                    _logger.Debug("Disposing trade subscription ...");
                    TradeSubscriptionHost.OrderStatusChanged -= TradeSubscriptionHostOnOrderStatusChanged;
                    TradeSubscriptionHost.TradeUpdated -= TradeSubscriptionHostOnTradeUpdated;
                    TradeSubscriptionHost?.DisposeSubscription();
                    OrderServiceClient = null;
                    TradeSubscriptionHost = null;
                    _logger.Debug("Disposed trade subscription.");
                }

                if (SecuritySubscriptionHost != null)
                {
                    _logger.Debug("Disposing security subscription ...");
                    SecuritySubscriptionHost.SecurityUpdated -= SecurityUpdated;
                    SecuritySubscriptionHost?.DisposeSubscription();
                    SecuritySubscriptionHost = null;
                    _logger.Debug("Disposed security subscription.");
                }

                if (SystemSubscriptionHost != null)
                {
                    _logger.Debug("Disposing system notification subscription ...");
                    SystemSubscriptionHost.RollCompleted -= OnRollCompleted;
                    SystemSubscriptionHost.RollStarted -= OnRollStarted;
                    SystemSubscriptionHost?.DisposeSubscription();
                    SystemSubscriptionHost = null;
                    _logger.Debug("Disposed system notification subscription.");
                }

                if (_utilityServiceClient != null)
                {
                    _logger.Debug("Disposing Ping task ...");
                    _tokenSource?.Cancel();
                    _resetEvent?.Set();
                    _utilityServiceClient = null;
                    _logger.Debug("Disposed Ping task ...");
                }

                if (_channel != null)
                {
                    _logger.Debug("Disposing grpc channel ...");
                    _channel.Dispose();
                    _channel = null;
                    _logger.Debug("Disposed grpc channel ...");
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Error while stopping GRPC services.", ex);
            }
        }

        private void OnRollStarted(string data)
        {            
            Utility.RaiseEvent(data, RollStarted);
        }

        private void OnRollCompleted(string data)
        {
            Utility.RaiseEvent(data, RollCompleted);            
        }

        private void SecurityUpdated(ISecurity security)
        {            
            Utility.RaiseEvent(security, SecurityChanged);
        }

        private void TradeSubscriptionHostOnTradeUpdated(IEnumerable<IBlockTrade> trades)
        {            
            Utility.RaiseEvent(trades, TradeUpdated);
        }

        private void TradeSubscriptionHostOnOrderStatusChanged(IEnumerable<IOrder> orders)
        {            
            Utility.RaiseEvent(orders, OrderStatusChanged);
        }       

        public void EnablePing()
        {
            _resetEvent = new ManualResetEventSlim(false);
            _tokenSource = new CancellationTokenSource();

            Task.Factory.StartNew(() =>
            {
                while (!_tokenSource.IsCancellationRequested)
                {
                    CheckChannelState();
                    _resetEvent.Wait(_settings.EMSPingInterval);
                }
            }, _tokenSource.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        private void CheckChannelState()
        {
            //here's where we can fix the state if need be
            try
            {
                _logger.Info("Pinging flex server... ");
                var pongStream = _utilityServiceClient.KeepAlive(new Ping());

                _streamParser.ParseStreamReturnFirst(pongStream);

                _logger.Info($"Pong: Channel state {_channel.ChannelState}");
            }
            catch (RpcException grpcEx)
            {
                //will this write out before we kill it?
                _logger.Fatal($"Received grpc exception during Ping, killing gateway {grpcEx.Message} {grpcEx.StackTrace}");
                Process.GetCurrentProcess().Kill();
            }


            //Detect connection losss - set a flag
            //Detect reconbnect   -= reset the flag and fire an event    
        }

        public OrderService.IOrderServiceClient OrderServiceClient { get; private set; }        

        public ISecuritySubscriptionHost SecuritySubscriptionHost { get; private set; }
        public ITradeSubscriptionHost TradeSubscriptionHost { get; private set; }

        public ISystemSubscriptionHost SystemSubscriptionHost { get; private set; }
        public void Dispose()
        {
            _logger.Debug("Disposing GrpcFacade ...");
            Stop();
            _logger.Debug("Disposed GrpcFacade.");

        }
    }
}