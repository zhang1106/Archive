﻿using System;
using System.Web.Http;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Compliance;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.EndPoints.Http;

namespace Bam.Oms.EndPoints.Compliance
{
    public class ComplianceController : BaseController
    {
        private readonly IFirmPositionComplianceSvc _complianceSvc;

        public ComplianceController(IFirmPositionComplianceSvc complianceSvc, 
            IHostConfiguration hostConfiguration, ILogger logger)
            : base(hostConfiguration, logger)
        {
            _complianceSvc = complianceSvc;
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Compliance.Write")]
        public string Run()
        {
            try
            {
                _complianceSvc.Run();
                return "done";
            }
            catch (Exception ex)
            {
                return ex.Message + ex.StackTrace + ex.InnerException.Message;
            }
        }
      
    }
}
