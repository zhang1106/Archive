﻿using System.Linq;
using System.Net;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Integration;
using Microsoft.AspNet.SignalR.Client;

namespace Bam.EventQ.SignalR
{
    public class SignalRExternalMessageSource<TMsg> : ExternalMessageSourceBase<TMsg[]>
    {
        private readonly HubConnection _hub;
        private readonly IHubProxy<ISignalRHub, ISignalRClient<SignalRPacket<TMsg>>> _proxy;
        private readonly ManualResetEventSlim _exitEvent;
        private readonly object _syncRoot = new object();
        private IBackgroundWorker _reconnectWorker;

        public SignalRExternalMessageSource(string host, int port, string hubName)
        {
            _hub = new HubConnection($"http://{host}:{port}") { Credentials = CredentialCache.DefaultCredentials };
            _hub.EnsureReconnecting();
            _proxy = _hub.CreateHubProxy<ISignalRHub, ISignalRClient<SignalRPacket<TMsg>>>(hubName);
            _exitEvent = new ManualResetEventSlim();
            _hub.StateChanged += OnHubStateChanged;
        }

        public ILogger Logger { get; set; }

        private void OnHubStateChanged(StateChange obj)
        {
            Logger?.LogInformation($"Hub connection state changing for {_hub.Url} to {obj.NewState}");
            if (obj.NewState == ConnectionState.Disconnected)
            {
                lock (_syncRoot)
                {
                    if (_exitEvent.IsSet)
                        return;

                    if (!(_reconnectWorker?.IsActive ?? false))
                    {
                        _reconnectWorker = BackgroundWorkerFactory.Current.Create($"Reconnect to {_hub.Url}");
                        _reconnectWorker.Start(Reconnect);
                    }
                }
            }
        }
        
        public override void Start()
        {
            base.Start();
            lock (_syncRoot)
            {
                _reconnectWorker = BackgroundWorkerFactory.Current.Create($"Reconnect to {_hub.Url}");
                _reconnectWorker.Start(Reconnect);
            }
        }

        public override void Stop()
        {
            _hub.StateChanged -= OnHubStateChanged;
            _exitEvent.Set();
            lock (_syncRoot)
            {
                _reconnectWorker?.Dispose();
            }
            _proxy.Dispose();
            _hub.Dispose();
            base.Stop();
        }

        private void OnPacket(SignalRPacket<TMsg> packet)
        {
            if (_exitEvent.IsSet)
                return;

            Handler?.Invoke(packet.Data.ToArray());
        }
        
        private void Reconnect(CancellationToken cancellationToken)
        {
            while (!cancellationToken.WaitHandle.WaitOne(1000))
            {
                if (_hub.State == ConnectionState.Disconnected)
                {
                    _hub.Start().ConfigureAwait(false).GetAwaiter().GetResult();
                }

                if (_hub.State != ConnectionState.Disconnected)
                {
                    _proxy.SubscribeOn<SignalRPacket<TMsg>>(m => m.ReceiveMessage, OnPacket);
                    break;
                }
            }
        }
    }
}
