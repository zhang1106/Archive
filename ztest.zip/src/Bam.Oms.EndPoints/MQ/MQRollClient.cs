﻿using Bam.Oms.Data.Configuration;
using BAM.Common.Messaging;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.MQ
{
    public class MQRollClient : MQFlowClient, IRollClient
    {
        public MQRollClient(IConnection mqConnection, string tradeTopic, string orderTopic, string positionTopic, ISettings settings, ILogger logger) 
            : base(mqConnection, tradeTopic, orderTopic, positionTopic, null, settings, logger)
        {            
        }
    }
}
