﻿using System;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;

namespace Bam.Oms.Data.Portfolios
{
    /// <summary>
    ///     Composite key that uniquely identifies a Portfolio
    /// </summary>
    [DataContract]
    public class Portfolio : IPortfolio
    {
        public Portfolio(string pmCode, string strategy = null, string subStrategy = null)
        {
            PMCode = pmCode;
            Strategy = strategy;
            SubStrategy = subStrategy;

            //TODO: Populate from reference data. Set defaults temporarily
            AggregationUnit = "AQTF";
            ComplianceGroup = PMCode;
        }        

        public Portfolio()
        {
        }

        [DataMember(Order = 1)]
        public string PMCode { get; set; }

        [DataMember(Order = 2)]
        public string Strategy { get; set; }

        [DataMember(Order = 3)]
        public string SubStrategy { get; set; }

        [DataMember(Order = 4)]
        public string AggregationUnit { get; set; }

        [DataMember(Order = 5)]
        public string ComplianceGroup { get; set; }

        public bool IsMatch(IPortfolio portfolio)
        {
            return PMCode.Equals(portfolio.PMCode)
                   &&
                   (string.IsNullOrEmpty(portfolio.Strategy) ||
                    Regex.IsMatch(Strategy, Utility.WildcardToRegex(portfolio.Strategy)))
                   &&
                   (string.IsNullOrEmpty(portfolio.SubStrategy) ||
                    Regex.IsMatch(SubStrategy, Utility.WildcardToRegex(portfolio.SubStrategy)));
        }

        public string Key
        {
            get { return ToString(); }
        }        

        public override string ToString()
        {
            return !string.IsNullOrEmpty(Strategy)
                ? (!string.IsNullOrEmpty(SubStrategy)
                    ? $"{PMCode}-{Strategy}-{SubStrategy}"
                    : $"{PMCode}-{Strategy}")
                : PMCode;
        }

        public int CompareTo(Object obj)
        {
            if (obj == this)
                return 0;

            var other = obj as IPortfolio;
            if (this.Equals(obj)) return 0;
            if (other == null)
                return -1;

            //using isMatch to make sure third level stragety is ignored
            return this.IsMatch(other) ? 0 : string.Compare(Key, other.Key, StringComparison.CurrentCultureIgnoreCase);
        }

        public int CompareTo(IPortfolio other)
        {
            
            if (this.Equals(other)) return 0;
            if (other == null)
                return -1;

            return this.IsMatch(other) ? 0 : string.Compare(this.Key, other.Key, StringComparison.CurrentCultureIgnoreCase);
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;

            var other = obj as IPortfolio;
            if (other == null)
                return false;

            return !string.IsNullOrEmpty(Strategy)
                ? (!string.IsNullOrEmpty(SubStrategy)
                    ? PMCode.Equals(other.PMCode, StringComparison.CurrentCultureIgnoreCase)
                      && Strategy.Equals(other.Strategy, StringComparison.CurrentCultureIgnoreCase)
                      && SubStrategy.Equals(other.SubStrategy, StringComparison.CurrentCultureIgnoreCase)
                    : PMCode.Equals(other.PMCode, StringComparison.CurrentCultureIgnoreCase)
                      && Strategy.Equals(other.Strategy, StringComparison.CurrentCultureIgnoreCase))
                : PMCode.Equals(other.PMCode, StringComparison.CurrentCultureIgnoreCase);
        }

        public override int GetHashCode()
        {
            return !string.IsNullOrEmpty(Strategy)
                ? (!string.IsNullOrEmpty(SubStrategy)
                    ? unchecked(PMCode.GetHashCode() * Strategy.GetHashCode() * SubStrategy.GetHashCode())
                    : unchecked(PMCode.GetHashCode() * Strategy.GetHashCode()))
                : PMCode.GetHashCode();
        }

        public static IPortfolio Parse(string portfolioString)
        {
            if (string.IsNullOrEmpty(portfolioString))
                return null;

            var portfolioParts = portfolioString.Split('-');
            string strategy = null;
            var pmCode = portfolioParts[0];
            if (portfolioParts.Length > 1)
            {
                strategy = portfolioParts[1];
            }

            string subStrategy = null;
            if (portfolioParts.Length > 2)
            {
                subStrategy = portfolioParts[2];
            }

            return new Portfolio(pmCode, strategy, subStrategy);
        }
    }
}