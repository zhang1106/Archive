﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.RefData;
using Bam.Oms.RefData.OMS;
using Bam.Oms.ReferenceDataGateway.Api.Model;
using BAM.Infrastructure.Ioc;
using FluentDateTime;
using Microsoft.Practices.ObjectBuilder2;
using AssetType = Bam.Oms.ReferenceDataGateway.Api.Model.AssetType;
using Portfolio = Bam.Oms.Data.Portfolios.Portfolio;
using Security = Bam.Oms.Data.Securities.Security;
using SecurityType = Bam.Oms.Data.Enumerators.SecurityType;

namespace Bam.Oms.EndPoints.Orders
{
    public class OrderPrepUtility : IOrderPrepUtility
    {
        private readonly IClientOrderIdRepository _clientOrderIdRepository;
        private readonly ILogger _logger;
        private readonly ISettings _settings;
        private readonly ISecurityMasterService _securityMasterService;
        private readonly IAccountService _accountService;
        private readonly ReferenceDataGateway.Api.Http.ICoverageController _coverageService;

        public OrderPrepUtility(IClientOrderIdRepository clientOrderIdRepository, ILogger logger, ISettings settings, ISecurityMasterService securityMasterService, IAccountService accountService, ReferenceDataGateway.Api.Http.ICoverageController coverageService)
        {
            if (clientOrderIdRepository == null) throw new ArgumentNullException(nameof(clientOrderIdRepository));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));
            if (coverageService == null) throw new ArgumentNullException(nameof(coverageService));

            _clientOrderIdRepository = clientOrderIdRepository;
            _logger = logger;
            _settings = settings;
            _securityMasterService = securityMasterService;
            _accountService = accountService;
            _coverageService = coverageService;
        }

        public IOrder CreateSwapOrder(IOrder equityOrder, string broker)
        {
            if (equityOrder == null ||
                !(equityOrder.Security.SecurityType == SecurityType.Equity || equityOrder.Security.SecurityType == SecurityType.EquitySwap) ||
                (equityOrder.OrderStatus != BamOrderStatus.PendingSend && equityOrder.OrderStatus != BamOrderStatus.Error))
            {
                return null;
            }

            broker = broker ?? equityOrder.Custodian;

            var security = _securityMasterService
                .GetSwapSecurity(equityOrder.Security.UnderlyingSymbol?? equityOrder.Security.BamSymbol, broker);
            if (security == null)
                return null;

            var order = CloneOrder(equityOrder);
            order.Security = (Security) security;
            order.Custodian = broker;
            return order;
        }

        public IList<string> AssignOrderIds(IEnumerable<IOrder> orders)
        {
            var orderIds = _clientOrderIdRepository.GenerateOrderIds(orders.Count());

            _logger.Info($"Batched {orderIds.Count} order id(s)");

            var i = 0;
            foreach (var order in orders)
            {
                order.ClientOrderId = orderIds[i];
                _logger.Info($"Generated order id {orderIds[i]} - {order}");
                i++;
            }

            return orderIds;
        }

        public void SetTradeDate(IEnumerable<IOrder> orders, DateTime now = default(DateTime)) //not a huge fan of passing this in, but for test coverage
        {
            //TODO: incorporate holiday calendars 
            if (now.Equals(default(DateTime)))
                now = DateTime.Now.ToLocalTime();
            
            var tradeDate = now.TimeOfDay.CompareTo(_settings.SODDateTime.TimeOfDay) >= 0 ? now.AddDays(1) : now;

            tradeDate = (tradeDate.DayOfWeek == DayOfWeek.Sunday ? tradeDate.AddDays(1) :
                tradeDate.DayOfWeek == DayOfWeek.Saturday ? tradeDate.AddDays(2) :
                    tradeDate).Date;

            foreach (var order in orders)
            {
                if (order.TradeDate == DateTime.MinValue)
                {
                    order.TradeDate = tradeDate;
                }

                if (order.SettleDate == DateTime.MinValue)
                {
                    //TODO: Adjust by stream.
                    order.SettleDate = tradeDate.AddBusinessDays(3); //T+3 settlememt
                }
            }
        }

        public void SetSecurityInformation(IEnumerable<IOrder> orders)
        {
            var tickerList = orders.Select(r => r.Security.BamSymbol).Distinct().ToList();
            var securities  = _securityMasterService.GetSecurities(tickerList);

            foreach (var order in orders)
            {
                var security = securities.FirstOrDefault(r => r.BamSymbol.Equals(order.Security.BamSymbol, StringComparison.CurrentCultureIgnoreCase));
                if (security != null) // prob should throw here
                {
                    order.Security = security as Security;
                    order.TradeCurrency = security.TradingCurrency;
                    order.SettlementCurrency = security.SettlementCurrency;
                }
                else
                    _logger.Warn($"Unable to find security for symbol {order.Security.BamSymbol}");
            }
        }

        public void SetTrader(IEnumerable<IOrder> orders, string entryUser = null)
        {
            TraderLogin traderLogin = null;

            if (entryUser != null)
                traderLogin = _coverageService.GetTraderLogin(entryUser);

            foreach (var order in orders)
            {
                //if the trader id is in this list, they the entering user is a trader, and we dont want to use the default coverage
                if (traderLogin != null)
                {
                    order.TraderLogin = traderLogin.ADLogin;
                    order.TraderId = traderLogin.Id;
                    _logger.Info($"Using overide trader {order.Trader} for order id {order.ClientOrderId}");
                    continue;
                }

                _logger.Info($"Using standard coverage for order id {order.ClientOrderId}");

                var assetType = GetAssetType(order.Security.SecurityType);

                if (assetType == null)
                {
                    _logger.Error($"Security type not supported for trader coverage for order {order.ClientOrderId} sec type {order.Security.SecurityType}");
                    order.StatusMessages.Add("Unable to find coverage");
                    order.OrderStatus = BamOrderStatus.Error;
                    continue;
                }

                var coverage = _coverageService.GetTraderCoverage(order.Portfolio.ToString(), order.Security.Currency, assetType.Value);

                if (coverage != null)
                {
                    order.TraderId = coverage.TradeId;
                    order.TraderLogin = coverage.ADLogin;
                }
                else
                {
                    //there really should never be a null coverage
                    _logger.Error($"Unable to find coverage for order id {order.ClientOrderId}");
                    order.StatusMessages.Add("Unable to find coverage");
                    order.OrderStatus = BamOrderStatus.Error;
                }
            }
        }     

        public string CreateBatchId(string pmCode, DateTime dt)
        {
            return $"{pmCode}-{dt.ToString("yyyyMMdd-HHmmssffff")}";
        }

        public void SetOrderStatus(IEnumerable<IOrder> orders)
        {
            orders.Where(r=>r.OrderStatus != BamOrderStatus.Error).ForEach(o => o.OrderStatus = BamOrderStatus.PendingValidation);
        }

        private AssetType? GetAssetType(SecurityType securityType)
        {
            switch (securityType)
            {
                case SecurityType.Equity:
                case SecurityType.EquitySwap:
                    return AssetType.Equity;
                case SecurityType.EquityOption:
                    return AssetType.Option;
            }

            _logger.Error($"Unsupported asset type {securityType} for coverage");
            return null;
        }

        public IEnumerable<IOrder> ScaleOrders(IEnumerable<IOrder> orders)
        {
            IList<IOrder> scaledOrders = new List<IOrder>();
            foreach (IOrder order in orders)
            {
                IList<OrderScale> scaleFactors =_accountService.GetScaleFactor(order.Portfolio, order.Security.SecurityType);
                if (scaleFactors != null && scaleFactors.Any())
                {
                    string nextOrderId = order.ClientOrderId;
                    foreach (OrderScale orderScale in scaleFactors)
                    {                        
                        //Preserving the batch-id for now
                        IOrder clonedOrder = (IOrder) order.Clone();
                        clonedOrder.Portfolio = (Portfolio) Portfolio.Parse(orderScale.DestinationPortfolio);
                        clonedOrder.ClientOrderId = _clientOrderIdRepository.IncrementVersion(nextOrderId);
                        clonedOrder.Size = Math.Truncate(order.Size*orderScale.ScaleFactor); //Discard the decimal portion. (round down)
                        clonedOrder.Allocations.Clear();
                        scaledOrders.Add(clonedOrder);
                        nextOrderId = clonedOrder.ClientOrderId;
                    }                    
                    scaledOrders.ForEach(so => so.Trader = order.Trader);
                }
            }
            if (scaledOrders.Any())
            {
                scaledOrders = _accountService.SetAccountAttributes(scaledOrders).Cast<IOrder>().ToList();
                return orders.Union(scaledOrders);
            }
            return orders;
        }

        public void SetCustodian(IEnumerable<IOrder> orders)
        {
            foreach (var order in orders)
            {
                if (string.IsNullOrEmpty(order.Custodian))
                {
                    _logger.Info($"[OrderId:{order.ClientOrderId}] Custodian not set, looking up default for {order.Portfolio}");
                    _accountService.SetCustodian(order);
                }
            }
        }

        public IOrder CloneOrder(IOrder order)
        {
            return new Order
            {
                Portfolio = order.Portfolio,
                Security = order.Security,
                BatchId = order.BatchId,
                ExecutionInstructions = order.ExecutionInstructions.ToList(),
                ExternalId = order.ExternalId,
                Note = order.Note,
                Side = order.Side,
                Size = order.Size,
                TradeDate = order.TradeDate,
                Urgency = order.Urgency,
                Price = order.Price,
                Custodian = order.Custodian,
            };
        }

        public void SetCreatedUser(IEnumerable<IOrder> orders, string user = "UND")
        {
            foreach (var order in orders)
            {
                order.CreatedUser = user;
                _logger.Info($"[OrderId:{order.ClientOrderId}] Setting created user to {user}");
            }
        }
    }
}