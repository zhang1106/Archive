﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using BAM.Infrastructure.Ioc;
using System.Collections.Generic;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.Persistence.Trades
{
    public class TradeRepository : PersistentRepository<BlockTrade>, ITradeRepository
    {
        private readonly ConcurrentDictionary<string, HashSet<string>> _byOrderIdLookup =
            new ConcurrentDictionary<string, HashSet<string>>();

        public TradeRepository(ILogger log) : base("TradeCache", log)
        {
        }
        
        public IEnumerable<BlockTrade> GetByClientOrderId(string orderId)
        {
            HashSet<string> item;
            if (_byOrderIdLookup.TryGetValue(orderId, out item))
            {
                var result = new List<BlockTrade>(item.Count);
                foreach (var key in item)
                {
                    result.Add(Get(key));
                }

                return result;
            }

            return Enumerable.Empty<BlockTrade>();
        }

        public override IEnumerable<BlockTrade> Save(IEnumerable<BlockTrade> items)
        {
            var saved = base.Save(items);
            foreach (var trade in saved)
            {
                _byOrderIdLookup.AddOrUpdate(
                    trade.ClientOrderId,
                    key => new HashSet<string> {trade.Key},
                    (key, old) =>
                    {
                        old.Add(trade.Key);
                        return old;
                    });
            }

            return saved;
        }

        public override IEnumerable<BlockTrade> Remove(IEnumerable<BlockTrade> items)
        {
            var removed = base.Remove(items);
            foreach (var trade in removed)
            {
                HashSet<string> item;
                if (_byOrderIdLookup.TryGetValue(trade.ClientOrderId, out item))
                {
                    item.Remove(trade.Key);
                }
            }

            return removed;
        }

        public override int ClearAll()
        {
            _byOrderIdLookup.Clear();
            return base.ClearAll();
        }

        public override int Clear(DateTime cutOffTimeUtc)
        {
            var toRemove = GetAll().Except(Get(cutOffTimeUtc)).ToList();
            foreach (var item in toRemove)
            {
                HashSet<string> trades;
                if (_byOrderIdLookup.TryGetValue(item.ClientOrderId, out trades))
                {
                    trades.Remove(item.Key);
                }
            }

            return base.Clear(cutOffTimeUtc);
        }

        public IDictionary<IPositionKey, IList<IBlockTrade>> GetAllTrades(Func<IBlockTrade, bool> predicate = null)
        {
            predicate = predicate ?? (t => true);

            IDictionary<IPositionKey, IList<IBlockTrade>> trades =
                new Dictionary<IPositionKey, IList<IBlockTrade>>();
            foreach (IBlockTrade trade in GetAll())
            {
                if (predicate(trade))
                {
                    IPositionKey positionKey = new PositionKey(trade.Portfolio, trade.Security);
                    IList<IBlockTrade> tradesList;
                    if (trades.TryGetValue(positionKey, out tradesList))
                    {
                        tradesList.Add(trade);
                    }
                    else
                    {
                        tradesList = new List<IBlockTrade>()
                        {
                            trade
                        };
                        trades[positionKey] = tradesList;
                    }
                }
            }
            return trades;
        }
    }
}
