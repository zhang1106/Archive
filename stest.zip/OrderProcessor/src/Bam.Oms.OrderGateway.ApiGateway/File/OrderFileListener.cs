﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Hosting;
using Bam.EventQ.Time;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using CsvHelper;

namespace Bam.Oms.OrderGateway.ApiGateway.File
{
    public class OrderFileListener : FileListener, IService
    {
        private readonly IOrderSubmission _orderSubmission;
        private readonly HashSet<string> _existingMappedColumns;
        private readonly OrderMapping _mapping;

        public OrderFileListener(IClock clock, IOrderSubmission orderSubmission, string watchPath, string archivePath, string errorPath)
            : base(clock, watchPath, archivePath, errorPath)
        {
            _orderSubmission = orderSubmission;
            _mapping = new OrderMapping();

            var names = _mapping.PropertyMaps.Select(r => r.Data).SelectMany(r => r.Names.Names);
            _existingMappedColumns = new HashSet<string>(names) {"TAlpha2"};
        }

        protected override void ProcessFile(string path, string entryUser)
        {
            var orders = ReadFile(path, entryUser);
            if (orders.Items.Any())
            {
                _orderSubmission.Submit(orders);
            }
            else
            {
                throw new Exception($"Received file with no records. File = '{path}'");
            }
        }

        private SubmitOrders ReadFile(string path, string entryUser)
        {
            var submission = new SubmitOrders
            {
                User = entryUser,
                SubmissionMethod = SubmissionMethod.File
            };

            using (var reader = new CsvReader(System.IO.File.OpenText(path)))
            {
                reader.Configuration.RegisterClassMap(_mapping);
                
                if (reader.ReadHeader() && reader.FieldHeaders.Contains("Strategy") && reader.FieldHeaders.Contains("TAlpha2"))
                {
                    throw new Exception("Order file cannot have both 'Strategy' and 'TAlpha2' columns.");
                }

                while (reader.Read())
                {
                    var order = reader.GetRecord<SubmitOrders.SubmitOrderLineItem>();

                    for (var i = 0; i < reader.FieldHeaders.Length; i++)
                    {
                        string field;
                        if (!_existingMappedColumns.Contains(reader.FieldHeaders[i]) &&
                            reader.TryGetField(i, out field) &&
                            !string.IsNullOrEmpty(field))
                        {
                            var header = reader.FieldHeaders[i].Trim();
                            order.ExecutionInstructions[header] = field.Trim();
                        }
                    }
                    submission.Items.Add(order);
                }
            }

            if (submission.Items.Count > 0)
            {
                var first = submission.Items.First();
                var portfolio = Portfolio.Parse(first.Portfolio);
                submission.BatchName = $"{portfolio.PMCode}-{Clock.Now:yyyyMMdd-HHmmssffff}";
            }

            return submission;
        }
    }
}
