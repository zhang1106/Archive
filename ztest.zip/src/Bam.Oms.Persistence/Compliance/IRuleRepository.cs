﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Persistence.Compliance
{
    public interface IRuleRepository<T> : IDBRepository<Rule<T>>
    {
        IEnumerable<Rule<T>> GetRules(int policyId);
    }
}
