﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;

namespace Bam.EventQ.Workflow
{
    public class EventAggregator<TItem> : IEventSource<TItem>
    {
        private const int MaximumPoolSize = 256;
        private static readonly LinkedList<EventListener> Pool = new LinkedList<EventListener>();

        private readonly LinkedList<EventListener> _used = new LinkedList<EventListener>();
        private IModelEventHandler<TItem> _eventHandler;

        public virtual IDisposable Attach(IEventSource<TItem> model)
        {
            EventListener listener;

            if (Pool.Count == 0)
            {
                listener = new EventListener();
            }
            else
            {
                listener = Pool.First.Value;
                Pool.RemoveFirst();
            }
            
            var node = _used.AddLast(listener);
            listener.Connect(_eventHandler);
            listener.Attach(model, node);
            return listener;
        }
        
        IModelEventHandler<TItem> IEventSource<TItem>.EventHandler
        {
            get { return _eventHandler; }
            set
            {
                _eventHandler = value;

                foreach (var item in _used)
                {
                    item.Connect(value);
                }
            }
        }

        private class EventListener : IModelEventHandler<TItem>, IDisposable
        {
            private IModelEventHandler<TItem> _sink;
            private LinkedListNode<EventListener> _node;
            private IEventSource<TItem> _model;
            
            public void Dispose()
            {
                _sink = null;

                if (_model != null)
                {
                    _model.EventHandler = null;
                    _model = null;
                }
                
                if (_node != null)
                {
                    if (Pool.Count < MaximumPoolSize)
                    {
                        Pool.AddLast(_node.Value);
                    }

                    _node.List.Remove(_node);
                    _node = null;
                }
            }

            public void Handle(TItem @event)
            {
                _sink?.Handle(@event);
            }

            public void Attach(IEventSource<TItem> model, LinkedListNode<EventListener> node)
            {
                _model = model;
                _node = node;
                model.EventHandler = this;
            }

            public void Connect(IModelEventHandler<TItem> sink)
            {
                _sink = sink;
            }
        }
    }
}