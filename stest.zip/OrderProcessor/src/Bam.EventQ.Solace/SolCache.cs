﻿using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Bam.EventQ.Solace
{
    public class SolCache : ISolCache
    {
        private readonly SolCacheOptions _options;

        public SolCache(SolCacheOptions options)
        {
            _options = options;
        }

        private static string XmlEncode(string value)
        {
            return new XText(value).ToString();
        }

        private async Task<string> DetermineSempVersion()
        {
            var handler = new HttpClientHandler
            {
                Credentials = new NetworkCredential(_options.Username, _options.Password)
            };

            using (var client = new HttpClient(handler))
            {
                string body = "<rpc semp-version='soltr/1' />";
                var content = new StringContent(body, Encoding.UTF8, "application/xml");
                using (var response = await client.PostAsync(_options.SempUrl, content))
                {
                    body = await response.Content.ReadAsStringAsync() ?? string.Empty;

                    var marker = "semp-version=";
                    var start = body.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
                    if (start == -1)
                    {
                        throw new Exception($"Unexpected response from Solace: {body}");
                    }

                    start = start + marker.Length + 1;
                    var end = body.IndexOf('"', start);
                    if (end < start)
                    {
                        throw new Exception($"Unexpected response from Solace: {body}");
                    }

                    string version = body.Substring(start, end - start);
                    return version;
                }
            }
        }

        public async Task<bool> FlushAsync(string topic)
        {
            var version = await DetermineSempVersion();

            var handler = new HttpClientHandler
            {
                Credentials = new NetworkCredential(_options.Username, _options.Password)
            };
            
            using (var client = new HttpClient(handler))
            {
                string body = $@"<rpc semp-version='{version}'>
 <admin>
   <distributed-cache>
    <name>{XmlEncode(_options.CacheName)}</name>
    <vpn-name>{XmlEncode(_options.VpnName)}</vpn-name>
     <delete-messages>
      <topic>{XmlEncode(topic)}</topic> 
      <cluster-name>{XmlEncode(_options.Cluster)}</cluster-name>
      <instance-name>{XmlEncode(_options.Instance)}</instance-name>
     </delete-messages>
    </distributed-cache>
 </admin>
</rpc>";

                var content = new StringContent(body, Encoding.UTF8, "application/xml");
                using (var response = await client.PostAsync(_options.SempUrl, content))
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        return false;
                    }

                    body = await response.Content.ReadAsStringAsync();
                    var doc = XDocument.Load(new StringReader(body));
                    var element = doc.Root?.Element("execute-result");
                    var attr = element?.Attribute("code");
                    if (attr == null) return false;

                    return "ok" == attr.Value;
                }
            }
        }
    }
}