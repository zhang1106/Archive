﻿using System.Collections.Generic;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface ISecurityProvider : IDataProvider
    {
        IDictionary<string, ISecurity> DWSecurities{get;}
        ISecurity GetSecurity(string bamSymbol);
    }
}
