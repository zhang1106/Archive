﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.DataProvider
{
    public static class Util
    {
        public static Tuple<string, decimal?> Sum(IEnumerable<Tuple<string, IPosition>> tuples, bool isOption = true)
        {
            //get context
          if (!tuples.Any()) return Tuple.Create(string.Empty, (decimal?)0m);
            var context = tuples.Aggregate((i, j) => new Tuple<string, IPosition>(i.Item1 + ',' + j.Item1, null)).Item1;
            var qty = tuples.Sum(p => p.Item2.EquivalentQuantity);
            return Tuple.Create<string, decimal?>(context, qty);
        }
        
        public static string FormatPositionInfo(IPosition position)
        {
            return $"{{\"AcuId\":\"{position.Portfolio.PMCode}\",\"BamSymbol\":\"{position.Security.BamSymbol}\",\"Qty\":{position.ActualQuantity},\"Side\":\"{position.ActualSide}\",\"SecurityType\":\"{position.Security.SecurityType}\",\"Optiontype\":\"{position.Security.OptionType}\"}}";
        }
    }
}
