﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Web.UI.WebControls;
using Bam.Oms.Compliance.TestPosition.Models;

namespace Bam.Oms.Compliance.TestPosition.Controllers
{
    public class HomeController : Controller
    {
        public static PositionModels Model => _Model ?? (_Model = new PositionModels());

        static PositionModels _Model;
        public ActionResult Index()
        {
            return View(Model);
        }

        public ActionResult Create(PositionModels model)
        {
            Model.Clone(model);
            return View("Index");
        }

        [HttpGet]
        public JsonResult GetTestPosition()
        {
            var mock = Model.GetDataMock();
            return Json(mock, JsonRequestBehavior.AllowGet);
        }
    }
}