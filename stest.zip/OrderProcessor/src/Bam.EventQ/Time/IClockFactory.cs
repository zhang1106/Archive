﻿namespace Bam.EventQ.Time
{
    public interface IClockFactory
    {
        IClock Create(string zoneId);
    }
}
