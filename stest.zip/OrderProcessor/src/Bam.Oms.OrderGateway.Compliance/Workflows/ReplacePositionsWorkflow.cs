﻿using System.Collections.Generic;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.Compliance.Workflows
{
    public class ReplacePositionsWorkflow : Workflow, IHandle<ReplacePositions>
    {
        private readonly IReferenceDataService _referenceDataService;
        private readonly IComplianceCache _cache;

        public ReplacePositionsWorkflow(IReferenceDataService referenceDataService, IComplianceCache cache)
        {
            _referenceDataService = referenceDataService;
            _cache = cache;
        }

        public void Execute(ReplacePositions input)
        {
            foreach (var item in input.Items)
            {
                Portfolio portfolio;
                PortfolioDetails details;
                if (!Portfolio.TryParse(item.Portfolio, out portfolio) ||
                    !_referenceDataService.TryGetPortfolioDetails(portfolio, out details))
                {
                    continue;
                }

                var key = new PositionKey(portfolio, item.Symbol);

                using (Attach(_cache))
                {
                    var set = _cache.GetPositionSet(key);

                    var longMarkingDelta = item.LongMarkingQuantity - set.Position.LongMarkingQuantity;
                    var shortMarkingDelta = item.ShortMarkingQuantity - set.Position.ShortMarkingQuantity;

                    using (Attach(set.Position))
                    using (Attach(set.CompliancePosition))
                    using (Attach(set.AggUnitPosition))
                    {
                        var actualEffects = new Dictionary<PositionAllocationKey, long>();
                        var theoreticalEffects = new Dictionary<PositionAllocationKey, long>();
                        foreach (var a in item.Allocations)
                        {
                            var actualKey = new PositionAllocationKey(a.FundId, a.CustodianId);
                            PositionAllocation actual;
                            if (set.Position.ActualAllocations.TryGetValue(actualKey, out actual))
                            {
                                var actualDelta = a.Quantity - actual.Quantity;
                                actualEffects[actualKey] = actualDelta;
                            }
                            else
                            {
                                actualEffects[actualKey] = a.Quantity;
                            }

                            var theoreticalKey = new PositionAllocationKey(a.FundId, a.CustodianId);
                            PositionAllocation theoretical;
                            if (set.Position.TheoreticalAllocations.TryGetValue(theoreticalKey, out theoretical))
                            {
                                var theoreticalDelta = a.Quantity - theoretical.Quantity;
                                theoreticalEffects[theoreticalKey] = theoreticalDelta;
                            }
                            else
                            {
                                theoreticalEffects[theoreticalKey] = a.Quantity;
                            }
                        }

                        set.Position.ApplyLongMarkingEffect(longMarkingDelta);
                        set.Position.ApplyShortMarkingEffect(shortMarkingDelta);
                        set.Position.ApplyTheoreticalQuantityEffect(theoreticalEffects);
                        set.Position.ApplyActualQuantityEffect(actualEffects);
                        set.CompliancePosition.ApplyShortMarkingEffect(shortMarkingDelta);
                        set.CompliancePosition.ApplyLongMarkingEffect(longMarkingDelta);
                        set.AggUnitPosition.ApplyShortMarkingEffect(shortMarkingDelta);
                    }

                    _cache.Save(new[] { set });
                }
            }
        }
    }
}
