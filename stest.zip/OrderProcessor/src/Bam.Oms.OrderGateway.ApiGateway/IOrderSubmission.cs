using System;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface IOrderSubmission
    {
        Guid Submit(SubmitOrders message);
        void ConvertToSwap(long orderId, string counterParty, string user);
        void Cancel(long[] orderIds, string user);
        void AcquireLocate(long[] orderIds, string user);
        void ToggleOrderScalingRule(int id, bool active, string user);
        void OverrideCompliance(long orderId, string messages, string user);
    }
}
