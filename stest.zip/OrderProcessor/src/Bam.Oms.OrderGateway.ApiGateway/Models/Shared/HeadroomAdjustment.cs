﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class HeadroomAdjustment
    {
        public int RuleId { get; set; }
        public string Identifier { get; set; }
        public Dictionary<string, double> Ratios { get; } = new Dictionary<string, double>();
    }
}
