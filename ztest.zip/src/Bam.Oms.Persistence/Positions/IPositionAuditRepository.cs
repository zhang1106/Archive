﻿using Bam.Oms.Data.Positions;
using System.Collections.Generic;

namespace Bam.Oms.Persistence.Positions
{
    public interface IPositionAuditRepository : IDBRepository<PositionAudit>
    {
        // Any Position Audit Repository related methods to go here.
        IList<PositionAudit> GetOlderAudits(int actionLogId);
    }
}