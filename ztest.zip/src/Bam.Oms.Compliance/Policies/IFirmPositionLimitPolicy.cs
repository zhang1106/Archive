﻿using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Policies
{
    public interface IFirmPositionLimitPolicy : IPolicy<CompliancePosition>
    {
        void PopulateRules();
    }
}
