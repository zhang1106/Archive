﻿using Bam.EventQ.Integration;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;

namespace Bam.Oms.OrderGateway.EzeGateway.Producers
{
    public interface IAsyncRpc : IExternalMessageSource<TradeCreateResponse>
    {
        void CreateOrders(TradeCreateRequest request);
    }
}
