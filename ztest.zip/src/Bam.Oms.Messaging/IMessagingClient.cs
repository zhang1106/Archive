﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bam.Oms.Messaging
{
    public interface IMessagingClient<T>
    {
        /// <summary>
        /// Callback delegate when a message matches the filter criteria
        /// </summary>
        Action<T> ReceiveMessageCallback { get; set; }

        /// <summary>
        /// Represents the datetime in ticks received from the server
        /// </summary>
        long LastPong { get; set; }

        /// <summary>
        /// Adds filter to the client listener
        /// </summary>
        /// <param name="criteria"></param>
        /// <returns></returns>
        Task ApplyFilter(IEnumerable<ParameterString> criteria);

        /// <summary>
        /// Removes the filter criteria
        /// </summary>
        /// <returns></returns>
        Task RemoveFilter();

        /// <summary>
        /// Represents a ping to server
        /// </summary>
        Task Ping();

        /// <summary>
        /// Notifies interested parties that the Order Gateway is up and ready to process orders
        /// </summary>
        event Action OrderGatewayInitialized;

        /// <summary>
        /// Notifies interested parties that the Order Gateway has rolled
        /// </summary>
        event Action<DateTime> SodRollCompletedOnGateway;

    }
}