﻿using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance.DataProvider
{
    public class CustomDataProvider : ICustomDataProvider
    {
        private HashSet<string> _euMonitoredIsins;
        private HashSet<string> _euExemptedIsins;
        private Dictionary<string, string> _pmRegionMapping;
        private Dictionary<string, decimal> _customSharesOutstandings;
        
        private ILookup<string, Constituent> _constituents;
        private readonly IOgDataRepository _customDataRepository;
        private readonly IDwRepository _dwRepository;
        private readonly ISecurityProvider _securityProvider;
        private Dictionary<string, IList<ISecurity>> _linkedSecurities;

        public CustomDataProvider(IOgDataRepository customDataRepository, IDwRepository dwRepository, ISecurityProvider securityProvider)
        {
            _customDataRepository = customDataRepository;
            _dwRepository = dwRepository;
            _securityProvider = securityProvider;
        }

        public void RefreshData()
        {
            _euExemptedIsins = _customDataRepository.GetEuExemptedIsins();
            _euMonitoredIsins = _dwRepository.GetEuMonitoredIsins();
            _pmRegionMapping = _dwRepository.GetPmRegionMapping();
            _customSharesOutstandings = _dwRepository.GetCustomSharesOutstandings();
           
            _constituents = _dwRepository.GetConstitents();
            _linkedSecurities = GetLinkedSecurities();
        }
 
        public IEnumerable<Constituent> GetConstituents(string symbol)
        {
            return _constituents[symbol];
        }
    
        public HashSet<string> GetEuMonitoredIsins()
        {
            return _euMonitoredIsins;
        }

        public HashSet<string> GetEuExemptedIsins()
        {
            return _euExemptedIsins;
        }

        public bool IsEuExempted(string isin)
        {
            return _euExemptedIsins.Contains(isin);
        }

        public IDictionary<string, IList<ISecurity>> LinkedSecurities => _linkedSecurities;
        
        public string GetEntity(string strategy)
        {
            return !_pmRegionMapping.ContainsKey(strategy) ? null : _pmRegionMapping[strategy];
        }

        public decimal? GetSharesOutstanding(string symbol)
        {
            return !_customSharesOutstandings.ContainsKey(symbol) ? (decimal?)null : _customSharesOutstandings[symbol];
        }
 
        public IEnumerable<DtdPosition> GetEodPositions()
        {
            return _customDataRepository.GetEodPositions();
        }
        
        private Dictionary<string, IList<ISecurity>> GetLinkedSecurities()
        {
            var linked = _dwRepository.GetCustomMergeSymbols();
            var linkedIsins = new Dictionary<string, IList<ISecurity>>();
            foreach (var key in linked.Keys)
            {
                var linkedSecurity = linked[key].Select(symbol => _securityProvider.GetSecurity(symbol)).Where(security => security != null).Cast<ISecurity>().ToList();

                if (linkedSecurity.GroupBy(s => s.Isin).Count() > 1)
                {
                    linkedIsins.Add(key, linkedSecurity);
                }
            }
            return linkedIsins;
        }
    }
}
