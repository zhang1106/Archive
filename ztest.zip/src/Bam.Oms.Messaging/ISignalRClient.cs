﻿using System;

namespace Bam.Oms.Messaging
{
    public interface ISignalRClient<in T>
    {
        /// <summary>
        /// Method invoked on the client when the server receives an update
        /// </summary>
        /// <param name="packet"></param>
        void ReceiveMessage(T packet);

        /// <summary>
        /// Method called from the server to the client in response to a pin
        /// </summary>
        /// <param name="ticks"></param>
        void Pong(long ticks);

        /// <summary>
        /// Method invoked on the client when the OrderGateway has been fully initialized
        /// </summary>
        void OrderGatewayInitializedMessage();

        /// <summary>
        /// Method invoked on the client when the OrderGateway does a roll
        /// </summary>
        /// <param name="timeRolled">DateTime object capturing the time the roll occured</param>
        void SodRolledMessage(DateTime timeRolled);

    }
}