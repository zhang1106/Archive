﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Data.Configuration;
using Bam.Oms.OrderRouting.Contracts;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Grpc.Core;

namespace Bam.Oms.OrderRouting.Flex
{
    public abstract class SubscriptionHost<T> : ISubscriptionDisposable
    {
        private readonly ILogger _logger;
        private readonly IGrpcChannel _channel;
        private readonly ISettings _settings;
        private readonly ILoggingAgent _eventLogger;
        protected readonly CancellationTokenSource CancellationTokenSource = new CancellationTokenSource();
        private IAsyncStreamReader<T> _stream;
        protected bool IsSubscribe;
        protected string SubscriptionId = Guid.NewGuid().ToString();
        private int _retryCount = 1;
        private int _retryWait;
        protected readonly string SubscriptionType;        

        protected SubscriptionHost(ILoggingAgent eventLogger , ILogger logger, IGrpcChannel channel, ISettings settings)
        {
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (channel == null) throw new ArgumentNullException(nameof(channel));
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            if (eventLogger == null) throw new ArgumentNullException(nameof(eventLogger));


            _logger = logger;
            _channel = channel;
            _settings = settings;
            _retryWait = _settings.EmsResubscribeWaitInterval;
            _eventLogger = eventLogger;

            SubscriptionType = typeof (T).Name;
        }

        protected void Listener()
        {
            while (!CancellationTokenSource.IsCancellationRequested && IsSubscribe)
            {
                try
                {                    
                    if (!ListenToPositionUpdates(_stream).Result)
                        break;
                }
                catch (AggregateException aex)
                {
                    aex.Handle(ex =>
                    {
                        var grpcException = ex as RpcException;

                        if (grpcException!= null) //we want to retry for all grpc exceptions, regardless of the status code.
                        {
                            //Treat task cancellation as Info
                            _logger.Fatal($"Received grpc exception during Ping, killing gateway {ex.Message} {ex.StackTrace}");
//
//                            string msg =
//                                $"Grpc exception issued b/c task cancelled or stopped. Status message: {ex.Message}.";
//                            _logger.Info(msg);
//
//                            _logger.Warn($"Starting re-connection attempts after Grpc exception, disposing stream of type {SubscriptionType}");
//
//                            var logEvent = new DataFlowEvent(EventCategory.Order, null, BamSystem.OMS_GATEWAY, DateTime.Now, msg, null, null, BamSystem.OMS_GATEWAY);
//                            _eventLogger.SendFailedEvent(logEvent);


                            //tactical hard kill
                            Process.GetCurrentProcess().Kill();

                            StartRetry();
                            return true;
                        }

                        //this should break the loop
                        _logger.FatalFormat("Subscription thread has failed {0} - {1}, ", ex.Message, ex.StackTrace);
                        return false;
                    });
                }
            }

            //if this was initiated by the Unsubscribe, we know we killed it, otherwise, re-sub (above)
            if (IsSubscribe)
            {
                _logger.Warn("Grpc gracefully disconnected.  Re-connection attempts started...");
                StartRetry();
            }
        }

        protected void Subscribe(IAsyncStreamReader<T> stream)
        {
            _stream = stream;

            if (IsSubscribe) return; //only spin up the task one time, even if we're generating the stream again after a disconnect

            IsSubscribe = true;
            
            Task.Factory.StartNew(Listener, CancellationTokenSource.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        protected async Task<bool> ListenToPositionUpdates(IAsyncStreamReader<T> subscription)
        {            
            if (await MoveSubscriptionCursor(subscription))
            {
                NewItemHandler(subscription.Current);
                return true;
            }

            return false;
        }

        [Log]
        protected abstract void NewItemHandler(T response);

        private async Task<bool> MoveSubscriptionCursor(IAsyncStreamReader<T> subscription)
        {
            return await subscription.MoveNext(CancellationToken.None); //still doesn't support manually canceling the subscription stream
        }

        protected virtual void Unsubscribe()
        {
            IsSubscribe = false;
        }

        protected abstract void Resubscribe();


        private void StartRetry()
        {
            _stream.Dispose();
            while (_retryCount < _settings.MaxResubscribeAttempt)
            {
                //Only attempt to generate a new stream if the channel has re-connected.
                if (_channel.ChannelState == ChannelState.Ready)
                {
                    Resubscribe();
                    _logger.Info($"Reconnected after {_retryCount} attempts...");                    
                    break;
                }

                _logger.Warn($"Re-connect attempt {_retryCount++} failed...");

                _retryWait = _retryWait + _retryWait;
                Thread.Sleep(1000*_retryWait);
            }

            if (_retryCount == _settings.MaxResubscribeAttempt)
            {
                _logger.Fatal($"Unable to re-connection {SubscriptionType} after {_settings.MaxResubscribeAttempt} attempts...");
                IsSubscribe = false;
            }

            _retryCount = 1;
            _retryWait = _settings.EmsResubscribeWaitInterval;
        }

        public void DisposeSubscription()
        {
            IsSubscribe = false;
            Unsubscribe();
            CancellationTokenSource.Cancel();
        }
    }
}