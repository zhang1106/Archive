﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using Bam.EventQ.SignalR;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;
using Microsoft.AspNet.SignalR.Hubs;
using Microsoft.AspNet.SignalR.Infrastructure;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.SignalR
{
    public class FilteredSignalRPublisher<TKey, TItem, THub> : SignalRPublisher<TItem, THub> where THub : IHub
    {
        public FilteredSignalRPublisher(
            IConnectionManager connectionManager, 
            ISignalRSessionRepository sessionRepository, 
            IPermissionedEntityFilter permissionedEntityFilter,
            Func<TItem, string> strategyAccessor,
            ICache<TKey, TItem> cache, 
            int publishBatchSize) 
            : base(connectionManager, sessionRepository, 
                  (items, identity) => Filter(permissionedEntityFilter, strategyAccessor, items, identity), 
                  () => GetAll(cache), publishBatchSize)
        {
        }

        protected static IEnumerable<TItem> Filter(
            IPermissionedEntityFilter permissionedEntityFilter, 
            Func<TItem, string> strategyAccessor, 
            IEnumerable<TItem> items, IIdentity identity)
        {
            return permissionedEntityFilter.FilterAsync(items, identity, strategyAccessor).Result;
        }

        protected static IEnumerable<TItem> GetAll(ICache<TKey, TItem> cache)
        {
            using (cache.AcquireReadAccess())
            {
                foreach (var item in cache.GetItems())
                    yield return item;
            }
        }
    }
}
