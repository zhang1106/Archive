﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.MarketData.Enumerators;

namespace Bam.Oms.MarketData
{
    public interface IRequestReject
    {
        string ReqID { get; }

        RequestRejectReason Reason { get; }

        string Text { get; }
    }
}
