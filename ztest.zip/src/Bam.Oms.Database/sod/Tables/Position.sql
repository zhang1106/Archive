﻿CREATE TABLE [sod].[Position] (
    [PositionId]           INT              IDENTITY (1, 1) NOT NULL,
    [FundCode]             VARCHAR (50)     NOT NULL,
    [CustodianName] VARCHAR(50) NOT NULL,
    [StrategyCode]         VARCHAR (50)     NOT NULL,
    [AssetType]       VARCHAR (50)     NOT NULL,
    [BAMSymbol]            VARCHAR (100)    NOT NULL,
    [CustodianAccountCode] VARCHAR (50)     NULL,
	[Qty]                  DECIMAL (28, 12) NOT NULL,
    [Price]                DECIMAL (28, 12) NOT NULL,
    [Cost] DECIMAL(28, 12) NULL, 
    [Ccy]                  VARCHAR (50)     NOT NULL,
    [FXRate]               DECIMAL (28, 12) NOT NULL,
    [Stream]               VARCHAR (50)     NULL,
    [EntryDate]            DATE             DEFAULT (CONVERT([date],getdate(),0)) NOT NULL,
    [ActionLogId]          INT              NULL,
    [AuditSequence]        INT              DEFAULT ((0)) NOT NULL,
    [LastModifiedBy]       VARCHAR (50)     NOT NULL,
    [LastModifiedOn]       DATETIME         DEFAULT (getdate()) NOT NULL,
    [CreatedOn]            DATETIME         DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_tblSODPosition] PRIMARY KEY CLUSTERED ([PositionId] ASC),
    CONSTRAINT [IX_tblSODPosition] UNIQUE NONCLUSTERED ([FundCode] ASC, [CustodianName] ASC, [StrategyCode] ASC, [AssetType] ASC, [BAMSymbol] ASC)
);



