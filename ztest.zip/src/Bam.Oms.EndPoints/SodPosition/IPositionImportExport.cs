﻿using System.Collections.Generic;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.EndPoints.SodPosition
{
    public interface IPositionImportExport
    {
        IReadOnlyList<IPosition> Import(string path);
        void Export(IReadOnlyList<IPosition> positions, string path);
    }
}
