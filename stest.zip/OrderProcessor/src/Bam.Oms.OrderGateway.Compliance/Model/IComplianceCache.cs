﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public interface IComplianceCache : IEventSource<IMessage>
    {
        PositionSet GetPositionSet(PositionKey key);
        IReadOnlyList<PositionSet> GetPositionSets(IReadOnlyList<PositionKey> keys);
        IList<Order> GetAllOrders(Func<Order, bool> predicate = null);
        void Save(IReadOnlyList<PositionSet> sets);
        IList<OrderStrategyAllocation> GetOrders(IEnumerable<PositionKey> keys);
        Order GetOrder(long id);
        IList<Order> GetOrders(IEnumerable<string> symbols);
        void UpdateSodPositions(IReadOnlyList<SodPosition> sodPositions, bool isContingency);
        LookupList<SodPosition> GetSodPositions(string symbol);
    }
}
