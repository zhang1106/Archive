﻿using System.IO;
using Bam.EventQ.Lookup;

namespace Bam.EventQ.Snapshot
{
    public interface ISnapshotRecoveryService<TMessage> : IEventSource<TMessage>
    {
        void Persist(Stream stream);
        void Recover(Stream stream);
    }
}