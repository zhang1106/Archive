﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

namespace Bam.EventQ.Diagnostics
{
    public class PerformanceCounterTelemetry : ITelemetry
    {
        private static readonly HashSet<string> CounterNames = new HashSet<string>(new[]
        {
            "OrderProcessor",
            "FlexGateway",
            "ApiGateway",
            "Compliance",
            "RuleBasedRouting",
            "LocateGateway",
            "RefDataGateway",
            "RollBlotter",
            "MessageLog",
            "SimulationEms",
            "EzeGateway"
        });

        public PerformanceCounterTelemetry()
        {
            CategoryName = "Order Gateway";
            CounterName = AppDomain.CurrentDomain.FriendlyName;

            using (var mutex = new Mutex(false, "Order Gateway Perf. Counters")) // guard against other app domains
            {
                mutex.WaitOne();
                try
                {
                    if (!PerformanceCounterCategory.Exists(CategoryName))
                    {
                        var collection = new CounterCreationDataCollection();
                        foreach (var key in CounterNames)
                        {
                            collection.Add(new CounterCreationData
                            {
                                CounterName = key
                            });
                        }

                        PerformanceCounterCategory.Create(CategoryName, CategoryName,
                            PerformanceCounterCategoryType.MultiInstance, collection);
                    }
                }
                finally
                {
                    mutex.ReleaseMutex();
                }
            }
        }

        public void Record<T>(string key, T value)
        {
            if (!CounterNames.Contains(CounterName))
                return;

            using (var count = new PerformanceCounter(CategoryName, CounterName, key, false))
            {
                if (typeof(T) == typeof(double))
                {
                    double val = (double) (object) value;
                    if (double.IsInfinity(val) || double.IsNaN(val))
                        return;
                }

                count.RawValue = Convert.ToInt64(value);
            }
        }

        private string CategoryName { get; }
        private string CounterName { get; }
    }
}
