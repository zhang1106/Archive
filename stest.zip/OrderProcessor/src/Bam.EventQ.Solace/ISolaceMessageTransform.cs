﻿using SolaceSystems.Solclient.Messaging;

namespace Bam.EventQ.Solace
{
    public interface ISolaceMessageTransform
    {
        void Transform(IMessage source, byte[] buffer, int index, out int received, out int topic);
    }
}
