﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Disruptor
{
    public class CompositeErrorHandler : IQueueErrorHandler
    {
        private readonly List<IQueueErrorHandler> _handlers;

        public CompositeErrorHandler()
        {
            _handlers = new List<IQueueErrorHandler>();
        }

        public void Add(IQueueErrorHandler handler)
        {
            _handlers.Add(handler);
        }

        public void HandleError(Exception ex, long? sequence, object evt)
        {
            foreach (var h in _handlers)
            {
                h.HandleError(ex, sequence, evt);
            }
        }
    }
}
