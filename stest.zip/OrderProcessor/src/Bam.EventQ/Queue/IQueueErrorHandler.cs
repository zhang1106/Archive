﻿using System;

namespace Bam.EventQ.Queue
{
    public interface IQueueErrorHandler
    {
        void HandleError(Exception ex, long? sequence, object evt);
    }
}
