﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web.Http;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class OrderController : BaseController
    {
        private readonly ICache<string, Order> _orderCache;
        private readonly IOrderSubmission _orderSubmission;
        private readonly IRouteSubmission _routeSubmission;
        private readonly ICancelSubmission _cancelSubmission;
        private readonly IAllocationSubmission _allocationSubmission;
        private readonly ICache<string, Security> _securityCache;

        public OrderController(
            ICache<string, Order> orderCache, 
            IOrderSubmission orderSubmission,
            IPermissionedEntityFilter entityFilter,
            IRouteSubmission routeSubmission,
            ICancelSubmission cancelSubmission,
            IAllocationSubmission allocationSubmission, 
            ICache<string, Security> securityCache)
            : base(entityFilter)
        {
            _orderCache = orderCache;
            _orderSubmission = orderSubmission;
            _routeSubmission = routeSubmission;
            _cancelSubmission = cancelSubmission;
            _allocationSubmission = allocationSubmission;
            _securityCache = securityCache;
        }
        
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public Task<List<Order>> Get()
        {
            using (_orderCache.AcquireReadAccess())
            {
                return FilterEntitiesAsync(_orderCache.GetItems().OrderBy(o => o.Key));
            }
        }

        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public async Task<Order> Get(string key)
        {
            if (string.IsNullOrEmpty(key))
                return null;

            using (_orderCache.AcquireReadAccess())
            {
                var order = _orderCache.Get(key.ToUpper());
                if (order != null)
                {
                    order = (await FilterEntitiesAsync(new[] {order})).FirstOrDefault();
                }

                return order;
            }
        }

        [RequiredPermissions("Function.OrderGateway.Trade.Read, Function.OrderGateway.Trade.Write")]
        public async Task<List<Order>> GetByUnderlyingSymbol(string underlyingSymbol)
        {
            if (string.IsNullOrEmpty(underlyingSymbol))
                return new List<Order>();

            underlyingSymbol = underlyingSymbol.ToUpper();
            var securities = new HashSet<string>();
            using (_securityCache.AcquireReadAccess())
            {
                securities.UnionWith(_securityCache.GetItems()
                    .Where(s => s.UltimateUnderlyingSymbol.Equals(underlyingSymbol))
                    .Select(s => s.BamSymbol));
            }

            if (!securities.Any())
                return await Task.FromResult(new List<Order>());

            using (_orderCache.AcquireReadAccess())
            {
                var orders = _orderCache.GetItems()
                    .Where(t => securities.Contains(t.Security.BamSymbol))
                    .OrderBy(t => t.Key);

                return await FilterEntitiesAsync(orders);
            }
        }

        [RequiredPermissions("Function.OrderGateway.Trade.Read, Function.OrderGateway.Trade.Write")]
        public async Task<List<Order>> GetBySymbol(string bamSymbol)
        {
            if (string.IsNullOrEmpty(bamSymbol))
                return new List<Order>();

            bamSymbol = bamSymbol.ToUpper();
            using (_orderCache.AcquireReadAccess())
            {
                var orders = _orderCache.GetItems()
                    .Where(t => t.Security.BamSymbol.Equals(bamSymbol))
                    .OrderBy(o => o.Key);

                return await FilterEntitiesAsync(orders);
            }
        }

        [RequiredPermissions("Function.OrderGateway.Trade.Read, Function.OrderGateway.Trade.Write")]
        public async Task<List<Order>> GetByPmCode(string pmCode)
        {
            if (string.IsNullOrEmpty(pmCode))
                return new List<Order>();

            pmCode = pmCode.ToUpper();
            using (_orderCache.AcquireReadAccess())
            {
                var orders = _orderCache.GetItems()
                    .Where(t => t.Portfolio.PMCode.Equals(pmCode))
                    .OrderBy(o => o.Key);

                return await FilterEntitiesAsync(orders);
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public async Task<List<Order>> BySymbol(string symbol)
        {
            if (string.IsNullOrEmpty(symbol))
                return new List<Order>();

            using (_orderCache.AcquireReadAccess())
            {
                return await FilterEntitiesAsync(
                    _orderCache.GetItems()
                        .Where(o => symbol.Equals(o.Security.Key, StringComparison.OrdinalIgnoreCase) ||
                                    symbol.Equals(o.Security.UnderlyingSymbol, StringComparison.OrdinalIgnoreCase))
                        .OrderBy(o => o.Key),
                    o => o.Portfolio.ToString());
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public async Task<List<Order>> ByBatch(string batchName)
        {
            if (string.IsNullOrEmpty(batchName))
                return new List<Order>();

            using (_orderCache.AcquireReadAccess())
            {
                return await FilterEntitiesAsync(
                    _orderCache.GetItems()
                        .Where(o => string.Equals(o.BatchId, batchName, StringComparison.OrdinalIgnoreCase))
                        .OrderBy(o => o.Key),
                    o => o.Portfolio.ToString());
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public async Task<List<Order>> ByStrategy(string strategy)
        {
            if (string.IsNullOrEmpty(strategy))
                return new List<Order>();

            var portfolio = Portfolio.Parse(strategy);
            using (_orderCache.AcquireReadAccess())
            {
                return await FilterEntitiesAsync(
                    _orderCache.GetItems()
                        .Where(o => o.Portfolio.Matches(portfolio))
                        .OrderBy(o => o.Key),
                    o => o.Portfolio.ToString());
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public async Task<List<Order>> ByBatchAndStrategy(string batchName, string strategy)
        {
            if (string.IsNullOrEmpty(strategy) || string.IsNullOrEmpty(batchName))
                return new List<Order>();

            var portfolio = Portfolio.Parse(strategy);
            using (_orderCache.AcquireReadAccess())
            {
                return await FilterEntitiesAsync(
                    _orderCache.GetItems()
                        .Where(o => string.Equals(o.BatchId, batchName, StringComparison.OrdinalIgnoreCase) && 
                                    o.Portfolio.Matches(portfolio))
                        .OrderBy(o => o.Key),
                    o => o.Portfolio.ToString());
            }
        }

        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public async Task<List<Order>> Get([FromUri(Name = "cutoffTimeUtc")] DateTime modifiedSince)
        {
            using (_orderCache.AcquireReadAccess())
            {
                return await FilterEntitiesAsync(
                    _orderCache.GetItems()
                        .Where(o => o.LastUpdated >= modifiedSince)
                        .OrderBy(o => o.Key),
                    o => o.Portfolio.ToString());
            }
        }

        [RequiredPermissions("Function.PMUI.Write")]
        public async Task<List<string>> PostOrders(List<Order> orders)
        {
            int originalCount = orders.Count;
            Logger?.LogInformation($"{User.GetLogin()} submitted batch of {originalCount} orders");

            orders = (await 
                FilterEntitiesAsync(orders, o => o.Portfolio?.ToString())).ToList();

            if (orders.Count != originalCount)
            {
                Logger?.LogError($"{User.GetLogin()} tried to submit {originalCount- orders.Count} orders for unauthorized strategy");
            }

            if (orders.Count == 0)
            {
                return new List<string>();
            }

            var submission = new SubmitOrders
            {
                BatchName = orders[0].BatchId ?? orders[0].Portfolio.PMCode + "-MANUAL",
                SubmissionMethod = SubmissionMethod.Api,
                User = User.GetLogin()
            };

            foreach (var o in orders)
            {
                var lineItem = new SubmitOrders.SubmitOrderLineItem
                {
                    Custodian = o.Custodian,
                    Side = o.Side.ToSide(),
                    LimitPrice = o.Price,
                    Notes = o.Note,
                    Quantity = (long) o.Size,
                    Portfolio = o.Portfolio.ToString(),
                    Symbol = o.Security.Key,
                    Urgency = (Urgency)Enum.Parse(typeof(Urgency), o.Urgency.ToString())
                };

                long replacedOrderId;
                if (long.TryParse(o.ClientOrderId, out replacedOrderId))
                    lineItem.ReplaceOrderId = replacedOrderId;

                foreach (var ei in o.ExecutionInstructions)
                {
                    lineItem.ExecutionInstructions[ei.Code] = ei.Value;
                }

                submission.Items.Add(lineItem);
            }

            var result = new List<string>();
            var submissionId = _orderSubmission.Submit(submission);
            if (submissionId != Guid.Empty)
            {
                Func<List<string>> submittedOrders = () =>
                {
                    using (_orderCache.AcquireReadAccess())
                    {
                        return _orderCache.GetItems()
                            .Where(o => o.SubmissionId == submissionId)
                            .Select(o => o.Key)
                            .ToList();
                    }
                };

                SpinUntil(() => (result = submittedOrders()).Count >= orders.Count, 
                    TimeSpan.FromSeconds(30));
            }

            return result;
        }

        [RequiredPermissions("Function.PMUI.Write")]
        public async Task<int> DeleteOrders([FromUri(Name = "ordersIds")] string[] orderIds)
        {
            if (orderIds == null || orderIds.Length == 0)
                return 0;

            Logger?.LogInformation($"{User.GetLogin()} cancelled orders {orderIds.Stringify()}");
            using (_orderCache.AcquireReadAccess())
            {
                var ids = await GetPermissibleOrderIds(orderIds);
                if (ids.Count != orderIds.Length)
                {
                    Logger?.LogError($"{User.GetLogin()} tried to cancel {orderIds.Length-ids.Count} orders he/she is not permissioned for");
                }

                if (ids.Count > 0)
                {
                    _cancelSubmission.Cancel(ids.ToArray(), User.GetLogin());
                }

                return ids.Count;
            }
        }

        [HttpPatch]
        [RequiredPermissions("Function.OrderGateway.Admin")]
        public void Rollback(long[] orderIds)
        {
            if (orderIds == null || orderIds.Length == 0)
                return;

            Logger?.LogInformation($"{User.GetLogin()} rolled back orders {orderIds.Stringify()}");
            _cancelSubmission.Rollback(orderIds, User.GetLogin());
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Write")]
        public async Task<List<Order>> CancelOrdersInDetailStrategyAndBatch(string detailStrategy, string batchId)
        {
            Logger?.LogInformation($"{User.GetLogin()} cancelled orders in strategy {detailStrategy} for batch {batchId}");
            var toCancel = await GetLiveOrdersInDetailStrategyAndBatch(detailStrategy, batchId);
            var allowed = await FilterEntitiesAsync(toCancel);
            await DeleteOrders(allowed.Select(o => o.ClientOrderId).ToArray());
            return allowed;
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Write")]
        public Task<List<Order>> CancelOrdersInDetailStrategy(string detailStrategy)
        {
            return CancelOrdersInDetailStrategyAndBatch(detailStrategy, null);
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public Task<List<Order>> GetLiveOrdersInDetailStrategyAndBatch(string detailStrategy, string batchId)
        {
            var portfolio = Portfolio.Parse(detailStrategy);
            if (portfolio == null)
            {
                return Task.FromResult(new List<Order>());
            }
            
            using (_orderCache.AcquireReadAccess())
            {
                var byStrategy = _orderCache.GetItems().Where(o => portfolio.Matches(o.Portfolio));
                var filtered = byStrategy.Where(o => o.CanBeCancelled() && (batchId == null || o.BatchId == batchId)).ToList();
                return FilterEntitiesAsync(filtered);
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public Task<List<Order>> GetLiveOrdersInDetailStrategy(string detailStrategy)
        {
            return GetLiveOrdersInDetailStrategyAndBatch(detailStrategy, null);
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public Task<bool> IsStrategyComplete(string detailStrategy)
        {
            if (detailStrategy == null) throw new ArgumentNullException(nameof(detailStrategy));

            var portfolio = Portfolio.Parse(detailStrategy);
            if (portfolio == null)
            {
                return Task.FromResult(false);
            }

            using (_orderCache.AcquireReadAccess())
            {
                var hasPendingOrders = _orderCache.GetItems().Any(o => portfolio.Matches(o.Portfolio) && !o.IsComplete);
                return Task.FromResult(!hasPendingOrders);
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public Task<bool> IsStrategyAndBatchComplete(string detailStrategy, string batchId)
        {
            if (detailStrategy == null) throw new ArgumentNullException(nameof(detailStrategy));
            if (batchId == null) throw new ArgumentNullException(nameof(batchId));

            var portfolio = Portfolio.Parse(detailStrategy);
            if (portfolio == null)
            {
                throw new Exception("Invalid strategy");
            }

            using (_orderCache.AcquireReadAccess())
            {
                var hasPendingOrders = _orderCache.GetItems().Any(o => portfolio.Matches(o.Portfolio) && o.BatchId == batchId && !o.IsComplete);
                return Task.FromResult(!hasPendingOrders);
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Read,Function.PMUI.Write")]
        public Task<bool> IsBatchComplete(string batchId)
        {
            if (batchId == null) throw new ArgumentNullException(nameof(batchId));

            using (_orderCache.AcquireReadAccess())
            {
                var hasPendingOrders = _orderCache.GetItems().Any(o => o.BatchId == batchId && !o.IsComplete);
                return Task.FromResult(!hasPendingOrders);
            }
        }

        [HttpPost]
        [RequiredPermissions("Function.PMUI.Write")]
        public async Task<List<string>> PostRoutedOrders([FromBody] string[] orderIds)
        {
            if (orderIds == null || orderIds.Length == 0)
                return null;

            Logger?.LogInformation($"{User.GetLogin()} routed orders {orderIds.Stringify()}");
            using (_orderCache.AcquireReadAccess())
            {
                var ids = await GetPermissibleOrderIds(orderIds);
                _routeSubmission.Route(ids.ToArray(), User.GetLogin());
                return ids.Select(id => Convert.ToString(id)).ToList();
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Write")]
        public Task<bool> ConvertToSwap(string orderId)
        {
            return ConvertToSwap(orderId, null);
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Write")]
        public async Task<bool> ConvertToSwap(string orderId, [FromUri(Name = "broker")] string counterPartyCode)
        {
            Logger?.LogInformation($"{User.GetLogin()} converted order {orderId} to swap with counter party '{counterPartyCode ?? "-default-"}'");

            Order order;
            using (_orderCache.AcquireReadAccess())
            {
                order = _orderCache.Get(orderId);
            }

            if (order == null)
            {
                Logger?.LogError($"Unable to convert order '{orderId}' to swap, order doesn't exist");
                return false;
            }

            var permissible = await FilterEntitiesAsync(new[] {order});
            if (!permissible.Any())
            {
                Logger?.LogError($"Unable to convert order '{orderId}' to swap, permission denied");
                return false;
            }

            long id;
            if (!long.TryParse(order.ClientOrderId, out id))
            {
                Logger?.LogError($"Unable to convert order '{orderId}' to swap, invalid order id");
                return false;
            }

            _orderSubmission.ConvertToSwap(id, counterPartyCode, User.GetLogin());

            return true;
        }

        [HttpGet]
        [RequiredPermissions("Function.PMUI.Write")]
        public async Task<bool> OverrideCompliance(string orderId, string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                Logger?.LogError($"Cannot override compliance with empty message.  '{orderId}'.");
                return false;
            }

            Order order;
            using (_orderCache.AcquireReadAccess())
            {
                order = _orderCache.Get(orderId);
            }

            if (order == null)
            {
                Logger?.LogError($"Unable to override compliance for '{orderId}', order doesn't exist");
                return false;
            }

            var permissible = await FilterEntitiesAsync(new[] { order });
            if (!permissible.Any())
            {
                Logger?.LogError($"Unable to override compliance for '{orderId}' to swap, permission denied");
                return false;
            }

            long actualOrderId;
            if (!long.TryParse(orderId, out actualOrderId))
            {
                Logger?.LogError($"Unable to convert order id '{orderId}' into int64.");
                return false;
            }

            Logger?.LogInformation($"{User.GetLogin()} overrode compliance error for order {actualOrderId}, '{message}'");
            _orderSubmission.OverrideCompliance(actualOrderId, message, User.GetLogin());
            return true;
        }

        [HttpPost]
        [RequiredPermissions("Function.PMUI.Write")]
        public async Task<bool> PostRedirectPbAllocation(RedirectPbAllocationRequest request)
        {
            Order order;
            using (_orderCache.AcquireReadAccess())
            {
                order = _orderCache.Get(request.OrderId);
            }

            if (order == null)
            {
                Logger?.LogError($"Unable to redirect pb allocations for '{request.OrderId}', order doesn't exist");
                return false;
            }

            var permissible = await FilterEntitiesAsync(new[] { order });
            if (!permissible.Any())
            {
                Logger?.LogError($"Unable to redirect pb allocations for '{request.OrderId}', permission denied");
                return false;
            }

            long orderId;
            if (!long.TryParse(request.OrderId, out orderId))
            {
                Logger?.LogError($"Unable to convert order id '{request.OrderId}' to long.");
                return false;
            }

            _allocationSubmission.RedirectPbAllocation(orderId, User.GetLogin(), request.Allocations);

            return true;
        }

        private async Task<IReadOnlyList<long>> GetPermissibleOrderIds(string[] orderIds)
        {
            var orders = new HashSet<Order>();
            if (orderIds != null)
            {
                foreach (var id in orderIds)
                {
                    if (id == null)
                        continue;

                    var order = _orderCache.Get(id);
                    if (order != null)
                    {
                        orders.Add(order);
                    }
                }
            }

            var allowed = await FilterEntitiesAsync(orders,
                o => o.Portfolio.ToString());

            var ids = new List<long>();
            foreach (var order in allowed)
            {
                long id;
                if (long.TryParse(order.ClientOrderId, out id))
                {
                    ids.Add(id);
                }
            }

            return ids;
        }
    }
}
