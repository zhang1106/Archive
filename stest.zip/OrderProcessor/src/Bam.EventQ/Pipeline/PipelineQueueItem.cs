﻿using System;

namespace Bam.EventQ.Pipeline
{
    public class PipelineQueueItem<TEntity>
    {
        private readonly ArraySegment<byte> _consecutiveFixedSizeBlock;

        public PipelineQueueItem(ArraySegment<byte> buffer)
        {
            IsValid = true;
            Buffer = _consecutiveFixedSizeBlock = buffer;
        }

        public ArraySegment<byte> Buffer { get; private set; }
        public int Length { get; private set; }
        public int Topic { get; private set; }
        public TEntity Payload { get; private set; }
        public bool IsValid { get; private set; }
        public bool IsReplay { get; private set; }
        public TimeSpan TimeInQueue => DateTime.UtcNow.Subtract(LastClear);
        public DateTime LastClear { get; private set; }

        public void EnsureBufferSize(int size)
        {
            if (Buffer.Count < size)
            {
                Buffer = new ArraySegment<byte>(new byte[size], 0, size);
            }
        }

        public void SetBufferLength(int length)
        {
            if (length <= Buffer.Count && length >= 0)
            {
                Length = length;
            }
        }

        public void SetPayload(TEntity payload)
        {
            Payload = payload;
        }

        public void Clear()
        {
            Topic = 0;
            IsReplay = false;
            IsValid = true;
            Length = 0;
            Buffer = _consecutiveFixedSizeBlock;
            Payload = default(TEntity);
            LastClear = DateTime.UtcNow;
        }

        public void SetTopic(int topic)
        {
            Topic = topic;
        }

        public void SetLastClear(DateTime lastClear)
        {
            LastClear = lastClear;
        }

        public void MarkReplay()
        {
            IsReplay = true;
        }

        public void MarkInvalid()
        {
            IsValid = false;
        }
    }
}
