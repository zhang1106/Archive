﻿namespace Bam.EventQ.Transport
{
    public interface IRpcServer
    {
        void Start();
        void Stop();
        void AddHandler(IRcpRequestHandler handler);
    }
}
