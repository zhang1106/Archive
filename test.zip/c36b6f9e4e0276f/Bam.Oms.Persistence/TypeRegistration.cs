﻿using System;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Persistence.Journal;
using Bam.Oms.Persistence.Serialization;
using ProtoBuf.Meta;


namespace Bam.Oms.Persistence
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            
            RegisterDBRepositories(container);
        }

 
        private void RegisterDBRepositories(Container container)
        {
            container.RegisterTypeWithLoggingInterfaceInterceptor<IFactRepository, FactRepository>(RegistrationType.Singleton);
        }
    }
}