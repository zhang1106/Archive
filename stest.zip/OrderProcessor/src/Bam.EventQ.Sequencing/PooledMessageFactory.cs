﻿using Bam.EventQ.Sequencing;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pooling
{
    public class PooledMessageFactory : MessageFactory
    {
        private readonly IObjectPool _pool;

        public PooledMessageFactory(IObjectPool pool)
        {
            _pool = pool;
        }

        public override T Create<T>()
        {
            return _pool.Get<T>();
        }
    }
}
