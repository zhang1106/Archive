﻿using Bam.Oms.Data.Orders;

namespace Bam.Oms.Compliance.Rules
{
    class PositionConcentrationRule : IComplianceRule<IOrder>
    {
        PositionConcentrationRule()
        {
            
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public void SetAndValidateParameters(string parametersInJsonFormat)
        {
            throw new System.NotImplementedException();
        }

        public IComplianceRuleViolation CheckViolation(IOrder input, bool isPreCheck)
        {
            throw new System.NotImplementedException();
        }
    }
}
