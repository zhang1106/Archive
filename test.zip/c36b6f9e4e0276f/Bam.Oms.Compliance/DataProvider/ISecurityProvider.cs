﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface ISecurityProvider : IDataProvider
    {
        ISecurity GetSecurity(string bamSymbol);

        IEnumerable<ISecurity> GetADRs(string bamSymbol);

        IEnumerable<ISecurity> GetUnderlyingSecurities();

        ConcurrentDictionary<string, ISecurity> Securities { get; }

        ILookup<string, ISecurity> SecuritiesByIsin { get; }

        ILookup<string, ISecurity> AdrLookup { get; }

        void RetriveRelatedSecurites(IEnumerable<string> symbols, out IList<string> notExist,
            out IList<string> related);

        void RetrieveSecurities(string[] underlyings);

        void UpdateSecurites(IEnumerable<Security> securities);

        void Start();

        void Stop();
    }
}
