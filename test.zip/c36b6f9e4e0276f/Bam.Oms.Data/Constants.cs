﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data
{
    public class Constants
    {
        public const string DefaultTrader = "System";
    }
}
