﻿using System;
using System.Linq;
using System.Security.Principal;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.Messaging;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.Hub
{
    public abstract class PortfolioFilteredSignalRHub<T> : SignalRHub<T> where T : IContainsPortfolio
    {
        protected PortfolioFilteredSignalRHub(ISignalRSessions<T> sessions, ILogger logger)
            : base(sessions, logger)
        {
        }

        protected override Func<T, bool> CreateFilter(IIdentity identity)
        {
            var strategies = PermissionChecker.GetPermissionedStrategies(identity)
                .Select(s => Portfolio.Parse(s.StrategyCode))
                .ToLookup(s => s.PMCode, s => s.Key, StringComparer.OrdinalIgnoreCase);

            return
                m => m.Portfolio != null &&
                     strategies.Contains(m.Portfolio.PMCode) &&
                     strategies[m.Portfolio.PMCode].Any(m.Portfolio.Key.StartsWith);
        }
    }
}
