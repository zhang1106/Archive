﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Threading;
using Bam.EventQ.Throttling;
using Microsoft.AspNet.SignalR.Hubs;
using Microsoft.AspNet.SignalR.Infrastructure;

namespace Bam.EventQ.SignalR
{
    public class SignalRPublisher<TItem, THub> : IThrottledBatchHandler<TItem> where THub : IHub
    {
        private readonly IConnectionManager _connectionManager;
        private readonly ISignalRSessionRepository _sessionRepository;
        private readonly Func<IEnumerable<TItem>, IIdentity, IEnumerable<TItem>> _filter;
        private readonly Func<IEnumerable<TItem>> _allAccessor;
        private readonly int _publishBatchSize;

        public SignalRPublisher(
            IConnectionManager connectionManager,
            ISignalRSessionRepository sessionRepository,
            Func<IEnumerable<TItem>, IIdentity, IEnumerable<TItem>> filter,
            Func<IEnumerable<TItem>> allAccessor,
            int publishBatchSize)
        {
            _connectionManager = connectionManager;
            _sessionRepository = sessionRepository;
            _filter = filter;
            _allAccessor = allAccessor;
            _publishBatchSize = publishBatchSize;

            _sessionRepository.NewConnection += SessionRepositoryOnNewConnection;
        }

        private void SessionRepositoryOnNewConnection(string connectionId)
        {
            ThreadPool.QueueUserWorkItem(PublishAll, connectionId);
        }

        public void Handle(IReadOnlyList<TItem> batch)
        {
            using (_sessionRepository.AcquirePublishingToken())
            {
                foreach (var connectionId in _sessionRepository.GetAllConnectionIds())
                {
                    var identity = _sessionRepository.TryGet(connectionId);
                    if (identity == null)
                        continue;

                    var client = GetClient(connectionId);
                    var visible = _filter(batch, identity);

                    foreach (var chunk in Batch(visible, _publishBatchSize))
                    {
                        client.ReceiveMessage(new SignalRPacket<TItem> 
                        {
                            Data = chunk
                        });
                    }
                }
            }
        }

        private void PublishAll(object state) 
        {
            string connectionId = (string)state;
            var identity = _sessionRepository.TryGet(connectionId);
            if (identity == null)
                return;

            using (_sessionRepository.AcquirePublishingToken())
            {
                var client = GetClient(connectionId);
                var visible = _filter(_allAccessor(), identity);

                foreach (var chunk in Batch(visible, _publishBatchSize))
                {
                    client.ReceiveMessage(new SignalRPacket<TItem> 
                    {
                        Data = chunk
                    });
                }
            }
        }

        private ISignalRClient<SignalRPacket<TItem>> GetClient(string connectionId) 
        {
            var orderCtx = _connectionManager.GetHubContext<THub, ISignalRClient<SignalRPacket<TItem>>>();
            return orderCtx.Clients.Client(connectionId);
        }

        private static IEnumerable<List<TItem>> Batch(IEnumerable<TItem> items, int batchSize) 
        {
            var batch = new List<TItem>(batchSize);

            foreach (var item in items)
            {
                batch.Add(item);
                if (batch.Count == batchSize)
                {
                    yield return batch;
                    batch = new List<TItem>(batchSize);
                }
            }

            if (batch.Count > 0)
            {
                yield return batch;
            }
        }
    }
}