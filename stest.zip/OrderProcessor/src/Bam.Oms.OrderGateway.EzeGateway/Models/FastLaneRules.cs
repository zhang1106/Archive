﻿using Bam.Oms.OrderGateway.EzeGateway.Services;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public class FastLaneRules : IFastLaneRules<SubmissionQueueItem>
    {
        private readonly int _fastLaneThreshold;

        public FastLaneRules(int fastLaneThreshold)
        {
            _fastLaneThreshold = fastLaneThreshold;
        }

        public bool CanUseFastLane(SubmissionQueueItem item)
        {
            return item.Request.trades.Length <= _fastLaneThreshold;
        }

        public bool CanBypass(SubmissionQueueItem behind, SubmissionQueueItem ahead)
        {
            return behind.Trade.Symbol != ahead.Trade.Symbol;
        }
    }
}
