﻿using System;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public struct EzeActualAllocationKey : IEquatable<EzeActualAllocationKey>
    {
        public bool Equals(EzeActualAllocationKey other)
        {
            return FundId == other.FundId && 
                   CustodianId == other.CustodianId && 
                   ExecutingBrokerId == other.ExecutingBrokerId &&
                   string.Equals(Portfolio, other.Portfolio);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is EzeActualAllocationKey && Equals((EzeActualAllocationKey) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = Portfolio?.GetHashCode() ?? 0;
                hashCode = (hashCode*397) ^ FundId;
                hashCode = (hashCode*397) ^ CustodianId;
                hashCode = (hashCode*397) ^ ExecutingBrokerId;
                return hashCode;
            }
        }

        public static bool operator ==(EzeActualAllocationKey left, EzeActualAllocationKey right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(EzeActualAllocationKey left, EzeActualAllocationKey right)
        {
            return !left.Equals(right);
        }

        public string Portfolio { get; set; }
        public int FundId { get; set; }
        public int CustodianId { get; set; }
        public int ExecutingBrokerId { get; set; }

        public EzeActualAllocationKey(string portfolio, int fundId, int custodianId, int executingBrokerId)
        {
            Portfolio = portfolio;
            FundId = fundId;
            CustodianId = custodianId;
            ExecutingBrokerId = executingBrokerId;
        }
    }
}