﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Dapper;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public class ContingencyRecordRepository : IContingencyRecordRepository
    {
        private readonly string _connectionString;

        public ContingencyRecordRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<IReadOnlyList<ContingencyRecord>> Load()
        {
            string table = "dbo.tblPositionsIntradayContingency";
            using (var connection = new SqlConnection(_connectionString))
            {
                var records = await connection.QueryAsync<ContingencyRecord>($"select * from {table}");
                return records.ToArray();
            }
        }

        public async Task Save(IReadOnlyList<ContingencyRecord> records)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var itemsToInsert = new List<DynamicParameters>();
                foreach (var item in records)
                {
                    var param = new DynamicParameters();
                    param.Add("@portfolio", value: item.Portfolio, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@symbolType", value: item.SymbolType, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@symbol", value: item.Symbol, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@symbolDesc", value: item.SymbolDesc, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@symbolPricing", value: item.SymbolPricing, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@quantity", value: item.Quantity, dbType: DbType.Decimal,
                        direction: ParameterDirection.Input);
                    param.Add("@sodPriceNative", value: item.SodPriceNative, dbType: DbType.Decimal,
                        direction: ParameterDirection.Input);
                    param.Add("@sodMarketValueNative", value: item.SodMarketValueNative, dbType: DbType.Decimal,
                        direction: ParameterDirection.Input);
                    param.Add("@multiplier", value: item.Multiplier, dbType: DbType.Decimal,
                        direction: ParameterDirection.Input);
                    param.Add("@currency", value: item.Currency, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@fxRate", value: item.FxRate, dbType: DbType.Decimal,
                        direction: ParameterDirection.Input);
                    param.Add("@country", value: item.Country, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@industry", value: item.Industry, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@underlyingSymbol", value: item.UnderlyingSymbol, dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    param.Add("@sysDate", value: item.SysDate, dbType: DbType.DateTime,
                        direction: ParameterDirection.Input);
                    itemsToInsert.Add(param);
                }

                await connection.ExecuteAsync("dbo.usp_InsertContingencyPosition", itemsToInsert,
                    commandType: CommandType.StoredProcedure);
            }
        }
    }
}
