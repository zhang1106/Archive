﻿using Bam.Oms.OrderGateway.Messages.RefDataGateway;
using CsvHelper.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway.File
{
    public sealed class SecurityMapping : CsvClassMap<SecurityInsert.SecurityInsertItem>
    {
        public SecurityMapping()
        {
            AutoMap();
            Map(r => r.Failed).Ignore();
            Map(r => r.Ticker).Ignore();
            Map(r => r.Currency).Name("TradingCurrency");//tODO: REMOVE CCY ON THE TOP LEVEL
        }
    }
}