﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Persistence.Compliance
{
    public interface IOgDataRepository
    {
        HashSet<string> GetEuExemptedIsins();

        IEnumerable<DtdPosition> GetEodPositions();

        bool IsContingencyPositionsSynced();

        bool IsSodPositionsSynced();

        IEnumerable<DtdPosition> GetAllSodPositions();

        IEnumerable<DtdPosition> GetLoadedSodPositions();

        void DumpPositions(IEnumerable<FlatPosition> positions);
    }


}
