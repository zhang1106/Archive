using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Schedulers;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.PositionTracker;
using Bam.Oms.ShortLocate;
using Bam.Oms.TradeMarker;
using BAM.Infrastructure.Ioc;
using Newtonsoft.Json;

namespace Bam.Oms.Service.Orders
{
    public class OrderProcessor : IOrderProcessor
    {
        private readonly IOrderMarker _orderMarker;
        private readonly IPositionTracker _positionTracker;
        private readonly IOrderRepository _orderRepository;
        private readonly IShortLocateService _shortLocateService;
        private readonly ILogger _logger;
        private readonly IEmsRouter _emsRouter;
        private readonly CancellationTokenSource _orderTaskCancellation = new CancellationTokenSource();
        private readonly ConcurrentDictionary<string, OrderedTaskScheduler> _orderSchedulers = new ConcurrentDictionary<string, OrderedTaskScheduler>();

        private readonly OrderedTaskScheduler _processorScheduler = new OrderedTaskScheduler();

        private long _totalOrdersProcessed = 0;
        public long TotalOrdersProcessed => _totalOrdersProcessed;

        public OrderProcessor(IOrderMarker orderMarker, IPositionTracker positionTracker, IOrderRepository orderRepository,
            IShortLocateService shortLocateService, ILogger logger, IEmsRouter emsRouter)
        {
            if (emsRouter == null) throw new ArgumentNullException("emsRouter");
            if (logger == null) throw new ArgumentNullException("logger");
            if (orderMarker == null) throw new ArgumentNullException("orderMarker");
            if (positionTracker == null) throw new ArgumentNullException("positionTracker");
            if (orderRepository == null) throw new ArgumentNullException("orderRepository");
            if (shortLocateService == null) throw new ArgumentNullException("shortLocateService");

            _orderMarker = orderMarker;
            _positionTracker = positionTracker;

            _orderRepository = orderRepository;            
            _shortLocateService = shortLocateService;
            _logger = logger;
            _emsRouter = emsRouter;

            _shortLocateService.InventoryFilled += ShortLocateClient_InventoryFilled;
        }

        public void Dispose()
        {
            _logger.Debug("Disposing order processor...");

            _orderTaskCancellation.Cancel();
            _shortLocateService.InventoryFilled -= ShortLocateClient_InventoryFilled;

            _logger.Debug("Disposed order processor...");
        }

        public IList<IOrder> MarkAndTrackOrder(IOrder order)
        {
            try
            {
                IList<IOrder> mkdOrders = _orderMarker.MarkOrder(order);
                foreach (IOrder mkdOrder in mkdOrders)
                {
                    _positionTracker.ApplyPositionUpdate(mkdOrder);
                    _orderRepository.Save((Order)mkdOrder);
                }
                return mkdOrders;
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error while marking order {0}. Exception {1}.", order.ToString(), ex);
                throw;
            }
        }

        public IList<IOrder> LocateShorts(IList<IOrder> markedOrders)
        {
            try
            {
                //make a sync call to get shorts
                var shortOrders = markedOrders.Where(o => o.Side == SideType.SellShort);
                var fullyLocatedShortOrders = LocateShortForOrdersWrap(shortOrders);

                //set the routed size for all these trades
                foreach (var orderToSubmit in fullyLocatedShortOrders)
                    orderToSubmit.RoutedSize = orderToSubmit.Size;

                //update the short located orders
                _orderRepository.Save(fullyLocatedShortOrders.Cast<Order>());
                return markedOrders;
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error while locating shorts for {0}. Exception {1}.", markedOrders.ToString(), ex);
                throw;
            }
        }

        public void ProcessNewOrder(IOrder order, string batchId = null)
        {
            Task.Factory.StartNew(() =>
            {
                Interlocked.Increment(ref _totalOrdersProcessed);
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return;
                }
                if (order.Size == 0 || order.Side == SideType.Unknown)
                {
                    _logger.Warn($"Ignoring an order of zero size or unknown side. Order:{order}.");
                    return;
                }
                try
                {
                    IList<IOrder> mkdOrders = _orderMarker.MarkOrder(order);
                    foreach (IOrder mkdOrder in mkdOrders)
                    {
                        _positionTracker.ApplyPositionUpdate(mkdOrder);
                    }

                    //make a sync call to get shorts
                    var shortOrders = mkdOrders.Where(o => o.Side == SideType.SellShort);
                    var fullyLocatedShortOrders = LocateShortForOrdersWrap(shortOrders);

                    //set the routed size for all these trades
                    foreach (var orderToSubmit in fullyLocatedShortOrders)
                        orderToSubmit.RoutedSize = orderToSubmit.Size;

                    //update the short located orders
                    _orderRepository.Save(fullyLocatedShortOrders.Cast<Order>());

                    IEnumerable<IOrder> orderStatus = _emsRouter.SubmitOrders(mkdOrders, batchId);
                    //Revert theoretical for any orders that were rejected or failed compliance
                    if (orderStatus.Any())
                    {
                        foreach (IOrder submittedOrder in orderStatus.Where(o => o.OrderStatus == BamOrderStatus.Rejected || o.OrderStatus == BamOrderStatus.FailedCompliance))
                        {
                            if (!RevertTheoreticalPosition(submittedOrder).Result)
                            {
                                _logger.ErrorFormat("Theoretical position may be incorrect because the order was NAK'ed and not reverted. Order: {0}.", submittedOrder);
                            }
                        }
                    }
                    else // All orders were rejected. backout all of them
                    {
                        foreach (IOrder submittedOrder in mkdOrders)
                        {
                            if (!RevertTheoreticalPosition(submittedOrder).Result)
                            {
                                _logger.ErrorFormat("Theoretical position may be incorrect because the order was NAK'ed and not reverted. Order: {0}.", submittedOrder);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.ErrorFormat("Error while processing order {0}. Exception {1}.", order.ToString(), ex);
                    return;
                }
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _orderSchedulers.GetOrAdd(order.Security.BamSymbol, _processorScheduler));
        }

        public Task ProcessNewOrders(IEnumerable<IOrder> orders, string batchId = null)
        {
            return Task.Factory.StartNew(() =>
            {
                var enumerable = orders as IOrder[] ?? orders.ToArray();

                var ordersToSubmit = MarkAndPositionTrackProcessOrders(enumerable, batchId);

                IEnumerable<IOrder> orderStatus = _emsRouter.SubmitOrders(ordersToSubmit, batchId);

                //Revert theoretical for any orders that were rejected or failed compliance
                if (orderStatus.Any())
                {
                    foreach (IOrder order in orderStatus.Where(o => o.OrderStatus == BamOrderStatus.Rejected || o.OrderStatus == BamOrderStatus.FailedCompliance))
                    {
                        if (!RevertTheoreticalPosition(order).Result)
                        {
                            _logger.ErrorFormat("Theoretical position may be incorrect because the order was NAK'ed and not reverted. Order: {0}.", order);
                        }
                    }
                }
                else // All orders were rejected. backout all of them
                {
                    foreach (IOrder order in orders)
                    {
                        if (!RevertTheoreticalPosition(order).Result)
                        {
                            _logger.ErrorFormat("Theoretical position may be incorrect because the order was NAK'ed and not reverted. Order: {0}.", order);
                        }
                    }
                }

            }, _orderTaskCancellation.Token, TaskCreationOptions.None, TaskScheduler.Default);
        }

        public Task ProcessReplaceOrder(IOrder replaceOrder)
        {
            Task returnTask = Task.Factory.StartNew(() =>
            {

                Order originalOrder = _orderRepository.Get(replaceOrder.OriginalOrderId);
                _orderRepository.Save((Order)replaceOrder);

                if (!RevertTheoreticalPosition(originalOrder).Result)
                {
                    _logger.ErrorFormat("Theoretical position may be incorrect because the original order was not reverted. Order: {0}.", originalOrder);
                    //Should we return here with a failure?
                }

                var order = replaceOrder;


                var markedOrders = MarkAndPositionTrackProcessOrders(new[] { order }).ToList();

                var originalOrderId = order.OriginalOrderId;

                var sameSideOrder = markedOrders.FirstOrDefault(o => o.Side == originalOrder.Side);
                var possibleSplit = markedOrders.FirstOrDefault(o => o.Side != originalOrder.Side);


                if (sameSideOrder != null)
                {
                    IOrder amendedOrder = _emsRouter.AmendOrder(sameSideOrder, originalOrderId);
                    if (amendedOrder != null && (amendedOrder.OrderStatus == BamOrderStatus.FailedCompliance ||
                        amendedOrder.OrderStatus == BamOrderStatus.Rejected))
                    {
                        if (!RevertTheoreticalPosition(amendedOrder).Result)
                        {
                            _logger.ErrorFormat("Theoretical position may be incorrect because the order was NAK'ed and not reverted. Order: {0}.", amendedOrder);
                        }
                        //Reapply oroginal order.
                        var revertedOrder = MarkAndUpdatePosition(originalOrder).Result;
                        return;
                    }
                }

                if (possibleSplit != null)
                {
                    var submittedOrders = _emsRouter.SubmitOrders(new[] { possibleSplit });
                    //Revert theoretical for any orders that were rejected or failed compliance
                    if (submittedOrders != null && submittedOrders.Any())
                    {
                        foreach (IOrder submittedOrder in submittedOrders.Where(o => o.OrderStatus == BamOrderStatus.Rejected || o.OrderStatus == BamOrderStatus.FailedCompliance))
                        {
                            _logger.ErrorFormat("Order partially amended. Original order {0}. Submitted order {1}, Rejected order {2}.", originalOrder, sameSideOrder, submittedOrder);
                            if (!RevertTheoreticalPosition(submittedOrder).Result)
                            {
                                _logger.ErrorFormat("Theoretical position may be incorrect because the order was NAK'ed and not reverted. Order: {0}.", submittedOrder);
                            }
                        }
                    }
                    else // Order was rejected. Revert
                    {
                        _logger.ErrorFormat("Order partially amended. Original order {0}. Submitted order {1}, Rejected order {2}.", originalOrder, sameSideOrder, possibleSplit);
                        if (!RevertTheoreticalPosition(possibleSplit).Result)
                        {
                            _logger.ErrorFormat("Theoretical position may be incorrect because the order was NAK'ed and not reverted. Order: {0}.", possibleSplit);
                        }

                    }
                }

            }, _orderTaskCancellation.Token, TaskCreationOptions.None, TaskScheduler.Default);

            return returnTask;
        }

        public Task ProcessCancelOrders(IEnumerable<string> orderIds)
        {
            return Task.Factory.StartNew(() =>
            {
                foreach (Order cancelledOrder in orderIds.Select(_orderRepository.Get))
                    _positionTracker.ApplyOrderCancel(cancelledOrder);

                _emsRouter.CancelOrders(orderIds.ToList());
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, TaskScheduler.Default);
        }

        public Task RouteOrder(string orderId)
        {
            Task returnTask = Task.Factory.StartNew(() =>
            {
                //not sure if this is where we want to handle this....
                var order = _orderRepository.Get(orderId);

                if (order != null)
                {
                    if (order.OrderStatus == BamOrderStatus.Marked)
                    {
                        if (order.Side == SideType.SellShort)
                        {
                            if (order.Locate != null)
                            {
                                _logger.InfoFormat("Updating routed order to be the partial locate size {0} for order id {1}", order.Locate.Sum(r=>r.Size), order.ClientOrderId);
                                order.RoutedSize = order.Locate.Sum(l => l.Size);
                            }
                            else
                            {
                                _logger.InfoFormat("Short order has no locate for order id {0}, nothing to route.", order.ClientOrderId);
                            }
                        }
                        else
                        {
                            _logger.InfoFormat("Routing full order size of {0} for order id {1}", order.Size, order.ClientOrderId);
                            order.RoutedSize = order.Size;
                        }

                        _emsRouter.SubmitOrders(new[] { order });
                    }
                    else
                    {
                        _logger.InfoFormat("Order has not been marked properly for order id {0}", order.ClientOrderId);
                        order.Note = "Unable to route order; Order has not been marked";
                    }

                    _orderRepository.Save(order);
                }
                else
                {
                    _logger.InfoFormat("No order exists in the gateway for order id {0}, nothing to route.", orderId);
                }
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, TaskScheduler.Default);

            return returnTask;
        }

        public Task RebuildOrderCache()
        {
            return Task.Factory.StartNew(async () =>
            {

                _logger.Info("Getting open orders from OMS ......");
                //Get all activity from OMS
                var openOrders = _emsRouter.GetOpenOrders();

                //Get all activity as per the local repository
                var gatewayOrders = _orderRepository.Get(DateTime.Today);

                //Orders that went past this gateway, but have not made it to the OMS
                var unknownOrders = FindMissingOrders(gatewayOrders, openOrders);
                if (unknownOrders.Any())
                {
                    _logger.Info($"Submitting {unknownOrders.Count()} order(s) that were not present in the ems.");
                    await ProcessNewOrders(unknownOrders.ToList());
                }

                //this may be removed, depends on whether this situation is in scope where a user can put in an order 
                //that bypasses the gateway
                var remainingOrders = RemoveUnknownOrders(gatewayOrders, openOrders);
                if (remainingOrders.Any())
                {
                    foreach (IOrder order in remainingOrders)
                    {
                        _orderRepository.Save((Order)order);
                    }
                }
            });
        }

        protected IEnumerable<IOrder> FindMissingOrders(IEnumerable<IOrder> gatewayOrders, IEnumerable<IOrder> emsOrders)
        {
            if (gatewayOrders == null || emsOrders == null || gatewayOrders.Count() == emsOrders.Count())
                return new List<IOrder>();

            return gatewayOrders.Except(emsOrders).ToList();
        }

        protected IEnumerable<IOrder> RemoveUnknownOrders(IEnumerable<IOrder> gatewayOrders, IEnumerable<IOrder> emsOrders)
        {
            if (gatewayOrders == null || emsOrders == null || gatewayOrders.Count() == emsOrders.Count())
                return new List<IOrder>();

            return gatewayOrders.Intersect(emsOrders);
        }

        protected IEnumerable<IOrder> MarkAndPositionTrackProcessOrders(IEnumerable<IOrder> orders, string batchId = null)
        {
            if (_orderTaskCancellation.Token.IsCancellationRequested)
            {
                _logger.Info("Cancellation requested. Aborting task...");
                return null;
            }

            try
            {
                //Mark and register the order with the position tracker
                ConcurrentStack<IOrder> finalOrdersToSubmit = new ConcurrentStack<IOrder>();
                Parallel.ForEach(orders, () => new List<IOrder>(),
                    (order, loopState, partialResult) => MarkAndTrackSingleOrder(order, partialResult),
                    (localPartialSum) =>
                    {
                        if (localPartialSum.Any())
                        {
                            finalOrdersToSubmit.PushRange(localPartialSum.ToArray());
                        }
                    });

                //TODO: DO NOT DELETE THIS COMMENTED CODE. Rohit is working with Flex to figure out how to eliminate duplicates.
                //var groupedOrders =
                //    finalOrdersToSubmit.GroupBy(order => new {order.BatchId, order.Portfolio, order.Security, order.Side, order.Custodian, order.ExecutionInstructions}).Select(g => new Order()
                //    {
                //        BatchId = g.Key.BatchId,
                //        Portfolio = g.Key.Portfolio,
                //        Security = g.Key.Security,
                //        Side = g.Key.Side,
                //        Custodian = g.Key.Custodian,
                //        ExecutionInstructions = g.Key.ExecutionInstructions,
                //        RoutedSize = g.Sum(o => o.RoutedSize),
                //        ClientOrderId = g.Min(o => o.ClientOrderId),                        
                //    }).ToList();

                //Remove the order that has been grouped above

                //make a sync call to get shorts
                var shortOrders = finalOrdersToSubmit.Where(o => o.Side == SideType.SellShort);
                var fullyLocatedShortOrders = LocateShortForOrdersWrap(shortOrders);

                //set the routed size for all these trades
                foreach (var orderToSubmit in fullyLocatedShortOrders)
                    orderToSubmit.RoutedSize = orderToSubmit.Size;

                //update the short located orders
                _orderRepository.Save(fullyLocatedShortOrders.Cast<Order>());

                return finalOrdersToSubmit;
            }
            catch (Exception ex)
            {
                _logger.Error("Exception while processing orders.", ex);
                throw;
            }
        }

        private List<IOrder> MarkAndTrackSingleOrder(IOrder order, List<IOrder> partialResult)
        {
            IList<IOrder> mkdOrders;

            try
            {
                mkdOrders = MarkAndUpdatePosition(order).Result;
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    // Handle the cancelled tasks
                    TaskCanceledException tcex = ex as TaskCanceledException;
                    if (tcex != null)
                    {
                        //Treat task cancellation as Info
                        _logger.InfoFormat("Mark and update task cancelled. Task Id {0}.", tcex.Task.Id);
                        return true;
                    }

                    _logger.ErrorFormat("Subscription thread has failed {0} - {1} ", ex.Message, ex.StackTrace);
                    return false;
                });
                return partialResult;
            }

            foreach (IOrder mkdOrder in mkdOrders)
            {
                _orderRepository.Save((Order)mkdOrder);
                partialResult.Add(mkdOrder);
            }

            //set the routed size for all these trades
            foreach (var orderToSubmit in partialResult.Where(o => o.Side != SideType.SellShort)) //only update routed size for non-shorts, they locates will be batched after this method
                orderToSubmit.RoutedSize = orderToSubmit.Size;

            _orderRepository.Save(partialResult.Cast<Order>());
            return partialResult;
        }


        private async Task<IList<IOrder>> MarkAndUpdatePosition(IOrder order)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                if (order.Size == 0 || order.Side == SideType.Unknown)
                {
                    _logger.Warn($"Ignoring an order of zero size or unknown side. Order:{order.ToString()}.");
                    return null;
                }
                try
                {
                    IList<IOrder> mkdOrders = _orderMarker.MarkOrder(order);
                    foreach (IOrder mkdOrder in mkdOrders)
                    {
                        _positionTracker.ApplyPositionUpdate(mkdOrder);
                    }
                    return mkdOrders;
                }
                catch (Exception ex)
                {
                    _logger.ErrorFormat("Error while processing order {0}. Exception {1}.", order.ToString(), ex);
                    return null;
                }
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _orderSchedulers.GetOrAdd(order.Security.BamSymbol, new OrderedTaskScheduler()));
        }

        private async Task<bool> RevertTheoreticalPosition(IOrder order)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return false;
                }
                if (order.Size == 0 || order.Side == SideType.Unknown)
                {
                    _logger.Warn(
                        $"Ignoring RevertTheoreticalPosition of an order of zero size or unknown side. Order:{order.ToString()}.");
                    return true;
                }
                try
                {
                    _logger.InfoFormat("Reverting order {0}.", order);
                    _positionTracker.ApplyOrderCancel(order);
                    _logger.InfoFormat("Completed reverting order {0}.", order);
                    return true;
                }
                catch (Exception ex)
                {
                    _logger.ErrorFormat("Error while processing RevertTheoreticalPosition of order {0}. Exception {1}.", order.ToString(), ex);
                    return false;
                }
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _orderSchedulers.GetOrAdd(order.Security.BamSymbol, new OrderedTaskScheduler()));
        }

        private IEnumerable<IOrder> LocateShortForOrdersWrap(IEnumerable<IOrder> shortOrders)
        {
            //request short locate, completely filled orders will go downstream
            var shortLocateRequests = shortOrders.Select(s => new LocateRequest(s, s.Custodian));

            if (!shortLocateRequests.Any()) return new List<IOrder>(); //return an empty list

            var locateResponses = _shortLocateService.RequestForInventory(shortLocateRequests);
            return locateResponses.Select(r => r.OriginalRequest.Order).Where(r => r.LocateStatus == LocateStatus.Filled);
        }

        protected Task ShortLocateClient_InventoryFilled(IList<ILocateResponse> filledResponses)
        {
            var ordersToSubmit = filledResponses.Select(r => r.OriginalRequest.Order);

            _logger.InfoFormat("Sending short orders that have filled locates {0}", ordersToSubmit.Count());

            foreach (var order in ordersToSubmit)
                order.RoutedSize = order.Size;

            return Task.Factory.StartNew(() => _emsRouter.SubmitOrders(ordersToSubmit), _orderTaskCancellation.Token, TaskCreationOptions.None, TaskScheduler.Default);
        }
    }
}