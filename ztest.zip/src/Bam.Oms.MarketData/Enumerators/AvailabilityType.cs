﻿namespace Bam.Oms.MarketData.Enumerators
{
    public enum AvailabilityType
    {
        Available = 0,
        Unavailable = 1,
        Unknown = 2
    }
}
