﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Bam.Oms.Filtering
{
    public class Operator
    {
        [JsonConverter(typeof(StringEnumConverter))]
        public OperatorType OperatorType{get; set;}

        public virtual bool Equal(IComparable left, IComparable right)
        {
            if (left == null || right == null) return false;
            if (left.GetType() != right.GetType())
            {
                return string.Compare(left.ToString(), right.ToString(), StringComparison.InvariantCultureIgnoreCase)==0;
            }
            return left.CompareTo(right) == 0;
        }

        public virtual bool NotEqual(IComparable left, IComparable right)
        {
            if (left == null || right == null) return false;
            return left.CompareTo(right) != 0;
        }

        public virtual bool InList(IComparable t, IEnumerable<IComparable> list)
        {
            if (t == null || list == null) return false;
            return list.Any(item => item.CompareTo(t) == 0);
        }

        public virtual bool Contains(IComparable left, IComparable right)
        {
            if (left == null || right == null) return false;
            var leftString = left.ToString().ToUpperInvariant();
            var rightString = right.ToString().ToUpperInvariant();
            return leftString.Contains(rightString);
        }

        public virtual bool StartsWith(IComparable left, IComparable right)
        {
            if (left == null || right == null) return false;
            var leftString = left.ToString().ToUpperInvariant();
            var rightString = right.ToString().ToUpperInvariant();
            return leftString.StartsWith(rightString);
        }

        public virtual bool InTheList(IComparable t, IComparable listName)
        {
            throw new NotImplementedException();
        }

        public virtual bool NotInTheList(IComparable t, IComparable listName)
        {
            throw new NotImplementedException();
        }
    }
}
