﻿using System;
using Bam.EventQ.Integration;
using Bam.EventQ.Journal;
using Bam.EventQ.Pipeline.Dsl;
using Bam.EventQ.Recovery;
using Bam.EventQ.Time;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pipeline
{
    public static class QueueItemHandlerDslExtensions
    {
        public static PipelineQueueItemHandlerChainDsl<TItem> If<TItem>(
            this PipelineQueueItemHandlerChainDsl<TItem> dsl, Func<bool> predicate,
            Action<PipelineQueueItemHandlerChainDsl<TItem>> then)
        {
            if (predicate()) then(dsl);
            return dsl;
        }

        public static ProcessingPipelineStepDsl<TItem> If<TItem>(
            this ProcessingPipelineStepDsl<TItem> dsl, Func<bool> predicate,
            Action<ProcessingPipelineStepDsl<TItem>> then)
        {
            if (predicate()) then(dsl);
            return dsl;
        }

        public static ProcessingPipelineDsl If(this ProcessingPipelineDsl dsl,
            Func<bool> predicate, Action<ProcessingPipelineDsl> then) 
        {
            if (predicate()) then(dsl);
            return dsl;
        }

        public static PipelineQueueItemHandlerChainDsl<TItem> If<TItem>(
            this PipelineQueueItemHandlerChainDsl<TItem> dsl, bool predicate,
            Action<PipelineQueueItemHandlerChainDsl<TItem>> then) 
        {
            if (predicate) then(dsl);
            return dsl;
        }

        public static ProcessingPipelineStepDsl<TItem> If<TItem>(
            this ProcessingPipelineStepDsl<TItem> dsl, bool predicate,
            Action<ProcessingPipelineStepDsl<TItem>> then) 
        {
            if (predicate) then(dsl);
            return dsl;
        }

        public static ProcessingPipelineDsl If(this ProcessingPipelineDsl dsl,
            bool predicate, Action<ProcessingPipelineDsl> then) 
        {
            if (predicate) then(dsl);
            return dsl;
        }

        public static PipelineQueueItemHandlerChainDsl<TItem> ValidateSequenceNumbers<TItem>(
            this PipelineQueueItemHandlerChainDsl<TItem> dsl, IClock clock, IRecoveryInvoker recoveryInvoker, TimeSpan recoveryTimeout, 
            Func<PipelineQueueItem<TItem>, SequenceInfo> seqInfoFunc, int selfSourceId)
        {
            dsl.AddHandler(new ValidateSequenceNumberHandler<TItem>(clock, recoveryInvoker, recoveryTimeout, seqInfoFunc, selfSourceId));
            return dsl;
        }

        public static PipelineQueueItemHandlerChainDsl<TItem> Journal<TItem>(
            this PipelineQueueItemHandlerChainDsl<TItem> dsl, IJournal journal)
        {
            dsl.AddHandler(new JournalHandler<TItem>(journal));
            return dsl;
        }

        public static ProcessingPipelineStepDsl<TOut> AddExternalSource<TIn, TOut>(
            this ProcessingPipelineStepDsl<TOut> dsl,
            IExternalMessageSource<TIn> source,
            IExternalMessageTransform<TIn, TOut> transform)
        {
            dsl.AddProducer(new TransformingQueueItemProducer<TIn, TOut>(source, transform));
            return dsl;
        }
    }
}
