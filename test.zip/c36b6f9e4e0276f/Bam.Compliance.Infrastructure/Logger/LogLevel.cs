﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Compliance.Infrastructure.Logger
{
    public enum LogLevel
    {
        Debug,
        Information,
        Warning,
        Error
    }
}
