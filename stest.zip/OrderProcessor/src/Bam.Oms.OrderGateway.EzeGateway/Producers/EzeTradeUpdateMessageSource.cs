﻿using System.Collections.Generic;
using Bam.EventQ.Integration;
using Bam.EventQ.Throttling;
using Bam.Oms.OrderGateway.EzeGateway.Models;
using Bam.Oms.OrderGateway.EzeGateway.Services;

namespace Bam.Oms.OrderGateway.EzeGateway.Producers
{
    public class EzeTradeUpdateMessageSource : ExternalMessageSourceBase<TradeUpdateDto>, IEzeUpdateSubmission
    {
        private readonly IThrottledBatchHandler<TradeUpdateDto> _handler;

        public EzeTradeUpdateMessageSource()
        {
            _handler = null;
        }

        public EzeTradeUpdateMessageSource(IThrottledBatchHandler<TradeUpdateDto> handler)
        {
            _handler = handler;
        }

        public void Submit(TradeUpdateDto message)
        {
            _handler?.Handle(new List<TradeUpdateDto> {message});
            Handler?.Invoke(message);
        }
    }
}
