﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.EndPoints.Http;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Compliance;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.EndPoints.Compliance
{
    public class RuleController : BaseController
    {
        private readonly IRuleRepository<CompliancePosition> _ruleRepository;

        public RuleController(IRuleRepository<CompliancePosition> ruleRepository, IHostConfiguration hostConfiguration, ILogger logger)
            : base(hostConfiguration, logger)
        {
            _ruleRepository = ruleRepository;
        }

        [AccessRequire("Function.OrderGateway.Compliance.Read, Function.OrderGateway.Compliance.Write")]
        public IList<Rule<CompliancePosition>> Get()
        {
            var rules = _ruleRepository.GetAll();

            return rules.ToList();
        }

        [AccessRequire("Function.OrderGateway.Compliance.Read, Function.OrderGateway.Compliance.Write")]
        public IList<Rule<CompliancePosition>> Get(bool populateJson)
        {
            if (populateJson)
            {
                IList<Rule<CompliancePosition>> pList = new List<Rule<CompliancePosition>>();
                foreach (var rule in _ruleRepository.GetAll())
                {
                    var nRule = (FirmRuleBase) ConvertBaseToChild.Map(rule);
                    nRule.Init();
                    pList.Add(nRule);
                }
                return pList;
            }
            else
            {
                return Get();
            }
        }
    }
}
