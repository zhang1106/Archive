﻿using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Sequencing
{
    public abstract class QueueItemProducerBase : QueueItemProducerBase<PipelineQueueItem<IMessage>>
    {
        private readonly IQueueMessageDispatcher _dispatcher;
        private bool _started;

        protected QueueItemProducerBase(IQueueMessageDispatcher dispatcher)
        {
            _dispatcher = dispatcher;
        }

        protected void Publish(IMessage message)
        {
            if (!_started)
            {
                Started.WaitOne();
                _started = true;
            }

            if (!Stopped)
            {
                _dispatcher.Dispatch(Queue, message);
            }
        }
    }
}
