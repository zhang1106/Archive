﻿CREATE TABLE [cp].[Rule] (
    [Id]             INT           IDENTITY (1, 1) NOT NULL,
    [Name]           VARCHAR (100) NOT NULL,
    [Type]           VARCHAR (100) NULL,
    [Description]    VARCHAR (200) NULL,
    [IsActive]       BIT           NOT NULL,
    [StartDate]      DATETIME      NULL,
    [EndDate]        DATETIME      NULL,
    [ParamsInJson]   VARCHAR (MAX) NULL,
    [CreatedOn]      DATETIME      NOT NULL,
    [CreatedBy]      VARCHAR (50)  NULL,
    [LastModifiedOn] DATETIME      NOT NULL,
    [LastModifiedBy] VARCHAR (50)  NULL,
    CONSTRAINT [PK__Rule__110458E21A9EF37A] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IDX_Name]
    ON [cp].[Rule]([Name] ASC);

