﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance
{
    public interface IFirmPositionComplianceSvc
    {
        void Init();
        void Run();
        List<IRuleResult> FirmWideComplianceResult
        { get;}
    }
}
