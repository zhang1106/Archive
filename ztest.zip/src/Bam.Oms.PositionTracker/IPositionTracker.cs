﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.PositionTracker
{
    public interface IPositionTracker
    {
        IEnumerable<IPosition> GetCurrentPositions();
        IEnumerable<IPosition> GetCurrentPositions(string bamSymbol);
        IEnumerable<IAggUnitPosition> GetAggUnitPositions();
        IEnumerable<IAggUnitPosition> GetAggUnitPositions(string bamSymbol);
        IEnumerable<ICompliancePosition> GetCompliancePositions();
        IEnumerable<ICompliancePosition> GetCompliancePositions(string bamSymbol);

        //Modifies actual
        IPosition ApplyPositionUpdate(IBlockTrade trade);

        //Modifies Theoretical
        IPosition ApplyOrderUpdate(IOrder order);

        //Overrides SOD position
        ICollection<IPosition> UpdateSODPositions(IEnumerable<IPosition> positions);
        ICollection<IPosition> LoadSODPositions(IEnumerable<IPosition> positions, IDictionary<IPositionKey, IList<IOrder>> orders, IDictionary<IPositionKey, IList<IBlockTrade>> trades);

        //Overrides Current position
        ICollection<IPosition> UpdatePositions(IEnumerable<IPosition> positions);

        int SavePositions(ref DateTime cutOffTime);

        void ClearPositions(string stream, IReadOnlyList<string> symbols);

        event Action<IList<IPosition>, PositionUpdate> SodPositionUpdate;
        event Action<IList<IPosition>, PositionUpdate> PositionUpdate;
    }
}
