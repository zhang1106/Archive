﻿using System.Linq;
using Bam.Oms.Compliance.DataProvider;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{

    [Category("Integration")]
    [TestFixture()]
    [Ignore("integration")]
    public class OGPositionTest 
    {
        [Test]
        public void VerifyOgPositionGet()
        {
            var baseUrl = "http://ems-gtwy2:9072";
            var dataRetriver = new JsonDataProvider();
            var positions = dataRetriver.GetPositions(baseUrl);

            Assert.IsTrue(positions.Any());
        }
       
    }
}