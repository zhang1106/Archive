﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Pipeline
{
    public class PipelineQueueItemFactory<TItem> : IQueueItemFactory<PipelineQueueItem<TItem>>
    {
        private const int TwoGig = 2147483591; // magic number from .NET
        private readonly int _bufferSize, _slotsPerChunk;
        private readonly byte[][] _chunks;
        private int _nextSlot = -1;
        
        public PipelineQueueItemFactory(int ringSize, int bufferSize)
        {
            var maxArraySize = TwoGig / Marshal.SizeOf<byte>();
            _bufferSize = bufferSize;            
            _slotsPerChunk = maxArraySize / bufferSize;
            int chunks = ringSize / _slotsPerChunk;
            if (ringSize % _slotsPerChunk > 0) chunks++;

            _chunks = new byte[chunks][];
            for (int i = 0; i < chunks; i++)
            {
                int chunkSize = i + 1 == chunks
                    ? (ringSize%_slotsPerChunk)*bufferSize
                    : bufferSize*_slotsPerChunk;
                _chunks[i] = new byte[chunkSize];
            }
        }
        
        public PipelineQueueItem<TItem> Create()
        {
            int slot = Interlocked.Increment(ref _nextSlot);
            int chunk = slot / _slotsPerChunk;
            int offset = (slot % _slotsPerChunk) *_bufferSize;

            var buffer = new ArraySegment<byte>(_chunks[chunk], offset, _bufferSize);
            return new PipelineQueueItem<TItem>(buffer);            
        }
    }
}
