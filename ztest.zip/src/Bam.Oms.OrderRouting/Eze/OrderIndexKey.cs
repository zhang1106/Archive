﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.OrderRouting.EZE
{
    public struct OrderIndexKey
    {
        public string TradeId { get; set;}
        public string Strategy { get; set; }

        public string Symbol { get; set; }

        public OrderIndexKey(string tradeId, string strategy, string symbol )
        {
            TradeId = tradeId;
            Strategy = strategy;
            Symbol = symbol;
        }
    }
}
