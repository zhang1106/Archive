﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.RestApi;
using Bam.Oms.Data.Securities;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.Securities
{
    public class SecurityController : BaseController, ISecurityController
    {
        private readonly ISecurityRepository _repository;
        private readonly ISecurityMasterService _securityMasterService;

        public SecurityController(ISecurityRepository repository, IHostConfiguration hostConfiguration, ISecurityMasterService securityMasterService, ILogger logger)
            : base(hostConfiguration, logger)
        {
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));
            _repository = repository;
            _securityMasterService = securityMasterService;
        }

        [AccessRequire("Function.OrderGateway.Security.Read, Function.OrderGateway.Security.Write")]
        public List<Security> Get()
        {            
            return Get(null);
        }

        [AccessRequire("Function.OrderGateway.Security.Read, Function.OrderGateway.Security.Write")]
        public List<Security> Get(DateTime? cutoffTime)
        {
            cutoffTime = !cutoffTime.HasValue ? DateTime.Today.ToUniversalTime() : cutoffTime.Value.ToUniversalTime();
            return _repository.Get(cutoffTime.GetValueOrDefault()).ToList();
        }

        [AccessRequire("Function.OrderGateway.Security.Write")]
        public int Delete(DateTime? cutoffTime)
        {
            cutoffTime = !cutoffTime.HasValue ? DateTime.UtcNow : cutoffTime.Value.ToUniversalTime();
            return _repository.Clear(cutoffTime.GetValueOrDefault());
        }
    }
}
