﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class OrderScalingRule : ModelBase<object>, ICloneable
    {
        public int Id { get; set; }
        public Portfolio SourceStrategy { get; set; }
        public Portfolio TargetStrategy { get; set; }
        public SecurityType? SecurityType { get; set; }
        public decimal Ratio { get; set; }
        public bool IsActive { get; set; }
        public List<string> ExcludedSymbols { get; private set; } = new List<string>();

        public object Clone()
        {
            return new OrderScalingRule
            {
                Id = Id,
                SecurityType = SecurityType,
                SourceStrategy = (Portfolio) SourceStrategy.Clone(),
                TargetStrategy = (Portfolio) TargetStrategy.Clone(),
                Ratio = Ratio,
                IsActive = IsActive,
                ExcludedSymbols = new List<string>(ExcludedSymbols)
            };
        }
    }
}
