﻿using System;
using System.IO;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Time;

namespace Bam.EventQ.Journal
{
    public class FileArchive : IFileArchive
    {
        private readonly IClock _clock;
        private readonly string _archiveDirectory;

        public ILogger Logger { get; set; }

        public FileArchive(IClock clock, string archiveDirectory)
        {
            if (clock == null) throw new ArgumentNullException(nameof(clock));
            _clock = clock;
            _archiveDirectory = archiveDirectory;
        }

        public void Archive(string sourcePath)
        {
            string path = GetArchiveFilePath(sourcePath);
            Logger?.LogInformation($"Archiving file '{sourcePath}' to {path}");
            File.Move(sourcePath, path);
        }

        private string GetArchiveFilePath(string sourcePath)
        {
            var fileName = Path.GetFileName(sourcePath);
            var archivePathWithDate = Path.Combine(
                _archiveDirectory, _clock.Now.ToString("yyyyMMdd"));

            if (!Directory.Exists(archivePathWithDate))
                Directory.CreateDirectory(archivePathWithDate);

            return Path.Combine(archivePathWithDate,
                $"{fileName}.{_clock.Now:HHmmssffff}");
        }

        public void Archive(IJournal journal)
        {
            string path = GetArchiveFilePath(journal.Path);
            Logger?.LogInformation($"Archiving journal '{journal.Path}' to {path}");
            journal.Truncate(path);
        }
    }
}