﻿using System;
using Bam.EventQ.Diagnostics;
using SolaceSystems.Solclient.Messaging;
using SolaceSystems.Solclient.Messaging.Cache;

namespace Bam.EventQ.Solace
{
    public class SolaceContextWrapper : IDisposable
    {
        private readonly SolaceOptions _options;
        private readonly ILogger _logger;

        public SolaceContextWrapper(SolaceOptions options, ILogger logger)
        {
            _options = options;
            _logger = logger;
            ContextFactory.Instance.Init(new ContextFactoryProperties
            {
                SolClientLogLevel = SolLogLevel.Info,
                LogDelegate = log =>
                {
                    switch (log.LogLevel)
                    {
                        case SolLogLevel.Emergency:
                        case SolLogLevel.Alert:
                        case SolLogLevel.Critical:
                        case SolLogLevel.Error:
                            logger.LogError("SOLACE: " + log.LogMessage, log.LogException);
                            break;
                        case SolLogLevel.Warning:
                        case SolLogLevel.Notice:
                            logger.LogWarning("SOLACE: " + log.LogMessage, log.LogException);
                            break;
                        case SolLogLevel.Info:
                        case SolLogLevel.Debug:
                            logger.LogDebug("SOLACE: " + log.LogMessage, log.LogException);
                            break;
                    }
                }
            });

            Context = ContextFactory.Instance.CreateContext(
                new ContextProperties(),
                (sender, args) =>
                {
                    logger.LogError($"SOLACE: {args.ErrorInfo?.ErrorStr}: {args.ErrorInfo?.SubCode}", args.Exception);
                });
        }

        public ContextFactory Factory => ContextFactory.Instance;
        public IContext Context { get; }

        public ISession CreateSession(EventHandler<MessageEventArgs> messageHandler)
        {
            return Context.CreateSession(_options.ToSessionProperties(),
                messageHandler, OnSessionEvent);
        }

        public ICacheSession CreateCacheSession(ISession session)
        {
            if (_options.CacheName == null)
                return null;

            return session.CreateCacheSession(_options.ToCacheSessionProperties());
        }

        private void OnSessionEvent(object sender, SessionEventArgs args)
        {
            _logger.LogDebug($"SOLACE: {args.Event} {args.Info}");
        }

        public void Dispose()
        {
            Context.Dispose();
            ContextFactory.Instance.Cleanup();
        }
    }
}
