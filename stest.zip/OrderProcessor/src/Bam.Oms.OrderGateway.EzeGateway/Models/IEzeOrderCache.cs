﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public interface IEzeOrderCache
    {
        List<EzeOrder> GetOrdersByEzeTradeId(string tradeId);
        EzeOrder GetOrder(OrderIndexKey key);
        EzeOrder GetByExternalId(long externalId);
        void Save(EzeOrder order);
     }
}
