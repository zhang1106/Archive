﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IIntradayPositionProvider : IDataProvider
    {
        IEnumerable<IPosition> Positions { get;  }
        /// <summary>
        /// get all the underlying securities of current positions
        /// cos we only check at underlying security level
        /// </summary>
        /// <returns></returns>
        IEnumerable<ISecurity> GetUnderlyingSecurities();
        Tuple<string, decimal?> GetFirmWideLongQuantity(string underlying);
        Tuple<string, decimal?> GetFirmWideShortQuantity(string underlying );
        Tuple<string, decimal?> GetFirmWideNetQuantity(string underlying);
    }
}
