﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Compliance.ApiGateway.Models
{
    public class AccessToken
    {
        public string access_token { get; set; }
    }
}
