﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Web.Http;
using System.Configuration;
using System.Security.Principal;
using Bam.Oms.EndPoints.PermissionService;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.Http
{
    
    public class BaseController : ApiController
    {
        private readonly string baseUrl;
        protected readonly ILogger _logger;        

        public BaseController(IHostConfiguration hostConfiguration, ILogger logger)
        {
            _logger = logger;            
            baseUrl = hostConfiguration.BaseUrl + "/api/" + GetType().Name.Replace("Controller", "") + "/";
        }

        [HttpGet]
        public List<string> About()
        {
            var actions = new List<string>();

            var type = GetType();

            foreach (var method in type.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly))
            {
                if(!method.Name.ToLower().StartsWith("get")) continue;

                var action = baseUrl + method.Name;

                if (method.GetParameters().Any())
                    action += "?";

                for (int index = 0; index < method.GetParameters().Length; index++)
                {
                    var parm = method.GetParameters()[index];
                    action += parm.Name + "=" + parm.ParameterType;

                    if (index < method.GetParameters().Length - 1)
                        action += "&";
                }

                actions.Add(action);
            }

            return actions;
        }

        protected StrategyInfo[] GetPermissionedStrategies(IIdentity user)
        {
            return PermissionChecker.GetPermissionedStrategies(user);
        }        
    }
}