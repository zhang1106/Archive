﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using SolaceSystems.Solclient.Messaging;

namespace Bam.EventQ.Solace
{
    internal class SolacePublisher : IDisposable
    {
        public const int MaxBatchSize = 50; // Solace constant

        private readonly ISession _session;
        private readonly IMessage[] _outBuffer;

        public SolacePublisher(SolaceContextWrapper contextWrapper)
        {
            _session = contextWrapper.CreateSession(null);
            _outBuffer = new IMessage[MaxBatchSize];
        }

        public ILogger Logger { get; set; }

        public void Connect()
        {
            var code = _session.Connect();
            if (code != ReturnCode.SOLCLIENT_OK)
            {
                Logger.LogError($"Failed to connect to Solace: {code}");
            }
        }
        
        public int Publish(IReadOnlyList<IMessage> batch, int index, int count)
        {
            int successful = 0;
            int end = index + count;
            for (int i = 0; i < end; i += MaxBatchSize)
            {
                int size = i + MaxBatchSize <= end ? MaxBatchSize : end - i;

                for (int j = 0; j < size; j++)
                {
                    _outBuffer[j] = batch[j + i];
                    _outBuffer[j].DeliveryMode = MessageDeliveryMode.NonPersistent;
                }

                int sent;
                var code = _session.Send(_outBuffer, 0, size, out sent);
                if (code != ReturnCode.SOLCLIENT_OK)
                {
                    Logger?.LogError($"Failed to publish to Solace: {code}");
                }

                successful += sent;
                for (int j = 0; j < sent; j++)
                {
                    _outBuffer[j].Dispose();
                }

                if (sent < size)
                {
                    break;
                }
            }

            Array.Clear(_outBuffer, 0, _outBuffer.Length);
            return successful;
        }

        public void Dispose()
        {
            _session.Dispose();
        }
    }
}
