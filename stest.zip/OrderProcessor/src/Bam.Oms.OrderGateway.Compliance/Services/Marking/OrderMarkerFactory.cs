﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.Compliance.Services.Marking
{
    public class OrderMarkerFactory : IOrderMarkerFactory
    {
        private readonly IOrderMarker _fallback;
        private readonly Dictionary<string, IOrderMarker> _cache;

        public OrderMarkerFactory(IEnumerable<IOrderMarker> markers, IOrderMarker fallback)
        {
            _fallback = new OmniMarkerDecorator(fallback);
            _cache = new Dictionary<string, IOrderMarker>();
            foreach (var m in markers)
            {
                foreach (var st in m.SupportedSecurityTypes)
                {
                    _cache[st] = new OmniMarkerDecorator(m);
                }
            }
        }

        public IOrderMarker Create(string securityType)
        {
            IOrderMarker marker;
            if (securityType == null || !_cache.TryGetValue(securityType, out marker))
            {
                marker = _fallback;
            }

            return marker;
        }
    }
}