﻿using System.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    [DebuggerDisplay("({Key}) = {ShortMarkingQuantity}")]
    public class AggUnitPosition : ModelBase<IMessage>
    {
        public AggUnitPosition(AggUnitKey key, long id, long shortMarkingQty = 0)
        {
            Key = key;
            PositionId = id;
            ShortMarkingQuantity = shortMarkingQty;
        }

        public AggUnitKey Key { get; }
        public long PositionId { get; set; }
        public long ShortMarkingQuantity { get; private set; }
        public bool IsFlat => ShortMarkingQuantity == 0;

        public long ApplyShortMarkingEffect(long effect)
        {
            if (effect != 0)
            {
                ShortMarkingQuantity += effect;
                Publish(new ShortMarkingPositionUpdated(PositionId, ShortMarkingQuantity));
            }

            return ShortMarkingQuantity;
        }
    }
}
