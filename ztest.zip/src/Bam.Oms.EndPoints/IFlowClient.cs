﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using BAM.Common.Messaging;

namespace Bam.Oms.EndPoints
{
    [Flags]
    public enum FlowClientScope
    {
        Contingency = 1,
        Ems = 2,
        Both = Contingency | Ems
    }

    public interface IFlowClient : IDisposable
    {
        void PublishOrders(IList<IOrder> orders);

        void PublishTrades(IList<IBlockTrade> trades);

        void PublishPositions(IList<IPosition> positions, DateTime nextBusinessDay);

        FlowClientScope Scope { get; }

        void PublishEzeOrders(IList<string> message, string route);
        
        void SubscribeEzeOrders();
        
        event Action<Message<string>> ObjectUpdated;
    }

    public static class FlowClientExtensions
    {
        public static IEnumerable<IFlowClient> OfScope(this IEnumerable<IFlowClient> clients, FlowClientScope scope)
        {
            foreach (var fc in clients)
            {
                if ((fc.Scope & scope) != 0)
                    yield return fc;
            }
        }
    }
}
