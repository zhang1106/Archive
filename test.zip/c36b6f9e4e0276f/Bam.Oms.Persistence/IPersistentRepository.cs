﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data;

namespace Bam.Oms.Persistence
{
    public interface IPersistentRepository<T> : IRepository<T> where T : IPersistentItem
    {
        string Name { get; }

        //ONLY A PLACE HOLDER, TODO: REMOVE ONCE WE BREAK APART SAVE/GET INTERFACES
        //this is going to be refactored out, this is only for integrating the hub
        event Action<IEnumerable<T>> ItemSaved;
    }
}
