﻿using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Journal;

namespace Bam.Oms.Persistence.Securities
{
    public class SecurityRepository : PersistentRepository<Security>, ISecurityRepository
    {
        public SecurityRepository(ILogger log, IEventJournalFactory eventJournalFactory) 
            : base("SecurityCache", log, eventJournalFactory)
        {
        }
    }
}
