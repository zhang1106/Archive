﻿using BAM.Infrastructure.Ioc;
using BAM.Infrastructure.DataFlowLogging.Client;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Persistence.Securities;

namespace Bam.Oms.Compliance.Service
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            Container.Instance.RegisterType<ISettings, ComplianceSetting>(RegistrationType.Singleton, "", new InjectionMethod("Initialize"));
            Container.Instance.RegisterType<IDateProvider, DateProvider>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IFactRepository, FactRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<ISecurityDBRepository, SecurityDBRepository>(RegistrationType.Singleton);
            container.RegisterTypeWithLoggingInterfaceInterceptor<IRuleResultRepository, RuleResultRepository>(RegistrationType.Singleton);

            Container.Instance.RegisterType<IComplianceGateway, ComplianceGateway>(RegistrationType.Singleton);

            var eventLogger = LoggingAgentFactory.Instance.GetLoggingAgent(BamSystem.POSITION_TRACKER);
            container.RegisterInstance(eventLogger);

        }
    }
}
