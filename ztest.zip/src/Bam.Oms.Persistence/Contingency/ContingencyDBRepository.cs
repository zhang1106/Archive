﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Configuration;

namespace Bam.Oms.Persistence.Contingency
{
    public class ContingencyDbRepository : DBRepository<ContingencyRecord>, IContingencyDbRepository
    {
        #region Private fields        
        private readonly ISettings _settings;
        private const string DeleteBySysdate = "DELETE FROM tblPositionsIntradayContingency WHERE Source = @emsName AND SysDate <= @cutOffTimeLocal";
        //private const string SelectBySysdate = "SELECT Portfolio, SymbolType, Symbol, SymbolDesc, SymbolPricing, Quantity, SodPriceNative, SodMarketValueNative, Multiplier, TradeCurrency, FXRate, Country, Industry, UnderlyingSymbol, SysDate FROM tblPositionsIntradayContingency WHERE SysDate >= @cutOffTimeLocal";
        //private const string SelectByKey = "SELECT Portfolio, SymbolType, Symbol, SymbolDesc, SymbolPricing, Quantity, SodPriceNative, SodmarketValueNative, Multiplier, TradeCurrency, FXRate, Country, Industry, UnderlyingSymbol, SysDate FROM tblPositionsIntradayContingency WHERE Portfolio = @portfolio AND SymbolType = @symbolType AND Symbol = @symbol";
        //private const string UpdateByKey = "UPDATE tblPositionsIntradayContingency SET SymbolDesc = @symbolDesc, SymbolPricing = @symbolPricing, Quantity = @quantity, SodPriceNative = @sodPriceNative, SodmarketValueNative = @sodMarketValueNative, Multiplier = @multiplier, TradeCurrency = @currency, FXRate = @fxRate, Country = @country, Industry = @industry, UnderlyingSymbol = @underlyingSymbol, SysDate = @sysDate FROM tblPositionsIntradayContingency WHERE Portfolio = @portfolio AND SymbolType = @symbolType AND Symbol = @symbol";
        //private const string DeleteByKey = "DELETE FROM tblPositionsIntradayContingency WHERE Portfolio = @portfolio AND SymbolType = @symbolType AND Symbol = @symbol";
        //private const string InsertContingencyRecord = "INSERT INTO [dbo].[tblPositionsIntradayContingency] ([Portfolio],[SymbolType],[Symbol],[SymbolDesc],[SymbolPricing],[Quantity],[SodPriceNative],[SodMarketValueNative],[Multiplier],[TradeCurrency],[FXRate],[Country],[Industry],[UnderlyingSymbol],[sysDate]) VALUES (@portfolio, @symbolType, @symbol, @symbolDesc, @symbolPricing, @quantity, @sodPriceNative, @sodMarketValueNative, @multiplier, @currency, @fxRate, @country, @industry, @underlyingSymbol, @sysDate)";
        #endregion

        internal static readonly Func<dynamic, ContingencyRecord> ResultMap = item => new ContingencyRecord
        {
            Portfolio = item.Portfolio,
            SymbolType = item.SymbolType,
            Symbol = item.Symbol,
            SymbolDesc = item.SymbolDesc,
            SymbolPricing = item.SymbolPricing,
            Quantity = item.Quantity,
            SodPriceNative = item.SodPriceNative ?? 0,
            SodMarketValueNative = item.SodMarketValueNative,
            Multiplier = item.Multiplier,
            Currency = item.Currency,
            FxRate = item.FXRate,
            Country = item.Country,
            Industry = item.Industry,
            UnderlyingSymbol = item.UnderlyingSymbol,
            SysDate = item.SysDate
        };

        /// <summary>
        /// Function to map Position fields to DB columns
        /// </summary>
        internal static readonly Func<ContingencyRecord, dynamic> ParameterMap = position => new
        {
            Portfolio = position.Portfolio,
            SymbolType = position.SymbolType,
            Symbol = position.Symbol,
            SymbolDesc = position.SymbolDesc,
            SymbolPricing = position.SymbolPricing,
            Quantity = position.Quantity,
            SodPriceNative = position.SodPriceNative,
            SodMarketValueNative = position.SodMarketValueNative,
            Multiplier = position.Multiplier,
            Currency = position.Currency,
            FXRate = position.FxRate,
            Country = position.Country,
            Industry = position.Industry,
            UnderlyingSymbol = position.UnderlyingSymbol,
            SysDate = position.SysDate
        };

        protected override IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_settings.ContingencyConnectionString);
            }
        }

        public ContingencyDbRepository(ISettings settings, ILogger log) : base(settings, log, "dbo", "tblPositionsIntradayContingency")
        {
            _settings = settings;
        }

        public override int Clear(DateTime cutOffTimeUtc)
        {
            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();                    
                    var param = new DynamicParameters();
                    param.Add("@cutOffTimeLocal", value: cutOffTimeUtc.ToLocalTime(), dbType: DbType.DateTime,
                        direction: ParameterDirection.Input);
                    param.Add("@emsName", value: _settings.EmsName.ToString(), dbType: DbType.String,
                        direction: ParameterDirection.Input);
                    return connection.Execute(DeleteBySysdate, param, commandType: CommandType.Text);
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error deleting contingency records.", ex);
                return 0;
            }
        }

        public override int ClearAll()
        {
            return this.Clear(_settings.SODDateTime);
        }

        public override IEnumerable<ContingencyRecord> Get(DateTime cutoffTimeUtc)
        {
            //Database is local time. The implicit assumption is the database server and the application server are in the same local timezone.
            DateTime cutOffTimeLocal = cutoffTimeUtc.ToLocalTime();
            return base.Get("SysDate >= @SysDate", new { @SysDate = cutOffTimeLocal }).ToList();
        }

        public override ContingencyRecord Get(string key)
        {
            string[] keyParts = key.Split(';');
            if (keyParts.Length < 3)
            {
                return null;   // Should we throw an exception?
            }

            string portfolio = keyParts[0];
            string symbolType = keyParts[1];
            string symbol = keyParts[2];
            return base.Get(new { Portfolio = portfolio, SymbolType = symbolType, Symbol = symbol }).FirstOrDefault();
        }

        public override ContingencyRecord Save(ContingencyRecord item)
        {
            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();
                    int recordCount = connection.Execute("dbo.usp_InsertContingencyPosition", new
                    {
                        item.Portfolio,
                        item.SymbolType,
                        item.Symbol,
                        item.SymbolDesc,
                        item.SymbolPricing,
                        item.Quantity,
                        item.SodPriceNative,
                        item.SodMarketValueNative,
                        item.Multiplier,
                        item.Currency,
                        item.FxRate,
                        item.Country,
                        item.Industry,
                        item.UnderlyingSymbol,
                        item.SysDate
                    }, commandType: CommandType.StoredProcedure);
                    if (recordCount == 1)
                    {
                        return item;
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error saving contingency record.", ex);
                return null;
            }
            return null;
        }

        public override IEnumerable<ContingencyRecord> Save(IEnumerable<ContingencyRecord> items)
        {
            if (!items.Any()) return items;
            try
            {
                using (IDbConnection connection = Connection)
                {
                    var itemsToInsert = new List<DynamicParameters>();
                    foreach (var item in items)
                    {
                        var param = new DynamicParameters();
                        param.Add("@portfolio", value: item.Portfolio, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@symbolType", value: item.SymbolType, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@symbol", value: item.Symbol, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@symbolDesc", value: item.SymbolDesc, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@symbolPricing", value: item.SymbolPricing, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@quantity", value: item.Quantity, dbType: DbType.Decimal,
                            direction: ParameterDirection.Input);
                        param.Add("@sodPriceNative", value: item.SodPriceNative, dbType: DbType.Decimal,
                            direction: ParameterDirection.Input);
                        param.Add("@sodMarketValueNative", value: item.SodMarketValueNative, dbType: DbType.Decimal,
                            direction: ParameterDirection.Input);
                        param.Add("@multiplier", value: item.Multiplier, dbType: DbType.Decimal,
                            direction: ParameterDirection.Input);
                        param.Add("@currency", value: item.Currency, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@fxRate", value: item.FxRate, dbType: DbType.Decimal,
                            direction: ParameterDirection.Input);
                        param.Add("@country", value: item.Country, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@industry", value: item.Industry, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@underlyingSymbol", value: item.UnderlyingSymbol, dbType: DbType.String,
                            direction: ParameterDirection.Input);
                        param.Add("@sysDate", value: item.SysDate, dbType: DbType.DateTime,
                            direction: ParameterDirection.Input);
                        itemsToInsert.Add(param);
                    }
                    int recordCount = connection.Execute("dbo.usp_InsertContingencyPosition", itemsToInsert,
                        commandType: CommandType.StoredProcedure);
                    if (recordCount == items.Count())
                    {
                        return items;
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error saving contingency records.", ex);
                return new List<ContingencyRecord>();
            }
            return new List<ContingencyRecord>();
        }

        public IEnumerable<IPosition> Save(IEnumerable<IPosition> positions)
        {
            IList<ContingencyRecord> contingencyRecords = positions.Select(position => new ContingencyRecord(position)).ToList();

            IEnumerable<ContingencyRecord> savedItems = this.Save(contingencyRecords).ToList();
            if (savedItems.Count() == positions.Count())
            {
                return positions;
            }
            //TODO: Compare saved items with the arguments
            return new List<IPosition>();
        }

    }
}
