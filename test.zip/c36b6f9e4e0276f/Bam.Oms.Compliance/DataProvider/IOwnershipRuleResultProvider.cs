﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IOwnershipRuleResultProvider : IRuleResultProvider
    {
        decimal? GetRatio(int policyId, int ruleId, string bamSymbol);
        decimal? GetLowLimit(int policyId, int ruleId, string bamSymbol);
        bool GetIsRuleOverriden(int policyId, int ruleId, string bamSymbol);
        IEnumerable<IRuleResult> GetHistory(string bamSysmbol);

    }
}
