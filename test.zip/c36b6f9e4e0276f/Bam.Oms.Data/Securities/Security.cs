﻿using System;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using Bam.Oms.Data.Enumerators;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Bam.Oms.Data.Securities
{
    [DataContract]
    public class Security : ISecurity
    {
        [DataMember(Order = 0, IsRequired = true)]
        public string Key => BamSymbol;

        [JsonConverter(typeof(StringEnumConverter))]
        [DataMember(Order = 1, IsRequired = true)]
        public SecurityType SecurityType { get; set; }

        [DataMember(Order = 2)]
        public string Currency { get; set; }

        [DataMember(Order = 3)]
        public string Issuer { get; set; }

        public bool Equals(ISecurity sec)
        {
            return BamSymbol.Equals(sec.Key);
        }

        public int CompareTo(ISecurity other)
        {
            if (this.Equals(other)) return 0;
            if (other == null)
                return -1;

            return string.Compare(this.Key, other.Key, StringComparison.CurrentCulture); //Case sensitive to support currencies in the future
        }

        public int CompareTo(Object obj)
        {
            if (obj == this)
                return 0;

            var other = obj as ISecurity;
            if (this.Equals(obj)) return 0;
            if (other == null)
                return -1;

            return string.Compare(this.Key, other.Key, StringComparison.CurrentCultureIgnoreCase);
        }

        public bool IsMatch(ISecurity security)
        {
            if (string.IsNullOrEmpty(security.Key) && string.IsNullOrEmpty(security.BamSymbol) &&
                string.IsNullOrEmpty(security.Ticker) && string.IsNullOrEmpty(security.Cusip) &&
                string.IsNullOrEmpty(security.Isin) && string.IsNullOrEmpty(security.Sedol) &&
                string.IsNullOrEmpty(security.BloombergSymbol))
            {
                return false;
            }

            return (string.IsNullOrEmpty(security.Key) || Regex.IsMatch(Key, Utility.WildcardToRegex(security.Key)))
                   &&
                   (string.IsNullOrEmpty(security.BamSymbol) ||
                    Regex.IsMatch(BamSymbol, Utility.WildcardToRegex(security.BamSymbol)))
                   &&
                   (string.IsNullOrEmpty(security.Ticker) ||
                    Regex.IsMatch(Ticker, Utility.WildcardToRegex(security.Ticker)))
                   &&
                   (string.IsNullOrEmpty(security.Cusip) ||
                    Regex.IsMatch(Cusip, Utility.WildcardToRegex(security.Cusip)))
                   &&
                   (string.IsNullOrEmpty(security.Isin) ||
                    Regex.IsMatch(Isin, Utility.WildcardToRegex(security.Isin)))
                   &&
                   (string.IsNullOrEmpty(security.Sedol) ||
                    Regex.IsMatch(Sedol, Utility.WildcardToRegex(security.Sedol)))
                   &&
                   (string.IsNullOrEmpty(security.BloombergSymbol) ||
                    Regex.IsMatch(BloombergSymbol, Utility.WildcardToRegex(security.BloombergSymbol)));
        }

        public override bool Equals(object obj)
        {
            var sec = obj as Security;

            return sec != null && Equals(sec);
        }

        public override int GetHashCode()
        {
            return Key.GetHashCode();
        }

        public override string ToString()
        {
            return
                $"BamSymbol:{BamSymbol}, Ticker:{Ticker}, Cusip:{Cusip}, Isin:{Isin}, Sedol:{Sedol}, BloombergSymbol:{BloombergSymbol}";
        }

        #region Identifiers

        [DataMember(Order = 4)]
        public string BamSymbol { get; set; }

        [DataMember(Order = 5)]
        public string Ticker { get; set; }

        [DataMember(Order = 6)]
        public string Cusip { get; set; }

        [DataMember(Order = 7)]
        public string Isin { get; set; }

        [DataMember(Order = 8)]
        public string Sedol { get; set; }

        [DataMember(Order = 9)]
        public string BloombergSymbol { get; set; }
        #endregion Identifiers

        [DataMember(Order = 10)]
        public string Country { get; set; }

        [DataMember(Order = 11)]
        public string Industry { get; set; }

        [DataMember(Order = 12)]
        public string UnderlyingSymbol { get; set; }

        [DataMember(Order = 13)]
        public decimal? ContractSize { get; set; }

        [DataMember(Order = 14)]
        public OptionType OptionType { get; set; }

        [DataMember(Order = 15)]
        public bool IsBilateral { get; set; }
        [DataMember(Order = 16)]
        public InvestmentType InvestmentType { get; set; }
        public AssetType AssetType { get; set; }
        public string AdrCode { get; set; }
        public string TrackIndexCode { get; set; }
        public decimal AdrRatio { get; set; }
        public bool ActiveInd { get; set; }
        public bool IsComposite()
        {
            return InvestmentType == InvestmentType.ETF
                   || InvestmentType == InvestmentType.Basket
                   || InvestmentType == InvestmentType.Index;
        }

        public bool IsEquity()
        {
            return AssetType == AssetType.Equity ||
                   (AssetType == AssetType.Swap && (InvestmentType == InvestmentType.EquitySwap || InvestmentType==InvestmentType.FutureSingleStock || InvestmentType == InvestmentType.WarrantAndRight));
        }

        public bool IsEquityOption()
        {
            return (this.AssetType == AssetType.Option &&
                 (this.InvestmentType == InvestmentType.Equity || this.InvestmentType == InvestmentType.WarrantAndRight));
        }

        public bool IsAdr()
        {
            return this.InvestmentType == InvestmentType.DepositoryReceipt ||
                   this.InvestmentType == InvestmentType.DepositaryReceipt;
        }
    }
}