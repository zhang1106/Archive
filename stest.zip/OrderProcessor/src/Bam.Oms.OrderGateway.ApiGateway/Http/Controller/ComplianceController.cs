﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web.Http;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class ComplianceController : BaseController
    {
        private readonly ICache<OwnershipHeadroomKey, OwnershipHeadroom> _cache;
        private readonly IComplianceSubmission _complianceSubmission;

        public ComplianceController(ICache<OwnershipHeadroomKey, OwnershipHeadroom> cache,
            IComplianceSubmission complianceSubmission, IPermissionedEntityFilter entityFilter) 
            : base(entityFilter)
        {
            _cache = cache;
            _complianceSubmission = complianceSubmission;
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Compliance.Read, Function.OrderGateway.Compliance.Write")]
        public IReadOnlyList<OwnershipHeadroom> GetHeadroom()
        {
            using (_cache.AcquireReadAccess())
            {
                return _cache.GetItems();
            }
        }
        
        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Compliance.Read, Function.OrderGateway.Compliance.Write")]
        public IReadOnlyList<OwnershipHeadroom> GetHeadroom(string identifier)
        {
            using (_cache.AcquireReadAccess())
            {
                return _cache.GetItems()
                    .Where(r => r.Key.Identifier.Equals(identifier, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }
        }

        [HttpPatch]
        [RequiredPermissions("Function.OrderGateway.Compliance.Write")]
        public void AdjustRatios(HeadroomAdjustment item)
        {
            Logger?.LogInformation($"{User.GetLogin()} adjusted headroom for identifier '{item.Identifier}' (rule {item.RuleId}) to {item.Ratios.Stringify()}");
            _complianceSubmission.AdjustHeadroomRatios(item.RuleId, item.Identifier, item.Ratios, User.GetLogin());
        }

        [HttpPut]
        [RequiredPermissions("Function.OrderGateway.Compliance.Write")]
        public void UpdateHeadroom(List<HeadroomLoaded.Item> items)
        {
            if (items == null || items.Count == 0)
                return;

            var msg = new HeadroomLoaded
            {
                Chunk = 1,
                TotalChunks = 1,
                IsWipeAndLoad = false
            };
            msg.Items.AddRange(items);

            Logger?.LogInformation($"{User.GetLogin()} updated headroom for identifiers: [{items.Select(s => s.Identifier).Distinct().Stringify()}]");
            _complianceSubmission.SubmitHeadroom(msg);
        }

        [HttpPatch]
        [RequiredPermissions("Function.OrderGateway.Compliance.Write")]
        public void DisableComplianceRules(List<DisableComplianceRuleRequest> rule)
        {
            foreach (var request in rule)
            {
                var disabled = request.Enabled ? "enabling" : "disabling";
                Logger?.LogInformation($"'{User.GetLogin()}' is {disabled} the following rule '{request.RuleName}'.");
            }
            
            _complianceSubmission.DisableComplianceRules(rule, User.GetLogin());
        }
    }
}