﻿using System.Collections.Generic;

namespace Bam.Oms.Data.Compliance
{
    public interface IEngine<T>
    {
        Dictionary<string, IPolicy<T>> Policies { get; }
        void RegisterPolicy(IPolicy<T> policy);
        void Refresh();
        /// <summary>
        /// check for violations against a policy by speicify policy ID or name
        /// </summary>
        IPolicyResult CheckViolations(IPolicy<T> policy, T input, bool isPreCheck);
        IPolicy<T> GetPolicy(string name);
    }
}
