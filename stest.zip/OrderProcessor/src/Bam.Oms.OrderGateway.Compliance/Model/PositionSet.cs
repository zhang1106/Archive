﻿namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public struct PositionSet
    {
        public PositionSet(Position position, CompliancePosition compliancePosition, AggUnitPosition aggUnitPosition)
        {
            Position = position;
            CompliancePosition = compliancePosition;
            AggUnitPosition = aggUnitPosition;
        }
        
        public PositionKey Key => Position.Key;
        public Position Position { get; set; }
        public CompliancePosition CompliancePosition {get; set;}
        public AggUnitPosition AggUnitPosition { get; set; }
    }
}
