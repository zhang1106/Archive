﻿using System.Collections.Generic;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Persistence.Positions
{
    public interface IPositionRepository
    {
        IReadOnlyList<IAggUnitPosition> GetAggUnitPositions();
        IReadOnlyList<ICompliancePosition> GetCompliancePositions();
        IReadOnlyList<IPosition> GetAllPositions();
        IReadOnlyList<IPosition> GetPositions(IReadOnlyList<IPositionKey> keys);
        IReadOnlyList<IPositionSet> Get(IReadOnlyList<IPositionKey> positionKeys);
        void Save(IReadOnlyList<IPositionSet> sets);
        void Clear();
        void Clear(IReadOnlyList<string> symbols);
        void Clear(string stream, IReadOnlyList<string> symbols);
    }
}
