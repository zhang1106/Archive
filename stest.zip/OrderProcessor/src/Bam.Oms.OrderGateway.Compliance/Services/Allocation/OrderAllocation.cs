﻿using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public struct OrderAllocation
    {
        public OrderAllocation(OrderAllocation copy)
        {
            Portfolio = copy.Portfolio;
            FundId = copy.FundId;
            CustodianId = copy.CustodianId;
            Side = copy.Side;
            Quantity = copy.Quantity;
            ClosingPortionSansOmni = copy.ClosingPortionSansOmni;
        }

        public Portfolio Portfolio { get; set; }
        public int FundId { get; set; }
        public int CustodianId { get; set; }
        public Side Side { get; set; }
        public long Quantity { get; set; }
        public long ClosingPortionSansOmni { get; set; }
    }
}
