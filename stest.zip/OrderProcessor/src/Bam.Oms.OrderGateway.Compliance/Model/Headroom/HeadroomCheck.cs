﻿using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    public struct HeadroomCheck
    {
        public bool IsContingency { get; set; }
        public decimal Threshold { get; set; }
        public ComplianceViolationLevel ViolationLevel { get; set; }
        public long StartOfDayQuantity { get; set; }
        public long IntradayQuantity { get; set; }
    }
}
