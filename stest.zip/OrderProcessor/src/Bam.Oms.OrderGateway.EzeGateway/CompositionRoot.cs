using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http.Dependencies;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Integration;
using Bam.EventQ.Journal;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Pooling;
using Bam.EventQ.RabbitMQ;
using Bam.EventQ.Recovery;
using Bam.EventQ.Sequencing;
using Bam.EventQ.Snapshot;
using Bam.EventQ.Throttling;
using Bam.EventQ.Time;
using Bam.EventQ.Transport;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.EzeGateway.Http;
using Bam.Oms.OrderGateway.EzeGateway.Models;
using Bam.Oms.OrderGateway.EzeGateway.Producers;
using Bam.Oms.OrderGateway.EzeGateway.Services;
using Bam.Oms.OrderGateway.EzeGateway.Workflows;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.Audit;
using Bam.Oms.OrderGateway.Integrations.StructureMap;
using Bam.Oms.OrderGateway.Messages;
using StructureMap;

namespace Bam.Oms.OrderGateway.EzeGateway
{
    public class CompositionRoot : StructureMapCompositionRoot<EzeGatewayService, EzeGatewaySettings>
    {
        protected override void Configure(ConfigurationExpression config, EzeGatewaySettings settings)
        {
            ConfigureEze(config, settings);
        }

        private void ConfigureEze(ConfigurationExpression config, EzeGatewaySettings settings)
        {
            if (settings.RabbitMq.Publish)
            {
                config.For<IEzeUpdateSubmission>()
                    .Use<EzeTradeUpdateMessageSource>()
                    .Ctor<IThrottledBatchHandler<TradeUpdateDto>>()
                        .Is<RabbitMqTopicPublisher<TradeUpdateDto>>(c => c
                            .Ctor<string>("endpoint").Is(settings.RabbitMq.Endpoint)
                            .Ctor<string>("exchange").Is(settings.RabbitMq.TradeUpdateExchange)
                            .Ctor<Func<TradeUpdateDto, string>>().Is(dto => dto.GetRoutingKey())
                            .Ctor<TimeSpan>().Is(settings.RabbitMq.RetryInterval))
                    .Singleton();
            }
            else
            {
                config.For<IEzeUpdateSubmission>()
                    .Use<EzeTradeUpdateMessageSource>()
                    .SelectConstructor(() => new EzeTradeUpdateMessageSource())
                    .Singleton();
            }

            config.ForConcreteType<EzeGatewayService>().Configure
                .Ctor<IService>().Is<HttpService>(cfg => cfg
                    .Ctor<string>().Is(settings.HttpCallbackUrl)
                    .Ctor<IDependencyResolver>().Is(ctx => new StructureMapDependencyResolver(ctx.GetInstance<IContainer>())));

            config.For<IEzeClient>()
                .Use<EzeClient>()
                .Ctor<string>("tradeUrl").Is(settings.TradingServiceUrl)
                .Ctor<string>("pubSubUrl").Is(settings.PublishSubscribeUrl)
                .Ctor<string>("username").Is(settings.Username)
                .Ctor<string>("password").Is(settings.Password)
                .Singleton();

            config.For<IFastLaneQueue<SubmissionQueueItem>>()
                .Use<FastLaneQueue<SubmissionQueueItem>>()
                .Ctor<IFastLaneRules<SubmissionQueueItem>>().Is<FastLaneRules>(
                    rules => rules.Ctor<int>().Is(settings.FastLaneThreshold))
                .Singleton();

            config.For<IAsyncRpc>().Use<AsyncRpc>().Singleton();                

            config.ForConcreteType<ExternalMessageWorkflow>().Configure
                .Ctor<IEnumerable<string>>("supportedSecurityTypes").Is(settings.SupportedSecurityTypes)
                .Singleton();

            config.For<IEzeOrderCache>()
                .Use<EzeOrderCache>()
                .Singleton();

            config.For<IExternalOrderIdService>()
                .Use<ExternalOrderIdService>()
                .Singleton()
                .AlsoKnownAs(config, typeof(ISnapshotRecoverable));
            
            config.For<IEzeTranslator>()
                .Use<EzeTranslator>()
                .Ctor<Dictionary<string,string>>("userDefinedFields").Is(settings.UserDefinedFields)
                .Ctor<Dictionary<string, string>>("brokerMpids").Is(settings.BrokerMarketParticipantIds)
                .Singleton()
                .AlsoKnownAs(config, typeof(ISnapshotRecoverable));

            for (int i = 0; i < settings.SubmissionThreadPoolSize; i++)
            {
                bool fastLane = i < settings.SubmissionFastLaneCount;

                config.For<IEzePooledWorker>()
                    .Add<EzePooledWorker>()
                    .Ctor<int>("maxBatchSize").Is(
                        fastLane ? settings.FastLaneMaxBatchSize : settings.MaxBatchSize)
                    .Ctor<bool>().Is(fastLane);
            }

            config.For<IEzeSubmissionService>()
                .Use<EzeSubmissionService>()
                .Ctor<int>("maxBatchSize").Is(settings.MaxBatchSize)
                .Ctor<int>("submissionRetryCount").Is(settings.SubmissionRetryCount);
        }
        
        protected override void ConfigureMessageAudit(ConfigurationExpression config, EzeGatewaySettings settings)
        {
            if (settings.LogEzeMessages)
                config.For<IMessageAudit>().Use<MessageAudit>().Singleton();
            else
                base.ConfigureMessageAudit(config, settings);
        }

        protected override IEnumerable<IProcessingPipeline> CreatePipelines(EzeGatewaySettings settings,
            IContainer container)
        {
            var ezeHttp = (IExternalMessageSource<TradeUpdateDto>) 
                container.GetInstance<IEzeUpdateSubmission>();
            var ezeRpc = container.GetInstance<IAsyncRpc>();
            
            yield return ProcessingPipeline.New()
                .LogErrors(container.GetInstance<ILogger>())
                .UseObjectInitializer(ObjectInitializer)
                .UseObjectDecorator(new TelemetryObjectDecorator(container.GetInstance<ITelemetry>(), settings.TelemetryPublishInterval))
                .UseRecoveryInvoker(container.GetInstance<IRecoveryInvoker>())
                .UseRpcServer(container.GetInstance<IRpcServer>())
                .AddStep<IMessage>(step => step
                    .AddSequenceInfoAccessor()
                    .AddQueueMessageDispatcher(container.GetInstance<IQueueMessageDispatcher>())
                    .UseDisruptor(settings.Queue.InputRingSize, settings.Queue.BufferSize)
                    .ReplayFromJournal(container.GetInstance<IJournal>(), container.GetAllInstances<IJournalSeed>())
                    .AddInitializer(container.GetInstance<InitialReplayInitializer>())
                    .AddExternalSource(ezeRpc, container.GetInstance<TradeCreateResponseTransform>())
                    .If(!settings.RabbitMq.Receive, then => then
                        .AddExternalSource(ezeHttp, container.GetInstance<TradeUpdateDtoTransform>()))
                    .If(settings.RabbitMq.Receive, then => then
                        .ReceiveJsonFromRabbitMq(settings.RabbitMq.Endpoint,
                            settings.RabbitMq.TradeUpdateExchange, settings.RabbitMq.TradeUpdateQueue,
                            settings.MaximumMessageSize, container.GetInstance<TradeUpdateDtoTransform>()))
                    .SubscribeWithZeroMq(settings.Endpoints.PubSubBySource, settings.MaximumMessageSize)
                    .SubscribeTo(Source.OrderProcessor, Topic.Ems)
                    .SubscribeTo(Source.RefDataGateway, Topic.RefData, Topic.Security)
                    .SubscribeTo(Source.ApiGateway, Topic.Admin)
                    .SendHeartbeats(WallClock, settings.HeartbeatInterval, settings.SelfSource, Topic.Enrichment, Topic.Ems)
                    .AddHandlerChain(chain => chain
                        .ValidateSequenceNumbers(container.GetInstance<IClock>(), settings.RecoveryTimeout, settings.SelfSource)
                        .Journal(container.GetInstance<IJournal>())
                        .Deserialize()
                        .AddHandler(new EmsMessageFilter(EmsSystem.Eze))
                        .LogMessagesTo("IN", settings.LogAllMessages, container.GetInstance<ILogger>())
                        .DispatchToWorkflow(container.GetInstance<IWorkflowDispatcher<IMessage, IMessage>>())
                        .ReleasePayload(container.GetInstance<IObjectPool>())))
                .AddStep<IMessage>(step => step
                    .AddSequenceInfoAccessor()
                    .UseDisruptor(settings.Queue.OutputRingSize, settings.Queue.BufferSize)
                    .ReceiveFromPreviousStep<IMessage>()
                    .PublishWithZeroMq()
                    .AddHandlerChain(chain => chain
                        .Serialize(settings.SelfSource, settings.MaximumMessageSize, WallClock)
                        .LogMessagesTo("OUT", settings.LogAllMessages, container.GetInstance<ILogger>())
                        .Publish(settings.SelfPubSub))
                    .UseReplayRecovery(settings.SelfPubSub))
                .Build();
        }

        private class StructureMapDependencyResolver : IDependencyResolver
        {
            private readonly IContainer _container;

            public StructureMapDependencyResolver(IContainer container)
            {
                _container = container;
            }

            public void Dispose()
            {
                // nothing
            }

            public object GetService(Type serviceType)
            {
                return _container.TryGetInstance(serviceType);
            }

            public IEnumerable<object> GetServices(Type serviceType)
            {
                return _container.GetAllInstances(serviceType).Cast<object>();
            }

            public IDependencyScope BeginScope()
            {
                return new StructureMapDependencyScope(_container.GetNestedContainer());
            }

            private class StructureMapDependencyScope : IDependencyScope
            {
                private readonly IContainer _container;

                public StructureMapDependencyScope(IContainer container)
                {
                    _container = container;
                }

                public void Dispose()
                {
                    _container.Dispose();
                }

                public object GetService(Type serviceType)
                {
                    return _container.GetInstance(serviceType);
                }

                public IEnumerable<object> GetServices(Type serviceType)
                {
                    return _container.GetAllInstances(serviceType).Cast<object>();
                }
            }
        }
    }
}
