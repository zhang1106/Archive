﻿using System;

namespace Bam.Oms.Data.Enumerators
{
    [Flags]
    public enum PositionUpdate
    {
        None = 0,
        TheoreticalSize = 1,
        TheoreticalSide = 2,
        ActualSize = 4,
        ActualSide = 8,
    }
}
