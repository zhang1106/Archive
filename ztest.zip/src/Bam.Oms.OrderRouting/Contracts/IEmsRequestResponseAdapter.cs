﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.Filtering;

namespace Bam.Oms.OrderRouting.Contracts
{
    public interface IEmsRequestResponseAdapter : IEmsBaseAdapter
    {
        /// <summary>
        /// Sub new orders to EMS
        /// </summary>
        /// <param name="orders"></param>
        /// <returns>Orders with status. Orders woul be markes as error if the operation fails.</returns>
        IEnumerable<IOrder> SubmitOrders(IEnumerable<IOrder> orders, bool stageOrders = false);

        /// <summary>
        /// Submit amendments to orders that have been previously ack'ed by EMS. All EMs specific logic resides in this. For example, if an EMS requires an order to be cancelled and replaced for an amendment, that logic would reside here.
        /// </summary>
        /// <param name="orders"></param>
        /// <returns>Orders with status. Orders woul be markes as error if the operation fails.</returns>
        IEnumerable<IOrder> AmendOrders(IEnumerable<IOrder> orders);

        /// <summary>
        /// Cancel all orders that match the criteria. A blank filter would cancel all (panic or kill all) for the Ems.
        /// </summary>
        /// <param name="orderFilter">Key fields can be regular expressions</param>
        /// <returns></returns>
        bool CancelOrders(IFilter<IOrder> orderFilter);

        /// <summary>
        /// Returns a list of start of day positions.  Left blank returns all portfolios
        /// </summary>
        /// <returns></returns>
        IList<IPosition> GetSodPositions(IPortfolio portfolio = null);

        /// <summary>
        /// Returns a list of open orders for a given portfolio.  Left blank returns all open orders
        /// </summary>
        /// <returns></returns>
        void GetOpenOrders(out IReadOnlyList<IOrder> orders, out IReadOnlyList<IBlockTrade> trades);

        /// <summary>
        /// Returns a list of trades for the given trade date
        /// </summary>
        /// <param name="tradeDate"></param>
        /// <returns></returns>
        IEnumerable<IBlockTrade> GetTradesForTradeDate(DateTime tradeDate);

    }
}
