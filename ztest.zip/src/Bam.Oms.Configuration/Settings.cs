﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Management;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Data.Configuration
{
    public class Settings : ISettings
    {
        private readonly IDateProvider _dateProvider;
        private readonly ILogger _logger;

        public Settings(IDateProvider dateProvider, ILogger logger)
        {
            if (dateProvider == null) throw new ArgumentNullException(nameof(dateProvider));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            _dateProvider = dateProvider;
            _logger = logger;
        }

        public virtual void Initialize()
        {
            try
            {
                BaseUrl = ConfigurationManager.AppSettings["base_url"];
                if (string.IsNullOrWhiteSpace(BaseUrl))
                {
                    BaseUrl = "localhost";
                }

                BasePort = ConfigurationManager.AppSettings["base_port"];
                if (string.IsNullOrWhiteSpace(BasePort))
                {
                    BasePort = "8080";
                }

                string defaultSodTimeString = ConfigurationManager.AppSettings["SODTime"];
                DefaultSODDateTime = _dateProvider.SetSodTime(defaultSodTimeString);                
                SODDateTime = DefaultSODDateTime;                

                OrderGatewayConnectionString = ConfigurationManager.ConnectionStrings["OrderGateway"].ConnectionString;
                if (string.IsNullOrWhiteSpace(OrderGatewayConnectionString))
                {
                    throw new ApplicationException("Order Gateway connection string is required in the app.config.");
                }

                ContingencyConnectionString = ConfigurationManager.ConnectionStrings["Contingency"].ConnectionString;
                if (string.IsNullOrWhiteSpace(ContingencyConnectionString))
                {
                    throw new ApplicationException("Contingency connection string is required in the app.config.");
                }

                BamCoreLiteConnectionString = ConfigurationManager.ConnectionStrings["BamCoreLite"].ConnectionString;
                if (string.IsNullOrWhiteSpace(BamCoreLiteConnectionString))
                {
                    throw new ApplicationException("BamCoreLite connection string is required in the app.config.");
                }

                string contingencyTimerIntervalString = ConfigurationManager.AppSettings["ContingencyTimerInterval"];
                if (string.IsNullOrWhiteSpace(contingencyTimerIntervalString))
                {
                    ContingencyTimerInterval = 600000; // Default to evert 10 minutes
                }
                else
                {
                    ContingencyTimerInterval = Int32.Parse(contingencyTimerIntervalString) * 1000;
                }

                string emsSubscriptionRetryAttempts = ConfigurationManager.AppSettings["EmsSubscriptionRetryAttempts"];
                if (string.IsNullOrWhiteSpace(emsSubscriptionRetryAttempts))
                {
                    MaxResubscribeAttempt = 10;
                }
                else
                {
                    MaxResubscribeAttempt = Int32.Parse(emsSubscriptionRetryAttempts);
                }

                string maxStripedProcessorsString = ConfigurationManager.AppSettings["MaxStripedProcessors"];
                if (string.IsNullOrWhiteSpace(maxStripedProcessorsString))
                {
                    MaxStripedProcessors =
                        new ManagementObjectSearcher("Select NumberOfCores from Win32_Processor").Get().Cast<ManagementBaseObject>().Sum(item => int.Parse(item["NumberOfCores"].ToString())) * 2;
                }
                else
                {
                    MaxStripedProcessors = Int32.Parse(maxStripedProcessorsString);
                }

                string emsResubscribeWaitInterval = ConfigurationManager.AppSettings["EmsResubscribeWaitInterval"];
                if (string.IsNullOrWhiteSpace(emsResubscribeWaitInterval))
                {
                    EmsResubscribeWaitInterval = 10;
                }
                else
                {
                    EmsResubscribeWaitInterval = Int32.Parse(emsResubscribeWaitInterval);
                }

                if (ConfigurationManager.ConnectionStrings["MQ"] != null)
                {
                    MqConnectionString = ConfigurationManager.ConnectionStrings["MQ"].ConnectionString;
                    //if (string.IsNullOrWhiteSpace(MqConnectionString))
                    //{
                    //    throw new ApplicationException("MQ connection string is required in the app.config.");
                    //}
                }

                MqEODTradeTopic = ConfigurationManager.AppSettings["MQEODTradeTopic"];
                if (string.IsNullOrWhiteSpace(MqEODTradeTopic))
                {
                    MqEODTradeTopic = "BAM.TRADES.EOD";
                }

                MqEODOrderTopic = ConfigurationManager.AppSettings["MQEODOrderTopic"];
                if (string.IsNullOrWhiteSpace(MqEODOrderTopic))
                {
                    MqEODOrderTopic = "BAM.ORDERS.EOD";
                }

                MqEODPositionTopic = ConfigurationManager.AppSettings["MQEODPositionTopic"];
                if (string.IsNullOrWhiteSpace(MqEODPositionTopic))
                {
                    MqEODOrderTopic = "BAM.POSITIONS.EOD";
                }

                MqTradeTopic = ConfigurationManager.AppSettings["MQTradeTopic"];
                if (string.IsNullOrWhiteSpace(MqTradeTopic))
                {
                    MqTradeTopic = "BAM.TRADES.INTRADAY";
                }

                MqOrderTopic = ConfigurationManager.AppSettings["MQOrderTopic"];
                if (string.IsNullOrWhiteSpace(MqOrderTopic))
                {
                    MqOrderTopic = "BAM.ORDERS.INTRADAY";
                }

                MqEzeOrderTopic = ConfigurationManager.AppSettings["MqEzeOrderTopic"];
                if (string.IsNullOrWhiteSpace(MqEzeOrderTopic))
                {
                    MqEzeOrderTopic = "BAM.ORDERS.EZE";
                }


                MqPositionTopic = ConfigurationManager.AppSettings["MQPositionTopic"];
                if (string.IsNullOrWhiteSpace(MqPositionTopic))
                {
                    MqPositionTopic = "BAM.POSITIONS.INTRADAY";
                }

                MqMarketDataTopic = ConfigurationManager.AppSettings["MQMarketDataTopic"];
                if (string.IsNullOrWhiteSpace(MqMarketDataTopic))
                {
                    MqMarketDataTopic = "BAM.MARKETDATA";
                }
             
                MqMarketDataSubscribeQueue = ConfigurationManager.AppSettings["MQMarketDataSubscribeQueue"];
                if (string.IsNullOrWhiteSpace(MqMarketDataSubscribeQueue))
                {
                    MqMarketDataSubscribeQueue = "BAM.MARKETDATA.initial";
                }

                PermissionedApplications = ConfigurationManager.AppSettings["PermissionedApplications"];
                if (string.IsNullOrWhiteSpace(PermissionedApplications))
                {
                    PermissionedApplications = "PMUI,OrderGateway";
                }

                EnablePermission = ConfigurationManager.AppSettings["enablePermission"];
                if (string.IsNullOrWhiteSpace(EnablePermission))
                {
                    EnablePermission = "NO";
                }                

                NameValueCollection portfolioToComplianceGroupMap = ConfigurationManager.GetSection("PortfolioToComplianceGroupMap") as NameValueCollection;
                if (portfolioToComplianceGroupMap != null)
                {
                    PortfolioToComplianceGroup = portfolioToComplianceGroupMap.Cast<string>()
                        .Select(s => new { Key = s, Value = portfolioToComplianceGroupMap[s] })
                        .ToDictionary(p => p.Key, p => p.Value);
                }
                else
                {
                    _logger.Warn($"No configuration for PortfolioToComplianceGroupMap. Compliance group will default to portfolio code.");
                }

                NameValueCollection portfolioToAggUnitMap = ConfigurationManager.GetSection("PortfolioToAggUnitMap") as NameValueCollection;
                if (portfolioToAggUnitMap != null)
                {
                    PortfolioToAggUnit = portfolioToAggUnitMap.Cast<string>()
                        .Select(s => new { Key = s, Value = portfolioToAggUnitMap[s] })
                        .ToDictionary(p => p.Key, p => p.Value);
                }
                else
                {
                    _logger.Warn($"No configuration for PortfolioToAggUnitMap. Agg Unit will default to portfolio code.");
                }

                NameValueCollection managerCodeMap = ConfigurationManager.GetSection("ManagerCodeMap") as NameValueCollection;
                if (managerCodeMap != null)
                {
                    ManagerCodeMap = managerCodeMap.Cast<string>()
                        .Select(s => new { Key = s, Value = managerCodeMap[s] })
                        .ToDictionary(p => p.Key, p => p.Value);
                }
                else
                {
                    _logger.Warn($"No configuration for ManagerCodeMap. Trader will default to System.");
                }

                FlexHost = ConfigurationManager.AppSettings["flex_host"];
                FlexPort = ConfigurationManager.AppSettings["flex_port"];

                string connectionRetryIntervalString = ConfigurationManager.AppSettings["ConnectionRetryInterval"];
                if (string.IsNullOrWhiteSpace(connectionRetryIntervalString))
                {
                    ConnectionRetryInterval = 10000; // Default to evert 10 seconds
                }
                else
                {
                    ConnectionRetryInterval = Int32.Parse(connectionRetryIntervalString) * 1000;
                }

                string emsPingIntervalString = ConfigurationManager.AppSettings["EMSPingInterval"];
                if (string.IsNullOrWhiteSpace(emsPingIntervalString))
                {
                    EMSPingInterval = 1000 * 60 * 5; // Default to evert 1 minute
                }
                else
                {
                    EMSPingInterval = Int32.Parse(emsPingIntervalString) * 1000;
                }

                MqAccountTopic = ConfigurationManager.AppSettings["MQAccountTopic"];
                MqAmConnectionString = ConfigurationManager.ConnectionStrings["MQAM"].ConnectionString;

                string emsName = GetConfigValue("EMSName", string.Empty); //Should we default to Flex? could be dangerous to set a default.
                EmsName = Bam.Oms.Data.Utility.GetEnumValue<EmsSystem>(emsName);

                EzeUserName = GetConfigValue("EzeUserName", "bamclient");
                EzePassword = GetConfigValue("EzePassword", "b2amcl1ent");
                EzeSubmissionRetryCount = GetConfigValue("EzeSubmissionRetryCount", 2);

                CoverageServiceHost = GetConfigValue("CoverageServiceHost", "ems-gtwy-dev");
                CoverageServicePort = GetConfigValue("CoverageServicePort", "9090");
                EzeApiUrl = GetConfigValue("eze_api_url", "");
                PublishEzeToMq = GetConfigValue("publish_eze_to_mq", "NO");

                var isFullRefreshRequired = GetConfigValue("IsFullRefreshRequired", "YES");
                IsFullRefreshRequired = isFullRefreshRequired == "YES";

                FullRefreshBatchSize = GetConfigValue("FullRefreshBatchSize", 20);

                FullRefreshTimeInSeconds = GetConfigValue("FullRefreshTimeInSeconds", 1);
                PublishTimeInSeconds = GetConfigValue("PublishTimeInSeconds", 1);
                PublishBatchSize = GetConfigValue("PublishBatchSize", 1);

                var supportedSecurityTypes = GetConfigValue("SupportedSecurityTypes", "Equity,EquitySwap,EquityOption");
                SupportedSecurityTypes = new List<SecurityType>();
                foreach (var s in supportedSecurityTypes.Split(','))
                {
                    SecurityType sType;
                    if (!Enum.TryParse(s, true, out sType))
                    {
                        _logger.Debug("Invalid security type " + s);
                        continue;
                    }
                    SupportedSecurityTypes.Add(sType);
                }

                OrderFileLocation = GetConfigValue("order_file_location", "");

                if (string.IsNullOrWhiteSpace(OrderFileLocation))
                {
                    throw new ConfigurationErrorsException("Order file location is missing in app.config.");
                }

                var anonymousUrls = GetConfigValue("AnonymousUrls", "http://ems-gtwy-dev:8090/api/PublishCapture");
                AnonymousUrls = new List<string>();
                foreach (var s in anonymousUrls.Split(','))
                {
                    AnonymousUrls.Add(s);
                }
           

                SeedSodPositionsFromEms = GetConfigValue("SeedSodPositionsFromEms", true);

                PublishOrdersToMq = GetConfigValue("PublishOrdersToMq", true);
                PublishPositionsToMq = GetConfigValue("PublishOrdersToMq", true);


                var locatePrimeBrokers = ConfigurationManager.GetSection("LocateBrokerMpids") as NameValueCollection;
                if (locatePrimeBrokers != null)
                {
                    LocateBrokerMpidOverrides = locatePrimeBrokers.Cast<string>()
                        .Select(s => new { Key = s, Value = locatePrimeBrokers[s] })
                        .ToDictionary(p => p.Key, p => p.Value);
                }
            }
            catch (Exception ex)
            {
                _logger.Fatal($"Unable to perform settings initialization {ex.Message} {ex.StackTrace}");
                throw;
            }
        }

        private static T GetConfigValue<T>(string parameterName, T defaultValue)
        {
            object val = ConfigurationManager.AppSettings[parameterName];
            if (val != null)
            {
                try
                {
                    return (T)Convert.ChangeType(val, typeof(T));
                }
                catch
                {
                    return defaultValue;
                }
            }
            return defaultValue;
        }

        public string BaseUrl { get; set; }
        public string BasePort { get; set; }

        public DateTime SODDateTime { get; set; }

        public DateTime DefaultSODDateTime { get; set; }

        public string OrderGatewayConnectionString { get; set; }
        public string ContingencyConnectionString { get; set; }
        public string BamCoreLiteConnectionString { get; set; }
        public int ContingencyTimerInterval { get; set; }
        public int MaxResubscribeAttempt { get; set; }
        public int EmsResubscribeWaitInterval { get; set; }
        public int MaxStripedProcessors { get; set; }

        public string MqConnectionString { get; set; }
        public string MqAmConnectionString { get; set; }

        public string MqEODTradeTopic { get; set; }

        public string MqEODOrderTopic { get; set; }

        public string MqEODPositionTopic { get; set; }

        public string MqTradeTopic { get; set; }

        public string MqOrderTopic { get; set; }

        public string MqPositionTopic { get; set; }
        public string MqAccountTopic { get; set; }

        public string MqMarketDataTopic { get; set; }

        public string MqMarketDataSubscribeQueue { get; set; }
        
        public IDictionary<string, string> ManagerCodeMap { get; private set; }

        public IDictionary<string, string> PortfolioToComplianceGroup { get; private set; }

        public IDictionary<string, string> PortfolioToAggUnit { get; private set; }


        public string FlexHost { get; set; }
        public string FlexPort { get; set; }

        public int ConnectionRetryInterval { get; set; }

        public int EMSPingInterval { get; set; }

        public string PermissionedApplications { get; set; }

        public EmsSystem EmsName { get; private set; }    
        
        public string EzeUserName { get; private set; }

        public string EzePassword { get; private set; }

        public string MqEzeOrderTopic { get; set; }
        public string EnablePermission { get; set; }

        public string CoverageServiceHost { get; set;  }

        public string CoverageServicePort { get; set; }

        public string EzeApiUrl { get; set; }
        public string PublishEzeToMq { get; set; }

        public bool IsFullRefreshRequired { get; set; }
        public int FullRefreshBatchSize { get; set; }
        public int FullRefreshTimeInSeconds { get; set; }
        public int PublishTimeInSeconds { get; set; }
        public int PublishBatchSize { get; set; }
        public IList<SecurityType> SupportedSecurityTypes { get; set; }

        public string OrderFileLocation { get; private set; }
        public bool SeedSodPositionsFromEms { get; private set; }

        public IList<string> AnonymousUrls { get; set; }

        public bool IsSecurityTypeSupported(SecurityType type)
        {
            return (SupportedSecurityTypes == null || !SupportedSecurityTypes.Any() || SupportedSecurityTypes.Any(t => t == type));
        }

        public bool PublishOrdersToMq { get; private set; }
        public bool PublishPositionsToMq { get; private set; }
        public int EzeSubmissionRetryCount { get; private set; }
        public IDictionary<string, string> LocateBrokerMpidOverrides { get; set; }
    }
}
