﻿using Bam.EventQ.Solace;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Solace
{
    public class TradeSolaceTopicProvider : ISolaceTopicProvider<Trade>
    {
        private readonly string _baseTopic;

        public TradeSolaceTopicProvider(string baseTopic)
        {
            _baseTopic = baseTopic ?? string.Empty;
            if (_baseTopic.Length > 0 && !_baseTopic.EndsWith("/"))
            {
                _baseTopic += "/";
            }
        }

        public string GetTopic(Trade item)
        {
            return $"{_baseTopic}{item.Portfolio.AggregationUnit}/{item.DataSource}/{item.TradeId}";
        }
    }
}
