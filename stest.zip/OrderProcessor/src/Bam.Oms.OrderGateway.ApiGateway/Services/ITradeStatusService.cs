﻿using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public interface ITradeStatusService
    {
        TradeStatus GetStatus(string tradeId, long filledQuantity, bool isFinalized);
    }
}