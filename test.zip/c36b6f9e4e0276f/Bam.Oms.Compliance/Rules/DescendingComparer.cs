﻿using System.Collections.Generic;

namespace Bam.Oms.Compliance.Rules
{
    public class DescendingComparer : IComparer<decimal>
    {
        private const decimal Eps = 1E-10m;
        public int Compare(decimal x, decimal y)
        { return y > x + Eps ? 1 : y < x - Eps ? -1 : 0; }
    }
}
