﻿namespace Bam.EventQ.Queue
{
    public interface IQueueItemProducer<in TItem>
    {
        void Initialize(IQueue<TItem> queue);
        bool CanPause { get; }
        void Start();
        void Stop();
        void Pause();
        void Resume();
    }
}
