﻿using System;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public class HeadroomEffectCalculator : IHeadroomEffectCalculator
    {
        public HeadroomEffects Calculate(HeadroomInfo info)
        {
            if (info.IsOmni)
            {
                return default(HeadroomEffects);
            }

            return new HeadroomEffects
            {
                Long = CalculateLongEffect(info),
                Short = CalculateShortEffect(info),
                NetShort = CalculateNetShortEffect(info),
                NetLong = CalculateNetLongEffect(info)
            };
        }

        private long CalculateLongEffect(HeadroomInfo info)
        {
            if (info.Side.IsSellSide())
            {
                return Math.Min(info.FilledQuantity, info.ClosingQuantity);
            }

            long filled = Math.Min(info.FilledQuantity, info.FilledQuantity - info.ClosingQuantity);
            if (filled < 0) filled = 0;

            long qty = info.IsDead ? filled : info.TotalQuantity;
            return -Math.Min(qty, info.OpeningQuantity);
        }

        private long CalculateShortEffect(HeadroomInfo info)
        {
            if (!info.Side.IsSellSide())
            {
                return Math.Min(info.FilledQuantity, info.ClosingQuantity);
            }

            long filled = Math.Min(info.FilledQuantity, info.FilledQuantity - info.OpeningQuantity);
            if (filled < 0) filled = 0;

            long qty = info.IsDead ? filled : info.TotalQuantity;
            return -Math.Min(qty, info.OpeningQuantity);
        }

        private long CalculateNetShortEffect(HeadroomInfo info)
        {
            long qty = info.IsDead ? info.FilledQuantity : info.TotalQuantity;
            if (info.Side.IsSellSide())
            {
                return -qty;
            }

            return info.FilledQuantity;
        }

        private long CalculateNetLongEffect(HeadroomInfo info)
        {
            long qty = info.IsDead ? info.FilledQuantity : info.TotalQuantity;
            if (!info.Side.IsSellSide())
            {
                return -qty;
            }

            return info.FilledQuantity;
        }
    }
}