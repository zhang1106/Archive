﻿using System;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Positions;
using BAM.Infrastructure.Ioc;
using Dapper;

namespace Bam.Oms.Persistence.Positions
{
    public sealed class PositionArchiveRepository : DBRepository<PositionArchive>, IPositionArchiveRepository
    {
        /// <summary>
        /// Function to map DB Columns to PositionArchive object fields
        /// </summary>
        private static readonly Func<dynamic, PositionArchive> ResultMap = (item) => new PositionArchive
        {
            Position = PositionDBRepository.ResultMap(item),
            PositionArchiveId = item.PositionArchiveId
        };

        /// <summary>
        /// Function to map PositionArchive fields to DB columns
        /// </summary>
        private static readonly Func<PositionArchive, dynamic> ParameterMap =
            positionArchive => PositionDBRepository.ParameterMap(positionArchive.Position);

        public PositionArchiveRepository(ISettings settings, ILogger logger) : base(settings, logger, "sod", "PositionArchive", ResultMap, ParameterMap)
        {
            _includeColumnPredicate = (column => !column.Equals("Key"));
        }

        public void ArchivePositions(string stream)
        {
            if (stream == null)
            {
                throw new Exception("Stream mustn't be empty");
            }

            using (var connection = Connection)
            {
                connection.Execute(@"INSERT INTO [sod].[PositionArchive](
                                   [PositionId], [FundCode], [CustodianName], [CustodianAccountCode], [Cost], [StrategyCode],
                                   [AssetType], [BAMSymbol], [Qty], [Price], [Ccy], [FXRate], [EntryDate], [ActionLogId],
                                   [AuditSequence], [Stream], [LastModifiedBy], [LastModifiedOn], [CreatedOn]
                               )
                               SELECT [PositionId], [FundCode], [CustodianName], [CustodianAccountCode], [Cost], [StrategyCode],
                                   [AssetType], [BAMSymbol], [Qty], [Price], [Ccy], [FXRate], [EntryDate], [ActionLogId],
                                   [AuditSequence], [Stream], [LastModifiedBy], [LastModifiedOn], [CreatedOn]
                                 FROM [sod].[Position]
                                WHERE [Stream] = @stream;
                                DELETE FROM [sod].[Position]
                                 WHERE [Stream] = @stream", new { stream });
            }
        }
    }
}
