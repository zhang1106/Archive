﻿using Bam.EventQ.Sequencing;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Transport
{
    public abstract class MessageRpcRequestHandler : IRcpRequestHandler
    {
        public byte[] Invoke(string inquiry, byte[] payload)
        {
            var message = MessageSerializer.Current.Deserialize(payload, 0, payload.Length);
            var response = Invoke(inquiry, message);
            return new[] { response };
        }

        protected abstract byte Invoke(string inquiry, IMessage message);
        public abstract bool CanHandle(string inquiry);
    }
}
