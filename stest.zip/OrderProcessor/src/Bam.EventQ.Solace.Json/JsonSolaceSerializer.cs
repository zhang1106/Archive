﻿using System.IO;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using SolaceSystems.Solclient.Messaging;

namespace Bam.EventQ.Solace.Json
{
    public class JsonSolaceSerializer : ISolaceMessageSerializer<object>
    {
        private readonly JsonSerializer _serializer;
        private readonly CompatibilityMode _compatibilityMode;
        private readonly MemoryStream _stream;
        private readonly StreamWriter _writer;
        private readonly Encoding _encoding;

        public enum CompatibilityMode
        {
            SharedMessagingLibrary,
            Performance
        }        

        public JsonSolaceSerializer(CompatibilityMode compatibilityMode = CompatibilityMode.Performance)
        {
            _compatibilityMode = compatibilityMode;
            _serializer = new JsonSerializer();
            _serializer.Converters.Add(new StringEnumConverter());

            if (_compatibilityMode == CompatibilityMode.SharedMessagingLibrary)
            {
                _encoding = new UnicodeEncoding(false, false, false);
            }
            else
            {
                _encoding = new UTF8Encoding(false, false);
            }

            _stream = new MemoryStream(1024 * 1024);
            _writer = new StreamWriter(_stream, _encoding, 4096, true);
        }

        public void Serialize(IMessage target, object payload)
        {
            _stream.SetLength(0);
            _serializer.Serialize(_writer, payload);
            _writer.Flush();

            target.BinaryAttachment = _stream.ToArray();
            if (_compatibilityMode == CompatibilityMode.SharedMessagingLibrary)
            {
                if (target.UserPropertyMap == null)
                {
                    target.UserPropertyMap = target.CreateUserPropertyMap();
                }

                target.UserPropertyMap.AddString("SerializationMode", "Json");
            }
            else
            {
                target.HttpContentType = "application/json";
                target.HttpContentEncoding = _encoding.WebName;
            }
        }
    }
}
