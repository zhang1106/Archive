﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Contingency;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [Ignore]
    [Category("Integration")]
    [TestFixture()]
    public class ContingencyDbRepositoryTests
    { 
        private string _connectionString = @"Data Source=bos-db-dev;Initial Catalog = BossApp; UID=BossApp;Pwd=BossApp1;Application Name = OrderGateway";                   

        [Test()]
        public void SaveItemTest()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.SetupGet(s => s.ContingencyConnectionString).Returns(_connectionString);
            IContingencyDbRepository repo = new ContingencyDbRepository(settings.Object, new Mock<ILogger>().Object);

            ContingencyRecord item = new ContingencyRecord()
            {
                Portfolio = "MYPORTFOLIO-MYSTRATEGY",
                SymbolType = "EQ",
                Symbol = "WBA",
                SymbolDesc = "WALGREENS BOOTS ALLIANCE INC",
                SymbolPricing = "WBA",
                Quantity = -156000.000000000m,
                SodPriceNative = 84.030000m,
                SodMarketValueNative = -13108680.000000m,
                Multiplier = 1.0000000000m,
                Currency = "USD",
                FxRate = 1.0000000000m,
                Country = "USA",
                Industry = "Food & Staples Retailing",
                UnderlyingSymbol = "WBA",
                SysDate = DateTime.Now
            };

            ContingencyRecord saveditem = repo.Save(item);
            Assert.That(item.IsExact(saveditem));
        }

        [Test()]
        public void SaveItemsTest()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.SetupGet(s => s.ContingencyConnectionString).Returns(_connectionString);
            IContingencyDbRepository repo = new ContingencyDbRepository(settings.Object, new Mock<ILogger>().Object);

            IList<ContingencyRecord> recordsToSave = new List<ContingencyRecord>();    
            
            ContingencyRecord item1 = new ContingencyRecord()
            {
                Portfolio = "MYPORTFOLIO-MYSTRATEGY",
                SymbolType = "EQ",
                Symbol = "WBA",
                SymbolDesc = "WALGREENS BOOTS ALLIANCE INC",
                SymbolPricing = "WBA",
                Quantity = -156000.000000000m,
                SodPriceNative = 84.030000m,
                SodMarketValueNative = -13108680.000000m,
                Multiplier = 1.0000000000m,
                Currency = "USD",
                FxRate = 1.0000000000m,
                Country = "USA",
                Industry = "Food & Staples Retailing",
                UnderlyingSymbol = "WBA",
                SysDate = DateTime.Now
            };

            ContingencyRecord item2 = new ContingencyRecord()
            {
                Portfolio = "MYPORTFOLIO1-MYSTRATEGY1",
                SymbolType = "EQ",
                Symbol = "KEY",
                SymbolDesc = "KEYCORP",
                SymbolPricing = "KEY",
                Quantity = 791488.000000000m,
                SodPriceNative = 13.110748m,
                SodMarketValueNative = 10377000.120000m,
                Multiplier = 1.0000000000m,
                Currency = "USD",
                FxRate = 1.0000000000m,
                Country = "USA",
                Industry = "Banks",
                UnderlyingSymbol = "KEY",
                SysDate = DateTime.Now
            };
            recordsToSave.Add(item1);
            recordsToSave.Add(item2);

            IList<ContingencyRecord> saveditems = repo.Save(recordsToSave).ToList();
            Assert.AreEqual(recordsToSave, saveditems);
        }

        [Test]
        public void TestGetByKey()
        {
            //Save first
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.SetupGet(s => s.ContingencyConnectionString).Returns(_connectionString);
            IContingencyDbRepository repo = new ContingencyDbRepository(settings.Object, new Mock<ILogger>().Object);

            ContingencyRecord item = new ContingencyRecord()
            {
                Portfolio = "MYPORTFOLIO-MYSTRATEGY",
                SymbolType = "EQ",
                Symbol = "WBA",
                SymbolDesc = "WALGREENS BOOTS ALLIANCE INC",
                SymbolPricing = "WBA",
                Quantity = -156000.000000000m,
                SodPriceNative = 84.030000m,
                SodMarketValueNative = -13108680.000000m,
                Multiplier = 1.0000000000m,
                Currency = "USD",
                FxRate = 1.0000000000m,
                Country = "USA",
                Industry = "Food & Staples Retailing",
                UnderlyingSymbol = "WBA",
                SysDate = DateTime.Now
            };

            ContingencyRecord saveditem = repo.Save(item);

            ContingencyRecord fetchedItem = repo.Get(item.Key).FirstOrDefault();
            Assert.AreEqual(item, fetchedItem);
        }

        [Test]
        public void TestGetByCutOffTime()
        {
            DateTime cutoffTime = DateTime.Now;
            //Save first
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.SetupGet(s => s.ContingencyConnectionString).Returns(_connectionString);
            IContingencyDbRepository repo = new ContingencyDbRepository(settings.Object, new Mock<ILogger>().Object);

            ContingencyRecord item = new ContingencyRecord()
            {
                Portfolio = "MYPORTFOLIO-MYSTRATEGY",
                SymbolType = "EQ",
                Symbol = "WBA",
                SymbolDesc = "WALGREENS BOOTS ALLIANCE INC",
                SymbolPricing = "WBA",
                Quantity = -156000.000000000m,
                SodPriceNative = 84.030000m,
                SodMarketValueNative = -13108680.000000m,
                Multiplier = 1.0000000000m,
                Currency = "USD",
                FxRate = 1.0000000000m,
                Country = "USA",
                Industry = "Food & Staples Retailing",
                UnderlyingSymbol = "WBA",
                SysDate = DateTime.Now
            };

            ContingencyRecord saveditem = repo.Save(item);

            ContingencyRecord fetchedItem = repo.Get(cutoffTime).FirstOrDefault();
            Assert.AreEqual(item, fetchedItem);

            IEnumerable<ContingencyRecord> fetchedItems = repo.Get(DateTime.Now);
            Assert.That(!fetchedItems.Any());
        }
    }
}