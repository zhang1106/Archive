﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Bam.EventQ.Lookup
{
    public class ModelIndex<T> : IModelIndex<T>
    {
        private readonly HashSet<T> _all = new HashSet<T>();
        private readonly Dictionary<string, object> _lookups = new Dictionary<string, object>(1024);
        private readonly Dictionary<string, object> _multiLookups = new Dictionary<string, object>(1024);

        private readonly Dictionary<string, Tuple<Action<object, T>, Action<object, T>>> _dictMethods =
            new Dictionary<string, Tuple<Action<object, T>, Action<object, T>>>(1024);
        private readonly Dictionary<string, Tuple<Action<object, T>, Action<object, T>>> _multiDictMethods =
            new Dictionary<string, Tuple<Action<object, T>, Action<object, T>>>(1024);

        private readonly Dictionary<string, Func<T, object>> _propertyContainerFuncs = 
            new Dictionary<string, Func<T, object>>();
        private readonly Dictionary<object, Dictionary<string, HashSet<T>>> _attachedNotifyPropertyChanged =
            new Dictionary<object, Dictionary<string, HashSet<T>>>();

        public T LookupBy<TProp>(string property, TProp value)
        {
            object item;
            bool attachINotify = false;
            if (!_lookups.TryGetValue(property, out item))
            {
                var element = Expression.Parameter(typeof(T), "p");
                var prop = GetProperty(element, property);
                var lambda = Expression.Lambda<Func<T, TProp>>(prop, element);

                var d = new Dictionary<TProp, T>();
                IndexAll(d, lambda);
                item = _lookups[property] = d;
                attachINotify = true;
            }
            
            var dict = (Dictionary<TProp, T>)item;
            T match;
            if (!dict.TryGetValue(value, out match))
            {
                return default(T);
            }

            if (attachINotify)
            {
                AddINotifyChangedByParent(match, property);
            }

            return match;
        }

        public LookupList<T> MultiLookupBy<TProp>(string property, TProp value)
        {
            object item;
            bool attachINotify = false;
            if (!_multiLookups.TryGetValue(property, out item))
            {
                var element = Expression.Parameter(typeof(T), "p");
                var prop = GetProperty(element, property);
                var lambda = Expression.Lambda<Func<T, TProp>>(prop, element);

                var d = new Dictionary<TProp, MutableLookupList<T>>();
                IndexAll(d, lambda);
                item = _multiLookups[property] = d;
                attachINotify = true;
            }

            var dict = (Dictionary<TProp, MutableLookupList<T>>) item;
            MutableLookupList<T> match;
            if (!dict.TryGetValue(value, out match))
            {
                return LookupList<T>.Empty;
            }

            if (attachINotify)
            {
                foreach (var matchingItem in match)
                {
                    AddINotifyChangedByParent(matchingItem, property);
                }
            }

            return match;
        }

        public IReadOnlyList<T> GetAll()
        {
            return _all.ToArray();
        }

        public void Clear()
        {
            _all.Clear();
            _dictMethods.Clear();
            _lookups.Clear();
        }

        public void Insert(T item)
        {
            if (_all.Add(item))
            {
                foreach (string prop in _lookups.Keys)
                {
                    AddToIndex(prop, item);
                    AddINotifyChangedByParent(item, prop);
                }

                foreach (string prop in _multiLookups.Keys)
                {
                    AddToIndex(prop, item);
                    AddINotifyChangedByParent(item, prop);
                }
            }
        }

        public void Remove(T item)
        {
            if (_all.Remove(item))
            {
                foreach (string prop in _lookups.Keys)
                {
                    RemoveFromIndex(prop, item);
                    RemoveINotifyChangedByParent(item, prop);
                }

                foreach (string prop in _multiLookups.Keys)
                {
                    RemoveFromIndex(prop, item);
                    RemoveINotifyChangedByParent(item, prop);
                }
            }
        }

        private void ItemOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            Dictionary<string, HashSet<T>> parentPaths;
            if (_attachedNotifyPropertyChanged.TryGetValue(sender, out parentPaths))
            {
                foreach (var path in parentPaths)
                {
                    foreach (var parent in path.Value)
                    {
                        AddToIndex(path.Key, parent);
                    }
                }
            }
        }

        private void ItemOnPropertyChanging(object sender, PropertyChangingEventArgs e)
        {
            Dictionary<string, HashSet<T>> parentPaths;
            if (_attachedNotifyPropertyChanged.TryGetValue(sender, out parentPaths))
            {
                foreach (var path in parentPaths)
                {
                    foreach (var parent in path.Value)
                    {
                        RemoveFromIndex(path.Key, parent);
                    }
                }
            }
        }

        private void IndexAll<TProp>(Dictionary<TProp, T> dict, Expression<Func<T, TProp>> prop)
        {
            var lambda = prop.Compile();
            foreach (var item in _all)
            {
                if (lambda(item) == null)
                    continue;

                dict.Add(lambda(item), item);
            }
        }

        private void IndexAll<TProp>(Dictionary<TProp, MutableLookupList<T>> dict, Expression<Func<T, TProp>> prop)
        {
            var lambda = prop.Compile();
            foreach (var item in _all)
            {
                if (lambda(item) == null)
                    continue;

                MutableLookupList<T> list;
                if (!dict.TryGetValue(lambda(item), out list))
                {
                    dict.Add(lambda(item), list = new MutableLookupList<T>());
                }

                list.Add(item);
            }
        }

        public void AddToIndex(string property, T item)
        {
            object index;
            if (_lookups.TryGetValue(property, out index))
            {
                Tuple<Action<object, T>, Action<object, T>> actions;
                if (!_dictMethods.TryGetValue(property, out actions))
                {
                    actions = _dictMethods[property] = CompileActions(property);
                }

                actions.Item1(index, item);
            }
            else if (_multiLookups.TryGetValue(property, out index))
            {
                Tuple<Action<object, T>, Action<object, T>> actions;
                if (!_multiDictMethods.TryGetValue(property, out actions))
                {
                    actions = _multiDictMethods[property] = CompileMultiActions(property);
                }

                actions.Item1(index, item);
            }
        }

        public void RemoveFromIndex(string property, T item)
        {
            object index;
            if (_lookups.TryGetValue(property, out index))
            {
                Tuple<Action<object, T>, Action<object, T>> actions;
                if (!_dictMethods.TryGetValue(property, out actions))
                {
                    actions = _dictMethods[property] = CompileActions(property);
                }

                actions.Item2(index, item);
            }
            else if (_multiLookups.TryGetValue(property, out index))
            {
                Tuple<Action<object, T>, Action<object, T>> actions;
                if (!_multiDictMethods.TryGetValue(property, out actions))
                {
                    actions = _multiDictMethods[property] = CompileMultiActions(property);
                }

                actions.Item2(index, item);
            }
        }

        private Tuple<Action<object, T>, Action<object, T>> CompileActions(string property)
        {
            var itemParam = Expression.Parameter(typeof(T), "item");
            var prop = GetProperty(itemParam, property);

            var rawDictParam = Expression.Parameter(typeof(object), "dict");
            var dictParam = Expression.Convert(rawDictParam,
                typeof(Dictionary<,>).MakeGenericType(prop.Type, typeof(T)));

            var indexer = (from p in dictParam.Type.GetDefaultMembers().OfType<PropertyInfo>()
                where p.PropertyType == typeof(T)
                let q = p.GetIndexParameters()
                where q.Length == 1 && q[0].ParameterType == prop.Type
                select p).Single();

            var addCall = Expression.Assign(Expression.Property(dictParam, indexer, prop), itemParam);
            var removeCall = Expression.Call(dictParam, nameof(Dictionary<int, int>.Remove), new Type[] { }, prop);

            return new Tuple<Action<object, T>, Action<object, T>>(
                Expression.Lambda<Action<object, T>>(addCall, rawDictParam, itemParam).Compile(),
                Expression.Lambda<Action<object, T>>(removeCall, rawDictParam, itemParam).Compile());
        }

        private Tuple<Action<object, T>, Action<object, T>> CompileMultiActions(string property)
        {
            var itemParam = Expression.Parameter(typeof(T), "item");
            var prop = GetProperty(itemParam, property);

            var rawDictParam = Expression.Parameter(typeof(object), "dict");
            var dictParam = Expression.Convert(rawDictParam,
                typeof(Dictionary<,>).MakeGenericType(prop.Type, typeof(MutableLookupList<T>)));

            var addMi = GetType()
                .GetMethods(BindingFlags.Static | BindingFlags.NonPublic)
                .Single(m => m.Name == "MultiAdd")
                .MakeGenericMethod(prop.Type, typeof(T));
            var removeMi = GetType()
                .GetMethods(BindingFlags.Static | BindingFlags.NonPublic)
                .Single(m => m.Name == "MultiRemove")
                .MakeGenericMethod(prop.Type, typeof(T));

            var addCall = Expression.Call(addMi, dictParam, prop, itemParam);
            var removeCall = Expression.Call(removeMi, dictParam, prop, itemParam);

            return new Tuple<Action<object, T>, Action<object, T>>(
                Expression.Lambda<Action<object, T>>(addCall, rawDictParam, itemParam).Compile(),
                Expression.Lambda<Action<object, T>>(removeCall, rawDictParam, itemParam).Compile());
        }

        internal static void MultiAdd<TKey, TValue>(Dictionary<TKey, MutableLookupList<TValue>> dict, TKey key, TValue value)
        {
            if (key == null) return;

            MutableLookupList<TValue> item;
            if (!dict.TryGetValue(key, out item))
            {
                item = dict[key] = new MutableLookupList<TValue>();
            }

            item.Add(value);
        }

        internal static void MultiRemove<TKey, TValue>(Dictionary<TKey, MutableLookupList<TValue>> dict, TKey key, TValue value)
        {
            if (key == null) return;

            MutableLookupList<TValue> item;
            if (!dict.TryGetValue(key, out item))
            {
                return;
            }

            item.Remove(value);
            if (item.Count == 0)
            {
                dict.Remove(key);
            }
        }

        protected string GetPropertyName<TProp>(Expression<Func<T, TProp>> property)
        {
            var expr = property.Body as MemberExpression;
            return expr?.Member.Name;
        }

        private Expression GetProperty(ParameterExpression root, string propertyPath)
        {
            if (propertyPath.IndexOf('.') == -1)
            {
                return Expression.Property(root, propertyPath);
            }

            string[] chain = propertyPath.Split('.');
            Expression current = root;
            foreach (string name in chain)
            {
                current = Expression.Property(current, name);
            }

            var finalType = current.Type;
            var fallback = Expression.Default(finalType);
            return BuildSafePropertyAccessor(chain, 0, root, fallback);
        }

        private object GetPropertyContainer(T root, string propertyPath)
        {
            Func<T, object> accessor;
            if (!_propertyContainerFuncs.TryGetValue(propertyPath, out accessor))
            {
                if (propertyPath.IndexOf('.') == -1)
                {
                    accessor = t => t;
                }
                else
                {
                    var param = Expression.Parameter(typeof(T), "t");
                    var expr = GetProperty(param, propertyPath.Substring(0, propertyPath.LastIndexOf('.')));
                    var castExpr = Expression.Convert(expr, typeof(object));
                    var lambda = Expression.Lambda<Func<T, object>>(castExpr, param);
                    accessor = lambda.Compile();
                }

                _propertyContainerFuncs[propertyPath] = accessor;
            }

            return accessor(root);
        }

        private Expression BuildSafePropertyAccessor(string[] chain, int index,
            Expression current, Expression nullValue)
        {
            var property = Expression.Property(current, chain[index]);
            if (index + 1 == chain.Length)
                return property;

            return Expression.Condition(
                Expression.Equal(property, Expression.Default(property.Type)),
                nullValue,
                BuildSafePropertyAccessor(chain, index + 1, property, nullValue));
        }

        private void AddINotifyChangedByParent(T item, string prop)
        {
            var container = GetPropertyContainer(item, prop);

            Dictionary<string, HashSet<T>> parentsPath;
            if (!_attachedNotifyPropertyChanged.TryGetValue(container, out parentsPath))
            {
                _attachedNotifyPropertyChanged.Add(container, parentsPath = new Dictionary<string, HashSet<T>>());
            }

            HashSet<T> parent;
            if (!parentsPath.TryGetValue(prop, out parent))
            {
                parent = parentsPath[prop] = new HashSet<T>();
            }

            if (parent.Add(item))
            {
                var npc = container as INotifyPropertyChanged;
                if (npc != null) npc.PropertyChanged += ItemOnPropertyChanged;
                var npcc = container as INotifyPropertyChanging;
                if (npcc != null) npcc.PropertyChanging += ItemOnPropertyChanging;
            }
        }

        private void RemoveINotifyChangedByParent(T item, string prop)
        {
            var container = GetPropertyContainer(item, prop);

            Dictionary<string, HashSet<T>> parentsPath;
            HashSet<T> parent;
            if (_attachedNotifyPropertyChanged.TryGetValue(container, out parentsPath) && 
                parentsPath.TryGetValue(prop, out parent))
            {
                if (parent.Remove(item))
                {
                    var npc = container as INotifyPropertyChanged;
                    if (npc != null) npc.PropertyChanged -= ItemOnPropertyChanged;
                    var npcc = container as INotifyPropertyChanging;
                    if (npcc != null) npcc.PropertyChanging -= ItemOnPropertyChanging;
                }
            }
        }
    }
}