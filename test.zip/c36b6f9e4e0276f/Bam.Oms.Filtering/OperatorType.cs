﻿using System.Linq.Expressions;

namespace Bam.Oms.Filtering
{
    public enum OperatorType
    {
        Equal = ExpressionType.Equal,
        NotEqual = ExpressionType.NotEqual,
        InList,
        InTheList,
        Contains,
        StartsWith
    }
}
