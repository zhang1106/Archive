﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.OrderRouting.Contracts;

namespace Bam.Oms.OrderRouting.Flex
{
    public interface ISystemSubscriptionHost : ISubscriptionDisposable
    {
        event Action<string> RollStarted;
        event Action<string> RollCompleted;        
    }
}
