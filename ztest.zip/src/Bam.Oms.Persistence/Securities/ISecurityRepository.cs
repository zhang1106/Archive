﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Persistence.Securities
{
    public interface ISecurityRepository : IPersistentRepository<Security>
    {
        
    }
}
