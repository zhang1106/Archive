﻿using System;
using System.Collections.Generic;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Journal;

namespace Bam.Oms.Persistence.Compliance
{
    public class RuleResultRepository : PersistentRepository<RuleResult>, IRuleResultRepository
    {
        public RuleResultRepository(ILogger log, ISettings setting, IEventJournalFactory eventJournalFactory) : base("ComplianceResultCache", log, eventJournalFactory)
        {

        }
        public void Save(IEnumerable<IRuleResult> results)
        {
            foreach (var r in results)
            {
                r.BusinessDate = DateTime.Today;
                base.Save(r as RuleResult);
            }
        }

        public void SaveWithDate(RuleResult result)
        {
            result.BusinessDate = DateTime.Today;
            base.Save(result);
        }

    }
}
