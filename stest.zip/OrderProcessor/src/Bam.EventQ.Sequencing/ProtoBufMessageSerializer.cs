﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Bam.EventQ.Recovery;
using ProtoBuf.Meta;

namespace Bam.EventQ.Sequencing
{
    public class ProtoBufMessageSerializer : MessageSerializer
    {
        private readonly TypeModel _typeModel;

        public ProtoBufMessageSerializer(params Assembly[] messageAssemblies)
        {
            if (messageAssemblies?.Length == 0)
            {
                messageAssemblies = AppDomain.CurrentDomain.GetAssemblies();
            }

            _typeModel = CreateTypeModel(messageAssemblies);
        }

        public override int Serialize<T>(T message, byte[] buffer, int index)
        {
            message.Header.CopyTo(buffer, index);
            index += Message.HeaderSize;
            using (var ms = new MemoryStream(buffer, index, buffer.Length - index))
            {
                _typeModel.Serialize(ms, message);
                return unchecked((int)ms.Position + Message.HeaderSize);
            }
        }

        public override IMessage Deserialize(byte[] buffer, int index, int count)
        {
            count -= Message.HeaderSize;
            using (var ms = new MemoryStream(buffer, index + Message.HeaderSize, count))
            {
                var msg = (IMessage)_typeModel.Deserialize(ms, null, typeof(IMessage), count);
                msg.Header = buffer.ToMessageHeader(index);
                return msg;
            }
        }

        public static T CreateMessage<T>()
        {
            return MessageFactory.Current.Create<T>();
        }

        private static TypeModel CreateTypeModel(Assembly[] messageAssemblies)
        {
            var typeModel = TypeModel.Create();

            var hierarchy = new Dictionary<Type, MetaType>
            {
                {typeof(IMessage), typeModel.Add(typeof(IMessage), false)}
            };

            var types = messageAssemblies
                .SelectMany(a => a.GetTypes()).ToList();

            var messageTypes = (
                from t in types.OrderBy(t => t.Name)
                where typeof(IMessage).IsAssignableFrom(t) && !t.IsInterface && !t.IsGenericTypeDefinition
                let props = t.GetProperties().Where(p => p.DeclaringType == t)
                let parent = GetParentType(t)
                where parent != typeof(object)
                select new
                {
                    Type = t,
                    ParentType = parent,
                    Properties = props.Where(p => p.PropertyType != typeof(SequenceInfo)).OrderBy(p => p.Name).ToArray()
                }).Concat(
                from t in types.OrderBy(t => t.Name)
                where typeof(IBatchMessage).IsAssignableFrom(t) && !t.IsInterface
                let batchMsg = t.BaseType
                where batchMsg != typeof(Message)
                let props = batchMsg.GetProperties().Where(p => p.DeclaringType == batchMsg)
                let item = new 
                {
                    Type = batchMsg,
                    ParentType = batchMsg.BaseType,
                    Properties = props.Where(p => p.PropertyType != typeof(SequenceInfo)).OrderBy(p => p.Name).ToArray()
                }
                group item by item.Type into g
                select new
                {
                    Type = g.Key, g.First().ParentType, g.First().Properties,
                }).ToList();

            var factoryMi = typeof(ProtoBufMessageSerializer).GetMethod(nameof(CreateMessage),
                BindingFlags.Static | BindingFlags.Public);

            int subTypeId = 1000;
            while (messageTypes.Count > 0)
            {
                for (int i = messageTypes.Count - 1; i >= 0; i--)
                {
                    MetaType parentMetaType;
                    if (hierarchy.TryGetValue(messageTypes[i].ParentType, out parentMetaType))
                    {
                        parentMetaType.AddSubType(subTypeId++, messageTypes[i].Type);
                        var metaType = typeModel.Add(messageTypes[i].Type, false);
                        metaType.SetFactory(factoryMi.MakeGenericMethod(messageTypes[i].Type));
                        for (int j = 0; j < messageTypes[i].Properties.Length; j++)
                        {
                            var prop = messageTypes[i].Properties[j];
                            int index = parentMetaType.GetFields().Length + 1 + j;
                            metaType.AddField(index, prop.Name);
                        }

                        foreach (var nt in messageTypes[i].Type.GetNestedTypes())
                        {
                            var nestedMetaType = typeModel.Add(nt, false);
                            nestedMetaType.SetFactory(factoryMi.MakeGenericMethod(nt));
                            var props = nt.GetProperties().OrderBy(p => p.Name);
                            int field = 1;
                            foreach (var prop in props)
                            {
                                nestedMetaType.AddField(field++, prop.Name);
                            }
                        }

                        hierarchy[messageTypes[i].Type] = metaType;
                        messageTypes.RemoveAt(i);
                    }
                }
            }

            return typeModel.Compile();
        }

        private static Type GetParentType(Type type)
        {
            if (type == typeof(Message))
                return typeof(IMessage);

            if (type == typeof(IBatchMessage))
                return typeof(IMessage);

            if (typeof(IBatchMessage).IsAssignableFrom(type) && type.IsInterface)
                return typeof(IMessage);
            
            return type.BaseType;
        }
    }
}
