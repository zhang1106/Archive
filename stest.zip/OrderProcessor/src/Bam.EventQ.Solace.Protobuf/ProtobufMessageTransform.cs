﻿using System;
using Bam.EventQ.Pooling;
using Google.Protobuf;
using IMessage = SolaceSystems.Solclient.Messaging.IMessage;

namespace Bam.EventQ.Solace.Protobuf
{
    public class ProtobufMessageTransform<TProto> : ISolaceMessageTransform 
        where TProto : IMessage<TProto>, new()
    {
        private readonly IObjectPool _pool;
        private readonly Func<TProto, int> _topicFunc;
        private readonly SerializeDelegate _serialize;
        private readonly MessageParser<TProto> _parser;

        public delegate void SerializeDelegate(TProto obj, byte[] buffer, int index, out int length);

        public ProtobufMessageTransform(
            Func<TProto, int> topicFunc, SerializeDelegate serialize)
            : this(new NullObjectPool(), topicFunc, serialize)
        {
            
        }

        public ProtobufMessageTransform(IObjectPool pool, 
            Func<TProto, int> topicFunc, SerializeDelegate serialize)
        {
            _pool = pool;
            _topicFunc = topicFunc;
            _serialize = serialize;
            _parser = new MessageParser<TProto>(() => _pool.Get<TProto>());
        }

        public void Transform(IMessage source, byte[] buffer, int index, out int received, out int topic)
        {
            var proto = _parser.ParseFrom(source.BinaryAttachment);
            topic = _topicFunc(proto);
            _serialize(proto, buffer, index, out received);
            _pool.Release(proto);
        }
    }
}
