﻿using System.Collections.Generic;

namespace Bam.Oms.Data.Compliance
{
    public class Fact : IFact, IPersistentItem
    {
        public string Key => Name;
        public int FactId { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }

        public HashSet<string> GetList()
        {
            if (Value == null) return null;
            HashSet<string> set = new HashSet<string>();
            var list = Value.Split(',');
            foreach (var item in list)
            {
                if (set.Contains(item)) continue;
                set.Add(item.Trim());
            }
            return set;
        }
    }
}
