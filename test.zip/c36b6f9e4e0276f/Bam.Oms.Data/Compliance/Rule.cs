﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Bam.Oms.Data.Compliance
{
    public class Rule<T> : IRule<T>
    {
        public string Key => Id.ToString();
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }   //turn on/off a rule
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ParamsInJson { get; set; }
        [JsonProperty]
        public Dictionary<string, decimal> Ratio { get; set; }
        [JsonProperty]
        public bool IncludeConstituent { get; set; }
        /// <summary>
        /// check only if rule is active or not
        /// </summary>
        /// <param name="input"></param>
        /// <param name="isPreCheck"></param>
        /// <returns></returns>
        public virtual IRuleResult CheckViolation(T input, bool isPreCheck)
        {
            RuleResult ruleResult = new RuleResult() { RuleId = Id,
                AlertLevel = Enumerators.ComplianceAlertLevel.NoViolation
            };

            return ruleResult; 
        }
    }
}
