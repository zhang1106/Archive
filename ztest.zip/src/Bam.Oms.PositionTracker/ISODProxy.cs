﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.PositionTracker
{
    public interface ISODProxy : IDisposable
    {
        event Action<IList<Position>> SodPositionUpdated;
        void Initialize();
        IList<IPosition> GetPositions(string bamSymbol);
    }
}