﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.RestApi;
using Bam.Oms.Data.Securities;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using Newtonsoft.Json;

namespace Bam.Oms.EndPoints.Orders
{
    public class OrderController : BaseController, IOrderController
    {
        private readonly IOrderNotifier _notifier;
        private readonly IOrderPrepUtility _orderPrepUtility;
        private readonly IOrderValidator _orderValidator;
        private readonly IAccountService _accountService;
        private readonly IFlowManager _flowManager;
        private readonly IOrderRepository _orderRepository;

        private string EntryUser => User?.Identity?.Name.Replace("FOUNTAINHEAD\\", "");

        public OrderController(IOrderNotifier notifier, IOrderRepository orderRepository,
            IHostConfiguration hostConfiguration, IOrderPrepUtility orderPrepUtility, ILogger logger,
            IOrderValidator orderValidator, IAccountService accountService, IFlowManager flowManager)
            : base(hostConfiguration, logger)
        {
            if (notifier == null) throw new ArgumentNullException(nameof(notifier));
            if (orderRepository == null) throw new ArgumentNullException(nameof(orderRepository));
            if (orderPrepUtility == null) throw new ArgumentNullException(nameof(orderPrepUtility));
            if (orderValidator == null) throw new ArgumentNullException(nameof(orderValidator));
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));

            _notifier = notifier;
            _orderRepository = orderRepository;
            _orderPrepUtility = orderPrepUtility;
            _orderValidator = orderValidator;
            _accountService = accountService;
            _flowManager = flowManager;
        }

        [AccessRequire("Function.PMUI.Write")]
        public List<string> PostOrders(Order[] orders)
        {
            return PostOrders(orders, false);
        }

        private List<string> PostOrders(Order[] orders, bool omitScaling)
        {
            var permissionedOrders = FilterPermissionedEntities(orders);
            var orderList = permissionedOrders.ToList();

            if (!_orderValidator.IsValidOrder(orderList.Cast<IOrder>().ToList()))
            {
                _logger.Error($"Batch contains invalid orders.  Failing {orders.Length} orders.");
                return null; //todo: come up with better way to notify API user
            }

            // security details have to be set before the custodian is assigned
            var orderIds = _orderPrepUtility.AssignOrderIds(orderList);
            _orderPrepUtility.SetTradeDate(orderList);
            _orderPrepUtility.SetOrderStatus(orderList);
            _orderPrepUtility.SetSecurityInformation(orderList);
            _orderPrepUtility.SetCustodian(orderList);
            _orderPrepUtility.SetTrader(orderList, EntryUser);
            _orderPrepUtility.SetCreatedUser(orderList, EntryUser);

            _accountService.SetAccountAttributes(orderList);
            if(!omitScaling)
                orderList = _orderPrepUtility.ScaleOrders(orderList).Cast<Order>().ToList();

            // NOTE: Batch Id is set on the PMUI for now
            _notifier.NotifyNewOrders(new List<IOrder>(orderList));
            return orderIds.ToList();
        }



        [AccessRequire("Function.PMUI.Write")]
        public int DeleteOrders([FromUri] string[] ordersIds)
        {
            return DeleteOrders(ordersIds, false);
        }

        [AccessRequire("Function.PMUI.Write")]
        public int DeleteOrders([FromUri] string[] ordersIds, bool delete)
        {
            var matchingOrders = new List<Order>();
            matchingOrders.AddRange(ordersIds.Select(orderId => _orderRepository.Get(orderId)).ToList());


            var nullFilteredOrders = matchingOrders.Where(o => o != null).ToList();

            IEnumerable<IOrder> permissionedOrders = FilterPermissionedEntities(nullFilteredOrders);
            var permissionedOrdersAsList = permissionedOrders as IList<IOrder> ?? permissionedOrders.ToList();

            if (!permissionedOrdersAsList.Any()) return 0;

            IList<string> permissionedOrderIds = permissionedOrdersAsList.Select(order => order.ClientOrderId).ToList();

            if (delete)
                _notifier.NotifyDeleteOrders(permissionedOrderIds);
            else
                _notifier.NotifyCancelOrders(permissionedOrderIds);

            return permissionedOrderIds.Count;
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Admin")]
        public string Publish(bool eod)
        {
            _flowManager.PublishOrders(eod, FlowClientScope.Both);
            return "publishing all orders to downstream systems";
        }

        [AccessRequire("Function.PMUI.Write")]
        public string PostAmendedOrder(Order order)
        {
            IEnumerable<IOrder> permissionedOrders = FilterPermissionedEntities(new[] { order });

            var permissionedOrdersAsList = permissionedOrders as IList<IOrder> ?? permissionedOrders.ToList();
            if (!permissionedOrdersAsList.Any())
                return $"Permission denied.  You do not have access to change order {order.ClientOrderId}";

            var originalOrder = _orderRepository.Get(order.ClientOrderId);

            if (IsAmendable(originalOrder))
            {
                var deletedCount = DeleteOrders(new[] {originalOrder.ClientOrderId}, true);

                if (deletedCount == 1)
                {
                    order.OriginalOrderId = originalOrder.ClientOrderId;
                    var newOrderId = PostOrders(new[] {order}, true);

                    if (newOrderId != null && newOrderId.Count == 1)
                        return newOrderId[0];
                }
                else
                {
                    _logger.Error($"Unable to delete original order {originalOrder.ClientOrderId}");
                }
            }
            else
            {
                _logger.Error($"Cannot modify an order in {originalOrder.OrderStatus} state");
            }

            return "";
        }

        private bool IsAmendable(IOrder originalOrder)
        {
            return originalOrder.OrderStatus != BamOrderStatus.Working
                   && originalOrder.OrderStatus != BamOrderStatus.New
                   && originalOrder.OrderStatus != BamOrderStatus.Filled
                   && originalOrder.OrderStatus != BamOrderStatus.Cancelled
                   && originalOrder.OrderStatus != BamOrderStatus.Finalized
                   && originalOrder.OrderStatus != BamOrderStatus.PendingAck
                   && originalOrder.OrderStatus != BamOrderStatus.PendingCancel
                ;

        }


        [AccessRequire("Function.PMUI.Read,Function.PMUI.Write")]
        public Order Get(string key)
        {
            Order order = null;
            order = _orderRepository.Get(key);

            if (order == null)
                return null;
            IEnumerable<IOrder> permissionedOrders = FilterPermissionedEntities(new List<Order> { order });
            return permissionedOrders.Any() ? order : null;
        }

        [AccessRequire("Function.PMUI.Read,Function.PMUI.Write")]
        public List<Order> Get()
        {
            return Get((DateTime?)null);
        }

        [HttpGet]
        [AccessRequire("Function.PMUI.Write")]
        public List<string> CloneOrders([FromUri] string[] orderIds)
        {
            var orders = new List<IOrder>(orderIds.Length);
            foreach (var id in orderIds)
            {
                var existing = _orderRepository.Get(id);
                if (existing == null) continue;

                _logger.Info($"Cloning order {id}");
                orders.Add(_orderPrepUtility.CloneOrder(existing));
            }

            return PostOrders(orders.Cast<Order>().ToArray());
        }

        [HttpGet]
        [AccessRequire("Function.PMUI.Write")]
        public bool ConvertToSwap(string orderId)
        {
            return ConvertToSwap(orderId, null);
        }

        [HttpGet]
        [AccessRequire("Function.PMUI.Write")]
        public bool ConvertToSwap(string orderId, string broker)
        {
            if (string.IsNullOrWhiteSpace(broker))
                broker = null;

            var order = _orderRepository.Get(orderId);
            var swapOrder = (Order) _orderPrepUtility.CreateSwapOrder(order, broker);
            if (swapOrder == null)
                return false;

            if (PostOrders(new[] {swapOrder}, true).Count != 1)
                return false;

            DeleteOrders(new[] {orderId}, true);
            return true;
        }

        public int DeleteCache(DateTime? cutoffTimeUtc)
        {
            if (!cutoffTimeUtc.HasValue)
            {
                cutoffTimeUtc = DateTime.UtcNow;
            }
            return _orderRepository.Clear(cutoffTimeUtc.GetValueOrDefault());
        }

        [AccessRequire("Function.PMUI.Write")]
        public List<string> PostRoutedOrders([FromBody] string[] orderIds)
        {
            var orderIdsToReturn = orderIds.ToList();

            if (!_accountService.IsValidTrader(EntryUser))
            {
                _logger.Error($"{EntryUser} is not valid trader");
                return new List<string>();
            }
            _logger.Info($"Route orders called by {EntryUser}");
            
            _notifier.NotifyOrdersToRoute(orderIdsToReturn, EntryUser);

            // this is essentially the list that was passed in....
            return orderIdsToReturn;
        }

        [AccessRequire("Function.PMUI.Read,Function.PMUI.Write")]
        public List<Order> Get(DateTime? cutoffTimeUtc)
        {
            if (PermissionChecker.IsPermissionEnabled())
                _logger.Info($"{User.Identity.Name} REQUESTED orders at: {DateTime.Now.ToLongTimeString()} ");

            if (!cutoffTimeUtc.HasValue)
            {
                cutoffTimeUtc = DateTime.Today.ToUniversalTime();
            }
            var matchedOrders = _orderRepository.Get(cutoffTimeUtc.GetValueOrDefault()).ToList();

            var filterOrders = FilterPermissionedEntities(matchedOrders).ToList();

            if (PermissionChecker.IsPermissionEnabled())
                _logger.Info($"{User.Identity.Name} GOT trades at: {DateTime.Now.ToLongTimeString()} ");

            return filterOrders;
        }

        //I don't think we can do this....
        [HttpGet]
        [AccessRequire("Function.PMUI.Read,Function.PMUI.Write")]
        public List<Order> Find(Portfolio portfolio, Security security)
        {
            var matchedOrders = _orderRepository.Find(portfolio, security).ToList();
            return FilterPermissionedEntities(matchedOrders).ToList();
        }

        [HttpGet]
        [AccessRequire("Function.PMUI.Write")]
        public List<Order> CancelOrdersInDetailStrategyAndBatch(
    string detailStrategy, string batchId)
        {
            var toCancel = GetLiveOrdersInDetailStrategyAndBatch(detailStrategy, batchId);

            if (toCancel.Any())
            {
                _notifier.NotifyCancelOrders(toCancel.Select(o => o.ClientOrderId).ToList());
            }

            return toCancel;
        }

        [HttpGet]
        [AccessRequire("Function.PMUI.Write")]
        public List<Order> CancelOrdersInDetailStrategy(string detailStrategy)
        {
            return CancelOrdersInDetailStrategyAndBatch(detailStrategy, null);
        }

        [HttpGet]
        [AccessRequire("Function.PMUI.Read,Function.PMUI.Write")]
        public List<Order> GetLiveOrdersInDetailStrategyAndBatch(string detailStrategy, string batchId)
        {
            var portfolio = Portfolio.Parse(detailStrategy);
            if (portfolio == null)
            {
                return null;
            }

            var byStrategy = _orderRepository.Find(portfolio, null);
            var filtered = byStrategy.Where(o => o.CanBeCancelled && (batchId == null || o.BatchId == batchId)).ToList();
            return FilterPermissionedEntities(filtered).ToList();
        }

        [HttpGet]
        [AccessRequire("Function.PMUI.Read,Function.PMUI.Write")]
        public List<Order> GetLiveOrdersInDetailStrategy(string detailStrategy)
        {
            return GetLiveOrdersInDetailStrategyAndBatch(detailStrategy, null);
        }

        protected IEnumerable<Order> FilterPermissionedEntities(IEnumerable<Order> orders)
        {
            if (!PermissionChecker.IsPermissionEnabled())
            {
                _logger.Warn("DEV or QA. Skipping permissions.");
                return orders;
            }
            var strategiesInfo = GetPermissionedStrategies(User.Identity).ToList();

            var uniqueStrategies = orders.Select(r => r.Portfolio.ToString()).Distinct();
            var missingStrategies = uniqueStrategies.Except(strategiesInfo.Select(r => r.StrategyCode));

            _logger.Debug(missingStrategies.Any() ? $"The user {User.Identity.Name} does not have permission {JsonConvert.SerializeObject(missingStrategies.ToList())}" 
                : $"The user {User.Identity.Name} is permissiond for {strategiesInfo.Select(s => s.StrategyCode).Aggregate((i, j) => i + "|" + j)}.");

            return orders.Where(
                order => strategiesInfo.Any(s => order.Portfolio.ToString().Contains(s.StrategyCode)))
                    .ToList();
        }
    }
}