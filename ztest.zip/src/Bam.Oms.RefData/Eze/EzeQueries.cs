﻿namespace Bam.Oms.RefData.Eze
{
    public static class EzeQueries
    {
        public const string SelectPortfolios = @"
                                            SELECT distinct p.Prt_des [PortfolioDescription],
                                                    prt_Custodian [Broker],
                                                    Prt_mgr [ManagerCode]
                                            FROM [TC].dbo.ec_prt p  
                                            where prt_mgr is not null and Prt_Mgr <> ''
                                            order by Prt_des";
    }
}