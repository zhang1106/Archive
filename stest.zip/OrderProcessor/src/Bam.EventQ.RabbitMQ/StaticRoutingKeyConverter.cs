﻿namespace Bam.EventQ.RabbitMQ
{
    public class StaticRoutingKeyConverter : IRoutingKeyConverter
    {
        private readonly int _topic;

        public StaticRoutingKeyConverter(int topic)
        {
            _topic = topic;
        }

        public int GetTopic(string routingKey)
        {
            return _topic;
        }
    }
}
