﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Pipeline;

namespace Bam.EventQ.Queue
{
    public static class QueueExtensions
    {
        public static long PublishPayloads<TItem>(this IQueue<PipelineQueueItem<TItem>> queue, IReadOnlyList<TItem> items)
        {
            return PublishBatch(queue, items.Count,
                (index, item) =>
                {
                    item.SetPayload(items[index]);
                });
        }

        public static long PublishPayload<TItem>(this IQueue<PipelineQueueItem<TItem>> queue, TItem item)
        {
            var batch = queue.AllocateBatch(1);
            var slot = queue[batch.Start];
            slot.Clear();
            slot.SetPayload(item);
            queue.PublishBatch(batch);
            return batch.End;
        }

        public static long PublishBatch<TItem>(
            this IQueue<PipelineQueueItem<TItem>> queue, int batchSize,
            Action<int, PipelineQueueItem<TItem>> itemAction)
        {
            int published = 0;
            long lastSequence = 0;
            while (published != batchSize)
            {
                var batch = queue.AllocateBatch(batchSize - published);
                for (long i = batch.Start; i <= batch.End; i++)
                {
                    var slot = queue[i];
                    slot.Clear();
                    itemAction(unchecked ((int) (i - batch.Start)) + published, slot);
                    if (slot.Payload == null && slot.Length == 0 && slot.IsValid)
                    {
                        throw new InvalidOperationException("Expected 'itemAction' to either set payload or buffer size on ring buffer slot.");
                    }
                }
                queue.PublishBatch(batch);
                published += unchecked ((int) (batch.End - batch.Start)) + 1;
                lastSequence = batch.End;
            }

            return lastSequence;
        }
    }
}
