﻿using System.Collections.Generic;
using Bam.EventQ.Integration;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.EzeGateway;

namespace Bam.Oms.OrderGateway.EzeGateway.Producers
{
    public class TradeCreateResponseTransform : IExternalMessageTransform<TradeCreateResponse, IMessage>
    {
        public IEnumerable<IMessage> Transform(TradeCreateResponse input)
        {
            if (input.responseMap?.tradeResponses == null)
            {
                yield break;
            }

            var msg = new TradeCreated();
            foreach (var r in input.responseMap.tradeResponses)
            {
                TradeCreated.LineItem lineItem;
                msg.Items.Add(lineItem = new TradeCreated.LineItem
                {
                    TradeId = r.TradeId,
                    ExternalId = r.ExternalId,
                    ErrorMessage = r.ErrorMessage,
                    ErrorCode = r.ErrorCode.ToString()
                });

                if (r.ComplianceResults?.violations != null)
                {
                    foreach (var v in r.ComplianceResults.violations)
                    {
                        lineItem.ComplianceViolations.Add(new TradeCreated.ComplianceViolation
                        {
                            RuleId = v.RuleID,
                            RuleName = v.RuleName,
                            Level = ConvertComplianceLevel(v.ErrorLevel),
                            ViolationMessage = v.ViolationMessage
                        });
                    }
                }
            }

            yield return msg;
        }

        private ComplianceViolationLevel ConvertComplianceLevel(TradeComplianceErrorLevel errorLevel)
        {
            switch (errorLevel)
            {
                case TradeComplianceErrorLevel.Restriction:
                    return ComplianceViolationLevel.Restricted;

                case TradeComplianceErrorLevel.Override:
                    return ComplianceViolationLevel.Overrideable;
                default:
                    return ComplianceViolationLevel.Warning;
            }
        }
    }
}
