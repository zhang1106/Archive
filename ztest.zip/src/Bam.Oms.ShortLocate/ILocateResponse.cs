﻿using System.Collections.Generic;

namespace Bam.Oms.ShortLocate
{
    public interface ILocateResponse
    {
        decimal RequestedSize { get; }
        string Error { get; }

        ILocateRequest OriginalRequest { get; }
    }
}