﻿using System;

namespace Bam.Oms.Data.Positions
{
    public class DtdPosition
    {
      public string BamSymbol { get; set; }
      public long Quantity { get; set; }
      public decimal NetExposure { get; set; }
      public string Portfolio { get; set; }
      public string Fund { get; set; }
      public string Custodian { get;set;}
      public DateTime TradeDate { get; set; }
      public DateTime SysDate { get; set; }
      public string Stream { get; set; }
    }
}
