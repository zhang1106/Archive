﻿using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public interface IRule : IEventSource<IMessage>
    {
        string Name { get; }
        void Execute(RuleContext context, List<RuleViolation> violations);
    }
}
