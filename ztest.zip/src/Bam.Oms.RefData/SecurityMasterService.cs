﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Messaging;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.RefData
{
    public class SecurityMasterService : ISecurityMasterService
    {
        private readonly ReferenceDataGateway.Api.Http.ISecurityController _securityMasterService;
        private readonly ILogger _logger;
        private readonly ConcurrentDictionary<string, IUpdateSecurity> _securityCache;
        private readonly object _securityLock;

        public SecurityMasterService(ReferenceDataGateway.Api.Http.ISecurityController securityMasterService, ILogger logger,
            SignalRClient<SignalRPacket<ReferenceDataGateway.Api.Model.Security>> subscriber)
        {
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (subscriber == null) throw new ArgumentNullException(nameof(subscriber));

            _securityMasterService = securityMasterService;
            _logger = logger;
            subscriber.ReceiveMessageCallback += ReceiveMessageCallback;
            _securityCache = new ConcurrentDictionary<string, IUpdateSecurity>(StringComparer.InvariantCultureIgnoreCase);
            _securityLock = new object();
        }

        private void ReceiveMessageCallback(SignalRPacket<ReferenceDataGateway.Api.Model.Security> signalRPacket)
        {
            var updates = signalRPacket.Data.Select(MapToDomainModel).ToList();
            foreach (var updateSecurity in updates)
            {
                _securityCache[updateSecurity.BamSymbol] = updateSecurity;
                _logger.Info($"Received updated security information for symbol {updateSecurity.BamSymbol}");
            }

            SecurityUpdated?.Invoke(updates);
        }

        public string ExtractUnderlying(SecurityType type, string ticker)
        {
            IUpdateSecurity security;

            if (!_securityCache.TryGetValue(ticker, out security))
            {
                var missingSecurity = LookupSecurityFromService(ticker);
                if (missingSecurity != null)
                {
                    security = _securityCache[missingSecurity.BamSymbol] = missingSecurity;
                }
                else
                {
                    return ticker;
                }
            }

            return security.SecurityType == SecurityType.EquitySwap ? security.UnderlyingSymbol : security.BamSymbol;
        }

        public IDictionary<string, bool> IsValidSecurity(IList<string> tickers)
        {
            var returnList = new Dictionary<string, bool>();
            var actualSecurities = GetSecurities(tickers);

            foreach (var ticker in tickers)
            {
                if (actualSecurities.Any(r=>r.BamSymbol == ticker))
                    returnList[ticker] = true;
                else
                    returnList[ticker] = false;
            }

            return returnList;
        }

        public void LoadSecurityCache(IList<IPosition> positions)
        {
            _logger.Info($"Loading all securities for {positions.Count} SOD positions");
            var uniqueSecurities = positions.Select(r => r.Security.BamSymbol).Distinct().ToList();
            GetSecurities(uniqueSecurities);
        }

        public IUpdateSecurity GetSecurity(string key)
        {
            IUpdateSecurity security;
            if (_securityCache.TryGetValue(key, out security))
                return security;

            var missingSecurity = LookupSecurityFromService(key);
            if (missingSecurity != null)
            {
                security = _securityCache[missingSecurity.BamSymbol] = missingSecurity;
            }

            return security;
        }

        private IUpdateSecurity LookupSecurityFromService(string key)
        {
            lock (_securityLock)
            {
                var security = _securityMasterService.Get(key);
                return security == null ? null : MapToDomainModel(security);
            }
        }

        private List<IUpdateSecurity> LookupSecurityFromService(IList<string> tickers)
        {
            lock(_securityLock)
                return _securityMasterService.PostQueryMany(tickers.ToArray()).Select(MapToDomainModel).ToList();
        }

        public List<IUpdateSecurity> GetSecurities(IList<string> tickers)
        {
            var returnList = new List<IUpdateSecurity>();
            var missingTickers = new List<string>();

            foreach (var ticker in tickers)
            {
                IUpdateSecurity security;
                if (!_securityCache.TryGetValue(ticker, out security))
                {
                    missingTickers.Add(ticker);
                }
                else
                    returnList.Add(security);
            }

            if (missingTickers.Any())
            {
                var missingSecurities = LookupSecurityFromService(missingTickers);

                foreach (var missingSecurity in missingSecurities)
                {
                    _securityCache[missingSecurity.BamSymbol] = missingSecurity;
                }

                returnList.AddRange(missingSecurities);
            }

            return returnList;

        }

        private IUpdateSecurity MapToDomainModel(ReferenceDataGateway.Api.Model.Security security)
        {
            return new UpdateSecurity()
            {
                SecurityType = MapToDomainSecType(security.SecurityType),
                Currency = security.Currency,
                Issuer = security.Issuer,
                BamSymbol = security.BamSymbol,
                Ticker = security.Ticker,
                Cusip = security.Cusip,
                Isin = security.Isin,
                Sedol = security.Sedol,
                BloombergSymbol = security.BloombergSymbol,
                Country = security.Country,
                Industry = security.Industry,
                UnderlyingSymbol = security.UnderlyingSymbol,
                UnderlyingCurrency = security.UnderlyingCurrency,
                TradingCurrency = security.TradingCurrency,
                SettlementCurrency = security.SettlementCurrency,
                QuotingCurrency = security.QuotingCurrency
            };
        }

        private SecurityType MapToDomainSecType(ReferenceDataGateway.Api.Model.SecurityType sectype)
        {
            switch (sectype)
            {
                case ReferenceDataGateway.Api.Model.SecurityType.EquitySwap:
                    return SecurityType.EquitySwap;
                case ReferenceDataGateway.Api.Model.SecurityType.Equity:
                    return SecurityType.Equity;
                case ReferenceDataGateway.Api.Model.SecurityType.EquityOption:
                    return SecurityType.EquityOption;
                case ReferenceDataGateway.Api.Model.SecurityType.FixedIncome:
                    return SecurityType.FixedIncome;
                case ReferenceDataGateway.Api.Model.SecurityType.FXOption:
                    return SecurityType.FXOption;
                case ReferenceDataGateway.Api.Model.SecurityType.ForwardFx:
                    return SecurityType.ForwardFx;
                case ReferenceDataGateway.Api.Model.SecurityType.Future:
                    return SecurityType.Future;
                case ReferenceDataGateway.Api.Model.SecurityType.FutureOption:
                    return SecurityType.FutureOption;
                case ReferenceDataGateway.Api.Model.SecurityType.Repo:
                    return SecurityType.Repo;
                case ReferenceDataGateway.Api.Model.SecurityType.SpotFx:
                    return SecurityType.SpotFx;
                case ReferenceDataGateway.Api.Model.SecurityType.Bond:
                    return SecurityType.Bond;
                case ReferenceDataGateway.Api.Model.SecurityType.Other:
                    return SecurityType.Other;
                default:
                    return SecurityType.Unknown;
            }
        }

        public IEnumerable<IContainsSecurity> SetSecurityAttributes(IEnumerable<IContainsSecurity> items)
        {
            var uniqueSecurities = items.Select(r => r.Security.BamSymbol.ToString()).Distinct();
            var securities = GetSecurities(uniqueSecurities.ToArray());

            foreach (var item in items)
            {
                var security = securities.FirstOrDefault(r => r.BamSymbol == item.Security.BamSymbol);

                if (security == null)
                {
                    //throw new MissingSecurityException(item.Security);
                    _logger.Error($"Unknown security requested from Security Master, {item.Security}.");
                    continue;
                }

                item.Security.Currency = security.Currency;
                item.Security.Issuer = security.Issuer;
                item.Security.BamSymbol = security.BamSymbol;
                item.Security.Ticker = security.Ticker;
                item.Security.Cusip = security.Cusip;
                item.Security.Isin = security.Isin;
                item.Security.Sedol = security.Sedol;
                item.Security.BloombergSymbol = security.BloombergSymbol;
                item.Security.Country = security.Country;
                item.Security.Industry = security.Industry;
                item.Security.UnderlyingSymbol = security.UnderlyingSymbol;
                item.Security.QuotingCurrency = security.QuotingCurrency;
            }

            return items;
        }

        public ISecurity GetSwapSecurity(string symbol, string broker)
        {
            if (broker == null || broker.Length < 2)
                return null;

            string ticker = $"{symbol} {broker.Substring(0, 2)} SWAP";
            var security = GetSecurity(ticker);

            // In the old symbol naming convention MSCO was considered
            // the default broker and was not explicitly included in the
            // symbol name. In case there is no security matching the new
            // naming conventions then try to find a security that still
            // follows the old naming convention
            if (security == null && "MSCO".Equals(broker, StringComparison.OrdinalIgnoreCase))
            {
                ticker = $"{symbol} SWAP";
                security = GetSecurity(ticker);
            }

            return security;
        }

        public event Action<IList<IUpdateSecurity>> SecurityUpdated;
    }
}