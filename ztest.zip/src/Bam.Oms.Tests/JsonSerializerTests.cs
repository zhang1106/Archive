﻿using System;
using System.Collections;
using System.Runtime.Serialization;
using System.Text;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Serialization;
using FluentAssertions;
using NUnit.Framework;
using Ploeh.AutoFixture;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class JsonSerializerTests
    {
        [TestCaseSource(nameof(Entities))]
        public void VerifyRoundtripSerialization<T>(T expected)
        {
            // arange
            var sut = new JsonSerializer();

            // act
            var buffer = sut.Serialize(expected);
            var actual = sut.Deserialize<T>(buffer);

            // assert
            expected.ShouldBeEquivalentTo(actual);
        }

        [Test]
        public void VerifyThrowsOnInvalidJson()
        {
            // arange
            var sut = new JsonSerializer();

            // act
            Action act = () => sut.Deserialize<BlockTrade>(Encoding.UTF8.GetBytes("asdf"));

            // assert
            act.ShouldThrow<SerializationException>();
        }
        
        public static IEnumerable Entities
        {
            get
            {
                var fixture = new Fixture();
                yield return fixture.Create<BlockTrade>();
                yield return fixture.Create<Order>();
                yield return fixture.Create<Security>();
                yield return fixture.Create<Position>();
                yield return new AggUnitKey("test", new Security { BamSymbol = "123" });
                yield return
                    new AggUnitPosition
                    {
                        Key = new AggUnitKey("test", new Security { BamSymbol = "123" }),
                        ShortMarkingQuantity = 5
                    };
            }
        }
    }
}
