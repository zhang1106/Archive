﻿using System.Diagnostics;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    [DebuggerDisplay("({Key}) = {Quantity}")]
    public class PositionAllocation
    {
        public PositionAllocation(PositionAllocationKey key, Position position)
        {
            Key = key;
            Position = position;
        }

        public PositionAllocationKey Key { get; }
        public Position Position { get; }
        public long Quantity { get; set; }
    }
}