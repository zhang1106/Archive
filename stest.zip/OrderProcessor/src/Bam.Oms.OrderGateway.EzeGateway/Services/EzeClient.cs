using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using Eze.Common.Integration;
using IEzeTradingServiceSync = Bam.Oms.OrderGateway.EzeGateway.EzeApi.IEzeTradingServiceSync;
using TradeCreateRequest = Bam.Oms.OrderGateway.EzeGateway.EzeApi.TradeCreateRequest;
using TradeResponse = Bam.Oms.OrderGateway.EzeGateway.EzeApi.TradeResponse;
using UserCredentials = Bam.Oms.OrderGateway.EzeGateway.EzeApi.UserCredentials;

namespace Bam.Oms.OrderGateway.EzeGateway.Services
{
    public class EzeClient : IEzeClient
    {
        private readonly string _tradeUrl;
        private readonly string _pubSubUrl;
        private readonly UserCredentials _credentials;

        public EzeClient(string tradeUrl, string pubSubUrl, string username, string password)
        {
            _tradeUrl = tradeUrl;
            _pubSubUrl = pubSubUrl;
            _credentials = new UserCredentials
            {
                userName = username,
                password = password
            };
        }

        public TradeResponse CreateTrade(TradeCreateRequest request)
        {
            request.userCredentials = _credentials;
            return (TradeResponse) DoRequest(c => c.CreateTrade(request));
        }

        public void TriggerReplay()
        {
            var factory = new WebChannelFactory<IPublishSubscriber>(new Uri(_pubSubUrl));
            factory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            var proxy = factory.CreateChannel();

            var req = new TradeSubscriptionRequest(
                new Eze.Common.Integration.UserCredentials(_credentials.userName, _credentials.password))
            {
                IsFullRefreshRequired = true,
                FullRefreshBatchSize = 100,
                FullRefreshTimeInSeconds = 1,
                PublishTimeInSeconds = 1,
                PublishBatchSize = 100
            };

            var result = proxy.Subscribe(req);
            if (!result.SubcriptionSucessful)
            {
                throw new Exception(result.ErrorMessage);
            }
        }

        private TResult DoRequest<TResult>(Func<IEzeTradingServiceSync, TResult> action)
        {
            var client = new EzeWcfTradingClient(_tradeUrl);
            try
            {
                return action(client.GetChannel());
            }
            finally
            {
                try
                {
                    if (client.State != CommunicationState.Faulted)
                    {
                        client.Close();
                    }
                }
                finally
                {
                    if (client.State != CommunicationState.Closed)
                    {
                        client.Abort();
                    }
                }
            }
        }
    }
}