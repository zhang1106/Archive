﻿using System;

namespace Bam.Oms.Data.Configuration
{
    public class DateProvider : IDateProvider
    {   
        public DateTime SetSodTime(string sodTimeString = "17:00:00" /* Roll time in Chicago time*/, DateTime now = default(DateTime))
        {
            if (now.Equals(default(DateTime)))
                now = DateTime.Now;

            DateTime sodDateTime;
            int daysAdjustment = now.DayOfWeek == DayOfWeek.Sunday
                   ? -2
                   : now.DayOfWeek == DayOfWeek.Saturday
                       ? -1
                       : now.DayOfWeek == DayOfWeek.Monday
                           ? -3
                           : -1;

            TimeSpan ts = TimeSpan.Parse(sodTimeString);
            sodDateTime = now.TimeOfDay >= ts && now.DayOfWeek != DayOfWeek.Sunday && now.DayOfWeek != DayOfWeek.Saturday ? now.Date.Add(TimeSpan.Parse(sodTimeString)) : now.Date.AddDays(daysAdjustment).Add(TimeSpan.Parse(sodTimeString));
            return sodDateTime;
        }
    }
}