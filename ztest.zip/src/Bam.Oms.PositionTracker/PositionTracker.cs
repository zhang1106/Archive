﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Contingency;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.PositionTracker
{
    public class PositionTracker : IPositionTracker, IDisposable
    {
        private readonly IPositionEffectCalculator _effectCalculator;
        private readonly IStartOfDayPositionCalculator _sodCalculator;
        private readonly IPositionRepository _positionRepository;
        private readonly ITradeRepository _tradeRepository;
        private readonly IOrderRepository _orderRepository;
        private readonly IContingencyDbRepository _contingencyDbRepository;
        private readonly ILogger _log;

        private int _contingencySaveInProgress;

        public PositionTracker(
            IPositionEffectCalculator effectCalculator,
            IStartOfDayPositionCalculator sodCalculator,
            IPositionRepository positionRepository,
            ITradeRepository tradeRepository,
            IOrderRepository orderRepository,
            IContingencyDbRepository contingencyDbRepository,
            ILogger logger)
        {
            _effectCalculator = effectCalculator;
            _sodCalculator = sodCalculator;
            _positionRepository = positionRepository;
            _tradeRepository = tradeRepository;
            _orderRepository = orderRepository;
            _contingencyDbRepository = contingencyDbRepository;
            _log = logger;
        }
        
        public IEnumerable<IPosition> GetCurrentPositions()
        {
            return _positionRepository.GetAllPositions();
        }

        public IEnumerable<IPosition> GetCurrentPositions(string bamSymbol)
        {
            return GetCurrentPositions().Where(p => p.Security.BamSymbol == bamSymbol).ToList();
        }

        public IEnumerable<IAggUnitPosition> GetAggUnitPositions()
        {
            return _positionRepository.GetAggUnitPositions();
        }

        public IEnumerable<IAggUnitPosition> GetAggUnitPositions(string bamSymbol)
        {
            return _positionRepository.GetAggUnitPositions().Where(p => p.Key.Security.BamSymbol == bamSymbol).ToList();
        }

        public IEnumerable<ICompliancePosition> GetCompliancePositions()
        {
            return _positionRepository.GetCompliancePositions();
        }

        public IEnumerable<ICompliancePosition> GetCompliancePositions(string bamSymbol)
        {
            return _positionRepository.GetCompliancePositions().Where(p => p.Key.Security.BamSymbol == bamSymbol).ToList();
        }

        public IPosition ApplyPositionUpdate(IBlockTrade trade)
        {
            var lastKnownTrade = _tradeRepository.GetByClientOrderId(trade.ClientOrderId)
                .OrderByDescending(t => t.TradeTimeStamp)
                .FirstOrDefault();
            var order = _orderRepository.Get(trade.ClientOrderId);

            var positionKey = new PositionKey(order.Portfolio, order.Security);
            var position = _positionRepository.Get(new[] {positionKey}).FirstOrDefault();

            _effectCalculator.ApplyEffects(position, order, lastKnownTrade, order, trade);
            _positionRepository.Save(new[] {position});

            Debug.Assert(position != null, "position != null");
            return position.Position;
        }

        public IPosition ApplyOrderUpdate(IOrder order)
        {
            var trades = _tradeRepository.GetByClientOrderId(order.ClientOrderId);
            var lastKnownOrder = _orderRepository.Get(order.ClientOrderId);
            IBlockTrade lastKnownTrade = trades.OrderByDescending(t => t.TradeTimeStamp).FirstOrDefault();

            var positionKey = new PositionKey(order.Portfolio, order.Security);
            var position = _positionRepository.Get(new[] {positionKey}).FirstOrDefault();

            _effectCalculator.ApplyEffects(position, lastKnownOrder, lastKnownTrade, order, lastKnownTrade);
            _positionRepository.Save(new[] {position});

            Debug.Assert(position != null, "position != null");
            return position.Position;
        }
        
        public void ClearPositions(string stream, IReadOnlyList<string> symbols)
        {
            _positionRepository.Clear(stream, symbols);
        }

        public ICollection<IPosition> UpdateSODPositions(IEnumerable<IPosition> positions)
        {
            foreach (var p in positions)
            {
                _log.Info($"SOD Position update received for {p.Portfolio}:{p.Security.BamSymbol}: {p.ActualQuantity}[{p.ActualSide}]");
            }

            var allOrders = _orderRepository.GetAllOrders(o => o.OrderStatus != BamOrderStatus.Error);
            var allTrades = _tradeRepository.GetAllTrades();

            var keys = positions.Select(p => new PositionKey(p.Portfolio, p.Security)).Distinct().ToList();
            var sets = _positionRepository.Get(keys);

            var orders = new Dictionary<IPositionKey, IList<IOrder>>();
            var trades = new Dictionary<IPositionKey, IList<IBlockTrade>>();
            foreach (var key in keys)
            {
                IList<IOrder> items1;
                if (allOrders.TryGetValue(key, out items1))
                {
                    orders[key] = items1;
                }

                IList<IBlockTrade> items2;
                if (allTrades.TryGetValue(key, out items2))
                {
                    trades[key] = items2;
                }
            }

            sets = _sodCalculator.Adjust(sets, positions.ToArray(), orders, trades);
            _positionRepository.Save(sets);

            foreach (var set in sets)
            {
                _log.Info($"Position set after applying SOD position and replay: {set}");
            }

            var result = sets.Select(s => s.Position).ToArray();
            SodPositionUpdate?.Invoke(result,
                Data.Enumerators.PositionUpdate.TheoreticalSide |
                Data.Enumerators.PositionUpdate.TheoreticalSize | Data.Enumerators.PositionUpdate.ActualSide |
                Data.Enumerators.PositionUpdate.ActualSize);

            return result;
        }

        public ICollection<IPosition> LoadSODPositions(IEnumerable<IPosition> positions,
            IDictionary<IPositionKey, IList<IOrder>> orders, IDictionary<IPositionKey, IList<IBlockTrade>> trades)
        {
            foreach (var p in positions)
            {
                _log.Info($"SOD Position update received for {p.Portfolio}:{p.Security.BamSymbol}: {p.ActualQuantity}[{p.ActualSide}]");
            }

            var sets = _sodCalculator.Calculate(positions.ToArray(), orders, trades);
            _positionRepository.Save(sets);

            foreach (var set in sets)
            {
                _log.Info($"Position set after applying SOD position and replay: {set}");
            }

            var result = sets.Select(s => s.Position).ToArray();
            SodPositionUpdate?.Invoke(result,
                Data.Enumerators.PositionUpdate.TheoreticalSide |
                Data.Enumerators.PositionUpdate.TheoreticalSize | Data.Enumerators.PositionUpdate.ActualSide |
                Data.Enumerators.PositionUpdate.ActualSize);

            return result;
        }
        
        public ICollection<IPosition> UpdatePositions(IEnumerable<IPosition> positions)
        {
            var keys = positions.Select(p => new PositionKey(p.Portfolio, p.Security)).ToArray();
            var sets = _positionRepository.Get(keys);
            var setLookup =
                sets.ToDictionary(
                    s => new PositionKey(s.Position.Portfolio, s.Position.Security));

            foreach (var p in positions)
            {
                var set = setLookup[new PositionKey(p.Portfolio, p.Security)];
                _effectCalculator.ReplacePosition(set, p);
            }

            _positionRepository.Save(sets);
            var result = sets.Select(s => s.Position).ToArray();

            PositionUpdate?.Invoke(result,
                Data.Enumerators.PositionUpdate.TheoreticalSide |
                Data.Enumerators.PositionUpdate.TheoreticalSize | Data.Enumerators.PositionUpdate.ActualSide |
                Data.Enumerators.PositionUpdate.ActualSize);
            return result;
        }

        public int SavePositions(ref DateTime cutOffTime)
        {
            if (Interlocked.CompareExchange(ref _contingencySaveInProgress, 1, 0) == 0)
            {
                _log.InfoFormat("Saving contingency positions since {0}.", cutOffTime.ToString("o"));
                DateTime newcutOffTime = DateTime.Now;
                IList<IPosition> savedPositions = _contingencyDbRepository.Save(GetCurrentPositions()).ToList();
                _log.InfoFormat("Saved {0} contingency positions since {1}.", savedPositions.Count(),
                    cutOffTime.ToString("o"));
                cutOffTime = newcutOffTime;
                Interlocked.CompareExchange(ref _contingencySaveInProgress, 0, 1);
                return savedPositions.Count();
            }

            _log.InfoFormat("Contingency save is already in progress for cut-off time {0}.", cutOffTime);
            return 0;
        }

        public event Action<IList<IPosition>, PositionUpdate> SodPositionUpdate;
        public event Action<IList<IPosition>, PositionUpdate> PositionUpdate;

        public void Dispose()
        {
            // nada
        }
    }
}
