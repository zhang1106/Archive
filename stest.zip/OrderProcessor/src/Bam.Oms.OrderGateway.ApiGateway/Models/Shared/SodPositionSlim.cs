﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class SodPositionSlim
    {
        public string Portfolio { get; set; }
        public string BamSymbol { get; set; }
        public string Custodian { get; set; }
        public string Fund { get; set; }
        public string Stream { get; set; }
        public DateTime AsOf { get; set; }
        public long Quantity { get; set; }
    }
}
