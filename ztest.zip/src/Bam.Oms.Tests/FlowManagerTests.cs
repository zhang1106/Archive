﻿using System.Collections.Generic;
using System.Threading;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Trades;
using Bam.Oms.EndPoints;
using Bam.Oms.EndPoints.Eze;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.OrderRouting.EZE;
using Bam.Oms.Persistence.Contingency;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.PositionTracker;
using Bam.Oms.RefData;
using Bam.Oms.Service.StateMachine;
using Bam.Oms.ShortLocate;
using Bam.Oms.SodPosition.Svc;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    public class FlowManagerTests
    {
        [Test]
        public void SendsFinalizedTradesToRollClients()
        {
            var rollClient = new Mock<IRollClient>();
            var flowClient = new Mock<IFlowClient>();

            var flowManager = new FlowManager(
                new Mock<IEmsRouter>().Object,
                new Mock<ILocateService>().Object,
                new Mock<ISecurityMasterService>().Object,
                new Mock<ISodPositionEdit>().Object,
                new Mock<IOrderRepository>().Object,
                new Mock<ITradeRepository>().Object,
                new Mock<ISecurityRepository>().Object,
                new Mock<IClientOrderIdRepository>().Object,
                new Mock<IContingencyDbRepository>().Object,
                new[] { flowClient.Object },
                new[] { rollClient.Object },
                new Mock<IDateProvider>().Object,
                new Mock<ISettings>().Object,
                new Mock<ILogger>().Object,
                new Mock<ILoggingAgent>().Object,
                new Mock<IPositionTracker>().Object,
                new Mock<IPositionRepository>().Object,
                new Mock<IMessageHandler>().Object,
                new Mock<INotificationCache>().Object,
                new Mock<IOrderNotifier>().Object,
                new Mock<IOrderPrepUtility>().Object,
                new Mock<IStartOfDayPositionCalculator>().Object,
                new Mock<IAccountService>().Object);

            var finalizedTrade = new Mock<IBlockTrade>();
            var unfinalizedTrade = new Mock<IBlockTrade>();
            finalizedTrade.Setup(t => t.isFinalized).Returns(true);
            unfinalizedTrade.Setup(t => t.isFinalized).Returns(false);

            flowManager.StripedProcessorTradesStatusChanged(
                new List<IBlockTrade>(new[]
                {
                    finalizedTrade.Object,
                    unfinalizedTrade.Object
                }));
            Thread.Sleep(100); // operation is async in flow manager

            flowClient.Verify(m => m.PublishTrades(It.Is<List<IBlockTrade>>(l => l.Count == 2)));
            rollClient.Verify(m => m.PublishTrades(It.Is<List<IBlockTrade>>(l => l.Count == 1)));
        }
    }
}