﻿using System.Collections.Generic;
using System.Linq;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public class EzeOrderCache : IEzeOrderCache
    {
        private readonly List<EzeOrder> _emptyList = new List<EzeOrder>();
        private readonly Dictionary<string, Dictionary<OrderIndexKey, EzeOrder>> _tradeIdMapDictionary;

        public EzeOrderCache()
        {
            _tradeIdMapDictionary = new Dictionary<string, Dictionary<OrderIndexKey,EzeOrder>>();
        }

        public EzeOrder GetByExternalId(long externalId)
        {
            foreach (var dict in _tradeIdMapDictionary.Values)
            {
                foreach (var order in dict.Values)
                {
                    if (order.OrderId == externalId)
                        return order;
                }
            }

            return null;
        }

        public List<EzeOrder> GetOrdersByEzeTradeId(string tradeId)
        {
            Dictionary<OrderIndexKey, EzeOrder> orders;
            return _tradeIdMapDictionary.TryGetValue(tradeId, out orders) 
                ? orders.Values.ToList() 
                : _emptyList;
        }

        public EzeOrder GetOrder(OrderIndexKey key)
        {
            Dictionary<OrderIndexKey, EzeOrder> orders;
            if (!_tradeIdMapDictionary.TryGetValue(key.TradeId, out orders))
            {
                return null;
            }

            EzeOrder order;
            return orders.TryGetValue(key, out order) ? order : null;
        }

        public void Save(EzeOrder order)
        {
            Dictionary<OrderIndexKey,EzeOrder> orders;
            if (_tradeIdMapDictionary.TryGetValue(order.Key.TradeId, out orders))
            {
                orders[order.Key] = order;
            }
            else
            {
                _tradeIdMapDictionary.Add(
                    order.Key.TradeId,
                    new Dictionary<OrderIndexKey, EzeOrder>
                    {
                        {order.Key, order}
                    });
            }
        }
    }
}
