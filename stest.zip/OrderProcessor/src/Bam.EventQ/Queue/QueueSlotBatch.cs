﻿namespace Bam.EventQ.Queue
{
    public struct QueueSlotBatch
    {
        public QueueSlotBatch(long start, long end)
        {
            Start = start;
            End = end;
        }

        public long Start { get; }
        public long End { get; }
    }
}
