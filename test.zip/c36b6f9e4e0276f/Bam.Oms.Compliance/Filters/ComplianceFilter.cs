﻿using Bam.Oms.Data.Securities;
using Bam.Oms.Filtering;

namespace Bam.Oms.Compliance.Filters
{
    public class PolicyFilter : Filter<ISecurity> 
    {

    }

}
