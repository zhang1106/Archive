﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.SodPosition.Client
{
    public interface ISvcClient
    {
        /// <summary>
        /// hands shaking
        /// </summary>
        /// <returns></returns>
        string Whatsup();

        IList<Position> GetSodPositions(string userId, DateTime? asofdate, string stream, string fundCode, string custodianAccountCode, string strategyCode, string securityType, string bamSymbol, out string message);
        bool SaveToCSVFile(string userId, string completeFileName, IList<Position> positions, out string message);

        Position InsertPosition(string userId, Position position, out string message);
        Position UpdatePosition(string userId, Position position, out string message);
        IList<PositionAudit> GetAudits(string userId, int positionId, System.DateTime entrydate, out string message);
        IList<Position> GetLatestUpdatedPositions(string userId, out string message);
        IList<SodAction> GetCorporateActions(string userId, out string message);

        bool PublishUpdatedPositions(string userId, IList<Position> positions, out string message);
        IList<Position> BulkUpdatePosition(string userId, IList<Position> positions, out string message);
        IList<Position> BulkInsertPosition(string userId, IList<Position> positions, out string message);
    }
}
