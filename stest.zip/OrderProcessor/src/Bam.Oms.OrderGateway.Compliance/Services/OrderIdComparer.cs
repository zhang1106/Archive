﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class OrderIdComparer : IComparer<RunCompliance.ComplianceLineItem>
    {
        public static OrderIdComparer Instance { get; } = new OrderIdComparer();

        public int Compare(RunCompliance.ComplianceLineItem x, RunCompliance.ComplianceLineItem y)
        {
            return x.OrderId.CompareTo(y.OrderId);
        }
    }
}