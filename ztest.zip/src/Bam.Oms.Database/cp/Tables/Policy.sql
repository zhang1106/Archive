﻿CREATE TABLE [cp].[Policy] (
    [Id]             INT           IDENTITY (1, 1) NOT NULL,
    [Name]           VARCHAR (100) NOT NULL,
    [Type]           VARCHAR (100) NULL,
    [Description]    VARCHAR (200) NULL,
    [IsActive]       BIT           NOT NULL,
    [StartDate]      DATETIME      NOT NULL,
    [EndDate]        DATETIME      NOT NULL,
    [ParamsInJson]   VARCHAR (MAX) NULL,
    [CreatedOn]      DATETIME      NOT NULL,
    [CreatedBy]      VARCHAR (50)  NULL,
    [LastModifiedOn] DATETIME      NOT NULL,
    [LastModifiedBy] VARCHAR (50)  NULL,
    CONSTRAINT [PK__Policy__2E1339A41209AD79] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IDX_Name]
    ON [cp].[Policy]([Name] ASC);

