﻿using System;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public struct OrderStrategyAllocationKey : IEquatable<OrderStrategyAllocationKey>
    {
        public bool Equals(OrderStrategyAllocationKey other)
        {
            return PositionKey.Equals(other.PositionKey);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is OrderStrategyAllocationKey && Equals((OrderStrategyAllocationKey) obj);
        }

        public override int GetHashCode()
        {
            return PositionKey.GetHashCode();
        }

        public static bool operator ==(OrderStrategyAllocationKey left, OrderStrategyAllocationKey right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(OrderStrategyAllocationKey left, OrderStrategyAllocationKey right)
        {
            return !left.Equals(right);
        }

        public PositionKey PositionKey { get; }

        public OrderStrategyAllocationKey(PositionKey positionKey)
        {
            PositionKey = positionKey;
        }
    }
}
