﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.PositionTracker
{
    public class PositionEffectCalculator : IPositionEffectCalculator
    {
        private struct PositionEffects
        {
            public decimal TheoreticalQuantity;
            public decimal ActualQuantity;
            public decimal ShortMarkingQuantity;
            public decimal LongMarkingQuantity;
        }

        private static readonly IOrder NoOrder = new Order { OrderStatus = BamOrderStatus.PendingValidation, Side = SideType.Buy };
        private static readonly IBlockTrade NoTrade = new BlockTrade();

        public void ApplyEffects(
            IPositionSet set,
            IOrder currentOrder, IBlockTrade currentTrade,
            IOrder updatedOrder, IBlockTrade updatedTrade)
        {
            currentOrder = currentOrder ?? NoOrder;
            currentTrade = currentTrade ?? NoTrade;
            updatedOrder = updatedOrder ?? NoOrder;
            updatedTrade = updatedTrade ?? NoTrade;
            
            var effects1 = CalculateEffects(currentOrder, currentTrade);
            var effects2 = CalculateEffects(updatedOrder, updatedTrade);

            var effect = new PositionEffects
            {
                LongMarkingQuantity = effects2.LongMarkingQuantity - effects1.LongMarkingQuantity,
                TheoreticalQuantity = effects2.TheoreticalQuantity - effects1.TheoreticalQuantity,
                ShortMarkingQuantity = effects2.ShortMarkingQuantity - effects1.ShortMarkingQuantity,
                ActualQuantity = effects2.ActualQuantity - effects1.ActualQuantity
            };

            set.Position.ActualQuantity += effect.ActualQuantity;
            set.Position.TheoreticalQuantity += effect.TheoreticalQuantity;
            set.Position.ShortMarkingQuantity += effect.ShortMarkingQuantity;
            set.Position.LongMarkingQuantity += effect.LongMarkingQuantity;

            set.CompliancePosition.LongMarkingQuantity += effect.LongMarkingQuantity;
            set.CompliancePosition.ShortMarkingQuantity += effect.ShortMarkingQuantity;

            set.AggUnitPosition.ShortMarkingQuantity += effect.ShortMarkingQuantity;

            //distributed position effect
            var effectDpos = CalculateEffects(currentTrade, updatedTrade, updatedOrder);
            var mPosition = set.Position.DistributedPositions.Concat(effectDpos);
            set.Position.DistributedPositions = (from p in mPosition
                group p by new {p.CustodianName, p.FundCode}
                into grp
                select
                    new DistributedPosition()
                    {
                        CustodianName = grp.Key.CustodianName,
                        FundCode = grp.Key.FundCode,
                        Quantity = grp.Sum(t => t.Quantity)
                    }).ToList<DistributedPosition>();

        }

        private IEnumerable<DistributedPosition> CalculateEffects(IBlockTrade currentTrade, IBlockTrade updatedTrade, IOrder updatedOrder)
        {
            var dPos = new List<DistributedPosition>(10);
            var side = IsShortSide(updatedOrder) ? -1 : 1;
            dPos.AddRange(currentTrade.Allocations.Select(a=>new DistributedPosition() {FundCode=a.Fund,CustodianName = a.PrimeBroker, Quantity = side*(-1)*a.Quantity}));
            dPos.AddRange(updatedTrade.Allocations.Select(a => new DistributedPosition() { FundCode = a.Fund, CustodianName = a.PrimeBroker, Quantity = side*a.Quantity}));
            return dPos;
        }

        public void ReplacePosition(IPositionSet set, IPosition replacement)
        {
            var old = set.Position;
            set.Position = replacement;

            set.CompliancePosition.ShortMarkingQuantity = set.CompliancePosition.ShortMarkingQuantity -
                                                          old.ShortMarkingQuantity +
                                                          replacement.ShortMarkingQuantity;

            set.CompliancePosition.LongMarkingQuantity = set.CompliancePosition.LongMarkingQuantity -
                                                         old.LongMarkingQuantity +
                                                         replacement.LongMarkingQuantity;

            set.AggUnitPosition.ShortMarkingQuantity = set.AggUnitPosition.ShortMarkingQuantity -
                                                       old.ShortMarkingQuantity +
                                                       replacement.ShortMarkingQuantity;
        }

        private bool IsShortSide(IOrder order)
        {
            return order.Side == SideType.SellShort || order.Side == SideType.Sell || order.Side == SideType.Short; 
        }

        private PositionEffects CalculateEffects(IOrder order, IBlockTrade trade)
        {
            decimal theoreticalEffect;
            decimal actualEffect;
            decimal longMarkingEffect;
            decimal shortMarkingEffect;

            //this can be a read-only calculated property in order object
            bool isOrderNotLive = !order.IsLive;
            bool isShortSide = IsShortSide(order);
            
            var orderQty = order.Size;
            var fillledQty = trade.TradedQuantity;
            if (isShortSide)
            {
                orderQty = -orderQty;
                fillledQty = -fillledQty;
            }
            
            if(isOrderNotLive)
            {
                theoreticalEffect = fillledQty;
                actualEffect = fillledQty;
                longMarkingEffect = fillledQty;
                shortMarkingEffect = fillledQty;
            }
            else
            {
                theoreticalEffect = orderQty;
                actualEffect = fillledQty;
                longMarkingEffect = isShortSide ? fillledQty : orderQty;
                shortMarkingEffect = isShortSide ? orderQty : fillledQty;
            }
            
            return new PositionEffects
            {
                ActualQuantity = actualEffect,
                LongMarkingQuantity = Utility.IsOmni(order.Custodian)? 0:longMarkingEffect,
                ShortMarkingQuantity = Utility.IsOmni(order.Custodian) ? 0:shortMarkingEffect,
                TheoreticalQuantity = theoreticalEffect
            };
        }
    }
}
