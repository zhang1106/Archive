﻿using System;
using Newtonsoft.Json;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Rules
{
    [JsonObject(MemberSerialization.OptIn)]
    public class LongOwnershipLimit : FirmRuleBase 
    {
        //rule specific
       [JsonProperty]
       public decimal Threshhold { get; set; }
        
       
        public override IRuleResult CheckViolation(ICompliancePosition input, bool isPreCheck)
        {
            var result = input.Helper.CreateFilingResult(input, this, SideType.Long, "FIRM", "SYMBOL");
            var context = string.Empty;
            try
            {
                //appy filters first
                var longQuantityInfo =   input.PositionProvider.GetFirmWideQuantity(input.BamSymbol, input.PositionType, SideType.Long);
                var longQuantity = longQuantityInfo.Item2;
                context = longQuantityInfo.Item1;

                result.HeadRoom.Holding = (long?)longQuantity;
                result.HeadRoom.HeadRooms.Add(new HeadRoom.HeadRoomUnit()
                {
                    Threshold = Threshhold,
                    HeadRoom = (long?)(Threshhold - longQuantity),
                    AlertLevel = ComplianceAlertLevel.Restricted.ToString()
                });

                if (!longQuantity.HasValue)
                {
                    result.AlertLevel = ComplianceAlertLevel.NoDataAvaiable;
                    result.Description = "Position not available";
                }
                else
                {
                    result.AlertLevel = longQuantity.Value >= Threshhold ? ComplianceAlertLevel.Restricted : ComplianceAlertLevel.NoViolation;
                    result.Description = result.AlertLevel == ComplianceAlertLevel.Restricted ?
                        $"Going above {longQuantity.Value:N0} Ownership" : "No Violation";
                    result.PositionQty = longQuantity;
                }
                input.Helper.LogEvent(result.Key, context);
            }
            catch(Exception ex)
            {
                result.AlertLevel = ComplianceAlertLevel.Error;
                result.Description = ex.Message;
                input.Helper.LogErrorEvent(result.Key, context);
                input.Logger.Error(ex.Message);
            }

            return result;
        }
        
    }
}
