﻿using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Threading;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;
using log4net;
using log4net.Config;

namespace Bam.Oms.Compliance.Service
{
    public partial class ComplianceGateway : ServiceBase, IComplianceGateway
    {
        private static readonly ILog Logger = LogManager.GetLogger("Bam.Oms.Compliance.Service");
        private static ISettings _settings;
        private static IHelper _helper;
        private static bool _stop;
      
        [Log]
        public ComplianceGateway(ISettings settings, IHelper helper) 
        {
            InitializeComponent();
            _settings = settings;
            _helper = helper;
        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        private static void Main(string[] args)
        {
            var currentDomain = AppDomain.CurrentDomain;
            Directory.SetCurrentDirectory(currentDomain.BaseDirectory);
            XmlConfigurator.Configure();

            var service = (ComplianceGateway)BAM.Infrastructure.Ioc.Container.Instance.Resolve<IComplianceGateway>();

            if (Environment.UserInteractive)
            {
                service.OnStart(args);
                Console.WriteLine("Press any key to stop program");
                Console.Read();
                service.OnStop();
            }
            else
            {
                Run(service);
            }
        }

        public string Name => "Ownership Service";

        protected void SvcThread()
        {
            try
            {
                Logger.Info($"Starting...{Assembly.GetExecutingAssembly().FullName}");
                Logger.Info("Gateway Service Started...");
                Logger.Info("Init  Service, load rules...");
                var cService = (FirmPositionComplianceSvc)BAM.Infrastructure.Ioc.Container.Instance.Resolve<IFirmPositionComplianceSvc>();
                cService.Init();
                Logger.Info("validate positions agains rules...");
                //mins
                var interval = _settings.ComplianceSpan*1000*60;

                //recalc sod headroom upon starting
                Logger.Info("Sod: Calc sod headroom on service starting");
                cService.Run(PositionType.Sod);

                var checkedEodDate = DateTime.MinValue;
                while (!_stop)
                {
                    var eodDate = _helper.GetEodBusinessDate();
                    try
                    {
                        if ("DEV".Equals(ConfigurationManager.AppSettings["DEPLOYMNT_ENV"]))
                        {
                            Logger.Info($"service wont run because no POMO access.");
                        }
                        else
                        {
                            if (DateTime.Now.DayOfWeek != DayOfWeek.Saturday && DateTime.Now.DayOfWeek != DayOfWeek.Sunday)
                            {
                                //intraday check
                                if (DateTime.Now.Hour >= _settings.ComplianceStart && DateTime.Now.Hour <= _settings.ComplianceEnd)
                                {
                                    cService.Run(PositionType.Intraday);
                                    Logger.Info($"Intraday: Next run will be - {DateTime.Now.AddMilliseconds(interval).ToLongTimeString()}");
                                }
                                else
                                {
                                    Logger.Info($"Intraday: Service only runs between {_settings.ComplianceStart} and {_settings.ComplianceEnd} during weekdays");
                                }
                                //run eod report
                                if (DateTime.Now.Hour >= _settings.EodStartTime ||
                                    DateTime.Now.Hour <= _settings.EodEndTime)
                                {
                                    if (eodDate != checkedEodDate && cService.RunEod(eodDate).Any())
                                    {
                                        Logger.Info($"Eod: Created Eod report for {eodDate.ToShortDateString()}");
                                        checkedEodDate = eodDate;
                                    }
                                    else
                                    {
                                        Logger.Warn($"Eod: Did not get any Eod position for {eodDate.ToShortDateString()}");
                                    }
                                    ;
                                }
                                else
                                {
                                    Logger.Info($"Eod: Svc only runs after {_settings.EodStartTime} and end at {_settings.EodEndTime}");
                                }
                            }
                            else
                            {
                                    Logger.Info($"Service: Wont run on weekends");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Error(ex);
                    }

                    Thread.Sleep(interval);
                }

                Logger.Info("done...");
            }
            catch (Exception ex)
            {
                Logger.FatalFormat($"Unable to start service {ex.Message} - {ex.StackTrace}");
            }
        }
        
        public void Start()
        {
            var t = new Thread(SvcThread) { IsBackground = true };
            t.Start();
        }
        
        [Log]
        protected override void OnStart(string[] args)
        {
           Start();
          
           var httpRoot = new Bam.Compliance.ApiGateway.CompositionRoot();
           var httpSvc =  httpRoot.Initialize();
           httpSvc.Start();
        }

        protected override void OnStop()
        {
            Logger.Info("Stopping......");
            try
            {
                var results = (RuleResultRepository)BAM.Infrastructure.Ioc.Container.Instance.Resolve<IRuleResultRepository>();
                results.Clear(DateTime.UtcNow.AddDays(-5));

                _stop = false;
                // This would call the dispose on all the injected disposable objects, including the persistence repositories. The persistence caches are flushed at dispose.
                BAM.Infrastructure.Ioc.Container.Instance.Dispose();
            }
            catch (Exception ex)
            {  
                Logger.Warn("Exception disposing IOC container.", ex); 
            }

            Logger.Info("Stopped service.");
        }
    }
}