﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bam.Oms.Persistence.Journal
{
    public interface IEventJournal
    {
        Task AppendAsync(object item);
        Task AppendAsync(IReadOnlyList<object> items);
        Task TruncateAsync();
        Task TruncateAsync(DateTime beforeUtc);
        Task<IReadOnlyList<KeyValuePair<DateTime, object>>> RetrieveAsync();
    }
}
