﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Bam.EventQ.Transport
{
    public class RpcClientFactory : IRpcClientFactory
    {
        private readonly Dictionary<int, IRpcClient> _clients;

        public RpcClientFactory(IEnumerable<KeyValuePair<int, IRpcClient>> clients)
        {
            _clients = clients.ToDictionary(c => c.Key, c => c.Value);
        }

        public IRpcClient Create(int sourceId)
        {
            IRpcClient client;
            if (!_clients.TryGetValue(sourceId, out client))
                throw new Exception($"No RPC client for source {sourceId} defined");

            return client;
        }
    }
}
