﻿using Bam.EventQ.Solace;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Solace
{
    public class OrderSolaceTopicProvider : ISolaceTopicProvider<Order>
    {
        private readonly string _baseTopic;

        public OrderSolaceTopicProvider(string baseTopic)
        {
            _baseTopic = baseTopic ?? string.Empty;
            if (_baseTopic.Length > 0 && !_baseTopic.EndsWith("/"))
            {
                _baseTopic += "/";
            }
        }

        public string GetTopic(Order item)
        {
            return $"{_baseTopic}{item.Portfolio.AggregationUnit}/{item.Portfolio}/{item.ClientOrderId}";
        }
    }
}
