﻿using System;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;

namespace Bam.EventQ.Throttling
{
    public class IntervalConsumptionTrigger : IConsumptionTrigger<object>, IDisposable
    {
        private readonly IBackgroundWorker _triggerWorker;
        private readonly TimeSpan _interval;

        public IntervalConsumptionTrigger(TimeSpan interval)
        {
            _interval = interval;
            _triggerWorker = BackgroundWorkerFactory.Current.Create("Throttled Consumption Trigger " + interval);
            _triggerWorker.Start(Trigger);
        }

        public void Throttled(object item, long sequence, bool endOfBatch)
        {
            // ignore
        }

        public event EventHandler Consume;
        public ILogger Logger { get; set; }

        public void Dispose()
        {
            _triggerWorker.Dispose();
            Consume = null;
        }

        private void Trigger(CancellationToken cancellationToken)
        {
            TimeSpan delay = _interval;
            while (!cancellationToken.WaitHandle.WaitOne(delay))
            {
                var handler = Consume;
                if (handler != null)
                {
                    long start = DateTime.UtcNow.Ticks;
                    foreach (var dlg in handler.GetInvocationList())
                    {
                        try
                        {
                            dlg?.DynamicInvoke(this, EventArgs.Empty);
                        }
                        catch (Exception ex)
                        {
                            Logger?.LogError("Error triggering throttled consumption", ex);
                        }
                    }

                    long end = DateTime.UtcNow.Ticks;
                    var delta = TimeSpan.FromTicks(end - start);
                    if (delta.Ticks > 0)
                    {
                        delay = delta.Ticks < _interval.Ticks 
                            ? _interval.Subtract(delta) 
                            : TimeSpan.Zero;
                    }
                    else
                    {
                        delay = _interval;
                    }
                }
            }
        }
    }
}
