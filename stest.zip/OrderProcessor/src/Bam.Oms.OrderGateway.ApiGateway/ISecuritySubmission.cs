﻿using Bam.Oms.OrderGateway.Messages.RefDataGateway;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface ISecuritySubmission
    {
        void Submit(SecurityInsert updates);
    }
}