using System;
using System.Collections;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Schedulers;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;

namespace Bam.Oms.EndPoints.Http
{
    public class JsonNetFormatter : MediaTypeFormatter
    {
        private readonly JsonSerializer _serializer;
        private readonly TaskScheduler _scheduler;

        public JsonNetFormatter()
        {
            SupportedMediaTypes.Add(new System.Net.Http.Headers.MediaTypeHeaderValue("application/json"));
            _serializer = new JsonSerializer();
            _serializer.Converters.Add(new IsoDateTimeConverter());
            _serializer.Formatting = Formatting.Indented;
            _scheduler = new LimitedConcurrencyLevelTaskScheduler(4);
        }

        public override bool CanWriteType(Type type)
        {
            // don't serialize JsonValue structure use default for that
            if (type == typeof(JValue) || type == typeof(JObject) || type == typeof(JArray))
                return false;

            return true;
        }

        public override bool CanReadType(Type type)
        {
            return true;
        }

        public override Task<object> ReadFromStreamAsync(Type type, Stream stream, 
            HttpContent content, IFormatterLogger formatterLogger)
        {
            using (var sr = new StreamReader(stream, Encoding.UTF8, false, 4096, true))
            using (var reader = new JsonTextReader(sr))
            {
                return Task.FromResult(_serializer.Deserialize(reader, type));
            }
        }

        public override Task WriteToStreamAsync(Type type, object value, Stream stream, 
            HttpContent content, TransportContext transportContext)
        {
            return Task.Factory.StartNew(() =>
            {
                using (var sw = new StreamWriter(stream, Encoding.UTF8, 4096, true))
                using (var writer = new JsonTextWriter(sw))
                {
                    IEnumerable array;
                    if (value != null && value.GetType() != typeof(string) && (array = value as IEnumerable) != null)
                    {
                        writer.WriteStartArray();
                        foreach (var item in array)
                        {
                            _serializer.Serialize(writer, item);
                        }
                        writer.WriteEndArray();
                    }
                    else
                    {
                        _serializer.Serialize(writer, value);
                    }
                }
            }, CancellationToken.None, TaskCreationOptions.HideScheduler, _scheduler);
        }
    }
}