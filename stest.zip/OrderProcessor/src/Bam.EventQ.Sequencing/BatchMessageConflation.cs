﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Bam.EventQ.Sequencing
{
    public class BatchMessageConflation
    {
        private readonly HashSet<Type> _types;
        private readonly Dictionary<Type, int> _firstMessageIndex;
        private readonly Dictionary<Type, Action<IBatchMessage, IBatchMessage>> _mergeFuncs;

        public BatchMessageConflation()
        {
            _types = new HashSet<Type>();
            _firstMessageIndex = new Dictionary<Type, int>(256);
            _mergeFuncs = new Dictionary<Type, Action<IBatchMessage, IBatchMessage>>(256);
        }

        public void Conflate(List<IMessage> messages)
        {
            foreach (var t in _types)
            {
                _firstMessageIndex[t] = -1;
            }

            for (int i = 0; i < messages.Count; i++)
            {
                var batch = messages[i] as IBatchMessage;
                if (batch == null)
                    continue;

                var type = messages[i].GetType();

                int index;
                if (!_firstMessageIndex.TryGetValue(type, out index) || index == -1)
                {
                    _types.Add(type);
                    _firstMessageIndex[type] = i;
                }
                else
                {
                    Action<IBatchMessage, IBatchMessage> merge;
                    if (!_mergeFuncs.TryGetValue(type, out merge))
                    {
                        merge = _mergeFuncs[type] = CreateMergeFunc(type);
                    }

                    merge((IBatchMessage) messages[index], batch);
                    messages[i] = null;
                }
            }

            int count = messages.Count;
            int next = 0;
            for (int i = 0; i < messages.Count; i++)
            {
                if (messages[i] == null)
                {
                    next = Math.Max(next, i + 1);
                    for (int j = next; j < messages.Count; j++)
                    {
                        if (messages[j] != null)
                        {
                            messages[i] = messages[j];
                            messages[j] = null;
                            next = j + 1;
                            break;
                        }
                    }
                }

                if (messages[i] == null)
                {
                    count = i;
                    break;
                }
            }
            
            if (count < messages.Count)
            {
                messages.RemoveRange(count, messages.Count - count);
            }
        }

        private Action<IBatchMessage, IBatchMessage> CreateMergeFunc(Type type)
        {
            var iface = type.GetInterfaces().First(i => typeof(IBatchMessage).IsAssignableFrom(i) && i.IsGenericType);
            var msgType = iface.GetGenericArguments()[0];

            var p1 = Expression.Parameter(typeof(IBatchMessage), "first");
            var p2 = Expression.Parameter(typeof(IBatchMessage), "other");
            var cast1 = Expression.Convert(p1, iface);
            var cast2 = Expression.Convert(p2, iface);

            var mi = GetType().GetMethods(BindingFlags.Static | BindingFlags.Public).First(m => m.Name == nameof(Merge));
            var call = Expression.Call(mi.MakeGenericMethod(msgType), cast1, cast2);
            return Expression.Lambda<Action<IBatchMessage, IBatchMessage>>(call, p1, p2).Compile();
        }

        public static void Merge<TItem>(IBatchMessage<TItem> first, IBatchMessage<TItem> other)
        {
            first.Items.AddRange(other.Items);
            other.Items.Clear();
        }
    }
}
