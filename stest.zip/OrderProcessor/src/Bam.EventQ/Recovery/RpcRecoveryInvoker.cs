﻿using System;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Recovery
{
    public class RpcRecoveryInvoker : IRecoveryInvoker
    {
        private readonly IRpcClientFactory _clientFactory;

        public RpcRecoveryInvoker(IRpcClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public bool TryInvoke(int sourceId, int? topic, long expectedSequence)
        {
            byte[] buffer = new byte[12];
            (topic ?? -1).CopyToBuffer(buffer, 0);
            expectedSequence.CopyToBuffer(buffer, 4);

            var client = _clientFactory.Create(sourceId);
            bool invoked = client.TryInvoke("recover", buffer, TimeSpan.FromSeconds(2), out buffer);
            return invoked && buffer != null && buffer.Length == 1 && buffer[0] == 0x00;
        }
    }
}
