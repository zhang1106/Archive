﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
  
    [Category("Integration")]
    [TestFixture()]
    public class DataAccessIntegrationTest
    {
      
        private ISettings _settings;

        [SetUp]
        public void Setup()
        {
            _settings = Factory.GetSettings();
        }

        [Test]
        public void TestIsinData()
        {

            var custRepo = new OgDataRepository(_settings, new Mock<ILogger>().Object);
            var isins = custRepo.GetEuExemptedIsins();

            Assert.IsTrue(isins.Any());
        }

        [Test]
        public void TestEodData()
        {

            var dwRepo = new DwRepository(_settings, new Mock<ILogger>().Object);
            var eods = dwRepo.GetEodPositions(DateTime.Now.AddDays(-1));

            Assert.IsTrue(eods.Any());
        }

    }
}
