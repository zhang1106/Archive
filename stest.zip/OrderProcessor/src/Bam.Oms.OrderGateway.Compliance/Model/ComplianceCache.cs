﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public class ComplianceCache : IComplianceCache
    {
        private readonly IIndexFactory _indexFactory;
        private readonly IPositionIdGenerator _positionIdGenerator;
        private readonly IReferenceDataService _referenceDataService;
        private readonly IModelIndex<Position> _positionModelIndex;
        private readonly IModelIndex<Order> _orderModelIndex;
        private readonly IModelIndex<AggUnitPosition> _aggUnitPositionModelIndex;
        private readonly IModelIndex<CompliancePosition> _compliancePositionModelIndex;
        private readonly IModelIndex<SodPosition> _sodPositionModelIndex;
        private readonly Dictionary<PositionKey, PositionSet> _cachedPositionSets;

        public ComplianceCache(
            IPositionIdGenerator positionIdGenerator, 
            IReferenceDataService referenceDataService,
            IIndexFactory indexFactory)
        {
            _positionIdGenerator = positionIdGenerator;
            _referenceDataService = referenceDataService;
            _indexFactory = indexFactory;
            _positionModelIndex = _indexFactory.For<Position>();
            _orderModelIndex = _indexFactory.For<Order>();
            _aggUnitPositionModelIndex = _indexFactory.For<AggUnitPosition>();
            _compliancePositionModelIndex = _indexFactory.For<CompliancePosition>();
            _sodPositionModelIndex = _indexFactory.For<SodPosition>();
            _cachedPositionSets = new Dictionary<PositionKey, PositionSet>(4096);
        }

        public IModelEventHandler<IMessage> EventHandler { get; set; }
        
        public IReadOnlyList<PositionSet> GetPositionSets(IReadOnlyList<PositionKey> keys)
        {
            var result = new List<PositionSet>(keys.Count);
            result.AddRange(keys.Select(GetPositionSet));
            return result;
        }

        public PositionSet GetPositionSet(PositionKey pk)
        {
            PositionSet set;
            if (!_cachedPositionSets.TryGetValue(pk, out set))
            {
                var position = GetPosition(pk);
                set = new PositionSet
                {
                    Position = position,
                    CompliancePosition = GetCompliancePosition(position.ComplianceGroupKey, pk),
                    AggUnitPosition = GetAggUnitPosition(position.AggregationUnitKey, pk)
                };

                _cachedPositionSets[pk] = set;
            }

            return set;
        }

        private Position GetPosition(PositionKey pk)
        {
            var position = _positionModelIndex.LookupBy(nameof(Position.Key), pk);
            if (position == null)
            {
                position = CreateNewPosition(pk);

                _positionModelIndex.Insert(position);

                var message = new PositionCreated();
                message.Items.Add(new PositionCreated.LineItem
                {
                    PositionId = position.PositionId,
                    Portfolio = pk.Portfolio.Key,
                    Symbol = pk.Symbol,
                });
                Publish(message);
            }

            return position;
        }

        private AggUnitPosition GetAggUnitPosition(AggUnitKey key, PositionKey pk)
        {
            var aggUnitPosition = _aggUnitPositionModelIndex.LookupBy(nameof(AggUnitPosition.Key), key);
            if (aggUnitPosition == null)
            {
                aggUnitPosition = CreateNewAggUnitPosition(key);
                _aggUnitPositionModelIndex.Insert(aggUnitPosition);

                var message = new AggUnitPositionCreated();
                message.Items.Add(new AggUnitPositionCreated.LineItem
                {
                    PositionId = aggUnitPosition.PositionId,
                    AggregationUnit = aggUnitPosition.Key.AggregationUnit,
                    Symbol = pk.Symbol,
                    ShortMarkingQuantity = aggUnitPosition.ShortMarkingQuantity
                });
                Publish(message);
            }

            return aggUnitPosition;
        }
        
        private CompliancePosition GetCompliancePosition(ComplianceGroupKey key, PositionKey pk)
        {
            var compliancePosition = _compliancePositionModelIndex.LookupBy(nameof(CompliancePosition.Key), key);
            if (compliancePosition == null)
            {
                compliancePosition = CreateNewCompliancePosition(key);
                _compliancePositionModelIndex.Insert(compliancePosition);

                var message = new ComplianceGroupPositionCreated();
                message.Items.Add(new ComplianceGroupPositionCreated.LineItem
                {
                    PositionId = compliancePosition.PositionId,
                    ComplianceGroup = compliancePosition.Key.ComplianceGroup,
                    Symbol = pk.Symbol,
                    ShortMarkingQuantity = compliancePosition.ShortMarkingQuantity,
                    LongMarkingQuantity = compliancePosition.LongMarkingQuantity
                });
                Publish(message);
            }
            return compliancePosition;
        }

        public Order GetOrder(long id)
        {
            return _orderModelIndex.LookupBy(nameof(Order.OrderId), id);
        }        

        public IList<Order> GetAllOrders(Func<Order, bool> predicate)
        {
            predicate = predicate ?? (o => true);
            return GetAllOrders().Where(predicate).ToList();
        }

        public IList<Order> GetOrders(IEnumerable<string> symbols)
        {
            var result = new List<Order>();
            foreach (string symbol in symbols)
            {
                result.AddRange(_orderModelIndex.MultiLookupBy("Security.Symbol", symbol));
            }
            
            return result;
        }

        public IList<OrderStrategyAllocation> GetOrders(IEnumerable<PositionKey> keys)
        {
            var result = new List<OrderStrategyAllocation>();
            var pks = new HashSet<PositionKey>(keys);
            foreach (var order in GetAllOrders())
            {
                foreach (var alloc in order.Allocations)
                {
                    if (pks.Contains(alloc.Key))
                    {
                        result.Add(alloc.Value);
                    }
                }
            }

            return result;
        }

        public void UpdateSodPositions(IReadOnlyList<SodPosition> sodPositions, bool isContingency)
        {
            var load = new SodPositionLoaded();
            foreach (var item in sodPositions)
            {
                var lastSod = _sodPositionModelIndex.LookupBy(nameof(item.Key), item.Key);
                if (lastSod == null && item.ActualQuantity == 0 && !isContingency)
                {
                    continue;
                }

                if (lastSod != null)
                {
                    _sodPositionModelIndex.Remove(lastSod);
                }

                var lineItem = new SodPositionLoaded.SodItem
                {
                    Quantity = item.ActualQuantity,
                    Symbol = item.Key.BamSymbol,
                    Strategy = item.Key.Portfolio.Key,
                    Custodian = item.Key.Custodian,
                    Fund = item.Key.Fund,
                    AsOf = item.AsOf
                };

                load.SodPositions.Add(lineItem);
                _sodPositionModelIndex.Insert(item);
            }

            if (load.SodPositions.Count > 0)
            {
                Publish(load);
            }
        }
        
        public LookupList<SodPosition> GetSodPositions(string symbol)
        {
            return _sodPositionModelIndex.MultiLookupBy("PositionKey.Symbol", symbol);
        }

        public void Save(IReadOnlyList<PositionSet> sets)
        {
            foreach (var set in sets)
            {
                var pk = set.Key;

                PositionSet cachedSet;
                if (_cachedPositionSets.TryGetValue(pk, out cachedSet))
                {
                    cachedSet.Position = set.Position ?? cachedSet.Position;
                    cachedSet.CompliancePosition = set.CompliancePosition ?? cachedSet.CompliancePosition;
                    cachedSet.AggUnitPosition = set.AggUnitPosition ?? cachedSet.AggUnitPosition;
                    _cachedPositionSets[pk] = cachedSet;
                }

                if (set.Position != null)
                {
                    var position = _indexFactory.For<Position>().LookupBy(nameof(Position.Key), set.Position.Key);
                    if (position == null && !set.Position.IsFlat)
                    {
                        _indexFactory.For<Position>().Insert(set.Position);
                        var item = new PositionCreated.LineItem
                        {
                            PositionId = set.Position.PositionId,
                            Portfolio = pk.Portfolio.Key,
                            Symbol = pk.Symbol,
                            ActualQuantity = set.Position.ActualQuantity,
                            TheoreticalQuantity = set.Position.TheoreticalQuantity,
                            ShortMarkingQuantity = set.Position.ShortMarkingQuantity,
                            LongMarkingQuantity = set.Position.LongMarkingQuantity,
                        };

                        foreach (var alloc in set.Position.ActualAllocations)
                        {
                            item.ActualAllocations.Add(new PositionCreated.Allocation
                            {
                                FundId = alloc.Key.FundId,
                                CustodianId = alloc.Key.CustodianId,
                                Quantity = alloc.Value.Quantity
                            });
                        }

                        foreach (var alloc in set.Position.TheoreticalAllocations)
                        {
                            item.TheoreticalAllocations.Add(new PositionCreated.Allocation
                            {
                                FundId = alloc.Key.FundId,
                                CustodianId = alloc.Key.CustodianId,
                                Quantity = alloc.Value.Quantity
                            });
                        }

                        var positionCreateEvent = new PositionCreated
                        {
                            Items = { item }
                        };

                        Publish(positionCreateEvent);
                    }
                    else if (position != null)
                    {
                        set.Position.PositionId = position.PositionId;
                        _indexFactory.For<Position>().Remove(position);  
                        _indexFactory.For<Position>().Insert(set.Position);

                        if (position.ActualAllocationDiffers(set.Position))
                        {
                            var actualUpdate = new ActualPositionUpdated();
                            var lineItem = new ActualPositionUpdated.LineItem
                            {
                                PositionId = position.PositionId
                            };
                            
                            foreach (var alloc in set.Position.ActualAllocations)
                            {
                                lineItem.Allocations.Add(new ActualPositionUpdated.Allocation
                                {
                                    Quantity = alloc.Value.Quantity,
                                    CustodianId = alloc.Key.CustodianId,
                                    FundId = alloc.Key.FundId
                                });
                            }

                            actualUpdate.Items.Add(lineItem);
                            Publish(actualUpdate);
                        }

                        if (position.TheoreticalAllocationDiffers(set.Position))
                        {
                            var theoreticalUpdate = new TheoreticalPositionUpdated();
                            var lineItem = new TheoreticalPositionUpdated.LineItem
                            {
                                PositionId = position.PositionId
                            };

                            foreach (var alloc in set.Position.TheoreticalAllocations)
                            {
                                lineItem.Allocations.Add(new TheoreticalPositionUpdated.Allocation
                                {
                                    Quantity = alloc.Value.Quantity,
                                    FundId = alloc.Key.FundId,
                                    CustodianId = alloc.Key.CustodianId
                                });
                            }

                            theoreticalUpdate.Items.Add(lineItem);
                            Publish(theoreticalUpdate);
                        }

                        if (position.ShortMarkingQuantity != set.Position.ShortMarkingQuantity)
                        {
                            var shortMarkingUpdate = new ShortMarkingPositionUpdated();
                            shortMarkingUpdate.Items.Add(new ShortMarkingPositionUpdated.LineItem()
                            {
                                PositionId = position.PositionId,
                                Quantity = set.Position.ShortMarkingQuantity,
                            });

                            Publish(shortMarkingUpdate);
                        }

                        if (position.LongMarkingQuantity != set.Position.LongMarkingQuantity)
                        {
                            var longMarkingUpdate = new LongMarkingPositionUpdated();
                            longMarkingUpdate.Items.Add(new LongMarkingPositionUpdated.LineItem
                            {
                                PositionId = position.PositionId,
                                Quantity = set.Position.LongMarkingQuantity,
                            });

                            Publish(longMarkingUpdate);
                        }
                    }
                }
                
                if (set.AggUnitPosition != null)
                {
                    var aggUnitKey = set.AggUnitPosition.Key;
                    var aggUnitPos = _indexFactory.For<AggUnitPosition>().LookupBy(nameof(AggUnitPosition.Key), aggUnitKey);
                    if (aggUnitPos == null && !set.AggUnitPosition.IsFlat)
                    {
                        _indexFactory.For<AggUnitPosition>().Insert(set.AggUnitPosition);
                        Publish(new AggUnitPositionCreated(
                            set.AggUnitPosition.PositionId,
                            set.AggUnitPosition.Key.AggregationUnit,
                            set.AggUnitPosition.Key.Symbol,
                            set.AggUnitPosition.ShortMarkingQuantity));
                    }
                    else if (aggUnitPos != null)
                    {
                        set.AggUnitPosition.PositionId = aggUnitPos.PositionId;
                        _indexFactory.For<AggUnitPosition>().Remove(aggUnitPos);
                        _indexFactory.For<AggUnitPosition>().Insert(set.AggUnitPosition);

                        if (aggUnitPos.ShortMarkingQuantity != set.AggUnitPosition.ShortMarkingQuantity)
                        {
                            var update = new ShortMarkingPositionUpdated(aggUnitPos.PositionId, set.AggUnitPosition.ShortMarkingQuantity);
                            Publish(update);
                        }
                    }
                }
                
                if (set.CompliancePosition != null)
                {
                    var complianceKey = set.CompliancePosition.Key;
                    var compliancePosition = _indexFactory.For<CompliancePosition>().LookupBy(nameof(CompliancePosition.Key), complianceKey);
                    if (compliancePosition == null && !set.CompliancePosition.IsFlat)
                    {
                        _indexFactory.For<CompliancePosition>().Insert(set.CompliancePosition);
                        Publish(new ComplianceGroupPositionCreated(
                            set.CompliancePosition.PositionId,
                            set.CompliancePosition.Key.ComplianceGroup,
                            set.CompliancePosition.Key.Symbol,
                            set.CompliancePosition.ShortMarkingQuantity,
                            set.CompliancePosition.LongMarkingQuantity));
                    }
                    else if (compliancePosition != null)
                    {
                        set.CompliancePosition.PositionId = compliancePosition.PositionId;
                        _indexFactory.For<CompliancePosition>().Remove(compliancePosition);
                        _indexFactory.For<CompliancePosition>().Insert(set.CompliancePosition);

                        if (compliancePosition.ShortMarkingQuantity != set.CompliancePosition.ShortMarkingQuantity)
                        {
                            var update = new ShortMarkingPositionUpdated(set.CompliancePosition.PositionId,
                                set.CompliancePosition.ShortMarkingQuantity);
                            Publish(update);
                        }

                        if (compliancePosition.LongMarkingQuantity != set.CompliancePosition.LongMarkingQuantity)
                        {
                            var update = new LongMarkingPositionUpdated(set.CompliancePosition.PositionId, set.CompliancePosition.LongMarkingQuantity);
                            Publish(update);
                        }
                    }
                }
            }
        }

        public IEnumerable<Order> GetAllOrders()
        {
            return _orderModelIndex.GetAll();
        }

        private Position CreateNewPosition(PositionKey pk)
        {
            PortfolioDetails details;
            if (!_referenceDataService.TryGetPortfolioDetails(pk.Portfolio, out details))
            {
                throw new Exception($"Cannot create position for unknown portfolio {pk.Portfolio}");
            }

            return new Position(_positionIdGenerator.GetNextPositionId(),
                pk, details.AggregationUnit, details.ComplianceGroup);
        }

        private CompliancePosition CreateNewCompliancePosition(ComplianceGroupKey key)
        {
            return new CompliancePosition(key, _positionIdGenerator.GetNextPositionId());
        }

        private AggUnitPosition CreateNewAggUnitPosition(AggUnitKey key)
        {
            return new AggUnitPosition(key, _positionIdGenerator.GetNextPositionId());
        }
        
        private void Publish(IMessage @event)
        {
            EventHandler?.Handle(@event);
        }
    }
}