﻿using System.Linq;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Time;
using Bam.Oms.OrderGateway.Messages.RefDataGateway;
using CsvHelper;

namespace Bam.Oms.OrderGateway.ApiGateway.File
{
    public class SecurityFileListener : FileListener, IService
    {
        private readonly ISecuritySubmission _submission;

        public SecurityFileListener(IClock clock, string watchPath, string archivePath, string errorPath, ISecuritySubmission submission) 
            : base(clock, watchPath, archivePath, errorPath)
        {
            _submission = submission;
        }

        protected override void ProcessFile(string path, string entryUser)
        {
            var update = ReadFile(path);
            if (update.Items.Any())
            {
                Logger?.LogInformation($"Security file imported {update.Items.Count} securities");
                _submission.Submit(update);
            }
        }

        private SecurityInsert ReadFile(string path)
        {
            var updates = new SecurityInsert();

            using (var reader = new CsvReader(System.IO.File.OpenText(path)))
            {
                reader.Configuration.RegisterClassMap<SecurityMapping>();

                while (reader.Read())
                {
                    var securityUpdatesItem = reader.GetRecord<SecurityInsert.SecurityInsertItem>();
                    updates.Items.Add(securityUpdatesItem);
                }
            }

            return updates;
        }
    }
}