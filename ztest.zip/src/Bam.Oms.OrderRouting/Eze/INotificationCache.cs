﻿using System.Collections.Generic;
using EzeEi = Eze.Common.Integration;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.OrderRouting.EZE
{
    public interface INotificationCache
    {
        void AddEzeTrades(IReadOnlyList<EzeEi.Trade> trades);
        EzeEi.Trade GetTrade(string tradeId);
        void AddToOrderIdIndex(Order order, bool saveToRepository = true);
        void AddToOrderIdIndex(IList<IOrder> orders);
        string GetOrderId(OrderIndexKey key);
        Dictionary<string, IOrder> GetOrdersByEzeTradeId(string tradeId);
    }
}
