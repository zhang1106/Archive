﻿using System;
using System.Collections.Generic;

namespace Bam.EventQ.Lookup
{
    public class IndexFactory : IIndexFactory
    {
        private readonly Dictionary<Type, object> _indexes = new Dictionary<Type, object>();

        public IModelIndex<TModel> For<TModel>()
        {
            object obj;
            if (!_indexes.TryGetValue(typeof(TModel), out obj))
            {
                obj = _indexes[typeof(TModel)] = new ModelIndex<TModel>();
            }

            return (IModelIndex<TModel>) obj;
        }
    }
}
