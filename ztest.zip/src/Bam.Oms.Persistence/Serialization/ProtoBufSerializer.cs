﻿using System;
using System.IO;
using System.Linq.Expressions;
using System.Runtime.Serialization;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Orders;
using ProtoBuf.Meta;
using Bam.Oms.RefData;

namespace Bam.Oms.Persistence.Serialization
{
    public class ProtoBufSerializer : ISerializer
    {
        private readonly TypeModel _typeModel;

        public ProtoBufSerializer(Action<RuntimeTypeModel> additionalTypeModelRegistrations = null)
        {
            _typeModel = CreateTypeModel(additionalTypeModelRegistrations);
        }

        public byte[] Serialize<T>(T item)
        {
            using (var ms = new MemoryStream())
            {
                _typeModel.Serialize(ms, item);
                return ms.ToArray();
            }
        }

        public T Deserialize<T>(byte[] input)
        {
            return Deserialize<T>(input, 0, input.Length);
        }

        public T Deserialize<T>(byte[] input, int startIndex, int length)
        {
            return (T)Deserialize(input, startIndex, length, typeof(T));
        }

        public object Deserialize(byte[] input, int startIndex, int length, Type type)
        {
            try
            {
                using (var ms = new MemoryStream(input, startIndex, length))
                {
                    return HandlePostDeserialize(_typeModel.Deserialize(ms, null, type));
                }
            }
            catch (Exception ex)
            {
                throw new SerializationException("Unable to deserialize input with ProtoBuf", ex);
            }
        }

        private object HandlePostDeserialize(object obj)
        {
            if (obj.GetType() == typeof(BlockTrade))
            {
                var trade = (BlockTrade)obj;
                foreach (var a in trade.Allocations)
                {
                    a.Fees = a.Fees ?? new Fee[] { };
                    a.Commissions = a.Commissions ?? new Fee[] { };
                }
            }

            return obj;
        }

        private TypeModel CreateTypeModel(Action<RuntimeTypeModel> additionalTypeModelRegistrations)
        {
            var model = TypeModel.Create();

            model.Add<IComplianceIssue>()
                .AddSubType<ComplianceIssue>(c => c
                    .Add(m => m.Description, m => m.IssueType, m => m.RuleName));

            model.Add<ISecurity>()
                .AddSubType<Security>(c => c
                    .Add(m => m.BamSymbol, m => m.BloombergSymbol, m => m.ContractSize, m => m.Country,
                        m => m.Currency, m => m.Cusip, m => m.Industry, m => m.InvestmentType,
                        m => m.IsBilateral, m => m.Isin, m => m.Issuer, m => m.OptionType,
                        m => m.SecurityType, m => m.Sedol, m => m.Ticker, m => m.UnderlyingSymbol)
                    .AddSubType<UpdateSecurity>(u => u
                        .Add(m => m.BamSymbol, m => m.BloombergSymbol, m => m.ContractSize, m => m.Country,
                            m => m.Currency, m => m.Cusip, m => m.Industry, m => m.InvestmentType,
                            m => m.IsBilateral, m => m.Isin, m => m.Issuer, m => m.OptionType,
                            m => m.SecurityType, m => m.Sedol, m => m.Ticker, m => m.UnderlyingSymbol)));

            model.Add<IBlockTrade>()
                .AddSubType<BlockTrade>(c => c
                    .Add(m => m.Security, m => m.ClientOrderId, m => m.TradeId, m => m.AccruedInterest,
                        m => m.ActualSettlementDate, m => m.AveragePrice, m => m.BaseCurrency,
                        m => m.DataSource, m => m.DayCountConvention, m => m.FxRate, m => m.GrossAmount,
                        m => m.HairCut, m => m.MaturityDate, m => m.NetAmount, m => m.NetAmountBase,
                        m => m.Portfolio, m => m.RepoRate, m => m.Side, m => m.Status,
                        m => m.TradeCurrency, m => m.TradeDate, m => m.TradeId, m => m.TradeStatus,
                        m => m.TradeTimeStamp, m => m.TradedQuantity, m => m.Trader, m => m.isFinalized)
                    .AddLists(m => m.Allocations));

            model.Add<IAllocation>()
                .AddSubType<Allocation>(c => c
                    .Add(m => m.AllocationId, m => m.AveragePrice, m => m.CounterParty, m => m.Fund,
                        m => m.Note, m => m.ParentTradeId, m => m.PrimeBroker, m => m.PrimeBrokerAccount,
                        m => m.Quantity, m => m.SettleDate)
                    .AddLists(m => m.Commissions, m => m.Fees));

            model.Add<AllocationInfo>()
                    .Add(ai => ai.AllocationId, ai => ai.CounterParty, ai => ai.Fund, ai => ai.PrimeBroker, ai => ai.PrimeBrokerAccount, ai => ai.Quantity);

            model.Add<IFee>()
                .AddSubType<Fee>(c => c
                    .Add(m => m.Currency, m => m.Name, m => m.Rate, m => m.RateType));

            model.Add<IOrder>()
                .AddSubType<Order>(c => c
                    .Add(m => m.Security, m => m.BatchId, m => m.ClientOrderId, m => m.Custodian,
                        m => m.Portfolio, m => m.ExternalStatus, m => m.LocateStatus,
                        m => m.Note, m => m.OrderStatus, m => m.OrderTimeStamp, m => m.OriginalOrderId,
                        m => m.Price, m => m.RoutedSize, m => m.SettleDate, m => m.Side, m => m.Size,
                        m => m.TraderLogin, m => m.TraderId, m => m.TradeDate, m => m.Trader, m => m.TradeCurrency,
                        m => m.SettlementCurrency, m => m.ExternalId, m => m.CreatedDateTime, m => m.FillQuantity,
                        m => m.AveragePrice, m=> m.CreatedUser)
                    .AddLists(m => m.ComplianceFailures, m => m.ExecutionInstructions, m => m.Errors,
                        m => m.Locate, m => m.StatusMessages, m => m.StreetOrders, m => m.Allocations));

            model.Add<IPortfolio>()
                .AddSubType<Portfolio>(c => c
                    .Add(m => m.AggregationUnit, m => m.ComplianceGroup, m => m.PMCode, m => m.Strategy,
                        m => m.SubStrategy));

            model.Add<ExecutionInstruction>()
                .Add(m => m.Value, m => m.Code);

            model.Add<ILocate>()
                .AddSubType<Locate>(c => c
                    .Add(m => m.Size, m => m.AssignmentId, m => m.PrimeBroker, m => m.Rate,
                        m => m.RateType, m => m.TimeReceived, m => m.LocateId));

            model.Add<IStreetOrder>()
                .AddSubType<StreetOrder>(c => c
                    .Add(m => m.Security, m => m.ClientOrderId, m => m.ExecutingBroker, m => m.FilledQuantity,
                        m => m.Portfolio, m => m.PrimeBroker, m => m.Side, m => m.Side, m => m.Size,
                        m => m.StreetOrderId, m => m.TradeDate, m => m.WeightedAvgPrice));

            model.Add<ICompliancePosition>()
                .AddSubType<CompliancePosition>(c => c
                    .Add(m => m.Key, m => m.LongMarkingQuantity, m => m.ShortMarkingQuantity));

            model.Add<IAggUnitPosition>()
                .AddSubType<AggUnitPosition>(c => c
                    .Add(m => m.Key, m => m.ShortMarkingQuantity));

            model.Add<DistributedPosition>()
                    .Add(dp => dp.Quantity, dp => dp.CustodianName, dp => dp.FundCode);

            model.Add<IPosition>()
                .AddSubType<Position>(c => c
                    .Add(m => m.Security, m => m.CustodianName, m => m.Portfolio,
                        m => m.ShortMarkingQuantity, m => m.EntryDate, m => m.FXRate,
                        m => m.CustodianName, m => m.Price, m => m.ActualQuantity,
                        m => m.LongMarkingQuantity, m => m.TheoreticalQuantity, m => m.DistributedPositions)
                    .AddLists(m => m.DistributedPositions)
                        );

            model.Add<IPositionKey>()
                .AddSubType<PositionKey>(c => c
                    .Add(m => m.Security, m => m.Portfolio));

            model.Add<IPositionSet>()
                .AddSubType<PositionSet>(c => c
                    .Add(m => m.Position, m => m.AggUnitPosition, m => m.CompliancePosition));

            model.Add<IComplianceGroupKey>()
                .AddSubType<ComplianceGroupKey>(c => c
                    .Add(m => m.Security, m => m.ComplianceGroup));

            model.Add<IAggUnitKey>()
                .AddSubType<AggUnitKey>(c => c
                    .Add(m => m.Security, m => m.AggregationUnit));

            model.Add<ClientOrderId>()
                .Add(m => m.CurrentIndex, m => m.Key);

            additionalTypeModelRegistrations?.Invoke(model);

            return model.Compile();
        }
    }

    public static class RuntimeTypeModelExtensions
    {
        public static FluentMetaType<T> Add<T>(this RuntimeTypeModel model, int fieldIdSeed = 0)
        {
            return new FluentMetaType<T>(model, model.Add(typeof(T), false), fieldIdSeed);
        }
    }

    public class FluentMetaType<T>
    {
        private readonly RuntimeTypeModel _model;
        private readonly MetaType _metaType;
        private int _nextFieldId;
        private int _nextSubTypeId;

        public FluentMetaType(RuntimeTypeModel model, MetaType metaType, int fieldIdSeed = 0)
        {
            _model = model;
            _metaType = metaType;
            _nextFieldId = fieldIdSeed;
            _nextSubTypeId = fieldIdSeed + 100;
        }

        public FluentMetaType<T> AddSubType<TSub>(Action<FluentMetaType<TSub>> config = null)
        {
            _metaType.AddSubType(++_nextSubTypeId, typeof(TSub));
            config?.Invoke(_model.Add<TSub>(_nextSubTypeId + 1));
            return this;
        }

        public FluentMetaType<T> UseSurrogate<TSurrogate>()
        {
            _metaType.SetSurrogate(typeof(TSurrogate));
            return this;
        }

        public FluentMetaType<T> Add(params Expression<Func<T, object>>[] properties)
        {
            foreach (var item in properties)
            {
                MemberExpression expr;
                var unaryExpression = item.Body as UnaryExpression;
                if (unaryExpression != null)
                {
                    expr = (MemberExpression)unaryExpression.Operand;
                }
                else
                {
                    expr = (MemberExpression)item.Body;
                }

                _metaType.AddField(++_nextFieldId, expr.Member.Name);
            }

            return this;
        }

        public FluentMetaType<T> AddLists(params Expression<Func<T, object>>[] properties)
        {
            foreach (var item in properties)
            {
                MemberExpression expr;
                var unaryExpression = item.Body as UnaryExpression;
                if (unaryExpression != null)
                {
                    expr = (MemberExpression)unaryExpression.Operand;
                }
                else
                {
                    expr = (MemberExpression)item.Body;
                }

                _metaType.AddField(++_nextFieldId, expr.Member.Name);
            }

            return this;
        }
    }
}
