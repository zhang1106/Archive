﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Compliance.ServiceBroker
{
    public interface IServiceBrokerListener
    {
        event Action<IList<IPosition>> SodPositionChanged;
        event Action Positionchanged;
        void Start(string connectionString, MonitorTarget target);
        void Stop();
    }
}
