﻿using System.Collections.Generic;
using Bam.EventQ.Snapshot;
using Bam.Oms.OrderGateway.EzeGateway.Models;
using Bam.Oms.OrderGateway.EzeGateway.Models.Snapshot;

namespace Bam.Oms.OrderGateway.EzeGateway.Services
{
    public class ExternalOrderIdService : 
        IExternalOrderIdService, 
        ISnapshotRecoverable<TradeIdMapSnapshot>
    {
        private long _counter;
        private readonly Dictionary<OrderIndexKey, long> _idMap;
        private readonly HashSet<long> _usedIds;

        public ExternalOrderIdService()
        {
            _idMap = new Dictionary<OrderIndexKey, long>();
            _usedIds = new HashSet<long>();
        }

        public long GetId(OrderIndexKey key, string externalId)
        {
            long id;
            if (!_idMap.TryGetValue(key, out id))
            {
                if (!long.TryParse(externalId, out id) || _usedIds.Contains(id))
                {
                    do
                    {
                        id = ++_counter;
                    } while (_usedIds.Contains(_counter));
                }

                _idMap[key] = id;
                _usedIds.Add(id);
            }

            return id;
        }

        TradeIdMapSnapshot ISnapshotRecoverable<TradeIdMapSnapshot>.Persist()
        {
            var snap = new TradeIdMapSnapshot();
            foreach (var item in _idMap)
            {
                snap.Items.Add(new TradeIdMapSnapshot.LineItem
                {
                    Symbol = item.Key.Symbol,
                    Strategy = item.Key.Strategy,
                    TradeId = item.Key.TradeId,
                    EmsOrderId = item.Value
                });
            }

            return snap;
        }

        void ISnapshotRecoverable<TradeIdMapSnapshot>.Recover(TradeIdMapSnapshot snapshot)
        {
            foreach (var item in snapshot.Items)
            {
                var key = new OrderIndexKey(item.TradeId, item.Strategy, item.Symbol);
                _idMap[key] = item.EmsOrderId;
                _usedIds.Add(item.EmsOrderId);
            }
        }
    }
}