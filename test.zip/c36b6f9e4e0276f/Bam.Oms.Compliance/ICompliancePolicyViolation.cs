﻿using System.Collections.Generic;

namespace Bam.Oms.Compliance
{
    public interface ICompliancePolicyViolation
    {
        int PolicyId { get; set; }
        string PolicyName { get; set; }
        IList<IComplianceRuleViolation> Violations { get; set; }
        //highest violation level
        ComplianceViolationLevel ViolationLevel { get; }
    }
}
