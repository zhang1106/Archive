﻿using System.Collections.Generic;

namespace Bam.EventQ.Throttling
{
    public interface IThrottledBatchHandler<in TItem>
    {
        void Handle(IReadOnlyList<TItem> batch);
    }
}
