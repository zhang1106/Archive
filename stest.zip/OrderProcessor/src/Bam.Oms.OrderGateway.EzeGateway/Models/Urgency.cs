﻿namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public enum Urgency
    {
        High,
        Low,
        Manual,
        Medium,
        Vwap
    }
}
