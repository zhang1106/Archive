﻿using Bam.EventQ.Recovery;

namespace Bam.EventQ.Sequencing
{
    public interface IMessage
    {
        SequenceInfo Header { get; set; }
    }
}
