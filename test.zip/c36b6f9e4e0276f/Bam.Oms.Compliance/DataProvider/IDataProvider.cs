﻿namespace Bam.Oms.Compliance.DataProvider
{
    public interface IDataProvider
    {
        void RefreshData();
    }
}
