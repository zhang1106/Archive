﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace Bam.EventQ.RabbitMQ
{
    public class CachingConsumer : IBasicConsumer
    {
        private readonly IRoutingKeyConverter _routingKeyConverter;
        private readonly ConcurrentQueue<Entry> _received;
        private readonly ManualResetEventSlim _dataAvailable;
        
        private struct Entry
        {
            public int Topic { get; set; }
            public byte[] Data { get; set; }
            public ulong DeliveryTag { get; set; }
        }

        public CachingConsumer(IModel model, IRoutingKeyConverter routingKeyConverter)
        {
            Model = model;
            _routingKeyConverter = routingKeyConverter;
            _received = new ConcurrentQueue<Entry>();
            _dataAvailable = new ManualResetEventSlim();
        }

        public void HandleBasicCancel(string consumerTag)
        {
            
        }

        public void HandleBasicCancelOk(string consumerTag)
        {
            
        }

        public void HandleBasicConsumeOk(string consumerTag)
        {
            
        }

        public void HandleBasicDeliver(string consumerTag, ulong deliveryTag, 
            bool redelivered, string exchange, string routingKey, IBasicProperties properties, byte[] body)
        {
            int topic = _routingKeyConverter.GetTopic(routingKey);
            _received.Enqueue(new Entry
            {
                Topic = topic,
                Data = body,
                DeliveryTag = deliveryTag
            });
            _dataAvailable.Set();
        }

        public void HandleModelShutdown(object model, ShutdownEventArgs reason)
        {
            
        }

        public IModel Model { get; }
        public WaitHandle DataAvailable => _dataAvailable.WaitHandle;

        public event EventHandler<ConsumerEventArgs> ConsumerCancelled
        {
            add { }
            remove { }
        }

        public bool TryDequeue(out KeyValuePair<int, byte[]> data)
        {
            Entry entry;
            bool result = _received.TryDequeue(out entry);
            if (_received.IsEmpty)
            {
                _dataAvailable.Reset();
            }

            if (result)
            {
                data = new KeyValuePair<int, byte[]>(entry.Topic, entry.Data);
                Model.BasicAck(entry.DeliveryTag, false);
            }
            else
            {
                data = default(KeyValuePair<int, byte[]>);
            }

            return result;
        }
    }
}
