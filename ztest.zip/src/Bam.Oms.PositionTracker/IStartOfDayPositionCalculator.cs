﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.PositionTracker
{
    public interface IStartOfDayPositionCalculator
    {
        IReadOnlyList<IPositionSet> Adjust(
            IReadOnlyList<IPositionSet> positionSets,
            IReadOnlyList<IPosition> newPositions,
            IDictionary<IPositionKey, IList<IOrder>> orders,
            IDictionary<IPositionKey, IList<IBlockTrade>> trades);

        IReadOnlyList<IPositionSet> Calculate(
            IReadOnlyList<IPosition> positions,
            IDictionary<IPositionKey, IList<IOrder>> orders,
            IDictionary<IPositionKey, IList<IBlockTrade>> trades);

        IReadOnlyList<IPosition> Pick(
            IReadOnlyList<IPosition> officialSodPositions,
            IReadOnlyList<IPosition> snapshotSodPositions,
            DateTime currentBusinessDay);
    }
}