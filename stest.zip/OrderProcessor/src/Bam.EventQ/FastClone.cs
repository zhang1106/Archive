﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;

namespace Bam.EventQ
{
    public static class FastClone
    {
        public static T Clone<T>(this T instance)
        {
            if (ReferenceEquals(instance, default(T)))
            {
                return default(T);
            }

            return FastClone<T>.CloneFunc(instance);
        }
    }

    internal static class FastClone<T>
    {
        public static Func<T, T> CloneFunc { get; }

        static FastClone()
        {
            var type = typeof(T);
            var ctor = type.GetConstructor(Type.EmptyTypes);
            if (ctor == null)
            {
                throw new InvalidOperationException($"Cannot clone {type.GetDisplayName()} because it has no public constructor.");
            }

            var ops = new List<Expression>();
            var param = Expression.Parameter(typeof(T), "instance");
            var clone = Expression.Variable(typeof(T), "clone");

            ops.Add(Expression.Assign(clone, Expression.New(ctor)));
            
            foreach (var prop in type.GetProperties())
            {
                if (!prop.CanRead)
                    continue;

                var source = Expression.Property(param, prop);
                var target = Expression.Property(clone, prop);

                Type itemType, keyType, valueType;
                if (IsDirectAssignment(prop.PropertyType))
                {
                    if (prop.CanWrite)
                    {
                        ops.Add(Expression.Assign(target, source));
                    }
                }
                else if (prop.PropertyType.IsCollectionType(out itemType))
                {
                    var list = Expression.Variable(prop.PropertyType, "list");
                    var item = Expression.Variable(itemType, "item");
                    ops.Add(Expression.Block(new[] {list, item},
                        Expression.Assign(list, target),
                        ForEach(source, item, Expression.Call(
                            list, nameof(ICollection<int>.Add), Type.EmptyTypes, 
                            IsDirectAssignment(itemType) ? item : Clone(item)))
                    ));
                }
                else if (prop.PropertyType.IsDictionaryType(out keyType, out valueType))
                {
                    var dict = Expression.Variable(prop.PropertyType, "dict");
                    var item = Expression.Variable(
                        typeof(KeyValuePair<,>).MakeGenericType(keyType, valueType),
                        "item");
                    var keyProp = Expression.Property(item, nameof(KeyValuePair<int, int>.Key));
                    var valueProp = Expression.Property(item, nameof(KeyValuePair<int, int>.Value));
                    ops.Add(Expression.Block(new[] { dict, item },
                        Expression.Assign(dict, target),
                        ForEach(source, item, Expression.Call(
                            dict, nameof(IDictionary<int, int>.Add), Type.EmptyTypes,
                            IsDirectAssignment(keyType) ? keyProp : Clone(keyProp),
                            IsDirectAssignment(valueType) ? valueProp : Clone(valueProp)))
                    ));
                }
                else if (prop.CanWrite)
                {
                    ops.Add(Expression.Assign(target, Clone(source)));
                }
            }

            ops.Add(clone);

            var body = Expression.Block(new[] {clone}, ops);
            var lambda = Expression.Lambda<Func<T, T>>(body, param);
            CloneFunc = lambda.Compile();
        }

        private static Expression Clone(Expression instance)
        {
            var method = GetCloneMethod(instance.Type);
            return Expression.Call(null, method, instance);
        }

        private static MethodInfo GetCloneMethod(Type type)
        {
            MethodInfo method = null;
            foreach (var mi in typeof(FastClone).GetMethods())
            {
                if (mi.Name == nameof(FastClone.Clone))
                {
                    method = mi.MakeGenericMethod(type);
                    break;
                }
            }

            return method;
        }

        private static bool IsDirectAssignment(Type type)
        {
            return type.IsValueType || type == typeof(string) || type == typeof(byte[]);
        }
        
        private static Expression ForEach(Expression collection, ParameterExpression loopVar, Expression loopContent)
        {
            var elementType = loopVar.Type;
            var enumerableType = typeof(IEnumerable<>).MakeGenericType(elementType);
            var enumeratorType = typeof(IEnumerator<>).MakeGenericType(elementType);

            var enumeratorVar = Expression.Variable(enumeratorType, "enumerator");
            var getEnumeratorCall = Expression.Call(collection, enumerableType.GetMethod(nameof(IEnumerable.GetEnumerator)));
            var enumeratorAssign = Expression.Assign(enumeratorVar, getEnumeratorCall);

            var moveNextCall = Expression.Call(enumeratorVar, typeof(IEnumerator).GetMethod(nameof(IEnumerator.MoveNext)));

            var breakLabel = Expression.Label("LoopBreak");

            var loop = Expression.Block(new[] { enumeratorVar },
                enumeratorAssign,
                Expression.Loop(
                    Expression.IfThenElse(
                        Expression.Equal(moveNextCall, Expression.Constant(true)),
                        Expression.Block(new[] { loopVar },
                            Expression.Assign(loopVar, Expression.Property(enumeratorVar, nameof(IEnumerator.Current))),
                            loopContent
                        ),
                        Expression.Break(breakLabel)
                    ),
                    breakLabel)
            );

            return loop;
        }
    }
}
