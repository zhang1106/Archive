﻿using System.Threading;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Pipeline
{
    public interface IPipelineStepInitializer<TItem>
    {
        void Execute(IQueue<PipelineQueueItem<TItem>> queue, CancellationToken cancellationToken);
    }
}
