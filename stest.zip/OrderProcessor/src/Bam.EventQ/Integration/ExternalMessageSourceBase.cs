﻿using System;

namespace Bam.EventQ.Integration
{
    public abstract class ExternalMessageSourceBase<TItem> : IExternalMessageSource<TItem>
    {
        protected Action<TItem> Handler { get; private set; }

        public void Initialize(Action<TItem> handler)
        {
            Handler = handler;
            Initialize();
        }

        protected virtual void Initialize()
        {
            
        }

        public virtual void Start()
        {
            
        }

        public virtual void Stop()
        {
            
        }
    }
}
