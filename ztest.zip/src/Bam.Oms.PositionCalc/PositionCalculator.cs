﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data;

namespace Bam.Oms.PositionCalc
{
    public class PositionCalculator : IPositionCalculator
    {        
        public IEnumerable<IPosition> CalculatePositions(IEnumerable<IPosition> currentPositions, IEnumerable<ITrade> fills)
        {
            return fills.Select(fill => CalculatePosition(currentPositions, fill)).ToList();
        }

        public IEnumerable<IOrder> CalculatePositionAndMarkOrders(IEnumerable<IPosition> currentPositions, IEnumerable<IOrder> orders, out IEnumerable<IPosition> finalPositions )
        {
            IEnumerable<IOrder> finalOrders = new List<IOrder>();
            IList<IPosition> finalPositionList = new List<IPosition>();

            if (!orders.Any())
            {
                finalPositions = currentPositions;
                return finalOrders;
            }

            foreach (IOrder order in orders)
            {
                IPosition finalPosition;
                finalOrders = finalOrders.Concat(CalculatePositionAndMarkOrder(currentPositions.ToList(), order, out finalPosition));
                finalPositionList.Add(finalPosition);
            }
            finalPositions = finalPositionList;
            return finalOrders;
        }

        public IPosition CalculatePosition(IEnumerable<IPosition> currentPositions, ITrade trade)
        {
            IPosition position =
                currentPositions.Single(
                    pos => pos.Portfolio.Equals(trade.Portfolio) && pos.Security.Equals(trade.Security));
            
            return CalculatePosition(trade, position);            
        }        

        public IEnumerable<IOrder> CalculatePositionAndMarkOrder(IEnumerable<IPosition> currentPositions, IOrder order, out IPosition finalPosition)
        {
            IEnumerable<IPosition> positions = currentPositions as IPosition[] ?? currentPositions.ToArray();
            decimal longTheoPosition = (from pos in positions
                                        where pos.Security.Equals(order.Security) && pos.TheoreticalSide == SideType.Long
                                        select pos.TheoreticalQuantity).Sum();

            decimal shortTheoPosition = (from pos in positions
                                         where pos.Security.Equals(order.Security) && pos.TheoreticalSide == SideType.Short
                                         select pos.TheoreticalQuantity).Sum();

            decimal currentTheoPosition = longTheoPosition - shortTheoPosition;
            IList<IOrder> finalOrders = new List<IOrder>();

            if ((currentTheoPosition >= 0 && order.Side == SideType.Buy)
                || (currentTheoPosition >= 0 && order.Side == SideType.Sell && Math.Abs(currentTheoPosition) >= order.Size))
            {
                IOrder finalOrder = (IOrder)(order.Clone());
                finalOrder.Size = order.Size;
                finalOrder.Side = order.Side;                
                finalOrders.Add(finalOrder);                
            }
            else if (currentTheoPosition <= 0 && order.Side == SideType.Sell)
            {
                // SellShort order.size
                IOrder finalSellOrder = (IOrder)(order.Clone());
                finalSellOrder.Size = order.Size;
                finalSellOrder.Side = SideType.SellShort;                                
                finalOrders.Add(finalSellOrder);                
            }
            else if (currentTheoPosition > 0 && order.Side == SideType.Sell && Math.Abs(currentTheoPosition) <= order.Size)
            {
                // Sell order currentTheoPosition
                IOrder finalSellOrder = (IOrder)(order.Clone());
                finalSellOrder.Size = Math.Abs(currentTheoPosition);
                finalSellOrder.Side = SideType.Sell;

                // Sell Short order.Size - currentTheoPosition
                IOrder finalSellShortOrder = (IOrder)(order.Clone());
                finalSellShortOrder.Size = Math.Abs(order.Size - Math.Abs(currentTheoPosition));
                finalSellShortOrder.Side = SideType.SellShort;

                finalOrders.Add(finalSellOrder);       
                finalOrders.Add(finalSellShortOrder);
            }
            else if (currentTheoPosition < 0 && order.Side == SideType.Buy && Math.Abs(currentTheoPosition) >= order.Size)
            {
                // CoverShort order currentTheoPosition
                IOrder finalCoverOrder = (IOrder)(order.Clone());
                finalCoverOrder.Size = order.Size;
                finalCoverOrder.Side = SideType.Cover;                

                finalOrders.Add(finalCoverOrder);                
            }
            else if (currentTheoPosition < 0 && order.Side == SideType.Buy && Math.Abs(currentTheoPosition) <= order.Size)
            {
                // CoverShort order currentTheoPosition
                IOrder finalCoverOrder = (IOrder)(order.Clone());
                finalCoverOrder.Size = Math.Abs(currentTheoPosition);
                finalCoverOrder.Side = SideType.Cover;
                finalOrders.Add(finalCoverOrder);

                // Buy order.Size - currentTheoPosition
                IOrder finalBuyOrder = (IOrder)(order.Clone());
                finalBuyOrder.Size = Math.Abs(order.Size - Math.Abs(currentTheoPosition));
                finalBuyOrder.Side = SideType.Buy;                
                finalOrders.Add(finalBuyOrder);
            }
            else
            {
                throw new ApplicationException("Invalid side for the order. Order side must be either Buy or Sell.");
            }

            finalPosition = positions.SingleOrDefault( pos => pos.Portfolio.Equals(order.Portfolio) && pos.Security.Equals(order.Security))
                ?? new Position(order.Portfolio, order.Security);

            finalPosition = finalOrders.Aggregate(finalPosition, AdjustFinalPosition);
            return finalOrders;
        }

        public IPosition CancelOrder(IPosition position, IOrder order)
        {
            IPosition finalPosition = (IPosition)position.Clone();
            if (position.TheoreticalSide == SideType.Long)
            {
                finalPosition.TheoreticalQuantity = position.TheoreticalQuantity - (order.Side == SideType.Buy || order.Side == SideType.Cover
                    ? order.Size
                    : -1 * order.Size);
            }

            if (position.TheoreticalSide == SideType.Short)
            {
                finalPosition.TheoreticalQuantity = (-1 * position.TheoreticalQuantity) -
                                                    (order.Side == SideType.Buy || order.Side == SideType.Cover
                                                        ? order.Size
                                                        : -1 * order.Size);
            }

            finalPosition.TheoreticalSide = finalPosition.TheoreticalQuantity >= 0 ? SideType.Long : SideType.Short;
            finalPosition.TheoreticalQuantity = Math.Abs(finalPosition.TheoreticalQuantity);
            return finalPosition;
        }

        private static IPosition AdjustFinalPosition(IPosition position, IOrder finalOrder)
        {
            IPosition finalPosition = (IPosition)position.Clone();
            if (position.TheoreticalSide == SideType.Long)
            {
                finalPosition.TheoreticalQuantity = position.TheoreticalQuantity + (finalOrder.Side == SideType.Buy || finalOrder.Side == SideType.Cover
                    ? finalOrder.Size
                    : -1 * finalOrder.Size);
            }

            if (position.TheoreticalSide == SideType.Short)
            {
                finalPosition.TheoreticalQuantity = (-1 * position.TheoreticalQuantity) +
                                                    (finalOrder.Side == SideType.Buy || finalOrder.Side == SideType.Cover
                                                        ? finalOrder.Size
                                                        : -1 * finalOrder.Size);
            }

            finalPosition.TheoreticalSide = finalPosition.TheoreticalQuantity >= 0 ? SideType.Long : SideType.Short;
            finalPosition.TheoreticalQuantity = Math.Abs(finalPosition.TheoreticalQuantity);
            return finalPosition;
        }

        private static IPosition CalculatePosition(ITrade trade, IPosition position)
        {
            IPosition finalPosition = (IPosition)position.Clone();
            switch (position.ActualSide)
            {
                case SideType.Long:
                    finalPosition.ActualQuantity = (position.ActualQuantity + (trade.Side == SideType.Buy || trade.Side == SideType.Cover
                        ? trade.TradedQuantity
                        : -1 * trade.TradedQuantity));
                    break;
                case SideType.Short:
                    finalPosition.ActualQuantity = (-1 * position.ActualQuantity) +
                                                   (trade.Side == SideType.Buy || trade.Side == SideType.Cover
                                                       ? trade.TradedQuantity
                                                       : -1 * trade.TradedQuantity);
                    break;
                default:
                    throw new ApplicationException("Invalid position side.");
            }

            finalPosition.ActualSide = finalPosition.ActualQuantity >= 0 ? SideType.Long : SideType.Short;
            finalPosition.ActualQuantity = Math.Abs(finalPosition.ActualQuantity);
            return finalPosition;
        }
    }
}
