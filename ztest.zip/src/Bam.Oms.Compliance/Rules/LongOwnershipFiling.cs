﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Securities;
using Bam.Oms.Compliance.Results;
using BAM.Infrastructure.Ioc;
using BAM.Infrastructure.DataFlowLogging.Client;

namespace Bam.Oms.Compliance.Rules
{
    [JsonObject(MemberSerialization.OptIn)]
    public class LongOwnerShipFiling : FirmRuleBase 
    {
        private readonly IIntradayPositionProvider _positionProvider;
        private readonly ILongOwnershipRuleResultProvider _ruleResultDataProvider;
        private readonly IMarketDataProvider _marketDataProvider;
       [JsonProperty]
        public SortedList<decimal, ThreshholdWarning>  Threshholds { get; set; }
        public LongOwnerShipFiling(IIntradayPositionProvider positionProvider, IMarketDataProvider marketDataProvider, IFactProvider factProvider,
        ILongOwnershipRuleResultProvider ruleResultDataProvider,  ILogger logger, ILoggingAgent eventLogger)
            : base(factProvider, logger, eventLogger)
        {
            _positionProvider = positionProvider;
            _ruleResultDataProvider = ruleResultDataProvider;
            _marketDataProvider = marketDataProvider;
            Threshholds = new SortedList<decimal, ThreshholdWarning>(new DescendingComparer());
        }
        public override IRuleResult CheckViolation(CompliancePosition input, bool isPreCheck)
        {
            var result = new LongOwnershipFilingResult()
            {
                RuleId = this.Id,
                RuleName = this.Name,
                Type = typeof(LongOwnershipFilingResult).FullName,
                BamSymbol = input.BamSymbol,
                PolicyId = input.PolicyId,
                IsViolationOverriden = false,
                AlertLevel = ComplianceAlertLevel.NoViolation,
                Ratio = null,
                SharesOutstanding = null,
                Description = "No Violation"
            };

            var context=string.Empty;
            try
            {
                var security = input.Security;
                if (!isPreCheck && IsActive && (SecurityFilter == null || SecurityFilter.ApplyFilter(this.GetType().FullName, security)))
                {
                    var currentHeld = _positionProvider.GetFirmWideLongQuantity(input.BamSymbol);
                    var sharesOutstanding = _marketDataProvider.GetSharesOutstanding(input.BamSymbol);
                    var ratio = currentHeld.Item2 / sharesOutstanding;
                    context = currentHeld.Item1;
                    result.PositionQty = currentHeld.Item2;
                    //no data available
                    if (!ratio.HasValue)
                    {
                        result.AlertLevel = ComplianceAlertLevel.NoDataAvaiable;
                        result.Description = $"No {(currentHeld.Item2.HasValue ? "Sharesoutstanding" : "Position")} available";
                        result.Ratio = null;
                        base.LogEvent(result.Key, context);
                        return result;
                    }
                    //get history
                    var lastRatio = _ruleResultDataProvider.GetRatio(input.PolicyId, this.Id, input.BamSymbol);
                    var lastLowLimit = _ruleResultDataProvider.GetLowLimit(input.PolicyId, this.Id, input.BamSymbol);
                    //set result
                    result.Ratio = ratio;
                    result.SharesOutstanding = sharesOutstanding;
                    //waterfall checking
                    foreach (var threshhold in Threshholds.Values)
                    {
                        if (threshhold.IsInCurentWarningArea(ratio.Value))
                        {
                            result.LowLimit = threshhold.LowLimit;
                            result.AlertLevel = threshhold.GetAlertlevel(ratio, lastRatio, lastLowLimit);
                            switch(result.AlertLevel)
                            {
                                case ComplianceAlertLevel.ExceedWarning:
                                    result.Description = $"Going above {threshhold.LowLimit*100}% Ownership";
                                    break;
                                case ComplianceAlertLevel.FallBelowWarning:
                                    result.Description = $"Falling below {threshhold.UpLimit*100}% Ownership ";
                                    break;
                                case ComplianceAlertLevel.SubWarning:
                                    result.Description = string.Format("Current ratio: {0:N2}% , last: {1:N2}% and its change exceeds: {2:N2}%",
                                    ratio.Value*100, lastRatio.Value*100,  threshhold.SubsequentChange.Value * 100);
                                    break;
                                default:
                                    result.Description = $"Alert Status:{result.AlertLevel.ToString()}";
                                    break;
                            }
                        }
                    }
                    //log to dataflow
                    LogEvent(result.Key, context);
                }
            }
            catch (Exception ex)
            {
                result.AlertLevel = ComplianceAlertLevel.Error;
                result.Description = ex.Message;
                _logger.Error(ex.Message);
                //log to dataflow
                LogErrorEvent(result.Key, context);
            }
            if (result.AlertLevel == ComplianceAlertLevel.NotApplicable)
            {
                _logger.Debug(input.ToString());
            }
            return result;
        }
    }
}
