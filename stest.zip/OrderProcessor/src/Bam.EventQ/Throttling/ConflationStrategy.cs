﻿using System;
using System.Collections.Generic;
using System.Threading;
using Bam.EventQ.Diagnostics;

namespace Bam.EventQ.Throttling
{
    public class ConflationStrategy<TKey, TItem> : IThrottlingStrategy<TItem>
    {
        private readonly CasLock _lock = new CasLock();
        private readonly Func<TItem, TKey> _keyFunc;
        private readonly Predicate<TItem> _predicate;
        private readonly List<TItem> _list = new List<TItem>(4096);
        private Dictionary<TKey, TItem> _write = new Dictionary<TKey, TItem>(4096);
        private Dictionary<TKey, TItem> _process = new Dictionary<TKey, TItem>(4096);

        public ConflationStrategy(Func<TItem, TKey> keyFunc)
            : this(keyFunc, m => true)
        {
            
        }

        public ConflationStrategy(Func<TItem, TKey> keyFunc, Predicate<TItem> predicate)
        {
            _keyFunc = keyFunc;
            _predicate = predicate;
        }

        public ILogger Logger { get; set; }

        public void Throttle(TItem item, long sequence, bool endOfBatch)
        {
            if (!_predicate(item))
                return;

            var key = _keyFunc(item);
            using (_lock.Acquire())
            {
                var write = Volatile.Read(ref _write);
                write[key] = item;
            }
        }

        public void Flush(IThrottledBatchHandler<TItem> handler)
        {
            using (_lock.Acquire())
            {
                var write = Volatile.Read(ref _write);
                var process = Volatile.Read(ref _process);
                Volatile.Write(ref _write, process);
                Volatile.Write(ref _process, write);
            }
            
            foreach (var item in _process.Values)
            {
                _list.Add(item);
            }
            _process.Clear();

            if (_list.Count > 0)
            {
                Logger?.LogDebug($"Processing batch of {_list.Count} '{typeof(TItem).GetDisplayName()}'");
                handler.Handle(_list);
            }
            _list.Clear();
        }
    }
}
