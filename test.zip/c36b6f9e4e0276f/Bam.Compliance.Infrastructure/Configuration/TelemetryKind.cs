﻿namespace Bam.Compliance.Infrastructure.Configuration
{
    public enum TelemetryKind
    {
        LogFile = 1,
        PerformanceCounters = 2
    }
}
