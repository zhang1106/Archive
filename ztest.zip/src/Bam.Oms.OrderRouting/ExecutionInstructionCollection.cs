﻿using System.Collections.Generic;
using System.Configuration;

namespace Bam.Oms.OrderRouting
{

    public class ExecutionInstructionConfigurationSection : ConfigurationSection
    {
        [ConfigurationProperty("executionInstructions", IsDefaultCollection = false)]
        [ConfigurationCollection(typeof(ExecutionInstructionCollection),
            AddItemName = "add",
            ClearItemsName = "clear",
            RemoveItemName = "remove")]
        public ExecutionInstructionCollection ExecutionInstructions
        {
            get
            {
                return (ExecutionInstructionCollection)base["executionInstructions"];
            }
        }
    }

    [ConfigurationCollection(typeof(InstructionElement))]
    public class ExecutionInstructionCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new InstructionElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((InstructionElement)element).ExecutionCode;
        }
    }

    public class InstructionElement : ConfigurationElement
    {
        [ConfigurationProperty("tag", IsKey = false, IsRequired = true)]
        public string Tag
        {
            get { return (string)base["tag"]; }
            set { base["tag"] = value; }
        }

        [ConfigurationProperty("executionCode", IsKey = true,IsRequired = true)]
        public string ExecutionCode
        {
            get { return (string)base["executionCode"]; }
            set { base["executionCode"] = value; }
        }
    }
}