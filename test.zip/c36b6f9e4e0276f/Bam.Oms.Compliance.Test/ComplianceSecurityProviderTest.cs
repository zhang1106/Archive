﻿using System;
using System.Collections.Generic;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Securities;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class ComplianceSecurityProviderTest
    {
        DwSecurityProvider _dwSecurityProvider;

        [SetUp]
        public void Setup()
        {
            var testSecurities = new List<Security>
            {
                new Security() {BamSymbol = "IBM", Country = "US", SecurityType = Data.Enumerators.SecurityType.Equity},
                new Security() {BamSymbol = "APPL", Country = "US", SecurityType = Data.Enumerators.SecurityType.Equity}
            };
            var securityProvider = new Mock<ISecurityDBRepository>();
            securityProvider.Setup(n => n.GetSecurities(It.IsAny<string[]>(), It.IsAny<DateTime>())).Returns(testSecurities);
            _dwSecurityProvider = new DwSecurityProvider(securityProvider.Object, new Mock<ILogger>().Object, new Mock<ISettings>().Object);
        }
        

        [Test]
        public void TestDwSecurityProviderGetSecurity()
        {
            //setup
            _dwSecurityProvider.RefreshData();
            //act
            var security = _dwSecurityProvider.GetSecurity("IBM");
            //ass
            Assert.IsTrue(security.BamSymbol == "IBM");
        }
    }
}
