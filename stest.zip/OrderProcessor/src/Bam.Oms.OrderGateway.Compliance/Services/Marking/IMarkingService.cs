﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;

namespace Bam.Oms.OrderGateway.Compliance.Services.Marking
{
    public interface IMarkingService
    {
        void Mark(CachedSecurity security, List<OrderAllocation> opening, List<OrderAllocation> closing);

        List<Order> Split(Order order, IOrderFactory factory, List<OrderAllocation> openingAllocations,
            List<OrderAllocation> closingAllocations, List<OrderAllocation> mergedAllocations,
            long approvedShortLocate);
    }
}