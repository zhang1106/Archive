﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Results;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance
{
    public class Helper : IHelper
    {
        private readonly ISettings _settings;
        private readonly ICustomDataProvider _customDataProvider;
        private readonly IOgDataRepository _ogDataRepository;
        private readonly ILogger _logger;
        private readonly ISecurityProvider _securityProvider;

        public Helper(ISettings settings, ICustomDataProvider customDataProvider, IOgDataRepository ogDataRepository, ISecurityProvider securityProvider, ILogger logger)
        {
            _settings = settings;
            _customDataProvider = customDataProvider;
            _ogDataRepository = ogDataRepository;
            _securityProvider = securityProvider;
            _logger = logger;
        }

        /// <summary>
        /// Create a new object which type is defined by item.Type. 
        /// All the writable properpies will get the same value from source item.
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public   object ConvertBaseToChild(IExtensible item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            var targetType = Type.GetType(item.Type);

            var target = Activator.CreateInstance(targetType);

            foreach (var p in item.GetType().GetProperties())
            {
                var targetProperty = targetType?.GetProperty(p.Name);
                if (targetProperty != null && targetProperty.CanWrite)
                {
                    targetProperty.SetValue(target, p.GetValue(item));
                }
            }

            return target;
        }

        public void DumpToDb(IEnumerable<IPosition> positions, PositionType type)
        {
            var time = DateTime.Now;
            var flatPositions = positions.Select(p => new FlatPosition()
            {
                BamSymbol = p.Security.BamSymbol,
                CompositeParent = p.ParentSymbol,
                Entity = _customDataProvider.GetEntity(p.Portfolio.ToString()),
                Isin = p.Security.Isin,
                Quantity = (long)p.ActualQuantity,
                SecurityType = p.Security.SecurityType.ToString(),
                Strategy = p.Portfolio.ToString(),
                CustodianAcct = p.CustodianAccount,
                UnderlyingSymbol = p.Security.UnderlyingSymbol,
                PositionType = type.ToString(),
                TimeStamp = time
            }
            );
            _ogDataRepository.DumpPositions(flatPositions);
        }
        
        public   OwnershipFilingResult CreateFilingResult(ICompliancePosition input, IRule<ICompliancePosition> rule, SideType side, string entity, string identityType)
        {
            var result = new OwnershipFilingResult()
            {
                RuleId = rule.Id,
                BamSymbol =  input.BamSymbol,
                RuleName = rule.Name,
                Description = "No violation",
                PolicyId = input.PolicyId,
                IsViolationOverriden = false,
                PositionQty = 0m,
                Type = typeof(OwnershipFilingResult).FullName,
                AlertLevel = ComplianceAlertLevel.NoViolation,
                HeadRoom = new HeadRoom()
                {
                    Side = side.ToString(),
                    IdentifierType = identityType,
                    Identifier = identityType == "SYMBOL" ? input.BamSymbol : input.Security.Isin,
                    IsExempt = false,
                    Entity = string.IsNullOrEmpty(entity)? "FIRM" : entity,
                    IncludeConstituent = rule.IncludeConstituent,
                    HeadRooms = new List<HeadRoom.HeadRoomUnit>(),
                    Ratio = new Dictionary<string, decimal>(){{"AQTF", 0m },{"MAIN", 1m }}
                }
            };
            return result;
        }

        protected Dictionary<string, decimal> GetRatio(IRule<ICompliancePosition> rule)
        {
            return rule.Ratio ?? new Dictionary<string, decimal>()
            {
                {"AQTF", _settings.HeadRoomRatioAQTF / 100m},
                {"MAIN", _settings.HeadRoomRatioMAIN / 100m}
            };
        }

        protected long calcHeadRoom(long sharesOutstanding, decimal lowLimit, decimal ratio, decimal position, SideType ruleSide)
        {
            if (ruleSide == SideType.Long || ruleSide == SideType.NetLong)
            {
                return  (long)(sharesOutstanding * lowLimit * ratio - position);
            }
            if (ruleSide == SideType.Short || ruleSide == SideType.NetShort)
            {
                return (long)(sharesOutstanding * lowLimit * ratio + position);
            }
            
            //default to long
            _logger.Error($"Not supported rule side: {ruleSide}");
            return 0;
        }

        public HeadRoom.HeadRoomUnit CreateHeadRoomUnit(IRule<ICompliancePosition> rule, OwnershipFilingResult result, ThreshholdWarning threshhold, SideType side)
        {
            var ratio = GetRatio(rule)["MAIN"];

            var headRoom = new HeadRoom.HeadRoomUnit()
            {
                Threshold = threshhold.LowLimit,
                HeadRoom =  calcHeadRoom((long)result.SharesOutstanding, threshhold.LowLimit.Value, ratio, result.PositionQty.Value, side),
                AlertLevel = GetAlertLevel(result, threshhold.AlertLevel),
                FireOnce = threshhold.FireOnce
            };
            return headRoom;
        }
        
        public IList<HeadRoom.HeadRoomUnit> CreateErrHeadRoomUnit(OwnershipFilingResult result, IEnumerable<ThreshholdWarning> threshholds)
        {
            var headRooms = threshholds.Where(t=>t.LowLimit!=null && t.LowLimit != 0 && t.AlertLevel != ComplianceAlertLevel.Reportable).Select(t=>
            new HeadRoom.HeadRoomUnit()
            {
                Threshold = t.LowLimit,
                HeadRoom =0,
                AlertLevel = GetAlertLevel(result, t.AlertLevel),
                FireOnce = t.FireOnce
            });
            return headRooms.ToList();
        }

        public IEnumerable<IRuleResult> CreateNoInfoFilingResult(IEnumerable<string> underlyings, string description )
        {
            var result = underlyings.Select(s=> new OwnershipFilingResult()
            {
                RuleId = 0,
                BamSymbol = s,
                RuleName = description,
                Description = description,
                PolicyId = 0,
                IsViolationOverriden = false,
                PositionQty = 0m,
                Type = typeof(OwnershipFilingResult).FullName,
                AlertLevel = ComplianceAlertLevel.Warning,
                HeadRoom = new HeadRoom()
                {
                    Side = SideType.NetLong.ToString(),
                    IdentifierType = "SYMBOL",
                    Identifier =  s,
                    IsExempt = false,
                    Entity =   "FIRM"  ,
                    IncludeConstituent = false,
                    HeadRooms = new List<HeadRoom.HeadRoomUnit>()
                    {
                        new HeadRoom.HeadRoomUnit()
                        {
                            Threshold = 0,
                            HeadRoom =0,
                            AlertLevel = (_settings.WarningOnly?ComplianceAlertLevel.Warning:ComplianceAlertLevel.Overrideable).ToString(),
                            FireOnce = false
                        }
                    },
                    Ratio =   new Dictionary<string, decimal>() { { "AQTF",  0m }, { "MAIN", 1m } }
                }
            });
            return result;
        }

        protected string GetAlertLevel(OwnershipFilingResult result, ComplianceAlertLevel? alertLevel)
        {
            if(_settings.WarningOnly || result.HeadRoom.IsExempt) return ComplianceAlertLevel.Warning.ToString();
            return alertLevel == null
                ? ComplianceAlertLevel.Warning.ToString()
                : alertLevel.ToString();
        }

        public IRuleResult CreateNoRuleHeadRoomForAll(string symbol, int policyId)
        {
            return new RuleResult()
            {
                RuleName = "No rules found applying to this position",
                BamSymbol = symbol,
                HeadRoom = new HeadRoom()
                {
                    Identifier = symbol,
                    IdentifierType = "SYMBOL",
                    IsExempt = true,
                    Side = "All",
                    PolicyId = policyId,
                    HeadRooms = new List<HeadRoom.HeadRoomUnit>(),
                    Entity = "Firm",
                    Ratio = new Dictionary<string, decimal>() { { "AQTF", 0m } ,{ "MAIN",  1m}}
                }
            };
        }
 
        public DateTime GetBusinessDate(DateTime now)
        {    
            return now.TimeOfDay > _settings.SODDateTime.TimeOfDay
                ? now.Date.AddDays(1)
                : now.Date;
        
        }

        public IEnumerable<IPosition> Convert(IEnumerable<DtdPosition> positions, PositionType type)
        {
            var sb = new StringBuilder();
            var result = new List<IPosition>();
            foreach (var p in positions)
            {
                var security = _securityProvider.GetSecurity(p.BamSymbol);
                if (security == null)
                {
                    _logger.Info($"Security: Not found in Security Master-{p.BamSymbol}");
                    sb.AppendLine(p.BamSymbol);
                    continue;
                }
                var portfolio = Portfolio.Parse(p.Portfolio);
                var position = new Position
                {
                    Portfolio = (Portfolio)portfolio,
                    Security = (Security)security,
                    ActualQuantity = p.Quantity,
                    CustodianAccount = p.Custodian,
                    NetExposure = p.NetExposure,
                    EntryDate = p.TradeDate,
                }.InitPosition();
                result.Add(position);
            }

            if (type != PositionType.Sod) return result;

            var file = _settings.DebugFilePath + "SodSecurityNotExists" + DateTime.UtcNow.Ticks + ".csv";
            System.IO.File.WriteAllText(file, sb.ToString());

            return result;
        }

        public IEnumerable<Security> Convert(IEnumerable<MarketData> bbData)
        {
            var securites = bbData.Select(b => new Security()
            {
                BamSymbol = b.Symbol,
                Isin = b.ISIN,
                Country = b.CountryOfSedo1,
                Industry = b.GicIndustry,
                SecurityType = Bam.Oms.Data.Utility.ConvertEnum<SecurityType>(b.SecurityType)
            });
            return securites;
        }

        public ICompliancePosition CreateCompliancePosition(ISecurity security, IPolicy<ICompliancePosition> policy,
            PositionType pType)
        {
          
            var pTarget = Container.Instance.Resolve<ICompliancePosition>()
                            .Init(security, policy, pType);
            return pTarget;
        }

        public DateTime GetEodBusinessDate()
        {
            return DateTime.Now.Hour < _settings.EodEndTime ? DateTime.Now.AddDays(-1).Date : DateTime.Now.Date;
        }

        public void LogEvent(string resultKey, string context)
        {
            _logger.Debug(resultKey + " | " + context);

        }
        public void LogErrorEvent(string resultKey, string context)
        {
            _logger.Debug(resultKey + " | " + context);
        }

    }
}
