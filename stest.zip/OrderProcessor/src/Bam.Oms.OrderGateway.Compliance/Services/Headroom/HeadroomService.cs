﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.EventQ.Snapshot;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;
using Bam.Oms.OrderGateway.Compliance.Model.Snapshot;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public class HeadroomService : EventRelay<IMessage>, IHeadroomService, ISnapshotRecoverable<HeadroomRuleSnapshot>
    {
        private readonly IOrderEffectMediator _orderEffectMediator;
        private readonly IHeadroomEffectCache _headroomEffectCache;
        private readonly IModelIndex<HeadroomRule> _rules;
        private readonly IModelIndex<Order> _orders;
        private readonly HashSet<HeadroomKey> _newHeadroomKeys;
        private readonly HashSet<string> _removeHeadroomKey;
        private int _loadedCount;

        public HeadroomService(
            IIndexFactory index, 
            IOrderEffectMediator orderEffectMediator,
            IHeadroomEffectCache headroomEffectCache)
        {
            _orderEffectMediator = orderEffectMediator;
            _headroomEffectCache = headroomEffectCache;
            _rules = index.For<HeadroomRule>();
            _orders = index.For<Order>();
            _newHeadroomKeys = new HashSet<HeadroomKey>();
            _removeHeadroomKey = new HashSet<string>();
        }

        public ILogger Logger { get; set; }

        public void Load(HeadroomLoaded input)
        {
            OwnershipHeadroomChanged message = null;
            _newHeadroomKeys.Clear();
            _loadedCount = 0;

            Logger?.LogInformation($"Received {input.Items.Count} headroom rules.");

            int counter = 0;
            foreach (var item in input.Items)
            {
                if (item.Identifier == null)
                {
                    Logger?.LogError($"Received headroom for blank identifier; rule '{item.RuleName}' ({item.RuleId}).");
                    continue;
                }

                var headroomKey = new HeadroomKey(item.RuleId, item.Identifier);
                var direction = ConvertDirection(item.Side);
                var headroom = new Model.Headroom.Headroom(headroomKey, direction,
                    item.IsContingency, item.IsExempt);

                _newHeadroomKeys.Add(headroomKey);

                var rule = _rules.LookupBy(nameof(HeadroomRule.Id), item.RuleId);
                if (rule == null)
                {
                    rule = new HeadroomRule(item.RuleId);
                    _rules.Insert(rule);
                }

                rule.ApplyDetails(item.RuleName, item.Entity, direction,
                    ConvertIdentifierType(item.IdentifierType));
                rule.SetHeadroom(headroom);

                if (message == null)
                {
                    message = new OwnershipHeadroomChanged();
                }

                _loadedCount++;
                var messageItem = new OwnershipHeadroomChanged.Item
                {
                    RuleId = rule.Id,
                    RuleName = rule.Name,
                    Direction = rule.Direction.ToString(),
                    Identifier = headroom.Key.Identifier,
                    IdentifierType = rule.IdentifierType.ToString(),
                    ReportingEntity = item.Entity,
                    IsContingency = headroom.IsContingency,
                    IsExempt = item.IsExempt
                };

                item.Ratio.CopyTo(messageItem.Ratios);
                message.Items.Add(messageItem);

                List<HeadroomThreshold> thresholds = null;
                foreach (var itemHeadRoom in item.Headrooms)
                {
                    ComplianceViolationLevel violation;
                    if (!Enum.TryParse(itemHeadRoom.AlertLevel, false, out violation))
                    {
                        Logger?.LogError($"Unable to parse headroom compliance violation level '{itemHeadRoom.AlertLevel}'.");
                        continue;
                    }

                    if (thresholds == null)
                        thresholds = new List<HeadroomThreshold>();

                    var threshold = new HeadroomThreshold(violation, itemHeadRoom.Threshold,
                        itemHeadRoom.HeadRoom, itemHeadRoom.FireOnce);
                    thresholds.Add(threshold);

                    var thresholdItem = new OwnershipHeadroomChanged.HeadroomThreshold
                    {
                        AlertLevel = violation,
                        HeadRoom = itemHeadRoom.HeadRoom,
                        FireOnce = itemHeadRoom.FireOnce,
                        Threshold = itemHeadRoom.Threshold
                    };

                    messageItem.HeadRoomThresholds.Add(thresholdItem);
                }

                if (thresholds != null)
                {
                    headroom.ApplyStartOfDay(thresholds, item.Ratio);
                }

                counter += message.Items.Count;
                if (counter > 5000)
                {
                    Publish(message);
                    message = null;
                    counter = 0;
                }
            }

            if (message != null)
            {
                Publish(message);
            }

            Logger?.LogInformation($"Loaded {_loadedCount} headroom rules.");

            var orders = _orders.GetAll();
            // ReSharper disable once ForCanBeConvertedToForeach
            for (int i = 0; i < orders.Count; i++)
            {
                var order = orders[i];
                using (Attach(order))
                {
                    _orderEffectMediator.ApplyEffects(order);
                }
            }

            // remove all headrooms that do not exist in the new set if its an sod load
            if (input.IsWipeAndLoad)
            {
                var allRules = _rules.GetAll();
                foreach (var rule in allRules)
                {
                    _removeHeadroomKey.Clear();

                    foreach (var headroom in rule.Headrooms)
                    {
                        var key = new HeadroomKey(rule.Id, headroom.Key);
                        if (!_newHeadroomKeys.Contains(key))
                        {
                            _removeHeadroomKey.Add(headroom.Key);

                            foreach (var item in orders)
                            {
                                if (item.Security.FindUltimateUnderlying().Symbol == key.Identifier ||
                                    item.Security.FindUltimateUnderlying().Isin == key.Identifier)
                                {
                                    _headroomEffectCache.Reset(item.OrderId, rule.Id, key.Identifier);
                                }
                            }
                        }
                    }

                    if (_removeHeadroomKey.Count > 0)
                    {
                        using (Attach(rule))
                        {
                            rule.RemoveHeadroom(_removeHeadroomKey);
                        }
                    }

                    if (rule.Headrooms.Count == 0)
                        _rules.Remove(rule);
                }
            }
        }

        public void AdjustRatios(AdjustHeadroomRatios input)
        {
            var rule = _rules.LookupBy(nameof(HeadroomRule.Id), input.RuleId);
            if (rule == null)
            {
                Logger?.LogError($"Received headroom adjustment for unknown rule {input.RuleId}");
                return;
            }

            using (Attach(rule))
            {
                rule.AdjustRatios(input.Identifier, input.Ratios);
            }
        }

        private HeadroomDirection ConvertDirection(string direction)
        {
            return (HeadroomDirection)Enum.Parse(typeof(HeadroomDirection), direction, true);
        }

        private HeadroomIdentifierType ConvertIdentifierType(string type)
        {
            return "ISIN".Equals(type, StringComparison.OrdinalIgnoreCase)
                ? HeadroomIdentifierType.Isin
                : HeadroomIdentifierType.UnderlyingSymbol;
        }

        HeadroomRuleSnapshot ISnapshotRecoverable<HeadroomRuleSnapshot>.Persist()
        {
            var snapshot = new HeadroomRuleSnapshot();
            foreach (var rule in _rules.GetAll())
            {
                HeadroomRuleSnapshot.Item ruleSnap;
                snapshot.Items.Add(ruleSnap = new HeadroomRuleSnapshot.Item
                {
                    Id = rule.Id,
                    Name = rule.Name,
                    Direction = rule.Direction.ToString(),
                    IdentifierType = rule.IdentifierType.ToString(),
                    ReportingEntity = rule.ReportingEntity
                });

                foreach (var headroom in rule.Headrooms.Values)
                {
                    HeadroomRuleSnapshot.Item.Headroom headroomSnap;
                    ruleSnap.Headrooms.Add(headroomSnap = new HeadroomRuleSnapshot.Item.Headroom
                    {
                        Identifier = headroom.Key.Identifier,
                        IsContingency = headroom.IsContingency,
                        IsExempt = headroom.IsExempt
                    });

                    headroom.AggregationUnitRatios.CopyTo(headroomSnap.AggregationUnitRatios);

                    foreach (var threshold in headroom.Thresholds)
                    {
                        headroomSnap.Thresholds.Add(new HeadroomRuleSnapshot.Item.Headroom.HeadroomThreshold
                        {
                            Quantity = threshold.Quantity,
                            FireOnce = threshold.FireOnce,
                            Threshold = threshold.Threshold,
                            ViolationLevel = threshold.ViolationLevel.ToString()
                        });
                    }
                }
            }

            return snapshot;
        }

        void ISnapshotRecoverable<HeadroomRuleSnapshot>.Recover(HeadroomRuleSnapshot snapshot)
        {
            var msg = new HeadroomLoaded
            {
                Chunk = 1,
                TotalChunks = 1,
                IsWipeAndLoad = true
            };
            
            foreach (var ruleSnap in snapshot.Items)
            {
                foreach (var headroomSnap in ruleSnap.Headrooms)
                {
                    HeadroomLoaded.Item item;
                    msg.Items.Add(item = new HeadroomLoaded.Item
                    {
                        Side = ruleSnap.Direction,
                        RuleName = ruleSnap.Name,
                        IsExempt = headroomSnap.IsExempt,
                        Identifier = headroomSnap.Identifier,
                        RuleId = ruleSnap.Id,
                        Entity = ruleSnap.ReportingEntity,
                        IdentifierType = ruleSnap.IdentifierType,
                        IsContingency = headroomSnap.IsContingency
                    });

                    headroomSnap.AggregationUnitRatios.CopyTo(item.Ratio);

                    foreach (var thresholdSnap in headroomSnap.Thresholds)
                    {
                        item.Headrooms.Add(new HeadroomLoaded.Headroom
                        {
                            Threshold = thresholdSnap.Threshold,
                            AlertLevel = thresholdSnap.ViolationLevel,
                            FireOnce = thresholdSnap.FireOnce,
                            HeadRoom = thresholdSnap.Quantity
                        });
                    }
                }
            }

            Load(msg);
        }
    }
}
