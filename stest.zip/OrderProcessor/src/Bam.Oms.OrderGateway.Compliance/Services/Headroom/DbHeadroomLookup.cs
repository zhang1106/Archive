﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;
using Dapper;

namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public class DbHeadroomLookup : IDbHeadroomLookup
    {
        private readonly SqlConnection _connection;

        public DbHeadroomLookup(SqlConnection connection)
        {
            _connection = connection;
        }

        public List<HeadRoomDto> GetHeadroom(out DateTime businessDay)
        {
            businessDay = _connection.QueryFirstOrDefault<DateTime>("SELECT ISNULL(MAX(BusinessDate), '1/1/1900') FROM [og].[EodHeadroom]");
            if (businessDay.Year == 1900)
            {
                return new List<HeadRoomDto>();
            }

            return _connection.Query<HeadRoomDto>("SELECT * FROM [og].[EodHeadroom] WHERE [BusinessDate] = @TradeDate",
                new { TradeDate = businessDay }).ToList();
        }

        public List<HeadroomRatioDto> GetHeadroomRatios(DateTime businessDay)
        {
            return _connection.Query<HeadroomRatioDto>("SELECT * FROM [og].[EodHeadroomRatio] WHERE [BusinessDate] = @TradeDate",
                new {TradeDate = businessDay}).ToList();
        }
    }
}