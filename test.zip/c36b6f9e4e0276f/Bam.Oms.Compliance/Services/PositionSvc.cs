﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance.Services
{
    public class PositionSvc:IPositionSvc
    {
        private readonly IPositionProvider _positionProvider;
        private readonly ICustomDataProvider _customDataProvider;
        private readonly IDwRepository _dwRepository;
        private readonly ISecurityProvider _securityProvider;
        private readonly ISettings _settings;
        private readonly IHelper _helper;
        
        public PositionSvc(IPositionProvider positionProvider,
            ICustomDataProvider customDataProvider, IDwRepository dwRepository, ISecurityProvider securityProvider, ISettings settings, IHelper helper)
        {
            _positionProvider = positionProvider;
            _customDataProvider = customDataProvider;
            _dwRepository = dwRepository;
            _securityProvider = securityProvider;
            _settings = settings;
            _helper = helper;
        }

        public IEnumerable<FlatPosition> GetPositionsByUnderlying(PositionType type, string underlying)
        {
            var positions = _positionProvider.GetData(type, PositionIndex.Underlying);
            if(!positions.Contains(underlying)) return null;
                
            var transferPos = positions[underlying].Select(p => new FlatPosition()
            {
                BamSymbol = p.Security.BamSymbol,
                CompositeParent = p.ParentSymbol,
                Entity = _customDataProvider.GetEntity(p.Portfolio.ToString()),
                Isin = p.Security.Isin,
                Quantity = (long) (p.ActualSide == SideType.Short ? (-1)*p.ActualQuantity : p.ActualQuantity),
                SecurityType = p.Security.SecurityType.ToString(),
                Strategy = p.Portfolio.ToString(),
                UnderlyingSymbol = p.Security.UnderlyingSymbol
            });
            return transferPos;
        }

        public IEnumerable<FlatPosition> GetDecomposedPositionsByIsin(string isin, PositionType type, bool dumpToDb = false)
        {
            var time = DateTime.Now;
            var positions = _positionProvider.GetData(type, PositionIndex.Isin);
            if (!positions.Contains(isin)) return null;

            var transferPos = positions[isin].Select(p=>new FlatPosition()
                {
                    BamSymbol = p.Security.BamSymbol,
                    CompositeParent = p.ParentSymbol,
                    Entity = _customDataProvider.GetEntity(p.Portfolio.ToString()),
                    Isin = p.Security.Isin,
                    Quantity =  (long)(p.ActualSide== SideType.Short?(-1)*p.ActualQuantity:p.ActualQuantity),
                    SecurityType = p.Security.SecurityType.ToString(),
                    Strategy = p.Portfolio.ToString(),
                    UnderlyingSymbol = p.Security.UnderlyingSymbol,
                    TimeStamp = time
                }
            );

            return transferPos;
        }

        public IEnumerable<Constituent> GetConstituents(string symbol)
        {
            var constituents = _dwRepository.GetConstitents();
            if (constituents.Contains(symbol)) return constituents[symbol];
            var security = _securityProvider.GetSecurity(symbol);
            if (security == null) return null;
            return constituents.Contains(security.TrackIndexCode) ? constituents[security.TrackIndexCode] : null;
        }
    }
}
