﻿using System;
using Bam.Oms.Filtering;
using Bam.Oms.Compliance.DataProvider;

namespace Bam.Oms.Compliance.Filters
{
    public class ComplianceOperator : Operator
    {
        private readonly IFactProvider _factProvider;
        public ComplianceOperator(IFactProvider factProvider)
        {
            _factProvider = factProvider;
        }
        public override bool InTheList(IComparable item, IComparable factList)
        {
            if (item == null) return false;
            var list = _factProvider.GetList((string)factList);
            if (list == null) return false;
            var exist = list.Contains(item.ToString());
            return exist;
        }

        public override bool NotInTheList(IComparable item, IComparable factList)
        {
            var exist = InTheList(item, factList);
            return !exist;
        }
    }
}
