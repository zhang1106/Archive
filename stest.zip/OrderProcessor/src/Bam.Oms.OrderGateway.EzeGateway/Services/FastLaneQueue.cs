﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;

namespace Bam.Oms.OrderGateway.EzeGateway.Services
{
    public class FastLaneQueue<TItem> : IFastLaneQueue<TItem>
    {
        private readonly IFastLaneRules<TItem> _rules;
        private readonly LinkedList<TItem> _queued;
        private readonly LinkedList<TItem> _inFlight;
        private readonly LinkedList<TItem> _empty;
        private readonly AutoResetEvent _itemsAvailable;

        public FastLaneQueue(IFastLaneRules<TItem> rules)
        {
            _rules = rules;
            _queued = new LinkedList<TItem>();
            _inFlight = new LinkedList<TItem>();
            _empty = new LinkedList<TItem>();
            _itemsAvailable = new AutoResetEvent(false);
        }
        
        public int Count
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            get { return _queued.Count; }
        }

        public int InFlight
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            get { return _inFlight.Count; }
        }

        public WaitHandle ItemsAvailable => _itemsAvailable;

        [MethodImpl(MethodImplOptions.Synchronized)]
        public bool TryDequeue(bool fastLane, out TItem item)
        {
            var outer = new Iterator(_empty, _queued);
            while (outer.MoveNext())
            {
                var inner = new Iterator(_inFlight, _queued);

                bool blocked = fastLane && !_rules.CanUseFastLane(outer.Current.Value);
                while (inner.MoveNext() && !outer.Current.Equals(inner.Current))
                {
                    blocked |= !_rules.CanBypass(outer.Current.Value, inner.Current.Value);
                    if (blocked) break;
                }

                if (!blocked)
                {
                    _queued.Remove(outer.Current);
                    _inFlight.AddLast(outer.Current);
                    item = outer.Current.Value;
                    return true;
                }

                if (fastLane && inner.Current.List == _queued)
                {
                    _queued.Remove(inner.Current);
                    _inFlight.AddLast(inner.Current);
                    item = inner.Current.Value;
                    return true;
                }
            }

            item = default(TItem);
            return false;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public void Ack(TItem item)
        {
            _inFlight.Remove(item);
            if (_queued.Count > 0)
                _itemsAvailable.Set();
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public void Ack(IEnumerable<TItem> items)
        {
            foreach (var item in items)
            {
                _inFlight.Remove(item);
            }

            if (_queued.Count > 0)
                _itemsAvailable.Set();
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public void Enqueue(TItem item)
        {
            _queued.AddLast(item);
            _itemsAvailable.Set();
        }

        public struct Iterator : IEnumerator<LinkedListNode<TItem>>
        {
            private readonly LinkedList<TItem> _l1;
            private readonly LinkedList<TItem> _l2;
            private LinkedListNode<TItem> _current;

            public Iterator(LinkedList<TItem> l1, LinkedList<TItem> l2)
            {
                _l1 = l1;
                _l2 = l2;
                _current = null;
            }

            public void Dispose()
            {
                
            }

            public bool MoveNext()
            {
                if (_current == null)
                {
                    if (_l1.Count > 0)
                    {
                        _current = _l1.First;
                        return true;
                    }

                    if (_l2.Count > 0)
                    {
                        _current = _l2.First;
                        return true;
                    }

                    return false;
                }

                if (_current.Next == null && _current.List == _l1 && _l2.Count > 0)
                {
                    _current = _l2.First;
                    return true;
                }

                _current = _current.Next;
                return _current != null;
            }

            public void Reset()
            {
                _current = null;
            }

            public LinkedListNode<TItem> Current => _current;
            object IEnumerator.Current => _current;
        }
    }
}
