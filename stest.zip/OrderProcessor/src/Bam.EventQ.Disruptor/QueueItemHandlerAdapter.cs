﻿using Bam.EventQ.Queue;
using Disruptor;

namespace Bam.EventQ.Disruptor
{
    public class QueueItemHandlerAdapter<TItem> : IEventHandler<TItem>
    {
        private readonly IQueueItemHandler<TItem> _handler;

        public QueueItemHandlerAdapter(IQueueItemHandler<TItem> handler)
        {
            _handler = handler;
        }

        public void OnNext(TItem data, long sequence, bool endOfBatch)
        {
            _handler.Handle(data, sequence, endOfBatch);
        }
    }
}
