﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Bam.EventQ.Workflow
{
    public class WorkflowDispatcher<TIn, TOut> : IWorkflowDispatcher<TIn, TOut>
    {
        private readonly IWorkflowRepository _repository;

        private readonly Dictionary<Type, List<Func<TIn, long, bool, IReadOnlyList<TOut>>>> _compiledWorkflows
            = new Dictionary<Type, List<Func<TIn, long, bool, IReadOnlyList<TOut>>>>();

        private readonly TOut[] _emptyResult = new TOut[0];
        private readonly List<TOut> _combinedResult = new List<TOut>(256);

        public WorkflowDispatcher(IWorkflowRepository repository)
        {
            _repository = repository;
            CompileWorkflows();
        }

        public IReadOnlyList<TOut> Dispatch(TIn input, long sequence, bool isReplay)
        {
            List<Func<TIn, long, bool, IReadOnlyList<TOut>>> item;
            if (!_compiledWorkflows.TryGetValue(input.GetType(), out item) || item.Count == 0)
            {
                return _emptyResult;
            }

            if (item.Count == 1)
            {
                return item[0](input, sequence, isReplay);
            }

            _combinedResult.Clear();
            foreach (var func in item)
            {
                _combinedResult.AddRange(func(input, sequence, isReplay));
            }

            return _combinedResult;
        }

        private void CompileWorkflows()
        {
            foreach (var item in _repository.GetAll())
            {
                /*
                 * 
                 * IReadOnlyList<IMessage> ~(IMessage input, long sequence, bool isReplay)
                 * {
                 *     workflow.Reset(sequence, isReplay);
                 *     workflow.Execute((SubmitOrder) input);
                 *     return Convert<OrderSubmitted, IMessage>(workflow.Result);
                 * }
                 * 
                 */

                if (!typeof(TIn).IsAssignableFrom(item.Key))
                    continue;

                var outInterfaceType =
                    item.Value.GetType()
                        .GetInterfaces()
                        .SingleOrDefault(
                            it =>
                                it.IsGenericType &&
                                it.GetGenericTypeDefinition() == typeof(IWorkflow<,>) &&
                                it.GetGenericArguments()[0] == item.Key);

                var outputType = typeof(TOut);
                if (outInterfaceType != null)
                {
                    outputType = outInterfaceType.GetGenericArguments()[1];
                }

                if (!typeof(TOut).IsAssignableFrom(outputType))
                    continue;

                var untypedWf = Expression.Constant(item.Value);
                var inputParam = Expression.Parameter(typeof(TIn), "input");
                var sequenceParam = Expression.Parameter(typeof(long), "sequence");
                var replayParam = Expression.Parameter(typeof(bool), "isReplay");
                var typedInput = Expression.Convert(inputParam, item.Key);
                var typedWf = Expression.Convert(untypedWf, item.Value.GetType());

                var reset = Expression.Call(untypedWf, typeof(IWorkflow).GetMethod(nameof(IWorkflow.Reset)),
                    sequenceParam, replayParam);

                var execute = Expression.Call(typedWf,
                    item.Value.GetType().GetMethod(nameof(IWorkflow<TOut>.Execute), 
                    new[] {item.Key}), typedInput);

                Expression result;
                if (outInterfaceType != null)
                {
                    var outList =  new List<TOut>(1024);
                    var outListExpr = Expression.Constant(outList);

                    var convertMethod =
                        GetType()
                            .GetMethod(nameof(Convert), BindingFlags.Static | BindingFlags.Public)
                            .MakeGenericMethod(outputType, typeof(TOut));
                    result = Expression.Call(convertMethod,
                        Expression.Property(typedWf, nameof(IWorkflow<TIn, TOut>.Result)),
                        outListExpr);
                }
                else
                {
                    result = Expression.Constant(new TOut[] {}, typeof(IReadOnlyList<TOut>));
                }

                var block = Expression.Block(reset, execute, result);
                var lambda = Expression.Lambda<Func<TIn, long, bool, IReadOnlyList<TOut>>>(
                    block, inputParam, sequenceParam, replayParam);

                List<Func<TIn, long, bool, IReadOnlyList<TOut>>> entry;
                if (!_compiledWorkflows.TryGetValue(item.Key, out entry))
                {
                    entry = _compiledWorkflows[item.Key] = new List<Func<TIn, long, bool, IReadOnlyList<TOut>>>(2);
                }

                entry.Add(lambda.Compile());
            }
        }
        
        public static IReadOnlyList<T2> Convert<T1, T2>(IReadOnlyList<T1> input, List<T2> output)
        {
            output.Clear();
            for (int i = 0; i < input.Count; i++)
            {
                output.Add((T2) (object) input[i]);
            }

            return output;
        }
    }
}
