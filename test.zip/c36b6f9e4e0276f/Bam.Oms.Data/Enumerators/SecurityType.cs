﻿using System.Runtime.Serialization;

namespace Bam.Oms.Data.Enumerators
{
    [DataContract]
    public enum SecurityType
    {
        [EnumMember]
        [Enum(StringValue = "Unknown")]
        Unknown = 0,

        [EnumMember]
        [Enum(StringValue = "Equity")]
        Equity,

        [EnumMember]
        [Enum(StringValue = "Equity Option")]
        EquityOption,

        [EnumMember]
        [Enum(StringValue = "Equity Swap")]
        EquitySwap,

        [EnumMember]
        [Enum(StringValue = "Forward FX")]
        ForwardFx,

        [EnumMember]
        [Enum(StringValue = "Spot FX")]
        SpotFx,

        [EnumMember]
        [Enum(StringValue = "Future")]
        Future,

        [EnumMember]
        [Enum(StringValue = "Future Option")]
        FutureOption,

        [EnumMember]
        [Enum(StringValue = "FX Option")]
        FXOption,

        [EnumMember]
        [Enum(StringValue = "Bond")]
        Bond,

        [EnumMember]
        [Enum(StringValue = "Repo")]
        Repo,

        [EnumMember]
        [Enum(StringValue = "Equity ETF")]
        EquityETF,

        [EnumMember]
        [Enum(StringValue = "Equity Index")]
        EquityIndex,

        [EnumMember]
        [Enum(StringValue = "Equity Basket")]
        EquityBasket,

        [EnumMember]
        [Enum(StringValue = "Basket Swap")]
        BasketSwap,

        [EnumMember]
        [Enum(StringValue = "Basket Option")]
        BasketOption,

        [EnumMember]
        [Enum(StringValue = "Index Swap")]
        IndexSwap,

        [EnumMember]
        [Enum(StringValue = "Index Future")]
        IndexFuture,

        [EnumMember]
        [Enum(StringValue = "Equity ADR")]
        EquityADR,

        [EnumMember]
        [Enum(StringValue = "Equity Warrant And Right")]
        EquityWarrantRight
    }
}