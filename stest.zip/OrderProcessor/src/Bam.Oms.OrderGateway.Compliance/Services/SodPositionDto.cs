﻿using System;
using Bam.Oms.OrderGateway.Infrastructure;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class SodPositionDto
    {
        public class SodSecurityDto
        {
            public string BamSymbol { get; set; }
        }

        public SodSecurityDto Security { get; set; }
        public Portfolio Portfolio { get; set; }
        public string CustodianName { get; set; }
        public decimal ActualQuantity { get; set; }
        public string FundCode { get; set; }
        public string Stream { get; set; }
        public DateTime EntryDate { get; set; }
    }
}
