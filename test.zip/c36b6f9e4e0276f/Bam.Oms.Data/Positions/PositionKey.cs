﻿using System;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Data.Position
{
    public class PositionKey : IPositionKey
    {     
        public IPortfolio Portfolio { get; }
        public ISecurity Security { get; }
        
        public string CustodianAccount { get; }        

        public PositionKey(IPortfolio portfolio, ISecurity security, string custodianAccount)
        {
            Portfolio = portfolio;
            Security = security;
            CustodianAccount = CustodianAccount;
        }

        public int CompareTo(IPositionKey other)
        {
            return this.Portfolio.Equals(other.Portfolio) ? this.Security.Equals(other.Security) ? String.Compare(this.CustodianAccount, other.CustodianAccount, StringComparison.Ordinal) : this.Security.CompareTo(other.Security) : other.Portfolio.CompareTo(this.Portfolio);
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;

            var other = obj as IPositionKey;
            if (other == null)
                return false;

            return Portfolio.Equals(other.Portfolio)
                   && Security.Equals(other.Security)
                   && CustodianAccount.Equals(other.CustodianAccount);
        }

        public override int GetHashCode()
        {
            return unchecked(Portfolio.GetHashCode() * Security.GetHashCode() * CustodianAccount.GetHashCode());
        }

        public override string ToString()
        {
            return
                $"{Portfolio}:{Security}:{CustodianAccount}";
        }
    }
}
