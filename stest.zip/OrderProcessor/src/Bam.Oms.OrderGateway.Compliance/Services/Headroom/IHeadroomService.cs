﻿using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public interface IHeadroomService : IEventSource<IMessage>
    {
        void Load(HeadroomLoaded input);
        void AdjustRatios(AdjustHeadroomRatios input);
    }
}