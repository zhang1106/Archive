﻿using System.Collections.Generic;
using Bam.Oms.Data;

namespace Bam.Oms.EndPoints.Hub.Signals
{
    public interface IHubSignal<T> 
    {
        /// <summary>
        /// Sends a message to the underlying pub/sub component (Rabbit, SignalR, etc)
        /// </summary>
        /// <param name="items"></param>
        void SignalHub(IEnumerable<T> items);
    }
}