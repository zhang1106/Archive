﻿using Bam.Oms.Data;
using System.Collections.Generic;

namespace Bam.Oms.Persistence
{
    /// <summary>
    /// Contains DB related operations
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IDBRepository<T> : IRepository<T> where T : IPersistentItem
    {
        /// <summary>
        /// Inserts a record in DB table.
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        new T Save(T item);

        /// <summary>
        /// Inserts a set of records in DB table.
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        new IEnumerable<T> Save(IEnumerable<T> items);

        /// <summary>
        /// Removes the given item from DB table.
        /// </summary>
        /// <param name="item"></param>
        void Clear(T item);

        /// <summary>
        /// Updates the given record fields.
        /// </summary>
        /// <param name="item"></param>
        void Update(T item);

        /// <summary>
        /// Returns a record from Table with matching id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        T GetById(int id);

        /// <summary>
        /// Returns a set of records from table for the matching criteria.
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        IEnumerable<T> Get(string filter, object param);

        /// <summary>
        /// Returns a set of records from table for the matching criteria.
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        IEnumerable<T> Get(object param);

        /// <summary>
        /// Returns all records from the table.
        /// </summary>
        /// <returns></returns>
        IEnumerable<T> GetAll();
    }
}
