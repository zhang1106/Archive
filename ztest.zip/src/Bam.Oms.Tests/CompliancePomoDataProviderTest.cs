﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Runtime;
using Moq;
using NUnit.Framework;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class CompliancePomoDataProviderTest
    {
        private string _sampleJsonPomo;
        private const string TestSymbol = "ANTO LN";
        private const string TestOption = "ANTO LN  1/15/16 P51";
        private const string TestSwap = "ACA FP";
        private const string TestSwapCode = "ACA FP SWAP";
        private const string File = "pomoData.json";
        PomoDataProvider _pomoProvider;

        [SetUp]
        public void Setup()
        {
            //read file
            var Assm = Assembly.GetExecutingAssembly().CodeBase;
            var split = Assm.Split('/');
            var path = split[3] + @"\";
            for (var i = 4; i < split.Length - 1; i++)
                path = Path.Combine(path, split[i]);

            string testpath = Path.Combine(path, "TestData");
            using (
                var fStream = System.IO.File.Open(Path.Combine(testpath, File), FileMode.Open, FileAccess.Read,
                    FileShare.Read))
            {
                TextReader tr = new StreamReader(fStream);
                _sampleJsonPomo = tr.ReadToEnd();
            }
            //
           
            var jsonDataProvider = new Mock<IJsonDataProvider>();
            jsonDataProvider.Setup(n => n.GetDataInJson(It.IsAny<string>())).
                Returns(_sampleJsonPomo);

            var securityProvider = new Mock<ISecurityProvider>();
            securityProvider.Setup(n => n.RefreshData()).Verifiable();
            securityProvider.Setup(n => n.GetSecurity(TestSymbol)).
            Returns(new Security() { BamSymbol = TestSymbol, UnderlyingSymbol = TestSymbol, Country = "LN", Currency = "EUR", SecurityType = Data.Enumerators.SecurityType.Equity });
            securityProvider.Setup(n => n.GetSecurity(TestOption)).
            Returns(new Security() { BamSymbol = TestOption, UnderlyingSymbol = TestSymbol, Country = "LN", Currency = "EUR", OptionType=OptionType.Put, SecurityType= SecurityType.EquityOption, ContractSize=100 });
            securityProvider.Setup(n => n.GetSecurity(TestSwap)).
            Returns(new Security() { BamSymbol = TestSwap, UnderlyingSymbol = TestSwap, Country = "FP", Currency = "EUR",  SecurityType = SecurityType.Equity});
            securityProvider.Setup(n => n.GetSecurity(TestSwapCode)).
            Returns(new Security() { BamSymbol = TestSwapCode, UnderlyingSymbol = TestSwap, Country = "FP", Currency = "EUR", SecurityType = SecurityType.EquitySwap });

            _pomoProvider = new PomoDataProvider(jsonDataProvider.Object, securityProvider.Object);
            _pomoProvider.RefreshData();
        }

        [Test]
        public void TestPomoDataProviderDataRefresh()
        {
            //act
            _pomoProvider.RefreshData();
            //ass
            Assert.IsTrue(_pomoProvider.RefreshTime.ToUniversalTime() == DateTime.Parse("2015-12-15T13:21:37.3025966Z").ToUniversalTime());
        }

        [Test]
        public void TestPomoProviderGetSharesOutstanding()
        {
            //arr
            IMarketDataProvider mProvider = _pomoProvider;
            //act
            decimal? sharesOutstanding = mProvider.GetSharesOutstanding(TestSymbol);
            //ass
            Assert.IsTrue(sharesOutstanding == 985856700);
        }

        [Test]
        public void TestPomoProviderGetFirmWideLongQuantity()
        {
            //arr
            IIntradayPositionProvider pProvider = _pomoProvider;
            //act
            decimal? longQty = pProvider.GetFirmWideLongQuantity(TestSymbol).Item2;
            //ass
            Assert.IsTrue(longQty == 1397794);
        }
        
        [Test]
        public void TestPomoProviderGetFirmWideShortuantity()
        {
            //arr
            IIntradayPositionProvider pProvider = _pomoProvider;
            //act
            var shortInfo = pProvider.GetFirmWideShortQuantity(TestSymbol);
            var info = shortInfo.Item1;
            decimal? shortQty = shortInfo.Item2;
            //ass
            Assert.IsTrue(shortQty == 1387794);
        }

        [Test]
        public void TestPomoProviderGetFirmWideNetQuantity()
        {
            //arr
            IIntradayPositionProvider pProvider = _pomoProvider;
            //act
            decimal? netQty = pProvider.GetFirmWideNetQuantity(TestSymbol).Item2;
            //ass
            Assert.IsTrue(netQty == 10000);
        }

        [Test]
        public void TestPomoProviderGetFirmWideNetQuantityWithSwap()
        {
            //arr
            IIntradayPositionProvider pProvider = _pomoProvider;
            //act
            decimal? netQty = pProvider.GetFirmWideNetQuantity(TestSwap).Item2;
            //ass
            Assert.IsTrue(netQty == 3000);
        }

        [Test]
        public void TestPomoProviderGetUnderlying()
        {
            //arr
           IIntradayPositionProvider pProvider = _pomoProvider;
           //
           IEnumerable<ISecurity> underlyingPositions = pProvider.GetUnderlyingSecurities();
           //
           Assert.IsTrue(underlyingPositions.ToList().Count == 2);
        }
    }
}
