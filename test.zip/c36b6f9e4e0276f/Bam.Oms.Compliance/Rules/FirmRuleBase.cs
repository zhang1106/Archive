﻿using Newtonsoft.Json;
using System.Collections.Generic;
using Bam.Oms.Compliance.Filters;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Filtering;
using Bam.Oms.Data.Securities;
using Bam.Oms.Compliance.DataProvider;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.Rules
{
    public class FirmRuleBase : Rule<ICompliancePosition>
    {
        [JsonProperty]
        public IEnumerable<Parameter> FilterParams { get; set; }
        [JsonProperty]
        public Filter<ISecurity> SecurityFilter { get; set; }
        
        /// <summary>
        /// popudate json and convert filter or compliance filter
        /// </summary>
        public virtual void Init()
        {
               if (!string.IsNullOrWhiteSpace(ParamsInJson))
                {
                    JsonConvert.PopulateObject(ParamsInJson, this);
                }
                if (FilterParams != null)
                {
                    foreach (var p in FilterParams)
                    {
                        p.Operator = new ComplianceOperator(Container.Instance.Resolve<IFactProvider>()) { OperatorType = p.Operator.OperatorType };
                    }
                    SecurityFilter = new Filter<ISecurity>();
                    SecurityFilter.AddToFilter(this.GetType().FullName, FilterParams);
                }
        }
      
    }
}
