﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.PositionTracker;
using Bam.Oms.Service.Orders;
using Bam.Oms.ShortLocate;
using Bam.Oms.TradeMarker;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class OrderProcessorTests
    {
        [Test]
        public void VerifyRoutedSizeSet()
        {
            var order = new Order();
            order.Custodian = "CSPB";
            order.Security = new Security() {BamSymbol = "IBM"};
            order.Portfolio = new Portfolio("RLEW", "GENERALIST", "EMR");
            order.Size = 100;
            order.Side = SideType.Buy;
            order.ClientOrderId = "123";

            var orderMarker = new Mock<IOrderMarker>();
            orderMarker.Setup(r => r.MarkOrder(It.IsAny<IOrder>(), null)).Returns(new IOrder[] { order });

            // arrange
            var orderProcess = new OrderProcessorFacade(orderMarker.Object, new Mock<IPositionTracker>().Object,
                new Mock<IOrderRepository>().Object, new Mock<IShortLocateService>().Object, new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object);

            // act
            var unit = orderProcess.MarkAndPositionTrackProcessOrders(new[] {order}).ToList();

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.Count(), Is.EqualTo(1));
            Assert.That(unit[0].RoutedSize, Is.EqualTo(100));
        }

        [Test]
        public void VerifyRoutedSizeNotSetIfNolocate()
        {
            var order = new Order();
            order.Custodian = "CSPB";
            order.Security = new Security() { BamSymbol = "IBM" };
            order.Portfolio = new Portfolio("RLEW", "GENERALIST", "EMR");
            order.Size = 100;
            order.Side = SideType.SellShort;
            order.ClientOrderId = "123";

            order.Locate =  new List<Data.Orders.Locate>() { new Data.Orders.Locate() {PrimeBroker = "CSFB" } };

            var orderMarker = new Mock<IOrderMarker>();
            orderMarker.Setup(r => r.MarkOrder(It.IsAny<IOrder>(), null)).Returns(new IOrder[] { order });

            var locateResponse = new LocateResponse();
            locateResponse.OriginalRequest = new LocateRequest(order, "CSFB");
            locateResponse.OriginalRequest.Order.LocateStatus = LocateStatus.Denied;


            var locateSvc = new Mock<IShortLocateService>();
            locateSvc.Setup(l => l.RequestForInventory(It.IsAny<IEnumerable<ILocateRequest>>())).Returns(new[] { locateResponse });

            // arrange
            var orderProcess = new OrderProcessorFacade(orderMarker.Object, new Mock<IPositionTracker>().Object,
                new Mock<IOrderRepository>().Object, locateSvc.Object, new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object);

            // act
            var unit = orderProcess.MarkAndPositionTrackProcessOrders(new[] { order }).ToList();

            // assert
            Assert.That(unit.Count, Is.EqualTo(1));
            Assert.That(unit[0].RoutedSize, Is.EqualTo(0));
        }

        [Test]
        public void VerifyRoutedSizeSetWithLocate()
        {
            var order = new Order();
            order.Custodian = "CSPB";
            order.Security = new Security() { BamSymbol = "IBM" };
            order.Portfolio = new Portfolio("RLEW", "GENERALIST", "EMR");
            order.Size = 100;
            order.Side = SideType.SellShort;
            order.ClientOrderId = "123";

            order.Locate = new List<Data.Orders.Locate>() { new Data.Orders.Locate() {Size = 100, PrimeBroker = "CSFB"} };
            order.LocateStatus = LocateStatus.Filled;

            var orderMarker = new Mock<IOrderMarker>();
            orderMarker.Setup(r => r.MarkOrder(It.IsAny<IOrder>(), null)).Returns(new IOrder[] { order });

            var locateResponse = new LocateResponse();
            locateResponse.OriginalRequest = new LocateRequest(order, "CSFB");


            var locateSvc = new Mock<IShortLocateService>();
            locateSvc.Setup(l => l.RequestForInventory(It.IsAny<IEnumerable<LocateRequest>>())).Returns(new[] { locateResponse });

            // arrange
            var orderProcess = new OrderProcessorFacade(orderMarker.Object, new Mock<IPositionTracker>().Object,
                new Mock<IOrderRepository>().Object, locateSvc.Object, new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object);

            // act
            var unit = orderProcess.MarkAndPositionTrackProcessOrders(new[] { order }).ToList();

            // assert
            Assert.That(unit.Count, Is.EqualTo(1));
            Assert.That(unit[0].RoutedSize, Is.EqualTo(100));
        }

        [TestCase(SideType.Buy, 100d, 0d, LocateStatus.Denied,true)]
        [TestCase(SideType.Sell, 100d, 0d, LocateStatus.Denied, true)]
        [TestCase(SideType.Cover, 100d, 0d, LocateStatus.Denied, true)]
        [TestCase(SideType.SellShort, 0d, 0d, LocateStatus.Denied, true)]
        [TestCase(SideType.SellShort, 100d, 100d, LocateStatus.Filled, true)]
        [TestCase(SideType.SellShort, 90d, 90d, LocateStatus.Partial, true)]
        [TestCase(SideType.SellShort, 0d, 0d, LocateStatus.Partial, false )]
        public async void VerifyRouteOrder(SideType sideType, double routedSize, double located , LocateStatus locateStatus, bool isMarked)
        {
            // arrange
            var order = new Order();
            order.Security = new Security() { BamSymbol = "IBM" };
            order.Portfolio = new Portfolio("RLEW", "GENERALIST", "EMR");
            order.OrderStatus = isMarked ? BamOrderStatus.Marked : BamOrderStatus.New;
            order.Size = 100;
            order.Side = sideType;
            order.ClientOrderId = "123";

            order.Locate = new List<Data.Orders.Locate>() { new Data.Orders.Locate() {Size = (decimal)located ,PrimeBroker = "CSFB" } };
            order.LocateStatus = locateStatus;

            var repo = new Mock<IOrderRepository>();

            repo.Setup(r => r.Get(It.IsAny<string>())).Returns(order);

            var orderProcess = new OrderProcessorFacade(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object,
                repo.Object, new Mock<IShortLocateService>().Object, new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object);

            // act
            await orderProcess.RouteOrder("123");

            // assert
            Assert.That(order.RoutedSize, Is.EqualTo(routedSize));
        }

        [TestCase(SideType.Buy, 100d, 1, 0, 1)]
        [TestCase(SideType.Buy, 100d, 1, 1, 2)]
        [TestCase(SideType.Sell, 100d, 1, 0, 1)]
        [TestCase(SideType.Sell, 100d, 1, 1, 2)]
        public async void VerifyReplaceOrder(SideType sideType, double routedSize, int amendCount, int createNewCount, int markedOrderCount)
        {
            // arrange
            int actualAmends = 0;
            int actualCreate = 0;
            
            var order = new Order();
            order.OriginalOrderId = "456";
            order.Security = new Security() { BamSymbol = "IBM" };
            order.Portfolio = new Portfolio("RLEW", "GENERALIST", "EMR");
            order.OrderStatus = BamOrderStatus.Marked;
            order.Custodian = "CSFB";
            order.Size = 100;
            order.Side = sideType;
            order.ClientOrderId = "123";

            IList<ILocateResponse> shortResponses = new List<ILocateResponse>();

            IList<IOrder> markedOrders = null;

            if (markedOrderCount > 1)
            {
                var order0 = (Order) order.Clone();
                order0.ClientOrderId = "123Z1";
                order0.Size = order.Size - 10;
                order0.Side = sideType == SideType.Sell ? SideType.SellShort : SideType.Cover;
                order0.LocateStatus = sideType == SideType.Sell ? LocateStatus.Filled : (LocateStatus?) null;
                order.Size = 10;

                markedOrders = new IOrder[] {order, order0};

                shortResponses.Add(new LocateResponse() {OriginalRequest = new LocateRequest(order0, order0.Custodian) });
            }
            else
                markedOrders = new IOrder[] {order};

            var orderMarker = new Mock<IOrderMarker>();
            orderMarker.Setup(r => r.MarkOrder(It.IsAny<IOrder>(), null)).Returns(markedOrders);

            var router = new Mock<IEmsRouter>();
            router.Setup(r => r.SubmitOrders(It.IsAny<IEnumerable<IOrder>>(), It.IsAny<string>(),It.IsAny<bool>())).Callback<IEnumerable<IOrder>, string,bool>((c,s,b) => actualCreate = c.Count());
            router.Setup(r => r.AmendOrder(It.IsAny<IOrder>(), It.IsAny<string>(), It.IsAny<bool>())).Callback<IOrder, string, bool>((c, s, b) => actualAmends = 1);

            var shortSvc = new Mock<IShortLocateService>();
            shortSvc.Setup(r => r.RequestForInventory(It.IsAny<IEnumerable<LocateRequest>>())).Returns(shortResponses);

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get("456")).Returns(order);

            var orderProcess = new OrderProcessorFacade(orderMarker.Object, new Mock<IPositionTracker>().Object, repo.Object,
                shortSvc.Object, new Mock<ILogger>().Object, router.Object);
            
            // act
            await orderProcess.ProcessReplaceOrder(order);
    
            // assert
            Assert.That(actualCreate, Is.EqualTo(createNewCount));
            Assert.That(actualAmends, Is.EqualTo(amendCount));
        }

        [Test]
        public async void VerifyCancelOrderIdsSentToEms()
        {
            // arrange
            var cancelIds = new[] {"123"};
            IList<string> unit = null;

            var router = new Mock<IEmsRouter>();
            router.Setup(r => r.CancelOrders(It.IsAny<IList<string>>())).Callback<IList<string>>(c => unit = c);

            var orderProcess = new OrderProcessorFacade(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object,
                new Mock<IShortLocateService>().Object, new Mock<ILogger>().Object, router.Object);

            // act
            await orderProcess.ProcessCancelOrders(cancelIds);

            // assert
            Assert.That(unit, Is.Not.Null);
            Assert.That(unit.Contains("123"));
        }

        [Test]
        public async void VerifyInventoryFilledRoutes()
        {
            // arrange
            var unit = 0;

            var router = new Mock<IEmsRouter>();
            router.Setup(r => r.SubmitOrders(It.IsAny<IEnumerable<IOrder>>(), It.IsAny<string>(),It.IsAny<bool>())).Callback<IEnumerable<IOrder>, string,bool>((c, s,b) => unit = c.Count());

            var orderProcess = new OrderProcessorFacade(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object,
                new Mock<IShortLocateService>().Object, new Mock<ILogger>().Object, router.Object);

            // act
            await orderProcess.ShortLocateClient_InventoryFilled(new[] {new LocateResponse() {OriginalRequest = new LocateRequest(new Order(), "CSFB")},});

            // assert
            Assert.That(unit, Is.EqualTo(1));
        }

        [Test]
        public void VerifyNullValueInCtorThrows()
        {
            // assert
            Assert.Throws<ArgumentNullException>(() => new OrderProcessor(null, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object, new Mock<IShortLocateService>().Object,new Mock<ILogger>().Object,new Mock<IEmsRouter>().Object));
            Assert.Throws<ArgumentNullException>(() => new OrderProcessor(new Mock<IOrderMarker>().Object, null, new Mock<IOrderRepository>().Object, new Mock<IShortLocateService>().Object, new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object));
            Assert.Throws<ArgumentNullException>(() => new OrderProcessor(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, null, new Mock<IShortLocateService>().Object, new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object));
            Assert.Throws<ArgumentNullException>(() => new OrderProcessor(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object, null, new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object));
            Assert.Throws<ArgumentNullException>(() => new OrderProcessor(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object, new Mock<IShortLocateService>().Object, null, new Mock<IEmsRouter>().Object));
            Assert.Throws<ArgumentNullException>(() => new OrderProcessor(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object, new Mock<IShortLocateService>().Object, new Mock<ILogger>().Object, null));
        }

        [Test]
        public void VerifyFindMissingOrdersIgnoresMatch()
        {
            // arrange
            var orderOn = new Order();
            orderOn.ClientOrderId = "789";

            var orderOne = new Order();
            orderOne.ClientOrderId = "123";

            var orderTwo = new Order();
            orderTwo.ClientOrderId = "123";

            var gateway = new OrderProcessorFacade(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object, new Mock<IShortLocateService>().Object,
                new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object);

            // act
            var unit = gateway.FindMissingOrders(new[] { orderTwo }, new[] { orderOne, orderOn });

            // assert
            Assert.That(unit.Count(), Is.EqualTo(0));
        }

        [Test]
        public void VerifyFindMissingOrders()
        {
            // arrange
            var orderOn = new Order();
            orderOn.ClientOrderId = "789";

            var orderOne = new Order();
            orderOne.ClientOrderId = "123";

            var orderTwo = new Order();
            orderTwo.ClientOrderId = "123";
            orderTwo.Security = new Security() { BamSymbol = "IBM" };

            var gateway = new OrderProcessorFacade(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object, new Mock<IShortLocateService>().Object,
                new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object);

            // act
            var unit = gateway.RemoveUnknownOrders(new[] { orderTwo }, new[] { orderOne, orderOn });

            // assert
            Assert.That(unit.Count(), Is.EqualTo(1));
            Assert.That(unit.First().Security, Is.Not.Null);
            Assert.That(unit.First().Security.BamSymbol, Is.EqualTo("IBM"));
        }

        [Test]
        public void VerifyRemoveUnknownOrdersDropsOrders()
        {
            // arrange
            var orderOn = new Order();
            orderOn.ClientOrderId = "789";

            var orderOne = new Order();
            orderOne.ClientOrderId = "456";

            var orderTwo = new Order();
            orderTwo.ClientOrderId = "123";

            var gateway = new OrderProcessorFacade(new Mock<IOrderMarker>().Object, new Mock<IPositionTracker>().Object, new Mock<IOrderRepository>().Object, new Mock<IShortLocateService>().Object,
                new Mock<ILogger>().Object, new Mock<IEmsRouter>().Object);

            // act
            var unit = gateway.FindMissingOrders(new[] { orderTwo }, new[] { orderOne, orderOn });

            // assert
            Assert.That(unit.Count(), Is.EqualTo(1));
        }

        private class OrderProcessorFacade : OrderProcessor
        {
            public OrderProcessorFacade(IOrderMarker orderMarker, IPositionTracker positionTracker, IOrderRepository orderRepository, IShortLocateService shortLocateService, ILogger logger, IEmsRouter emsRouter) 
                : base(orderMarker, positionTracker, orderRepository, shortLocateService, logger, emsRouter)
            {
            }

            public new IEnumerable<IOrder> MarkAndPositionTrackProcessOrders(IEnumerable<IOrder> orders)
            {
                return base.MarkAndPositionTrackProcessOrders(orders);
            }

            public new Task ShortLocateClient_InventoryFilled(IList<ILocateResponse> filledResponses)
            {
                return base.ShortLocateClient_InventoryFilled(filledResponses);
            }

            public new IEnumerable<IOrder> FindMissingOrders(IEnumerable<IOrder> gatewayOrders, IEnumerable<IOrder> emsOrders)
            {
                return base.FindMissingOrders(gatewayOrders, emsOrders);
            }

            public new IEnumerable<IOrder> RemoveUnknownOrders(IEnumerable<IOrder> gatewayOrders, IEnumerable<IOrder> emsOrders)
            {
                return base.RemoveUnknownOrders(gatewayOrders, emsOrders);
            }
        }
    }
}


