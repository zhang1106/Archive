USE [OrderGateway]


DROP TABLE [og].[PmOrder]
DROP TABLE [og].[EodPosition]
DROP TABLE [og].[EmsOrder]
DROP TABLE [og].[EmsOrderAllocation]
DROP TABLE [og].[EmsOrderAllocationFee]


GO

/****** Object:  Table [og].[PmOrder]    Script Date: 11/10/2016 7:59:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [og].[PmOrder](
	[SetId] [int] NOT NULL,
	[Id] [bigint] NOT NULL,
	[Created] [datetime] NULL,
	[BusinessDay] [date] NULL,
	[SubmissionId] [varchar](100) NULL,
	[BatchId] [varchar](100) NULL,
	[BamSymbol] [varchar](100) NULL,
	[SecurityType] [varchar](100) NULL,
	[Portfolio] [varchar](100) NULL,
	[Notes] [varchar](max) NULL,
	[OrderType] [varchar](100) NULL,
	[LimitPrice] [decimal](18, 6) NULL,
	[Custodian] [varchar](100) NULL,
	[Trader] [varchar](100) NULL,
	[SettlementDate] [date] NULL,
	[SettlementCurrency] [varchar](100) NULL,
	[TradingCurrency] [varchar](100) NULL,
	[OrderStatus] [varchar](100) NULL,
	[Side] [varchar](100) NULL,
	[Quantity] [bigint] NULL,
	[FilledQuantity] [bigint] NULL,
	[ExternalId] [bigint] NULL,
	[ExecutionInstructions] [varchar](max) NULL,
	[OriginalId] [bigint] NULL,
	[OrderUrgency] [varchar](100) NULL,
	[TargetSubId] [varchar](100) NULL,
	[SenderSubId] [varbinary](100) NULL,
 CONSTRAINT [PK_PmOrder] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO





CREATE TABLE [og].[EodPosition](
	[BamSymbol] [VARCHAR](100) NOT NULL,
	[Quantity] [INT] NOT NULL,
	[Portfolio] [VARCHAR](100) NOT NULL,
	[Fund] [VARCHAR](100) NOT NULL,
	[Custodian] [VARCHAR](100) NOT NULL,
	[TradeDate] [DATE] NOT NULL,
	[SysDate] [DATETIME] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [og].[EodPosition] ADD  DEFAULT (GETDATE()) FOR [SysDate]
GO




CREATE TABLE [og].[EmsOrder](
	[SetId] [int] NOT NULL,
	[Id] [bigint] NOT NULL,
	[BusinessDay] [date] NULL,
	[BamSymbol] [varchar](100) NULL,
	[SecurityType] [varchar](100) NULL,
	[OrderType] [varchar](100) NULL,
	[LimitPrice] [decimal](18, 6) NULL,
	[Custodian] [varchar](100) NULL,
	[Trader] [varchar](100) NULL,
	[SettlementDate] [date] NULL,
	[SettlementCurrency] [varchar](100) NULL,
	[TradingCurrency] [varchar](100) NULL,
	[OrderStatus] [varchar](100) NULL,
	[Side] [varchar](100) NULL,
	[Quantity] [bigint] NULL,
	[ExecutionInstructions] [varchar](max) NULL,
	[OriginalId] [bigint] NULL,
	[OrderUrgency] [varchar](100) NULL,
	[TargetSubId] [varchar](100) NULL,
	[SenderSubId] [varbinary](100) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


CREATE TABLE [og].[EmsOrderAllocation](
	[Id] [INT] IDENTITY(1,1) NOT NULL,
	[EmsOrderId] [BIGINT] NOT NULL,
	[Quantity] bigint NULL,
	[WeightedAveragePrice] [DECIMAL](18, 6) NULL,
	[Fund] [VARCHAR](100) NULL,
	[Custodian] [VARCHAR](100) NULL,
	[ExecutionBroker] [VARCHAR](100) NULL,
	[Commissions] [DECIMAL](18, 6) NULL,
 CONSTRAINT [PK_EmsOrderAllocation] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


CREATE TABLE [og].[EmsOrderAllocationFee](
	[Id] [INT] IDENTITY(1,1) NOT NULL,
	[EmsOrderId] [BIGINT] NOT NULL,
	[Category] [VARCHAR](50) NULL,
	[Fee] [DECIMAL](18, 6) NULL,
 CONSTRAINT [PK_EmsOrderAllocationFee] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


