﻿using System;
using System.Linq;
using System.Collections.Generic;
using Bam.Oms.EndPoints.Http;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.EndPoints.Compliance
{
    public class RuleResultController : BaseController
    {
        private readonly IRuleResultRepository _ruleResultRepository;
        public RuleResultController(IRuleResultRepository ruleResultRepository, IHostConfiguration hostConfiguration, ILogger logger)
            : base(hostConfiguration, logger)
        {
            _ruleResultRepository = ruleResultRepository;
        }

        [AccessRequire("Function.OrderGateway.Compliance.Read. Function.OrderGateway.Compliance.Write")]
        public IList<RuleResult> Get()
        {
            return Get(null);
        }

        [AccessRequire("Function.OrderGateway.Compliance.Read, Function.OrderGateway.Compliance.Write")]
        public List<RuleResult> Get(DateTime? cutoffTime)
        {
            cutoffTime = cutoffTime?.ToUniversalTime() ?? DateTime.Today.ToUniversalTime();
            var results = _ruleResultRepository.Get(cutoffTime.GetValueOrDefault()).ToList();
            return results;
        }
    }
}
