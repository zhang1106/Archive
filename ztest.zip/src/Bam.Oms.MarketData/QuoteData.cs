﻿using Bam.Oms.Data;
using Bam.Oms.MarketData.Enumerators;

namespace Bam.Oms.MarketData
{
    public class QuoteData
    {
        public QuoteData(string securityId, SecurityIdSource securityIdSource, string mdEntryTime, double bidPx, double bidSize, double offerPx, double offerSize, double lastPx, double tradeVolume, double change)
        {
            SecurityId = securityId;
            SecurityIdSource = securityIdSource;
            MdEntryTime = mdEntryTime;
            BidPx = bidPx;
            BidSize = bidSize;
            OfferPx = offerPx;
            OfferSize = offerSize;
            LastPx = lastPx;
            TradeVolume = tradeVolume;
            Change = change;
        }

        public string SecurityId { get; }
        public SecurityIdSource SecurityIdSource { get; }

        public string MdEntryTime { get; }

        public double BidPx { get; }
        public double BidSize { get; }
        public double OfferPx { get; }
        public double OfferSize { get; }
        public double LastPx { get; }
        public double TradeVolume { get; }
        public double Change { get; }

        public override string ToString()
        {
            return
                $"SecurityId:{SecurityId};SecurityIdSource:{Utility.GetStringFromEnumAttribute(SecurityIdSource)};EntryTime:{MdEntryTime};Bid:{BidPx}@{BidPx}:Ask:{OfferSize}@{OfferPx};Last:{LastPx};TradeVolume:{TradeVolume}";
        }        
    }
}
