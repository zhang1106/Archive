﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web.Http;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class OrderScalingController : ApiController
    {
        private readonly ICache<int, OrderScalingRule> _cache;
        private readonly IOrderSubmission _orderSubmission;

        public OrderScalingController(
            ICache<int, OrderScalingRule> cache,
            IOrderSubmission orderSubmission)
        {
            _cache = cache;
            _orderSubmission = orderSubmission;
        }

        public ILogger Logger { get; set; }

        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public List<OrderScalingRule> Get()
        {
            using (_cache.AcquireReadAccess())
            {
                return _cache.GetItems().ToList();
            }
        }

        [HttpPatch]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public void Activate(int id)
        {
            Logger.LogInformation($"{User.GetLogin()} activated order scaling rule {id}");
            _orderSubmission.ToggleOrderScalingRule(id, true, RequestContext.Principal.Identity.Name);
        }

        [HttpPatch]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public void Deactivate(int id)
        {
            Logger.LogInformation($"{User.GetLogin()} deactivated order scaling rule {id}");
            _orderSubmission.ToggleOrderScalingRule(id, false, RequestContext.Principal.Identity.Name);
        }
    }
}
