﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data;

namespace Bam.Oms.Persistence
{
    public class PositionRepository : PersistentRepository<IPosition>, IP
    {
        
    }
}
