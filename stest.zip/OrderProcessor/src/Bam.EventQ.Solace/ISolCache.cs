﻿using System.Threading.Tasks;

namespace Bam.EventQ.Solace
{
    public interface ISolCache
    {
        Task<bool> FlushAsync(string topic);
    }
}
