﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Contingency;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.PositionTracker;
using Bam.Oms.SodPosition.Svc;
using Bam.Oms.TradeMarker;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class OrderMarkerTests
    {
        [TestCase(SideType.Long, 100d, SideType.Long, 50d, SideType.Buy, 50.0d, 1, SideType.Buy, 50d, SideType.Unknown, 0d)] // UC:2 Basic PM,Firm,Order All long 
        [TestCase(SideType.Long, 100d, SideType.Long, 50d, SideType.Sell, 50.0d, 1, SideType.Sell, 50d, SideType.Unknown, 0d)] //UC:1 Basic, PM,Firm Long and 
        [TestCase(SideType.Long, 100d, SideType.Long, 500d, SideType.Sell, 150.0d, 2, SideType.Sell, 100d, SideType.SellShort, 50d)] //UC:3
        [TestCase(SideType.Long, 100d, SideType.Short, -500d, SideType.Sell, 50.0d, 1, SideType.SellShort, 50d, SideType.Unknown, 0d)] //UC:4.1
        [TestCase(SideType.Long, 100d, SideType.Short, -50d, SideType.Sell, 75.0d, 2, SideType.Sell, 50d, SideType.SellShort, 25d)] //UC:6.2
        [TestCase(SideType.Long, 100d, SideType.Short, -150d, SideType.Buy, 50.0d, 1, SideType.Buy, 50d, SideType.Unknown, 0d)] //UC:5 Special case for Geneva, cannot send cover when PM is long
        [TestCase(SideType.Long, 100d, SideType.Short, -500d, SideType.Sell, 100d, 1, SideType.SellShort, 100d, SideType.Unknown, 0d)]//UC:6.1
        [TestCase(SideType.Long, 100d, SideType.Long, 150d, SideType.Sell, 300d, 2, SideType.Sell, 100d, SideType.SellShort, 200d)]//UC:6.2                
        [TestCase(SideType.Long, 100d, SideType.Short, -500d, SideType.Sell, 150d, 1, SideType.SellShort, 150d, SideType.Unknown, 0d)]//UC:6.1
        [TestCase(SideType.Long, 500d, SideType.Short, -100d, SideType.Sell, 50d, 1, SideType.Sell, 50d, SideType.Unknown, 0d)]//UC:1 
        [TestCase(SideType.Long, 500d, SideType.Short, -200d, SideType.Sell, 350d, 2, SideType.Sell, 300d, SideType.SellShort, 50d)]//UC: 
        [TestCase(SideType.Long, 500d, SideType.Short, -100d, SideType.Sell, 450d, 2, SideType.Sell, 400d, SideType.SellShort, 50d)] //UC:4.2
        [TestCase(SideType.Short, -100d, SideType.Long, 500d, SideType.Sell, 150d, 1, SideType.SellShort, 150d, SideType.Unknown, 0d)] //UC:8 Short,Long,Sell order
        [TestCase(SideType.Short, -100d, SideType.Long, 500d, SideType.SellShort, 150d, 1, SideType.SellShort, 150d, SideType.Unknown, 0d)] //UC:8 Short,Long,Sell order
        [TestCase(SideType.Short, -100d, SideType.Long, 500d, SideType.SellShort, 600d, 1, SideType.SellShort, 600d, SideType.Unknown, 0d)] //UC:8 Short,Long,Sell order
        [TestCase(SideType.Short, -100d, SideType.Short, -500d, SideType.Sell, 150d, 1, SideType.SellShort, 150d, SideType.Unknown, 0d)] //UC:11 Short,Short,Sell order
        [TestCase(SideType.Short, -2080d, SideType.Long, 3480d, SideType.Sell, 100d, 1, SideType.SellShort, 100d, SideType.Unknown, 0d)] //UC:8 Short,Long,Sell order
        [TestCase(SideType.Short, -800d, SideType.Long, 800d, SideType.Sell, 100d, 1, SideType.SellShort, 100d, SideType.Unknown, 0d)] // UC:11 Short,Flat,Sell order
        [TestCase(SideType.Long, 800d, SideType.Short, -800d, SideType.Sell, 100d, 1, SideType.SellShort, 100d, SideType.Unknown, 0d)] //UC:4.1 Long,Flat,Sell order
        [TestCase(SideType.Long, 200d, SideType.Short, -300d, SideType.Sell, 500d, 1, SideType.SellShort, 500d, SideType.Unknown, 0d)] //UC:6.1 Long,Short,Sell order
        [TestCase(SideType.Short, -820d, SideType.Long, 200d, SideType.SellShort, 1380d, 1, SideType.SellShort, 1380d, SideType.Unknown, 0d)] //UC:11 Short,Short,Short order        
        [TestCase(SideType.Short, -500d, SideType.Long, 700d, SideType.Buy, 100d, 1, SideType.Cover, 100d, SideType.Unknown, 0d)]//UC:7.1,10.1 Short,Long,Buy Order
        [TestCase(SideType.Short, -500d, SideType.Long, 700d, SideType.Buy, 600d, 2, SideType.Cover, 500d, SideType.Buy, 100d)]//UC:9.1,12 Short,Long,Buy Order
        [TestCase(SideType.Short, -400d, SideType.Long, 950d, SideType.Buy, 1000d, 2, SideType.Cover, 400d, SideType.Buy, 600d)]//
        [TestCase(SideType.Long, 2000d, SideType.Short, -1000d, SideType.Sell, 5000d, 2, SideType.Sell, 1000d, SideType.SellShort, 4000d)]//
        [TestCase(SideType.Long, 2570, SideType.Short, -500d, SideType.Sell, 2570d, 2, SideType.Sell, 2070d, SideType.SellShort, 500)]//
        [TestCase(SideType.Long, 2570, SideType.Short, -500d, SideType.Sell, 2570d, 2, SideType.Sell, 2070d, SideType.SellShort, 500)]//
        [Test]
        public void TestMarkOrders(SideType position1Side, double position1Size, SideType position2Side, double position2Size, SideType orderSide, double orderQuantity, int numOrders, SideType expectedOrder1Side, double expectedOrder1Size, SideType expectedOrder2Side, double expectedOrder2Size)
        {
            IPortfolio portfolio1 = Portfolio.Parse("MYPORT1-MYSTRATEGY1-MYSUBSTRATEGY1");
            Security security1 = new Security() { BamSymbol = "IBM Equity" };
            string primeBroker = "CSFB";

            IPortfolio portfolio2 = Portfolio.Parse("MYPORT2-MYSTRATEGY2-MYSUBSTRATEGY2");
            Security security2 = new Security() { BamSymbol = "IBM Equity" };

            Mock<IPosition> position1 = new Mock<IPosition>();
            position1.SetupGet(pos => pos.Portfolio).Returns((Portfolio)portfolio1);
            position1.SetupGet(pos => pos.Security).Returns(security1);
            position1.SetupGet(pos => pos.TheoreticalQuantity).Returns(Convert.ToDecimal(position1Size));
            position1.SetupGet(pos => pos.ActualQuantity).Returns(Convert.ToDecimal(position1Size));
            position1.SetupGet(pos => pos.ShortMarkingQuantity).Returns(Convert.ToDecimal(position1Size));
            position1.Setup(pos => pos.Clone()).Returns(position1.Object);

            Mock<IPosition> position2 = new Mock<IPosition>();
            position2.SetupGet(pos => pos.Portfolio).Returns((Portfolio)portfolio2);
            position2.SetupGet(pos => pos.Security).Returns(security1);
            position2.SetupGet(pos => pos.TheoreticalQuantity).Returns(Convert.ToDecimal(position2Size));
            position2.SetupGet(pos => pos.ActualQuantity).Returns(Convert.ToDecimal(position2Size));
            position2.SetupGet(pos => pos.ShortMarkingQuantity).Returns(Convert.ToDecimal(position2Size));
            position2.Setup(pos => pos.Clone()).Returns(position2.Object);

            IPosition finalPosition = new Position(portfolio1, security1, primeBroker);
            finalPosition.ActualQuantity = 0;
            finalPosition.TheoreticalQuantity = 0;
            finalPosition.ShortMarkingQuantity = 0;
            position1.Setup(pos => pos.Clone()).Returns(finalPosition);


            var order = new Order() { ClientOrderId = "1234", Portfolio = (Portfolio)portfolio1, Security = security1, Size = Convert.ToDecimal(orderQuantity), Side = orderSide };

            IList<IPosition> positionCollection = new List<IPosition>();
            positionCollection.Add(position1.Object);
            positionCollection.Add(position2.Object);

            Mock<IPositionTracker> positionTracker = new Mock<IPositionTracker>();
            Mock<ILogger> logger = new Mock<ILogger>();
            positionTracker.Setup(pt => pt.GetCurrentPositions()).Returns(positionCollection);

            decimal netPosition = Convert.ToDecimal(position1Size + position2Size);
            decimal shortMarkingPosition = Convert.ToDecimal(position1Size);
            decimal longMarkingPosition = Convert.ToDecimal(position1Size);

            var positionSet1 = new PositionSet
            {
                Position = position1.Object,
                CompliancePosition = new CompliancePosition
                {
                    ShortMarkingQuantity = shortMarkingPosition,
                    LongMarkingQuantity = longMarkingPosition
                },
                AggUnitPosition = new AggUnitPosition
                {
                    ShortMarkingQuantity = netPosition
                }
            };

            var positionSet2 = new PositionSet
            {
                Position = position2.Object,
                CompliancePosition = new CompliancePosition
                {
                    ShortMarkingQuantity = shortMarkingPosition,
                    LongMarkingQuantity = longMarkingPosition
                },
                AggUnitPosition = new AggUnitPosition
                {
                    ShortMarkingQuantity = netPosition
                }
            };

            var positionSets = new[] { positionSet1, positionSet2 };

            var positionRepository = new Mock<IPositionRepository>();
            positionRepository.Setup(r => r.Get(It.IsAny<IReadOnlyList<PositionKey>>()))
                .Returns(positionSets);

            IOrderMarker orderMarker = new OrderMarker(logger.Object, new Mock<IClientOrderIdRepository>().Object, new Mock<ILoggingAgent>().Object);
            IEnumerable<IOrder> orders = orderMarker.MarkOrder(order, positionSet1);

            Assert.True(orders.ToList().Count == numOrders);
            Assert.AreEqual(Convert.ToDecimal(expectedOrder1Size), orders.First().Size);
            Assert.AreEqual(expectedOrder1Side, orders.First().Side);

            if (numOrders == 2)
            {
                Assert.AreEqual(Convert.ToDecimal(expectedOrder2Size), orders.Last().Size);
                Assert.AreEqual(expectedOrder2Side, orders.Last().Side);
            }
        }

        [Test]
        public void TestOrderSequenceCoverAndBuyOnComplianceGroupShortLessThanFirmShort()
        {
            IPortfolio portfolio1 = Portfolio.Parse("MYPORT1-MYSTRATEGY1-MYSUBSTRATEGY1");
            portfolio1.ComplianceGroup = "EGR";
            portfolio1.AggregationUnit = "AQTF";

            Security security1 = new Security() { BamSymbol = "IBM Equity" };

            IPortfolio portfolio2 = Portfolio.Parse("MYPORT2-MYSTRATEGY2-MYSUBSTRATEGY2");
            portfolio2.ComplianceGroup = "EGR";
            portfolio2.AggregationUnit = "AQTF";

            Security security2 = new Security() { BamSymbol = "IBM Equity" };
            string primeBroker = "CSFB";

            Mock<IPosition> position1 = new Mock<IPosition>();
            position1.SetupGet(pos => pos.Portfolio).Returns((Portfolio)portfolio1);
            position1.SetupGet(pos => pos.Security).Returns(security1);
            position1.SetupGet(pos => pos.TheoreticalQuantity).Returns(Convert.ToDecimal(-2510));
            position1.SetupGet(pos => pos.ActualQuantity).Returns(Convert.ToDecimal(-2510));
            position1.SetupGet(pos => pos.ShortMarkingQuantity).Returns(Convert.ToDecimal(-2510));
            position1.Setup(pos => pos.Clone()).Returns(position1.Object);

            Mock<IPosition> position2 = new Mock<IPosition>();
            position2.SetupGet(pos => pos.Portfolio).Returns((Portfolio)portfolio2);
            position2.SetupGet(pos => pos.Security).Returns(security1);
            position2.SetupGet(pos => pos.TheoreticalQuantity).Returns(Convert.ToDecimal(-17476));
            position2.SetupGet(pos => pos.ActualQuantity).Returns(Convert.ToDecimal(-17476));
            position2.SetupGet(pos => pos.ShortMarkingQuantity).Returns(Convert.ToDecimal(-17476));
            position2.Setup(pos => pos.Clone()).Returns(position2.Object);

            IPosition finalPosition = new Position(portfolio1, security1, primeBroker);
            finalPosition.ActualQuantity = 0;
            finalPosition.TheoreticalQuantity = 0;
            finalPosition.ShortMarkingQuantity = 0;
            position1.Setup(pos => pos.Clone()).Returns(finalPosition);


            var order1 = new Order() { ClientOrderId = "1234", Portfolio = (Portfolio)portfolio1, Security = security1, Size = Convert.ToDecimal(2510), Side = SideType.Cover };
            var order2 = new Order() { ClientOrderId = "1234", Portfolio = (Portfolio)portfolio1, Security = security1, Size = Convert.ToDecimal(25000), Side = SideType.Buy };

            IList<IPosition> positionCollection = new List<IPosition>();
            positionCollection.Add(position1.Object);
            positionCollection.Add(position2.Object);

            Position sodPosition1 = new Position(portfolio1, security1, primeBroker)
            {
                TheoreticalQuantity = -2510,
                ActualQuantity = -2510,
                ShortMarkingQuantity = -2510,
                Price = Convert.ToDecimal(1.0)
            };

            Position sodPosition2 = new Position(portfolio2, security1, primeBroker)
            {
                TheoreticalQuantity = -17476,
                ActualQuantity = -17476,
                ShortMarkingQuantity = -17476,
                Price = Convert.ToDecimal(1.0)
            };

            IList<IPosition> sodPositions = new List<IPosition>();
            sodPositions.Add(sodPosition1);
            sodPositions.Add(sodPosition2);

            var tradeList = new Dictionary<IPositionKey, IList<IBlockTrade>>();
            Mock<ITradeRepository> tradeRepository = new Mock<ITradeRepository>();
            tradeRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IBlockTrade>(null);
            tradeRepository.Setup(rep => rep.GetAllTrades(null)).Returns(tradeList);

            var orderList = new Dictionary<IPositionKey, IList<IOrder>>();
            Mock<IOrderRepository> orderRepository = new Mock<IOrderRepository>();
            orderRepository.Setup(rep => rep.Get(It.IsAny<string>())).Returns<IOrder>(null);
            orderRepository.Setup(rep => rep.GetAllOrders(null)).Returns(orderList);

            Mock<ISodPositionEdit> sodLoader = new Mock<ISodPositionEdit>();
            sodLoader.Setup(rep => rep.GetPositions(It.IsAny<DateTime?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(sodPositions);

            var effectsCalculator = new PositionEffectCalculator();
            var sodCalculator = new StartOfDayPositionCalculator(effectsCalculator, new Mock<ILogger>().Object);

            Mock<IPositionRepository> positionRepository = new Mock<IPositionRepository>();

            using (
                PositionTracker.PositionTracker positionTracker =
                    new PositionTracker.PositionTracker(effectsCalculator, sodCalculator,
                        positionRepository.Object,
                        tradeRepository.Object, orderRepository.Object,
                        new Mock<IContingencyDbRepository>().Object, new Mock<ILogger>().Object))
            {
                positionTracker.LoadSODPositions(sodPositions, orderList, tradeList);
                IOrderMarker orderMarker = new OrderMarker(new Mock<ILogger>().Object,
                    new Mock<IClientOrderIdRepository>().Object, new Mock<ILoggingAgent>().Object);
                IEnumerable<IOrder> orders1 = orderMarker.MarkOrder(
                    order1, new PositionSet
                    {
                        Position = position1.Object,
                        CompliancePosition = new CompliancePosition
                        {
                            ShortMarkingQuantity = position1.Object.ShortMarkingQuantity,
                            LongMarkingQuantity = position1.Object.LongMarkingQuantity
                        },
                        AggUnitPosition = new AggUnitPosition
                        {
                            ShortMarkingQuantity = position1.Object.ShortMarkingQuantity
                        }
                    });

                Assert.True(orders1.ToList().Count == 1);
                Assert.AreEqual(order1, orders1.First());

                //TODO: Rohit to research further on what the correct behaviour should be
                //IEnumerable<IOrder> orders2 = orderMarker.MarkOrder(order2);
                //Assert.True(orders2.ToList().Count == 1);
                //Assert.AreEqual(order2, orders2.First());
            }
        }
    }
}
