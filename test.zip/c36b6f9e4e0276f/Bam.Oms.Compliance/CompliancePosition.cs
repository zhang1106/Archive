﻿using BAM.Infrastructure.Ioc;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance
{
    public class CompliancePosition : ICompliancePosition
    {
        public CompliancePosition(IFactProvider factProvider,  
            IPositionProvider positionProvider,
            IOwnershipRuleResultProvider ruleResultProvider, ISecurityProvider securityProvider,
            IMarketDataProvider marketDataProvider,   ICustomDataProvider customDataProvider,
            IRuleResultRepository ruleResultRepository,
            ILogger logger, IHelper helper)
        {
            FactProvider = factProvider;
            PositionProvider = positionProvider;
            RuleResultProvider = ruleResultProvider;
            SecurityProvider = securityProvider;
            MarketDataProvider = marketDataProvider;
            CustomDataProvider = customDataProvider;
            RuleResultRepository = ruleResultRepository;
            Logger = logger;
            Helper = helper;
        }

        public ICompliancePosition Init(ISecurity security, IPolicy<ICompliancePosition> policy, PositionType type)
        {
            Security = security;
            Policy = policy;
            PositionType = type;
            return this;
        }
        public string  UnderlyingSymbol => Security.SecurityType == SecurityType.EquityADR ? Security.AdrCode : Security.BamSymbol;
          
        public string BamSymbol => Security.BamSymbol;
        public int PolicyId => Policy.Id;
        public IPolicy<ICompliancePosition> Policy { get; set; }
        public ISecurity Security { get; set; }
        public PositionType PositionType { get; set; }

        public IFactProvider FactProvider { get; }

        public IPositionProvider PositionProvider { get; }

        public IOwnershipRuleResultProvider RuleResultProvider { get; }

        public ISecurityProvider SecurityProvider { get; }

        public IMarketDataProvider MarketDataProvider { get; }
        
        public ICustomDataProvider CustomDataProvider { get; }

        public IRuleResultRepository RuleResultRepository { get; }

        public ILogger Logger { get; }

        public IHelper Helper { get; }
    }
}
