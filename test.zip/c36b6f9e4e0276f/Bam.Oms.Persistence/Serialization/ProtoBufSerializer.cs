﻿using System;
using System.IO;
using System.Linq.Expressions;
using System.Runtime.Serialization;
using Bam.Oms.Data.Compliance;
using ProtoBuf.Meta;

namespace Bam.Oms.Persistence.Serialization
{
    public class ProtoBufSerializer : ISerializer
    {
        private readonly TypeModel _typeModel;

        public ProtoBufSerializer(Action<RuntimeTypeModel> additionalTypeModelRegistrations = null)
        {
            _typeModel = CreateTypeModel(additionalTypeModelRegistrations);
        }

        public byte[] Serialize<T>(T item)
        {
            using (var ms = new MemoryStream())
            {
                _typeModel.Serialize(ms, item);
                return ms.ToArray();
            }
        }

        public T Deserialize<T>(byte[] input)
        {
            return Deserialize<T>(input, 0, input.Length);
        }

        public T Deserialize<T>(byte[] input, int startIndex, int length)
        {
            return (T)Deserialize(input, startIndex, length, typeof(T));
        }

        public object Deserialize(byte[] input, int startIndex, int length, Type type)
        {
            try
            {
                using (var ms = new MemoryStream(input, startIndex, length))
                {
                    return HandlePostDeserialize(_typeModel.Deserialize(ms, null, type));
                }
            }
            catch (Exception ex)
            {
                throw new SerializationException("Unable to deserialize input with ProtoBuf", ex);
            }
        }

        private object HandlePostDeserialize(object obj)
        {
           
            return obj;
        }

        private TypeModel CreateTypeModel(Action<RuntimeTypeModel> additionalTypeModelRegistrations)
        {
            var model = TypeModel.Create();

            model.Add<IRuleResult>()
                .AddSubType<RuleResult>(
                    c => c.Add(m => m.BamSymbol, m => m.AlertLevel, m => m.Description, m => m.IsViolationOverriden,
                         m => m.ParamsInJson, m => m.PolicyId, m => m.PositionQty, m => m.RuleId,
                        m => m.RuleName, m => m.Type, m=>m.BusinessDate));

            additionalTypeModelRegistrations?.Invoke(model);
            
            return model.Compile();
        }
    }

    public static class RuntimeTypeModelExtensions
    {
        public static FluentMetaType<T> Add<T>(this RuntimeTypeModel model, int fieldIdSeed = 0)
        {
            return new FluentMetaType<T>(model, model.Add(typeof(T), false), fieldIdSeed);
        }
    }

    public class FluentMetaType<T>
    {
        private readonly RuntimeTypeModel _model;
        private readonly MetaType _metaType;
        private int _nextFieldId;
        private int _nextSubTypeId;

        public FluentMetaType(RuntimeTypeModel model, MetaType metaType, int fieldIdSeed = 0)
        {
            _model = model;
            _metaType = metaType;
            _nextFieldId = fieldIdSeed;
            _nextSubTypeId = fieldIdSeed + 100;
        }

        public FluentMetaType<T> AddSubType<TSub>(Action<FluentMetaType<TSub>> config = null)
        {
            _metaType.AddSubType(++_nextSubTypeId, typeof(TSub));
            config?.Invoke(_model.Add<TSub>(_nextSubTypeId + 1));
            return this;
        }

        public FluentMetaType<T> UseSurrogate<TSurrogate>()
        {
            _metaType.SetSurrogate(typeof(TSurrogate));
            return this;
        }

        public FluentMetaType<T> Add(params Expression<Func<T, object>>[] properties)
        {
            foreach (var item in properties)
            {
                MemberExpression expr;
                var unaryExpression = item.Body as UnaryExpression;
                if (unaryExpression != null)
                {
                    expr = (MemberExpression)unaryExpression.Operand;
                }
                else
                {
                    expr = (MemberExpression)item.Body;
                }

                _metaType.AddField(++_nextFieldId, expr.Member.Name);
            }

            return this;
        }

        public FluentMetaType<T> AddLists(params Expression<Func<T, object>>[] properties)
        {
            foreach (var item in properties)
            {
                MemberExpression expr;
                var unaryExpression = item.Body as UnaryExpression;
                if (unaryExpression != null)
                {
                    expr = (MemberExpression)unaryExpression.Operand;
                }
                else
                {
                    expr = (MemberExpression)item.Body;
                }

                _metaType.AddField(++_nextFieldId, expr.Member.Name);
            }

            return this;
        }
    }
}
