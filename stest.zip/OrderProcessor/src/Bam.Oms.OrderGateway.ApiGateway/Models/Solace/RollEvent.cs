﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Solace
{
    public class RollEvent
    {
        public DateTime RollTime { get; set; }
        public string BusinessDay { get; set; }
    }
}