﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data;
using Bam.Oms.PositionCalc;

namespace Bam.Oms.OrderMarker
{
    public class OrderMarker : IOrderMarker, IDisposable
    {
        private readonly IPositionCalculator _positionCalculator;

        public OrderMarker(IPositionCalculator positionCalculator)
        {
            _positionCalculator = positionCalculator;
        }

        [Log]
        public IList<Data.IOrder> MarkOrder(Data.IOrder order)
        {
            return _positionCalculator.CalculatePosition();
        }

        [Log]
        public IList<Data.IOrder> MarkOrder(IEnumerable<Data.IOrder> order)
        {
            throw new NotImplementedException();
        }

        public event Action<Data.IOrder, string> NotifyError;

        public event Action<Data.IOrder, string> NotifyWarning;

        public event Action<Data.IOrder, string> NotifyLog;

        protected void PublishLogEvent(IOrder order, string message)
        {
            if (NotifyLog != null)
            {
                NotifyLog(order, message);
            }
        }

        protected void PublishWarningEvent(IOrder order, string message)
        {
            if (NotifyWarning != null)
            {
                NotifyWarning(order, message);
            }
        }

        protected void PublishErrorEvent(IOrder order, string message)
        {
            if (NotifyError != null)
            {
                NotifyError(order, message);
            }
        }

        #region IDisposable.

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected void Dispose(bool disposing)
        {
            PublishLogEvent(null, "Disposing....");
            if (disposing)
            {

            }
            PublishLogEvent(null, "Disposed.");

        }

        // Use C# destructor syntax for finalization code.
        ~OrderMarker()
        {
            Dispose(false);
        }

        #endregion IDisposable

    }
}
