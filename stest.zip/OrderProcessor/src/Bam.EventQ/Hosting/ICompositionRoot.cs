﻿using System;

namespace Bam.EventQ.Hosting
{
    public interface ICompositionRoot<out TService> : IDisposable where TService : IService
    {
        TService Initialize();
    }
}
