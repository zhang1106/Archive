﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Bam.Oms.SodPosition.SvcHost
{
    /// <summary>
    /// Represents a services configuration section in a configuration file.
    /// </summary>
    public class ServicesConfigurationSection : ConfigurationSection
    {

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ServicesConfigurationSection"/> class.
        /// </summary>
        public ServicesConfigurationSection()
        {
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets the services.
        /// </summary>
        /// <value>The services.</value>
        [ConfigurationProperty("services", IsDefaultCollection = false)]
        [ConfigurationCollection(
            typeof(ServiceElementCollection),
            AddItemName = "add",
            ClearItemsName = "clear",
            RemoveItemName = "remove")]
        public ServiceElementCollection Services
        {
            get
            {
                ServiceElementCollection servicesCollection = (ServiceElementCollection)base["services"];
                return servicesCollection;
            }
        }

        #endregion Properties

    }
}
