﻿using System;
using System.Collections.Generic;

namespace Bam.Oms.Data.Compliance
{
    public interface IRule<in T> : IPersistentItem, IExtensible
    {
        int Id { get; set; }
        string Name { get; set; }
        string Description { get; set; }
        bool IsActive { get; set; } //turn on/off a rule
        DateTime StartDate { get; set; }
        DateTime EndDate { get; set; }
        IRuleResult CheckViolation(T input, bool isPreCheck);
        Dictionary<string, decimal> Ratio { get; set; }
        bool IncludeConstituent { get; set; }
    }
}
