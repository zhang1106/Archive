﻿namespace Bam.EventQ.SignalR
{
    public interface ISignalRClient<in T>
    {
        void ReceiveMessage(T packet);
        void Pong(long ticks);
    }
}