﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Services
{
    public interface IFactSvc
    {
        IList<Fact> GetAll();
        Fact Get(int id);

        void Save(Fact fact);
    }
}
