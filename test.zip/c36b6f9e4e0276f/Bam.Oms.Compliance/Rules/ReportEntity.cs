﻿using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Compliance.Rules
{
    public enum ReportEntity
    {
        [Enum(StringValue = "Firm")]
        Firm,
        [Enum(StringValue = "BAM")]
        Bam,
        [Enum(StringValue = "BAMHK")]
        BamHk,
        [Enum(StringValue = "BAMSG")]
        BamSg,
        [Enum(StringValue = "BEAM")]
        Beam
    }
}
