﻿namespace Bam.EventQ.Throttling
{
    public interface IThrottlingStrategy<TItem>
    {
        void Throttle(TItem item, long sequence, bool endOfBatch);
        void Flush(IThrottledBatchHandler<TItem> handler);
    }
}
