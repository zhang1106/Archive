﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public interface IDetailedPositionImportExport
    {
        IReadOnlyList<DetailedPosition> Import(string path);
        void Export(IReadOnlyList<DetailedPosition> positions, string path);
    }
}
