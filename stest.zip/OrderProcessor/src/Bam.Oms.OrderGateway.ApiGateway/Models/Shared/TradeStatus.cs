﻿namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public enum TradeStatus
    {
        New,
        Modified,
        Deleted
    }
}
