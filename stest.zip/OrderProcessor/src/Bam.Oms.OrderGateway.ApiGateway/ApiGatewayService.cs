﻿using System.Collections.Generic;
using Bam.EventQ.Hosting;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Transport;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class ApiGatewayService : PipelinesWithRpcServiceBase
    {
        private readonly IService _httpService;
        private readonly IService _orderFileListener;
        private readonly IService _securityFileListener;
        private readonly IService _headroomFileListener;

        public ApiGatewayService(
            IEnumerable<IProcessingPipeline> pipelines, 
            IRpcServer rpcServer,
            IService httpService, 
            IService orderFileListener, 
            IService securityFileListener,
            IService headroomFileListener) 
            : base(pipelines, rpcServer)
        {
            _httpService = httpService;
            _orderFileListener = orderFileListener;
            _securityFileListener = securityFileListener;
            _headroomFileListener = headroomFileListener;
        }

        public override void Start()
        {
            base.Start();
            _orderFileListener.Start();
            _securityFileListener.Start();
            _httpService.Start();
            _headroomFileListener.Start();
        }

        public override void Stop()
        {
            _httpService.Stop();
            _orderFileListener.Stop();
            _securityFileListener.Stop();
            base.Stop();
        }

        public override string Name => "API";
    }
}
