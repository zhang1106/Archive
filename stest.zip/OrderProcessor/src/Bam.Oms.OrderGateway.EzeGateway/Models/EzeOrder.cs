﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public class EzeOrder  
    {
        public EzeOrder(Guid submissionId)
        {
            SubmissionId = submissionId;
        }

        public Guid SubmissionId { get; }
        public OrderIndexKey Key { get; set; }
        public long OrderId { get; set; }
        public OrderStatus Status{get;set;}
        public DateTime Created { get; set; }
        public DateTime BusinessDay { get; set; }
        public DateTime SettlementDate { get; set; }
        public Side Side { get; set; }
        public string TradingCurrency { get; set; }
        public string SettlementCurrency { get; set; }
        public decimal? LimitPrice { get; set; }
        public string Trader { get; set; }
        public string Notes { get; set; }
        public Messages.Urgency Urgency { get; set; }
        public string BatchName { get; set; }
        public Dictionary<string, string> ExecutionInstructions { get; } = new Dictionary<string, string>();
        public Dictionary<EzeTargetAllocationKey, long> TargetAllocations { get; } = new Dictionary<EzeTargetAllocationKey, long>();

        public bool StatusChanged(EzeOrder other)
        {
            return Status != other?.Status;
        }

        public bool DetailsChanged(EzeOrder other)
        {
            bool modified =
                other == null ||
                TargetAllocations.Count != other.TargetAllocations.Count ||
                Trader != other.Trader ||
                Side != other.Side ||
                Urgency != other.Urgency ||
                Notes != other.Notes ||
                LimitPrice != other.LimitPrice ||
                TradingCurrency != other.TradingCurrency ||
                SettlementCurrency != other.SettlementCurrency;

            if (!modified)
            {
                foreach (var key in TargetAllocations.Keys)
                {
                    if (!other.TargetAllocations.ContainsKey(key) ||
                        TargetAllocations[key] != other.TargetAllocations[key])
                    {
                        modified = true;
                        break;
                    }
                }
            }

            return modified;
        }
    }
}
