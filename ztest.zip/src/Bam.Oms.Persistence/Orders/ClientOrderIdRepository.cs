﻿using System;
using System.Collections.Generic;
using Bam.Oms.Persistence.Journal;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Persistence.Orders
{
    public class ClientOrderIdRepository : PersistentRepository<ClientOrderId>, IClientOrderIdRepository
    {
        private readonly object _threadLock = new object();
        private const string ClientOrderKey = "ClientOrderIdKey";
        private const char VersionDelimiter = 'Z';
        private readonly string _hostHash = Convert.ToString(Math.Abs(Environment.MachineName.GetHashCode()) % 100000, 16).ToUpper();

        public IList<string> GenerateOrderIds(int count)
        {
            //thread safety enforcement
            var currentIndex = 0;

            lock (_threadLock)
            {
                var clientOrderCounter = Get(ClientOrderKey);

                currentIndex = clientOrderCounter.CurrentIndex;

                clientOrderCounter.CurrentIndex += count;
                Save(clientOrderCounter);
            }

            var returnList = new string[count];

            for (var i = 0; i < count; i++)
                returnList[i] = GenerateUniqueId(currentIndex++);
            
            return returnList;
        }
        
        public string ResetOrderIdIndex(int seed = 0)
        {
            var clientOrderId = Get(ClientOrderKey);

            clientOrderId.CurrentIndex = seed;
            Save(clientOrderId);

            return GenerateUniqueId(seed);
        }

        public string IncrementVersion(string orderId)
        {
            var split = orderId.Split(VersionDelimiter);
            int version = 1;

            if (split.Length > 1)
            {
                orderId = split[0];
                if (Int32.TryParse(split[1], out version))
                    version++;
            }

            return orderId + VersionDelimiter + version;
        }

        public override int ClearAll()
        {
            // we want to make sure we don't clear the ClientOrderKey entry, as it's only created onStart
            ResetOrderIdIndex(0);
            return 1;
        }

        private string GenerateUniqueId(int index) //not sure if this is where we want to leave this, as it has to do with creating a unique order id
        {          
            var today = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
            var base16 = Convert.ToString(index, 16).ToUpper();

            return $"{today}{_hostHash}{base16}";
        }

        public ClientOrderIdRepository(ILogger log, IEventJournalFactory eventJournalFactory) 
            : base("ClientOrderIdCache", log, eventJournalFactory)
        {
            if (Get(ClientOrderKey) == null)
            {
                Save(new ClientOrderId(ClientOrderKey) { CurrentIndex = 0 });
            }
        }
    }
}