﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.EndPoints.Http
{
    public class AccessRequireAttribute : Attribute
    {
        public string Privilege  { get; set; }

        public IEnumerable<string> Privileges => Privilege.Replace(" ", string.Empty).Split(',');
        
        public AccessRequireAttribute(string privilege)
        {
            Privilege = privilege;
        }
    }
}
