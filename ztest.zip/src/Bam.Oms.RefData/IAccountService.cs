﻿using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Bam.Oms.RefData.OMS;

namespace Bam.Oms.RefData
{
    public interface IAccountService
    {
        string GetFlexTraderCode(IPortfolio portfolio, ISecurity security);
        /// <summary>
        /// Sets the compliance group, agg unit, and allocation scheme 
        /// </summary>
        /// <param name="items"></param>
        IEnumerable<IContainsPortfolio> SetAccountAttributes(IEnumerable<IContainsPortfolio> items);

        IList<Portfolio> GetPortfolioByPmCode(string pmCode = null);

        Data.Portfolios.Portfolio GetPortfolioByStrategy(string strategy);

        IList<Portfolio> GetAllPortfolios();

        IDictionary<string, bool> IsValidStrategy(IList<string> strategies);

        string GetManagerCode(IPortfolio portfolio,string currency, string broker);

        IList<OrderScale> GetScaleFactor(IPortfolio portfolio, SecurityType securityType);

        string GetEzeTraderCode(int traderId);
        string GetFlexTraderCode(int traderId);

        bool IsValidTrader(string login);

        void SetTraderLogin(IOrder orders);

        void SetCustodian(IOrder order);
    }
}
