﻿using System;

namespace Bam.Oms.Service.Security
{
    public interface ISecurityProcessor : IDisposable
    {
    }
}