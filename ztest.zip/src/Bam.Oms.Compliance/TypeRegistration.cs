﻿using BAM.Infrastructure.Ioc;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Persistence.Securities;

namespace Bam.Oms.Compliance
{
    public class TypeRegtistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            Container.Instance.RegisterType<IJsonDataProvider, JsonDataProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<ISecurityProvider, DWSecurityProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IPolicyProvider, PolicyProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IIntradayPositionProvider, PomoDataProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IMarketDataProvider, PomoDataProvider>(RegistrationType.Singleton);

            Container.Instance.RegisterType<ILongOwnershipRuleResultProvider, LongOwnershipRuleResultProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IRuleResultProvider, LongOwnershipRuleResultProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IEngine<CompliancePosition>, FirmPositionComplianceEngine>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IFactProvider, FactProvider>(RegistrationType.Singleton);

            Container.Instance.RegisterType<IRuleRepository<CompliancePosition>, RuleRepository<CompliancePosition>>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IPolicyRepository<CompliancePosition>, PolicyRepository<CompliancePosition>>(RegistrationType.Singleton);
            
            Container.Instance.RegisterType<IFirmPositionComplianceSvc, FirmPositionComplianceSvc>(RegistrationType.Singleton);
        }
    }
}
