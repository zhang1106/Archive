﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Data.Compliance
{
    public class RuleResult : IRuleResult, IPersistentItem, ICloneable
    { 
        public string Key => FormatKey(PolicyId, RuleId, BamSymbol, BusinessDate);
        public string MiniKey => $"{PolicyId}-{RuleId}-{BamSymbol}";
        public int RuleId { get; set; }
        public int PolicyId { get; set; }
        public string RuleName { get; set; }
        public string BamSymbol { get; set; }
        public string Description { get; set; }
        [JsonProperty]
        [JsonConverter(typeof(StringEnumConverter))]
        public ComplianceAlertLevel AlertLevel { get; set; }
        public bool IsViolationOverriden { get; set; }
        public decimal? PositionQty { get; set; }
        public DateTime BusinessDate { get; set; }
        /// <summary>
        /// custom data in json format that can be specific to rules
        /// </summary>
        public string ParamsInJson { get; set; }
        public string Type { get; set; }
        public HeadRoom HeadRoom { get {return _headRoom;} set { _headRoom = value;
            _headRoom.RuleName = RuleName;
            _headRoom.RuleId = RuleId;
            _headRoom.PolicyId = PolicyId;
        } }private HeadRoom _headRoom;
        
        public static string FormatKey(int policyId, int ruleId, string bamSymbol, DateTime businessDate)
        {
            return $"{policyId}-{ruleId}-{bamSymbol}-{businessDate.ToShortDateString()}";
        }
        public virtual object Clone()
        {
            return new RuleResult()
            {
                PolicyId = this.PolicyId,
                RuleId = this.RuleId,
                BamSymbol = this.BamSymbol,
                AlertLevel = this.AlertLevel,
                PositionQty = this.PositionQty,
                ParamsInJson = this.ParamsInJson,
                BusinessDate = this.BusinessDate
            };
        }

        public virtual bool Same(object obj)
        {
            if (obj == this)
                return true;

            var other = obj as IRuleResult;
            if (this.Equals(obj)) return true;
            if (other == null)
                return false;

            return (Key == other.Key ) 
                && AlertLevel == other.AlertLevel
                && Description  == other.Description
                ;
        }
    }
}
