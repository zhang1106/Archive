﻿using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance
{
    public class CompliancePosition 
    {
        public string BamSymbol => Security.BamSymbol;
        public int PolicyId => Policy.Id;
        public IPolicy<CompliancePosition> Policy { get; set; }
        public ISecurity Security { get; set; }
    }
}
