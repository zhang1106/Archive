﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data.Enumerators
{
    public enum DayCountConvention
    {
        [EnumMember]
        [Enum(StringValue = "N/A")]
        NotApplicable = 0,

        [EnumMember]
        [Enum(StringValue = "30A/360")]
        Thirty360BondBasis = 1,        

        [EnumMember]
        [Enum(StringValue = "30/360")]
        Thirty360US = 2,

        [EnumMember]
        [Enum(StringValue = "30E/360")]
        ThirtyE360 = 3,

        [EnumMember]
        [Enum(StringValue = "30E/360 ISDA")]
        ThirtyE360ISDA = 4,

        [EnumMember]
        [Enum(StringValue = "ACT/ACT")]
        ActualActualICMA = 5,

        [EnumMember]
        [Enum(StringValue = "ACT/365")]
        ActualActualISDA = 6,

        [EnumMember]
        [Enum(StringValue = "ACT/365F")]
        Actual365Fixed = 7,

        [EnumMember]
        [Enum(StringValue = "ACT/360")]
        Actual360 =8,

        [EnumMember]
        [Enum(StringValue = "ACT/364")]
        Actual364 = 9,

        [EnumMember]
        [Enum(StringValue = "ACT/365L")]
        Actual365L = 10,

        [EnumMember]
        [Enum(StringValue = "ACT/ACT AFB")]
        ActualActualAFB = 11,
    }
}
