﻿using System;
using CsvHelper;
using System.ServiceModel;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Transactions;
using AutoMapper;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Enumerators;
using System.Runtime.Caching;
using System.Runtime.CompilerServices;
using Bam.Oms.Data;
using BAM.Infrastructure.Ioc;
using Bam.Oms.SodPosition.Svc.File;
using System.Threading.Tasks;

namespace Bam.Oms.SodPosition.Svc
{
    /// <summary>
    /// Implementation of SodPositionEdit using entity framework
    /// </summary>
    public class SodPositionEditEF : ISodPositionEdit
    {
        private const string EXCEPTION_SOURCE = "Web Service";

        private readonly Func<DBModel.OrderGatewayEntities> _orderGatewayGenerator = null;

        private readonly IFileLoading _fileLoading;

        private readonly IList<string> _streams;

        private readonly MemoryCache _cache = MemoryCache.Default;

        private IDictionary<string, DateTime> _streamEntryDateMap = new Dictionary<string, DateTime>();

        private readonly IMappingEngine _mappingEngine;

        private DBModel.OrderGatewayEntities _dbContext
        {
            get
            {
                return _orderGatewayGenerator();
            }
        }

        public SodPositionEditEF()
            : this(() => new DBModel.OrderGatewayEntities(), null)
        {

        }
        public SodPositionEditEF(Func<DBModel.OrderGatewayEntities> dbcontextGenerator)
            : this(dbcontextGenerator, null)
        {
        }
        public SodPositionEditEF(Func<DBModel.OrderGatewayEntities> dbcontextGenerator, IFileLoading fileLoading)
        {
            var streamList = ConfigurationManager.AppSettings["streams"];
            if (string.IsNullOrEmpty(streamList))
            {
                throw new Exception("Can't find the list of streams in the configuration file.");
            }
            else
            {
                _streams = streamList.Split(';');
            }

            _mappingEngine = Container.Instance.Resolve<IMappingEngine>();

            this._orderGatewayGenerator = dbcontextGenerator;
            this._fileLoading = fileLoading;
        }

        public virtual void Start()
        {
            RefreshStreamEntryDateMap();
            if (this._fileLoading != null)
            {
                this._fileLoading.SodPositionLoaded += PublishLoadedPositions;
                this._fileLoading.SodPositionLoaded += RefreshStreamEntryDateMap;
                _fileLoading.Start();
            }
        }

        public virtual void Dispose()
        {
        }

        public string CSVOutputPath
        {
            get
            {
                if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["sodPosition_update_path"]))
                {
                    throw new Exception("Cant find the output path for Sod position update path - [SodPosition-Update-Path] in configuration file.");
                }
                else
                {
                    return ConfigurationManager.AppSettings["sodPosition_update_path"];
                }
            }
        }

        public string Whatsup()
        {
            return "Hello World";
        }

        public IList<IPosition> GetPositions(string userId, DateTime? asofdate, string stream, string fundCode, string custodianName, string strategyCode, string securityType, string bamSymbol)
        {
            var positions = GetSodPositions(userId, asofdate, stream, fundCode, custodianName, strategyCode, securityType, bamSymbol);
            IList<IPosition> rlist = positions.ToList<IPosition>();

            return rlist;
        }

        public IList<Position> GetSodPositions(string userId, DateTime? asofdate, string stream, string fundCode, string custodianName, string strategyCode, string securityType, string bamSymbol)
        {
            using (var dbContext = _dbContext)
            {
                try
                {
                    List<Func<DBModel.Position, bool>> positionFilters = new List<Func<DBModel.Position, bool>>();
                    positionFilters.Add(x => asofdate == null || x.EntryDate.Equals(asofdate));

                    positionFilters.Add(x => string.IsNullOrWhiteSpace(stream) || x.Stream.Equals(stream));

                    positionFilters.Add(x => string.IsNullOrWhiteSpace(custodianName) || x.CustodianName.Equals(custodianName));

                    positionFilters.Add(x => string.IsNullOrWhiteSpace(fundCode) || x.FundCode.Equals(fundCode));

                    positionFilters.Add(x => string.IsNullOrWhiteSpace(strategyCode) || x.StrategyCode.Equals(strategyCode));

                    positionFilters.Add(x => string.IsNullOrWhiteSpace(securityType) || x.AssetType.Equals(securityType));

                    positionFilters.Add(x => string.IsNullOrWhiteSpace(bamSymbol) || x.BAMSymbol.Equals(bamSymbol));
                    var combinedPredicate = And(positionFilters.ToArray());
                    var rlist = dbContext.Positions.Where(combinedPredicate).ToList();
                    var returnedPositions = _mappingEngine.Map<IList<DBModel.Position>, IList<Position>>(rlist);
                    return returnedPositions;
                }
                catch (Exception ex)
                {
                    LogException("POSITION_FETCH", ex);
                    throw;
                }
            }
        }

        /// <summary>
        /// get latest updated positions which have not been published
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public IList<Position> GetLatestUpdatedPositions(string userId, string stream)
        {
            List<DBModel.Position> positions = null;
            try
            {
                using (var dbContext = _dbContext)
                {
                    var publishActionName = GetPublishPositionsActionName(stream);
                    var action = GetAction(dbContext, publishActionName, Constants.BAM_ACTION_TYPE);

                    if (action == null)
                    {
                        throw new Exception($"Couldn't find the action corresponding to {publishActionName}");
                    }
                    else
                    {
                        var actionLog = dbContext.ActionLogs.Where(x => x.ActionId == action.ActionId).OrderByDescending(x => x.CreatedOn).FirstOrDefault();
                        DateTime now = DateTime.Now;
                        if (actionLog == null)
                        {
                            // No previous action log present. All the records need to be exported
                            positions = dbContext.Positions.Where(x => x.Stream.Equals(stream) && x.LastModifiedOn <= now && x.AuditSequence > 0).ToList();
                        }
                        else
                        {
                            positions = dbContext.Positions.Where(x => x.Stream.Equals(stream) && x.LastModifiedOn > actionLog.CreatedOn && x.LastModifiedOn <= now && x.AuditSequence > 0).ToList();
                        }
                    }
                    var rlist = _mappingEngine.Map<IList<DBModel.Position>, IList<Position>>(positions);
                    return rlist;
                }
            }
            catch (Exception ex)
            {
                LogException("LATEST_UPDATED_POSITIONS_FETCH", ex);
                throw;
            }
        }

        public string GetPublishPositionsActionName(string stream)
        {
            return stream + "_PUBLISH_UPDATED_POSITIONS";
        }


        /// <summary>
        /// get list of audit trails for a poistion
        /// </summary>
        /// <param name="positionId"></param>
        /// <param name="entrydate"></param>
        /// <returns></returns>
        public IList<PositionAudit> GetAudits(string userId, int positionId, DateTime entrydate)
        {
            try
            {
                using (var dbContext = _dbContext)
                {
                    var audits = dbContext.PositionAudits.Where(x => x.PositionId == positionId && x.EntryDate.Equals(entrydate)).ToList();
                    var rlist = _mappingEngine.Map<IList<DBModel.PositionAudit>, IList<PositionAudit>>(audits);
                    return rlist;
                }
            }
            catch (Exception ex)
            {
                LogException("GET_AUDIT_TRAIL", ex);
                throw;
            }
        }


        /// <summary>
        /// update a position
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="position"></param>
        /// <returns></returns>
        public Position UpdatePosition(string userId, Position position)
        {
            try
            {
                var dbPosition = _mappingEngine.Map<Position, DBModel.Position>(position);

                using (var dbContext = _dbContext)
                using (var tscope = new TransactionScope())
                {
                    var action = GetAction(dbContext, Constants.POSITION_UPDATE_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find the action corresponding to {Constants.POSITION_UPDATE_ACTION_NAME}");
                    }
                    // action is not null
                    DBModel.ActionLog actionLogEntry = new DBModel.ActionLog { ActionId = action.ActionId, ActionDetails = "Updated a position", CreatedOn = DateTime.Now };
                    dbContext.ActionLogs.Add(actionLogEntry);
                    dbContext.SaveChanges();
                    if (position.PositionId == 0)
                    {
                        var matchingPosition = GetMatchingPosition(dbContext, dbPosition);
                        if (matchingPosition == null)
                        {
                            dbPosition = InsertPosition(dbContext, dbPosition, actionLogEntry.ActionLogId);
                        }
                        else
                        {
                            dbPosition.PositionId = matchingPosition.PositionId;
                            dbPosition.AuditSequence = matchingPosition.PositionId;
                            dbPosition = UpdatePosition(dbContext, dbPosition, actionLogEntry.ActionLogId);
                        }
                    }
                    else
                    {
                        dbPosition = UpdatePosition(dbContext, dbPosition, actionLogEntry.ActionLogId);
                    }
                    var updatedPosition = _mappingEngine.Map<DBModel.Position, Position>(dbPosition);
                    tscope.Complete();
                    return updatedPosition;
                }
            }
            catch (Exception ex)
            {
                LogException("UPDATE_POSITION", ex);
                throw;
            }
        }

        /// <summary>
        /// bulk update positions
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        public IList<Position> BulkUpdatePosition(string userId, IList<Position> positions)
        {
            try
            {
                IList<DBModel.Position> dbPositions = _mappingEngine.Map<IList<Position>, IList<DBModel.Position>>(positions);
                using (var dbContext = _dbContext)
                using (var tscope = new TransactionScope())
                {
                    var action = GetAction(dbContext, Constants.POSITION_BULK_UPDATE_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find the action corresponding to {Constants.POSITION_BULK_UPDATE_ACTION_NAME}");
                    }
                    // action is not null
                    DBModel.ActionLog actionLogEntry = new DBModel.ActionLog { ActionId = action.ActionId, ActionDetails = "Updated a position", CreatedOn = DateTime.Now };
                    dbContext.ActionLogs.Add(actionLogEntry);
                    dbContext.SaveChanges();
                    var modifiedPositions = UpdatePositions(dbContext, dbPositions, actionLogEntry.ActionLogId);
                    var rlist = _mappingEngine.Map<IList<DBModel.Position>, IList<Position>>(modifiedPositions);
                    tscope.Complete();
                    return rlist;
                }
            }
            catch (Exception ex)
            {
                LogException("BULK_UPDATE_POSITION", ex);
                throw;
            }
        }

        /// <summary>
        /// insert a position
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        public Position InsertPosition(string userId, Position positionToInsert)
        {

            try
            {
                var position = _mappingEngine.Map<Position, DBModel.Position>(positionToInsert);
                using (var dbContext = _dbContext)
                using (var tscope = new TransactionScope(TransactionScopeOption.Required,
                    new TransactionOptions() { IsolationLevel = IsolationLevel.ReadUncommitted }))
                {
                    var action = GetAction(dbContext, Constants.POSITION_INSERT_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find the action corresponding to {Constants.POSITION_INSERT_ACTION_NAME}");
                    }
                    DBModel.ActionLog actionLogEntry = new DBModel.ActionLog { ActionId = action.ActionId, ActionDetails = "Inserted a position", CreatedOn = DateTime.Now };
                    dbContext.ActionLogs.Add(actionLogEntry);
                    dbContext.SaveChanges();
                    position = InsertPosition(dbContext, position, actionLogEntry.ActionLogId);
                    // Persist the position

                    var insertedPosition = _mappingEngine.Map<DBModel.Position, Position>(position);
                    tscope.Complete();
                    return insertedPosition;
                }
            }
            catch (Exception ex)
            {
                LogException("INSERT_POSITION", ex);
                throw;
            }
        }

        /// <summary>
        /// bulk inert poistions
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        public IList<Position> BulkInsertPosition(string userId, IList<Position> positionsToInsert)
        {
            try
            {
                var positions = _mappingEngine.Map<IList<Position>, IList<DBModel.Position>>(positionsToInsert);
                using (var dbContext = _dbContext)
                using (var transactionScope = new TransactionScope())
                {
                    var action = GetAction(dbContext, Constants.POSITION_BULK_INSERT_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find the action corresponding to {Constants.POSITION_BULK_INSERT_ACTION_NAME}");
                    }
                    DateTime now = DateTime.Now;
                    DBModel.ActionLog actionLogEntry = new DBModel.ActionLog { ActionId = action.ActionId, ActionDetails = "Bulk inserted positions", CreatedOn = now };
                    dbContext.ActionLogs.Add(actionLogEntry);
                    dbContext.SaveChanges();
                    positions = InsertPositions(dbContext, positions, actionLogEntry.ActionLogId);

                    transactionScope.Complete();
                    var rlist = _mappingEngine.Map<IList<DBModel.Position>, IList<Position>>(positions);
                    return rlist;
                }
            }
            catch (Exception exception)
            {
                LogException("BULK_INSERT_POSITION", exception);
                throw;
            }
        }

        /// <summary>
        /// publish changes to subscribers
        /// </summary>
        /// <param name="positions"></param>
        /// <returns></returns>
        public bool PublishUpdatedPositions(string userId, string stream)
        {
            try
            {
                bool success;
                IList<Position> positions = GetLatestUpdatedPositions(userId, stream);
                DateTime now = DateTime.Now;
                var publishActionName = GetPublishPositionsActionName(stream);
                using (var dbContext = _dbContext)
                {
                    var action = GetAction(dbContext, publishActionName, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception($"Couldn't find the action corresponding to {publishActionName}");
                    }
                    success = SaveToCSVFile(userId, "", positions);
                    DBModel.ActionLog actionLogEntry = new DBModel.ActionLog { ActionId = action.ActionId, ActionDetails = "Saving positions to CSV", CreatedOn = now };
                    dbContext.ActionLogs.Add(actionLogEntry);
                    dbContext.SaveChanges();
                }
                // Raise event in a new thread
                Task.Factory.StartNew(() => RaisePositionUpdatedEvent(positions));
                return success;
            }
            catch (Exception exception)
            {
                LogException("PUBLISH_UPDATED_POSITIONS", exception);
                throw;
            }
        }

        public IList<Position> GetUndoChanges(string userId, int positionId)
        {
            try
            {
                using (var tscope = new TransactionScope())
                using (var dbContext = _dbContext)
                {
                    IList<DBModel.Position> undoChanges = GetUndoChanges(dbContext, positionId);
                    tscope.Complete();
                    return _mappingEngine.Map<IList<DBModel.Position>, IList<Position>>(undoChanges);
                }
            }
            catch (Exception exception)
            {
                LogException("GET_UNDO_CHANGES", exception);
                throw;
            }
        }

        public IList<Position> ExecuteUndo(string userId, int positionId, IList<Position> undoList)
        {
            try
            {
                using (var tscope = new TransactionScope())
                using (var dbContext = _dbContext)
                {
                    var action = GetAction(dbContext, Constants.UNDO_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception($"Couldn't find the action corresponding to {Constants.UNDO_ACTION_NAME}");
                    }
                    DateTime now = DateTime.Now;
                    DBModel.ActionLog actionLogEntry = new DBModel.ActionLog { ActionId = action.ActionId, ActionDetails = "Undid operation", CreatedOn = now };
                    dbContext.ActionLogs.Add(actionLogEntry);
                    dbContext.SaveChanges();
                    IList<DBModel.Position> undoChanges = GetUndoChanges(dbContext, positionId);

                    if (undoChanges == null || undoChanges.Count == 0) return new List<Position>();
                    var undoPositions = _mappingEngine.Map<IList<Position>, IList<DBModel.Position>>(undoList);
                    if (!IsSamePositionList(undoPositions, undoChanges))
                    {
                        // Apparently, the some of the positions have been updated
                        return new List<Position>();
                    }

                    IList<DBModel.Position> modifiedPositions = UpdatePositions(dbContext, undoPositions, actionLogEntry.ActionLogId);
                    var rlist = _mappingEngine.Map<IList<DBModel.Position>, IList<Position>>(modifiedPositions);
                    tscope.Complete();
                    return rlist;
                }
            }
            catch (Exception exception)
            {
                LogException("EXECUTE_UNDO", exception);
                throw;
            }
        }

        private bool IsSamePositionList(IList<DBModel.Position> list1, IList<DBModel.Position> list2)
        {
            if (list1 == null && list2 == null)
            {
                return true;
            }
            if (list1.Count != list2.Count)
            {
                return false;
            }
            foreach (var p in list1)
            {
                bool found = false;
                for (int i = 0; i < list2.Count; ++i)
                {
                    if (IsSamePosition(p, list2[i]))
                    {
                        list2.RemoveAt(i);
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    return false;
                }
            }
            return true;
        }

        private IList<DBModel.Position> GetUndoChanges(DBModel.OrderGatewayEntities dbContext, int positionId)
        {
            var position = dbContext.Positions.FirstOrDefault(x => x.PositionId == positionId);
            if (position == null || position.AuditSequence == 0)
            {
                //Cannot find the position or the position has just been loaded as part of daily load
                return new List<DBModel.Position>();
            }
            var actionLogId = position.ActionLogId;
            //Find all the positions associated with this actionLogId from the audit table
            var audits = dbContext.PositionAudits.Where(x => x.ActionLogId == actionLogId).ToList();
            var contributingPositions = dbContext.Positions.Where(x => x.ActionLogId == actionLogId).ToList();
            if (audits.Count != contributingPositions.Count)
            {
                //Cannot undo as not all positions seem to be in the same state as they were
                // post the operation
                return new List<DBModel.Position>();
            }
            // Confirm that all the positions are having different position ids.
            // If such is not the case, it points to data corruption.
            if (audits.Count != audits.Select(x => x.PositionId).Distinct().Count())
            {
                return new List<DBModel.Position>();
            }
            // All the positions are at the same state as they were post the operation
            // Get the previous state of all those positions
            // For each position, get the older state, or if the position was not present,
            // set the quantity to 0 so that it can be taken as deleted
            var olderDbAudits = (from audit in dbContext.PositionAudits
                                 join pos in dbContext.Positions
                                 on audit.PositionId equals pos.PositionId
                                 where (pos.AuditSequence == audit.AuditSequence + 1
                                 && pos.ActionLogId == actionLogId)
                                 select audit).ToList();
            var existingOlderPositionIds = olderDbAudits.Select(x => x.PositionId).ToList();
            // Find all positions for which no previous positions were found.
            // those positions need to be set to deleted i.e. Qty set to zero
            var positionsToBeDeleted = _mappingEngine.Map<IList<DBModel.Position>, IList<Position>>(contributingPositions.Where(x => !existingOlderPositionIds.Contains(x.PositionId)).ToList());
            // get the positions for all these positions ids and set Qty to zero
            foreach (var pos in positionsToBeDeleted)
            {
                pos.ActualQuantity = 0;
                pos.TheoreticalQuantity = 0;
                pos.Price = 0;
            }
            var olderPositions = _mappingEngine.Map<IList<DBModel.PositionAudit>, IList<DBModel.Position>>(olderDbAudits);
            foreach (var pos in olderPositions)
            {
                pos.AuditSequence++;
            }
            List<DBModel.Position> aggregatedPositions = new List<DBModel.Position>();
            aggregatedPositions.AddRange(_mappingEngine.Map<IList<Position>, IList<DBModel.Position>>(positionsToBeDeleted));
            aggregatedPositions.AddRange(olderPositions);
            return aggregatedPositions;
        }

        public IList<SodAction> GetBulkActions(string userId)
        {
            try
            {
                using (var dbContext = _dbContext)
                {
                    var actions = dbContext.Actions.Where(x => x.Type.Equals(Constants.CORP_ACTION_TYPE)).ToList();
                    var rlist = _mappingEngine.Map<IList<DBModel.Action>, IList<SodAction>>(actions);
                    return rlist;
                }
            }
            catch (Exception exception)
            {
                LogException("GET_BULK_ACTIONS", exception);
                throw;
            }
        }

        public IList<string> GetStreams(string userId)
        {
            return _streams;
        }

        public string GetLatestLoadedStream(string userId)
        {
            try
            {
                using (var dbContext = _dbContext)
                {
                    var streams = GetStreams(userId);
                    IDictionary<int, string> actionIdToStreamMap = new Dictionary<int, string>();
                    foreach (var stream in streams)
                    {
                        var dailyLoadAction = GetAction(dbContext, GetDailyLoadingActionName(stream), Constants.BAM_ACTION_TYPE);
                        if (dailyLoadAction != null)
                        {
                            actionIdToStreamMap[dailyLoadAction.ActionId] = stream;
                        }
                    }
                    var maxLoadTime = (from actLog in dbContext.ActionLogs
                                       where actionIdToStreamMap.Keys.Contains(actLog.ActionId)
                                       select (DateTime?)actLog.CreatedOn).Max();
                    if (maxLoadTime == null)
                    {
                        return null;
                    }
                    var actionId = dbContext.ActionLogs.First(x => x.CreatedOn == maxLoadTime).ActionId;
                    return actionIdToStreamMap[actionId];
                }
            }
            catch (Exception exception)
            {
                LogException("GET_LATEST_LOADED_STREAM", exception);
                throw;
            }
        }

        private string GetDailyLoadingActionName(string stream)
        {
            return stream + "_DAILY_LOADING";
        }

        /// <summary>
        /// output a list of positions to a csv file
        /// </summary>
        /// <param name="positions"></param>
        /// <returns></returns>
        public bool SaveToCSVFile(string userId, string completeFileName, IList<Position> positions)
        {
            completeFileName = $"{CSVOutputPath}/FLEX_SOD_FILE_UPDATE_{DateTime.Now:yyyyMMdd_hhmmssfff}.csv";
            string formatter = "0.############";
            IList<DBModel.Position> dbPositions = _mappingEngine.Map<IList<Position>, IList<DBModel.Position>>(positions);
            using (var writer = new StreamWriter(completeFileName))
            {
                var records = dbPositions.Select(x => new
                {
                    Symbol = x.BAMSymbol,
                    Qty = x.Qty.ToString(formatter),
                    Price = x.Price.ToString(formatter),
                    Currency = x.Ccy,
                    FxRate = x.FXRate.ToString(formatter),
                    Custodian = x.CustodianName,
                    SecurityType = x.AssetType,
                    Strategy = x.StrategyCode,
                    Fund = x.FundCode,
                    Stream = x.Stream
                }).ToList();
                var csvWriter = new CsvWriter(writer);
                csvWriter.WriteRecords(records);
            }
            return true;
        }

        public static Func<T, bool> And<T>(params Func<T, bool>[] predicates)
        {
            return delegate(T item)
            {
                foreach (Func<T, bool> predicate in predicates)
                {
                    if (!predicate(item))
                    {
                        return false;
                    }
                }
                return true;
            };
        }

        public event Action<IList<Position>> SodPositionUpdated;

        private void LogException(string data, Exception exception)
        {
            string description = exception.Message;
            // If innerexception is present, append that information as well
            var innerException = exception.InnerException;
            int count = 5; //Don't go more than 5 level deep
            while (count-- != 0)
            {
                if (innerException != null)
                {
                    description += " InnerException: " + innerException.Message;
                    innerException = innerException.InnerException;
                }
            }
            var dbException = new DBModel.Exception { Source = EXCEPTION_SOURCE, Data = data, Description = Truncate(description, 300), CreatedOn = DateTime.Now };
            using (var dbContext = _dbContext)
            {
                dbContext.Exceptions.Add(dbException);
                dbContext.SaveChanges();
            }
        }

        private string Truncate(string str, int maxLength)
        {
            if (string.IsNullOrEmpty(str)) return str;
            return str.Length <= maxLength ? str : str.Substring(0, maxLength);
        }

        private DBModel.Action GetAction(DBModel.OrderGatewayEntities dbContext, string name, string type)
        {
            var key = name + "||" + type;
            var action = _cache.Get(key) as DBModel.Action;
            if (action == null)
            {
                action = dbContext.Actions.Where(x => x.Name.Equals(name) && x.Type.Equals(type)).FirstOrDefault();
                action = _mappingEngine.Map<DBModel.Action, DBModel.Action>(action); // Create a copy
                if (action != null)
                {
                    _cache.Set(key, action, new CacheItemPolicy());
                }
            }
            return action;
        }

        private void PreparePositionForUpdate(DBModel.Position position, DBModel.Position existingPosition, int actionLogId)
        {
            DateTime now = DateTime.Now;
            position.AuditSequence = existingPosition.AuditSequence + 1;
            position.ActionLogId = actionLogId;
            position.LastModifiedOn = now;
            position.CreatedOn = existingPosition.CreatedOn;
            position.EntryDate = existingPosition.EntryDate;
        }

        private bool IsSamePosition(DBModel.Position pos1, DBModel.Position pos2)
        {
            if (pos1 == pos2)
            {
                return true;
            }
            if (pos1 == null && pos2 != null)
            {
                return false;
            }
            return string.Equals(pos1.BAMSymbol, pos2.BAMSymbol)
                && string.Equals(pos1.Ccy, pos2.Ccy)
                && string.Equals(pos1.CustodianName, pos2.CustodianName)
                && string.Equals(pos1.FundCode, pos2.FundCode)
                && decimal.Equals(pos1.FXRate, pos2.FXRate)
                && string.Equals(pos1.AssetType, pos2.AssetType)
                && decimal.Equals(pos1.Price, pos2.Price)
                && decimal.Equals(pos1.Qty, pos2.Qty)
                && string.Equals(pos1.StrategyCode, pos2.StrategyCode)
                && string.Equals(pos1.Stream, pos2.Stream)
                && string.Equals(pos1.CustodianAccountCode, pos2.CustodianAccountCode)
                && pos1.Cost == pos2.Cost;
        }


        private IList<DBModel.Position> UpdatePositions(DBModel.OrderGatewayEntities dbContext, IList<DBModel.Position> dbPositions, int actionLogId)
        {
            dbPositions = PreprocessPositions(dbContext, dbPositions);
            var positionsToInsert = dbPositions.Where(x => x.PositionId == 0).ToList();
            var positionsToUpdate = dbPositions.Where(x => x.PositionId != 0).ToList();
            var insertedPositions = InsertPositions(dbContext, positionsToInsert, actionLogId);
            var positionIds = positionsToUpdate.Select(x => x.PositionId).Distinct().ToList();
            if (positionIds.Count + positionsToInsert.Count != dbPositions.Count)
            {
                throw new Exception("Apparently, there are some positions with same position ids");
            }
            var existingPositions = (from pos in dbContext.Positions
                                     join pId in positionIds
                                     on pos.PositionId equals pId
                                     select pos).ToList();
            if (existingPositions.Count < positionIds.Count)
            {
                throw new InvalidOperationException("Couldn't find positions corresponding to a few position ids");
            }
            IDictionary<int, DBModel.Position> idToPositionMap = new Dictionary<int, DBModel.Position>();
            foreach (var pos in existingPositions)
            {
                idToPositionMap.Add(pos.PositionId, pos);
            }
            var now = DateTime.Now;
            foreach (var pos in positionsToUpdate)
            {
                var existingPosition = idToPositionMap[pos.PositionId];
                if (pos.AuditSequence != existingPosition.AuditSequence)
                {
                    throw new DbUpdateConcurrencyException("Cannot update the record as the new record has a different audit sequence than expected");
                }
                if (!IsSamePosition(pos, existingPosition))
                {
                    PreparePositionForUpdate(pos, existingPosition, actionLogId);
                    dbContext.Entry(existingPosition).CurrentValues.SetValues(pos);
                }
            }
            dbContext.SaveChanges();
            var modifiedPositions = new List<DBModel.Position>(insertedPositions);
            modifiedPositions.AddRange(positionsToUpdate);

            return modifiedPositions;
        }

        private IList<DBModel.Position> PreprocessPositions(DBModel.OrderGatewayEntities dbContext, IList<DBModel.Position> positions)
        {
            // For positions with position ids as 0, we need to check if similar positions exist with quantity zeros
            // If so, they need to be updated
            var existingPositions = dbContext.Positions.ToList();
            var posDict = (from existingPos in existingPositions
                           join pos in positions
                           on new
                           {
                               existingPos.FundCode,
                               existingPos.CustodianName,
                               existingPos.StrategyCode,
                               existingPos.AssetType,
                               existingPos.BAMSymbol,
                               existingPos.Qty,
                               existingPos.EntryDate
                           } equals new { pos.FundCode, pos.CustodianName, pos.StrategyCode, pos.AssetType, pos.BAMSymbol, Qty = 0M, pos.EntryDate }
                           select new { existingPos.PositionId, pos.FundCode, pos.CustodianName, pos.StrategyCode, pos.AssetType, pos.BAMSymbol, existingPos.AuditSequence }).ToDictionary(pos => new { pos.FundCode, pos.CustodianName, pos.StrategyCode, pos.AssetType, pos.BAMSymbol });
            foreach (var pos in positions)
            {
                var lookupKey = new { pos.FundCode, pos.CustodianName, pos.StrategyCode, pos.AssetType, pos.BAMSymbol };
                if (posDict.ContainsKey(lookupKey))
                {
                    var matchingExistingPos = posDict[lookupKey];
                    pos.PositionId = matchingExistingPos.PositionId;
                    pos.AuditSequence = matchingExistingPos.AuditSequence;
                }
            }
            return positions;
        }

        private DBModel.Position UpdatePosition(DBModel.OrderGatewayEntities dbContext, DBModel.Position dbPosition, int actionLogId)
        {
            var existingPosition = dbContext.Positions.Where(x => x.PositionId == dbPosition.PositionId).FirstOrDefault();

            if (existingPosition == null)
            {
                throw new Exception("Couldn't find a matching position");
            }
            if (dbPosition.AuditSequence != existingPosition.AuditSequence)
            {
                throw new DbUpdateConcurrencyException("Cannot update the record as the new record has a different audit sequence than expected");
            }
            if (!IsSamePosition(dbPosition, existingPosition))
            {
                PreparePositionForUpdate(dbPosition, existingPosition, actionLogId);
                dbContext.Entry(existingPosition).CurrentValues.SetValues(dbPosition);
            }
            dbContext.SaveChanges();
            return dbPosition;
        }

        private DBModel.Position InsertPosition(DBModel.OrderGatewayEntities dbContext, DBModel.Position position, int actionLogId)
        {

            PreparePositionForInsert(position, actionLogId);
            dbContext.Positions.Add(position);
            dbContext.SaveChanges();
            return position;

        }

        private DBModel.Position GetMatchingPosition(DBModel.OrderGatewayEntities dbContext, DBModel.Position position)
        {
            return dbContext.Positions.FirstOrDefault(x => x.FundCode == position.FundCode
                                                        && x.CustodianName == position.CustodianName
                                                        && x.StrategyCode == position.StrategyCode
                                                        && x.AssetType == position.AssetType
                                                        && x.BAMSymbol == position.BAMSymbol
                                                        && x.Qty == 0M
                                                        && x.EntryDate == position.EntryDate);
        }


        private void PreparePositionForInsert(DBModel.Position pos, int actionLogId)
        {
            DateTime now = DateTime.Now;
            pos.LastModifiedOn = now;
            if (_streamEntryDateMap.ContainsKey(pos.Stream))
            {
                pos.EntryDate = _streamEntryDateMap[pos.Stream];
            }
            else
            {
                throw new Exception("Couldn't find the entryDate corresponding to the given stream");
            }
            pos.CreatedOn = now;
            pos.AuditSequence = 1;
            pos.ActionLogId = actionLogId;
        }

        private IList<DBModel.Position> InsertPositions(DBModel.OrderGatewayEntities dbContext, IList<DBModel.Position> positions, int actionLogId)
        {
            foreach (var pos in positions)
            {
                PreparePositionForInsert(pos, actionLogId);
            }
            dbContext.Positions.AddRange(positions);
            dbContext.SaveChanges();

            return positions;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        private void RefreshStreamEntryDateMap()
        {
            try
            {
                IDictionary<string, DateTime> streamEntryDateMap = new Dictionary<string, DateTime>();
                using (var dbContext = _dbContext)
                {
                    var streamDates = dbContext.Positions.Select(x => new { Stream = x.Stream, EntryDate = x.EntryDate }).Distinct();
                    foreach (var streamDate in streamDates)
                    {
                        if (streamEntryDateMap.ContainsKey(streamDate.Stream))
                        {
                            throw new Exception("Inconsistent data: same stream with different entry dates found");
                        }
                        else
                        {
                            streamEntryDateMap.Add(streamDate.Stream, streamDate.EntryDate);
                        }
                    }
                }
                _streamEntryDateMap = streamEntryDateMap;
            }
            catch (Exception exception)
            {
                _streamEntryDateMap.Clear();
                LogException(exception.Message, exception);
            }
        }

        private void PublishLoadedPositions()
        {
            try
            {
                IList<Position> positions;
                using (var tscope = new TransactionScope())
                using (var dbContext = _dbContext)
                {
                    var action = GetAction(dbContext, Constants.PUBLISH_LOADED_POSITIONS_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find an action corresponding to action name: {Constants.PUBLISH_LOADED_POSITIONS_ACTION_NAME}, and action type: {Constants.BAM_ACTION_TYPE}");
                    }
                    var latestRecordTime = dbContext.ActionLogs.Where(x => x.ActionId == action.ActionId).Select(x => (DateTime?)x.CreatedOn).Max();
                    DateTime now = DateTime.Now;

                    IList<DBModel.Position> dbPositions = null;
                    if (latestRecordTime == null)
                    {
                        // This is the first instance. Publish all the positions
                        dbPositions = dbContext.Positions.Where(x => x.AuditSequence == 0 && x.CreatedOn < now).ToList();
                    }
                    else
                    {
                        dbPositions = dbContext.Positions.Where(x => x.AuditSequence == 0 && x.CreatedOn >= latestRecordTime && x.CreatedOn < now).ToList();
                    }
                    positions = _mappingEngine.Map<IList<DBModel.Position>, IList<Position>>(dbPositions);
                    dbContext.ActionLogs.Add(new DBModel.ActionLog { ActionId = action.ActionId, ActionDetails = "Publish loaded positions", CreatedOn = now });
                    dbContext.SaveChanges();
                    tscope.Complete();
                }
                // This event needs to be raised on a different thread
                Task.Factory.StartNew(() => RaisePositionUpdatedEvent(positions));
            }
            catch (Exception exception)
            {
                LogException(exception.Message, exception);
            }
        }

        /// <summary>
        /// Executes the SodPositionUpdated. In case one of the handler fails,
        /// the execution of other handlers doesn't get impacted
        /// </summary>
        /// <param name="positions"></param>
        private void RaisePositionUpdatedEvent(IList<Position> positions)
        {
            if (SodPositionUpdated != null)
            {

                foreach (var handler in SodPositionUpdated.GetInvocationList().Cast<Action<IList<Position>>>())
                {
                    try
                    {
                        handler(positions);
                    }
                    catch (Exception exception)
                    {
                        LogException(exception.Message, exception);
                    }
                }
            }
        }
    }
}
