﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Snapshot;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Model.Snapshot;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class OrderFactory : IOrderFactory, ISnapshotRecoverable<OpeningClosingAllocationSnapshot>
    {
        private readonly ISplitOrderIdGenerator _idGenerator;
        private readonly IReferenceDataService _referenceDataService;
        private readonly ISecurityCache _securityCache;
        private readonly IModelIndex<Order> _orders;
        private readonly Dictionary<long, KeyValuePair<List<OrderAllocation>, List<OrderAllocation>>> _recoveredAllocations
            = new Dictionary<long, KeyValuePair<List<OrderAllocation>, List<OrderAllocation>>>();

        public ILogger Logger { get; set; }

        public OrderFactory(
            ISplitOrderIdGenerator idGenerator, 
            IReferenceDataService referenceDataService,
            ISecurityCache securityCache,
            IIndexFactory index)
        {
            _idGenerator = idGenerator;
            _referenceDataService = referenceDataService;
            _securityCache = securityCache;
            _orders = index.For<Order>();
        }

        public Order Create(long id, string symbol, string securityType, Portfolio portfolio, long size, Side side)
        {
            PortfolioDetails details;
            if (!_referenceDataService.TryGetPortfolioDetails(portfolio, out details))
            {
                return null;
            }

            CachedSecurity sec;
            if (!_securityCache.TryGetSecurity(symbol, out sec))
            {
                sec = _securityCache.AddPlaceholder(symbol);
            }

            var order = new Order(id, sec, portfolio, size, side, 
                details.ReportingEntity, details.AggregationUnit);
            _orders.Insert(order);

            KeyValuePair<List<OrderAllocation>, List<OrderAllocation>> recovered;
            if (_recoveredAllocations.TryGetValue(id, out recovered))
            {
                order.SetOpeningAllocations(recovered.Key);
                order.SetClosingAllocations(recovered.Value);
                _recoveredAllocations.Remove(id);
            }

            return order;
        }

        public Order CreateSplit(long originalId, Order reference)
        {
            long id = _idGenerator.GetNextOrderId(originalId);
            var order = reference.Clone(id);
            _orders.Insert(order);
            return order;
        }

        OpeningClosingAllocationSnapshot ISnapshotRecoverable<OpeningClosingAllocationSnapshot>.Persist()
        {
            var opening = new List<OrderAllocation>();
            var closing = new List<OrderAllocation>();

            var snap = new OpeningClosingAllocationSnapshot();
            foreach (var order in _orders.GetAll())
            {
                opening.Clear();
                closing.Clear();
                order.GetAllocations(opening, closing);
                var allocations = new List<OpeningClosingAllocationSnapshot.Allocation>();

                for (int i = 0; i < 2; i++)
                {
                    foreach (var alloc in i == 0 ? opening : closing)
                    {
                        allocations.Add(new OpeningClosingAllocationSnapshot.Allocation
                        {
                            Quantity = alloc.Quantity,
                            ClosingPortionSansOmni = alloc.ClosingPortionSansOmni,
                            Side = alloc.Side.ToString(),
                            Portfolio = alloc.Portfolio.Key,
                            CustodianId = alloc.CustodianId,
                            FundId = alloc.FundId,
                            IsOpening = i == 0
                        });
                    }
                }

                snap.Items[order.OrderId] = allocations;
            }

            return snap;
        }

        void ISnapshotRecoverable<OpeningClosingAllocationSnapshot>.Recover(OpeningClosingAllocationSnapshot snapshot)
        {
            _recoveredAllocations.Clear();
            foreach (var item in snapshot.Items)
            {
                var opening = new List<OrderAllocation>();
                var closing = new List<OrderAllocation>();

                foreach (var alloc in item.Value)
                {
                    var target = alloc.IsOpening ? opening : closing;
                    target.Add(new OrderAllocation
                    {
                        Quantity = alloc.Quantity,
                        ClosingPortionSansOmni = alloc.ClosingPortionSansOmni,
                        Side = alloc.Side.AsEnum<Side>(),
                        Portfolio = Portfolio.Parse(alloc.Portfolio),
                        CustodianId = alloc.CustodianId,
                        FundId = alloc.FundId
                    });
                }

                _recoveredAllocations[item.Key] = new KeyValuePair<List<OrderAllocation>, List<OrderAllocation>>(
                    opening, closing);
            }
        }
    }
}
