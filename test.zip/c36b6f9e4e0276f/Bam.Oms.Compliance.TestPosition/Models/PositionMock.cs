﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;

namespace Bam.Oms.Compliance.TestPosition.Models
{
    public struct PositionMock
    {
        public IList<Position> Positions { get; set; }
        public IList<Security> Securities { get; set; }
        public string RefreshTime => DateTime.Now.ToShortDateString();
    }

    public struct Position
    {
        public int SecurityId { get; set; }
        public int Quantity { get; set; }
        public string LastModified => DateTime.Now.ToShortDateString();
    }

    public struct MarketDataInfo
    {
        public int SharesOutstanding { get; set; }
    }

    public struct Security
    {
        public MarketDataInfo MarketDataInfo { get; set; }
        public int SecurityId { get; set; }
        public string DisplayCode { get; set; }
    }
}