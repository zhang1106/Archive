﻿using System;
using System.Collections.Generic;
using System.Linq;
using Moq;
using NUnit.Framework;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Filtering;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class ComplianceSecurityProviderTest
    {
        DWSecurityProvider _DWSecurityProvider;

        [SetUp]
        public void Setup()
        {
            var testSecurities = new List<Security>();
            testSecurities.Add(new Security() { BamSymbol = "IBM", Country = "US", SecurityType = Data.Enumerators.SecurityType.Equity });
            testSecurities.Add(new Security() { BamSymbol = "APPL", Country = "US", SecurityType = Data.Enumerators.SecurityType.Equity });
            var securityProvider = new Mock<ISecurityDBRepository>();
            securityProvider.Setup(n => n.GetSecurities(It.IsAny<IFilter<ISecurity>>())).Returns(testSecurities);
            _DWSecurityProvider = new DWSecurityProvider(securityProvider.Object, null);
        }

        [Test]
        public void TestDWSecurityProviderRefreshData()
        {
            //act
            _DWSecurityProvider.RefreshData();
            //ass
            Assert.IsTrue(_DWSecurityProvider.DWSecurities.Count == 2);
        }

        [Test]
        public void TestDWSecurityProviderGetSecurity()
        {
            //setup
            _DWSecurityProvider.RefreshData();
            //act
            var security = _DWSecurityProvider.GetSecurity("IBM");
            //ass
            Assert.IsTrue(security.BamSymbol == "IBM");
        }
    }
}
