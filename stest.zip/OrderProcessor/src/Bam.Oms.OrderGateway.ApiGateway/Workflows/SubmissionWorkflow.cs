﻿using System;
using System.Linq;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.ApiGateway.Services;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;
using Bam.Oms.OrderGateway.Messages.RefDataGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Workflows
{
    public class SubmissionWorkflow : Workflow<object>,
        IWorkflow<SubmitOrders, object>,
        IWorkflow<CancelOrders, object>,
        IWorkflow<RollbackOrders, object>,
        IWorkflow<RequestLocate, object>,
        IWorkflow<TriggerRouteOrders, object>,
        IWorkflow<LoadSodPositions, object>,
        IWorkflow<BusinessDayChanged, object>,
        IWorkflow<RollBlotter, object>,
        IWorkflow<ToggleOrderScalingRule, object>,
        IWorkflow<CreateSwapConversion, object>,
        IWorkflow<SecurityInsert, object>,
        IWorkflow<OverrideCompliance, object>, 
        IWorkflow<RedirectPbAllocation, object>,
        IWorkflow<HeadroomLoaded, object>,
        IWorkflow<AdjustHeadroomRatios, object>,
        IWorkflow<DisableComplianceRules, object>,
        IWorkflow<UpdateSodPositions, object>
    {
        private readonly IOrderValidator _orderValidator;
        private readonly IOrderAggregator _orderAggregator;

        public SubmissionWorkflow(IOrderValidator orderValidator, IOrderAggregator orderAggregator)
        {
            if (orderValidator == null) throw new ArgumentNullException(nameof(orderValidator));
            if (orderAggregator == null) throw new ArgumentNullException(nameof(orderAggregator));
            _orderValidator = orderValidator;
            _orderAggregator = orderAggregator;
        }

        public void Execute(SubmitOrders input)
        {
            var copyBatch = new SubmitOrders
            {
                BatchName = input.BatchName,
                SubmissionId = input.SubmissionId,
                SubmissionMethod = input.SubmissionMethod,
                User = input.User
            };

            foreach (var order in _orderAggregator.Collapse(input.Items))
            {
                var copyOrder = new SubmitOrders.SubmitOrderLineItem
                {
                    Created = order.Created,
                    BusinessDay = order.BusinessDay,
                    Side = order.Side,
                    Quantity = order.Quantity,
                    LimitPrice = order.LimitPrice,
                    Symbol = order.Symbol,
                    BloombergSymbol = order.BloombergSymbol,
                    UnderlyingSymbol = order.UnderlyingSymbol,
                    SecurityType = order.SecurityType,
                    Custodian = order.Custodian,
                    Portfolio = order.Portfolio,
                    TraderId = order.TraderId,
                    Notes = order.Notes,
                    FailedValidation = order.FailedValidation,
                    ReplaceOrderId = order.ReplaceOrderId,
                    FundAllocationOverride = order.FundAllocationOverride,
                    Urgency = order.Urgency,
                };

                foreach (var orderExecutionInstruction in order.ExecutionInstructions)
                {
                    copyOrder.ExecutionInstructions[orderExecutionInstruction.Key] = orderExecutionInstruction.Value;
                }

                copyBatch.Items.Add(copyOrder);
            }

            _orderValidator.ValidateOrders(copyBatch);

            //sets trader coverage and sec types
            var missingSecurities = _orderValidator.PopulateReferenceData(copyBatch);

            if (missingSecurities.Any())
            {
                var enrich = new EnrichSecurities();
                foreach (var missing in missingSecurities)
                {
                    enrich.Items.Add(missing);
                }

                Publish(enrich);
                Logger?.LogWarning($"Unable to find securities for symbols {missingSecurities.Stringify()}");
            }

            Logger?.LogInformation($"Submitting order batch {copyBatch.BatchName} with {copyBatch.Items.Count} orders.");
            Publish(copyBatch);
        }

        public void Execute(CancelOrders input)
        {
            var message = new CancelOrders {User = input.User};
            foreach (var inputOrderId in input.OrderIds)
            {
                message.OrderIds.Add(inputOrderId);
            }

            Publish(message);
        }

        public void Execute(RollbackOrders input)
        {
            var message = new RollbackOrders {User = input.User};
            foreach (var inputOrderId in input.OrderIds)
            {
                message.OrderIds.Add(inputOrderId);
            }

            Publish(message);
        }

        public void Execute(RequestLocate input)
        {
            var message = new RequestLocate {User = input.User};
            foreach (var inputOrderId in input.OrderIds)
            {
                message.OrderIds.Add(inputOrderId);
            }

            Publish(message);
        }

        public void Execute(TriggerRouteOrders input)
        {
            var message = new TriggerRouteOrders {User = input.User};
            foreach (var item in input.OrderIds)
            {
                message.OrderIds.Add(item);
            }

            Publish(message);
        }

        public void Execute(LoadSodPositions input)
        {
            var message = new LoadSodPositions
            {
                AsOf = input.AsOf,
                User = input.User
            };

            foreach (var inputSodPosition in input.SodPositions)
            {
                message.SodPositions.Add(new LoadSodPositions.SodItem
                {
                    Strategy = inputSodPosition.Strategy,
                    Symbol = inputSodPosition.Symbol,
                    Custodian = inputSodPosition.Custodian,
                    Quantity = inputSodPosition.Quantity,
                    Fund = inputSodPosition.Fund,
                });
            }

            Publish(message);
        }

        public void Execute(RollBlotter input)
        {
            var message = new RollBlotter
            {
                User = input.User,
                RollTime = input.RollTime,
                ForceRoll = input.ForceRoll,
                NextBusinessDay = input.NextBusinessDay
            };
            Publish(message);
        }

        public void Execute(BusinessDayChanged input)
        {
            Publish(new BusinessDayChanged
            {
                User = input.User,
                BusinessDay = input.BusinessDay
            });
        }

        public void Execute(ToggleOrderScalingRule input)
        {
            Publish(new ToggleOrderScalingRule
            {
                OrderScalingRuleId = input.OrderScalingRuleId,
                User = input.User,
                IsActive = input.IsActive
            });
        }

        public void Execute(CreateSwapConversion input)
        {
            var msg = new CreateSwapConversion {User = input.User};
            foreach (var item in input.Items)
            {
                msg.Items.Add(new CreateSwapConversion.LineItem
                {
                    OrderId = item.OrderId,
                    CounterPartyCode = item.CounterPartyCode
                });
            }

            Publish(msg);
        }

        public void Execute(SecurityInsert input)
        {
            var copyBatch = new SecurityInsert();

            foreach (var item in input.Items)
            {
                copyBatch.Items.Add(new SecurityInsert.SecurityInsertItem
                {
                    BamSymbol = item.BamSymbol,
                    BloombergSymbol = item.BloombergSymbol,
                    Country = item.Country,
                    Currency = item.Currency,
                    Cusip = item.Cusip,
                    Failed = item.Failed,
                    Industry = item.Industry,
                    InvestmentType = item.InvestmentType,
                    Isin = item.Isin,
                    Issuer = item.Issuer,
                    QuotingCurrency = item.QuotingCurrency,
                    SecurityType = item.SecurityType,
                    Sedol = item.Sedol,
                    SettlementCurrency = item.SettlementCurrency,
                    Ticker = item.Ticker,
                    TradingCurrency = item.TradingCurrency,
                    UnderlyingSymbol = item.UnderlyingSymbol,
                    PricingFactor = item.PricingFactor,
                    TradingFactor = item.TradingFactor,
                    ConversionRatio = item.ConversionRatio,
                });
            }

            Publish(copyBatch);
        }

        public void Execute(OverrideCompliance input)
        {
            var copy = new OverrideCompliance()
            {
                User = input.User,
                OrderId = input.OrderId,
                OverrideMessage = input.OverrideMessage
            };
            Publish(copy);
        }

        public void Execute(HeadroomLoaded input)
        {
            var copy = new HeadroomLoaded
            {
                Chunk = input.Chunk,
                TotalChunks = input.TotalChunks,
                IsWipeAndLoad = input.IsWipeAndLoad
            };

            foreach (var item in input.Items)
            {
                HeadroomLoaded.Item copyItem;
                copy.Items.Add(copyItem = new HeadroomLoaded.Item()
                {
                    RuleId = item.RuleId,
                    RuleName = item.RuleName,
                    Identifier = item.Identifier,
                    IdentifierType = item.IdentifierType,
                    Side = item.Side,
                    IsExempt = item.IsExempt,
                    Entity = item.Entity,
                    IsContingency = item.IsContingency
                });

                foreach (var headroom in item.Headrooms)
                {
                    copyItem.Headrooms.Add(new HeadroomLoaded.Headroom()
                    {
                        Threshold = headroom.Threshold,
                        AlertLevel = headroom.AlertLevel,
                        HeadRoom = headroom.HeadRoom,
                        FireOnce = headroom.FireOnce
                    });
                }

                item.Ratio.CopyTo(copyItem.Ratio);
            }

            Publish(copy);
        }

        public void Execute(AdjustHeadroomRatios input)
        {
            var msg = new AdjustHeadroomRatios
            {
                User = input.User,
                RuleId = input.RuleId,
                Identifier = input.Identifier
            };
            input.Ratios.CopyTo(msg.Ratios);

            Publish(msg);
        }

        public void Execute(RedirectPbAllocation input)
        {
            var copy = new RedirectPbAllocation
            {
                OrderId = input.OrderId,
                User = input.User
            };
            copy.CustodianRedirection.CopyFrom(input.CustodianRedirection);

            Publish(copy);
        }
		
        public void Execute(DisableComplianceRules input)
        {
            var copy = new DisableComplianceRules {User = input.User};

            foreach (var item in input.Items)
            {
                copy.Items.Add(new DisableComplianceRules.Item()
                {
                    Rule = item.Rule,
                    IsEnabled = item.IsEnabled,
                });
            }

            Publish(copy);
        }

        public void Execute(UpdateSodPositions input)
        {
            var copy = new UpdateSodPositions
            {
                AsOf = input.AsOf,
                User = input.User
            };

            foreach (var sod in input.Items)
            {
                copy.Items.Add(new UpdateSodPositions.SodItem()
                {
                    Strategy = sod.Strategy,
                    Symbol = sod.Symbol,
                    Custodian = sod.Custodian,
                    Fund = sod.Fund,
                    Quantity = sod.Quantity,
                });
            }

            Publish(copy);
        }
    }
}