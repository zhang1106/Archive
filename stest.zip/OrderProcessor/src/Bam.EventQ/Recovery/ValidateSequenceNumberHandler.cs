﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Bam.EventQ.Time;

namespace Bam.EventQ.Recovery
{
    public class ValidateSequenceNumberHandler<TItem> : IQueueItemHandler<PipelineQueueItem<TItem>>
    {
        private readonly IRecoveryInvoker _recoveryInvoker;
        private readonly TimeSpan _recoveryTimeout;
        private readonly IClock _clock;
        private readonly Func<PipelineQueueItem<TItem>, SequenceInfo> _sequenceInfoAccessor;
        private readonly int _selfSourceId;
        private readonly Dictionary<ValidationKey, DateTime> _sourcesInRecoverySince = new Dictionary<ValidationKey, DateTime>();
        private readonly Dictionary<ValidationKey, long> _expectedSequenceNumbers = new Dictionary<ValidationKey, long>();

        public ILogger Logger { get; set; }

        public ValidateSequenceNumberHandler(
            IClock clock, IRecoveryInvoker recoveryInvoker, TimeSpan recoveryTimeout,
            Func<PipelineQueueItem<TItem>, SequenceInfo> sequenceInfoAccessor, int selfSourceId)
        {
            _recoveryInvoker = recoveryInvoker;
            _recoveryTimeout = recoveryTimeout;
            _clock = clock;
            _sequenceInfoAccessor = sequenceInfoAccessor;
            _selfSourceId = selfSourceId;
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            var info = _sequenceInfoAccessor(item);
            var key = new ValidationKey(info.SourceId, info.Topic);

            if (key.SourceId == _selfSourceId)
            {
                return;
            }

            if (key.SourceId == 0)
            {
                item.MarkInvalid();
                Logger?.LogError($"Received message from invalid source '{info.SourceId}'");
                return;
            }

            long expected;
            if (!_expectedSequenceNumbers.TryGetValue(key, out expected))
            {
                expected = _expectedSequenceNumbers[key] = 0;
            }

            if (info.Sequence > expected)
            {
                item.MarkInvalid();
                if (!_sourcesInRecoverySince.ContainsKey(key))
                {
                    _sourcesInRecoverySince[key] = _clock.Now;
                    Logger?.LogWarning(
                        $"Received out of order sequence {info.Sequence} from source {info.SourceId} + topic {info.Topic} (expected {expected}), requesting recovery.");
                    if (!_recoveryInvoker.TryInvoke(info.SourceId, info.Topic, expected))
                    {
                        _sourcesInRecoverySince.Remove(key);
                        Logger?.LogError($"Source {info.SourceId} not available for recovery.");
                    }
                }
                else
                {
                    Logger?.LogDebug($"Received out of order sequence {info.Sequence} from source {info.SourceId} + topic {info.Topic} (expected {expected})");
                    if (_sourcesInRecoverySince[key] + _recoveryTimeout < _clock.Now)
                    {
                        Logger?.LogError($"Failed to recover source {info.SourceId} + topic {info.Topic} within {_recoveryTimeout}, aborting recovery.");
                        _sourcesInRecoverySince.Remove(key);
                    }
                }
            }
            else if (info.Sequence < expected)
            {
                item.MarkInvalid();
                Logger?.LogDebug($"Received sequence {info.Sequence} from source {info.SourceId} + topic {info.Topic} multiple times, ignoring.");
            }
            else
            {
                if (_sourcesInRecoverySince.Remove(key))
                {
                    Logger?.LogInformation($"Successfully recovered source {info.SourceId} + topic {info.Topic} from sequence {expected}.");
                }

                _expectedSequenceNumbers[key]++;
            }
        }

        private struct ValidationKey : IEquatable<ValidationKey>
        {
            public ValidationKey(int sourceId, int topic)
            {
                SourceId = sourceId;
                Topic = topic;
            }

            public int SourceId { get; }
            private int Topic { get; }

            public bool Equals(ValidationKey other)
            {
                return SourceId == other.SourceId && Topic == other.Topic;
            }

            public override bool Equals(object obj)
            {
                if (ReferenceEquals(null, obj)) return false;
                return obj is ValidationKey && Equals((ValidationKey)obj);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    return (SourceId * 397) ^ Topic;
                }
            }

            public static bool operator ==(ValidationKey left, ValidationKey right)
            {
                return left.Equals(right);
            }

            public static bool operator !=(ValidationKey left, ValidationKey right)
            {
                return !left.Equals(right);
            }
        }
    }
}
