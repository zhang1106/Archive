﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public abstract class FileListenerSettings : AppSettingsBase
    {
        protected FileListenerSettings(string listener) :
            base($"ApiGateway.{listener}.")
        {
        }

        public string Path
        {
            get { return GetValue(() => Path); }
        }

        public string ArchivePath
        {
            get { return GetValue(() => ArchivePath); }
        }

        public string ErrorPath
        {
            get { return GetValue(() => ErrorPath); }
        }
    }
}