﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;
using NUnit.Framework;
using Moq;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class PositionCalculatorTest
    {
        [Test]
        public void TestEquityEtfLongCalc()
        {
            var positions = new List<IPosition>()
            {
                Factory.CreatePosition("IBM", "IBM", "IbmIsin", 1000, InvestmentType.ETF),
                Factory.CreatePosition("IBM", "IBM",  "IbmIsin", -500, InvestmentType.ETF),
            };

            var posProvider = CreatePositionProvider(positions);

            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Long).Item2 == 1000);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Short).Item2 == -500);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Net).Item2 == 500);
        }

        [Test]
        public void TestEquityLongCalc()
        {
            var positions = new List<IPosition>()
            {
                Factory.CreatePosition("IBM", "IBM", "IbmIsin", 1000),
                Factory.CreatePosition("IBM", "IBM", "IbmIsin", -500),
            };

            var posProvider = CreatePositionProvider(positions);

            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Long).Item2 == 1000);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Short).Item2 == -500);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Net).Item2 == 500);
        }

        [Test]
        public void TestEquityOptionCallLongCalc()
        {
            var positions = new List<IPosition>()
            {
                Factory.CreateOptionPosition("IBM", "IbmIsin", 5, OptionType.Call, InvestmentType.Equity),
                Factory.CreateOptionPosition("IBM", "IbmIsin", -5, OptionType.Call, InvestmentType.Equity),
            };

            var posProvider = CreatePositionProvider(positions);

            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Long).Item2 == 500);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Short).Item2 == -500);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Net).Item2 == 0);
        }

        [Test]
        public void TestEquityOptionCallWarrantAndRightLongCalc()
        {
            var positions = new List<IPosition>()
            {
                 Factory.CreateOptionPosition("IBM", "IbmIsin", 5, OptionType.Call, InvestmentType.WarrantAndRight),
                Factory.CreateOptionPosition("IBM", "IbmIsin", -5, OptionType.Call, InvestmentType.WarrantAndRight),
            };

            var posProvider = CreatePositionProvider(positions);

            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Long).Item2 == 500);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Short).Item2 == -500);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Net).Item2 == 0);
        }

        [Test]
        public void TestEquityOptionPutLongCalc()
        {
            var positions = new List<IPosition>()
            {
                 Factory.CreateOptionPosition("IBM", "IbmIsin", 5, OptionType.Put, InvestmentType.Equity),
                Factory.CreateOptionPosition("IBM", "IbmIsin", -5, OptionType.Put, InvestmentType.Equity),
            };

            var posProvider = CreatePositionProvider(positions);

            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Long).Item2 == 500);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Short).Item2 == -500);
            Assert.IsTrue(posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Net).Item2 == 0);
        }
        
        [Test]
        public void TestEquityShortCalc()
        {
            var positions = new List<IPosition>()
            {
                Factory.CreatePosition("IBM", "IBM", "IbmIsin", 200),
                Factory.CreatePosition("IBM2", "IBM", "IbmIsin", 800),
                Factory.CreatePosition("IBM", "IBM", "IbmIsin", -500),
            };

            var posProvider = CreatePositionProvider(positions);
            
            var pos = posProvider.GetEntityWideQuantityByIsin("IBM", PositionType.SodDecomposed, "BAM", SideType.Net).Item2;
            
            Assert.IsTrue(pos == 500);
        }

        [Test]
        public void TestEquityOptionCallShortCalc()
        {
            var positions = new List<IPosition>()
            {
                Factory.CreateOptionPosition("IBM", "IbmIsin", 10, OptionType.Call, InvestmentType.Equity),
                Factory.CreateOptionPosition("IBM", "IbmIsin", -5, OptionType.Call, InvestmentType.Equity),
            };

            var posProvider = CreatePositionProvider(positions); ;

            var pos = posProvider.GetFirmWideQuantity("IBM", PositionType.Sod, SideType.Net).Item2;

            Assert.IsTrue(pos == 500);
        }

        [Test]
        public void TestEquityOptionPutShortCalc()
        {
            var positions = new List<IPosition>()
            {
                 Factory.CreateOptionPosition("IBM", "IbmIsin", 10, OptionType.Put, InvestmentType.Equity),
                Factory.CreateOptionPosition("IBM", "IbmIsin", -5, OptionType.Put, InvestmentType.Equity),
            };

            var posProvider = CreatePositionProvider(positions);

            var pos = posProvider.GetEntityWideQuantityByIsin("IBM", PositionType.SodDecomposed, "BAM", SideType.Net).Item2;

            Assert.IsTrue(pos == -500);
        }

        [Test]
        public void TestEquityWithAdrCalc()
        {
            var positions = new List<IPosition>()
            {
                Factory.CreatePosition("IBM", "IBM", "IbmIsin", 5),
                Factory.CreatePosition("IBM", "IBM", "IbmIsin", 5),
                Factory.CreatePosition("IBM", "IBM", "IbmIsin", -5),
                Factory.CreatePosition("Adr1", "Adr1", "Adr1Isin", 5), //adrRatio = 1
                Factory.CreatePosition("Adr2", "Adr2","Adr1Isin", 5), //adrRatio = 1 
                Factory.CreatePosition("Adr3", "Adr3","Adr2Isin", 10), //adrRatio = 2
            };

            var posProvider = CreatePositionProvider(positions);

            var pos = posProvider.GetFirmWideQuantityWithAdr("IBM", PositionType.SodDecomposed, SideType.Long).Item2;

            var isinPos = posProvider.GetEntityWideQuantityByIsin("IBM", PositionType.SodDecomposed, "BAM", SideType.Net).Item2;
            

            Assert.IsTrue(pos == 40);

            Assert.IsTrue(isinPos == 35);
        }

        private IPositionCalculator CreateCalculator()
        {
            var securityProvider = new Mock<ISecurityProvider>();
            securityProvider.Setup(s => s.GetSecurity(It.IsAny<string>())).Returns(Factory.CreateSecurity("IBM","IBM", "IbmIsin"));
            securityProvider.Setup(s => s.GetADRs(It.IsAny<string>())).Returns(new[] {Factory.CreateAdrSecurity("Adr1", "Adr1Isin", 1)
                , Factory.CreateAdrSecurity("Adr2", "Adr1Isin",1)
                , Factory.CreateAdrSecurity("Adr3", "Adr2Isin",2)
            });

            var customData = new Mock<ICustomDataProvider>();
            customData.Setup(c => c.GetEntity(It.IsAny<string>())).Returns("BAM");
            customData.SetupGet(c => c.LinkedSecurities).Returns(new ConcurrentDictionary<string, IList<ISecurity>>());
            
            var calculator = new PositionCalculator(securityProvider.Object, customData.Object, new Mock<ILogger>().Object);

            return calculator;
        }


        private IHoldingProvider CreateHoldingProvider(IList<IPosition> positions)
        {
            var holdingProvider = new Mock<IHoldingProvider>();
            holdingProvider.SetupGet(h => h.IntradayPositions)
                .Returns(positions);
            holdingProvider.SetupGet(h => h.SodPositions)
                .Returns(positions);
            holdingProvider.SetupGet(h => h.DecomposedSodByIsin).Returns(positions.ToLookup(p => p.Security.Isin));
            holdingProvider.SetupGet(h => h.SodByUnderlying)
                .Returns(positions.ToLookup(p => p.Security.UnderlyingSymbol));
            holdingProvider.SetupGet(h => h.DecomposedSodByUnderlying).Returns(positions.ToLookup(p => p.Security.UnderlyingSymbol));
            holdingProvider.Setup(h => h.GetData(It.IsAny<PositionType>(), PositionIndex.Underlying)).Returns(positions.ToLookup(p => p.Security.UnderlyingSymbol));
            holdingProvider.Setup(h => h.GetData(It.IsAny<PositionType>(), PositionIndex.Isin)).Returns(positions.ToLookup(p => p.Security.Isin));

            return holdingProvider.Object;
        }


        private IPositionProvider CreatePositionProvider(IEnumerable<IPosition> positions)
        {
            return new PositionProvider(CreateHoldingProvider(positions.ToList()), CreateCalculator(), new Mock<ISecurityProvider>().Object,  new Mock<Logger>().Object);
        }
    }
}
