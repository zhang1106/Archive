﻿using System;

namespace Bam.EventQ.Time
{
    public class FrozenClock : Clock
    {
        private DateTime _now;

        public FrozenClock(string zoneId, TimeZoneInfo timeZoneInfo) :
            base(zoneId, timeZoneInfo) 
        {            
            // ReSharper disable VirtualMemberCallInConstructor
            _now = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZoneInfo);
            BusinessDate = Now.Date;
            // ReSharper restore VirtualMemberCallInConstructor
        }

        public FrozenClock(DateTime now, string zoneId, TimeZoneInfo timeZoneInfo) : 
            base(zoneId, timeZoneInfo)
        {
            _now = now;
            // ReSharper disable once VirtualMemberCallInConstructor
            BusinessDate = now.Date;
        }

        public override DateTime Now => _now;

        public void SetNow(DateTime now)
        {
            _now = now;
        }

        public void SetTimestamp(int timestamp)
        {
            long delta = timestamp*(TimeSpan.TicksPerMillisecond/20);
            long now = BusinessDate.Ticks + delta;
            _now = new DateTime(now);
        }
    }
}
