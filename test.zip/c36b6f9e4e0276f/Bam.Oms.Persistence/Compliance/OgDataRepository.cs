﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Bam.Compliance.Infrastructure.Database;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using BAM.Infrastructure.Ioc;
using Dapper;

namespace Bam.Oms.Persistence.Compliance
{
    public class OgDataRepository : IOgDataRepository
    {
        internal static readonly Func<dynamic, DtdPosition> SodMap = item => new DtdPosition()
        {
            BamSymbol = item.BAMSymbol,
            Quantity = (long)item.Qty,
            Portfolio = item.StrategyCode,
            Fund = item.FundCode,
            Custodian = item.CustodianAccountCode,
            TradeDate = item.EntryDate,
            SysDate = item.LastModifiedOn,
            Stream = item.Stream,
            NetExposure = item.NetExposure
        };
        

        private const string IsinQuery = @"SELECT distinct [shs_isin]
                                            FROM [OrderGateway].[cp].[EUShortExemptedSecurities] e (nolock)";

        private const string EodQuery = @" DECLARE @sodDate DATETIME
                                        SELECT @sodDate = MAX(TradeDate) FROM [OrderGatewayMain].[og].[EodPosition2]
                                        SELECT [BamSymbol]  ,[Quantity]  ,[Portfolio] ,[Fund] ,[Custodian]  ,[TradeDate]  ,[SysDate], NetExposure = 0 
                                        FROM [OrderGatewayMain].[og].[EodPosition2] WHERE TradeDate = @sodDate AND NOT Custodian LIKE 'OMNI%'
                                        ";

        private const string EodSyncCheck = @"  DECLARE @sodDate DATETIME, @eodDate DATETIME
                                            SELECT @eodDate = MAX(TradeDate) FROM [OrderGatewayMain].[og].[EodPosition2]
                                            SELECT @sodDate = MAX(EntryDate) FROM [OrderGatewayMain].[sod].[Position]
                                            SELECT Same = 1 where @eodDate > @sodDate";

        private const string SodSyncCheck = @" DECLARE  @numOfTradeDatesMain int, @maxEodTradeDate DATETIME
                                        SELECT @numOfTradeDatesMain = COUNT(distinct EntryDate) FROM [OrderGatewayMain].[sod].[Position]
                                        SELECT @maxEodTradeDate = MAX(TradeDate) FROM [OrderGatewayMain].[og].[EodPosition2]
                                        SELECT top 1 Same = 1 FROM [OrderGatewayMain].[sod].[Position] WHERE @numOfTradeDatesMain = 1 and entrydate >= @maxEodTradeDate
                                        ";
 
        private const string SodOverrideQuery = @"
                                DECLARE @tradeDate DATETIME
                                SELECT @tradeDate = MAX(TradeDate) FROM [OrderGatewayMain].[og].[EodPosition2]
                                SELECT *, NetExposure = Qty*Price FROM [OrderGatewayMain].[sod].[Position] WHERE EntryDate = @tradeDate and not CustodianName LIKE 'OMNI%'
                                ";

        private const string SodAllQuery = @" 
                                                SELECT *, NetExposure = Qty*Price FROM [OrderGatewayMain].[sod].[Position]
	                                            WHERE  not CustodianName LIKE 'OMNI%'
                                            ";
        
        private readonly ISettings _settings;
        private readonly ILogger _logger;

        public OgDataRepository(ISettings settings, ILogger logger)  
        {
            _settings = settings;
            _logger = logger;
        }

        protected IDbConnection Connection => new SqlConnection(_settings.OrderGatewayConnectionString);

        public  HashSet<string> GetEuExemptedIsins()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var result = cn.Query<string>(IsinQuery);
                    var set = new HashSet<string>();
                    set.UnionWith(result);
                    return set;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving records from BamCorelite Security", e);
                throw;
            }
        }

        public IEnumerable<DtdPosition> GetEodPositions()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var result = cn.Query<DtdPosition>(EodQuery);
                   
                    return result;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving contingencey from ems gateway", e);
                throw;
            }
        }

      

        public bool IsContingencyPositionsSynced()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var query = string.Format(EodSyncCheck);
                    var result = cn.Query<dynamic>(query);

                    return result.Any();
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving contingencey from ems gateway", e);
                throw;
            }
        }

        public IEnumerable<DtdPosition> GetAllSodPositions()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var query = string.Format(SodAllQuery);
                    var result = cn.Query<dynamic>(query).Select(SodMap);

                    return result;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving contingencey from ems gateway", e);
                throw;
            }

        }

        public bool IsSodPositionsSynced()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var query = string.Format(SodSyncCheck);
                    var result = cn.Query<dynamic>(query);

                    return result.Any();
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving sod from ems gateway", e);
                throw;
            }
        }

        public IEnumerable<DtdPosition> GetLoadedSodPositions()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var query = string.Format(SodOverrideQuery);
                    var result = cn.Query<dynamic>(query).Select(SodMap);

                    return result;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving contingencey from ems gateway", e);
                throw;
            }

        }


        public void DumpPositions(IEnumerable<FlatPosition> positions)
        {
            using (var conn = new SqlConnection(_settings.OrderGatewayConnectionString))
            {
                conn.Open();
                var db = new DbOperation(conn);
                db.SaveItems(positions, "cp.FlatPosition");
            }
        }
    }
}
