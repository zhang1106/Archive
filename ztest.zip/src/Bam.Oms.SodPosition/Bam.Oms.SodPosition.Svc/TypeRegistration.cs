﻿using Bam.Oms.Persistence.DBContext;
using Bam.Oms.SodPosition.Svc.File;
using BAM.Infrastructure.Ioc;
using System;
using System.Configuration;
using Bam.Oms.RefData;

namespace Bam.Oms.SodPosition.Svc
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            try
            {
                //   container.RegisterInstance<IMappingEngine>(MappingEngineFactory.GetSodPositionMapper());
                container.RegisterType<ILogger, Logger>(RegistrationType.Singleton);
                var logger = container.Resolve<ILogger>();
                var dirPath = ConfigurationManager.AppSettings["sodPosition_incoming_path"];
                if (string.IsNullOrWhiteSpace(dirPath))
                {
                    throw new ArgumentException("Couldn't find the sodPosition_incoming_path set in the application config");
                }

                var sodPositionDBContext = container.Resolve<SodPositionDBContext>();

                container.RegisterInstance<IFileLoading>(new FileLoading(dirPath, logger, sodPositionDBContext));
                container.RegisterType<ISodPositionEdit, SodPositionEditDapper>(RegistrationType.Singleton, 
                    new InjectionConstructor(typeof (ILogger), typeof (IFileLoading), sodPositionDBContext, typeof(IAccountService), typeof(ISecurityMasterService)));
            }
            catch (Exception ex)
            {
                var logger = container.Resolve<ILogger>();
                logger.Fatal($"Unable to construct Sod Svc {ex.Message} {ex.StackTrace}");
            }
        }
    }
}
