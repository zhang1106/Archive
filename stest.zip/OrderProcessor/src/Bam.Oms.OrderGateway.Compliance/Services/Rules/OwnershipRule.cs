﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;
using Bam.Oms.OrderGateway.Compliance.Services.Headroom;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.Compliance;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public abstract class OwnershipRule : EventRelay<IMessage>, IRule
    {
        private readonly IModelIndex<HeadroomRule> _rules;
        private readonly List<HeadroomRule> _filtered;
        private readonly IHeadroomEffectCache _effectCache;
        private readonly bool _monitoringMode;
        private readonly Dictionary<HeadroomCheckKey, HeadroomCheck> _latestViolations;
        private readonly HashSet<string> _coveredSecurityTypes, _contingencyResults;

        public abstract string Name { get; }

        protected OwnershipRule(IIndexFactory index, IHeadroomEffectCache effectCache,
            IEnumerable<string> coveredSecurityTypes, bool monitoringMode)
        {
            _rules = index.For<HeadroomRule>();
            _effectCache = effectCache;
            _monitoringMode = monitoringMode;
            _filtered = new List<HeadroomRule>(64);
            _latestViolations = new Dictionary<HeadroomCheckKey, HeadroomCheck>();
            _contingencyResults = new HashSet<string>();
            _coveredSecurityTypes = new HashSet<string>(
                coveredSecurityTypes, StringComparer.OrdinalIgnoreCase);
        }

        protected abstract bool ShouldExecute(HeadroomRule rule, Order order);

        public void Execute(RuleContext context, List<RuleViolation> violations)
        {
            if (CanSkip(context.Order))
                return;

            _contingencyResults.Clear();
            _filtered.Clear();
            bool handled = false;
            var rules = _rules.GetAll();
            var security = context.Order.Security;
            
            // ReSharper disable once ForCanBeConvertedToForeach
            for (int i = 0; i < rules.Count; i++)
            {
                var rule = rules[i];
                if (!handled)
                {
                    handled |= rule.Handles(security);
                }

                if (ShouldExecute(rule, context.Order))
                {
                    _filtered.Add(rule);
                }
            }

            if (!handled)
            {
                if (!_monitoringMode)
                {
                    violations.Add(new RuleViolation
                    {
                        RuleName = Name,
                        Message = "no headroom available",
                        Level = ComplianceViolationLevel.ComplianceOverrideable,
                        Status = context.IsDryRun ? ComplianceStatus.RequireHeadroom : ComplianceStatus.RuleFailure
                    });
                }
                else
                {
                    violations.Add(new RuleViolation
                    {
                        RuleName = Name,
                        Message = "no headroom available",
                        Level = ComplianceViolationLevel.Warning,
                        Status = ComplianceStatus.Success
                    });
                }

                return;
            }

            foreach (var rule in _filtered)
            {
                var currentEffect = _effectCache.GetEffect(context.Order.OrderId,
                    rule.Id, rule.GetIdentifier(context.Order.Security));

                bool suppress = context.SuppressedRules.Contains(rule.Name);

                HeadroomCheck previous;
                decimal? suppressedThreshold = null;
                var headroomCheckKey = new HeadroomCheckKey(context.Order.OrderId, rule.Id);
                if (suppress && _latestViolations.TryGetValue(headroomCheckKey, out previous))
                {
                    suppressedThreshold = previous.Threshold;
                }

                HeadroomCheck check;
                bool breached;
                if (rule.TryCheck(context.Order, currentEffect, suppressedThreshold, out breached, out check))
                {
                    context.AuditTrail[$"{rule.Name} SOD"] = check.StartOfDayQuantity;
                    context.AuditTrail[$"{rule.Name} Intraday"] = check.IntradayQuantity;

                    if (check.IsContingency)
                    {
                        _contingencyResults.Add(context.Order.Security.FindUltimateUnderlying().Symbol);
                    }

                    if (breached)
                    {
                        _latestViolations[headroomCheckKey] = check;
                        string percentage = check.Threshold.ToString("0.########## %");

                        if (check.StartOfDayQuantity == 0)
                        {
                            AddViolation(violations, rule.Name,
                                ComplianceViolationLevel.ComplianceOverrideable,
                                "no headroom available");
                        }
                        else
                        {
                            AddViolation(violations, rule.Name, check.ViolationLevel,
                                $"Exceeded {percentage} threshold");
                        }
                    }
                    else if (!suppress)
                    {
                        _latestViolations.Remove(headroomCheckKey);
                    }
                }
            }

            if (_contingencyResults.Count > 0 && !_monitoringMode)
            {
                var msg = new RequireHeadroom();
                msg.UnderlyingSymbols.AddRange(_contingencyResults);
                Publish(msg);
            }
        }

        private void AddViolation(List<RuleViolation> violations, string rule,
            ComplianceViolationLevel violationLevel, string message)
        {
            if (_monitoringMode)
            {
                violationLevel = ComplianceViolationLevel.Warning;
            }

            violations.Add(new RuleViolation
            {
                RuleName = rule,
                Message = message,
                Level = violationLevel,
                Status = violationLevel == ComplianceViolationLevel.Warning 
                    ? ComplianceStatus.Success
                    : ComplianceStatus.RuleFailure
            });
        }
        
        protected virtual bool CanSkip(Order order)
        {
            return order.IsOmni || !_coveredSecurityTypes.Contains(order.Security.SecurityType);
        }
    }
}
