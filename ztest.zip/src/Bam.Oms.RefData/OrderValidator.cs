﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.RefData
{
    public class OrderValidator : IOrderValidator
    {
        private readonly IAccountService _accountService;
        private readonly ISecurityMasterService _securityMasterService;
        private readonly ILogger _logger;
        private readonly ILoggingSerializer _loggingSerializer;

        public OrderValidator(IAccountService accountService, ISecurityMasterService securityMasterService, ILogger logger, ILoggingSerializer loggingSerializer)
        {
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (loggingSerializer == null) throw new ArgumentNullException(nameof(loggingSerializer));
            _accountService = accountService;
            _securityMasterService = securityMasterService;
            _logger = logger;
            _loggingSerializer = loggingSerializer;
        }

        public bool IsValidOrder(IList<IOrder> orders)
        {
            //            //will need to eventually check securities too
            return IsValidStrategy(orders) && IsValidSecurity(orders) && IsValidSize(orders);
        }

        private bool IsValidSize(IList<IOrder> orders)
        {
            return orders.All(r => r.Size > 0);
        }

        private bool IsValidStrategy(IList<IOrder> orders)
        {
            var uniqueStrategies = orders.Select(r => r.Portfolio.ToString()).Distinct().ToList();
            var validStrategies = _accountService.IsValidStrategy(uniqueStrategies);

            if (validStrategies.Any(r => !r.Value))
            {
                _logger.Error($"Invalid strategies {_loggingSerializer.Serialize(validStrategies.Where(r => !r.Value).Select(r => r.Key).ToList())}");
                return false;
            }

            return true;
        }

        private bool IsValidSecurity(IList<IOrder> order)
        {
            var uniqueSecurities = order.Select(r => r.Security.BamSymbol).Distinct().ToList();
            var securityList = _securityMasterService.IsValidSecurity(uniqueSecurities);

            foreach (var o in order)
            {
                if (securityList.ContainsKey(o.Security.BamSymbol) && !securityList[o.Security.BamSymbol])
                {
                    o.OrderStatus = BamOrderStatus.Error;
                    o.StatusMessages.Add("Security not found in security master");
                }
            }

            //we now always allow order even with missing/unknown securities to pass thru
            return true;
        }
    }
}