﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Persistence
{
    public class PersistenceException : Exception
    {
        public PersistenceException(string failedItem, int itemsAffected, string message) : base(message)
        {
            AffectedItems = itemsAffected;
            FailedItem = failedItem;
        }

        public int AffectedItems { private set; get; }
        public string FailedItem { private set; get; }

    }
}
