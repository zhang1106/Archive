﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.Policies;

namespace Bam.Oms.Compliance
{
    public class FirmPositionComplianceEngine : IEngine<CompliancePosition>
    {
        public Dictionary<string, IPolicy<CompliancePosition>> Policies { get; private set; }
        public FirmPositionComplianceEngine()
        {
            Policies = new Dictionary<string, IPolicy<CompliancePosition>>();
        }
        public void RegisterPolicy (IPolicy<CompliancePosition> policy)
        {
            ((FirmPositionLimitPolicy)policy).PopulateRules();
            Policies.Add(policy.Name, policy);
        }
        /// <summary>
        /// check for violations against a policy by speicify policy ID or name
        /// </summary>
        public IPolicyResult CheckViolations(IPolicy<CompliancePosition> policy, CompliancePosition input, bool isPreCheck)
        {
            return policy.CheckViolations(input, isPreCheck);
        }
        public IPolicy<CompliancePosition> GetPolicy(string name)
        {
            return Policies[name];
        }
    }
}
