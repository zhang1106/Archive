﻿namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public struct OrderIndexKey
    {
        public string TradeId { get; set; }
        public string Strategy { get; set; }

        public string Symbol { get; set; }

        public OrderIndexKey(string tradeId, string strategy, string symbol)
        {
            TradeId = tradeId;
            Strategy = strategy;
            Symbol = symbol;
        }
        
        public bool Equals(OrderIndexKey other)
        {
            return string.Equals(TradeId, other.TradeId) && string.Equals(Strategy, other.Strategy) && string.Equals(Symbol, other.Symbol);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = TradeId?.GetHashCode() ?? 0;
                hashCode = (hashCode*397) ^ (Strategy?.GetHashCode() ?? 0);
                hashCode = (hashCode*397) ^ (Symbol?.GetHashCode() ?? 0);
                return hashCode;
            }
        }
    }
}
