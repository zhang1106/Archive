﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.DataProvider
{
    public class MarketDataProvider : IMarketDataProvider
    {
        private readonly ICustomDataProvider _customDataProvider;
        private readonly IBbMarketDataProvider _bbMarketDataProvider;
        private readonly ISecurityProvider _securityProvider;
        private readonly ILogger _logger;

        public ConcurrentDictionary<string, MarketData> CurrentMarketData { get; set; }

        public HashSet<string> CheckedInBb { set; get; }

        public MarketDataProvider(IDwRepository dwRepository, ICustomDataProvider customDataProvider, IBbMarketDataProvider bbMarketDataProvider,
            ISecurityProvider securityProvider,
            ILogger logger)
        {
            _logger = logger;
            _customDataProvider = customDataProvider;
            _bbMarketDataProvider = bbMarketDataProvider;
            _securityProvider = securityProvider;
            CheckedInBb = new HashSet<string>();
            //init market data from DW data
            CurrentMarketData = new ConcurrentDictionary<string, MarketData>(dwRepository.GetMarketData());
        }

        public void RefreshData()
        {
            CurrentMarketData = new ConcurrentDictionary<string, MarketData>();
            CheckedInBb = new HashSet<string>();
        }
        
        public IEnumerable<MarketData> GetBbData(IEnumerable<string> symbols)
        {
            try
            {
                var ary = symbols.Where(s=>!CheckedInBb.Contains(s)).ToArray();

                _logger.Info($"BB: check bb for {ary.Length} securities");

                var bbData = _bbMarketDataProvider.GetMarketDataList(ary).ToList();

                CheckedInBb.UnionWith(ary);

                foreach (var m in bbData)
                {
                     CurrentMarketData.AddOrUpdate(m.Symbol, m, (key, old) => m);
                }

                return bbData;
            }
            catch (Exception ex)
            {
                _logger.Error($"Unable to load BB data - {ex.Message}");
            }

            return null;
        }

        public void CheckMarketData(IEnumerable<string> underlyings, out IList<string> notExist)
        {
            notExist = underlyings.Where(s => !CurrentMarketData.ContainsKey(s) || CurrentMarketData[s].SharesOutstanding==null||CurrentMarketData[s].SharesOutstanding==0).ToList();
        }
        
        public decimal? GetPrice(string bamSymbol)
        {
            var marketData = CurrentMarketData.ContainsKey(bamSymbol) ? CurrentMarketData[bamSymbol] : null;
            if (marketData != null || !CheckBbData) return marketData?.PriceInDollar;

            _logger.Info("No cached sharesoutstanding found for " + bamSymbol);
            _logger.Info("Check Bloomberg for " + bamSymbol);
            var bbMarkdata = _bbMarketDataProvider.GetMarketData(bamSymbol);

            //add in the cache
            if (bbMarkdata != null) CurrentMarketData[bamSymbol] = bbMarkdata;
            _logger.Info($"Get market data from Bloomberg for {bamSymbol}");

            return bbMarkdata?.PriceInDollar;
        }

        /// <summary>
        /// get shares outstanding by bamsymbol
        /// </summary>
        /// <param name="bamSymbol"></param>
        /// <returns></returns>
        public long? GetSharesOutstanding(string bamSymbol)
        {
            //use any of the linked security to get shares
            var security = _securityProvider.GetSecurity(bamSymbol);
            if (security == null) return null;

            var linked = _securityProvider.SecuritiesByIsin[security.Isin].Select(s=>s.UnderlyingSymbol).Distinct();

            //check linked custom share first
            foreach (var s in linked)
            {
                var shares = _customDataProvider.GetSharesOutstanding(s);
                if (shares != null && shares != 0) return (long?)shares;
            }

            //check current market data
            foreach (var s in linked)
            {
                var shares = CurrentMarketData.ContainsKey(s) ? CurrentMarketData[s].SharesOutstanding : null;
                if (shares != null && shares != 0) return (long?)shares;
            }
            
            if (!CheckBbData) return null;

            _logger.Info("No cached sharesoutstanding found for " + bamSymbol);
            _logger.Info("Check Bloomberg for " + bamSymbol);
            var bbMarkdata = _bbMarketDataProvider.GetMarketData(bamSymbol);

            //add in the cache
            if (bbMarkdata != null) CurrentMarketData[bamSymbol] = bbMarkdata;
            _logger.Info($"Get market data from Bloomberg for {bamSymbol}");

            return bbMarkdata?.SharesOutstanding;
            //
        }

        public long? GetCustomizedShareOutstanding(string symbol)
        {
            if (!_customDataProvider.LinkedSecurities.ContainsKey(symbol))
                return (long?)_customDataProvider.GetSharesOutstanding(symbol) ?? GetSharesOutstanding(symbol);

            long? result = 0;
            foreach (var s in _customDataProvider.LinkedSecurities[symbol])
            {
                result += (long?)_customDataProvider.GetSharesOutstanding(symbol) ?? GetSharesOutstanding(symbol);
            }

            return result;
        }

        public bool CheckBbData { get; set; }
    }

   
}
