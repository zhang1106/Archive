﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.EndPoints.Orders
{
    public interface IFlowManager : IDisposable
    {
        IList<IOrder> ProcessOrders(List<IOrder> orders, string batchId = null, bool fromFile = false);
        
        IList<IOrder> RouteOrders(IList<string> orderIds, string entryUser);
        IList<IOrder> ProcessDeleteOrders(IList<string> orderIds);
        IList<IOrder> ProcessCancelOrders(IList<string> orderIds);

        DateTime RollSod(DateTime? dateTimeToRollTo);

        void RunContingency();
        void PublishOrders(bool eod, FlowClientScope scope);
        void PublishTrades(bool eod, FlowClientScope scope);

        void RequestLocates(IList<string> orderIds);

        IList<Position> ReplacePositions(IList<Position> position);
        event Action FlowManagerInitialized;
        event Action<IOrder> OrderStateChanged;
        event Action<IList<IOrder>> OrdersStateChanged;
        event Action<IBlockTrade> TradeStateChanged;
        event Action<IList<IBlockTrade>> TradesStateChanged;
        event Action<IList<Order>> OrdersOnEOD;
        event Action<IList<BlockTrade>> TradesOnEOD;
        event Action<IList<Position>> PositionsOnEOD;
        event Action<DateTime> SODRolled;        
    }

}
