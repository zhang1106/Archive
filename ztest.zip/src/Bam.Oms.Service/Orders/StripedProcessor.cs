﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Schedulers;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.PositionTracker;
using Bam.Oms.RefData;
using Bam.Oms.ShortLocate;
using Bam.Oms.TradeMarker;
using BAM.Infrastructure.Ioc;
using Newtonsoft.Json;

namespace Bam.Oms.Service.Orders
{
    public class StripedProcessor : IDisposable, IStripedProcessor
    {
        private readonly IPositionTracker _positionTracker;
        private readonly IOrderMarker _orderMarker;
        private readonly IOrderRepository _orderRepository;
        private readonly ITradeRepository _tradeRepository;
        private readonly IEmsRouter _emsRouter;
        private readonly ILocateService _locateService;
        private readonly IAccountService _accountService;


        private readonly ISettings _settings;
        private readonly ILogger _logger;

        private readonly CancellationTokenSource _orderTaskCancellation = new CancellationTokenSource();
        private readonly OrderedTaskScheduler _processorScheduler = new OrderedTaskScheduler();

        private long _totalOrdersProcessed = 0;
        private volatile bool _initialized = true;
        private readonly object _locker = new Object();

        public long TotalOrdersProcessed
        {
            get { return _totalOrdersProcessed; }
            set { _totalOrdersProcessed = value; }
        }

        public HashSet<string> SubscribedSymbols { get; } = new HashSet<string>();

        public event Action<IOrder> OrderStatusChanged;
        public event Action<IList<IOrder>> OrdersStatusChanged;
        public event Action<ITrade> TradeStatusChanged;
        public event Action<IList<ITrade>> TradesStatusChanged;

        public StripedProcessor(IEmsRouter emsRouter, ILocateService locateService, IPositionTracker positionTracker, IOrderMarker orderMarker, IOrderRepository orderRepository, ITradeRepository tradeRepository, IAccountService accountService, ISettings settings, ILogger logger)
        {
            _settings = settings;
            _logger = logger;
            _locateService = locateService;
            _emsRouter = emsRouter;
            _positionTracker = positionTracker;
            _orderMarker = orderMarker;
            _orderRepository = orderRepository;
            _tradeRepository = tradeRepository;
            _accountService = accountService;

            _emsRouter.OrderStatusChanged += this.EmsRouterOnOrderStatusChanged;
            _emsRouter.TradeUpdated += this.EmsRouterOnTradeUpdated;
        }

        public bool SetInitialized(bool initialized)
        {
            lock (_locker)
            {
                bool returnValue = _initialized;
                _initialized = initialized;
                if (initialized)
                {
                    Monitor.PulseAll(_locker);
                }
                return returnValue;
            }
        }

        public void AddSubscribedSymbol(string symbol)
        {
            SubscribedSymbols.Add(symbol);
            _positionTracker.SubscribedSymbols.Add(symbol);
        }

        public async Task<IOrder> GetOrderAsync(string orderId)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return GetOrder(orderId);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public IOrder SaveOrder(IOrder order, string batchId = null)
        {
            if (order.Size <= 0 || order.Side == SideType.Unknown)
            {
                _logger.Warn($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Ignoring an order of zero size or unknown side. Order:{order}.");
                return null;
            }

            Utility.RaiseEvent(order, OrderStatusChanged);
            return _orderRepository.Save((Order)order);
        }

        public async Task<IOrder> SaveOrderAsync(IOrder order, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                if (order.Size <= 0 || order.Side == SideType.Unknown)
                {
                    _logger.Warn($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Ignoring an order of zero size or unknown side. Order:{order}.");
                    return null;
                }
                Utility.RaiseEvent(order, OrderStatusChanged);
                return _orderRepository.Save((Order)order);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public ITrade SaveTrade(ITrade trade, string batchId = null)
        {
            return _tradeRepository.Save((Trade)trade);
        }

        public async Task<ITrade> SaveTradeAsync(ITrade trade, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }

                return _tradeRepository.Save((Trade)trade);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public IOrder DeleteOrder(IOrder order, string batchId = null)
        {
            Utility.RaiseEvent(order, OrderStatusChanged);
            return _orderRepository.Remove((Order)order);
        }

        public async Task<IOrder> DeleteOrderAsync(IOrder order, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                Utility.RaiseEvent(order, OrderStatusChanged);
                return _orderRepository.Remove((Order)order);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public IList<IOrder> SaveOrders(IList<IOrder> orders, string batchId = null)
        {
            Utility.RaiseEvent(orders, OrdersStatusChanged);
            foreach (IOrder order in orders)
            {
                _orderRepository.Save((Order)order);
            }
            return orders;
        }

        public async Task<IList<IOrder>> SaveOrdersAsync(IList<IOrder> orders, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return new List<IOrder>();
                }
                foreach (IOrder order in orders)
                {
                    this.SaveOrder(order, batchId);
                }
                return orders;
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }


        public IList<IOrder> ProcessOrder(string orderId)
        {
            IOrder order = GetOrder(orderId);
            if (order != null)
            {
                return ProcessOrder(order, order.BatchId);
            }
            return new List<IOrder>();
        }

        public async Task<IList<IOrder>> ProcessOrderAsync(string orderId)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                IOrder order = GetOrder(orderId);
                if (order != null)
                {
                    return ProcessOrder(order, order.BatchId);
                }
                return new List<IOrder>();
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public IList<IOrder> ProcessOrder(IOrder order, string batchId = null)
        {
            try
            {
                IList<IOrder> markedOrders = order.OrderStatus == BamOrderStatus.Error || order.OrderStatus == BamOrderStatus.PendingValidation ? MarkOrder(order, batchId) : new List<IOrder>() { order };
                order.OrderStatus = BamOrderStatus.PendingSend;
                markedOrders = SaveOrders(markedOrders, batchId);
                if (markedOrders.Any(o => o.Side == SideType.SellShort && o.LocateStatus != LocateStatus.Approved))
                {
                    markedOrders = this.LocateShorts(markedOrders, batchId);
                    markedOrders = SaveOrders(markedOrders, batchId);
                }
                markedOrders = markedOrders.Where(o => o.RoutedSize > 0).ToList();
                if (markedOrders.Any())
                {
                    IList<IOrder> submittedOrders = SubmitOrders(markedOrders, batchId);
                    submittedOrders = SaveOrders(submittedOrders, batchId);
                    return submittedOrders;
                }
                else
                {
                    _logger.Info($"[BatchId:{batchId} ignoring orders with RoutedSize <= 0. Ignored Orders: {order}.");
                }
                return new List<IOrder>();
            }
            catch (AggregateException ae)
            {
                throw ae.Flatten();
            }
        }

        public async Task<IList<IOrder>> ProcessOrderAsync(IOrder order, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return ProcessOrder(order, order.BatchId);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public IList<IOrder> ReplaceOrder(IOrder order)
        {
            IOrder originalOrder = GetOrder(order.OriginalOrderId);
            if (originalOrder == null)
            {
                return ProcessOrder(order, order.BatchId);
            }
            RevertOrder(order, order.BatchId);
            BamOrderStatus originalOrderStatus = originalOrder.OrderStatus;
            originalOrder.OrderStatus = BamOrderStatus.PendingCancel;
            SaveOrder(originalOrder, originalOrder.BatchId);

            IList<IOrder> markedOrders = MarkOrder(order, order.BatchId);

            IOrder sameSideOrder = markedOrders.FirstOrDefault(o => o.Side == originalOrder.Side);
            IList<IOrder> sideChangedOrders = markedOrders.Where(o => o.Side != originalOrder.Side).ToList();

            IList<IOrder> amendedOrders = new List<IOrder>() { sameSideOrder };
            if (sameSideOrder != null)
            {
                IOrder amendedOrder = AmendOrder(sameSideOrder);
                amendedOrders = SaveOrders(amendedOrders, sameSideOrder.BatchId);
                if (amendedOrders.Any())
                {
                    foreach (IOrder rejectedOrder in amendedOrders.Where(o => o.OrderStatus == BamOrderStatus.Error))
                    {
                        RevertOrder(rejectedOrder, order.BatchId);
                    }
                    originalOrder.OrderStatus = originalOrderStatus;
                    TrackOrder(originalOrder);
                }
                else // All orders were rejected. backout all of them
                {
                    RevertOrders(amendedOrders);
                    originalOrder.OrderStatus = originalOrderStatus;
                    TrackOrder(originalOrder);
                }
            }

            if (!sideChangedOrders.Any()) return amendedOrders;

            foreach (IOrder submittedOrder in ProcessOrder(order, order.BatchId))
            {
                amendedOrders.Add(submittedOrder);
            }
            return amendedOrders;
        }

        public async Task<IList<IOrder>> ReplaceOrderAsync(IOrder order)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return ReplaceOrder(order);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public IOrder CancelOrder(IOrder order)
        {
            try
            {
                if (!this.SubscribedSymbols.Contains(order.Security.BamSymbol))
                {
                    return order;
                }

                IOrder originalOrder = GetOrder(order.ClientOrderId);
                if (originalOrder == null)
                {
                    _logger.Warn(
                        $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId} is unknown to the Gateway. Cancel request ignored.");
                    return order;
                }
                order = originalOrder;
                _logger.Debug($"Cancelling order {order}.");
                switch (originalOrder.OrderStatus)
                {
                    case BamOrderStatus.PendingValidation:
                    case BamOrderStatus.Cancelled:
                        originalOrder.OrderStatus = BamOrderStatus.Cancelled;
                        return originalOrder;
                    case BamOrderStatus.PendingSend:
                    case BamOrderStatus.IncompleteLocate:
                    case BamOrderStatus.PendingLocate:
                        RevertOrder(order, order.BatchId);
                        originalOrder.OrderStatus = BamOrderStatus.Cancelled;
                        return originalOrder;
                    case BamOrderStatus.Error:
                    case BamOrderStatus.Filled:
                    case BamOrderStatus.Finalized:
                        _logger.Error($"[BatchId:{originalOrder.BatchId},OrderId:{originalOrder.ClientOrderId}] Order state is {originalOrder.OrderStatus}. Order cannot be cancelled.");
                        return originalOrder;
                    default:
                        originalOrder.OrderStatus = BamOrderStatus.PendingCancel;
                        //IList<string> cancelledOrderIds =
                        //    _emsRouter.CancelOrders(new List<string>() { originalOrder.ClientOrderId });                        
                        return originalOrder;
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Exception while cancelling order {order}.", ex);
                return order;
            }
            finally
            {
                SaveOrder(order, order.BatchId);
            }
        }

        public async Task<IOrder> CancelOrderAsync(IOrder order)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return CancelOrder(order);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public async Task<IList<IOrder>> CancelOrderAsync(IList<IOrder> orders)
        {
            return await Task.Factory.StartNew(() =>
            {
                IList<IOrder> ordersCancelled = new List<IOrder>();
                foreach (IOrder order in orders)
                {
                    if (_orderTaskCancellation.Token.IsCancellationRequested)
                    {
                        _logger.Info("Cancellation requested. Aborting task...");
                        return ordersCancelled;
                    }
                    IOrder cancelledOrder = CancelOrder(order);
                    if (cancelledOrder != null)
                    {
                        ordersCancelled.Add(cancelledOrder);
                    }
                }
                return ordersCancelled;
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public IList<IOrder> MarkOrder(IOrder order, string batchId = null)
        {
            Interlocked.Increment(ref _totalOrdersProcessed);

            if (order.Size <= 0 || order.Side == SideType.Unknown)
            {
                _logger.Warn($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Ignoring an order of zero size or unknown side. Order:{order}.");
                return new List<IOrder>();
            }

            try
            {
                //_logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] begin marking order:{order}.");
                IList<IOrder> mkdOrders = _orderMarker.MarkOrder(order);
                //_logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] completed marking order:{order}.");

                //_logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] begin position tracking orders:{JsonConvert.SerializeObject(mkdOrders)}.");
                foreach (IOrder mkdOrder in mkdOrders)
                {
                    _positionTracker.ApplyPositionUpdate(mkdOrder);
                }
                //_logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] completed position tracking orders:{JsonConvert.SerializeObject(mkdOrders)}.");
                //set the routed size for all these trades
                foreach (var orderToSubmit in mkdOrders.Where(o => o.Side != SideType.SellShort)) //only update routed size for non-shorts, the locates will be batched after this method
                    orderToSubmit.RoutedSize = orderToSubmit.Size;
                return mkdOrders;
            }
            catch (Exception ex)
            {
                _logger.Error($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Error while marking order {order}.", ex);
                throw;
            }
        }

        public async Task<IList<IOrder>> MarkOrderAsync(IList<IOrder> orders, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                List<IOrder> markedOrders = new List<IOrder>();
                foreach (IOrder order in orders)
                {
                    if (_orderTaskCancellation.Token.IsCancellationRequested)
                    {
                        _logger.Info("Cancellation requested. Aborting task...");
                        return markedOrders;
                    }
                    markedOrders.AddRange(MarkOrder(order, batchId));
                }
                return markedOrders;
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public async Task<IList<IOrder>> MarkOrderAsync(IOrder order, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return new List<IOrder>();
                }
                return MarkOrder(order, batchId);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public void RevertOrder(IOrder order, string batchId)
        {
            if (order.Size <= 0 || order.Side == SideType.Unknown)
            {
                _logger.Warn(
                    $"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Ignoring RevertTheoreticalPosition of an order of zero size or unknown side. Order:{order}.");
                return;
            }
            try
            {
                _logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Reverting order {order}.");
                _positionTracker.ApplyOrderCancel(order);
                _logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}]Completed reverting order {order}.");
            }
            catch (Exception ex)
            {
                _logger.Error($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Error while processing RevertTheoreticalPosition of order {order}.", ex);
                _logger.Error($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Theoretical position may be incorrect because the order was NAK'ed and not reverted. Order: {order}.");
            }
            return;
        }

        public async Task RevertOrderAsync(IOrder order, string batchId)
        {
            await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return;
                }
                RevertOrder(order, batchId);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public void RevertOrders(IList<IOrder> orders)
        {
            foreach (IOrder revertedOrder in orders)
            {
                RevertOrder(revertedOrder, revertedOrder.BatchId);
            }
            return;
        }

        public async Task RevertOrdersAsync(IList<IOrder> orders)
        {
            await Task.Factory.StartNew(() =>
            {
                foreach (IOrder revertedOrder in orders)
                {
                    RevertOrder(revertedOrder, revertedOrder.BatchId);
                }
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public async Task<IList<IOrder>> RevertOrdersAsync(IEnumerable<string> orderIds)
        {
            return await Task.Factory.StartNew(() =>
            {
                IList<IOrder> cancelledOrders = new List<IOrder>();
                foreach (string orderId in orderIds)
                {
                    if (_orderTaskCancellation.Token.IsCancellationRequested)
                    {
                        _logger.Info("Cancellation requested. Aborting task...");
                        return cancelledOrders;
                    }
                    var originalOrder = _orderRepository.Get(orderId);
                    if (originalOrder == null)
                    {
                        _logger.Error($"[OrderId:{orderId}] Order not found in cache while processing RevertOrder.");
                        _logger.Error($"[OrderId:{orderId}] Theoretical position may be incorrect because the order was not reverted.");
                        continue;
                    }
                    if (!this.SubscribedSymbols.Contains(originalOrder.Security.BamSymbol))
                    {
                        continue;
                    }
                    this.RevertOrder(originalOrder, originalOrder.BatchId);
                    cancelledOrders.Add(originalOrder);
                }
                return cancelledOrders;
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);

        }

        public IPosition TrackTrade(ITrade trade)
        {
            try
            {
                var originalOrder = _orderRepository.Get(trade.ClientOrderId);
                if (originalOrder == null)
                {
                    _logger.Info($"[OrderId:{trade.ClientOrderId}] Unable to find order in cache, skipping trade update");
                    return null;
                }
                var hydratedTrade = new Trade()
                {
                    Security = originalOrder.Security,
                    TradedQuantity = trade.TradedQuantity,
                    Fund = trade.Fund,
                    PrimeBroker = trade.PrimeBroker,
                    Portfolio = trade.Portfolio,
                    Side = originalOrder.Side,
                    AveragePrice = trade.AveragePrice,
                    ClientOrderId = trade.ClientOrderId,
                    SettleDate = originalOrder.SettleDate,
                    TradeDate = originalOrder.TradeDate,
                    Status = trade.Status,
                    TradeStatus = trade.TradeStatus,
                    PrimeBrokerAccount = "", //TODO: Lookup PB Account from Reference Data Service
                    TradeId = trade.TradeId,
                    FxRate = 1.0m, // Default
                    TradeCurrency = trade.TradeCurrency,
                    BaseCurrency = trade.BaseCurrency,
                    TradeTimeStamp = trade.TradeTimeStamp
                };
                return _positionTracker.ApplyPositionUpdate(hydratedTrade);
            }
            catch (Exception ex)
            {
                _logger.Error($"[OrderId:{trade.ClientOrderId}] Error while tracking trade {trade}. Exception {1}.", ex);
                throw;
            }
        }

        public async Task<IPosition> TrackTradeAsync(ITrade trade)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return TrackTrade(trade);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public IPosition TrackOrder(IOrder order)
        {
            try
            {
                var originalOrder = _orderRepository.Get(order.ClientOrderId);
                if (originalOrder == null)
                {
                    _logger.Info($"[OrderId:{order.ClientOrderId}] Unable to find order in cache, skipping order update");
                    return null;
                }
                originalOrder.OrderStatus = order.OrderStatus;
                return _positionTracker.ApplyPositionUpdate(originalOrder);
            }
            catch (Exception ex)
            {
                _logger.Error($"[OrderId:{order.ClientOrderId}] Error while tracking order {order}.", ex);
                throw;
            }
        }

        public async Task<IPosition> TrackOrderAsync(IOrder order)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    ;
                    return null;
                }

                return TrackOrder(order);
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public async Task<IList<IOrder>> SetStateAsync(IEnumerable<string> orderIds, BamOrderStatus orderStatus)
        {
            return await Task.Factory.StartNew(() =>
            {
                IList<IOrder> orders = new List<IOrder>();
                foreach (string orderId in orderIds)
                {
                    if (_orderTaskCancellation.Token.IsCancellationRequested)
                    {
                        _logger.Info("Cancellation requested. Aborting task...");
                        return orders;
                    }
                    var originalOrder = _orderRepository.Get(orderId);
                    if (originalOrder == null)
                    {
                        _logger.Error($"[OrderId:{orderId}] Order not found in cache while processing RevertOrder.");
                        _logger.Error(
                            $"[OrderId:{orderId}] Theoretical position may be incorrect because the order was not reverted.");
                        continue;
                    }
                    if (!this.SubscribedSymbols.Contains(originalOrder.Security.BamSymbol))
                    {
                        continue;
                    }
                    originalOrder.OrderStatus = orderStatus;
                    Utility.RaiseEvent(originalOrder, OrderStatusChanged);
                    _orderRepository.Save(originalOrder);
                    orders.Add(originalOrder);
                }
                return orders;
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public async Task<IList<Position>> LoadSODPositionsAsync(IList<Position> sodPositions)
        {
            return await Task.Factory.StartNew(() =>
            {
                List<Position> positions = new List<Position>();
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return positions;
                }
                var orders = _orderRepository.GetAllOrders();
                var trades = _tradeRepository.GetAllTrades();
                positions.AddRange(_positionTracker.LoadSODPositions(sodPositions, orders, trades).Cast<Position>());

                return positions;
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public async Task<IList<Position>> UpdateSODPositionsAsync(IList<Position> sodPositions)
        {
            return await Task.Factory.StartNew(() =>
            {
                List<Position> positions = new List<Position>();
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return positions;
                }
                positions.AddRange(_positionTracker.UpdateSODPositions(sodPositions).Cast<Position>());

                return positions;
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        public async Task<IList<Position>> UpdatePositionsAsync(IList<Position> positions)
        {
            return await Task.Factory.StartNew(() =>
            {
                List<Position> positionsReplaced = new List<Position>();
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return positionsReplaced;
                }
                positionsReplaced.AddRange(_positionTracker.UpdatePositions(positions).Cast<Position>());

                return positions;
            }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
        }

        private IOrder GetOrder(string orderId)
        {
            IOrder order = _orderRepository.Get(orderId);
            return order;
        }

        private ITrade GetTrade(string tradeId)
        {
            ITrade trade = _tradeRepository.Get(tradeId);
            return trade;
        }

        private IList<IOrder> SubmitOrders(IList<IOrder> orders, string batchId = null)
        {
            _logger.Info($"[BatchId:{batchId}] Submitting {orders.Count} orders.");
            return _emsRouter.SubmitOrders(orders).ToList();
        }

        private IOrder AmendOrder(IOrder order)
        {
            _logger.Info($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] Amending order {order}.");
            order.OrderStatus = BamOrderStatus.PendingSend;
            return _emsRouter.AmendOrder(order, order.OriginalOrderId);
        }


        private IList<IOrder> LocateShorts(IList<IOrder> markedOrders, string batchId = null)
        {
            _logger.InfoFormat($"[BatchId:{batchId}] Running short locate for batch.");
            try
            {
                //make a sync call to get shorts
                var shortOrders = markedOrders.Where(o => o.Side == SideType.SellShort);
                _logger.InfoFormat($"[BatchId:{batchId}] has {shortOrders.Count()} short orders for locate.");
                var fullyLocatedShortOrders = LocateShortForOrdersWrap(shortOrders);

                //set the routed size for all these trades
                foreach (var orderToSubmit in fullyLocatedShortOrders)
                    orderToSubmit.RoutedSize = orderToSubmit.Size;

                _logger.InfoFormat($"[BatchId:{batchId}] Completed running short locate{0}.");
                return markedOrders;
            }
            catch (Exception ex)
            {
                _logger.Error($"[BatchId:{batchId}] Error while locating shorts for {JsonConvert.SerializeObject(markedOrders)}.", ex);
                throw;
            }
        }

        //TODO: Move this to Short locate proxy/facade
        private IEnumerable<IOrder> LocateShortForOrdersWrap(IEnumerable<IOrder> shortOrders)
        {
            //request short locate, completely filled orders will go downstream
            var shortLocateRequests = shortOrders.Select(s => new LocateRequest(s, s.Custodian));

            if (!shortLocateRequests.Any()) return new List<IOrder>(); //return an empty list

            var locateResponses = _locateService.RequestForInventory(shortLocateRequests);
            return locateResponses;
        }

        private void EmsRouterOnTradeUpdated(IEnumerable<ITrade> trades)
        {
            if (trades == null || !trades.Any()) return;
            try
            {
                Task.Factory.StartNew(() =>
                {
                    Stopwatch sw = Stopwatch.StartNew();
                    if (!_initialized)
                    {
                        lock (_locker)
                        {
                            while (!_initialized)
                            {
                                Monitor.Wait(_locker, 60000);
                            }
                        }
                    }
                    var processedTrades = new List<ITrade>();
                    foreach (ITrade trade in trades)
                    {
                        try
                        {
                            IOrder order = this.GetOrder(trade.ClientOrderId);
                            if (order == null) continue;
                            if (!this.SubscribedSymbols.Contains(order.Security.BamSymbol))
                            {
                                continue;
                            }                            

                            //Set reqd properties from the original order
                            trade.Portfolio = order.Portfolio;
                            trade.Security = order.Security;
                            trade.TradeDate = order.TradeDate;
                            trade.SettleDate = order.SettleDate;
                            trade.Trader = order.Trader;
                            trade.Side = order.Side;

                            ITrade tradeFromRepo = this.GetTrade(trade.TradeId);
                            if (tradeFromRepo != null)
                            {
                                trade.TradeStatus = BamTradeStatus.Modified;
                            }

                            _logger.Info(
                                    $"From FLEX -> [OrderId:{trade.ClientOrderId},TradeId:{trade.TradeId}] Processing trade update {trade}.");
                            IPosition position = this.TrackTrade(trade);
                            if (position != null)
                            {
                                _logger.Info(
                                        $"From FLEX -> [OrderId:{trade.ClientOrderId},TradeId:{trade.TradeId}] Resulting position is {position}");
                            }
                            _tradeRepository.Save(new List<Trade>() { (Trade)trade });
                            _logger.Info(
                                    $"From FLEX -> [OrderId:{trade.ClientOrderId},TradeId:{trade.TradeId}] Completed processing trade update {trade}.");
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Exception procesing order updates. {trade}", ex);
                        }
                        processedTrades.Add(trade);
                    }
                    Utility.RaiseEvent(processedTrades, TradesStatusChanged);
                    sw.Stop();
                    _logger.Debug($"From FLEX Trades Update took {sw.ElapsedMilliseconds} ms for {processedTrades.Count} out of {trades.Count()} trades. checksum: {trades.Sum(t => t.TradedQuantity)}-{trades.Sum(t => t.AveragePrice)}");
                }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error($"[OrderId:{trades.First().ClientOrderId},TradeId:{trades.First().TradeId}] Exception while processing trade {trades}.", ex);
                    return true;
                });
            }
        }

        private void EmsRouterOnOrderStatusChanged(IEnumerable<IOrder> orders)
        {
            if (orders == null || !orders.Any()) return;
            try
            {
                Task.Factory.StartNew(() =>
                {
                    Stopwatch sw = Stopwatch.StartNew();
                    if (!_initialized)
                    {
                        lock (_locker)
                        {
                            while (!_initialized)
                            {
                                Monitor.Wait(_locker, 60000);
                            }
                        }
                    }
                    var processedOrders = new List<IOrder>();
                    foreach (IOrder order in orders)
                    {
                        try
                        {
                            IOrder updatedOrder = this.GetOrder(order.ClientOrderId);
                            if (updatedOrder?.Security == null) continue;
                            if (!this.SubscribedSymbols.Contains(updatedOrder.Security.BamSymbol))
                            {
                                continue;
                            }
                            _logger.Info(
                                $"From FLEX -> [BatchId:{updatedOrder.BatchId},OrderId{updatedOrder.ClientOrderId}] Processing order update {updatedOrder}.");

                            BamOrderStatus oldStatus = updatedOrder.OrderStatus;                            
                            updatedOrder.OrderStatus = order.OrderStatus;

                            if (oldStatus == BamOrderStatus.Cancelled && updatedOrder.OrderStatus != BamOrderStatus.Finalized)
                            {
                                _logger.Error($"[BatchId:{updatedOrder.BatchId},OrderId{updatedOrder.ClientOrderId}] Order is already cancelled. Ignoring further updates, except finalized status.");
                                continue;
                            }
                            updatedOrder.StatusMessages.AddRange(order.StatusMessages);
                            
                            if ((oldStatus != BamOrderStatus.Error && updatedOrder.OrderStatus == BamOrderStatus.Error)
                                ||
                                (oldStatus != BamOrderStatus.Cancelled && updatedOrder.OrderStatus == BamOrderStatus.Cancelled)
                            )
                            {
                                _logger.Info(
                                    $"[BatchId:{updatedOrder.BatchId},OrderId{updatedOrder.ClientOrderId}] Order status from Flex is {updatedOrder.OrderStatus} and old status is {oldStatus}. Reverting.");
                                this.RevertOrder(updatedOrder, order.BatchId);
                            }
                            processedOrders.Add(updatedOrder);
                            _logger.Info(
                                $"From FLEX -> [BatchId:{updatedOrder.BatchId},OrderId{updatedOrder.ClientOrderId}] Completed processing order update {updatedOrder}.");
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Exception procesing order updates. {order}", ex);
                        }
                    }
                    this.SaveOrders(processedOrders);
                    sw.Stop();
                    _logger.Debug($"From FLEX Order Update took {sw.ElapsedMilliseconds} ms for {processedOrders.Count} out of {orders.Count()} orders.");
                }, _orderTaskCancellation.Token, TaskCreationOptions.None, _processorScheduler);
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error(
                        $"[BatchId:{orders.First().BatchId}] Exception {ex} while processing order status change {JsonConvert.SerializeObject(orders)}.");
                    return true;
                });
            }
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _orderTaskCancellation.Cancel();
                    _emsRouter.OrderStatusChanged -= EmsRouterOnOrderStatusChanged;
                    _emsRouter.TradeUpdated -= EmsRouterOnTradeUpdated;
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~StripedProcessor() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }

        #endregion
    }
}
