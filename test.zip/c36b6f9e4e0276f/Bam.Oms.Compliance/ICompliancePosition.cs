﻿using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance
{
    public interface ICompliancePosition
    {
        ICompliancePosition Init(ISecurity security, IPolicy<ICompliancePosition> policy, PositionType type);
        string BamSymbol { get;}
        int PolicyId { get; } 
        IPolicy<ICompliancePosition> Policy { get;}
        ISecurity Security { get;   }
        PositionType PositionType { get; set; }
        
        IFactProvider FactProvider { get; }
        IPositionProvider PositionProvider { get; }
        IOwnershipRuleResultProvider RuleResultProvider { get; }
        ISecurityProvider SecurityProvider { get; }
        IMarketDataProvider MarketDataProvider { get; }
        ICustomDataProvider CustomDataProvider { get; }
        IRuleResultRepository RuleResultRepository { get; }
        ILogger Logger { get; }
        IHelper Helper { get; }

        string UnderlyingSymbol { get; }
    }
}
