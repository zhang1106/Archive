﻿using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Enumerators;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class ComplianceThreshholdWarningTests
    {
        [Test]
        [TestCase(0.15, MovingDirection.FallBelow)]
        [TestCase(0.01, MovingDirection.Exceed)]
        [TestCase(0.05, MovingDirection.NoChange)]
        public void TestGetMovingDirection( decimal lastLowLimit, MovingDirection direction)
        {
            var warning = new ThreshholdWarning() { LowLimit = 0.05m, UpLimit = 0.1m };
            var thisDirection = warning.GetMovingDirection(lastLowLimit);
            Assert.IsTrue(direction == thisDirection);
        }
        [Test]
        public void TestGetMovingDirectionNoHistory()
        {
            var warning = new ThreshholdWarning() { LowLimit = 0.05m, UpLimit = 0.1m };
            var thisDirection = warning.GetMovingDirection(null);
            Assert.IsTrue(thisDirection == MovingDirection.NoHistory);
        }
       [Test]
        [TestCase(0.06, 0.11, 0.10, ComplianceAlertLevel.FallBelowWarning)]
        [TestCase(0.06, 0.07, 0.05, ComplianceAlertLevel.NoAlertLevelChange)]
        [TestCase(0.06, 0.03, 0.0, ComplianceAlertLevel.ExceedWarning)]
        [TestCase(0.02, 0.03, 0.0, ComplianceAlertLevel.NoViolation)]
        public void TestGetAlertlevel(decimal currentVal, decimal lastVal, decimal lastLowLimit, ComplianceAlertLevel alert)
        {
            var warning = new ThreshholdWarning() { LowLimit = 0.05m, UpLimit = 0.1m };
            var thisAlert = warning.GetAlertlevel(currentVal, lastVal, lastLowLimit);
            Assert.IsTrue(alert == thisAlert);
            //[TestCase(0.06, 0.03, null, ComplianceAlertLevel.Warning)]
        }
        [Test]
        [TestCase(0.03, false)]
        [TestCase(0.06, true)]
        [TestCase(0.16, false)]
        public void TestIsInCurentWarningArea(decimal currentVal, bool inAreaa)
        {
            var warning = new ThreshholdWarning() { LowLimit = 0.05m, UpLimit = 0.1m };
            var rslt = warning.IsInCurentWarningArea(currentVal);
            Assert.IsTrue(rslt == inAreaa);
        }
    }
}
