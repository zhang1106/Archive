﻿CREATE TABLE [cp].[PolicyRuleAudit] (
    [PolicyRuleAuditId] INT          NOT NULL,
    [PolicyRuleId]      INT          NOT NULL,
    [PolicyId]          INT          NOT NULL,
    [RuleId]            INT          NOT NULL,
    [CreatedOn]         DATETIME     NOT NULL,
    [CreatedBy]         VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([PolicyRuleAuditId] ASC)
);

