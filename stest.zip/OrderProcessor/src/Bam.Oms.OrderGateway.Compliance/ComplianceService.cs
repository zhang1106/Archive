﻿using System.Collections.Generic;
using Bam.EventQ.Hosting;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Transport;

namespace Bam.Oms.OrderGateway.Compliance
{
    public class ComplianceService : PipelinesWithRpcServiceBase
    {
        public ComplianceService(
            IEnumerable<IProcessingPipeline> pipelines, IRpcServer rpcServer) 
            : base(pipelines, rpcServer)
        {
        }

        public override string Name => "Compliance";
    }
}
