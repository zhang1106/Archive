﻿namespace Bam.Oms.Data.Enumerators
{
    public enum LocateStatus //TODO: these are duplicates of the BrokerLocateStatus from the locate service, these need to get consolidated
    {
        New,
        Pending,
        Denied,
        Approved,
        Partial,
        TimedOut,
        Error
    }
}