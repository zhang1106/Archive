﻿using System;
using CsvHelper.Configuration;

namespace Bam.Oms.SodPosition.Svc.File
{
    public sealed class PositionMap : CsvClassMap<PositionRecord>
    {
        public PositionMap()
        {
            Map(m => m.AssetType).Name("SecurityType");
            Map(m => m.BAMSymbol).Name("Symbol");
            Map(m => m.Ccy).Name("Currency");
            Map(m => m.FXRate).Name("FxRate");
            Map(m => m.FXRate).ConvertUsing(row =>
            {
                var fxRateString = row.GetField("FxRate").ToString();
                decimal fxRate;
                if (!string.IsNullOrWhiteSpace(fxRateString) && decimal.TryParse(fxRateString, out fxRate))
                {
                    return fxRate;
                }
                return 1.0m;
            });            
            Map(m => m.Price).ConvertUsing(row =>
            {
                var priceString = row.GetField("Price").ToString();
                decimal price;
                if (!string.IsNullOrWhiteSpace(priceString) && decimal.TryParse(priceString, out price))
                {
                    return price;
                }
                return 0.0m;
            });
            Map(m => m.Qty).Name("Qty");
            Map(m => m.StrategyCode).Name("Strategy");
            Map(m => m.Cost).Name("Cost");
            Map(m => m.CustodianName).Name("Custodian");
            Map(m => m.CustodianAccountCode).Name("CustodianAccount");
            Map(m => m.FundCode).Name("Fund");
            Map(m => m.Cost).Name("CostPrice");
        }
    }
}
