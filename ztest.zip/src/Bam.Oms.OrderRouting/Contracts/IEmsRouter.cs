﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using BAM.Infrastructure.Ioc;
using Ft;
using Grpc.Core;

namespace Bam.Oms.OrderRouting.Contracts
{
    /// <summary>
    /// Contract for sending orders to an execution management system
    /// </summary>
    public interface IEmsRouter : IEmsSubscriptionAdapter, IEmsRequestResponseAdapter
    {
        /// <summary>
        /// Notify EMS to cancel a list of orders, by order id
        /// </summary>
        /// <param name="orderIds"></param>        
        /// <returns>A list of successfully canceled ids.  Failures will be omitted.</returns>
        [Log]
        IList<string> CancelOrders(IList<string> orderIds);

        /// <summary>
        /// Submits an amendment to an existing order, with option to stage.  Default auto routes to EMS
        /// </summary>
        /// <param name="order"></param>
        /// <param name="originalClientOrderId"></param>
        /// <param name="stageOrders"></param>
        /// <returns></returns>
        [Log]
        IOrder AmendOrder(IOrder order, string originalClientOrderId, bool stageOrders = false);                      
    }
}