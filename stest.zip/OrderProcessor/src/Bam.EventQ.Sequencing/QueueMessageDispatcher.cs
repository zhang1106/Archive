﻿using System;
using System.Threading;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Bam.EventQ.Recovery;
using Bam.EventQ.Time;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Sequencing
{
    public class QueueMessageDispatcher : IQueueMessageDispatcher
    {
        private readonly IClock _clock;
        private readonly IMessageTopicProvider<IMessage> _topicProvider;
        private readonly int _sourceId;

        private static readonly ThreadLocal<byte[]> SerializeBuffer
            = new ThreadLocal<byte[]>(() => new byte[1024*1024], false);

        public QueueMessageDispatcher(IClock clock, IMessageTopicProvider<IMessage> topicProvider, int sourceId)
        {
            _clock = clock;
            _topicProvider = topicProvider;
            _sourceId = sourceId;
        }

        public void Dispatch(IQueue<PipelineQueueItem<IMessage>> queue, IMessage message)
        {
            byte[] buffer = SerializeBuffer.Value;
            message.Header = new SequenceInfo(_sourceId, _topicProvider.GetTopic(message), 0, _clock.Timestamp);

            retry:
            int count;
            try
            {
                count = MessageSerializer.Current.Serialize(message, buffer, 0);
            }
            catch (NotSupportedException) // memory stream not expandable
            {
                buffer = new byte[buffer.Length * 2];
                goto retry;
            }

            var batch = queue.AllocateBatch(1);
            queue[batch.Start].Clear();
            queue[batch.Start].EnsureBufferSize(count);
            Buffer.BlockCopy(buffer, 0,
                queue[batch.Start].Buffer.Array, queue[batch.Start].Buffer.Offset, count);
            queue[batch.Start].SetBufferLength(count);

            queue.PublishBatch(batch);
        }
    }
}