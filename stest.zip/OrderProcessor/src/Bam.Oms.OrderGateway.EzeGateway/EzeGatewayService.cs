﻿using System.Collections.Generic;
using Bam.EventQ.Hosting;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Transport;

namespace Bam.Oms.OrderGateway.EzeGateway
{
    public class EzeGatewayService : PipelinesWithRpcServiceBase
    {
        private readonly IService _httpService;

        public EzeGatewayService(
            IEnumerable<IProcessingPipeline> pipelines, 
            IRpcServer rpcServer, IService httpService) 
            : base(pipelines, rpcServer)
        {
            _httpService = httpService;
        }

        public override void Start() 
        {
            base.Start();
            _httpService.Start();
        }

        public override void Stop() 
        {
            _httpService.Stop();
            base.Stop();
        }

        public override string Name => "EZE Gateway";
    }
}
