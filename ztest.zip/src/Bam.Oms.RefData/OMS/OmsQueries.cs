﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.RefData.OMS
{
    public static class OmsQueries
    {
        public const string SelectScaling = @"SELECT SourcePortfolio, DestinationPortfolio, SecurityType, ScaleFactor FROM dbo.OrderScaleFactor WHERE ScaleFactor > 0";
    }
}
