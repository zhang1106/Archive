﻿using System.Collections.Generic;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Pipeline
{
    public class MessageFilterTransform<TIn, TOut> : IQueueItemTransformer<TIn, TOut> where TOut : class
    {
        private readonly List<TOut> _returnList = new List<TOut>();

        public IReadOnlyList<TOut> Transform(TIn item, long sequence, bool isReplay)
        {
            _returnList.Clear();

            var message = item as TOut;
            if (message != null)
            { 
                _returnList.Add(message);
            }

            return _returnList;
        }
    }
}