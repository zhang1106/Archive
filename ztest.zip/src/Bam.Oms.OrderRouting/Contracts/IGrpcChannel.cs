﻿using System;
using Grpc.Core;

namespace Bam.Oms.OrderRouting.Contracts
{
    public interface IGrpcChannel 
    {
        /// <summary>
        /// Wrapper around the Grpc Channel State
        /// </summary>
        ChannelState ChannelState { get; }

        Channel Channel { get; }

        /// <summary>
        /// This is purposely not from IDisposable to avoid the Container from cleaning this up non-determinstically
        /// </summary>
        void Dispose();
    }
}