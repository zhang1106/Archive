﻿CREATE TABLE [cp].[RuleAudit] (
    [RuleAuditId]    INT           NOT NULL,
    [RuleId]         INT           NULL,
    [Name]           VARCHAR (100) NOT NULL,
    [Description]    VARCHAR (200) NULL,
    [IsActive]       BIT           NOT NULL,
    [StartDate]      DATETIME      NULL,
    [EndDate]        DATETIME      NULL,
    [ParamsInJson]   VARCHAR (MAX) NULL,
    [CreatedOn]      DATETIME      NOT NULL,
    [CreatedBy]      VARCHAR (50)  NULL,
    [LastModifiedOn] DATETIME      NOT NULL,
    [LastModifiedBy] VARCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([RuleAuditId] ASC)
);

