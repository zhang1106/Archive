﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public interface IContingencyRecordRepository
    {
        Task<IReadOnlyList<ContingencyRecord>> Load();
        Task Save(IReadOnlyList<ContingencyRecord> records);
    }
}
