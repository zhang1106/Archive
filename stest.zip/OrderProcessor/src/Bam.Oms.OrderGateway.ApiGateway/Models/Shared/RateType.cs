﻿namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public enum RateType
    {
        Unknown = -1,
        Rebate = 0,
        Fee = 1
    }
}
