﻿using System.Collections.Generic;
using System.Data.SqlClient;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Journal;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Pooling;
using Bam.EventQ.Recovery;
using Bam.EventQ.Sequencing;
using Bam.EventQ.Snapshot;
using Bam.EventQ.Time;
using Bam.EventQ.Transport;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.PositionTracker;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;
using Bam.Oms.OrderGateway.Compliance.Services.Headroom;
using Bam.Oms.OrderGateway.Compliance.Services.Marking;
using Bam.Oms.OrderGateway.Compliance.Services.Rules;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.Persistence;
using Bam.Oms.OrderGateway.Infrastructure.Roll;
using Bam.Oms.OrderGateway.Integrations.StructureMap;
using Bam.Oms.OrderGateway.Messages;
using StructureMap;

namespace Bam.Oms.OrderGateway.Compliance
{
    public class CompositionRoot : StructureMapCompositionRoot<ComplianceService, ComplianceSettings>
    {
        protected override void Configure(ConfigurationExpression config, ComplianceSettings settings)
        {
            ConfigureComplianceRules(config, settings);

            config.For<IComplianceCache>().Use<ComplianceCache>().Singleton();
            config.For<ISodPositionCalculator>().Use<SodPositionCalculator>().Singleton();
            config.For<IPositionEffectCalculator>().Use<PositionEffectCalculator>().Singleton();
            config.For<IPositionIdGenerator>().Use<PositionIdGenerator>().Singleton();
            config.For<IDbPersistence>().Use<DbPersistence>().Singleton().Ctor<SqlConnection>().Is(new SqlConnection(settings.EmsDatabaseConnection));
            config.For<IDbPositionLookup>().Use<DbPositionLookup>().Singleton().Ctor<SqlConnection>().Is(new SqlConnection(settings.EmsDatabaseConnection));
            config.For<IDbHeadroomLookup>().Use<DbHeadroomLookup>().Singleton().Ctor<SqlConnection>().Is(new SqlConnection(settings.EmsDatabaseConnection));
            config.For<IPositionEffectCache>().Use<PositionEffectCache>().Singleton();
            config.For<ISplitOrderIdGenerator>().Use<SplitOrderIdGenerator>().Singleton();
            config.For<IAllocationService>().Use<AllocationService>().Singleton();
            config.For<IMarkingService>().Use<MarkingService>().Singleton();
            config.For<IHeadroomEffectCalculator>().Use<HeadroomEffectCalculator>().Singleton();
            config.For<IHeadroomEffectCache>().Use<HeadroomEffectCache>().Singleton();

            config.For<IOrderFactory>()
                .Use<OrderFactory>()
                .AlsoKnownAs(config, typeof(ISnapshotRecoverable))
                .Singleton();

            config.For<IOrderEffectMediator>()
                .Use<OrderEffectMediator>()
                .Ctor<string[]>().Is(settings.SecurityTypesCoveredByOwnershipRules)
                .Singleton();
            
            var fallback = config.For<IOrderMarker>().Add<EquityOrderMarker>();
            config.For<IOrderMarker>().Add<FutureOrderMarker>();
            config.For<IOrderMarkerFactory>().Use<OrderMarkerFactory>()
                .Ctor<IOrderMarker>().Is(fallback)
                .Singleton();
            
            config.For<ISodPositionServiceClient>()
                .Use<SodPositionServiceClient>()
                .Ctor<string>().Is(settings.SodPositionServiceUri);

            config.For<IHeadroomService>()
                .Use<HeadroomService>()
                .AlsoKnownAs(config, typeof(ISnapshotRecoverable))
                .Singleton();

            config.ForConcreteType<InitialSodPositionLoad>().Configure.Singleton();
        }

        private void ConfigureComplianceRules(ConfigurationExpression config, ComplianceSettings settings)
        {
            config.For<IRule>().Add<PreValidationRule>()
                .Ctor<long>().Is(settings.MaximumOrderSize);

            config.For<IRule>().Add<SplitStrategyComplianceRule>();
            config.For<IRule>().Add<LongOwnershipRule>()
                .Ctor<string[]>().Is(settings.SecurityTypesCoveredByOwnershipRules)
                .Ctor<bool>().Is(settings.OwnershipMonitoringMode);
            config.For<IRule>().Add<ShortOwnershipRule>()
                .Ctor<string[]>().Is(settings.SecurityTypesCoveredByOwnershipRules)
                .Ctor<bool>().Is(settings.OwnershipMonitoringMode);

            var repo1 = config.For<IRuleRepository>().Add<ExplicitRuleRepository>();
            config.For<IRuleRepository>().Use<CompositeRuleRepository>()
                .EnumerableOf<IRuleRepository>().Contains(repo1);
        }

        protected override void ConfigureRollProcess(ConfigurationExpression config, ComplianceSettings settings)
        {
            base.ConfigureRollProcess(config, settings);
            config.For<IRollBlotterProcess>().Add<PersistPositionsRollBlotterProcess>();
        }

        protected override IEnumerable<IProcessingPipeline> CreatePipelines(ComplianceSettings settings, IContainer container)
        {
            yield return ProcessingPipeline.New()
                .LogErrors(container.GetInstance<ILogger>())
                .UseObjectInitializer(ObjectInitializer)
                .UseObjectDecorator(new TelemetryObjectDecorator(container.GetInstance<ITelemetry>(), settings.TelemetryPublishInterval))
                .UseRecoveryInvoker(container.GetInstance<IRecoveryInvoker>())
                .UseRpcServer(container.GetInstance<IRpcServer>())
                .AddStep<IMessage>(step => step
                    .AddSequenceInfoAccessor()
                    .UseDisruptor(settings.Queue.InputRingSize, settings.Queue.BufferSize)
                    .ReplayFromJournal(container.GetInstance<IJournal>(), container.GetAllInstances<IJournalSeed>())
                    .AddInitializer(container.GetInstance<InitialSodPositionLoad>())
                    .AddInitializer(container.GetInstance<InitialSodHeadroomLoad>())
                    .AddProducer(container.GetInstance<InitialSodHeadroomLoad>())
                    .AddProducer(container.GetInstance<InitialSodPositionLoad>())
                    .SubscribeWithZeroMq(settings.Endpoints.PubSubBySource, settings.MaximumMessageSize)
                    .SendHeartbeats(WallClock, settings.HeartbeatInterval, settings.SelfSource, Topic.Compliance, Topic.Position, Topic.Sod)
                    .SubscribeTo(Source.OrderProcessor, Topic.Compliance, Topic.Order, Topic.Allocation)
                    .SubscribeTo(Source.RefDataGateway, Topic.RefData, Topic.Security)
                    .SubscribeTo(Source.ApiGateway, Topic.Ems, Topic.Position, Topic.Sod, Topic.Admin)
                    .AddHandlerChain(chain => chain
                        .ValidateSequenceNumbers(container.GetInstance<IClock>(), settings.RecoveryTimeout, settings.SelfSource)
                        .Journal(container.GetInstance<IJournal>())
                        .Deserialize()
                        .LogMessagesTo("IN", settings.LogAllMessages, container.GetInstance<ILogger>())
                        .DispatchToWorkflow(container.GetInstance<IWorkflowDispatcher<IMessage, IMessage>>())
                        .ReleasePayload(container.GetInstance<IObjectPool>())))
                .AddStep<IMessage>(step => step
                    .AddSequenceInfoAccessor()
                    .UseDisruptor(settings.Queue.OutputRingSize, settings.Queue.BufferSize)
                    .ReceiveFromPreviousStep<IMessage>()
                    .PublishWithZeroMq()
                    .AddHandlerChain(chain => chain
                        .Serialize(settings.SelfSource, settings.MaximumMessageSize, WallClock)
                        .LogMessagesTo("OUT", settings.LogAllMessages, container.GetInstance<ILogger>())
                        .Publish(settings.SelfPubSub))
                    .UseReplayRecovery(settings.SelfPubSub))
                .Build();
        }
    }
}
