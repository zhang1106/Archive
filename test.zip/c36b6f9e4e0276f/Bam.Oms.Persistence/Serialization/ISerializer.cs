﻿using System;

namespace Bam.Oms.Persistence.Serialization
{
    public interface ISerializer
    {
        byte[] Serialize<T>(T item);
        T Deserialize<T>(byte[] input);
        T Deserialize<T>(byte[] input, int startIndex, int length);
        object Deserialize(byte[] input, int startIndex, int length, Type type);
    }
}
