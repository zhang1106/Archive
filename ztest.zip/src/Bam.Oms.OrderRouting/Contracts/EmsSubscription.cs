﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.OrderRouting.Contracts
{
    public class EmsSubscription
    {
        public EmsSubscription(Portfolio portfolio, Security security, String trader = "*")
        {
            Portfolio = portfolio;
            Security = security;
            Trader = trader;
        }

        public Portfolio Portfolio { get; private set; }
        public Security Security { get; private set; }

        public string Trader { get; private set; }
    }
}
