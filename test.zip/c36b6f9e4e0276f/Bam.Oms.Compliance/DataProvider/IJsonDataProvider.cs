﻿namespace Bam.Oms.Compliance.DataProvider
{
    public interface IJsonDataProvider
    {
        string GetDataInJson(string srcUri);
    }
}
