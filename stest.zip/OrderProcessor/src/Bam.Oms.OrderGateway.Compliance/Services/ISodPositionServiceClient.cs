﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public interface ISodPositionServiceClient
    {
        Task<List<SodPositionDto>> Get();
    }
}