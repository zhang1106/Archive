﻿using Bam.Oms.Data.Orders;
using Bam.Oms.Messaging;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

namespace Bam.Oms.EndPoints.Hub
{
    /// <summary>
    /// 
    /// </summary>
    [HubName("orderhub")] //we actually don't need to do this, only if you want the name idff
    public class OrderHub : PortfolioFilteredSignalRHub<Order>
    {
        public OrderHub(ISignalRSessions<Order> sessions, ILogger logger) : base(sessions, logger)
        {
        }

        public override IHubContext<ISignalRClient<SignalRPacket<Order>>> GetHubContext()
        {
            return GlobalHost.ConnectionManager.GetHubContext<OrderHub, ISignalRClient<SignalRPacket<Order>>>();
        }
    }
}