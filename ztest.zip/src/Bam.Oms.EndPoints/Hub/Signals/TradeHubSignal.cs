﻿using Bam.Oms.Data.Trades;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Messaging;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;

namespace Bam.Oms.EndPoints.Hub.Signals
{
    public class TradeHubSignal : HubSignal<BlockTrade, ITradeRepository>
    {
        public TradeHubSignal(ISignalRSessions<BlockTrade> sessions, IFlowManager flowManager, ILogger logger, IOrderRepository orderRepository, ITradeRepository tradeRepository)
            : base(sessions, flowManager, logger, orderRepository, tradeRepository)
        {
        }

        protected override IHubContext<ISignalRClient<SignalRPacket<BlockTrade>>> GetHubContext()
        {
            return GlobalHost.ConnectionManager.GetHubContext<TradeHub, ISignalRClient<SignalRPacket<BlockTrade>>>();
        }
    }
}