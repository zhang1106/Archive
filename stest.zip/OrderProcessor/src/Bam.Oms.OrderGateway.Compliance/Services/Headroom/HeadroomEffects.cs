﻿using System;

namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public struct HeadroomEffects
    {
        public long Long;
        public long Short;
        public long NetShort;
        public long NetLong;

        public static HeadroomEffects operator -(HeadroomEffects x, HeadroomEffects y)
        {
            return new HeadroomEffects
            {
                Short = x.Short - y.Short,
                Long = x.Long - y.Long,
                NetShort = x.NetShort - y.NetShort,
                NetLong = x.NetLong - y.NetLong
            };
        }

        public static HeadroomEffects operator *(HeadroomEffects x, double value)
        {
            return new HeadroomEffects
            {
                Short = (long) Math.Floor(x.Short * value),
                Long = (long) Math.Floor(x.Long * value),
                NetShort = (long) Math.Floor(x.NetShort * value),
                NetLong = (long) Math.Floor(x.NetLong * value),
            };
        }
    }
}
