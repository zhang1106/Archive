USE [OrderGatewayMain]
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[dbo].[AllocationRule]') IS NOT NULL
	DROP TABLE [dbo].[AllocationRule]
GO

CREATE TABLE [dbo].[AllocationRule](
	[Strategy] [nvarchar](50) NOT NULL,
	[SplitStrategy] [nvarchar](50) NOT NULL,
	[Fund] [nvarchar](50) NOT NULL,
	[Ratio] [decimal](8, 6) NOT NULL,
 CONSTRAINT [PK_AllocationRule] PRIMARY KEY CLUSTERED 
(
	[Strategy] ASC,
	[SplitStrategy] ASC,
	[Fund] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

INSERT INTO [dbo].[AllocationRule]
(Strategy, SplitStrategy, Fund, Ratio) VALUES
('ZANN-INDUSTRIALS-SPLIT', 'ZANN-INDUSTRIALS', 'ALMF', 0.4),
('ZANN-INDUSTRIALS-SPLIT', 'ZANN-INDUSTRIALS', 'AMF', 0.2),
('ZANN-INDUSTRIALS-SPLIT', 'ZANN-ZIE_I', 'BZF', 0.4)
GO