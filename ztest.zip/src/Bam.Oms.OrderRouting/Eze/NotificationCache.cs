﻿using System;
using System.Threading;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using EzeEi = Eze.Common.Integration;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.OrderRouting.EZE
{
    public class NotificationCache : INotificationCache
    {
        //strategy and symbol is key, what about if one PM finish an order and create another one?
        private readonly Dictionary<string, EzeEi.Trade> _ezeTrades;
        private readonly ReaderWriterLockSlim _lockEzeTrades = new ReaderWriterLockSlim();
        //index of ez orders by strategy, tradeid, custodian
        private readonly Dictionary<OrderIndexKey, string> _ezeOrders;
        private readonly ReaderWriterLockSlim _lockEzeOrders = new ReaderWriterLockSlim();
        private readonly IOrderRepository _orderRepository;
        //
        private readonly Dictionary<string, Dictionary<string, IOrder>> _ordersbyEzeTradeId;


        public NotificationCache(IOrderRepository orderRepository)
        {
            _ezeTrades = new Dictionary<string, EzeEi.Trade>();
            _ezeOrders = new Dictionary<OrderIndexKey, string>();
            _ordersbyEzeTradeId = new Dictionary<string, Dictionary<string, IOrder>>();
            _orderRepository = orderRepository;
        }
        public void AddEzeTrades(IReadOnlyList<EzeEi.Trade> trades)
        {
            _lockEzeTrades.EnterWriteLock();
            try
            {
                foreach (var trade in trades)
                {
                    EzeEi.Trade cTrade;
                    if (!_ezeTrades.TryGetValue(trade.TradeId, out cTrade))
                    {
                        cTrade = new EzeEi.Trade();
                        _ezeTrades.Add(trade.TradeId, cTrade);
                    }
                    MappingAgent.CopyBasicEzeTrade(trade, cTrade);
                }
            }
            finally
            {
                _lockEzeTrades.ExitWriteLock();
            }
        }
        public EzeEi.Trade GetTrade(string tradeId)
        {
            _lockEzeTrades.EnterReadLock();
            try
            {
                return _ezeTrades.ContainsKey(tradeId) ? _ezeTrades[tradeId] : null;
            }
            finally
            {
                _lockEzeTrades.ExitReadLock();
            }
        }
        public void AddToOrderIdIndex(Order order,  bool saveToRepository = true)
        {
            if (order.Portfolio == null) return;
            if (string.IsNullOrEmpty(order.ExternalId)) return;
            var key = new OrderIndexKey(order.ExternalId, order.Portfolio.ToString(), order.Security.BamSymbol);
            _lockEzeOrders.EnterWriteLock();
            try
            {
                if (!_ezeOrders.ContainsKey(key))
                {
                    _ezeOrders.Add(key, order.ClientOrderId);
                }
                else
                {
                    _ezeOrders[key] = order.ClientOrderId;
                }
 

                Dictionary<string, IOrder> orders;
                if (_ordersbyEzeTradeId.TryGetValue(order.ExternalId, out orders))
                {
                    if (!orders.ContainsKey(order.ClientOrderId))
                    {
                        orders.Add(order.ClientOrderId, order);
                    }
                }
                else
                {
                    orders = new Dictionary<string, IOrder> {{order.ClientOrderId, order}};
                    _ordersbyEzeTradeId.Add(order.ExternalId, orders);
                }

            }
            finally
            {
                _lockEzeOrders.ExitWriteLock();
            }
        }

        public Dictionary<string, IOrder> GetOrdersByEzeTradeId(string tradeId)
        {
            _lockEzeOrders.EnterReadLock();
            try
            {
                Dictionary<string, IOrder> orders;
                return _ordersbyEzeTradeId.TryGetValue(tradeId, out orders) ? orders : new Dictionary<string, IOrder>();
            }
            finally 
            {
                _lockEzeOrders.ExitReadLock();
            }
        }

        public void AddToOrderIdIndex(IList<IOrder> orders)
        {
            foreach (var order in orders)
            {
                AddToOrderIdIndex((Order)order);
            }
        }

        public string GetOrderId(OrderIndexKey key)
        {
            _lockEzeOrders.EnterReadLock();
            try
            {
                return _ezeOrders.ContainsKey(key) ? _ezeOrders[key] : null;
            }
            finally
            {
                _lockEzeOrders.ExitReadLock();
            }
        }
    }
}
