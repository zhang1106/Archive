﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Results;
using Bam.Oms.Compliance.ServiceBroker;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using BAM.Infrastructure.Ioc;
using Castle.Components.DictionaryAdapter;

namespace Bam.Oms.Compliance
{
    public class FirmPositionComplianceSvc : IFirmPositionComplianceSvc
    {
        private readonly IEngine<ICompliancePosition> _engine;
        private readonly IFactProvider _factProvider;
        private readonly ILogger _logger;
        private readonly IPolicyProvider _policyProvider;
        private readonly IPositionProvider _positionProvider;
        private readonly IRuleResultProvider _ruleResultProvider;
        private readonly ISecurityProvider _securityProvider;

        private readonly ISettings _setting;
        private readonly IHelper _helper;
        private readonly ISvcUtil _svcUtil;

        private IEnumerable<IRuleResult> _previousRuleResults;
        private readonly IHoldingProvider _holdingProvider;
        private readonly ICustomDataProvider _customDataProvider;
        
        private readonly IServiceBrokerListener _aqtfServiceBrokerListener;
        private readonly IServiceBrokerListener _mainServiceBrokerListener;
        private readonly IServiceBrokerListener _aqtfEodfServiceBrokerListener;
        private readonly IServiceBrokerListener _mainEodServiceBrokerListener;
        private readonly object _lock = new object();

        public bool SodPositionReady { get; set; }
        
        public FirmPositionComplianceSvc(ISettings setting, IPolicyProvider policyProvider,  IPositionProvider positionProvider,
            IHoldingProvider holdingProvider, IEngine<ICompliancePosition> engine,  IRuleResultProvider ruleResultProvider,  
            ISecurityProvider securityProvider, IFactProvider factProvider, 
            ICustomDataProvider customDataProvider,
            ILogger logger, IHelper helper, ISvcUtil svcUtil
            ,[NamedDependency("AQTF")]IServiceBrokerListener aqtfServiceBrokerListener
            , [NamedDependency("MAIN")]IServiceBrokerListener mainServiceBrokerListener
            , [NamedDependency("AQTFEod")]IServiceBrokerListener aqtfEodServiceBrokerListener
            , [NamedDependency("MAINEod")]IServiceBrokerListener mainEodServiceBrokerListener
            )
        {
            _policyProvider = policyProvider;
            _positionProvider = positionProvider;
          
            _engine = engine;
            _setting = setting;
            _ruleResultProvider = ruleResultProvider;
            _securityProvider = securityProvider;
            _factProvider = factProvider;
            _customDataProvider = customDataProvider;

            _logger = logger;
            _helper = helper;
            _svcUtil = svcUtil;
            
            _holdingProvider = holdingProvider;
            _aqtfServiceBrokerListener = aqtfServiceBrokerListener;
            _mainServiceBrokerListener = mainServiceBrokerListener;
            _aqtfEodfServiceBrokerListener = aqtfEodServiceBrokerListener;
            _mainEodServiceBrokerListener = mainEodServiceBrokerListener;
            //
            _previousRuleResults = new List<IRuleResult>();
        }

        public void Init()
        {
            _setting.Initialize();
            //
            _mainServiceBrokerListener.Start(_setting.OrderGatewayMainConnectionString, MonitorTarget.SodMonitor);
            _mainServiceBrokerListener.Positionchanged += RecalculateSodHeadRoom;

            _mainEodServiceBrokerListener.Start(_setting.OrderGatewayMainConnectionString, MonitorTarget.EodMainMonitor);
            _mainEodServiceBrokerListener.Positionchanged += RecalculateSodHeadRoom;

            RefreshRefData();
        }

        public void RefreshRefData()
        {
            //
            _policyProvider.RefreshData();
            _factProvider.RefreshData();
            //
            _engine.Refresh();

            _logger.Info($"Security: Start loading securites updated since {default(DateTime)}");
            _securityProvider.RefreshData();
            _securityProvider.Start();

            //refresh reference data
            _customDataProvider.RefreshData();
        }

        public PolicyResult PolicyResult { get; private set; }
     
        public void RefreshData(PositionType pType)
        {
            //position refresh
            if (pType == PositionType.Sod)
            {
                lock (_lock)
                {
                    SodPositionReady = false;
                    _holdingProvider.RefreshData(pType);
                    SodPositionReady = true;
                }
            }
            else
            {
                _holdingProvider.RefreshData(pType);
            }
        }

        public void RecalculateSodHeadRoom()
        {
            _logger.Info($"Sod: update sod position and recalc sod headrooms");
            Run(PositionType.Sod);
        }
        
        public IEnumerable<IRuleResult> CheckViolations(IList<string> securities, PositionType pType)
        {
            _logger.Info($"Start checking rules against against {pType} positions for {securities.Count} securities for {Environment.UserName}");

           //reset the result container
            var firmWideComplianceResult = new EditableList<IRuleResult>();
            ////get intraday positions
            
            foreach (var policy in _engine.Policies.Values)
            {
                //verify positions against the policy
                var violations = new List<IRuleResult>();
                PolicyResult = new PolicyResult { PolicyId = policy.Id, PolicyName = policy.Name, Alerts = violations };
                //check all the underliers
                foreach (var security in securities.Where(s=>!string.IsNullOrEmpty(s)).Distinct())
                {
                    var enrichedSecurity = _securityProvider.GetSecurity(security);
                    if (enrichedSecurity == null)
                    {
                        _logger.Info($"No security found for {security}");
                        violations.AddRange(_helper.CreateNoInfoFilingResult(new []{security}, "Security Does not Exist").ToList());
                        continue;
                    }
                    //not generate rules for ADRs  
                    if (enrichedSecurity.IsAdr() && enrichedSecurity.UnderlyingSymbol != enrichedSecurity.AdrCode)
                    {
                        continue;
                    }
                    if (enrichedSecurity.IsAdr() && enrichedSecurity.UnderlyingSymbol == enrichedSecurity.AdrCode)
                    {
                        violations.Add(_helper.CreateNoRuleHeadRoomForAll(enrichedSecurity.BamSymbol, policy.Id));
                        continue;
                    }
                    //check underlying security only
                    var pTarget = _helper.CreateCompliancePosition(enrichedSecurity, policy, pType);
                  
                    var result = _engine.CheckViolations(policy, pTarget, false);
                    violations.AddRange(result.Alerts);
                }
                firmWideComplianceResult.AddRange(violations);
            }

            return firmWideComplianceResult;
        }

        public List<IRuleResult> Run(PositionType pType)
        {
            _logger.Info($"{pType}: Run Started ");
            RefreshData(pType);
            
            //get intraday positions
            var underlyingSecurities = _positionProvider.GetUnderlyingSecurities(pType).ToList();

            _logger.Info($"{pType}: checking rules");
            var results = CheckViolations(underlyingSecurities, pType).ToList();
            
            //act
            Act(results, pType, DateTime.Now.Date);
            
            return results;
        }

        public List<IRuleResult> RunEod(DateTime date)
        {
            _logger.Info($"Eod: Start refreshing data for the date - {date}");
            
            RefreshData(PositionType.Eod);
            _holdingProvider.PopuldateEodPositions(date);

            //get intraday positions
            var underlyingSecurities = _positionProvider.GetUnderlyingSecurities(PositionType.Eod).ToList();

            _logger.Info("Eod: Start checking rules");
            var results = CheckViolations(underlyingSecurities, PositionType.Eod).ToList();

            //act
            Act(results, PositionType.Eod, date);

            return results;
        }

        public void ClearRepository()
        {
            _ruleResultProvider.Clear(DateTime.UtcNow.AddDays(-3));
        }

        protected void Act(IEnumerable<IRuleResult> ruleResults, PositionType pType, DateTime date)
        {
            //output sod headroom file
            if(pType == PositionType.Sod)
            {
               var file = _setting.HeadRoomFilePath + "OwnershipHeadroom" +DateTime.UtcNow.Ticks +".json";
                _svcUtil.ExportHeadRooms(ruleResults.Where(r=>(r.RuleName==_setting.HeadRoomRuleName || "*"==_setting.HeadRoomRuleName) 
                                    && (r.BamSymbol==_setting.HeadRoomSymbol || "*" == _setting.HeadRoomSymbol)), file);
                
                _svcUtil.ExportHeadRoomsToCsv(ruleResults);
                _svcUtil.ExportSodReconToCsv(ruleResults);
                
                return;
            }

            //send email report
            var thisResult = ruleResults.Where(r => r.Type==typeof(OwnershipFilingResult).FullName &&
                          r.AlertLevel != ComplianceAlertLevel.NoDataAvaiable &&
                          r.PositionQty.HasValue && r.PositionQty != 0).ToArray();

            var newAlerts = thisResult.Where(r=>!_previousRuleResults.Any(p => p.Same(r))).Select(r => r).ToList();
            var previousResult = thisResult;

            var reportable = new List<IRuleResult>();
            
            foreach (var r in thisResult)
            {
                var lResult = r as OwnershipFilingResult;
                if (lResult == null) continue;

                var lastResult = _ruleResultProvider.GetLastRuleResult(r, date) as OwnershipFilingResult;
                if(r.AlertLevel==ComplianceAlertLevel.NoViolation && ( lastResult == null || lastResult.Ratio == null || lastResult.AlertLevel == ComplianceAlertLevel.NoViolation)) continue;

                lResult.LastRatio = lastResult?.Ratio;

                if (!r.Same(lastResult)) r.Description += " **";
                if (r.HeadRoom.IsExempt) r.Description += " [exempt]";

                reportable.Add(lResult);
            }

            //set previous result record
            if (pType == PositionType.Intraday) _previousRuleResults = previousResult;

            //var lookup = thisResult.ToLookup(r => r.BamSymbol);
            
            if(pType == PositionType.Eod || (newAlerts.Any() && pType==PositionType.Intraday) || _svcUtil.IsEod())
            {
                const string euShortRule = "European Union: Short Ownership Filing";
                //eu short report
                if (newAlerts.Any(a => a.RuleName.Contains(euShortRule) && !a.HeadRoom.IsExempt))
                {
                    _svcUtil.EmailEuShortReport(reportable.Where(r=>r.RuleName.Contains(euShortRule) && !r.HeadRoom.IsExempt && r.BamSymbol != "ZVZZT"), pType);
                }

                //non eu short
                if (newAlerts.Any(a => !a.RuleName.Contains(euShortRule)))
                {
                    _svcUtil.EmailReport(thisResult.Where(r =>r.AlertLevel != ComplianceAlertLevel.NoViolation && !r.RuleName.Contains(euShortRule) &&r.BamSymbol != "ZVZZT"), pType);
                }
            }
            else
            {
                _logger.Info("not send email...no new alerts.");
            }
            
        }
      
    }
}