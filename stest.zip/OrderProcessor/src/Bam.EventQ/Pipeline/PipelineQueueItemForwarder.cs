﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Pipeline
{
    public class PipelineQueueItemForwarder<TIn, TOut> :
        QueueItemProducerBase<PipelineQueueItem<TOut>>,
        IQueueItemHandler<PipelineQueueItem<TIn>>
    {
        private static readonly IReadOnlyList<TOut> EmptyResult = new TOut[0];

        private readonly IQueueItemTransformer<TIn, TOut> _transformer;
        private readonly ManualResetEventSlim _runningEvent = new ManualResetEventSlim(true);
        private readonly Action<int, PipelineQueueItem<TOut>> _publishItemAction;
        private readonly BatchItem[] _batch;
        private readonly int _batchSize;

        private int _batchIndex;

        private struct BatchItem
        {
            public TOut Payload { get; set; }
            public bool IsReplay { get; set; }
            public DateTime LastClear { get; set; }
        }

        public PipelineQueueItemForwarder(IQueueItemTransformer<TIn, TOut> transformer, int batchSize)
        {
            _transformer = transformer;
            _batchSize = batchSize;
            _batchIndex = -1;
            _batch = new BatchItem[_batchSize];
            _publishItemAction = PublishItem;
        }

        public override bool CanPause => true;

        public void Handle(PipelineQueueItem<TIn> item, long sequence, bool endOfBatch)
        {
            var result = item.IsValid 
                ? _transformer.Transform(item.Payload, sequence, item.IsReplay) 
                : EmptyResult;

            // ReSharper disable once ForCanBeConvertedToForeach
            for (int i = 0; i < result.Count; i++)
            {
                _batchIndex++;
                _batch[_batchIndex].Payload = result[i];
                _batch[_batchIndex].IsReplay = item.IsReplay;
                _batch[_batchIndex].LastClear = item.LastClear;

                if (_batchIndex + 1 == _batchSize)
                {
                    Forward();
                }
            }

            if (endOfBatch)
            {
                Forward();
            }

            _runningEvent.Wait();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void Forward()
        {
            int count = _batchIndex + 1;
            if (count == 0)
                return;

            _batchIndex = -1;
            Queue.PublishBatch(count, _publishItemAction);
        }

        private void PublishItem(int index, PipelineQueueItem<TOut> item)
        {
            var batchItem = _batch[index];
            item.SetPayload(batchItem.Payload);
            item.SetLastClear(batchItem.LastClear);

            if (batchItem.IsReplay)
            {
                item.MarkReplay();
            }
            
            _batch[index].Payload = default(TOut);
        }

        public override void Stop()
        {
            _runningEvent.Set();
        }

        public override void Pause()
        {
            _runningEvent.Reset();
        }

        public override void Resume()
        {
            _runningEvent.Set();
        }
    }
}
