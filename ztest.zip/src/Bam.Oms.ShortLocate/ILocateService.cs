﻿using System;
using System.Collections.Generic;
using Bam.Locate.Hub.Data;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Trades;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.ShortLocate
{
    public interface ILocateService : IDisposable
    {
        /// <summary>
        /// Submits a batch requests for short inventory
        /// </summary>
        /// <param name="requests"></param>
        /// <returns>A list of request that were fully or partially filled</returns>
        [Log]
        IEnumerable<IOrder> RequestForInventory(IEnumerable<ILocateRequest> requests); //todo: we might need to implement an all or nothing type request scheme

        /// <summary>
        /// Notifies when a batch of locate assignments have changed
        /// </summary>
        event Action<IList<TradeAssignment>> LocateAssignmentUpdated;

        void SubscribeToLocates();

        void CancelTrades(IDictionary<string, IList<IBlockTrade>> blockTrades);
    }
}