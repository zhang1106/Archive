﻿using System;
using System.Collections.Generic;
using Bam.Infrastructure.Connectivity;
using Bam.Locate.Hub.Data;

namespace Bam.Oms.ShortLocate
{
    public class LocateHubProxy : RestfulClientProxy<IInventoryController>, IInventoryController
    {
        public LocateHubProxy(string host, string port) : base(host, port) { }

        public List<InventoryItem> PostInventory(List<ResponseLocateInfo> responses)
        {
            return ProxyChannel.PostInventory(responses);
        }

        public List<TradeAssignment> PostInventoryAssignment(List<TradeAssignmentRequest> requests)
        {
            return ProxyChannel.PostInventoryAssignment(requests);
        }

        public List<TradeAssignment> GetTradeAssignments()
        {
            return ProxyChannel.GetTradeAssignments();
        }

        public TradeAssignment GetTradeAssignmentsByTradeId(string tradeId)
        {
            return ProxyChannel.GetTradeAssignmentsByTradeId(tradeId);
        }

        public List<InventoryItem> GetInventoryItemsByKey(string ticker, string broker, DateTime? tradeDate)
        {
            return ProxyChannel.GetInventoryItemsByKey(ticker, broker, tradeDate);
        }

        public int GetAvailableInventory(string ticker, string broker, string tradeDate)
        {
            return ProxyChannel.GetAvailableInventory(ticker, broker, tradeDate);
        }

        public List<string> GetBrokers()
        {
            return ProxyChannel.GetBrokers();
        }

        public int PostTradeAssignmentsToLiveApi(IList<TradeAssignmentRequest> requests)
        {
            return ProxyChannel.PostTradeAssignmentsToLiveApi(requests);
        }

        public string PostInventoryAdjustment(ResponseLocateInfo adjustedInventory)
        {
            return ProxyChannel.PostInventoryAdjustment(adjustedInventory);
        }

        public int PostCancelTrade(IList<CancelTradeRequest> cancelRequests)
        {
            return ProxyChannel.PostCancelTrade(cancelRequests);
        }

        //these are not supported from the gateway, we prob want to strip down this interface and make it specific to the OG
        public bool RollHub(DateTime? rollDay)
        {
//            throw new NotImplementedException();
            return true;
        }

        public bool Snap()
        {
//            throw new NotImplementedException();
            return true;
        }
    }
}