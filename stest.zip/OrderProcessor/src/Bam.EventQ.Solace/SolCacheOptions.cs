﻿namespace Bam.EventQ.Solace
{
    public class SolCacheOptions
    {
        public string SempUrl { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string CacheName { get; set; }
        public string VpnName { get; set; }
        public string Cluster { get; set; }
        public string Instance { get; set; }
    }
}
