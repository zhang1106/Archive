﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Persistence.Orders;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.TradeMarker
{
    public class OrderMarker : IOrderMarker
    {
        private readonly ILogger _log;
        private readonly IClientOrderIdRepository _clientOrderIdRepository;
        private readonly ILoggingAgent _eventLogger;

        public OrderMarker(ILogger logger, IClientOrderIdRepository clientOrderIdRepository, ILoggingAgent eventLogger)
        {
            _log = logger;
            _clientOrderIdRepository = clientOrderIdRepository;
            _eventLogger = eventLogger;
        }
        
        [Log]
        public IList<IOrder> MarkOrder(IOrder order, IPositionSet positionSet)
        {
            var shortComplianceSize = positionSet.CompliancePosition?.ShortMarkingQuantity ?? 0;
            decimal firmCurrentComplianceSize = positionSet.AggUnitPosition?.ShortMarkingQuantity ?? 0;
            decimal longComplianceSize = positionSet.CompliancePosition?.LongMarkingQuantity ?? 0;
            decimal omniSize = positionSet.Position.DistributedPositions?.Where(d => Utility.IsOmni(d.CustodianName)).Sum(d => d.Quantity) ?? 0;

            IList<IOrder> markedOrders = new List<IOrder>();

            _log.Debug($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] Order Side is {order.Side}. Firm Compliance position is {firmCurrentComplianceSize}. Short compliance size {shortComplianceSize}. long compliance size {longComplianceSize}. Omni size {omniSize}.");

            var origSide = order.Side;
            var origSize = order.Size;
            string msg;

            #region Marking sell/short Orders
            // Apply the Net Firm Position rule for Short or Sell order
            if (order.Side == SideType.Short || order.Side == SideType.Sell || order.Side == SideType.SellShort)
            {
                //compliance group or net firm position is flat or short. Mark entire trade as short
                if (firmCurrentComplianceSize <= 0 || shortComplianceSize <= 0)
                {
                    order.Side = SideType.SellShort;
                    order.OrderStatus = BamOrderStatus.Marked;
                    markedOrders.Add(order);
                    var msg0 = $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] MarkNetFirmShort: Symbol={order.Security.BamSymbol}; Portfolio={order.Portfolio}; Original Order={origSize}[{origSide}]; NetAggUnitPosition={firmCurrentComplianceSize}; NetComplianceGroupPosition={shortComplianceSize}; Omni size {omniSize}; Marked Order={order.Size}[{SideType.SellShort}]";
                    LogEvent(order, msg0);
                    return markedOrders;
                }

                //both compliance group and firm net long
                var maxSellong = Math.Min(firmCurrentComplianceSize, shortComplianceSize);

                if (order.Size <= maxSellong)
                {
                    order.Side = SideType.Sell;
                    order.OrderStatus = BamOrderStatus.Marked;
                    markedOrders.Add(order);
                    string msg0 = $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] MarkSide: Symbol={order.Security.BamSymbol}; Portfolio={order.Portfolio}; Original Order={origSize}[{origSide}]; NetAggUnitPosition={firmCurrentComplianceSize}; NetComplianceGroupPosition={shortComplianceSize};  Omni size {omniSize}; Marked Order={order.Size}[{order.Side}]";
                    LogEvent(order, msg0);
                    return markedOrders;
                }

                // Net firm position is long, but not enough to satisfy the sell. Split the trade into two.  
                IOrder markedOrder1 = (IOrder)order.Clone();
                markedOrder1.Side = SideType.Sell;
                markedOrder1.Size = maxSellong;
                markedOrder1.OrderStatus = BamOrderStatus.Marked;
                markedOrders.Add(markedOrder1);

                IOrder markedOrder2 = order;
                markedOrder2.Side = SideType.SellShort;
                markedOrder2.Size = Math.Abs(order.Size - maxSellong);
                markedOrder2.OrderStatus = BamOrderStatus.Marked;

                markedOrders.Add(markedOrder2);

                VersionOrderIds(order, markedOrders);

                msg = $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] MarkSide: Symbol={order.Security.BamSymbol}; Portfolio={order.Portfolio}; Original Order={origSize}[{origSide}]; NetAggUnitPosition={firmCurrentComplianceSize}; Short marking compliance position={shortComplianceSize};  Omni size {omniSize}; CrossZeroSplit order 1 = {markedOrder1.Size}[{markedOrder1.Side}]";
                LogEvent(markedOrder1, msg);

                msg = $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] MarkSide: Symbol={order.Security.BamSymbol}; Portfolio={order.Portfolio}; Original Order={origSize}[{origSide}]; NetAggUnitPosition={firmCurrentComplianceSize}; Short marking compliance position={shortComplianceSize}; Omni size {omniSize}; CrossZeroSplit order 2 = {markedOrder2.Size}[{markedOrder2.Side}]";
                LogEvent(markedOrder2, msg);

                return markedOrders;
            }

            #endregion Marking sell/short Orders

            #region Marking Long/Buy orders

            //compliance group position >= 0, mark as BUY
            if (longComplianceSize >= 0)
            {
                msg = $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] MarkSide: Symbol={order.Security.BamSymbol}; Portfolio={order.Portfolio}; Original Order={order.Size}[{order.Side}]; NetAggUnitPosition={firmCurrentComplianceSize}; Long compliance position={longComplianceSize}; Omni size {omniSize}; Marked Order={order.Size}[{SideType.Buy}]";
                order.Side = SideType.Buy;
                order.OrderStatus = BamOrderStatus.Marked;
                LogEvent(order, msg);
                markedOrders.Add(order);
                return markedOrders;
            }

            //compliance group short and order size less than short position, mark as COVER
            var maxCover = Math.Abs(longComplianceSize);
            if (order.Size <= maxCover)
            {
                msg = $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] MarkSide: Symbol={order.Security.BamSymbol}; Portfolio={order.Portfolio}; Original Order={order.Size}[{order.Side}]; NetAggUnitPosition={firmCurrentComplianceSize}; Long marking compliance position={longComplianceSize};  Omni size {omniSize}; Marked Order={order.Size}[{SideType.Cover}]";
                order.Side = SideType.Cover;
                order.OrderStatus = BamOrderStatus.Marked;
                LogEvent(order, msg);
                markedOrders.Add(order);
                return markedOrders;
            }

            //compliance group short and order size greater than short position, need to split
            var order1 = (IOrder)order.Clone();
            order1.Side = SideType.Cover;
            order1.Size = maxCover;
            order1.OrderStatus = BamOrderStatus.Marked;
            markedOrders.Add(order1);

            IOrder order2 = order;
            order2.Side = SideType.Buy;
            order2.Size = Math.Abs(order.Size - maxCover);
            order2.OrderStatus = BamOrderStatus.Marked;

            markedOrders.Add(order2);

            VersionOrderIds(order, markedOrders);

            msg = $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] MarkSide: Symbol={order.Security.BamSymbol}; Portfolio={order.Portfolio}; Original Order={origSize}[{origSide}]; NetAggUnitPosition={firmCurrentComplianceSize}; Long marking compliance position={longComplianceSize};  Omni size {omniSize}; CrossZeroSplit order 1 = {order1.Size}[{order1.Side}]";
            LogEvent(order1, msg);

            msg = $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] MarkSide: Symbol={order.Security.BamSymbol}; Portfolio={order.Portfolio}; Original Order={origSize}[{origSide}]; NetAggUnitPosition={firmCurrentComplianceSize}; Long marking compliance position={longComplianceSize};  Omni size {omniSize}; CrossZeroSplit order 2 = {order2.Size}[{order2.Side}]";
            LogEvent(order2, msg);

            return markedOrders;

            #endregion Marking Long/Buy orders
        }

        public IList<IOrder> MarkOrder(IEnumerable<KeyValuePair<IOrder, IPositionSet>> items)
        {
            List<IOrder> markedOrders = new List<IOrder>();
            foreach (var item in items)
            {
                markedOrders.AddRange(MarkOrder(item.Key, item.Value));
            }
            return markedOrders;
        }

        private void VersionOrderIds(IOrder originalOrder, IList<IOrder> newOrders)
        {
            var version1 = _clientOrderIdRepository.IncrementVersion(originalOrder.ClientOrderId);
            var version2 = _clientOrderIdRepository.IncrementVersion(version1);

            newOrders[0].ClientOrderId = version1;
            newOrders[1].ClientOrderId = version2;
        }

        private void LogEvent(IOrder order, string msg)
        {
            _log.Info(msg);
            Task.Run(() =>
            {
                var logEvent = new DataFlowEvent(EventCategory.Order, order.ClientOrderId, BamSystem.ORDER_MARKER,
                    DateTime.Now,
                    msg, null, order.ToString(), BamSystem.POSITION_TRACKER);
                _eventLogger.SendSuccessEvent(logEvent);
            });
        }
    }
}
