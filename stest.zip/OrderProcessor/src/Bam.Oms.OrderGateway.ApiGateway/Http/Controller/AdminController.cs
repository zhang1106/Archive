﻿using System;
using System.Security.Principal;
using System.Web.Http;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Time;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class AdminController : BaseController
    {
        private readonly IClock _clock;
        private readonly IRollBlotterSubmission _rollBlotterSubmission;

        public AdminController(
            IClock clock,
            IPermissionedEntityFilter entityFilter, 
            IRollBlotterSubmission rollBlotterSubmission) : base(entityFilter)
        {
            _clock = clock;
            _rollBlotterSubmission = rollBlotterSubmission;
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public string RollBlotter()
        {
            Logger?.LogInformation($"{User.GetLogin()} triggered blotter roll");
            _rollBlotterSubmission.StartRoll(_clock.Now, User.GetLogin(), false, null);
            return $"Sent roll blotter message at {_clock.Now} by {User.GetLogin()}";
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public string ChangeBusinessDay(DateTime businessDay)
        {
            Logger?.LogInformation($"{User.GetLogin()} changed business day to {businessDay}");
            _rollBlotterSubmission.ChangeBusinessDay(businessDay.Date, User.GetLogin());           
            return $"Changed business day to {businessDay.Date} by {User.GetLogin()}";
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public string ForceRollBlotter()
        {
            Logger?.LogInformation($"{User.GetLogin()} triggered forced roll");
            _rollBlotterSubmission.StartRoll(_clock.Now, User.GetLogin(), true, null);
            return $"Sent forced roll blotter message at {_clock.Now} by {User.GetLogin()}";
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public string ForceRollBlotter(DateTime nextBusinessDay)
        {
            Logger?.LogInformation($"{User.GetLogin()} triggered forced roll to {nextBusinessDay}");
            _rollBlotterSubmission.StartRoll(_clock.Now, User.GetLogin(), true, nextBusinessDay.Date);
            return $"Sent forced roll blotter message at {_clock.Now} by {User.GetLogin()}, next business day will be {nextBusinessDay}";
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public string PrepareSnapshotRecovery()
        {
            Logger?.LogInformation($"{User.GetLogin()} triggered snapshot recovery preparation");
            _rollBlotterSubmission.PrepareSnapshotRecovery(User.GetLogin());
            return "Generating snapshot recovery files and shutting down order gateway";
        }
    }
}