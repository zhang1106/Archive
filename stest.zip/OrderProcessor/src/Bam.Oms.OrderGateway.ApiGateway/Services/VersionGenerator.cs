﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Snapshot;
using Bam.Oms.OrderGateway.ApiGateway.Models.Snapshot;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public class VersionGenerator : IVersionGenerator, 
        ISnapshotRecoverable<OrderVersionSnapshot>,
        ISnapshotRecoverable<PositionVersionSnapshot>
    {
        private readonly Dictionary<string, int> _lastOrderVersion;
        private readonly Dictionary<long, int> _lastPositionVersion;
        private int _positionIdSeed;

        public VersionGenerator()
        {
            _lastOrderVersion = new Dictionary<string, int>();
            _lastPositionVersion = new Dictionary<long, int>();
        }

        public int NextOrderVersion(string clientOrderId)
        {
            int current;
            _lastOrderVersion.TryGetValue(clientOrderId, out current);
            _lastOrderVersion[clientOrderId] = ++current;
            return current;
        }

        public int NextPositionVersion(long positionId)
        {
            int current;
            if (!_lastPositionVersion.TryGetValue(positionId, out current))
            {
                current = _positionIdSeed;
            }

            _lastPositionVersion[positionId] = ++current;
            return current;
        }

        OrderVersionSnapshot ISnapshotRecoverable<OrderVersionSnapshot>.Persist()
        {
            var snapshot = new OrderVersionSnapshot();
            _lastOrderVersion.CopyTo(snapshot.LastVersion);
            return snapshot;
        }

        void ISnapshotRecoverable<PositionVersionSnapshot>.Recover(PositionVersionSnapshot snapshot)
        {
            _positionIdSeed = snapshot.MaxVersion;
        }

        void ISnapshotRecoverable<OrderVersionSnapshot>.Recover(OrderVersionSnapshot snapshot)
        {
            snapshot.LastVersion.CopyTo(_lastOrderVersion);
        }

        PositionVersionSnapshot ISnapshotRecoverable<PositionVersionSnapshot>.Persist()
        {
            return new PositionVersionSnapshot
            {
                MaxVersion = _lastPositionVersion.Max(v => v.Value)
            };
        }
    }
}