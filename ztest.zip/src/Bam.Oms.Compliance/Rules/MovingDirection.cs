﻿namespace Bam.Oms.Compliance.Rules
{
    public enum MovingDirection
    {
        Exceed,
        FallBelow,
        NoChange,
        NoHistory
    }
}
