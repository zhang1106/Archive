﻿using System;
using System.Collections.Generic;
using System.Web.Http.Dependencies;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;
using IDependencyResolver = System.Web.Http.Dependencies.IDependencyResolver;

namespace Bam.Oms.EndPoints.Http
{
    public class DependencyResolver : DefaultDependencyResolver, IDependencyResolver
    {
        public void Dispose()
        {
            base.Dispose();

            //    ((IDisposable)Container.Instance).Dispose();
        }

        public override object GetService(Type serviceType)
        {
            try
            {
                return Container.Instance.Resolve(serviceType);
            }
            catch (Exception ex)
            {
                return base.GetService(serviceType);
            }
        }

        public override IEnumerable<object> GetServices(Type serviceType)
        {
            try
            {
                return Container.Instance.ResolveAll(serviceType);
            }
            catch (Exception)
            {
                return base.GetServices(serviceType);
            }
        }

        public IDependencyScope BeginScope()
        {
            return this;
        }
    }
}