﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Securities;
using BAM.Infrastructure.Ioc;


namespace Bam.Oms.Compliance.DataProvider
{
    public class DwSecurityProvider : ISecurityProvider
    {
        private readonly ISecurityDBRepository _securityDbRepository;
        
        private readonly ILogger _logger;
        private readonly ISettings _settings;
        private DateTime _lastUpdated;
        private bool _keepRunning;
        private object _lock = new object();

        public DwSecurityProvider(ISecurityDBRepository securityDbRepository, ILogger logger, ISettings settings)
        {
            _securityDbRepository = securityDbRepository;
            _logger = logger;
            _settings = settings;
            Securities = new ConcurrentDictionary<string, ISecurity>();
            _keepRunning = true;
        }

        public  ConcurrentDictionary<string, ISecurity> Securities { get; }

        public ILookup<string, ISecurity> SecuritiesByIsin { get; set; }

        public ILookup<string, ISecurity> AdrLookup { get; set; }

        protected void RefreshData(DateTime lastUpdated)
        {
            _logger.Info($"Security: Refresh securities since {lastUpdated}");
            var securities = _securityDbRepository.GetSecurities(null, lastUpdated).ToList();
            
             
            if (!securities.Any())
            {
                _logger.Info("Security: No security udpates found since last time.");
                return;
            }

            _logger.Info($"Security: Update {securities.Count()} securities");

            UpdateSecurites(securities);
         
        }

        public void UpdateSecurites(IEnumerable<Security> securities)
        {
            if (securities == null || !securities.Any()) return;

            var toExcludeLookup = ExcludedSecurities.ToLookup(e => e);

            foreach (var s in securities)
            {
                if (!toExcludeLookup.Contains(s.BamSymbol))
                {
                    Securities.AddOrUpdate(s.BamSymbol, s, (key, old) => s);
                }
            }

            lock (_lock)
            {
                AdrLookup = Securities.Values.Where(d => !string.IsNullOrEmpty(d.AdrCode)).ToLookup(d => d.AdrCode, d => d);

                SecuritiesByIsin = Securities.Values.Where(d => !string.IsNullOrEmpty(d.Isin)).ToLookup(d => d.Isin, d => d);
            }
        }

        public void RefreshData()
        {
            if (Securities == null || !Securities.Any())
            {
                _lastUpdated = DateTime.Now;
                RefreshData(default(DateTime));
            }
            RefreshData(_lastUpdated);
            _lastUpdated = DateTime.Now;
        }

        public IEnumerable<ISecurity> GetUnderlyingSecurities()
        {
            return Securities.Where(s => s.Key == s.Value.UnderlyingSymbol).Select(s => s.Value);
        }

        public IEnumerable<ISecurity> GetADRs(string symbol)
        {
            return AdrLookup.Contains(symbol) ? AdrLookup[symbol] : null;
        }

        public ISecurity GetSecurity(string bamSymbol)
        {
            if(string.IsNullOrEmpty(bamSymbol)) return null;
            return Securities.ContainsKey(bamSymbol) ? Securities[bamSymbol] : null;
        }

        public void RetriveRelatedSecurites(IEnumerable<string> symbols, out IList<string> notExist,
            out IList<string> related)
        {
            var list = symbols.ToList();
            notExist = list.Where(s => !Securities.ContainsKey(s)).Distinct().ToList();
            var isins = list.Where(s => GetSecurity(s) != null).Select(s=>GetSecurity(s).Isin);
            var relatedSecurities = isins.SelectMany(i => SecuritiesByIsin[i]);
            related = relatedSecurities.Select(s => s.UnderlyingSymbol).Union(symbols).Distinct().ToList();
        }

        public void RetrieveSecurities(string[] underlyings)
        {
            var securites = _securityDbRepository.GetSecurities(underlyings);
            UpdateSecurites(securites);
        }

        public IList<string> ExcludedSecurities => new List<string>();
        
        public void Start()
        {
            Task.Factory.StartNew(() =>
            {
                while (_keepRunning)
                {
                    Thread.Sleep(_settings.SecurityRefreshRequency * 60 * 1000);
                    RefreshData();
                }
            });
        }

        public void Stop()
        {
            _keepRunning = false;
        }
    }
}
