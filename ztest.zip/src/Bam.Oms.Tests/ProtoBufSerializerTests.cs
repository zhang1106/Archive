﻿using System;
using System.Collections;
using System.Runtime.Serialization;
using System.Text;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Serialization;
using FluentAssertions;
using NUnit.Framework;
using Ploeh.AutoFixture;
using Ploeh.AutoFixture.Kernel;

namespace Bam.Oms.Tests
{    
    [TestFixture]
    public class ProtoBufSerializerTests
    {        
        [TestCaseSource(nameof(Entities))]
        public void VerifyRoundtripSerialization<T>(T expected)
        {
            // arange
            var sut = new ProtoBufSerializer();

            // act
            var buffer = sut.Serialize(expected);
            var actual = sut.Deserialize<T>(buffer);

            // assert
            expected.ShouldBeEquivalentTo(actual);
        }

        [Test]
        public void VerifyThrowsOnInvalidJson()
        {
            // arange
            var sut = new ProtoBufSerializer();

            // act
            Action act = () => sut.Deserialize<BlockTrade>(Encoding.UTF8.GetBytes("asdf"));

            // assert
            act.ShouldThrow<SerializationException>();
        }
        
        public static IEnumerable Entities
        {
            get
            {
                var fixture = new Fixture();
                fixture.Customizations.Add(new TypeRelay(typeof(IPosition), typeof(Position)));
                fixture.Customizations.Add(new TypeRelay(typeof(ICompliancePosition), typeof(CompliancePosition)));
                fixture.Customizations.Add(new TypeRelay(typeof(IAggUnitPosition), typeof(AggUnitPosition)));
                fixture.Customizations.Add(new TypeRelay(typeof(ISecurity), typeof(Security)));
                fixture.Customizations.Add(new TypeRelay(typeof(IComplianceGroupKey), typeof(ComplianceGroupKey)));
                fixture.Customizations.Add(new TypeRelay(typeof(IAggUnitKey), typeof(AggUnitKey)));

                yield return fixture.Create<BlockTrade>();                
                yield return fixture.Create<Security>();
                yield return fixture.Create<Order>();
                
                yield return fixture.Create<ClientOrderId>();

                yield return new AggUnitKey("test", new Security { BamSymbol = "123" });
            }
        }
    }
}
