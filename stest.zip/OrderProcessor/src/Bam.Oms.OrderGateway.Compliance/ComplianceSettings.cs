﻿using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.Compliance
{
    public class ComplianceSettings : SettingsBase
    {
        public ComplianceSettings()
            : base("Compliance.")
        {
        }

        public string SodPositionServiceUri
        {
            get { return GetValue(() => SodPositionServiceUri); }
        }

        public string[] SecurityTypesCoveredByOwnershipRules
        {
            get { return GetValue(() => SecurityTypesCoveredByOwnershipRules); }
        }

        public bool OwnershipMonitoringMode
        {
            get { return GetValue(() => OwnershipMonitoringMode); }
        }

        public long MaximumOrderSize
        {
            get { return GetValue(() => MaximumOrderSize, 50000000); }
        }

        public RingBufferSettings Queue { get; } = new RingBufferSettings("Compliance.Queue.");
        public override string SelfPubSub => Endpoints.CompliancePubSub;
        public override string SelfRpc => Endpoints.ComplianceRpc;
        public override Source SelfSource => Source.Compliance;

        public string EmsDatabaseConnection { get { return GetValue(() => EmsDatabaseConnection); } }
    }
}
