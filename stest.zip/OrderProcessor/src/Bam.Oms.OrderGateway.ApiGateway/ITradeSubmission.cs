﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface ITradeSubmission
    {
        bool Submit(List<Trade> trades);
    }
}
