﻿namespace Bam.Oms.Data
{
    public interface IPersistentItem
    {
        //Key
        string Key { get; }
    }
}

