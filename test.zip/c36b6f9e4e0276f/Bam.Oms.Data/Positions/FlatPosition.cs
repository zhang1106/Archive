﻿using System;

namespace Bam.Oms.Data.Positions
{
    public class FlatPosition
    {
        public string BamSymbol { get; set; }
        public string UnderlyingSymbol { get; set; }
        public string Isin { get; set; }
        public string CompositeParent { get; set; }
        public string SecurityType { get; set; }
        public string Strategy { get; set; }
        public string CustodianAcct { get; set; }
        public string Entity { get; set; }
        public long Quantity { get; set; }
        public string PositionType { get; set; }
        public DateTime TimeStamp { get; set; }
    }
}
