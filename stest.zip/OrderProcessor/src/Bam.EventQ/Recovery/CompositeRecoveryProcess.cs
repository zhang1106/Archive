﻿namespace Bam.EventQ.Recovery
{
    public class CompositeRecoveryProcess : IRecoveryProcess
    {
        private readonly IRecoveryProcess[] _processes;

        public CompositeRecoveryProcess(params IRecoveryProcess[] processes)
        {
            _processes = processes;
        }

        public bool Execute(int? topic, long sequence)
        {
            foreach (var recoveryProcess in _processes)
            {
                if (recoveryProcess.Execute(topic, sequence))
                    return true;
            }

            return false;
        }
    }
}
