﻿using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;

namespace Bam.Oms.PositionTracker
{
    public interface IPositionEffectCalculator
    {
        void ApplyEffects(IPositionSet set, IOrder currentOrder, IBlockTrade currentTrade, IOrder updatedOrder, IBlockTrade updatedTrade);
        void ReplacePosition(IPositionSet set, IPosition replacement);
    }
}