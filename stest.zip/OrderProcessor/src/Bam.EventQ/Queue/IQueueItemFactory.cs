﻿namespace Bam.EventQ.Queue
{
    public interface IQueueItemFactory<out TItem>
    {
        TItem Create();
    }
}
