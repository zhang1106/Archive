﻿namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class HeadroomFileListenerSettings : FileListenerSettings
    {
        public HeadroomFileListenerSettings() : base("HeadroomFileListener")
        {
        }
    }
}