﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.SodPosition.Svc
{
    public class Constants
    {
        public const string UNDO_ACTION_NAME = "UNDO";

        public const string POSITION_BULK_INSERT_ACTION_NAME = "POSITION_BULK_INSERT";

        public const string POSITION_INSERT_ACTION_NAME = "POSITION_INSERT";

        public const string POSITION_UPDATE_ACTION_NAME = "POSITION_UPDATE";

        public const string POSITION_BULK_UPDATE_ACTION_NAME = "POSITION_BULK_UPDATE";

        public const string PUBLISH_LOADED_POSITIONS_ACTION_NAME = "PUBLISH_LOADED_POSITIONS";

        public const string DAILY_LOADING_ACTION_NAME_SUFFIX = "_DAILY_LOADING";

        public const string BAM_ACTION_TYPE = "bam";

        public const string CORP_ACTION_TYPE = "corp";
    }
}
