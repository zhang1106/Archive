﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Web.Http;
using Bam.Oms.Data.Positions;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.PermissionService;
using Bam.Oms.SodPosition.Svc;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.SodPosition
{
    //TODO: THIS NEEDS TO BE INTEGRATED INTO THE REST OF THE DESIGN PATTERN FOR RESTFUL REQ/RESP

    public class SodPositionController : BaseController, IDisposable
    {
        private readonly ISodPositionEdit _sodPostionEdit;

        public SodPositionController(ISodPositionEdit sodPositionEdit, IHostConfiguration hostConfiguration, ILogger logger)
            : base(hostConfiguration, logger)
        {
            if (sodPositionEdit == null) throw new ArgumentNullException("sodPositionEdit");
            _sodPostionEdit = sodPositionEdit;
        }

        public new void Dispose()
        {
            base.Dispose();

            if (_sodPostionEdit != null)
            {
                _sodPostionEdit.Dispose();
            }
        }

        [HttpGet]
        public string Whatup()
        {
            return "Hello World!";
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public IList<Position> Get()
        {
            IList<Position> rList = Get(asofdate: null, stream: null, fundCode: null, custodianAccountCode: null,
                strategyCode: null, securityType: null, bamSymbol: null);
            return rList;
        }

      
        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public List<Position> Get(DateTime? cutoffTime)
        {
            cutoffTime = !cutoffTime.HasValue ? DateTime.Today.ToUniversalTime() : cutoffTime.Value.ToUniversalTime();
            IList<Position> sodPositions = _sodPostionEdit.GetSodPositions(asofdate: null, stream: null, fundCode: null, custodianAccountCode: null,
                strategyCode: null, securityType: null, bamSymbol: null);

            var positions = sodPositions.Where(r=>r.LastModifiedOn > cutoffTime);

            return FilterPermissionedEntities(positions).ToList();
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public List<Position> Get(string bamSymbol)
        {
            if (string.IsNullOrWhiteSpace(bamSymbol))
            {
                return new List<Position>();
            }

            IList<Position> sodPositions = _sodPostionEdit.GetSodPositions(asofdate: null, stream: null, fundCode: null, custodianAccountCode: null,
                strategyCode: null, securityType: null, bamSymbol: null);

            var positions = sodPositions.Where(r => r.Security.BamSymbol.ToUpper() == bamSymbol.ToUpper());

            return FilterPermissionedEntities(positions).ToList();
        }

        /// <summary>
        /// This "get" will exclude data which is initally loaded from a source file since the consumers already have the data.
        /// </summary>
        /// <param name="cutoffTime"></param>
        /// <returns></returns>
        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public List<Position> GetUpdates(DateTime? cutoffTime)
        {
            cutoffTime = !cutoffTime.HasValue ? DateTime.Today.ToUniversalTime() : cutoffTime.Value.ToUniversalTime();
            IList<Position> sodPositions = _sodPostionEdit.GetSodPositions(asofdate: null, stream: null, fundCode: null, custodianAccountCode: null,
                strategyCode: null, securityType: null, bamSymbol: null);

            var positions = sodPositions.Where(r => r.AuditSequence > 0 && r.LastModifiedOn > cutoffTime);
            return FilterPermissionedEntities(positions).ToList();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="asofdate"></param>
        /// <param name="stream"></param>
        /// <param name="fundCode"></param>
        /// <param name="custodianAccountCode"></param>
        /// <param name="strategyCode"></param>
        /// <param name="securityType"></param>
        /// <param name="bamSymbol"></param>
        /// <returns></returns>
        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public IList<Position> Get(DateTime? asofdate, string stream, string fundCode, string custodianAccountCode, string strategyCode, string securityType, string bamSymbol)
        {
            IList<Position> sodPositions = _sodPostionEdit.GetSodPositions(asofdate, stream, fundCode, custodianAccountCode, strategyCode, securityType, bamSymbol);
            return FilterPermissionedEntities(sodPositions).ToList();
        }

        /// <summary>
        /// get latest updated positions which have not been published
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public IList<Position> GetLastestUpdates(string stream)
        {
            IList<Position> sodPositions = _sodPostionEdit.GetLatestUpdatedPositions(stream);
            return FilterPermissionedEntities(sodPositions).ToList();
        }

        /// <summary>
        /// get list of audit trails for a poistion
        /// </summary>
        /// <param name="positionId"></param>
        /// <param name="entrydate"></param>
        /// <returns></returns>
        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public IList<PositionAudit> GetAudits(int positionId, DateTime entrydate)
        {
            IList<PositionAudit> positionAudits = _sodPostionEdit.GetAudits(positionId, entrydate);
            return FilterPermissionedEntities(positionAudits).ToList();
        }

        /// <summary>
        /// update a position
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="position"></param>
        /// <returns></returns>
        [HttpPost]
        [AccessRequire("Function.OrderGateway.Position.Write")]
        public Position PutPosition(Position position)
        {
            var permissionedPositions = FilterPermissionedEntities(new List<Position>() { position });
            return permissionedPositions.Any() ? _sodPostionEdit.UpdatePosition(position) : null;
        }

        /// <summary>
        /// insert a position
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpPost]
        [AccessRequire("Function.OrderGateway.Position.Write")]
        public Position PostPosition(Position position)
        {
            var permissionedPositions = FilterPermissionedEntities(new List<Position>() { position });
            return permissionedPositions.Any() ? _sodPostionEdit.InsertPosition(position) : null;
        }

        /// <summary>
        /// bulk inert poistions
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpPost]
        [AccessRequire("Function.OrderGateway.Position.Write")]
        public IList<Position> PostPositions(IList<Position> positions)
        {
            var permissionedPositions = FilterPermissionedEntities(positions);
            return permissionedPositions.Any() ? _sodPostionEdit.BulkInsertPosition(positions) : null;
        }

        /// <summary>
        /// bulk update positions
        /// </summary>
        /// <param name="userId"></param>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpPost]
        [AccessRequire("Function.OrderGateway.Position.Write")]
        public IList<Position> PutPositions(IList<Position> positions)
        {
            var permissionedPositions = FilterPermissionedEntities(positions);
            return permissionedPositions.Any() ? _sodPostionEdit.BulkUpdatePosition(positions) : null;
        }


        /// <summary>
        /// broadcast updtes to intested parties through files, events
        /// In the future, the updates will be published to a Queue
        /// </summary>
        /// <param name="positions"></param>
        /// <returns></returns>
        [HttpPost]
        [AccessRequire("Function.OrderGateway.Position.Write")]
        public bool Publish(string stream)
        {
            //var permissionedPositions = FilterPermissionedEntities(positions);
            //      return permissionedPositions.Any() && _sodPostionEdit.PublishUpdatedPositions(userId);
            return _sodPostionEdit.PublishUpdatedPositions(stream);
        }

        /// <summary>
        /// Fetch list of corporate actions
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public IList<SodAction> GetBulkActions()
        {
            return _sodPostionEdit.GetBulkActions();
        }

        [HttpPost]
        [AccessRequire("Function.OrderGateway.Position.Write")]
        public IList<Position> ExecuteUndo(int positionId, IList<Position> undoList)
        {
            return _sodPostionEdit.ExecuteUndo(positionId, undoList);
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public IList<Position> GetUndoChanges(int positionId)
        {
            return _sodPostionEdit.GetUndoChanges(positionId);
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public IList<string> GetStreams()
        {
            return _sodPostionEdit.GetStreams();
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public string GetLatestLoadedStream()
        {
            return _sodPostionEdit.GetLatestLoadedStream();
        }

        protected IEnumerable<Position> FilterPermissionedEntities(IEnumerable<Position> positions)
        {
            if (!PermissionChecker.IsPermissionEnabled())
            {
                _logger.Warn("DEV or QA. Skipping permissions.");
                return positions;
            }
            StrategyInfo[] strategiesInfos = GetPermissionedStrategies(User.Identity);
            _logger.Debug($"The user {User.Identity.Name} is permissiond for {String.Concat(strategiesInfos, ",")}.");
            return positions.Where(
                    position => strategiesInfos.Any(s => position.Portfolio.ToString().Contains(s.StrategyCode)))
                    .ToList();
        }

        protected IEnumerable<PositionAudit> FilterPermissionedEntities(IEnumerable<PositionAudit> positions)
        {
            if (!PermissionChecker.IsPermissionEnabled())
            {
                _logger.Warn("DEV or QA. Skipping permissions.");
                return positions;
            }
            StrategyInfo[] strategiesInfos = GetPermissionedStrategies(User.Identity);
            _logger.Debug($"The user {User.Identity.Name} is permissiond for {String.Concat(strategiesInfos, ",")}.");
            return positions.Where(
                    position => strategiesInfos.Any(s => position.Position.Portfolio.ToString().Contains(s.StrategyCode)))
                    .ToList();
        }
    }
}
