﻿using System;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.RefData
{
    public class MissingSecurityException : Exception
    {
        public MissingSecurityException(ISecurity security) : base($"No matching security for {security}")
        {
        }
    }
}