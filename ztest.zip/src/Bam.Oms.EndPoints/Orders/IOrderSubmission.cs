﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.EndPoints.Orders
{
    public interface IOrderSubmission
    {
        void AcceptOrders();
        event Action<IList<IOrder>,string, bool> NewOrdersReady;
        event Action<IList<string>> NewCancelOrdersReady;
        event Action<IList<string>> NewDeleteOrdersReady;
        event Action<IOrder> NewReplaceOrdersReady;
        event Action<Tuple<IList<string>, string>> NewOrdersToRouteReady;
        event Action<IList<string>> LocateRequestReceived;
    }
}