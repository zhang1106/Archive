﻿using AutoMapper;
using AutoMapper.Mappers;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.SodPosition.Svc
{
    class MappingEngineFactory
    {
        public static IMappingEngine GetSodPositionMapper()
        {
            var configurationStore = GetSodPositionMappingConfiguration();
            return new MappingEngine(configurationStore);
        }

        private static ConfigurationStore GetSodPositionMappingConfiguration()
        {
            ConfigurationStore config = new ConfigurationStore(new TypeMapFactory(), MapperRegistry.Mappers);

            config.CreateMap<DBModel.Action, SodAction>();
            config.CreateMap<DBModel.PositionAudit, PositionAudit>()
                .ForMember(x => x.Position, ops => ops.MapFrom(r => r));
            config.CreateMap<SodActionLog, DBModel.ActionLog>().ReverseMap();

            config.CreateMap<DBModel.PositionAudit, DBModel.Position>();
            config.CreateMap<DBModel.Position, Position>()
                                      .ConstructUsing(x =>
                                      new Position(Portfolio.Parse(x.StrategyCode), new Security() { BamSymbol = x.BAMSymbol, SecurityType = Enum.IsDefined(typeof(SecurityType), x.AssetType) ? Bam.Oms.Data.Utility.ConvertEnum<SecurityType>(x.AssetType) : default(SecurityType), Currency = x.Ccy }))
                                      .ForMember(x => x.ActualQuantity, ops => ops.MapFrom(r => Math.Abs(r.Qty)))
                                      .ForMember(x => x.ActualSide, ops => ops.MapFrom(r => r.Qty < 0 ? SideType.Short : SideType.Long))
                                      .ForMember(x => x.TheoreticalQuantity, ops => ops.MapFrom(r => Math.Abs(r.Qty)))
                                      .ForMember(x => x.TheoreticalSide, ops => ops.MapFrom(r => r.Qty < 0 ? SideType.Short : SideType.Long))
                                      .ForMember(x => x.Portfolio, ops => ops.Ignore())
                                      .ForMember(x => x.Security, ops => ops.Ignore())
                                      ;

            config.CreateMap<Position, DBModel.Position>()
                .ForMember(x => x.Qty, ops => ops.MapFrom(r => r.ActualSide == SideType.Long ? r.ActualQuantity : -r.ActualQuantity))
                .ForMember(x => x.BAMSymbol, ops => ops.MapFrom(r => r.Security.BamSymbol))
                .ForMember(x => x.Ccy, ops => ops.MapFrom(r => r.Security.Currency))
                .ForMember(x => x.StrategyCode, ops => ops.MapFrom(r => r.Portfolio.ToString()))
                .ForMember(x => x.AssetType, ops => ops.MapFrom(r => r.Security.SecurityType.ToString()))
                ;
            config.CreateMap<DBModel.PositionAudit, PositionAudit>()
                .ForMember(x => x.Position, ops => ops.MapFrom(r => r));
            config.CreateMap<DBModel.PositionAudit, Position>()
                .ConstructUsing(x =>
                          new Position(Portfolio.Parse(x.StrategyCode), new Security() { BamSymbol = x.BAMSymbol, SecurityType = Enum.IsDefined(typeof(SecurityType), x.AssetType) ? Bam.Oms.Data.Utility.ConvertEnum<SecurityType>(x.AssetType) : default(SecurityType), Currency = x.Ccy }))
                          .ForMember(x => x.ActualQuantity, ops => ops.MapFrom(r => Math.Abs(r.Qty)))
                          .ForMember(x => x.ActualSide, ops => ops.MapFrom(r => r.Qty < 0 ? SideType.Short : SideType.Long))
                          .ForMember(x => x.TheoreticalQuantity, ops => ops.MapFrom(r => Math.Abs(r.Qty)))
                          .ForMember(x => x.TheoreticalSide, ops => ops.MapFrom(r => r.Qty < 0 ? SideType.Short : SideType.Long))
                          .ForMember(x => x.Portfolio, ops => ops.Ignore())
                          .ForMember(x => x.Security, ops => ops.Ignore())
                          ;

            return config;
        }
    }
}
