﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Net.Http;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using System.Web.Security;
using Bam.Oms.OrderRouting.EZE;
using Bam.Oms.EndPoints.Http;
using BAM.Infrastructure.Ioc;
using Eze.Common.Integration;

namespace Bam.Oms.EndPoints.Eze
{
    public class PublishCaptureController : BaseController
    {
        private readonly IMessageHandler _messageHandler;

        public PublishCaptureController(IMessageHandler messageHandler, IHostConfiguration hostConfiguration, ILogger logger) 
            : base(hostConfiguration, logger)
        {
            if(messageHandler == null) throw new ArgumentNullException(nameof(messageHandler));
            _messageHandler = messageHandler;
        }

        [HttpGet]
        public string Whatup()
        {
            return "Hello";
        }

        //  URL: /API/PublishCapture/Trade
        [HttpPost]
        public HttpResponseMessage Trade()
        {
            try
            {
                var owinContext = Request.GetOwinContext();
                var body = new StreamReader(owinContext.Request.Body).ReadToEnd();
                //received trade
                _logger.Debug("Receive Eze Trade Message: " + StripPassword(body));
                _messageHandler.ProcessMessage(body, MessageHandler.EzeOrders);
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex);
            }
        }

        public static string StripPassword(string msg)
        {
            const string pattern = "\"[Pp]assword\":\"[^\"]*\"";
            var rgx = new Regex(pattern);
            var replaced = rgx.Replace(msg, "\"password\":\"\"");
            return replaced;
        }

        // URL: /API/PublishCapture/Allocation
        //disabled
        [HttpPost]
        public HttpResponseMessage Allocation()
        {
            try
            {
                var owinContext = Request.GetOwinContext();
                var body = new StreamReader(owinContext.Request.Body).ReadToEnd();
                //received allocations
                _logger.Debug("Receive Eze Allocation Message: " + StripPassword(body));
                _messageHandler.ProcessMessage(body, MessageHandler.EzeAllocations);
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex);
            }

        }

        // URL: /API/PublishCapture/Order
        //disabled
        [HttpPost]
        private HttpResponseMessage Order()
        {
            try
            {
                var owinContext = Request.GetOwinContext();
                var body = new StreamReader(owinContext.Request.Body).ReadToEnd();
                //process orders
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex);
            }
        }
    }
}
