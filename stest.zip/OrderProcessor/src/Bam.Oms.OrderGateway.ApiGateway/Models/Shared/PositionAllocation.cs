﻿namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class PositionAllocation
    {
        public PositionAllocation(PositionAllocationKey key)
        {
            Fund = key.Fund;
            Custodian = key.Custodian;
        }

        public string Fund { get; }
        public string Custodian { get; }
        public long Quantity { get; set; }
    }
}
