﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net.Mail;
using RazorEngine;

namespace Bam.Oms.Compliance.Actions
{
    //need refactor the email functionality to framework level
    public class FirmPositionAlertEmail : IAction
    {
        public static string BuildHtml(string template, dynamic data)
        {
            return Razor.Parse(template, data);
        }

        public static string GetTemplate(string completFilePath)
        {
            using (var sr = new StreamReader(completFilePath))
            {
                return sr.ReadToEnd();
            }
        }

        public static void SendEmail(string subject, string body, string from, string to, string cc, string bcc, IEnumerable<string> pdfAttachments = null, Dictionary<string, byte[]> pdfAttachmentsMemory = null)
        {
            var message = new MailMessage();

            message.From = new MailAddress(from);
          
            AddEmailAddressToMessage(message, from, to, cc, bcc);

            //Attachments from disk
            if (pdfAttachments != null)
            {
                foreach (var attachment in pdfAttachments.Where(i => !String.IsNullOrWhiteSpace(i)))
                {
                    message.Attachments.Add(new Attachment(attachment));
                }
            }

            //Attachments from memory
            if (pdfAttachmentsMemory != null)
            {
                foreach (var memAttachment in pdfAttachmentsMemory)
                {
                    //var ct = new System.Net.Mime.ContentType(System.Net.Mime.MediaTypeNames.Application.Pdf);
                    message.Attachments.Add(new Attachment(new MemoryStream(memAttachment.Value), memAttachment.Key));
                }
            }

            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = true;

            using (var smtpClient = new SmtpClient())
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Send(message);
            }
        }

        private static void AddEmailAddressToMessage(MailMessage message, string fromAddress, string toAddresses, string ccAddresses, string bccAddresses)
        {
            message.From = new MailAddress(fromAddress);

            var toItems = toAddresses.Split(';', ',').Where(toValue => !String.IsNullOrWhiteSpace(toValue));
            var ccItems = ccAddresses.Split(';', ',').Where(ccValue => !String.IsNullOrWhiteSpace(ccValue));
            var bccItems = bccAddresses.Split(';', ',').Where(bccValue => !String.IsNullOrWhiteSpace(bccValue));

            if (toItems != null)
            {
                foreach (var toAddress in toItems)
                {
                    message.To.Add(toAddress.Trim());
                }
            }

            if (ccItems != null)
            {
                foreach (var ccAddress in ccItems.Where(ccValue => !String.IsNullOrWhiteSpace(ccValue)))
                {
                    message.CC.Add(ccAddress.Trim());
                }
            }

            if (bccItems != null)
            {
                foreach (var bccAddress in bccItems.Where(bccValue => !String.IsNullOrWhiteSpace(bccValue)))
                {
                    message.Bcc.Add(bccAddress.Trim());
                }
            }
        }
    }
}
