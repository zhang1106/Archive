﻿namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class SecurityFileListenerSettings : FileListenerSettings
    {
        public SecurityFileListenerSettings() 
            : base("SecurityFileListener")
        {
        }
    }
}