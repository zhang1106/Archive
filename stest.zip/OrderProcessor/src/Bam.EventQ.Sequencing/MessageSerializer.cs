﻿namespace Bam.EventQ.Sequencing
{
    public abstract class MessageSerializer
    {
        static MessageSerializer()
        {
            Current = Default = new ProtoBufMessageSerializer();
        }

        public abstract int Serialize<T>(T message, byte[] buffer, int index) where T : IMessage;
        public abstract IMessage Deserialize(byte[] buffer, int index, int count);
      
        public static MessageSerializer Default { get; }
        public static MessageSerializer Current { get; set; }
    }
}
