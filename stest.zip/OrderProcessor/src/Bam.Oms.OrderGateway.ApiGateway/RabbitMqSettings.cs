﻿using System;
using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class RabbitMqSettings : AppSettingsBase
    {
        public RabbitMqSettings() : base("ApiGateway.RabbitMq.")
        {

        }

        public string Endpoint
        {
            get { return GetValue(() => Endpoint); }
        }

        public string IntradayTradesExchange
        {
            get { return GetValue(() => IntradayTradesExchange); }
        }

        public string IntradayOrdersExchange
        {
            get { return GetValue(() => IntradayOrdersExchange); }
        }
        
        public TimeSpan RetryInterval
        {
            get { return GetValue(() => RetryInterval, TimeSpan.FromSeconds(5)); }
        }

        public bool PublishTrades
        {
            get { return GetValue(() => PublishTrades, true); }
        }

        public bool PublishOrders
        {
            get { return GetValue(() => PublishOrders, true); }
        }
    }
}
