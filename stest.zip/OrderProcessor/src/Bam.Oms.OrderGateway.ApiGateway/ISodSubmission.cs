﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface ISodSubmission
    {
        void Load(DateTime asOf, IEnumerable<LoadSodPositions.SodItem> sodItems, string user);
        void Update(DateTime asOf, IEnumerable<UpdateSodPositions.SodItem> sodItems, string user);
    }
}
