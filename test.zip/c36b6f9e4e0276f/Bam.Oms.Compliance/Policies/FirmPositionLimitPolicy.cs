﻿using System.Linq;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Enumerators;
using BAM.Infrastructure.Ioc;
using Newtonsoft.Json;

namespace Bam.Oms.Compliance.Policies
{
    public class FirmPositionLimitPolicy: Policy<ICompliancePosition>, IFirmPositionLimitPolicy 
    {
        private const string TestSymbol = "ZVZZT";
        public override void AddRule(IRule<ICompliancePosition>  rule)
        {
            Logger.Info($"Populate Rule:{rule.Name}");
            if (!(rule is FirmRuleBase))
            {
                var mRule = (FirmRuleBase) Helper.ConvertBaseToChild(rule);
                mRule.Init();
                base.AddRule(mRule);
            }
            else
            {
                base.AddRule(rule);
            }
        }
        public void PopulateRules(IRuleRepository<ICompliancePosition> ruleRepository )
        {
            foreach(var rule in ruleRepository.GetRules(Id))
            {
                this.AddRule(rule);
            }
        }
        public override IPolicyResult CheckViolations(ICompliancePosition input, bool isPreCheck)
        {
            var result = new PolicyResult() { PolicyId = Id, PolicyName = Name };

            if (string.IsNullOrEmpty(input.BamSymbol) || input.BamSymbol.ToUpper().Contains(TestSymbol))
            {
                result.Alerts.Add(Helper.CreateNoRuleHeadRoomForAll(input.BamSymbol, Id));
                return result;
            }
            
            foreach (var rule in Rules)
            {
                var inFilter = IsRuleApplying(input, rule);
                
                if (!inFilter) continue;
                
                var ruleResult = (RuleResult)rule.CheckViolation(input, false);
                ruleResult.PolicyId = this.Id;
                result.Alerts.Add(ruleResult);
                ruleResult.ParamsInJson = JsonConvert.SerializeObject(ruleResult);

                if (input.PositionType != PositionType.Eod) continue;

                var cResult = ruleResult.Clone() as RuleResult;
                input.RuleResultRepository.SaveWithDate(cResult);
            }

            if (result.Alerts.Any())
            {
                return result;
            }

            //add isExempt headRoom
            result.Alerts.Add(Helper.CreateNoRuleHeadRoomForAll(input.BamSymbol, Id));
            
            return result;
        }

        protected bool IsRuleApplying(ICompliancePosition input, IRule<CompliancePosition> rule)
        {
            //not generate rules for adrs now
            if (input.Security.IsAdr()) return false;
            
            var inFilter = rule.IsActive && ((FirmRuleBase)rule).SecurityFilter == null || ((FirmRuleBase)rule).SecurityFilter.ApplyFilter(rule.GetType().FullName, input.Security);
            return inFilter;
        }

        private static IHelper Helper => Container.Instance.Resolve<IHelper>();
        private static ILogger Logger => Container.Instance.Resolve<ILogger>();
    }
}
