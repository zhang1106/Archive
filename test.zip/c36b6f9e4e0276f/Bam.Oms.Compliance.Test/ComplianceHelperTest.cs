﻿using System;
using System.Collections.Generic;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Results;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Persistence.Securities;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class ComplianceHelperTest
    {
        [TestCase("4/5/2017 18:00:00.00", "4/5/2017 17:00:00.00", "4/5/2017")]
        [TestCase("4/5/2017 18:00:00.00", "4/5/2017 19:00:00.00", "4/6/2017")]
        [TestCase("4/6/2017 18:00:00.00", "4/6/2017 1:00:00.00", "4/6/2017")]
        public void TestBusinessDate(string sodDateTime, string nowDt, string expected)
        {
            var settings = new Mock<ISettings>();
            settings.SetupGet(s => s.SODDateTime).Returns(Convert.ToDateTime(sodDateTime));
            var helper = Factory.GetHelper(settings.Object);

            var now = Convert.ToDateTime(nowDt);

            var businessDate = helper.GetBusinessDate(now);
            var expectedDate = Convert.ToDateTime(expected);

            Assert.IsTrue(businessDate.Date==expectedDate.Date);
        }

        [TestCase(0.05, 0.1, 1000L, -10L, SideType.Long, ComplianceAlertLevel.Overrideable, true, 60)]
        [TestCase(0.05, 0.1, 1000L, 0L, SideType.Long, ComplianceAlertLevel.Overrideable, true, 50)]
        [TestCase(0.05, 0.1, 1000L, 10L, SideType.Long, ComplianceAlertLevel.Overrideable, true, 40)]
       
        [TestCase(0.05, 0.1, 1000L, -10L, SideType.Short, ComplianceAlertLevel.Overrideable, true, 40)]
        [TestCase(0.05, 0.1, 1000L, 0L, SideType.Short, ComplianceAlertLevel.Overrideable, true, 50)]
        [TestCase(0.05, 0.1, 1000L, 10L, SideType.Short, ComplianceAlertLevel.Overrideable, true, 60)]
        public void TestHeadroomUnitCreation(decimal lowLimit, decimal upLimit, long sharesOutstanding, 
            long? holding, SideType side, ComplianceAlertLevel alertLevel, bool fireOnce, long expected)
        {
            var rule = new Mock<IRule<ICompliancePosition>>();
            rule.SetupGet(r=>r.Ratio).Returns(new Dictionary<string, decimal>()
            {
                {"AQTF",  0m},
                {"MAIN",   1m}
            });

            var threshold = new ThreshholdWarning()
            {
                LowLimit = lowLimit,
                UpLimit = upLimit,
                AlertLevel = ComplianceAlertLevel.Overrideable,
                FireOnce = fireOnce
            };

            var helper = Factory.GetHelper(new Mock<ISettings>().Object);
            var result = new OwnershipFilingResult()
            {
                SharesOutstanding = sharesOutstanding,
                PositionQty = holding,
                HeadRoom = new HeadRoom()
            };

            var unit = helper.CreateHeadRoomUnit(rule.Object, result, threshold, side);
            var expectedUnit = new HeadRoom.HeadRoomUnit()
            {
                Threshold=lowLimit,
                AlertLevel=alertLevel.ToString(),
                FireOnce=fireOnce,
                HeadRoom=expected
            };

            Assert.IsTrue(unit.Equals(expectedUnit));
        }

        [Test]
        public void TestConversion()
        {
           var rule = new Rule<ICompliancePosition>() {Id=1, Name="test", Type= "Bam.Oms.Compliance.Rules.LongOwnerShipFiling" };
            var helper = Factory.GetHelper(new Mock<ISettings>().Object);

            var toChild = helper.ConvertBaseToChild(rule);

            Assert.IsNotNull(toChild);

        }
    }
}
