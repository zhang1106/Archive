﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data.Compliance
{
    public class HeadRoom
    {
        public int RuleId { get; set; }
        public int PolicyId { get; set; }
        public Dictionary<string, decimal> Ratio;
        public decimal SharesOutstanding { get; set; }
        public string RuleName { get; set; }
        public string Identifier { get; set; }
        public string IdentifierType { get; set; }
        public string Side { get; set; }
        public bool IsExempt { get; set; }
        public long? Holding { get; set; }
        public IList<HeadRoomUnit> HeadRooms { get; set; }
        public string Entity { get; set; }
        public bool IncludeConstituent { get; set; }

        public bool Equals(HeadRoom other)
        {
            if (other == null) return false;

            return Identifier == other.Identifier && RuleName == other.RuleName;
        }

        public struct HeadRoomUnit
        {
            public decimal? Threshold { get; set; }
            public long? HeadRoom { get; set; }
            public string AlertLevel { get; set; }
            public bool FireOnce { get; set; }
        }
        
       public struct HRatio
       {
           public string Instance { get; set; }
           public decimal Ratio { get; set; }
       }

    }
}
