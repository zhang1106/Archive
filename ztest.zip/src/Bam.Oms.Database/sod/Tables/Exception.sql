﻿CREATE TABLE [sod].[Exception]
(
	[ExceptionId] INT IDENTITY(1, 1) NOT NULL PRIMARY KEY, 
    [Source] VARCHAR(50) NULL, 
    [Data] VARCHAR(300) NULL,
	[Description] VARCHAR(300) NULL, 
    [UserAffected] VARCHAR(50) NULL, 
    [CreatedOn] DATETIME NOT NULL DEFAULT getdate() 
    
)
