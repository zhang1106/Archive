﻿CREATE PROCEDURE [sod].[usp_loadpositions]
    @CsvPath VARCHAR(300) = '\\fh1-142\Flex\FLEX_SOD_FILE',
	@EntryDate DATE,
    @ArchivePositions BIT = 1,
    @BatchSize INT = 1000,
    @MaxErrors INT = 1000,
    @ErrorBaseDir VARCHAR(300) = '\\fh1-142\Flex\error.csv',
	@Delimiter VARCHAR(20) = ',',
	@Stream VARCHAR(20) = 'US',
	@ErrorStr VARCHAR(1000) = '' OUTPUT
As

if(not @CsvPath like '%.csv')
Begin
    Set @CsvPath = @CsvPath + '_' +  convert(varchar(4), datepart(year, getdate())) 
+ Right('00' + convert(varchar(2), datepart(MONTH, getdate())), 2) 
+ Right('00' + convert(varchar(2), datepart(day, getdate())), 2) + '.csv'
End
    
    DECLARE @actionId INT
    DECLARE @error INT
    DECLARE @errorData VARCHAR(500)
	DECLARE @actionName VARCHAR(30)
    SET @errorData = ''
	SET @actionName = @Stream + '_DAILY_LOADING'
    BEGIN TRY

	    IF OBJECT_ID('tempdb..#tmp') IS NOT NULL DROP TABLE #tmp
		IF OBJECT_ID('tempdb..#errorData') IS NOT NULL DROP TABLE #errorData
	    SELECT "ActionId", 'Data Loading In Process' AS "ActionDetails", CURRENT_USER AS "CreatedBy", GETDATE() AS "CreatedOn"
            FROM [sod].[Action]
                WHERE "Name" = @actionName
                      AND "Type" = 'bam'
	    IF @@ROWCOUNT = 0
		    BEGIN
			    SET @errorData = 'Couldn''t find a matching action in the Action table'
				SET @actionId = -1
			    RAISERROR(@errorData, 11, 1)
	        END
        INSERT INTO [sod].[ActionLog]("ActionId", "ActionDetails", "CreatedBy", "CreatedOn")
          SELECT "ActionId", 'Data Loading In Process' AS "ActionDetails", CURRENT_USER AS "CreatedBy", GETDATE() AS "CreatedOn"
            FROM [sod].[Action]
                WHERE "Name" = @Stream + '_DAILY_LOADING'
                      AND "Type" = 'bam'

        SELECT @actionId = @@IDENTITY

		select @actionId

        CREATE TABLE #tmp (
		    [BAMSymbol]       VARCHAR (100)    NOT NULL,
			[Qty]            DECIMAL (28, 12) NOT NULL,
		    [Price]          DECIMAL (28, 12) NOT NULL,
			[Ccy]            VARCHAR (50)     NOT NULL,
			[FxRate]         DECIMAL (28, 12) NOT NULL,
			[CustodianName]      VARCHAR (50)     NOT NULL,
			[CustodianAccount] VARCHAR(50) NULL,
			[AssetType]    VARCHAR (50)     NOT NULL,
			[StrategyCode]       VARCHAR (50)     NOT NULL,
			[FundCode]           VARCHAR (50)     NOT NULL,
			[Cost]            DECIMAL(28, 12) NULL,
        );

       DECLARE @bulkinsert NVARCHAR(500)
       DECLARE @errorFilePath VARCHAR(300)
       SET @errorFilePath = @ErrorBaseDir --+ '\' + FORMAT ( GETDATE(), 'HHmssmmm', 'en-US' ) + '.txt'

       SET @bulkinsert = N'BULK INSERT #tmp FROM ''' +
                         @CsvPath +
                         N''' WITH ( FIRSTROW=2, FIELDTERMINATOR = ' + 'N''' + @Delimiter + '''' + ', ROWTERMINATOR = ''\n'', ' +
                         N'FIRE_TRIGGERS, MAXERRORS=' +
                         CONVERT(VARCHAR(10), @MaxErrors) + 
                         N', TABLOCK, ERRORFILE = ''' + @errorFilePath + ''')'
        EXEC sp_executesql @bulkinsert;
              -- Check for error file existence
              DECLARE @file_exists INT
              EXEC master.dbo.xp_fileexist @errorFilePath, @file_exists OUTPUT

        Select @file_exists

        IF @file_exists <> 0
            --Error happened
            BEGIN
                DECLARE @errorCount INT
                CREATE TABLE #errorData (data VARCHAR(1000))
                SET @bulkinsert = N'BULK INSERT #errorData FROM ''' +
                                  @errorFilePath +
                                  N''' WITH ( FIELDTERMINATOR = ''\n'', ROWTERMINATOR = ''\n'', MAXERRORS=0)'
                EXEC sp_executesql @bulkinsert
                SELECT @errorCount = COUNT(*) FROM #errorData
                SET @errorData = @errorData + N' ' +
                                          CONVERT(VARCHAR(10), @errorCount) +
                                          N' rows could not be inserted';
                SET @error = 1
            END
    
        if @ArchivePositions = 1
        BEGIN
            INSERT INTO [sod].[PositionArchive]("PositionId", "FundCode", "CustodianName", "CustodianAccountCode", "Cost", "StrategyCode", "AssetType", "BAMSymbol", "Qty", "Price", "Ccy", "FXRate", "EntryDate", "ActionLogId", "AuditSequence", "Stream", "LastModifiedBy", "LastModifiedOn", "CreatedOn")
                SELECT "PositionId", "FundCode", "CustodianName", "CustodianAccountCode", "Cost", "StrategyCode", "AssetType", "BAMSymbol", "Qty", "Price", "Ccy", "FXRate", "EntryDate", "ActionLogId", "AuditSequence", "Stream", "LastModifiedBy", "LastModifiedOn", "CreatedOn"
                    FROM [sod].[Position]
					WHERE "Stream" = @Stream
        END
        DELETE FROM [sod].[Position]
		    WHERE "Stream" = @Stream
        INSERT INTO [sod].[Position] ("Stream", "FundCode", "CustodianName", "StrategyCode", "AssetType", "BAMSymbol", "Qty", "Price",
                                         "Ccy", "FXRate", "CustodianAccountCode", "Cost", "EntryDate", "ActionLogId", "LastModifiedBy")
            SELECT @Stream, "FundCode", "CustodianName", "StrategyCode", "AssetType", "BAMSymbol", "Qty", "Price", "Ccy", "FxRate", "CustodianAccount", "Cost", @EntryDate, @actionId, CURRENT_USER
                FROM #tmp
              IF @error != ''
				      RAISERROR('Error occurred during the process', 11, 1)
        --Everything went fine
        UPDATE [sod].[ActionLog]
            SET "ActionDetails" = N'SUCCESS'
                WHERE "ActionLogId" = @actionId
    END TRY
    BEGIN CATCH
        BEGIN
		    SET @ErrorStr = ERROR_MESSAGE() + N' ' + @errorData
		    SELECT @actionId
		    IF @actionId <> -1
			    BEGIN
                    UPDATE [sod].[ActionLog]
                       SET "ActionDetails" = N'FAILED:' + @ErrorStr
                     WHERE "ActionLogId" = @actionId
		        END
			-- Copy the data to the Exception table
            INSERT INTO [sod].[Exception] ("Source", "Data", "Description", "UserAffected", "CreatedOn")
               SELECT  @actionName, @ErrorStr, 'Error occurred while loading sod positions', CURRENT_USER, GETDATE()
        END
    END CATCH
	IF OBJECT_ID('tempdb..#tmp') IS NOT NULL DROP TABLE #tmp
	IF OBJECT_ID('tempdb..#errorData') IS NOT NULL DROP TABLE #errorData
	Select * from sod.ActionLog

    RETURN