﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.Filters;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IPolicyProvider : IDataProvider
    {
        //get all policies
        IEnumerable<IPolicy<CompliancePosition>> Get(PolicyFilter filter);
        IPolicy<CompliancePosition> Get(string mame);
    }
}
