﻿using System;
using Newtonsoft.Json;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Results;
using BAM.Infrastructure.Ioc;
using BAM.Infrastructure.DataFlowLogging.Client;

namespace Bam.Oms.Compliance.Rules
{
    [JsonObject(MemberSerialization.OptIn)]
    public class LongOwnershipLimit : FirmRuleBase 
    {
        //rule specific
       [JsonProperty]
        public decimal Threshhold { get; set; }
       [JsonProperty]
        public string BamSymbol { get; set; }
        readonly IIntradayPositionProvider _intradayPositionProvider;
        public LongOwnershipLimit(IIntradayPositionProvider intradayPositionProvider, IFactProvider factProvider,  ILogger logger, ILoggingAgent eventLogger)
            : base(factProvider, logger, eventLogger)
        {
            _intradayPositionProvider = intradayPositionProvider;
        }
        public override IRuleResult CheckViolation(CompliancePosition input, bool isPreCheck)
        {
            var result = new OwnershipLimitResult()
            {
                RuleId = this.Id,
                BamSymbol = input.BamSymbol,
                RuleName = this.Name,
                Description = "No violation",
                PolicyId = input.PolicyId,
                IsViolationOverriden = false,
                PositionQty = 0m,
                Type = typeof(OwnershipLimitResult).FullName,
                AlertLevel = ComplianceAlertLevel.NoViolation
            };
            var context = string.Empty;
            try
            {
                //appy filters first
                if (IsActive && String.Compare(BamSymbol, input.BamSymbol, StringComparison.OrdinalIgnoreCase) == 0)
                {
                    var longQuantityInfo = _intradayPositionProvider.GetFirmWideLongQuantity(input.BamSymbol);
                    var longQuantity = longQuantityInfo.Item2;
                    context = longQuantityInfo.Item1;
                    if (!longQuantity.HasValue)
                    {
                        result.AlertLevel = ComplianceAlertLevel.NoDataAvaiable;
                        result.Description = "Position not available";
                    }
                    else
                    {
                        result.AlertLevel = longQuantity.Value >= Threshhold ? ComplianceAlertLevel.Violated : ComplianceAlertLevel.NoViolation;
                        result.Description = result.AlertLevel == ComplianceAlertLevel.Violated ?
                            $"Going above {longQuantity.Value.ToString("N0")} Ownership"
                            : "No Violation";
                        result.PositionQty = longQuantity;
                    }
                    LogEvent(result.Key, context);
                }
            }
            catch(Exception ex)
            {
                result.AlertLevel = ComplianceAlertLevel.Error;
                result.Description = ex.Message;
                LogErrorEvent(result.Key, context);
                _logger.Error(ex.Message);
            }

            return result;
        }
        
    }
}
