﻿using System;
using System.Linq;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Journal;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Persistence.Orders
{
    public class OrderRepository : PersistentRepository<Order>, IOrderRepository
    {
        private readonly HashSet<string> _knownOrderIds;
        public OrderRepository(ILogger log, IEventJournalFactory eventJournalFactory) 
            : base("OrdersCache", log, eventJournalFactory)
        {
            _knownOrderIds = new HashSet<string>(GetAll().Select(o=>o.ClientOrderId).Distinct());
        }

        protected override bool ShouldAppendToJournal(Order order)
        {
            return _knownOrderIds.Add(order.ClientOrderId) ||
                   order.OrderStatus == BamOrderStatus.PendingSend ||
                   order.OrderStatus == BamOrderStatus.PendingAck ||
                   order.OrderStatus == BamOrderStatus.PendingLocate ||
                   order.OrderStatus == BamOrderStatus.PendingCancel ||
                   order.OrderStatus == BamOrderStatus.PendingValidation ||
                   order.OrderStatus == BamOrderStatus.IncompleteLocate ||
                   order.OrderStatus == BamOrderStatus.Marked ||
                   order.OrderStatus == BamOrderStatus.Error ||
                   order.OrderStatus == BamOrderStatus.Cancelled ||
                   order.OrderStatus == BamOrderStatus.Deleted;
        }
        
        public IEnumerable<Order> Find(IPortfolio portfolio, ISecurity security)
        {
            if (portfolio != null && security != null)
            {
                return
                    GetAll()
                        .Where(order => order.Portfolio.IsMatch(portfolio) && order.Security.IsMatch(security));
            }
            else if (portfolio != null)
            {
                return
                    GetAll()
                        .Where(order => order.Portfolio.IsMatch(portfolio));
            }
            else if (security != null)
            {
                return
                    GetAll()
                        .Where(order => order.Security.IsMatch(security));
            }

            return null;
        }

        public IDictionary<IPositionKey, IList<IOrder>> GetAllOrders(Func<IOrder, bool> predicate = null)
        {
            predicate = predicate ?? (o => true);

            IDictionary<IPositionKey, IList<IOrder>> orders = new Dictionary<IPositionKey, IList<IOrder>>();
            foreach (IOrder order in GetAll())
            {
                if (predicate(order))
                {
                    IPositionKey positionKey = new PositionKey(order.Portfolio, order.Security);
                    IList<IOrder> ordersList;
                    if (orders.TryGetValue(positionKey, out ordersList))
                    {
                        ordersList.Add(order);
                    }
                    else
                    {
                        ordersList = new List<IOrder>() {order};
                        orders[positionKey] = ordersList;
                    }
                }
            }

            return orders;
        }
    }
}