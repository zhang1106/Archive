﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Bam.Oms.SodPosition.Svc.File
{
    public interface IFileLoading
    {
        /// <summary>
        /// Load the file specified by the filePath
        /// </summary>
        /// <param name="filePath">The file to be loaded</param>
        /// <returns></returns>
        bool Process(string filePath);

        /// <summary>
        /// Start watching for files
        /// </summary>
        void Start();

        event Action SodPositionLoaded;
    }
}
