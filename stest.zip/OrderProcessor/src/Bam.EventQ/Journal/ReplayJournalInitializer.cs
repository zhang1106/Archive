﻿using System;
using System.Linq;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Journal
{
    public class ReplayJournalInitializer<TItem> : IPipelineStepInitializer<TItem>
    {
        private readonly IJournal _journal;
        private readonly IJournalSeed[] _seeds;
        
        public ReplayJournalInitializer(IJournal journal, params IJournalSeed[] seeds)
        {
            _journal = journal;
            _seeds = seeds;
        }

        public ILogger Logger { get; set; }

        public void Execute(IQueue<PipelineQueueItem<TItem>> queue, CancellationToken cancellationToken)
        {
            Logger?.LogInformation("Replaying events from journal");

            int seeded = 0;
            foreach (var seed in _seeds)
            {
                if (!_journal.RetrieveMarkers().Contains(seed.Marker))
                {
                    foreach (var item in seed.Retrieve(cancellationToken))
                    {
                        seeded++;
                        _journal.Append(item, 0, item.Length);
                    }

                    if (cancellationToken.IsCancellationRequested)
                        return;

                    _journal.AppendMarker(seed.Marker);
                }
            }

            if (seeded > 0)
            {
                _journal.Flush();
                Logger?.LogInformation($"Seeded journal with {seeded} items");
            }

            int replayed = 0;
            foreach (var item in _journal.Retrieve())
            {
                PlayItem(queue, item);
                replayed++;

                if (cancellationToken.IsCancellationRequested)
                    break;
            }

            Logger?.LogInformation($"Replayed {replayed} events");
        }

        private static void PlayItem(IQueue<PipelineQueueItem<TItem>> queue, byte[] item)
        {
            var batch = queue.AllocateBatch(1);
            var q = queue[batch.Start];

            q.Clear();
            q.EnsureBufferSize(item.Length);
            Buffer.BlockCopy(item, 0, q.Buffer.Array, q.Buffer.Offset, item.Length);
            q.SetBufferLength(item.Length);
            q.MarkReplay();

            queue.PublishBatch(batch);
        }
    }
}
