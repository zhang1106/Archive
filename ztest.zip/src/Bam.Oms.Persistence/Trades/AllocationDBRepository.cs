﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using BAM.Infrastructure.Ioc;
using Dapper;

namespace Bam.Oms.Persistence.Trades
{
    public class AllocationDBRepository : DBRepository<IBlockTrade>, IAllocationDBRepository
    {
        private readonly ISettings _settings;

        protected override IDbConnection Connection => new SqlConnection(_settings.OrderGatewayConnectionString);

        public AllocationDBRepository(ISettings settings, ILogger log) : base(settings, log, "dbo", "Allocation")
        {
            _settings = settings;
        }

        public override int Clear(DateTime cutOffTimeUtc)
        {
            throw new NotImplementedException("Cannot delete Allocation records throw this reposiroity. Directly delete in the database.");
        }

        public override int ClearAll()
        {
            return this.Clear(_settings.SODDateTime);
        }

        public override IEnumerable<IBlockTrade> Get(DateTime cutoffTimeUtc)
        {
            //Database is local time. The implicit assumption is the database server and the application server are in the same local timezone.
            DateTime cutOffTimeLocal = cutoffTimeUtc.ToLocalTime();
            return base.Get("TradeTimeStamp >= @TradeTimeStamp", new { @TradeTimeStamp = cutOffTimeLocal }).ToList();
        }

        public override IBlockTrade Get(string key)
        {
            return base.Get(new { TradeId = key }).FirstOrDefault();
        }

        public override IBlockTrade Save(IBlockTrade item)
        {
            //TODO: Consider doing the same with table value parameters for performance and efficiency
            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();
                    using (IDbTransaction transaction = connection.BeginTransaction())
                    {
                        int recordCount = 0;
                        foreach (IAllocation allocation in item.Allocations)
                        {
                            recordCount += connection.Execute("dbo.usp_InsertAllocation", new
                            {
                                TradeId = allocation.AllocationId,
                                TradeDateId =
                                    Int32.Parse(item.TradeDate.ToString("yyyyMMdd",
                                        System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
                                Portfolio = item.Portfolio.ToString(),
                                SecurityType = item.Security.SecurityType.ToString("F"),
                                Symbol = item.Security.BamSymbol,
                                SymbolDesc = item.Security.ToString(),
                                TradedQuantity = allocation.Quantity,
                                AveragePrice = allocation.AveragePrice,
                                Side = item.Side.ToString("F"),
                                ClientOrderId = item.ClientOrderId,
                                Status = item.isFinalized ? "FINALIZED" : "OPEN",
                                Trader = item.Trader,
                                Fund = allocation.Fund,
                                PrimeBroker = allocation.PrimeBroker,
                                PrimeBrokerAccount = allocation.PrimeBrokerAccount,
                                CounterParty = allocation.CounterParty,
                                SettleDateId =
                                    Int32.Parse(allocation.SettleDate.ToString("yyyyMMdd",
                                        System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
                                TradeCurrency = item.TradeCurrency,
                                BaseCurrency = item.BaseCurrency,
                                FXRate = item.FxRate,
                                GrossAmount = item.GrossAmount,
                                NetAmount = item.NetAmount,
                                NetAmountBase = item.NetAmountBase,
                                Note = allocation.Note,
                                TradeTimeStamp = item.TradeTimeStamp,
                                ParentTradeId = allocation.ParentTradeId,
                                DataSource = item.DataSource
                            }, commandType: CommandType.StoredProcedure, transaction: transaction);

                            //Commissions & Fees                            
                            foreach (Fee fee in allocation.Fees.Union(allocation.Commissions))
                            {
                                connection.Execute("dbo.InsertAllocationFee", new
                                {
                                    TradeDateId =
                                    Int32.Parse(item.TradeDate.ToString("yyyyMMdd",
                                        System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
                                    DataSource = item.DataSource,
                                    TradeId = allocation.AllocationId,
                                    Name = fee.Name,
                                    RateType = Data.Utility.GetStringFromEnumAttribute<RateType>(fee.RateType),
                                    Currency = fee.Currency,
                                    Amount = fee.Rate
                                }, commandType: CommandType.StoredProcedure, transaction: transaction);
                            }
                        }
                        if (recordCount == item.Allocations.Count)
                        {
                            transaction.Commit();
                            return item;
                        }
                        transaction.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error saving allocation record.", ex);
                return null;
            }
            return null;
        }

        public override IEnumerable<IBlockTrade> Save(IEnumerable<IBlockTrade> items)
        {
            //TODO: Use TVP for performance and efficiency
            var blockTrades = items as IList<IBlockTrade> ?? items.ToList();
            if (!blockTrades.Any()) return blockTrades;
            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();
                    using (IDbTransaction transaction = connection.BeginTransaction())
                    {
                        var itemsToInsert = new List<DynamicParameters>();
                        foreach (var item in blockTrades)
                        {
                            foreach (IAllocation allocation in item.Allocations)
                            {
                                var param = new DynamicParameters();
                                param.Add("@tradeId", value: allocation.AllocationId, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@tradeDateId",
                                    value:
                                        Int32.Parse(item.TradeDate.ToString("yyyyMMdd",
                                            System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
                                    dbType: DbType.Int32,
                                    direction: ParameterDirection.Input);
                                param.Add("@portfolio", value: item.Portfolio.ToString(), dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@securityType", value: item.Security.SecurityType.ToString("F"),
                                    dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@symbol", value: item.Security.BamSymbol, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@symbolDesc", value: item.Security.ToString(), dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@tradedQuantity", value: allocation.Quantity, dbType: DbType.Decimal,
                                    direction: ParameterDirection.Input);
                                param.Add("@averageprice", value: allocation.AveragePrice, dbType: DbType.Decimal,
                                    direction: ParameterDirection.Input);
                                param.Add("@side", value: item.Side.ToString("F"), dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@clientOrderId", value: item.ClientOrderId, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@status", value: item.TradeStatus, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@trader", value: item.Trader, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@fund", value: allocation.Fund, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@primeBroker", value: allocation.PrimeBroker, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@primeBrokerAccount", value: allocation.PrimeBrokerAccount,
                                    dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@counterParty", value: allocation.CounterParty, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@settleDateId",
                                    value:
                                        Int32.Parse(allocation.SettleDate.ToString("yyyyMMdd",
                                            System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
                                    dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@tradeCurrency", value: item.TradeCurrency, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@baseCurrency", value: item.BaseCurrency, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@fxRate", value: item.FxRate, dbType: DbType.Decimal,
                                    direction: ParameterDirection.Input);
                                param.Add("@grossAmount", value: item.GrossAmount, dbType: DbType.Decimal,
                                    direction: ParameterDirection.Input);
                                param.Add("@netAmount", value: item.NetAmount, dbType: DbType.Decimal,
                                    direction: ParameterDirection.Input);
                                param.Add("@netAmountBase", value: item.NetAmountBase, dbType: DbType.Decimal,
                                    direction: ParameterDirection.Input);
                                param.Add("@note", value: allocation.Note, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@tradeTimeStamp",
                                    value:
                                        item.TradeTimeStamp == DateTime.MinValue ? DateTime.UtcNow : item.TradeTimeStamp,
                                    dbType: DbType.DateTime,
                                    direction: ParameterDirection.Input);
                                param.Add("@parentTradeId", value: allocation.ParentTradeId, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@dataSource",
                                    value:
                                        String.IsNullOrWhiteSpace(item.DataSource)
                                            ? GetDataSource(item.Security.SecurityType)
                                            : item.DataSource, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                itemsToInsert.Add(param);
                            }
                        }
                        int recordCount = connection.Execute("dbo.usp_InsertAllocation", itemsToInsert,
                            commandType: CommandType.StoredProcedure, transaction:transaction);
                        itemsToInsert.Clear();
                        if (recordCount >= blockTrades.Count())
                        {
                            foreach (var blockTrade in blockTrades)
                            {
                                foreach (IAllocation allocation in blockTrade.Allocations)
                                {
                                    foreach (IFee fee in allocation.Fees.Union(allocation.Commissions))
                                    {
                                        var param = new DynamicParameters();
                                        param.Add("@tradeDateId",
                                            value:
                                                Int32.Parse(blockTrade.TradeDate.ToString("yyyyMMdd",
                                                    System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
                                            dbType: DbType.Int32,
                                            direction: ParameterDirection.Input);
                                        param.Add("@tradeId", value: allocation.AllocationId, dbType: DbType.String,
                                            direction: ParameterDirection.Input);
                                        param.Add("@dataSource", value: String.IsNullOrWhiteSpace(blockTrade.DataSource) ? GetDataSource(blockTrade.Security.SecurityType) : blockTrade.DataSource, dbType: DbType.String, direction: ParameterDirection.Input);
                                        param.Add("@name", value: fee.Name, dbType: DbType.String,
                                            direction: ParameterDirection.Input);
                                        param.Add("@rateType", value: Data.Utility.GetStringFromEnumAttribute<RateType>(fee.RateType), dbType: DbType.String,
                                            direction: ParameterDirection.Input);
                                        param.Add("@currency", value: fee.Currency, dbType: DbType.String,
                                            direction: ParameterDirection.Input);
                                        param.Add("@amount", value: fee.Rate, dbType: DbType.Decimal,
                                            direction: ParameterDirection.Input);
                                        itemsToInsert.Add(param);
                                    }
                                }
                            }
                            connection.Execute("dbo.usp_InsertAllocationFee", itemsToInsert,
                            commandType: CommandType.StoredProcedure, transaction: transaction);
                            transaction.Commit();
                            return blockTrades;
                        }
                        transaction.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error saving allocation records.", ex);
                return new List<IBlockTrade>();
            }
            return new List<IBlockTrade>();
        }

        private string GetDataSource(SecurityType securityType)
        {
            switch (securityType)
            {
                case SecurityType.Equity:
                    return $"EQ_{_settings.EmsName}";
                case SecurityType.EquityOption:
                    return $"EQO_{_settings.EmsName}";
                case SecurityType.EquitySwap:
                    return $"EQS_{_settings.EmsName}";
                case SecurityType.Unknown:
                default:
                    return "UNKNOWN";
            }
        }
    }
}
