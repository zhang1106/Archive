﻿namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public interface IHeadroomEffectCalculator
    {
        HeadroomEffects Calculate(HeadroomInfo info);
    }
}
