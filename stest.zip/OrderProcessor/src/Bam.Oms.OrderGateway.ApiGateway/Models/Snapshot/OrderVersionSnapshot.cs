﻿using System.Collections.Generic;
using Bam.EventQ.Snapshot;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Snapshot
{
    public class OrderVersionSnapshot : ISnapshot
    {
        public Dictionary<string, int> LastVersion { get; } = new Dictionary<string, int>();
    }
}
