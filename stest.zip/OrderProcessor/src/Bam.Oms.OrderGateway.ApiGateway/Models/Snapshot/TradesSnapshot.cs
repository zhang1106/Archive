﻿using System.Collections.Generic;
using Bam.EventQ.Snapshot;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Snapshot
{
    public class TradesSnapshot : ISnapshot
    {
        public List<string> TradeIds { get; } = new List<string>();
    }
}
