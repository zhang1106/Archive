﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Bam.EventQ.Recovery;
using Bam.EventQ.Time;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Sequencing
{
    public class MessageSerializerHandler : IQueueItemHandler<PipelineQueueItem<IMessage>>
    {
        private readonly int _sourceId;
        private readonly IClock _clock;
        private readonly IMessageTopicProvider<IMessage> _topicProvider;
        private readonly byte[] _buffer;
        private readonly Dictionary<int, long> _sequences;

        public MessageSerializerHandler(
            int sourceId, int bufferSize, IClock clock,
            IMessageTopicProvider<IMessage> topicProvider)
        {
            _sourceId = sourceId;
            _clock = clock;
            _topicProvider = topicProvider;
            _buffer = new byte[bufferSize];
            _sequences = new Dictionary<int, long>();
        }

        public void Handle(PipelineQueueItem<IMessage> item, long sequence, bool endOfBatch)
        {
            if (!item.IsValid)
                return;

            var topic = _topicProvider.GetTopic(item.Payload);

            long seq;
            if (!_sequences.TryGetValue(topic, out seq))
                seq = _sequences[topic] = 0;
            else
                _sequences[topic] = ++seq;
            
            item.Payload.Header = new SequenceInfo(_sourceId, topic, seq, _clock.Timestamp);
            int count = MessageSerializer.Current.Serialize(item.Payload, _buffer, 0);
            item.SetTopic(topic);
            item.EnsureBufferSize(count);
            Buffer.BlockCopy(_buffer, 0, item.Buffer.Array, item.Buffer.Offset, count);
            item.SetBufferLength(count);
        }
    }
}
