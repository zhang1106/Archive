﻿using Bam.Compliance.Infrastructure.Configuration;

namespace Bam.Oms.Compliance.Service
{
    public class ComplianceServiceSettings : SettingsBase
    {
        public int BbBatchSize
        {
             get { return GetValue(() => BbBatchSize); }
        }

        public bool UseBloombBergData
        {
            get { return GetValue(() => UseBloombBergData); }
        }

        public bool WarningOnly
        {
            get { return GetValue(() => WarningOnly); }
        }

        public bool EnableSqlMonitoring
        {
            get { return GetValue(() => EnableSqlMonitoring); }
        }

        public string BamCoreLite
        {
            get { return GetValue(() => BamCoreLite); }

        }

        public string OrderGateway
        {
            get { return GetValue(() => OrderGateway); }
        }

        public string OrderGatewayMain
        {
            get { return GetValue(() => OrderGatewayMain); }
        }

        public string MqConnectionString
        {
            get { return GetValue(() => MqConnectionString); }
        }
    }
}
