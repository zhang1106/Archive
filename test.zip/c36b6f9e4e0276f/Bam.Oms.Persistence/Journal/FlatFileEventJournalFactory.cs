﻿using Bam.Oms.Data;
using Bam.Oms.Persistence.Serialization;

namespace Bam.Oms.Persistence.Journal
{
    public class FlatFileEventJournalFactory : IEventJournalFactory
    {
        private readonly ISerializer _serializer;

        public FlatFileEventJournalFactory(ISerializer serializer)
        {
            _serializer = serializer;
        }

        public IEventJournal Create(string name)
        {
            return new FlatFileEventJournal(name + ".dat", _serializer);
        }
    }
}
