﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;

namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public interface IDbHeadroomLookup
    {
        List<HeadRoomDto> GetHeadroom(out DateTime businessDay);
        List<HeadroomRatioDto> GetHeadroomRatios(DateTime businessDay);
    }
}