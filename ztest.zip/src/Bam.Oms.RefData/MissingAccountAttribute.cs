﻿using System;
using Bam.Oms.Data.Portfolios;

namespace Bam.Oms.RefData
{
    public class MissingAccountAttribute : Exception
    {
        private readonly IPortfolio _portfolio; //stored if you want to inspect while debugging
        private readonly string _attribute;

        public MissingAccountAttribute(IPortfolio portfolio, string attribute) : base($"No attribute {attribute} for portfolio {portfolio}")
        {
            _portfolio = portfolio;
            _attribute = attribute;
        }
    }
}