﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;
using Bam.Oms.OrderGateway.EzeGateway.Models;

namespace Bam.Oms.OrderGateway.EzeGateway.Services
{
    public class EzePooledWorker : IEzePooledWorker
    {
        private static int _instanceCount;
        private static int _busyWorkers;
        private readonly IEzeSubmissionService _requestService;
        private readonly IFastLaneQueue<SubmissionQueueItem> _workItems;
        private readonly int _maxBatchSize;
        private readonly bool _isFastLane;
        private readonly IBackgroundWorker _worker;
        
        public EzePooledWorker(
            IEzeSubmissionService requestService,
            IFastLaneQueue<SubmissionQueueItem> workItems, 
             int maxBatchSize,
            bool isFastLane)
        {
            _requestService = requestService;
            _workItems = workItems;
            _maxBatchSize = maxBatchSize;
            _isFastLane = isFastLane;

            int id = Interlocked.Increment(ref _instanceCount);
            _worker = BackgroundWorkerFactory.Current.Create($"EZE #{id}");
        }

        public ILogger Logger { get; set; }
        public Action<TradeCreateResponse> Handler { get; set; }

        public void Start(Action<TradeCreateResponse> handler)
        {
            Handler = handler;
            _worker.Start(Process);
        }

        public void Dispose()
        {
            _worker.Dispose();
        }
        
        private void Process(CancellationToken cancellationToken)
        {
            var batch = new List<SubmissionQueueItem>(_maxBatchSize);
            var waitHandles = new[] { cancellationToken.WaitHandle, _workItems.ItemsAvailable };

            while ((_workItems.Count != 0 && !cancellationToken.IsCancellationRequested) ||
                   WaitHandle.WaitAny(waitHandles) != 0)
            {
                batch.Clear();

                SubmissionQueueItem item;
                while (batch.Count < _maxBatchSize &&
                       _workItems.TryDequeue(_isFastLane, out item))
                {
                    batch.Add(item);
                }

                if (batch.Count == 0)
                {
                    cancellationToken.WaitHandle.WaitOne(100);
                    continue;
                }

                var sw = Stopwatch.StartNew();
                int busy = Interlocked.Increment(ref _busyWorkers);
                Logger?.LogInformation($"[EZESTAT] Sending {batch.Count} trades to EZE, {busy} busy worker threads, " + 
                    $"{_workItems.InFlight} trades in-flight, {_workItems.Count} trades remaining in queue.");
                
                try
                {
                    var response = _requestService.Submit(cancellationToken, batch);

                    if (response != null)
                    {
                        Handler(response);
                    }
                }
                finally
                {
                    _workItems.Ack(batch);

                    sw.Stop();
                    busy = Interlocked.Decrement(ref _busyWorkers);
                    Logger?.LogInformation($"[EZESTAT] Completed sending {batch.Count} trades to EZE in {sw.Elapsed}, " + 
                        $"{busy} busy worker threads remaining, {_workItems.InFlight} trades in-flight, " + 
                        $"{_workItems.Count} trades remaining in queue.");
                }
            }
        }
    }
}
