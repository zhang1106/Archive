﻿using System;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;

namespace Bam.EventQ.Queue
{
    public abstract class ThreadedQueueItemProducerBase<TItem> : QueueItemProducerBase<TItem>, IDisposable
    {
        private readonly IBackgroundWorker _producerWorker;
        private readonly ManualResetEventSlim _pausedEvent = new ManualResetEventSlim();
        private readonly Func<bool> _stopSpinningDelegate;
        private long _isPaused;
        
        protected ThreadedQueueItemProducerBase(string threadName)
        {
            _producerWorker = BackgroundWorkerFactory.Current.Create($"[{AppDomain.CurrentDomain.FriendlyName}] {threadName}");
            _stopSpinningDelegate = StopSpinning;
        }

        public override bool CanPause => true;

        public override void Start()
        {
            Logger?.LogInformation($"Starting queue item producer '{ProducerName}'");
            _producerWorker.Start(Produce);
        }

        public override void Stop()
        {
            Logger?.LogInformation($"Stopping queue item producer '{ProducerName}'");
            Volatile.Write(ref _isPaused, 0);
            _producerWorker.Stop();
            Logger?.LogInformation($"Stopped queue item producer '{ProducerName}'");
        }

        public override void Pause()
        {
            if (Interlocked.Exchange(ref _isPaused, 1) == 1)
            {
                throw new InvalidOperationException("Cannot pause producer because it is already paused");
            }

            _pausedEvent.Reset();            
            if (_producerWorker.IsActive)
            {
                _pausedEvent.Wait();
            }
        }

        public override void Resume()
        {
            if (Interlocked.Exchange(ref _isPaused, 0) == 0)
            {
                throw new InvalidOperationException("Cannot resume producer because it is already resumed");
            }
        }

        public void Dispose()
        {
            Stop();
        }

        protected abstract void Produce(CancellationToken cancellationToken);
        
        protected void SpinWhilePaused()
        {
            SpinWait.SpinUntil(_stopSpinningDelegate);
        }

        internal bool StopSpinning()
        {
            if (Volatile.Read(ref _isPaused) == 1)
            {
                _pausedEvent.Set();
                return false;
            }

            return true;
        }

        protected string ProducerName => GetType().GetDisplayName();
    }
}
