using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Securities;
using CsvHelper.Configuration;

namespace Bam.Oms.EndPoints.File
{
    public sealed class OrderMapping : CsvClassMap<Order>
    {
        //Security,Side,Amount,TAlpha2(strategy),Manager,Cust
        public OrderMapping()
        {
            Map(m => m.Portfolio).Name("TAlpha2").TypeConverter<PortfolioConverter>();
            Map(m => m.Security).ConvertUsing<ISecurity>(row => new Security {BamSymbol = row.GetField("Security")});
            Map(m => m.Size).Name("Amount");
            Map(m => m.Custodian).Name("Cust"); //not sure if we're ever going to use this
            Map(m => m.Side).ConvertUsing(row =>
            {
                var side = row.GetField("Side").ToString();
                side = side.ToLower() == "short" ? "SellShort" : side == "cover" ? "Cover" : side;

                return Utility.ConvertEnum<SideType>(side);
            });            
        }
    }
}