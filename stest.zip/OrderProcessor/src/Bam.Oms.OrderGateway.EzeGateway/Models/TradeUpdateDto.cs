﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public class TradeUpdateDto
    {
        public List<Trade> Trades { get; set; } = new List<Trade>();

        public string GetRoutingKey()
        {
            return nameof(TradeUpdateDto);
        }
    }
}
