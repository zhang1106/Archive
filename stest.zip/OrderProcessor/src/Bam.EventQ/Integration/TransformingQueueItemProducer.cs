﻿using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Integration
{
    public class TransformingQueueItemProducer<TIn, TOut> : QueueItemProducerBase<PipelineQueueItem<TOut>>
    {
        private readonly IExternalMessageSource<TIn> _source;
        private readonly IExternalMessageTransform<TIn, TOut> _transform;
        private volatile bool _started;

        public TransformingQueueItemProducer(
            IExternalMessageSource<TIn> source,
            IExternalMessageTransform<TIn, TOut> transform)
        {
            _source = source;
            _transform = transform;
            source.Initialize(Handle);
        }

        public override void Start()
        {
            base.Start();
            _source.Start();
        }

        public override void Stop()
        {
            _source.Stop();
            base.Stop();
        }

        private void Handle(TIn input)
        {
            if (!_started)
            {
                Started.WaitOne();
                _started = true;
            }

            if (!Stopped)
            {
                foreach (var msg in _transform.Transform(input))
                {
                    Handle(msg);
                }
            }
        }

        protected virtual void Handle(TOut transformed)
        {
            Queue.PublishPayload(transformed);
        }
    }
}
