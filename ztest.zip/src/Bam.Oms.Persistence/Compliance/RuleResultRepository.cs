﻿using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Persistence.Compliance
{
    public class RuleResultRepository : PersistentRepository<RuleResult>, IRuleResultRepository
    {
        public RuleResultRepository(ILogger log) : base("ComplianceResultCache", log)
        {
        }
    }
}
