﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Bam.Oms.SodPosition.Svc;
using Moq;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.Infrastructure;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Enumerators;
using DBModel = Bam.Oms.DBModel;

namespace Bam.Oms.SodPosition.Test
{

    [TestClass]
    public class SvcTest
    {
        DateTime now = DateTime.Now;
        DateTime yesterday = DateTime.Now.AddDays(-1);

        [TestMethod]
        public void TestGetSodPositions()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianAccountCode="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long},

                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=now.Date, CustodianAccountCode="BARCLAYS", FXRate=104.75M, ActualQuantity=201.54M, ActualSide=SideType.Short, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=35, AuditSequence=5, LastModifiedOn=now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 201.54M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, null, null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        
        

        [TestMethod]
        public void TestGetSodPositionsWithEntryDateFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=now.Date, CustodianAccountCode="BARCLAYS", FXRate=104.75M, ActualQuantity=201.54M, ActualSide=SideType.Short, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=35, AuditSequence=5, LastModifiedOn=now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 201.54M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, now.Date, null, null, null, null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }

        }

        
        [TestMethod]
        public void TestGetSodPositionsWithStreamFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianAccountCode="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long},
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, "AS", null, null, null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }


        
        [TestMethod]
        public void TestGetSodPositionsWithBamSymbolFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianAccountCode="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long},
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, null, null, null, "MSFT");
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [TestMethod]
        public void TestGetSodPositionsWithFundCodeFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=now.Date, CustodianAccountCode="BARCLAYS", FXRate=104.75M, ActualQuantity=201.54M, ActualSide=SideType.Short, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=35, AuditSequence=5, LastModifiedOn=now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 201.54M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, "Fund2", null, null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [TestMethod]
        public void TestGetSodPositionsWithCustodianAccountFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianAccountCode="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, "GOLDMAN", null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [TestMethod]
        public void TestGetSodPositionsWithAssetTypeFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=now.Date, CustodianAccountCode="BARCLAYS", FXRate=104.75M, ActualQuantity=201.54M, ActualSide=SideType.Short, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=35, AuditSequence=5, LastModifiedOn=now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 201.54M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, null, null, "EquityOption", null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [TestMethod]
        public void TestGetSodPositionsWithStrategyCodeFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianAccountCode="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, null, "Obi-Wan-Kenobi", null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        
        [TestMethod]
        public void TestGetSodPositionsWithFilters()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianAccountCode="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, yesterday.Date, "AS", "Fund1", "GOLDMAN", "Obi-Wan-Kenobi", "Equity", "MSFT");
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        
        [TestMethod]
        public void TestGetPositionsWithFilters()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianAccountCode="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianAccountCode = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianAccountCode = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var pos1 = posEdit.GetPositions(null, yesterday.Date, "AS", "Fund1", "GOLDMAN", "Obi-Wan-Kenobi", "Equity", "MSFT");
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p1 in pos1)
            {
                var p = p1 as Position;
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [TestMethod]
        public void TestGetLatestUpdatedPositions()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);

            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 4, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 5, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = now.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "AS", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                 new Position {PositionId = 6, Security = new Security {BamSymbol = "GOOG", Currency = "USD", SecurityType = SecurityType.EquityOption }, Price = 2.5M, EntryDate = now.Date, CustodianAccountCode = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},
            };
            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {

                new DBModel.Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=-200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquityOption", LastModifiedOn=now, LastModifiedBy="kishore"},

            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };

            List<DBModel.ActionLog> actionLogRepository = new List<DBModel.ActionLog>()
            {
                new DBModel.ActionLog {ActionLogId = 1, ActionId = 2, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 2, ActionId = 3, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 3, ActionId = 4, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 4, ActionId = 5, CreatedOn = yesterday },
            };

            var mockPositionSet = GetMockDbSet(positionRepository);
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockActionLogSet = GetMockDbSet(actionLogRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            ISodPositionEdit posEdit = new SodPositionEdit(() => mockContext.Object);
            var updatedPositions = posEdit.GetLatestUpdatedPositions(null, "US");
            // All positions except the ones with Audit sequence = 0 should be returned
            // as there are no previous action logs of type: PUBLISH_UPDATED_POSITIONS
            var expected = expectedPositions.Where(x => x.AuditSequence > 0).ToList();
            Assert.IsTrue(expected.Count > 0);
            Assert.IsTrue(expected.Count == updatedPositions.Count());
            foreach (var p in updatedPositions)
            {
                Assert.IsTrue(IsSamePosition(p, expected.Find(x => x.PositionId == p.PositionId)));
            }


            // Add an action log corresponding to PUBLISH_UPDATED_POSITIONS action
            actionLogRepository.Add(new DBModel.ActionLog { ActionLogId = 5, ActionId = 1, CreatedOn = now.AddHours(-1) });
            mockPositionSet = GetMockDbSet(positionRepository);
            mockActionSet = GetMockDbSet(actionRepository);
            mockActionLogSet = GetMockDbSet(actionLogRepository);
            mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            posEdit = new SodPositionEdit(() => mockContext.Object);
            updatedPositions = posEdit.GetLatestUpdatedPositions(null, "US");
            // All positions except the ones with Audit sequence = 0 should be returned
            // as there are no previous action logs of type: PUBLISH_UPDATED_POSITIONS
            expected = expectedPositions.Where(x => x.LastModifiedOn > now.AddHours(-1) && x.AuditSequence > 0).ToList();
            Assert.IsTrue(expected.Count > 0);
            Assert.IsTrue(expected.Count == updatedPositions.Count());
            foreach (var p in updatedPositions)
            {
                Assert.IsTrue(IsSamePosition(p, expected.Find(x => x.PositionId == p.PositionId)));
            }
        }

        [TestMethod]
        public void TestGetAudits()
        {
            List<PositionAudit> expectedPositions = new List<PositionAudit>()
            {
                new PositionAudit {PositionAuditId = 1, Position =
                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, LastModifiedOn=yesterday, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long}
                },

                new PositionAudit {PositionAuditId = 2, Position =
                new Position {PositionId = 1, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long}
                },

                new PositionAudit {PositionAuditId = 3, Position =
                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short}
                },

                new PositionAudit {PositionAuditId = 4, Position =
                new Position {PositionId = 1, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Short}
                },

                new PositionAudit {PositionAuditId = 5, Position =
                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = now.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "AS", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long}
                },

                new PositionAudit {PositionAuditId = 6, Position =
                 new Position {PositionId = 1, Security = new Security {BamSymbol = "GOOG", Currency = "USD", SecurityType = SecurityType.EquityOption }, Price = 2.5M, EntryDate = now.Date, CustodianAccountCode = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long}
                },
            };

            var positionAuditRepository = new List<DBModel.PositionAudit>()
            {
               new DBModel.PositionAudit { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore", PositionAuditId = 1},

                new DBModel.PositionAudit { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore", PositionAuditId = 2},

                new DBModel.PositionAudit { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore", PositionAuditId = 3},
                new DBModel.PositionAudit { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=-200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore", PositionAuditId = 4},
                new DBModel.PositionAudit { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore", PositionAuditId = 5},

                new DBModel.PositionAudit { PositionId= 1, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquityOption", LastModifiedOn=now, LastModifiedBy="kishore", PositionAuditId = 6},
            };

            var mockPositionAuditSet = GetMockDbSet(positionAuditRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.PositionAudits).Returns(mockPositionAuditSet.Object);
            var posEdit = new SodPositionEdit(() => mockContext.Object);
            var auditInfo = posEdit.GetAudits(null, 1, yesterday.Date);
            var expected = auditInfo.Where(x => x.Position.PositionId == 1 && x.Position.EntryDate == yesterday.Date).ToList();
            Assert.IsTrue(expected.Count() > 0);
            Assert.IsTrue(expected.Count == auditInfo.Count());
            foreach (var audit in auditInfo)
            {
                Assert.IsTrue(IsSameAuditInfo(audit, expected.Find(x => x.PositionAuditId == audit.PositionAuditId)));
            }
        }

        [TestMethod]
        public void TestGetCorporateActions()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<SodAction> sodActions = new List<SodAction>()
            {
                new SodAction {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday }
            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            var posEdit = new SodPositionEdit(() => mockContext.Object);
            var corpActions = posEdit.GetBulkActions(null);
            var expected = actionRepository.Where(x => x.Type == "corp").ToList();
            Assert.IsTrue(expected.Count > 0);
            Assert.IsTrue(expected.Count == corpActions.Count());
            foreach (var cAct in corpActions)
            {
                Assert.IsTrue(IsSameAction(cAct, sodActions.Find(x => x.ActionId == cAct.ActionId)));
            }
        }

        
        [TestMethod]
        public void TestInsertPosition()
        {
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 4, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 5, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = now.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "AS", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {

                new DBModel.Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=-200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
            List<DBModel.ActionLog> actionLogRepository = new List<DBModel.ActionLog>()
            {
                new DBModel.ActionLog {ActionLogId = 1, ActionId = 2, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 2, ActionId = 3, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 3, ActionId = 4, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 4, ActionId = 5, CreatedOn = yesterday },
            };
            var mockPositionSet = GetMockDbSet(positionRepository);
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockActionLogSet = GetMockDbSet(actionLogRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            mockContext.Setup(x => x.Positions.Add(It.IsAny<DBModel.Position>())).Callback<DBModel.Position>((pos1) =>
            {
                pos1.PositionId = 1000;
                positionRepository.Add(pos1);
            });
            mockContext.Setup(x => x.ActionLogs.Add(It.IsAny<DBModel.ActionLog>())).Callback<DBModel.ActionLog>((actLog) =>
            {
                actLog.ActionLogId = 1000;
                actionLogRepository.Add(actLog);
            });
            
            var posEdit = new SodPositionEdit(() => mockContext.Object);
            var insertPosition = new Position
            {
                Security = new Security { BamSymbol = "GOOG", Currency = "USD", SecurityType = SecurityType.EquityOption },
                Price = 2.5M,
                EntryDate = now.Date,
                CustodianAccountCode = "Deutsche Bank",
                FXRate = 1M,
                ActualQuantity = -200000M,
                ActualSide = SideType.Long,
                Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"),
                Stream = "US",
                FundCode = "Fund1",
                LastModifiedBy = "kishore",
                TheoreticalQuantity = -200000M,
                TheoreticalSide = SideType.Long
            };
            var returnedPosition = posEdit.InsertPosition(null, insertPosition);
            Assert.IsTrue(returnedPosition != null);
            Assert.IsTrue(returnedPosition.PositionId == 1000);
            Assert.IsTrue(returnedPosition.ActionLogId == 1000);
            // Assuming it takes less than a minute to execute this test case
            Assert.IsTrue(returnedPosition.EntryDate == now.Date);
            Assert.IsTrue(returnedPosition.AuditSequence == 1);
            Assert.IsTrue(returnedPosition.CreatedOn > DateTime.Now.AddMinutes(-1)
                && returnedPosition.CreatedOn < DateTime.Now);
            Assert.IsTrue(returnedPosition.LastModifiedOn > DateTime.Now.AddMinutes(-1)
                && returnedPosition.LastModifiedOn < DateTime.Now);
            Assert.IsTrue(returnedPosition.Security.BamSymbol == "GOOG");
            Assert.IsTrue(returnedPosition.Security.Currency == "USD");
            Assert.IsTrue(returnedPosition.CustodianAccountCode == "Deutsche Bank");
            Assert.IsTrue(returnedPosition.FXRate == 1M);
            Assert.IsTrue(returnedPosition.FundCode == "Fund1");
            Assert.IsTrue(returnedPosition.Security.SecurityType == SecurityType.EquityOption);
            Assert.IsTrue(returnedPosition.Price == 2.5M);
            Assert.IsTrue(returnedPosition.Portfolio.Equals(Portfolio.Parse("Darth-Vader")));
            Assert.IsTrue(returnedPosition.LastModifiedBy == "kishore");
            Assert.IsTrue(returnedPosition.TheoreticalQuantity == 200000M);
            Assert.IsTrue(returnedPosition.Stream == "US");
            Assert.IsTrue(returnedPosition.ActualQuantity == 200000M);
            Assert.IsTrue(returnedPosition.ActualSide == SideType.Short);
            Assert.IsTrue(returnedPosition.TheoreticalSide == SideType.Short);

            var actionLog = actionLogRepository.Find(x => x.ActionLogId == 1000);
            Assert.IsTrue(actionLog.ActionId == 2);
        }

        [TestMethod]
        public void TestBulkInsertPosition()
        {
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianAccountCode = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {

                new DBModel.Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
            List<DBModel.ActionLog> actionLogRepository = new List<DBModel.ActionLog>()
            {
                new DBModel.ActionLog {ActionLogId = 1, ActionId = 2, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 2, ActionId = 3, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 3, ActionId = 4, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 4, ActionId = 5, CreatedOn = yesterday },
            };
            var mockPositionSet = GetMockDbSet(positionRepository);
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockActionLogSet = GetMockDbSet(actionLogRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            int positionIdCounter = 1000;
            int actionLogIdCounter = 1000;
            mockContext.Setup(x => x.Positions.AddRange(It.IsAny<IEnumerable<DBModel.Position>>())).Callback<IEnumerable<DBModel.Position>>((positions) =>
            {
                foreach (var pos1 in positions)
                {
                    pos1.PositionId = positionIdCounter++;
                }
                positionRepository.AddRange(positions);
            });
            mockContext.Setup(x => x.ActionLogs.Add(It.IsAny<DBModel.ActionLog>())).Callback<DBModel.ActionLog>((actLog) =>
            {
                actLog.ActionLogId = actionLogIdCounter++;
                actionLogRepository.Add(actLog);
            });

            var posEdit = new SodPositionEdit(() => mockContext.Object);
            var insertPosition1 = new Position
            {
                PositionId = 4,
                Security = new Security { BamSymbol = "IBM", Currency = "USD", SecurityType = SecurityType.EquitySwap },
                Price = 2.5M,
                EntryDate = yesterday.Date,
                CustodianAccountCode = "Deutsche Bank",
                FXRate = 1M,
                ActualQuantity = 200000M,
                ActualSide = SideType.Short,
                Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"),
                Stream = "US",
                FundCode = "Fund2",
                CreatedOn = now,
                ActionLogId = 1,
                AuditSequence = 1,
                LastModifiedOn = yesterday,
                LastModifiedBy = "kishore",
                TheoreticalQuantity = 200000M,
                TheoreticalSide = SideType.Short
            };

            var insertPosition2 = new Position
            {
                PositionId = 5,
                Security = new Security { BamSymbol = "GOOG", Currency = "GBP", SecurityType = SecurityType.Equity },
                Price = 4.5M,
                EntryDate = now.Date,
                CustodianAccountCode = "Goldman",
                FXRate = 1.15M,
                ActualQuantity = 2000M,
                ActualSide = SideType.Long,
                Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"),
                Stream = "AS",
                FundCode = "Fund1",
                CreatedOn = now,
                ActionLogId = 1,
                AuditSequence = 0,
                LastModifiedOn = now,
                LastModifiedBy = "kishore",
                TheoreticalQuantity = 2000M,
                TheoreticalSide = SideType.Long
            };
            var returnedPositions = posEdit.BulkInsertPosition(null, new List<Position> { insertPosition1, insertPosition2 });
            Assert.IsTrue(returnedPositions.Count == 2);
            var returnedPosition1 = returnedPositions.Where(x => x.Security.BamSymbol == "IBM").First();
            var returnedPosition2 = returnedPositions.Where(x => x.Security.BamSymbol == "GOOG").First();
            Assert.IsTrue(returnedPosition1.PositionId == 1000 || returnedPosition2.PositionId == 1000);
            Assert.IsTrue(returnedPosition1.PositionId == 1001 || returnedPosition2.PositionId == 1001);
            Assert.IsTrue(returnedPosition1.ActionLogId == 1000 && returnedPosition2.ActionLogId == 1000);

            // Assuming it takes less than a minute to execute this test case
            Assert.IsTrue(returnedPosition1.EntryDate == now.Date);
            Assert.IsTrue(returnedPosition1.AuditSequence == 1);
            Assert.IsTrue(returnedPosition1.CreatedOn > DateTime.Now.AddMinutes(-1)
                && returnedPosition1.CreatedOn < DateTime.Now);
            Assert.IsTrue(returnedPosition1.LastModifiedOn > DateTime.Now.AddMinutes(-1)
                && returnedPosition1.LastModifiedOn < DateTime.Now);
            Assert.IsTrue(returnedPosition1.Security.BamSymbol == "IBM");
            Assert.IsTrue(returnedPosition1.Security.Currency == "USD");
            Assert.IsTrue(returnedPosition1.CustodianAccountCode == "Deutsche Bank");
            Assert.IsTrue(returnedPosition1.FXRate == 1M);
            Assert.IsTrue(returnedPosition1.FundCode == "Fund2");
            Assert.IsTrue(returnedPosition1.Security.SecurityType == SecurityType.EquitySwap);
            Assert.IsTrue(returnedPosition1.Price == 2.5M);
            Assert.IsTrue(returnedPosition1.Portfolio.Equals(Portfolio.Parse("Obi-Wan-Kenobi")));
            Assert.IsTrue(returnedPosition1.LastModifiedBy == "kishore");
            Assert.IsTrue(returnedPosition1.ActualQuantity == 200000M);
            Assert.IsTrue(returnedPosition1.TheoreticalQuantity == 200000M);
            Assert.IsTrue(returnedPosition1.TheoreticalSide == SideType.Short);
            Assert.IsTrue(returnedPosition1.ActualSide == SideType.Short);
            Assert.IsTrue(returnedPosition1.Stream == "US");

            Assert.IsTrue(returnedPosition2.EntryDate == now.Date);
            Assert.IsTrue(returnedPosition2.AuditSequence == 1);
            Assert.IsTrue(returnedPosition2.CreatedOn > DateTime.Now.AddMinutes(-1)
                && returnedPosition2.CreatedOn < DateTime.Now);
            Assert.IsTrue(returnedPosition2.LastModifiedOn > DateTime.Now.AddMinutes(-1)
                && returnedPosition2.LastModifiedOn < DateTime.Now);
            Assert.IsTrue(returnedPosition2.Security.BamSymbol == "GOOG");
            Assert.IsTrue(returnedPosition2.Security.Currency == "GBP");
            Assert.IsTrue(returnedPosition2.CustodianAccountCode == "Goldman");
            Assert.IsTrue(returnedPosition2.FXRate == 1.15M);
            Assert.IsTrue(returnedPosition2.FundCode == "Fund1");
            Assert.IsTrue(returnedPosition2.Security.SecurityType == SecurityType.Equity);
            Assert.IsTrue(returnedPosition2.Price == 4.5M);
            Assert.IsTrue(returnedPosition2.Portfolio .Equals(Portfolio.Parse("Darth-Vader")));
            Assert.IsTrue(returnedPosition2.LastModifiedBy == "kishore");
            Assert.IsTrue(returnedPosition2.ActualQuantity == 2000M);
            Assert.IsTrue(returnedPosition2.TheoreticalQuantity == 2000M);
            Assert.IsTrue(returnedPosition2.TheoreticalSide == SideType.Long);
            Assert.IsTrue(returnedPosition2.ActualSide == SideType.Long);
            Assert.IsTrue(returnedPosition2.Stream == "AS");
        }
        
        /*
        [TestMethod]
        public void TestSvcClient()
        {
            SvcClient client = new SvcClient();
            string errorMsg;
            var s = client.GetSodPositions(null, null, null, null, null, null, null, null, out errorMsg);

        }

    */
        ////[TestMethod]
        //public void TestPositionInsert()
        //{

        //    SodPositionEdit s = new SodPositionEdit();
        //    var position = s.InsertPosition("kishore", new Data.SodPosition()
        //    {
        //        FundCode = "PQRSUVT",
        //        CustodianAccountCode = "C",
        //        StrategyCode = "s",
        //        AssetType = "IOKNsadfdD",
        //        BAMSymbol = "BALY",
        //        Qty = 1.5M,
        //        Ccy = "USD",
        //        AuditSequence = 0,
        //        FXRate = 0.1M,
        //        Price = 2.3M,
        //        ActionLogId = 1,
        //        CreatedOn = DateTime.Now,
        //        EntryDate = DateTime.Now.Date,
        //        LastModifiedBy = "kishore",
        //        LastModifiedOn = DateTime.Now,
        //        Steam = null
        //    });
        //    Assert.IsTrue(position.PostionId > 0);

        //}

        ////[TestMethod]
        //public void TestPositionUpdate()
        //{


        //    SodPositionEdit s = new SodPositionEdit();
        //    s.UpdatePosition("kishore", new Data.SodPosition()
        //    {
        //        PostionId = 23204,
        //        FundCode = "ABCZ",
        //        CustodianAccountCode = "CLT20",
        //        StrategyCode = "s",
        //        AssetType = "IZPQL",
        //        BAMSymbol = "B",
        //        Qty = 1.5M,
        //        Ccy = "CNY",
        //        AuditSequence = 0,
        //        FXRate = 0.1M,
        //        Price = 5.3M,
        //        ActionLogId = 1,
        //        CreatedOn = DateTime.Now,
        //        EntryDate = DateTime.Now.Date,
        //        LastModifiedBy = "kishore",
        //        LastModifiedOn = DateTime.Now,
        //        Steam = null
        //    });
        //}
        ////[TestMethod]
        //public void TestGetPositions()
        //{
        //    SodPositionEdit s = new SodPositionEdit();
        //    var positions = s.GetSodPositions(userId: "CORP\\kishore", asofdate: null, stream: null, fundCode: null, custodianAccountCode: null,
        //        strategyCode: null, securityType: null, bamSymbol: null);
        //    Assert.IsNotNull(positions);
        //    Assert.IsTrue(positions.Count > 0);
        //}

        ////[TestMethod]
        //public void TestWriteToCsv()
        //{
        //    SodPositionEdit s = new SodPositionEdit();
        //    var isPublished = s.SaveToCSVFile(null, @"C:\Users\kishore\positions.csv", s.GetLastestUpdatedPositions(null));
        //    Assert.IsTrue(isPublished);
        //}
        /*

        //[TestMethod]
        public void TestGetSodPositions()
        {
            SodPositionEdit s = new SodPositionEdit();
            var positions = s.GetSodPositions(userId: "CORP\\kishore", asofdate: null, stream: null, fundCode: null, custodianAccountCode: null,
                strategyCode: null, securityType: null, bamSymbol: null);
            Assert.IsNotNull(positions);
            Assert.IsTrue(positions.Count > 0);
        }

        //[TestMethod]
        public void TestGetPositions()
        {
            SodPositionEdit s = new SodPositionEdit();
            var positions = s.GetPositions(userId: "CORP\\kishore", asofdate: null, stream: null, fundCode: null, custodianAccountCode: null,
                strategyCode: null, securityType: null, bamSymbol: null);
            Assert.IsNotNull(positions);
            Assert.IsTrue(positions.Count > 0);
        }

        //[TestMethod]
        public void TestGetUpdatedPositions()
        {
            SodPositionEdit s = new SodPositionEdit();
            var positions = s.GetLatestUpdatedPositions(null);
            Assert.IsNotNull(positions);
        }

        //[TestMethod]
        public void TestGetPositionAudits()
        {
            SodPositionEdit s = new SodPositionEdit();
            var audits = s.GetAudits(null, 10369, new DateTime(2015, 11, 2));
            Assert.IsNotNull(audits);
            Assert.IsTrue(audits.Count > 0);
        }
        */
        /*
        private DateTime now;
        private DateTime yesterday;
        private List<Data.Action> actionRepository;
        public SvcTest()
        {
            now = DateTime.Now;
            yesterday = now.AddDays(-1);
            actionRepository = new List<Data.Action>()
            {
                new Data.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Action {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Action {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
        }

        [TestMethod]
        public void TestGetLatestUpdatedPositions()
        {
            List<Data.SodPosition> positionRepository = new List<Data.SodPosition>()
            {
                new Data.SodPosition { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Straddle", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="OPTION", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="LOSH", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EQUITY", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Straddle", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="OPTION", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="USEQ", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EQUITY", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="JPEQ", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EQUITY", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="JPEQ", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EQUITY", LastModifiedOn=now, LastModifiedBy="kishore"},
            };
            var mockDAO = new Mock<Data.ISodPositionEdit>();
            mockDAO.Setup(c => c.GetAction(It.IsAny<string>(), It.IsAny<string>())).Returns<string, string>((name, type) => actionRepository.Find(x => x.Name == name && x.Type == type));
            mockDAO.Setup(c => c.GetLatestActionLog(1)).Returns(new Data.ActionLog { ActionId = 1, ActionLogId = 1, CreatedOn = now.AddMinutes(-60) });
            mockDAO.Setup(c => c.GetSodPositions(null, null, null, null, null, null, null, It.IsAny<DateTime?>(), It.IsAny<DateTime?>())).Returns(positionRepository);
            ISodPositionEdit sEdit = new SodPositionEdit(mockDAO.Object);
            var returnedPositions = sEdit.GetLatestUpdatedPositions(null);
            var expectedPositions = positionRepository.Where(x => x.AuditSequence > 0).ToList();
            Assert.IsTrue(expectedPositions.Count > 0);
            Assert.IsTrue(returnedPositions.Count == expectedPositions.Count);
            foreach (var p in returnedPositions)
            {
                Assert.IsTrue(positionRepository.Contains(p));
            }
        }

        [TestMethod]
        [ExpectedException(typeof(DbUpdateConcurrencyException))]
        public void TestUpdatePositionWithConcurrencyException()
        {
            List<Data.SodPosition> positionRepository = new List<Data.SodPosition>()
            {
                new Data.SodPosition { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Straddle", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="OPTION", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="LOSH", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EQUITY", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Straddle", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="OPTION", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="USEQ", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EQUITY", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="JPEQ", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EQUITY", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="JPEQ", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EQUITY", LastModifiedOn=now, LastModifiedBy="kishore"},
            };
            var mockDAO = new Mock<Data.ISodPositionEdit>();
            mockDAO.Setup(c => c.GetAction(It.IsAny<string>(), It.IsAny<string>())).Returns<string, string>((name, type) => actionRepository.Find(x => x.Name == name && x.Type == type));
            mockDAO.Setup(c => c.CreateActionLog(It.IsAny<Data.ActionLog>())).Returns<Data.ActionLog>(a => new Data.ActionLog { ActionId = 3, ActionLogId = 1, CreatedOn = DateTime.Now });
            mockDAO.Setup(c => c.UpdatePosition(It.IsAny<Data.SodPosition>())).Returns<Data.SodPosition>(a => a);
            mockDAO.Setup(c => c.InsertException(It.IsAny<Data.Exception>())).Returns<Data.Exception>(p => p);
            mockDAO.Setup(c => c.GetSodPosition(It.IsAny<int>())).Returns<int>(p =>
            {
                var existingPosition = positionRepository.Find(x => x.PositionId == p);
                return new Data.SodPosition
                {
                    PositionId = existingPosition.PositionId,
                    BAMSymbol = existingPosition.BAMSymbol,
                    Ccy = existingPosition.Ccy,
                    Price = existingPosition.Price,
                    EntryDate = existingPosition.EntryDate,
                    CustodianAccountCode = existingPosition.CustodianAccountCode,
                    FXRate = existingPosition.FXRate,
                    Qty = existingPosition.Qty,
                    FundCode = existingPosition.FundCode,
                    AssetType = existingPosition.AssetType,
                    Stream = existingPosition.Stream,
                    AuditSequence = existingPosition.AuditSequence - 1
                };
            });
            ISodPositionEdit sEdit = new SodPositionEdit(mockDAO.Object);
            var pos1 = sEdit.UpdatePosition(null, positionRepository[1]);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestUpdatePositionWithInvalidOperationException()
        {
            List<Data.SodPosition> positionRepository = new List<Data.SodPosition>()
            {
                new Data.SodPosition { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Straddle", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="OPTION", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="LOSH", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EQUITY", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Straddle", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="OPTION", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="USEQ", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EQUITY", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="JPEQ", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EQUITY", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="JPEQ", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EQUITY", LastModifiedOn=now, LastModifiedBy="kishore"},
            };
            var mockDAO = new Mock<Data.ISodPositionEdit>();
            mockDAO.Setup(c => c.GetAction(It.IsAny<string>(), It.IsAny<string>())).Returns<string, string>((name, type) => actionRepository.Find(x => x.Name == name && x.Type == type));
            mockDAO.Setup(c => c.CreateActionLog(It.IsAny<Data.ActionLog>())).Returns<Data.ActionLog>(a => new Data.ActionLog { ActionId = 3, ActionLogId = 1, CreatedOn = DateTime.Now });
            mockDAO.Setup(c => c.UpdatePosition(It.IsAny<Data.SodPosition>())).Returns<Data.SodPosition>(a => a);
            mockDAO.Setup(c => c.InsertException(It.IsAny<Data.Exception>())).Returns<Data.Exception>(p => p);
            mockDAO.Setup(c => c.GetSodPosition(It.IsAny<int>())).Returns<int>(p => null);
            ISodPositionEdit sEdit = new SodPositionEdit(mockDAO.Object);
            var pos1 = sEdit.UpdatePosition(null, positionRepository[1]);
        }

        [TestMethod]
        public void TestUpdatePosition()
        {
            List<Data.SodPosition> positionRepository = new List<Data.SodPosition>()
            {
                new Data.SodPosition { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Straddle", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="OPTION", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="LOSH", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EQUITY", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Straddle", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="OPTION", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="USEQ", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EQUITY", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="JPEQ", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EQUITY", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Data.SodPosition { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="JPEQ", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EQUITY", LastModifiedOn=now, LastModifiedBy="kishore"},
            };
            var existingPosition = positionRepository[1];
            var newPosition = new Data.SodPosition
            {
                PositionId = existingPosition.PositionId,
                BAMSymbol = existingPosition.BAMSymbol + "_TMP_",
                Ccy = existingPosition.Ccy + "_TMP_",
                Price = existingPosition.Price + 2.5M,
                EntryDate = existingPosition.EntryDate,
                CustodianAccountCode = existingPosition.CustodianAccountCode + "_TMP_",
                FXRate = existingPosition.FXRate + 2.5M,
                Qty = existingPosition.Qty + 2.5M,
                FundCode = existingPosition.FundCode + "_TMP_",
                AssetType = existingPosition.AssetType + "_TMP_",
                Stream = existingPosition.Stream + "_TMP_",
                AuditSequence = existingPosition.AuditSequence,
                LastModifiedBy = "CORP\\kishore"
            };
            var mockDAO = new Mock<Data.ISodPositionEdit>();
            mockDAO.Setup(c => c.GetAction(It.IsAny<string>(), It.IsAny<string>())).Returns<string, string>((name, type) => actionRepository.Find(x => x.Name == name && x.Type == type));
            mockDAO.Setup(c => c.CreateActionLog(It.IsAny<Data.ActionLog>())).Returns<Data.ActionLog>(a => new Data.ActionLog { ActionId = 3, ActionLogId = 2, CreatedOn = DateTime.Now });
            mockDAO.Setup(c => c.UpdatePosition(It.IsAny<Data.SodPosition>())).Returns<Data.SodPosition>(a => a);
            mockDAO.Setup(c => c.InsertException(It.IsAny<Data.Exception>())).Returns<Data.Exception>(p => p);
            mockDAO.Setup(c => c.GetSodPosition(It.IsAny<int>())).Returns<int>(p => positionRepository[1]);
            ISodPositionEdit sEdit = new SodPositionEdit(mockDAO.Object);
            var pos1 = sEdit.UpdatePosition(null, newPosition);
            var expectedPosition = new Data.SodPosition
            {
                PositionId = existingPosition.PositionId,
                BAMSymbol = existingPosition.BAMSymbol + "_TMP_",
                Ccy = existingPosition.Ccy + "_TMP_",
                Price = existingPosition.Price + 2.5M,
                EntryDate = existingPosition.EntryDate,
                CustodianAccountCode = existingPosition.CustodianAccountCode + "_TMP_",
                FXRate = existingPosition.FXRate + 2.5M,
                Qty = existingPosition.Qty + 2.5M,
                FundCode = existingPosition.FundCode + "_TMP_",
                AssetType = existingPosition.AssetType + "_TMP_",
                Stream = existingPosition.Stream + "_TMP_",
                AuditSequence = existingPosition.AuditSequence + 1,
                ActionLogId = 2,
                LastModifiedBy = "CORP\\kishore"
            };
            Assert.IsTrue(pos1.PositionId == expectedPosition.PositionId);
            Assert.IsTrue(pos1.BAMSymbol == expectedPosition.BAMSymbol);
            Assert.IsTrue(pos1.Ccy == expectedPosition.Ccy);
            Assert.IsTrue(pos1.Price == expectedPosition.Price);
            Assert.IsTrue(pos1.EntryDate == expectedPosition.EntryDate);
            Assert.IsTrue(pos1.FundCode == expectedPosition.FundCode);
            Assert.IsTrue(pos1.FXRate == expectedPosition.FXRate);
            Assert.IsTrue(pos1.AssetType == expectedPosition.AssetType);
            Assert.IsTrue(pos1.LastModifiedBy == expectedPosition.LastModifiedBy);
            Assert.IsTrue(pos1.LastModifiedOn < DateTime.Now && pos1.LastModifiedOn > DateTime.Now.AddMinutes(-1));
            Assert.IsTrue(pos1.Qty == expectedPosition.Qty);
            Assert.IsTrue(pos1.StrategyCode == expectedPosition.StrategyCode);
            Assert.IsTrue(pos1.Stream == expectedPosition.Stream);
            Assert.IsTrue(pos1.ActionLogId == 2);
        }

        private List<Data.Positions.SodAction> GetActions()
        {
            List<Data.Positions.SodAction> actionRepository = new List<Data.Positions.SodAction>()
            {
                new Data.Positions.SodAction {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Positions.SodAction {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Positions.SodAction {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Positions.SodAction {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new Data.Positions.SodAction{ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
            return actionRepository;
        }
        [TestMethod]
        public void TestBulkUpdatePosition()
        {
            List<Position> positionRepository = new List<Position>()
            {
                new Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="PM1-Straddle-SUBSTRADDLE", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="PM3-LOSH-SUBSTRAT", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="PM4-Straddle-SUBSTRADDLE", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Position { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="PM5-USEQ-SUBEQ", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new Position { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Goldman", FXRate=1M, Qty=200000M, StrategyCode="PM5-JPEQ-SUBEQ", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},
                new Position { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianAccountCode="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="PM5-JPEQ-SUBEQ", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},
            };

            var existingPosition1 = positionRepository[1];
            var existingPosition2 = positionRepository[2];
            var newPosition1 = new Position
            {
                PositionId = existingPosition1.PositionId,
                BAMSymbol = existingPosition1.BAMSymbol + "_TMP_",
                Ccy = existingPosition1.Ccy + "_TMP_",
                Price = existingPosition1.Price + 2.5M,
                EntryDate = existingPosition1.EntryDate,
                CustodianAccountCode = existingPosition1.CustodianAccountCode + "_TMP_",
                FXRate = existingPosition1.FXRate + 2.5M,
                Qty = existingPosition1.Qty + 2.5M,
                FundCode = existingPosition1.FundCode + "_TMP_",
                AssetType = existingPosition1.AssetType + "_TMP_",
                Stream = existingPosition1.Stream + "_TMP_",
                AuditSequence = existingPosition1.AuditSequence,
                LastModifiedBy = "CORP\\kishore"
            };

            var newPosition2 = new Position
            {
                PositionId = existingPosition2.PositionId,
                BAMSymbol = existingPosition2.BAMSymbol + "_TMP_",
                Ccy = existingPosition2.Ccy + "_TMP_",
                Price = existingPosition2.Price + 2.5M,
                EntryDate = existingPosition2.EntryDate,
                CustodianAccountCode = existingPosition2.CustodianAccountCode + "_TMP_",
                FXRate = existingPosition2.FXRate + 2.5M,
                Qty = existingPosition2.Qty + 2.5M,
                FundCode = existingPosition2.FundCode + "_TMP_",
                AssetType = existingPosition2.AssetType + "_TMP_",
                Stream = existingPosition2.Stream + "_TMP_",
                AuditSequence = existingPosition2.AuditSequence,
                LastModifiedBy = "CORP\\kishore"
            };
            var mockDAO = new Mock<ISodPositionEdit>();
            mockDAO.Setup(c => c.GetAction(It.IsAny<string>(), It.IsAny<string>())).Returns<string, string>((name, type) => actionRepository.Find(x => x.Name == name && x.Type == type));
            mockDAO.Setup(c => c.CreateActionLog(It.IsAny<Data.ActionLog>())).Returns<Data.ActionLog>(a => new Data.ActionLog { ActionId = 5, ActionLogId = 2, CreatedOn = DateTime.Now });
            mockDAO.Setup(c => c.UpdatePosition(It.IsAny<Data.SodPosition>())).Returns<Data.SodPosition>(a => a);
            mockDAO.Setup(c => c.InsertException(It.IsAny<Data.Exception>())).Returns<Data.Exception>(p => p);
            mockDAO.Setup(c => c.GetSodPositions(It.IsAny<IList<int>>())).Returns<List<int>>(p =>
            {
                return (from x in p
                        join y in positionRepository
                        on x equals y.PositionId
                        select y).ToList();

            });
            mockDAO.Setup(c => c.BulkUpdatePosition(It.IsAny<IList<Data.SodPosition>>())).Returns<IList<Data.SodPosition>>(p => p);
            ISodPositionEdit sEdit = new SodPositionEdit(mockDAO.Object);
            var updatedPositions = sEdit.BulkUpdatePosition(null, new List<Data.SodPosition> { newPosition1, newPosition2 });
            var expectedPosition1 = new Data.SodPosition
            {
                PositionId = existingPosition1.PositionId,
                BAMSymbol = existingPosition1.BAMSymbol + "_TMP_",
                Ccy = existingPosition1.Ccy + "_TMP_",
                Price = existingPosition1.Price + 2.5M,
                EntryDate = existingPosition1.EntryDate,
                CustodianAccountCode = existingPosition1.CustodianAccountCode + "_TMP_",
                FXRate = existingPosition1.FXRate + 2.5M,
                Qty = existingPosition1.Qty + 2.5M,
                FundCode = existingPosition1.FundCode + "_TMP_",
                AssetType = existingPosition1.AssetType + "_TMP_",
                Stream = existingPosition1.Stream + "_TMP_",
                AuditSequence = existingPosition1.AuditSequence + 1,
                ActionLogId = 2,
                LastModifiedBy = "CORP\\kishore"
            };

            var expectedPosition2 = new Data.SodPosition
            {
                PositionId = existingPosition2.PositionId,
                BAMSymbol = existingPosition2.BAMSymbol + "_TMP_",
                Ccy = existingPosition2.Ccy + "_TMP_",
                Price = existingPosition2.Price + 2.5M,
                EntryDate = existingPosition2.EntryDate,
                CustodianAccountCode = existingPosition2.CustodianAccountCode + "_TMP_",
                FXRate = existingPosition2.FXRate + 2.5M,
                Qty = existingPosition2.Qty + 2.5M,
                FundCode = existingPosition2.FundCode + "_TMP_",
                AssetType = existingPosition2.AssetType + "_TMP_",
                Stream = existingPosition2.Stream + "_TMP_",
                AuditSequence = existingPosition2.AuditSequence + 1,
                ActionLogId = 2,
                LastModifiedBy = "CORP\\kishore"
            };
            Assert.IsTrue(updatedPositions.Count == 2);
            Data.SodPosition pos1, pos2;
            if (updatedPositions[0].PositionId == expectedPosition1.PositionId)
            {
                pos1 = updatedPositions[0];
                pos2 = updatedPositions[1];
            }
            else
            {
                pos1 = updatedPositions[1];
                pos2 = updatedPositions[0];
            }
            Assert.IsTrue(pos1.PositionId == expectedPosition1.PositionId);
            Assert.IsTrue(pos1.BAMSymbol == expectedPosition1.BAMSymbol);
            Assert.IsTrue(pos1.Ccy == expectedPosition1.Ccy);
            Assert.IsTrue(pos1.Price == expectedPosition1.Price);
            Assert.IsTrue(pos1.EntryDate == expectedPosition1.EntryDate);
            Assert.IsTrue(pos1.FundCode == expectedPosition1.FundCode);
            Assert.IsTrue(pos1.FXRate == expectedPosition1.FXRate);
            Assert.IsTrue(pos1.AssetType == expectedPosition1.AssetType);
            Assert.IsTrue(pos1.LastModifiedBy == expectedPosition1.LastModifiedBy);
            Console.WriteLine(pos1.LastModifiedOn);
            // For some wierd reason, the assert below fails if test cases are run without debugging
            // but runs fine if run with debug enabled
            // Assert.IsTrue(pos1.LastModifiedOn < DateTime.Now && pos1.LastModifiedOn > DateTime.Now.AddMinutes(-1));
            Assert.IsTrue(pos1.Qty == expectedPosition1.Qty);
            Assert.IsTrue(pos1.StrategyCode == expectedPosition1.StrategyCode);
            Assert.IsTrue(pos1.Stream == expectedPosition1.Stream);
            Assert.IsTrue(pos1.ActionLogId == 2);


            Assert.IsTrue(pos2.PositionId == expectedPosition2.PositionId);
            Assert.IsTrue(pos2.BAMSymbol == expectedPosition2.BAMSymbol);
            Assert.IsTrue(pos2.Ccy == expectedPosition2.Ccy);
            Assert.IsTrue(pos2.Price == expectedPosition2.Price);
            Assert.IsTrue(pos2.EntryDate == expectedPosition2.EntryDate);
            Assert.IsTrue(pos2.FundCode == expectedPosition2.FundCode);
            Assert.IsTrue(pos2.FXRate == expectedPosition2.FXRate);
            Assert.IsTrue(pos2.AssetType == expectedPosition2.AssetType);
            Assert.IsTrue(pos2.LastModifiedBy == expectedPosition2.LastModifiedBy);
            Assert.IsTrue(pos2.LastModifiedOn < DateTime.Now && pos2.LastModifiedOn > DateTime.Now.AddMinutes(-1));
            Assert.IsTrue(pos2.Qty == expectedPosition2.Qty);
            Assert.IsTrue(pos2.StrategyCode == expectedPosition2.StrategyCode);
            Assert.IsTrue(pos2.Stream == expectedPosition2.Stream);
            Assert.IsTrue(pos2.ActionLogId == 2);
        }

        /*
        //[TestMethod]
        public void TestGetPositions()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var positions = sEdit.GetPositions(null, null, null, null, null, null, null, null);
            Assert.IsTrue(positions.Count > 0);
        }
        //[TestMethod]
        public void TestGetLatestUpdatedPositions()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var positions = sEdit.GetLatestUpdatedPositions(null);
        }

//        [TestMethod]
        public void TestGetAudits()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var audits = sEdit.GetAudits(null, 28359, new DateTime(2015, 11, 4));
            Console.WriteLine(audits);
        }

        //[TestMethod]
        public void TestUpdatePosition()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var pos = sEdit.GetPositions(null, null, null, null, null, null, null, "A").First() as Data.Positions.Position;
            var newPos = new Bam.Oms.Data.Positions.Position(new Data.Portfolios.Portfolio("COBI", "SPECIALIZED", "SLW_US"), new Data.Securities.Security() { BamSymbol = pos.Security.BamSymbol, SecurityType = pos.Security.SecurityType });
            newPos.ActualSide = Data.Enumerators.SideType.Short;
            newPos.FundCode = "MyFund";
            newPos.Stream = "EU";
            newPos.ActualQuantity = 1000;
            newPos.Security.Currency = "EUR";
            newPos.CustodianAccountCode = "CUST1";
            newPos.EntryDate = pos.EntryDate;
            newPos.FXRate = 2;
            newPos.LastModifiedBy = "kishore";
            newPos.PositionId = pos.PositionId;
            newPos.Price = 200.22M;
            newPos.AuditSequence = pos.AuditSequence;
            var updatedPosition = sEdit.UpdatePosition(null, newPos);
        }

//        [TestMethod]
        public void TestBulkUpdatePosition()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var pos = sEdit.GetPositions(null, null, null, null, null, null, null, "A").First() as Data.Positions.Position;
            var newPos = new Bam.Oms.Data.Positions.Position(new Data.Portfolios.Portfolio("COBI", "GENERALIZED", "SLW_US"), new Data.Securities.Security() { BamSymbol = pos.Security.BamSymbol, SecurityType = pos.Security.SecurityType });
            newPos.ActualSide = Data.Enumerators.SideType.Short;
            newPos.FundCode = "INITFND";
            newPos.Stream = "US";
            newPos.ActualQuantity = 1234;
            newPos.Security.Currency = "USD";
            newPos.CustodianAccountCode = "CPLSB";
            newPos.EntryDate = pos.EntryDate;
            newPos.FXRate = 1;
            newPos.LastModifiedBy = "kk";
            newPos.PositionId = pos.PositionId;
            newPos.Price = 1357.991M;
            newPos.AuditSequence = pos.AuditSequence;
            var updatedPosition = sEdit.BulkUpdatePosition(null, new List<Data.Positions.Position> { newPos });
        }

        //[TestMethod]
        public void TestBulkInsertPosition()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var lst = new List<Data.Positions.Position>();
            var positions = sEdit.GetPositions(null, null, null, null, null, null, null, null).Skip(30).Take(2).Cast<Data.Positions.Position>().ToList();
            int i = 0;
            foreach (var pos in positions)
            {
                var newPos = new Bam.Oms.Data.Positions.Position(new Data.Portfolios.Portfolio("COBI", "GENERALIZED", "SLW_US"), new Data.Securities.Security() { BamSymbol = pos.Security.BamSymbol, SecurityType = pos.Security.SecurityType });
                newPos.ActualSide = Data.Enumerators.SideType.Short;
                newPos.FundCode = "NEWFUND_T" + i++;
                newPos.Stream = "US";
                newPos.ActualQuantity = 1234;
                newPos.Security.Currency = "USD";
                newPos.CustodianAccountCode = "CPLSB";
                newPos.EntryDate = pos.EntryDate;
                newPos.FXRate = 1;
                newPos.LastModifiedBy = "kk";
                newPos.PositionId = pos.PositionId;
                newPos.Price = 1357.991M;
                newPos.AuditSequence = pos.AuditSequence;
                lst.Add(newPos);
            }
            var insertedPositions = sEdit.BulkInsertPosition(null, lst);
            Console.WriteLine(insertedPositions);
        }

        //[TestMethod]
        public void TestInsertPosition()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var lst = new List<Data.Positions.Position>();
            var pos = sEdit.GetPositions(null, null, null, null, null, null, null, null).Skip(40).First() as Data.Positions.Position;
            int i = 3;
           
                var newPos = new Bam.Oms.Data.Positions.Position(new Data.Portfolios.Portfolio("COBI", "GENERALIZED", "SLW_US"), new Data.Securities.Security() { BamSymbol = pos.Security.BamSymbol, SecurityType = pos.Security.SecurityType });
                newPos.ActualSide = Data.Enumerators.SideType.Short;
                newPos.FundCode = "NEWFUND_T" + i++;
                newPos.Stream = "US";
                newPos.ActualQuantity = 555;
                newPos.Security.Currency = "EUR";
                newPos.CustodianAccountCode = "CPLSB";
                newPos.EntryDate = pos.EntryDate;
                newPos.FXRate = 1;
                newPos.LastModifiedBy = "kk";
                newPos.PositionId = pos.PositionId;
                newPos.Price = 1357.991M;
                newPos.AuditSequence = pos.AuditSequence;
                lst.Add(newPos);
            
            var insertedPositions = sEdit.InsertPosition(null, newPos);
            Console.WriteLine(insertedPositions);
        }

        [TestMethod]
        public void PublishUpdatedPositions()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var updatedPositions = sEdit.GetLatestUpdatedPositions(null);
            var publishUpdatedPositions = sEdit.PublishUpdatedPositions(null);
            Assert.IsTrue(publishUpdatedPositions);
        }

        //[TestMethod]
        public void TestGetCorporateActions()
        {
            ISodPositionEdit sEdit = new SodPositionEdit();
            var corpActions = sEdit.GetCorporateActions(null);
            Console.WriteLine(corpActions);
        }
        */

        private Mock<DbSet<T>> GetMockDbSet<T>(IList<T> entryList) where T : class
        {
            var queryable = entryList.AsQueryable();
            var mockSet = new Mock<DbSet<T>>();
            mockSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(queryable.Provider);
            mockSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(queryable.Expression);
            mockSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(queryable.ElementType);
            mockSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(queryable.GetEnumerator());
            return mockSet;
        }

        private bool IsSamePosition(Position p1, Position p2)
        {
            if (p2 == p1)
                return true;

            return p1.Portfolio.Equals(p2.Portfolio)
                   && p1.Security.Equals(p2.Security)
                   && p1.ActualQuantity.Equals(p2.ActualQuantity)
                   && p1.ActualSide.Equals(p2.ActualSide)
                   && p1.TheoreticalQuantity.Equals(p2.TheoreticalQuantity)
                   && p1.TheoreticalSide.Equals(p2.TheoreticalSide)
                   && p1.PositionId == p2.PositionId
                   && p1.Price == p2.Price
                   && p1.Stream == p2.Stream
                   && p1.ActionLogId == p2.ActionLogId
                   && p1.AuditSequence == p2.AuditSequence
                   && p1.CreatedOn == p2.CreatedOn
                   && p1.CustodianAccountCode == p2.CustodianAccountCode
                   && p1.EntryDate == p2.EntryDate
                   && p1.FundCode == p2.FundCode
                   && p1.FXRate == p2.FXRate
                   && p1.LastModifiedBy == p2.LastModifiedBy
                   && p1.LastModifiedOn == p2.LastModifiedOn;
        }

        private bool IsSameAuditInfo(PositionAudit p1, PositionAudit p2)
        {
            if(p1 == p2)
            {
                return true;
            }
            return p1.PositionAuditId == p2.PositionAuditId
                && IsSamePosition(p1.Position, p2.Position);
        }

        private bool IsSameAction(SodAction act1, SodAction act2)
        {
            if(act1 == act2)
            {
                return true;
            }
            return act1.ActionId == act2.ActionId
                && act1.Description == act2.Description
                && act1.LastModifiedBy == act2.LastModifiedBy
                && act1.LastModifiedOn == act2.LastModifiedOn
                && act1.Name == act2.Name
                && act1.Type == act2.Type;
        }
    }
}
