﻿using System;
using System.Collections.Generic;
using System.Linq;
using Moq;
using NUnit.Framework;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Data.Compliance;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Compliance;
using Bam.Oms.Compliance.DataProvider;
using  Bam.Oms.Filtering;
using Bam.Oms.Compliance.Filters;

namespace Bam.Oms.Tests
{
    [Category("Integration")]
    [TestFixture()]
    public class ComplianceIntegrationTest
    {
        private string _connectionString = @"Data Source=dw-db-uat;Initial Catalog=BamCoreLite;UID=RiskSvcAgent;Pwd=R1skSvcAg3nt;Application Name=OrderGateway";
        private string _ogwy_connectionString = @"Data Source=bos-db-dev;Initial Catalog=OrderGateway;UID=BossApp;Pwd=BossApp1;Application Name=OrderGateway";

        [Test()]
        public void TestGetSecurities()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.SetupGet(s => s.BamCoreLiteConnectionString).Returns(_connectionString);
            settings.SetupGet(s => s.OrderGatewayConnectionString).Returns(_ogwy_connectionString);
            IFactProvider fact = new  FactProvider(new FactRepository(settings.Object, new Mock<ILogger>().Object));
            ISecurityDBRepository repo = new SecurityDBRepository(settings.Object, new Mock<ILogger>().Object);
            fact.RefreshData();

            var parameter = new Parameter()
            {
                Operator = new ComplianceOperator(fact) { OperatorType = OperatorType.InTheList },
                Property = "SecurityType",
                Value = "SupportedSecurityTypes"
            };
            var filter = new Filter<ISecurity>();
            filter.AddToFilter(string.Empty, new Parameter[] { parameter });

            IEnumerable<ISecurity> r = repo.GetSecurities(filter);
            Assert.IsTrue(r.Any());
        }

        [Test]
        public void TestGetPolicyRules()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.SetupGet(s => s.OrderGatewayConnectionString).Returns(_ogwy_connectionString);
            IPolicyRepository<CompliancePosition> repo = new PolicyRepository<CompliancePosition>(settings.Object, new Mock<ILogger>().Object);
            IRuleRepository<CompliancePosition> repoRules = new RuleRepository<CompliancePosition>(settings.Object, new Mock<ILogger>().Object);

            IEnumerable<IPolicy<CompliancePosition>> policies = repo.GetAll();
            IEnumerable<IRule<CompliancePosition>> rules = repoRules.GetRules(policies.ToList()[0].Id);

            Assert.IsTrue(policies.Count() > 0);
            Assert.IsTrue(rules.Count() > 0);
        }

        [Test]
        public void TestGetFacts()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.SetupGet(s => s.OrderGatewayConnectionString).Returns(_ogwy_connectionString);
            IFactRepository facts = new FactRepository(settings.Object, new Mock<ILogger>().Object);
            var list = facts.GetAll();

            Assert.IsTrue(list.Any());
        }
    }
}
