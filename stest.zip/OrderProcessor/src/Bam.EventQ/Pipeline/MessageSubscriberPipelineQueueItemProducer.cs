﻿using System;
using System.Threading;
using Bam.EventQ.Queue;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Pipeline
{
    public class MessageSubscriberPipelineQueueItemProducer<TItem> : ThreadedQueueItemProducerBase<PipelineQueueItem<TItem>>
    {
        private readonly byte[] _receiveBuffer;
        private readonly byte[] _batchBuffer;
        private readonly ArraySegment<byte>[] _batchSlices;
        private readonly int[] _batchTopics;

        private readonly IMessageSubscriber _messageSubscriber;
        private readonly ManualResetEventSlim _subscribed;

        public MessageSubscriberPipelineQueueItemProducer(IMessageSubscriber messageSubscriber, int bufferSize)
            : base(messageSubscriber.Name)
        {
            _messageSubscriber = messageSubscriber;
            _receiveBuffer = new byte[bufferSize];
            _batchBuffer = new byte[bufferSize];
            _batchSlices = new ArraySegment<byte>[bufferSize / 20]; // assume average message size is not smaller than 20 bytes
            _batchTopics = new int[_batchSlices.Length];
            _subscribed = new ManualResetEventSlim(false);
        }
        
        public override void Start()
        {
            base.Start();
            _subscribed.Wait();
        }

        protected override void Produce(CancellationToken cancellationToken)
        {
            _subscribed.Set();

            int index = 0;
            int offset = 0;
            var receiveTimeout = TimeSpan.FromMilliseconds(200);
            while (!cancellationToken.IsCancellationRequested)
            {
                int received, topic;
                if (_messageSubscriber.TryReceive(_receiveBuffer, 0, out received, out topic, 
                        index == 0 ? receiveTimeout : TimeSpan.Zero))
                {
                    if (received + offset > _batchBuffer.Length)
                    {
                        Publish(index);
                        offset = 0;
                        index = 0;
                    }

                    Buffer.BlockCopy(_receiveBuffer, 0, _batchBuffer, offset, received);
                    _batchSlices[index] = new ArraySegment<byte>(_batchBuffer, offset, received);
                    _batchTopics[index] = topic;
                    offset += received;
                    index++;
                }
                else if (index > 0)
                {
                    Publish(index);
                    offset = 0;
                    index = 0;
                }
            }
        }

        private void Publish(int count)
        {
            Queue.PublishBatch(count,
                (index, item) =>
                {
                    var slice = _batchSlices[index];

                    item.EnsureBufferSize(slice.Count);
                    Buffer.BlockCopy(
                        slice.Array, slice.Offset,
                        item.Buffer.Array, item.Buffer.Offset, slice.Count);
                    item.SetBufferLength(slice.Count);
                    item.SetTopic(_batchTopics[index]);
                });

            SpinWhilePaused();
        }
    }
}
