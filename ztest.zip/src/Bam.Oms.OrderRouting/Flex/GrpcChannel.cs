﻿using System;
using Bam.Oms.OrderRouting.Contracts;
using Grpc.Core;

namespace Bam.Oms.OrderRouting.Flex
{
    public class GrpcChannel : IGrpcChannel
    {
        private readonly Channel _channel;

        public GrpcChannel(Channel channel)
        {
            if (channel == null) throw new ArgumentNullException(nameof(channel));
            _channel = channel;
        }
        public ChannelState ChannelState => _channel.State;

        public Channel Channel =>_channel;

        public void Dispose()
        {
            _channel.ShutdownAsync().Wait();
        }

    }
}