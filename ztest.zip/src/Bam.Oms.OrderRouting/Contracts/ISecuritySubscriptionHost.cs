﻿using System;
using Bam.Oms.Data;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.OrderRouting.Contracts
{
    /// <summary>
    /// Service for sending and receiving security/asset information
    /// </summary>
    public interface ISecuritySubscriptionHost : ISubscriptionDisposable
    {
        /// <summary>
        /// Notify any listeners of a change to the downstream security master
        /// </summary>
        [Log]
        event Action<ISecurity> SecurityUpdated;
    }
}