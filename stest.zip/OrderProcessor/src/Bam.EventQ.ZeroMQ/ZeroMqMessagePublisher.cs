﻿using System;
using Bam.EventQ.Transport;
using NetMQ;
using NetMQ.Sockets;

namespace Bam.EventQ.ZeroMQ
{
    public class ZeroMqMessagePublisher : IMessagePublisher, IDisposable
    {
        private readonly PublisherSocket _socket;
        private readonly byte[] _topicBytes;

        public ZeroMqMessagePublisher(string endpoint)
        {
            _socket = new PublisherSocket(endpoint);
            _socket.Options.SendHighWatermark = 0; // unlimited
            _topicBytes = new byte[4];
        }
        
        public void Publish(int topic, byte[] data, int index, int count)
        {
            topic.CopyToBuffer(_topicBytes, 0);
            _socket.SendFrame(_topicBytes, true);
            
            var m = new Msg();
            m.InitPool(count);
            Buffer.BlockCopy(data, index, m.Data, m.Offset, count);
            _socket.Send(ref m, false);
            m.Close();
        }

        public void Dispose()
        {
            _socket.Dispose();
        }
    }
}
