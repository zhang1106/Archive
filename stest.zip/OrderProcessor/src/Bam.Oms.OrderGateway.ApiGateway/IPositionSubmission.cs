﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface IPositionSubmission
    {
        void ReplacePositions(IReadOnlyList<DetailedPosition> positions, string user);
    }
}
