﻿using Bam.Oms.Persistence.Positions;

namespace Bam.Oms.Persistence.DBContext
{
    /// <summary>
    /// Wraps all Sod position related DB repositories.
    /// </summary>
    public class SodPositionDBContext
    {
        public IPositionDBRepository Positions { get; private set; }
        public IPositionAuditRepository PositionAudits { get; private set; }
        public IPositionArchiveRepository PositionArchives { get; private set; }
        public IActionRepository Actions { get; private set; }
        public IActionLogRepository ActionLogs { get; private set; }
        public IExceptionRepository Exceptions { get; private set; }

        public SodPositionDBContext(IPositionDBRepository positionDBRepository,
                                    IPositionAuditRepository positionAuditRepository,
                                    IPositionArchiveRepository positionArchiveRepository,
                                    IActionRepository actionRepository,
                                    IActionLogRepository actionLogRepository,
                                    IExceptionRepository exceptionRepository)
        {
            Positions = positionDBRepository;
            PositionAudits = positionAuditRepository;
            PositionArchives = positionArchiveRepository;
            Actions = actionRepository;
            ActionLogs = actionLogRepository;
            Exceptions = exceptionRepository;
        }
    }
}
