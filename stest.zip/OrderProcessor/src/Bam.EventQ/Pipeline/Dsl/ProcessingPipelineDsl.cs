﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Queue;
using Bam.EventQ.Recovery;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Pipeline.Dsl
{
    public class ProcessingPipelineDsl
    {
        private readonly List<ProcessingPipelineStepDsl> _steps;
        private readonly List<IQueueErrorHandler> _errorHandlers;
        private readonly List<IRecoveryProcess> _recoveryProcesses;
        private IObjectDecorator _objectDecorator;
        private Action<object> _initAction;
        
        public ProcessingPipelineDsl()
        {
            _objectDecorator = new NullObjectDecorator();
            _initAction = o => { };
            _steps = new List<ProcessingPipelineStepDsl>();
            _errorHandlers = new List<IQueueErrorHandler>();
            _recoveryProcesses = new List<IRecoveryProcess>();
        }

        public ProcessingPipelineDsl AddStep<TItem>(Action<ProcessingPipelineStepDsl<TItem>> stepConfig)
        {
            var step = new ProcessingPipelineStepDsl<TItem>(this);
            stepConfig(step);
            _steps.Add(step);
            return this;
        }

        public ProcessingPipelineDsl UseObjectDecorator(IObjectDecorator decorator)
        {
            _objectDecorator = decorator;
            return this;
        }

        public ProcessingPipelineDsl UseObjectInitializer(Action<object> initAction)
        {
            _initAction = initAction;
            return this;
        }

        public ProcessingPipelineDsl UseRecoveryInvoker(IRecoveryInvoker recoveryInvoker)
        {
            RecoveryInvoker = recoveryInvoker;
            return this;
        }

        public ProcessingPipelineDsl UseRpcServer(IRpcServer server)
        {
            RpcServer = server;
            return this;
        }

        public ProcessingPipelineDsl AddErrorHandler(IQueueErrorHandler handler)
        {
            _errorHandlers.Add(handler);
            return this;
        }

        public ProcessingPipelineDsl LogErrors(ILogger logger)
        {
            return AddErrorHandler(new LogErrorHandler(logger));
        }

        public IRpcServer RpcServer { get; private set; }
        public IObjectDecorator ObjectDecorator => _objectDecorator;
        public Action<object> ObjectInitializer => _initAction;
        public IReadOnlyList<ProcessingPipelineStepDsl> Steps => _steps;
        public IReadOnlyList<IQueueErrorHandler> ErrorHandlers => _errorHandlers;
        public IRecoveryInvoker RecoveryInvoker { get; set; }

        public IProcessingPipeline Build()
        {
            var steps = new List<IProcessingPipelineStep>();
            foreach (var item in _steps)
            {
                steps.Add(item.Build());
            }

            if (RpcServer != null)
            {
                foreach (var p in _recoveryProcesses)
                {
                    ObjectInitializer(p);
                }

                if (_recoveryProcesses.Any())
                {
                    RpcRecoveryRequestHandler handler;
                    if (_recoveryProcesses.Count == 1)
                    {
                        handler = new RpcRecoveryRequestHandler(_recoveryProcesses[0]);
                    }
                    else
                    {
                        handler = new RpcRecoveryRequestHandler(
                            new CompositeRecoveryProcess(_recoveryProcesses.ToArray()));
                    }

                    ObjectInitializer(handler);
                    RpcServer.AddHandler(handler);
                }
            }

            return new ProcessingPipeline(steps.ToArray());
        }

        public ProcessingPipelineDsl AddRecoveryProcess(IRecoveryProcess process, int? index = null)
        {
            if (index != null)
                _recoveryProcesses.Insert(0, process);
            else
                _recoveryProcesses.Add(process);

            return this;
        }
    }
}
