﻿using Bam.Oms.Data.Configuration;
using BAM.Infrastructure.Ioc;


namespace Bam.Oms.Data
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            Container.Instance.RegisterType<ISettings, Settings>(RegistrationType.Singleton, "", new InjectionMethod("Initialize"));
            Container.Instance.RegisterType<IDateProvider, DateProvider>(RegistrationType.Singleton);
        }
    }
}