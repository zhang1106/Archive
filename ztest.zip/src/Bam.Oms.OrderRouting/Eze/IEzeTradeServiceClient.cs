﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.OrderRouting.EzeTradeAPI;

namespace Bam.Oms.OrderRouting.Eze
{
    public interface IEzeTradeServiceClient : IEzeTradingServiceSync, IDisposable
    {
       
    }
}
