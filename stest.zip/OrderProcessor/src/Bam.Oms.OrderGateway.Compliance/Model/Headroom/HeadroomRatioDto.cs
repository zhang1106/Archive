﻿namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    public class HeadroomRatioDto
    {
        public int RuleId { get; set; }
        public string AggregationUnit { get; set; }
        public double Ratio { get; set; }
    }
}