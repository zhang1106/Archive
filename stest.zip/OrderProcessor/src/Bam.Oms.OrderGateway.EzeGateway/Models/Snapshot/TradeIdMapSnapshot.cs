﻿using System.Collections.Generic;
using Bam.EventQ.Snapshot;

namespace Bam.Oms.OrderGateway.EzeGateway.Models.Snapshot
{
    public class TradeIdMapSnapshot : ISnapshot
    {
        public List<LineItem> Items { get; } = new List<LineItem>();

        public class LineItem
        {
            public string TradeId { get; set; }
            public string Strategy { get; set; }
            public string Symbol { get; set; }
            public long EmsOrderId { get; set; }
        }
    }
}
