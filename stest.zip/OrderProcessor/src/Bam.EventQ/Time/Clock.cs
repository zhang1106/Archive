﻿using System;
using System.Diagnostics;

namespace Bam.EventQ.Time
{
    [DebuggerDisplay("{Now} ({ZoneId,nq})")]
    public class Clock : IClock
    {
        private readonly TimeZoneInfo _timeZoneInfo;
        private static readonly Lazy<IClock> LazyUtc = new Lazy<IClock>(() => new UtcClock(), true);

        public Clock(string zoneId, TimeZoneInfo timeZoneInfo)
        {
            ZoneId = zoneId;
            _timeZoneInfo = timeZoneInfo;

            // ReSharper disable VirtualMemberCallInConstructor
            BusinessDate = Now.Date;
            // ReSharper restore VirtualMemberCallInConstructor
        }
        
        public static IClock Utc => LazyUtc.Value;

        public virtual string ZoneId { get; }
        public virtual DateTime BusinessDate { get; protected set; }

        public virtual DateTime Now => TimeZoneInfo.ConvertTime(DateTime.UtcNow, TimeZoneInfo.Utc, _timeZoneInfo);
        public virtual DateTime Today => Now.Date;

        public int Timestamp
        {
            get
            {
                long now = Now.Ticks;
                long offset = BusinessDate.Ticks;
                long delta = now - offset;

                return unchecked((int) (delta/(TimeSpan.TicksPerMillisecond/20))); // 20 micro second resolution
            }
        }

        public DateTime From(DateTime utc)
        {
            return TimeZoneInfo.ConvertTime(utc, TimeZoneInfo.Utc, _timeZoneInfo);
        }

        public DateTime From(DateTimeOffset dateTime)
        {
            return TimeZoneInfo.ConvertTime(dateTime, _timeZoneInfo).DateTime;
        }

        public TimeZoneInfo GetTimeZoneInfo()
        {
            return _timeZoneInfo;
        }

        public DateTime GetNextBusinessDay(TimeSpan minimumTimeToRollToNextDay)
        {
            var now = Now;
            var result = now.TimeOfDay < minimumTimeToRollToNextDay
                ? now.Date
                : now.Date.AddDays(1);

            return new DateTime(result.Year, result.Month, result.Day,
                0, 0, 0, DateTimeKind.Unspecified);
        }

        public void SetBusinessDay(DateTime businessDateTime)
        {
            var businessDay = businessDateTime.Date;
            BusinessDate = new DateTime(businessDay.Year, businessDay.Month, businessDay.Day,
                0, 0, 0, DateTimeKind.Unspecified);
        }
    }
}
