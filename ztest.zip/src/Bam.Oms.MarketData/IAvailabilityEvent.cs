﻿using Bam.Oms.MarketData.Enumerators;

namespace Bam.Oms.MarketData
{
    public interface IAvailabilityEvent
    {
        AvailabilityType Type { get; }
        string Text { get; }
    }
}
