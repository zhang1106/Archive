﻿using System.Linq.Expressions;

namespace Bam.Oms.Data.Enumerators
{
    public enum OperatorType
    {
        Equal = ExpressionType.Equal,
        NotEqual = ExpressionType.NotEqual,
        GreatThan = ExpressionType.GreaterThan,
        GreatThanOrEqual = ExpressionType.GreaterThanOrEqual,
        LessThan = ExpressionType.LessThan,
        LessThanOrEqual = ExpressionType.LessThanOrEqual,
        InList
    }
}
