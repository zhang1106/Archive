﻿namespace Bam.Oms.OrderGateway.ApiGateway.Cache
{
    public interface IMortal
    {
        bool IsDeceased();
        void Kill();
    }
}