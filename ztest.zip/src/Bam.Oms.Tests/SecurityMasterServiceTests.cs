﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Messaging;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR.Client;
using Bam.Oms.ReferenceDataGateway.Api.Model;
using FluentAssertions;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    public class SecurityMasterServiceTests
    {
        [TestCase("IBM LN", "CSPB", "IBM LN CS SWAP")]
        [TestCase("IBM LN", "MSCO", "IBM LN MS SWAP")]
        [TestCase("MSFT LN", "CSPB", "MSFT LN CS SWAP")]
        [TestCase("MSFT LN", "MSCO", "MSFT LN SWAP")]
        [TestCase("MSFT LN", "UBSW", null)]
        public void VerifyGetSwapSecurity(string symbol, string broker, string expectedSymbol)
        {
            var securityController = new Mock<ReferenceDataGateway.Api.Http.ISecurityController>();
            var logger = new Mock<ILogger>();
            var client = new SignalRClient<SignalRPacket<Security>>(
                new Mock<IConnection>().Object, 
                new Mock<IHubProxy<ISignalRHub, ISignalRClient<SignalRPacket<Security>>>>().Object);
            ConfigureSecurityMaster(securityController);

            var sut = new SecurityMasterService(securityController.Object, logger.Object, client);
            var actual = sut.GetSwapSecurity(symbol, broker);

            if (expectedSymbol == null)
            {
                actual.Should().BeNull();
            }
            else
            {
                actual.Should().NotBeNull();
                actual.BamSymbol.Should().Be(expectedSymbol);
            }
        }

        private void ConfigureSecurityMaster(Mock<ReferenceDataGateway.Api.Http.ISecurityController> sm)
        {
            var ibm = new Security
            {
                BamSymbol = "IBM LN",
                SecurityType = SecurityType.Equity
            };

            var msft = new Security
            {
                BamSymbol = "MSFT LN",
                SecurityType = SecurityType.Equity
            };

            var ibmSwapCspb = new Security
            {
                BamSymbol = "IBM LN CS SWAP",
                SecurityType = SecurityType.EquitySwap
            };

            var ibmSwapMsco = new Security
            {
                BamSymbol = "IBM LN MS SWAP",
                SecurityType = SecurityType.EquitySwap
            };

            var ibmSwapMsco2 = new Security
            {
                BamSymbol = "IBM LN SWAP",
                SecurityType = SecurityType.EquitySwap
            };

            var msftSwapMsco = new Security
            {
                BamSymbol = "MSFT LN SWAP",
                SecurityType = SecurityType.EquitySwap
            };

            var msftSwapCspb = new Security
            {
                BamSymbol = "MSFT LN CS SWAP",
                SecurityType = SecurityType.EquitySwap
            };

            var securities = new Dictionary<string, Security>(StringComparer.OrdinalIgnoreCase)
            {
                {ibm.BamSymbol, ibm},
                {msft.BamSymbol, msft},
                {ibmSwapCspb.BamSymbol, ibmSwapCspb},
                {ibmSwapMsco.BamSymbol, ibmSwapMsco},
                {ibmSwapMsco2.BamSymbol, ibmSwapMsco2},
                {msftSwapCspb.BamSymbol, msftSwapCspb},
                {msftSwapMsco.BamSymbol, msftSwapMsco}
            };

            sm.Setup(m => m.PostQueryMany(It.IsAny<string[]>())).Returns(
                (string[] tickers) =>
                {
                    return tickers.Where(securities.ContainsKey).Select(s => securities[s]).ToList();
                });

            foreach (var sec in securities.Values)
            {
                sm.Setup(m => m.Get(sec.BamSymbol)).Returns(() => sec);
            }
        }
    }
}
