﻿using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Lookup;

namespace Bam.EventQ.Workflow
{
    public abstract class Workflow<TItem> : EventAggregator<TItem>, IWorkflow, IModelEventHandler<TItem>
    {
        private const int InitialCapacity = 16;
        
        private readonly List<TItem> _result = new List<TItem>(InitialCapacity);
        private readonly List<TItem> _removeList = new List<TItem>(InitialCapacity);

        private long _sequence;
        private bool _isReplay;
        private ILogger _mutedLogger;

        public ILogger Logger { get; set; }
        public long Sequence => _sequence;
        public bool IsReplay => _isReplay;

        protected Workflow()
        {
            ((IEventSource<TItem>) this).EventHandler = this;
        }

        public virtual void Reset(long sequence, bool isReplay)
        {
            _result.Clear();
            _sequence = sequence;
            _isReplay = isReplay;
            if (isReplay && Logger != null)
            {
                _mutedLogger = Logger;
                Logger = null;
            }
            else if (!isReplay && Logger == null)
            {
                Logger = _mutedLogger;
                _mutedLogger = null;
            }
        }

        public void Reset()
        {
            Reset(0, false);
        }
        
        public virtual IReadOnlyList<TItem> Result => _result;

        protected List<TItem> GetResults()
        {
            return _result;
        }

        public void Publish(TItem message)
        {
            _result.Add(message);
        }

        public void Publish(TItem[] messages)
        {
            _result.AddRange(messages);
        }

        public void RemoveAll<TMsg>()
        {
            // Using two lists is much faster than calling
            // Remove(At) on the _results list

            // ReSharper disable once ForCanBeConvertedToForeach
            for (int i = 0; i < _result.Count; i++)
            {
                if (_result[i].GetType() != typeof(TMsg))
                    _removeList.Add(_result[i]);
            }

            _result.Clear();
            _result.AddRange(_removeList);
            _removeList.Clear();
        }
        
        void IModelEventHandler<TItem>.Handle(TItem @event)
        {
            _result.Add(@event);
        }
    }
}
