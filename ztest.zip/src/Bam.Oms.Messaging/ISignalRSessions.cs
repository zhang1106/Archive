﻿using System;
using System.Collections.Generic;

namespace Bam.Oms.Messaging
{
    public interface ISignalRSessions<T>
    {
        void Add(string connectionId, Func<T, bool> filter);
        void Remove(string connectionId);
        IEnumerable<string> ConnectionIds { get; }
        IEnumerable<T> Filter(IEnumerable<T> items, string connectionId);
        IReadOnlyDictionary<string, IEnumerable<T>> Filter(IEnumerable<T> items);
        event Action<string> NewSession;
    }
}