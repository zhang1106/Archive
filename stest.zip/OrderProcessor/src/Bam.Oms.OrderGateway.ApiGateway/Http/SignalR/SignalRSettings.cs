﻿using System;
using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.SignalR
{
    public class SignalRSettings : AppSettingsBase
    {
        public SignalRSettings() : base ("ApiGateway.SignalR.")
        {

        }

        public int BufferSize
        {
            get { return GetValue(() => BufferSize, 500); }
        }

        public int BatchSize
        {
            get { return GetValue(() => BatchSize, 40); }
        }

        public TimeSpan ConnectionTimeout
        {
            get { return GetValue(() => ConnectionTimeout, TimeSpan.FromSeconds(120)); }
        }
    }
}
