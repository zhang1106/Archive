﻿using System;
using System.Threading.Tasks;
using System.Security.Principal;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;

namespace Bam.Oms.Messaging
{
    /// <summary>
    /// Abstract ephemeral hub
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class SignalRHub<T> : Hub<ISignalRClient<T>>, ISignalRHub
    {
        private readonly ISignalRSessions<T> _sessions;
        protected readonly ILogger _logger;

        protected string HubType { get; } = typeof(T).AssemblyQualifiedName;

        protected SignalRHub(ISignalRSessions<T> sessions, ILogger logger)
        {
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            _sessions = sessions;
            _logger = logger;
        }

        public override Task OnConnected()
        {
            _logger.DebugFormat("ConnectionId {0} connected on hub of type {1}", Context.ConnectionId, HubType);
            _sessions.Add(Context.ConnectionId, CreateFilter(Context.User?.Identity));
            return base.OnConnected();
        }

        public override Task OnDisconnected(bool stopCalled)
        {
            _logger.DebugFormat("Disconnected {0} {1} on hub of type {2}", Context.ConnectionId, stopCalled, HubType);
            _sessions.Remove(Context.ConnectionId);
            return base.OnDisconnected(stopCalled);
        }

        public override Task OnReconnected()
        {
            _logger.DebugFormat("ConnectionId {0} reconnected hub of type {1}", Context.ConnectionId, HubType);
            _sessions.Add(Context.ConnectionId, CreateFilter(Context.User?.Identity));
            return base.OnReconnected();
        }

        public void AddFilter(ParameterString[] criteria)
        {
            // deprecated
        }

        public void RemoveFilter()
        {
            // deprecated
        }

        public void Ping()
        {
            var hubContext = GetHubContext();
            var client = hubContext.Clients.Client(Context.ConnectionId);

            var now = DateTime.Now;
            client.Pong(now.Ticks);

            _logger.DebugFormat("Connection id ping {0} at {1}", Context.ConnectionId, now.ToString("o"));
        }

        protected abstract Func<T, bool> CreateFilter(IIdentity identity);

        public abstract IHubContext<ISignalRClient<SignalRPacket<T>>> GetHubContext();
    }
}
