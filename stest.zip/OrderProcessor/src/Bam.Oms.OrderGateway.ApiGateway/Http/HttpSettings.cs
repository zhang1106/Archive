﻿using System;
using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway.Http
{
    public class HttpSettings : AppSettingsBase
    {
        public HttpSettings() : base ("ApiGateway.Http.")
        {
            
        }

        public string BaseUrl
        {
            get { return GetValue(() => BaseUrl, "http://localhost:8090"); }
        }

        public TimeSpan DefaultTokenExpiry
        {
            get { return GetValue(() => DefaultTokenExpiry, TimeSpan.FromDays(1)); }
        }

        public bool AllowTokenAsUrlParameter
        {
            get { return GetValue(() => AllowTokenAsUrlParameter, true); }
        }

        public int? MaxPendingRequests
        {
            get { return GetValue(() => MaxPendingRequests); }
        }

        public int? MaxActiveRequests
        {
            get { return GetValue(() => MaxActiveRequests); }
        }
    }
}
