﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.RefData;
using Bam.Oms.RefData.Eze;
using Bam.Oms.ReferenceDataGateway.Api.Http;
using Bam.Oms.ReferenceDataGateway.Api.Model;
using BAM.Infrastructure.Ioc;
using FluentAssertions;
using Moq;
using NUnit.Framework;
using Portfolio = Bam.Oms.Data.Portfolios.Portfolio;
using Security = Bam.Oms.Data.Securities.Security;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class AccountServiceTests
    {
        [TestCase("SEET-TMT-US", "UBSW", BamOrderStatus.PendingValidation)]
        [TestCase("GREE-GENERALIST-USCS", "UBSW", BamOrderStatus.PendingValidation)]
        [TestCase("GREE-GENERALIST-1234", null, BamOrderStatus.Error)]
        [TestCase("QIAN-GENERALIST", "CBPS", BamOrderStatus.PendingValidation)]
        [TestCase("QIAN-GENERALIST-1234", null, BamOrderStatus.Error)]
        [TestCase("SEB-ISNO-PM", null, BamOrderStatus.Error)]
        [TestCase("PMB", null, BamOrderStatus.Error)]
        public void VerifyPicksCustodian(string portfolio, string expected, BamOrderStatus status)
        {
            var accounts = new Mock<IAccountController>();
            var coverage = new Mock<ICoverageController>();
            var sql = new Mock<ISqlConnectionWrapper>();
            var logger = new Mock<ILogger>();

            accounts.Setup(r => r.Get()).Returns(new List<ReferenceDataGateway.Api.Model.Portfolio>());


            accounts.Setup(m => m.GetCustodian("SEET-TMT-US", "USD")).Returns(
                "UBSW");
            accounts.Setup(m => m.GetCustodian("GREE-GENERALIST","USD")).Returns(
                  "UBSW" );
            accounts.Setup(m => m.GetCustodian("GREE-GENERALIST-USCS", "USD")).Returns("UBSW");
            accounts.Setup(m => m.GetCustodian("QIAN-GENERALIST", "USD")).Returns("CBPS" );
            accounts.Setup(m => m.GetCustodian("SEB-ISNO-PM", "USD")).Returns((string)null);

            var sut = new AccountService(accounts.Object, coverage.Object, sql.Object, logger.Object);
            var order = new Order { Portfolio = (Portfolio) Portfolio.Parse(portfolio), Security = new Security() {Currency = "USD"} };

            sut.SetCustodian(order);

            order.Custodian.Should().Be(expected);
            order.OrderStatus.Should().Be(status);
        }
    }
}
