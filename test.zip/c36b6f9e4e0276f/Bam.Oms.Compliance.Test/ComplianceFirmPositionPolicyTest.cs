﻿using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Policies;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Securities;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class ComplianceFirmPositionPolicyTest
    {
        private ISettings _settings;

        [SetUp]
        public void Setup()
        {
            _settings = Factory.GetSettings();
        }

        [Test]
        public void TestFirmPositionLimitPolicyAddRule()
        {
            //arr
            var policy = new FirmPositionLimitPolicy() { Type = "FirmPositionLimitPolicy" };
            var rule1 = new LongOwnershipLimit( )
            {
                Name = "LongOnwershipLimit1",
                IsActive = true,
                Type = "Bam.Oms.Compliance.Rules.LongOwnershipLimit",
                Threshhold = 1300000
            };
            //act
            policy.AddRule(rule1);

            //ass
            Assert.IsTrue(policy.Rules.Count == 1);
        }

        [Test]
        [TestCase("LongOnwershipLimit1", 1300000, Data.Enumerators.ComplianceAlertLevel.Restricted)]
        [TestCase("LongOnwershipLimit1", 1400000, Data.Enumerators.ComplianceAlertLevel.NoViolation)]
        public void TestFirmPositionLimitPolicy(string ruleName, decimal threshhold, Data.Enumerators.ComplianceAlertLevel alertLevel)
        {
            var policyProvider = new Mock<IPolicyProvider>();
            var rule = new LongOwnershipLimit()
            {
                Name = ruleName,
                IsActive = true,
                Type = "Bam.Oms.Compliance.Rules.LongOwnershipLimit",
                Threshhold = threshhold
            };

            var policy = new FirmPositionLimitPolicy() { Type = "FirmPositionLimitPolicy" };
            policy.AddRule(rule);

            policyProvider.Setup(n => n.Get(It.IsAny<string>()))
                .Returns((Policy<ICompliancePosition>)policy);
            //
            
            var pos = Factory.CreateCompliancePosition(_settings, new Security(){BamSymbol = "Test"},policy,true, 1350000m);
            //act

            var result = policy.CheckViolations(pos.Object, false);

            //assert
            Assert.IsTrue(result.Alerts[0].AlertLevel == alertLevel);
        }
    }
}
