﻿using System;

namespace Bam.Oms.Data.Enumerators
{
    public class EnumAttribute : Attribute
    {
        public string StringValue
        {
            get;
            set;
        }
    }

}
