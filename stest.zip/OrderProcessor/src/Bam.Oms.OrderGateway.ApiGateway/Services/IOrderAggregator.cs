﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public interface IOrderAggregator
    {
        IReadOnlyList<SubmitOrders.SubmitOrderLineItem> Collapse(IReadOnlyList<SubmitOrders.SubmitOrderLineItem> fullList);
    }
}