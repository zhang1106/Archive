﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;
using Newtonsoft.Json;

namespace Bam.Oms.Compliance.DataProvider
{
    public class HoldingProvider : IHoldingProvider
    {
        private readonly ISettings _settings;
        private readonly IHelper _helper;
        private readonly IJsonDataProvider _jsonDataProvider;
        private readonly ISecurityProvider _dwSecurityProvider;
        private readonly ICompositeDecomposer _compositeDecomposer;
        private readonly ICustomDataProvider _customDataProvider;
        private readonly IOgDataRepository _ogDataRepository;
        private readonly IMarketDataProvider _marketDataProvider;
        private readonly IDwRepository _dwRepository;
        private readonly ILogger _logger;
        private bool _contingencyPosUsed;

        public HoldingProvider(IJsonDataProvider jsonProvider, ISecurityProvider dwSecurityProvider,
            ICompositeDecomposer compositeDecomposer, ICustomDataProvider customDataProvider,
            IOgDataRepository ogDataRepository, IMarketDataProvider marketDataProvider, IDwRepository dwRepository,
            ISettings settings, IHelper helper, ILogger logger)
        {
            _jsonDataProvider = jsonProvider;
            _dwSecurityProvider = dwSecurityProvider;
            _compositeDecomposer = compositeDecomposer;
            _customDataProvider = customDataProvider;
            _ogDataRepository = ogDataRepository;
            _marketDataProvider = marketDataProvider;
            _dwRepository = dwRepository;
            _settings = settings;
            _helper = helper;
            _logger = logger;
        }

        private IDictionary<string, MarketData> MarketData => _marketDataProvider.CurrentMarketData;

        //sod
        public IList<IPosition> SodPositions { get; set; }
        public IList<IPosition> DecomposedSodPositions { get; set; }
        public ILookup<string, IPosition> DecomposedSodByUnderlying { get; set; }
        public ILookup<string, IPosition> DecomposedSodByIsin { get; set; }
        public ILookup<string, IPosition> SodByUnderlying { get; set; }
        public ConcurrentDictionary<string, IList<IPosition>> SodPositionDictionary { get; set; }
        //intraday
        public IList<IPosition> IntradayPositions { get; set; }
        public IList<IPosition> DecomposedIntradayPositions { get; set; }
        public ILookup<string, IPosition> DecomposedIntradayByIsin { get; set; }
        public ILookup<string, IPosition> DecomposedIntradayByUnderlying { get; set; }
        public ILookup<string, IPosition> IntradayByUnderlying { get; set; }
        //eod
        public IList<IPosition> EodPositions { get; set; }
        public IList<IPosition> DecomposedEodPositions { get; set; }
        public ILookup<string, IPosition> DecomposedEodByIsin { get; set; }
        public ILookup<string, IPosition> DecomposedEodByUnderlying { get; set; }
        public ILookup<string, IPosition> EodByUnderlying { get; set; }

        public void RefreshData(PositionType pType)
        {
            try
            {
                //populate pomo data for market data
                if  (pType == PositionType.Intraday)
                {
                    IntradayPositions = new List<IPosition>();
                    _logger.Info($"{pType}: populate pomo data");
                    PopulatePomoData();

                    _logger.Info($"{pType}: Prepare intraday data");
                    DecomposedIntradayPositions = Decompose(IntradayPositions).ToList();
                    IntradayByUnderlying = IntradayPositions.Where(i => !string.IsNullOrEmpty(i.Security.UnderlyingSymbol)).ToLookup(i => i.Security.UnderlyingSymbol);
                    DecomposedIntradayByIsin = DecomposedIntradayPositions.Where(i => !string.IsNullOrEmpty(i.Security.Isin)).ToLookup(d => d.Security.Isin);
                    DecomposedIntradayByUnderlying = DecomposedIntradayPositions.Where(d => !string.IsNullOrEmpty(d.Security.UnderlyingSymbol)).ToLookup(d => d.Security.UnderlyingSymbol);

                    return;
                }

                if (pType == PositionType.Eod) return;

                PopulateSod();
            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
 
            }
        }


        protected void PopulateSod()
        {
            SodPositions = new List<IPosition>();

            _logger.Info("Sod: Populate OG sod positions");
            LoadSodPositions();

            _logger.Info("Sod: Populate OG contingency positions");
            PopulateContingencyPositions();

            var lookup = SodPositions.ToLookup(p => p.Key);

            var dictionary = lookup.Select(l => l.Key)
                .ToDictionary<string, string, IList<IPosition>>(key => key, key => lookup[key].ToList());
            SodPositionDictionary = new ConcurrentDictionary<string, IList<IPosition>>(dictionary);

            //mount loaded sod on top of eod
            if (_contingencyPosUsed)
            {
                _logger.Info("Sod: Contingency positions used.");
                var sodUpdates = _ogDataRepository.GetLoadedSodPositions().ToList();
                if (sodUpdates.Any())
                {
                    _logger.Info($"Sod: Applied {sodUpdates.Count} sod positions on top of Contingency positions.");
                    Update(_helper.Convert(sodUpdates, PositionType.Sod), PositionType.Sod);
                }
            }

            DecomposedSodPositions = Decompose(SodPositions).ToList();
            DecomposedSodByIsin = DecomposedSodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.Isin)).ToLookup(d => d.Security.Isin);
            DecomposedSodByUnderlying = DecomposedSodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.UnderlyingSymbol)).ToLookup(d => d.Security.UnderlyingSymbol);
            SodByUnderlying = SodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.UnderlyingSymbol)).ToLookup(s => s.Security.UnderlyingSymbol);

            //
            _helper.DumpToDb(SodPositions, PositionType.Sod);
            _helper.DumpToDb(DecomposedSodPositions, PositionType.SodDecomposed);

            //
            GetMarketData(PositionType.Sod);
        }

        protected void GetMarketData(PositionType pType)
        {
            if (!_settings.UseBloombBergData) return;

            var noData = (GetUnderlyingSecurities(pType).Where(s => !MarketData.ContainsKey(s) && !_marketDataProvider.CheckedInBb.Contains(s))).ToList();

            _logger.Info($"{pType}: BB Warning: No sharesoutstanding for {noData.Count()} securities");
            _marketDataProvider.GetBbData(noData);
        }

        public IEnumerable<string> GetUnderlyingSecurities(PositionType pType)
        {
            if (pType == PositionType.Sod)
            {
                var underlyingSymbols = _dwSecurityProvider.Securities.Where(s => SodByUnderlying.Contains(s.Value.UnderlyingSymbol)).Select(s => s.Value?.UnderlyingSymbol);
                var decomposedSymbols = _dwSecurityProvider.Securities.Where(s => DecomposedSodByIsin.Contains(s.Value.Isin)).Select(s => s.Value?.UnderlyingSymbol);
                var adrRef = _dwSecurityProvider.AdrLookup.Select(a => a.Key);
                return decomposedSymbols.Union(underlyingSymbols).Union(adrRef);
            }

            var data = GetData(pType, PositionIndex.Underlying);
            return data.Select(s => s.Key).Distinct();
        }
        
       
        public IEnumerable<IPosition> Decompose(IEnumerable<IPosition> positions)
        {
            var decomposed = new List<IPosition>();
            foreach (var p in positions)
            {
                p.Portfolio.AggregationUnit = _customDataProvider.GetEntity(p.Portfolio.ToString());
                var constituents = _compositeDecomposer.Decompose(p);
                if(constituents!= null) decomposed.AddRange(constituents);
            }
            return decomposed;
        }
        
        public void PopuldateEodPositions(DateTime date)
        {
            _logger.Info($"Eod: populate eod data for {date.ToShortDateString()}");
            var eodPosition = _dwRepository.GetEodPositions(date);
            EodPositions = _helper.Convert(eodPosition, PositionType.Eod).ToList();
            //
            DecomposedEodPositions = Decompose(EodPositions).ToList();
            DecomposedEodByIsin = DecomposedEodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.Isin)).ToLookup(d => d.Security.Isin);
            DecomposedEodByUnderlying = DecomposedEodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.UnderlyingSymbol)).ToLookup(d => d.Security.UnderlyingSymbol);
            EodByUnderlying = EodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.UnderlyingSymbol)).ToLookup(s => s.Security.UnderlyingSymbol);
            
            //refresh market data
            _marketDataProvider.RefreshData();

            GetMarketData(PositionType.Eod);

            _helper.DumpToDb(EodPositions, PositionType.Eod);
            _helper.DumpToDb(DecomposedEodPositions, PositionType.EodDecomposed);
        }

        public void Update(IEnumerable<IPosition> positions, PositionType pType)
        {
            var lookup = positions.ToLookup(p => p.Key);
            foreach (var lKey in lookup.Select(l => l.Key))
            {
                var sodPositions = lookup[lKey].ToList();
                SodPositionDictionary.AddOrUpdate(lKey, sodPositions, (key, oldVal) => sodPositions);
            }

            var newSodPositions = new List<IPosition>();
            foreach (var value in SodPositionDictionary.Values)
            {
                newSodPositions.AddRange(value);
            }
            SodPositions = newSodPositions;

            DecomposedSodPositions = Decompose(SodPositions).ToList();
            DecomposedSodByIsin = DecomposedSodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.Isin)).ToLookup(d => d.Security.Isin);
            DecomposedSodByUnderlying = DecomposedSodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.UnderlyingSymbol)).ToLookup(d => d.Security.UnderlyingSymbol);
            SodByUnderlying = SodPositions.Where(d=>!string.IsNullOrEmpty(d.Security.UnderlyingSymbol)).ToLookup(s => s.Security.UnderlyingSymbol);
        }

        public void LoadSodPositions()
        {
            if (!_ogDataRepository.IsSodPositionsSynced())
            {
                _logger.Info("Sod: Init-Not init Sod positions. Different tradedates between AQTF and Main");
                return;
            }

            var positions = _ogDataRepository.GetAllSodPositions().ToList();

            //using ct time
            if (positions.Any() && SodPositions.Any() && positions[0].TradeDate < SodPositions[0].EntryDate)
            {
                _logger.Info($"Sod: Current Sod Positions has later trade date than {positions[0].TradeDate}");
                return;
            }

            SodPositions = _helper.Convert(positions, PositionType.Sod).ToList();
        }

        public void PopulateContingencyPositions()
        {
            _contingencyPosUsed = false;

            if (!_ogDataRepository.IsContingencyPositionsSynced())
            {
                _logger.Info("Sod: Contingency Position Load-Not load Contignency positions. Different tradedates between AQTF and Main");
                return;
            }

            var positions = _ogDataRepository.GetEodPositions().ToList();

            //using ct time
            if (positions.Any() && SodPositions.Any() && positions[0].TradeDate <= SodPositions[0].EntryDate)
            {
                _logger.Info($"Sod: Contingency Position Load-Not load Contignency positions. Already Has Sod Positions for {positions[0].TradeDate}");
                return;
            }
            SodPositions = _helper.Convert(positions, PositionType.Sod).ToList();

            _contingencyPosUsed = true;
        }

        /// <summary>
        /// populate data from a json string which is generated from pomo svc
        /// </summary>
        public void PopulatePomoData()
        {
            try
            {
                //populdate position data
                var holding = _jsonDataProvider.GetDataInJson(_settings.PomoHoldingUrl);
                var holdingData = JsonConvert.DeserializeObject<HoldingContainerInfo>(holding);

                //pomo position linked by dw security id
                var pomoSecurities = holdingData.Securities.ToDictionary(s => s.SecurityId);
 
                foreach (var position in holdingData.Holdings)
                {
                    if (!pomoSecurities.ContainsKey(position.SecurityId)) continue;
                    //exclude paper portfolio (dups)
                    if (position.FundCode == "QNT") continue;
                    //exclude OMNI
                    if (position.CustodianAccountCode.StartsWith("OMNI")) continue;
                    
                    var security = _dwSecurityProvider.GetSecurity(pomoSecurities[position.SecurityId].DisplayCode);
                    if (security == null ) continue;
                   
                    var pos = new Position()
                    {
                        ActualQuantity = position.Quantity,
                        NetExposure = position.NetExposure,
                        Security = (Security)security,
                        Portfolio = (Portfolio)Portfolio.Parse(position.StrategyCode),
                        CustodianAccount = position.CustodianAccountCode,
                        LastModifiedOn = holdingData.RefreshTime
                    }.InitPosition();

                    IntradayPositions.Add(pos);
                }

            }
            catch (Exception ex)
            {
                _logger.Error("Pomo: Cant get POMO data " + ex.Message);
            }
           
        }

        public ILookup<string, IPosition> GetData(PositionType pType, PositionIndex pIndex)
        {
            ILookup<string, IPosition> data = null;
            if (pType == PositionType.Sod && pIndex == PositionIndex.Underlying)
            {
                data = SodByUnderlying;
            }
            else if (pType == PositionType.SodDecomposed && pIndex == PositionIndex.Isin)
            {
                data = DecomposedSodByIsin;
            }
            else if (pType == PositionType.SodDecomposed && pIndex == PositionIndex.Underlying)
            {
                data = DecomposedSodByUnderlying;
            }
            else if (pType == PositionType.Intraday && pIndex == PositionIndex.Underlying)
            {
                data = IntradayByUnderlying;
            }
            else if (pType == PositionType.IntradayDecomposed && pIndex == PositionIndex.Isin)
            {
                data = DecomposedIntradayByIsin;
            }
            else if (pType == PositionType.IntradayDecomposed && pIndex == PositionIndex.Underlying)
            {
                data = DecomposedIntradayByUnderlying;
            }
            else if (pType == PositionType.Eod && pIndex == PositionIndex.Underlying)
            {
                data = EodByUnderlying;
            }

            else if (pType == PositionType.EodDecomposed && pIndex == PositionIndex.Isin)
            {
                data = DecomposedEodByIsin;
            }
            else if (pType == PositionType.EodDecomposed && pIndex == PositionIndex.Underlying)
            {
                data = DecomposedEodByUnderlying;
            }

            else
            {
                throw new ArgumentOutOfRangeException(nameof(pType), pType, null);
            }
            return data;
        }

    }
}
