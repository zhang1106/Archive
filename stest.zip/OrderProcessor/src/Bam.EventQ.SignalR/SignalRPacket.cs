﻿using System;
using System.Collections.Generic;

namespace Bam.EventQ.SignalR
{
    public class SignalRPacket<T> 
    {
        public int TotalExpectedPackets { get; set; }
        public int Sequence { get; set; }
        public IEnumerable<T> Data { get; set; }
        public Guid Id { get; set; }
    }
}
