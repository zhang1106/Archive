﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Bam.Oms.Persistence.Utility
{
    /// <summary>
    /// Auxiliary methods to return insert and update queries
    /// </summary>
    internal sealed class DynamicQuery
    {
        /// <summary>
        /// Constructs the insert query.
        /// 
        /// Note that since we have to return the object with the Id value (identity auto-incremented) populated
        /// we are using OUTPUT clause with the INSERT sql statement.
        /// And since, OUTPUT INSERTED.* doesn't work with triggers, we have to use OUTPUT INSERTED.* INTO #SOMETABLE
        /// Hence we are creating a #TEMP_OUTPUT with same structure with TEMP_ID (additional column) to hold the auto-incremented value.
        /// 
        /// Sample Insert query would look like this
        /// IF OBJECT_ID('tempdb..#TEMP_OUTPUT') IS NOT NULL DROP TABLE #TEMP_OUTPUT
        /// SELECT TOP 0 * INTO #TEMP_OUTPUT FROM sourceTable -- Create a table with similar structure
        /// ALTER TABLE #TEMP_OUTPUT ADD TEMP_ID INT NULL -- sourceTableId will be an Identity column, hence add an additional column TEMP_ID
        /// 
        /// INSERT INTO sourceTable(col1, col2)
        /// OUTPUT INSERTED.col1, INSERTED.col2, INSERTED.sourceTableId AS TEMP_ID INTO #TEMP_OUTPUT (col1, col2, TEMP_ID)
        /// VALUES ('value1', 'value2')
        /// 
        /// SELECT col1, col2, TEMP_ID AS sourceTableId FROM #TEMP_OUTPUT
        /// 
        /// </summary>
        /// <param name="tableName">Name of the table.</param>
        /// <param name="idColumnName">Column name of Id column</param>
        /// <param name="item">The item.</param>
        /// <param name="includeOutput">Flag to indicate if Output Inserted section should be included or not</param>
        /// <param name="valuesSqlSection">Provide optional value sql section i.e supplier of data to the insert query</param>
        /// <returns>
        /// The Sql query based on the item properties of the anonymous type.
        /// </returns>
        public static string GetInsertQuery(string tableName, string idColumnName, dynamic item, Func<string, bool> includeColumnPredicate = null,
            bool includeOutput = true, string valuesSqlSection = null)
        {
            includeColumnPredicate = includeColumnPredicate ?? (s => true);

            PropertyInfo[] props = item.GetType().GetProperties();

            string[] columns = props.Select(p => p.Name).Where(s => s != idColumnName && includeColumnPredicate.Invoke(s)).ToArray();
            string[] outputColumns = columns.Select(p => "INSERTED." + p).ToArray();

            string nonIdColumnStr = string.Join(",", columns);

            // Default Values section
            valuesSqlSection = valuesSqlSection ?? $"VALUES (@{string.Join(",@", columns)})";

            string tempOutputTableCreation =
                $@"
            IF OBJECT_ID('tempdb..#TEMP_OUTPUT') IS NOT NULL DROP TABLE #TEMP_OUTPUT
            SELECT TOP 0 * INTO #TEMP_OUTPUT FROM {
                    tableName}
            ALTER TABLE #TEMP_OUTPUT ADD TEMP_ID INT NULL";

            string insertStatement =
                $"INSERT INTO {tableName} ({string.Join(",", columns)}) ";

            string outputSection =
                $"OUTPUT {String.Join(",", outputColumns)},INSERTED.{idColumnName} AS TEMP_ID INTO #TEMP_OUTPUT ({nonIdColumnStr},TEMP_ID)";

            string selectFromOutputSqlSection = $"SELECT {nonIdColumnStr}, TEMP_ID AS {idColumnName} FROM #TEMP_OUTPUT";

            if (includeOutput)
            {
                return
                    $@"
            {tempOutputTableCreation}
            {insertStatement} {outputSection} {
                        valuesSqlSection}
            {selectFromOutputSqlSection}";
            }

            return $"{insertStatement} {valuesSqlSection}";
        }

        public static string GetInsertRangeQuery(string tableName, string idColumnName, dynamic item, Func<string, bool> includeColumnPredicate = null)
        {
            return GetInsertQuery(tableName, idColumnName, item, includeColumnPredicate, false);
        }

        /// <summary>
        /// Gets the update query.
        /// </summary>
        /// <param name="tableName">Name of the table.</param>
        /// <param name="idColumnName">Column name of the Id column</param>
        /// <param name="item">The item.</param>
        /// <returns>
        /// The Sql query based on the item properties of the anonymous type.
        /// </returns>
        public static string GetUpdateQuery(string tableName, string idColumnName, dynamic item, Func<string, bool> includeColumnPredicate = null)
        {
            includeColumnPredicate = includeColumnPredicate ?? (s => true);

            PropertyInfo[] props = item.GetType().GetProperties();
            string[] columns = props.Select(p => p.Name).Where(s => s != idColumnName && includeColumnPredicate.Invoke(s)).ToArray();

            var parameters = columns.Select(name => name + "=@" + name).ToList();

            return string.Format("UPDATE {0} SET {1} WHERE {2}=@{2}", tableName, string.Join(",", parameters), idColumnName);
        }

        /// <summary>
        /// Gets the where query.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns>The where clause of a query from an anonymous type.</returns>
        public static string GetWhereQuery(dynamic item)
        {
            if (item == null)
            {
                return string.Empty;
            }
            string[] columns = null;
            if (item is ExpandoObject)
            {
                IDictionary<string, object> map = (IDictionary<string, object>)item;
                columns = map.Keys.ToArray();
            }
            else
            {
                PropertyInfo[] props = item.GetType().GetProperties();
                columns = props.Select(p => p.Name).ToArray();
            }

            var builder = new StringBuilder();

            for (int i = 0; i < columns.Count(); i++)
            {
                string col = columns[i];
                builder.Append(col);
                builder.Append("=@");
                builder.Append(col);

                if (i < columns.Count() - 1)
                {
                    builder.Append(" AND ");
                }
            }

            return builder.ToString();
        }
    }
}
