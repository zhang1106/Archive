﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public abstract class BaseController : ApiController
    {
        private readonly IPermissionedEntityFilter _entityFilter;

        protected BaseController(IPermissionedEntityFilter entityFilter)
        {
            _entityFilter = entityFilter;
        }

        public ILogger Logger { get; set; }

        protected async Task<List<T>> FilterEntitiesAsync<T>(IEnumerable<T> items, Func<T, string> strategyAccessor)
        {
            var result = await _entityFilter.FilterAsync(items, RequestContext.Principal?.Identity, strategyAccessor);
            return result.ToList();
        }

        protected Task<List<Position>> FilterEntitiesAsync(IEnumerable<Position> items)
        {
            return FilterEntitiesAsync(items, p => p.Portfolio?.ToString());
        }

        protected Task<List<Order>> FilterEntitiesAsync(IEnumerable<Order> items)
        {
            return FilterEntitiesAsync(items, o => o.Portfolio?.ToString());
        }

        protected Task<List<Trade>> FilterEntitiesAsync(IEnumerable<Trade> items)
        {
            return FilterEntitiesAsync(items, t => t.Portfolio?.ToString());
        }

        protected Task<List<SodPosition>> FilterEntitiesAsync(IEnumerable<SodPosition> items)
        {
            return FilterEntitiesAsync(items, p => p.Portfolio?.ToString());
        }

        protected bool SpinUntil(Func<bool> predicate, TimeSpan timeout)
        {
            var start = DateTime.UtcNow;
            while (start + timeout > DateTime.UtcNow && !predicate())
            {
                Thread.Sleep(25);
            }

            return start + timeout <= DateTime.UtcNow;
        }
    }
}
