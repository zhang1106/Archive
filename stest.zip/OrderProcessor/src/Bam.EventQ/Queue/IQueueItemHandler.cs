﻿namespace Bam.EventQ.Queue
{
    public interface IQueueItemHandler<in TItem>
    {
        void Handle(TItem item, long sequence, bool endOfBatch);
    }
}
