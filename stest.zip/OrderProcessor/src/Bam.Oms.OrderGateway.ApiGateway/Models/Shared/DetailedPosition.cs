﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Lookup;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
  public class DetailedPosition : ModelBase<object>, ICloneable
    {
        private readonly Dictionary<PositionAllocationKey, PositionAllocation> _actualAllocations =
            new Dictionary<PositionAllocationKey, PositionAllocation>();
        private readonly Dictionary<PositionAllocationKey, PositionAllocation> _theoreticalAllocations =
            new Dictionary<PositionAllocationKey, PositionAllocation>();

        public long PositionId { get; set; }
        public string Portfolio { get; set; }
        public string BamSymbol { get; set; }
        public long ActualQuantity => _actualAllocations.Values.Sum(a => a.Quantity);
        public long TheoreticalQuantity => _theoreticalAllocations.Values.Sum(a => a.Quantity);
        public long ShortMarkingQuantity { get; set; }
        public long LongMarkingQuantity { get; set; }
        public DateTime LastUpdated { get; set; }

        public IReadOnlyList<PositionAllocation> ActualAllocations => 
            _actualAllocations.Values.ToList();

        public IReadOnlyList<PositionAllocation> TheoreticalAllocations =>
            _theoreticalAllocations.Values.ToList();
        
        public void SetActualAllocation(PositionAllocationKey key, long quantity)
        {
            PositionAllocation alloc;
            if (!_actualAllocations.TryGetValue(key, out alloc))
            {
                alloc = _actualAllocations[key] = new PositionAllocation(key);
            }

            alloc.Quantity = quantity;
        }

        public void SetTheoreticalAllocation(PositionAllocationKey key, long quantity) 
        {
            PositionAllocation alloc;
            if (!_theoreticalAllocations.TryGetValue(key, out alloc))
            {
                alloc = _theoreticalAllocations[key] = new PositionAllocation(key);
            }

            alloc.Quantity = quantity;
        }

        public PositionAllocation GetActualAllocation(PositionAllocationKey key)
        {
            PositionAllocation a;
            _actualAllocations.TryGetValue(key, out a);
            return a;
        }

        public PositionAllocation GetTheoreticalAllocation(PositionAllocationKey key) 
        {
            PositionAllocation a;
            _theoreticalAllocations.TryGetValue(key, out a);
            return a;
        }

        public virtual object Clone()
        {
            var c = new DetailedPosition
            {
                Portfolio = Portfolio,
                PositionId = PositionId,
                BamSymbol = BamSymbol,
                LongMarkingQuantity = LongMarkingQuantity,
                ShortMarkingQuantity = ShortMarkingQuantity,
                LastUpdated = LastUpdated,
            };

            foreach (var kvp in _actualAllocations)
            {
                c._actualAllocations.Add(kvp.Key, new PositionAllocation(kvp.Key)
                {
                    Quantity = kvp.Value.Quantity
                });
            }

            foreach (var kvp in _theoreticalAllocations)
            {
                c._theoreticalAllocations.Add(kvp.Key, new PositionAllocation(kvp.Key) 
                {
                    Quantity = kvp.Value.Quantity
                });
            }

            return c;
        }

        public void ClearTheoreticalAllocations()
        {
            foreach (var key in _theoreticalAllocations.Keys.ToList())
            {
                _theoreticalAllocations[key].Quantity = 0;
            }
        }

        public void ClearActualAllocations()
        {
            foreach (var key in _actualAllocations.Keys.ToList())
            {
                _actualAllocations[key].Quantity = 0;
            }
        }
    }
}
