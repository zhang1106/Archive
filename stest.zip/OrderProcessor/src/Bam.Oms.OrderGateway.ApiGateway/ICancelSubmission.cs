﻿namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface ICancelSubmission
    {
        void Cancel(long[] orderIds, string user);
        void Rollback(long[] orderIds, string user);
    }
}