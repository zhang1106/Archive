using System;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Tests
{
    class SodPositionTestDataProvider
    {
        private static readonly DateTime Now = DateTime.Now;
        private static readonly DateTime Yesterday = Now.AddDays(-1);

        internal static readonly IList<Position> SodPositionUpdates = new List<Position>()
        {
            new Position
            {
                PositionId = 1,
                Security = new Security {BamSymbol = "IBM", Currency = "INR", SecurityType = SecurityType.Equity},
                AuditSequence = 0,
                LastModifiedOn = new DateTime(2015, 12, 11, 1, 10, 0, 0, DateTimeKind.Utc),

            },
            new Position
            {
                PositionId = 1,
                Security = new Security {BamSymbol = "MSFT", Currency = "INR", SecurityType = SecurityType.Equity},
                AuditSequence = 3,
                LastModifiedOn = new DateTime(2015, 12, 11, 11, 10, 0, 0, DateTimeKind.Utc),
                
            },
            new Position
            {
                PositionId = 2,
                Security = new Security {BamSymbol = "GOOG", Currency = "PKR", SecurityType = SecurityType.EquityOption},
                AuditSequence = 5,
                LastModifiedOn = new DateTime(2015, 12, 11, 15, 10, 0, 0, DateTimeKind.Utc),
            }
        };

        internal static readonly IList<Position> SodPositions = new List<Position>()
        {
            new Position
            {
                PositionId = 1,
                Security = new Security {BamSymbol = "MSFT", Currency = "INR", SecurityType = SecurityType.Equity},
                Price = 75.45M,
                EntryDate = DateTime.Now.Date,
                CustodianAccountCode = "GOLDMAN_ACC",
                CustodianName = "GOLDMAN",
                FXRate = 65.5M,
                ActualQuantity = 200.54M,
                Portfolio = (Portfolio) Portfolio.Parse("QIAN-GENERALIST"),
                Stream = "US-EU",
                FundCode = "Fund1",
                CreatedOn = DateTime.Now,
                ActionLogId = 25,
                AuditSequence = 3,
                LastModifiedOn = Now,
                LastModifiedBy = "test",
                TheoreticalQuantity = 200.54M
            },
            new Position
            {
                PositionId = 2,
                Security = new Security {BamSymbol = "GOOG", Currency = "PKR", SecurityType = SecurityType.EquityOption},
                Price = 7115.45M,
                EntryDate = Now.Date,
                CustodianAccountCode = "BARCLAYS_ACC",
                CustodianName = "BARCLAYS",
                FXRate = 104.75M,
                ActualQuantity = -201.54M,
                Portfolio = (Portfolio) Portfolio.Parse("Darth-Vader"),
                Stream = "US-EU",
                FundCode = "Fund2",
                CreatedOn = Now,
                ActionLogId = 35,
                AuditSequence = 5,
                LastModifiedOn = Now,
                LastModifiedBy = "test",
                TheoreticalQuantity = -201.54M
            }
        };

        internal static readonly IList<dynamic> DbPositions = new List<dynamic>()
        {
            new
            {
                PositionId = 1,
                BAMSymbol = "MSFT",
                Ccy = "INR",
                CreatedOn = Yesterday,
                ActionLogId = 25,
                AuditSequence = 3,
                CustodianAccountCode = "GOLDMAN_ACC",
                CustodianName = "GOLDMAN",
                EntryDate = Yesterday.Date,
                FundCode = "Fund1",
                FXRate = 65.5M,
                AssetType = "Equity",
                Price = 75.45M,
                Qty = 200.54M,
                StrategyCode = "QIAN-GENERALIST",
                Stream = "US-EU",
                LastModifiedBy = "test",
                LastModifiedOn = Now
            },
            new
            {
                PositionId = 2,
                BAMSymbol = "GOOG",
                Ccy = "PKR",
                CreatedOn = Now,
                ActionLogId = 35,
                AuditSequence = 5,
                CustodianAccountCode = "BARCLAYS_ACC",
                CustodianName = "BARCLAYS",
                EntryDate = Now.Date,
                FundCode = "Fund2",
                FXRate = 104.75M,
                AssetType = "EquityOption",
                Price = 7115.45M,
                Qty = -201.54M,
                StrategyCode = "Darth-Vader",
                Stream = "US-EU",
                LastModifiedBy = "test",
                LastModifiedOn = Now
            }
        };
    }
}
