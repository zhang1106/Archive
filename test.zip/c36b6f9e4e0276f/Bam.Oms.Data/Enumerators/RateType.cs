﻿namespace Bam.Oms.Data.Enumerators
{
    public enum RateType
    {
        [Enum(StringValue = "Unknown")]
        Unknown = -1,

        [Enum(StringValue = "Rebate")]
        Rebate = 0,

        [Enum(StringValue = "Fee")]
        Fee = 1
    }
}
