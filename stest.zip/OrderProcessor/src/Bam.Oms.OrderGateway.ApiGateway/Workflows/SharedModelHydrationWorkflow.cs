using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Time;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.ApiGateway.Services;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using Bam.Oms.OrderGateway.Messages.Compliance;
using Bam.Oms.OrderGateway.Messages.EmsGateway;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;
using Bam.Oms.OrderGateway.Messages.RefDataGateway;
using OrderExecutionDetailsChanged = Bam.Oms.OrderGateway.Messages.OrderProcessor.OrderExecutionDetailsChanged;
using OrderStatusChanged = Bam.Oms.OrderGateway.Messages.OrderProcessor.OrderStatusChanged;
using Portfolio = Bam.Oms.OrderGateway.ApiGateway.Models.Shared.Portfolio;

namespace Bam.Oms.OrderGateway.ApiGateway.Workflows
{
    public class SharedModelHydrationWorkflow : Workflow<object>,
        IWorkflow<OrdersCreated, object>,
        IWorkflow<OrderStatusChanged, object>,
        IWorkflow<OrderSideChanged, object>,
        IWorkflow<OrderQuantityChanged, object>,
        IWorkflow<OrderAllocationChanged, object>,
        IWorkflow<OrderExecutionDetailsChanged, object>,
        IWorkflow<OrderStatusMessageChanged, object>,
        IWorkflow<OrderLocateStatusChanged, object>,
        IWorkflow<OrdersRouted, object>,
        IWorkflow<PositionCreated, object>,
        IWorkflow<TheoreticalPositionUpdated, object>,
        IWorkflow<ActualPositionUpdated, object>,
        IWorkflow<SodPositionLoaded, object>,
        IWorkflow<AggUnitPositionCreated, object>,
        IWorkflow<ComplianceGroupPositionCreated, object>,
        IWorkflow<LongMarkingPositionUpdated, object>,
        IWorkflow<ShortMarkingPositionUpdated, object>,
        IWorkflow<OrderLocateDetailsChanged, object>,
        IWorkflow<SecurityUpdates, object>,
        IWorkflow<TargetAllocationChanged, object>,
        IWorkflow<OrderNotesChanged, object>,
        IWorkflow<FinalPositionChanged, object>,
        IWorkflow<NewOrderScalingRule, object>,
        IWorkflow<TraderIdChanged, object>,
        IWorkflow<SecurityCreated, object>,
        IWorkflow<ExternalOrderIdChanged, object>,
        IWorkflow<LimitPriceChanged, object>,
        IWorkflow<OrderModified, object>,
        IWorkflow<EmsDestinationChanged, object>,
        IWorkflow<ComplianceViolationChanged, object>,
        IWorkflow<ComplianceOverrideMessageChanged, object>,
        IWorkflow<OwnershipHeadroomChanged, object>,
        IWorkflow<OwnershipIntradayQuantityChanged, object>,
        IWorkflow<OwnershipHeadroomRatiosAdjusted, object>,
        IWorkflow<OwnershipHeadroomRemoved, object>
    {
        private readonly ICache<string, Security> _securityUpdateCache;
        private readonly FrozenClock _clock;
        private readonly IReferenceDataService _referenceData;
        private readonly ICache<string, Security> _newSecurityCache;
        private readonly ISecurityCache _internalSecurityCache;
        private readonly IVersionGenerator _versionGenerator;
        private readonly ITradeStatusService _tradeStatusService;
        private readonly IModelIndex<Order> _orders;
        private readonly IModelIndex<Position> _positions;
        private readonly IModelIndex<DetailedPosition> _detailedPositions;
        private readonly IModelIndex<Trade> _trades;
        private readonly IModelIndex<SodPosition> _sodPositions;
        private readonly IModelIndex<AggUnitPosition> _aggUnitPositions;
        private readonly IModelIndex<ComplianceGroupPosition> _complianceGroupPositions;
        private readonly IModelIndex<OwnershipHeadroom> _ownershipHeadroom;

        public SharedModelHydrationWorkflow(
            IIndexFactory index,
            ICache<string, Security> securityUpdateCache,
            IClock clock, IReferenceDataService referenceData,
            ICache<string, Security> newSecurityCache,
            ISecurityCache internalSecurityCache,
            IVersionGenerator versionGenerator,
            ITradeStatusService tradeStatusService)
        {
            _securityUpdateCache = securityUpdateCache;
            _clock = (FrozenClock) clock;
            _referenceData = referenceData;
            _newSecurityCache = newSecurityCache;
            _internalSecurityCache = internalSecurityCache;
            _versionGenerator = versionGenerator;
            _tradeStatusService = tradeStatusService;
            _orders = index.For<Order>();
            _positions = index.For<Position>();
            _trades = index.For<Trade>();
            _sodPositions = index.For<SodPosition>();
            _aggUnitPositions = index.For<AggUnitPosition>();
            _complianceGroupPositions = index.For<ComplianceGroupPosition>();
            _detailedPositions = index.For<DetailedPosition>();
            _ownershipHeadroom = index.For<OwnershipHeadroom>();
        }

        #region Security

        public void Execute(SecurityCreated input)
        {
            using (_securityUpdateCache.AcquireWriteAccess())
            {
                _newSecurityCache.Update(input.BamSymbol,
                    new Security
                    {
                        Created = _clock.Now,
                        BamSymbol = input.BamSymbol,
                        BloombergSymbol = input.BloombergSymbol,
                        Currency = input.Currency,
                        Cusip = input.Cusip,
                        Isin = input.Isin,
                        Issuer = input.Issuer,
                        Ticker = input.Ticker,
                        Sedol = input.Sedol,
                        SecurityType = (SecurityType) Enum.Parse(typeof(SecurityType), input.SecurityType.Replace(" ", ""))
                    });
            }
        }

        public void Execute(SecurityUpdates updates)
        {
            _internalSecurityCache.AddSecurityUpdates(updates);
            foreach (var item in updates.Items)
            {
                var ordersForSecurity = _orders.MultiLookupBy("Security.BamSymbol", item.BamSymbol);

                CachedSecurity security;
                _internalSecurityCache.TryGetSecurity(item.BamSymbol, out security);

                foreach (var order in ordersForSecurity)
                {
                    UpdateOrder(order.ClientOrderId, o =>
                    {
                        o.Security.Apply(security);
                        o.TradeCurrency = o.TradeCurrency ?? item.Currency;
                    }, updates.Header.Timestamp);

                    UpdateTrade(order.ClientOrderId, t =>
                    {
                        t.Security.Apply(security);
                    }, updates.Header.Timestamp);
                }

                var positions = _positions.MultiLookupBy("Security.BamSymbol", item.BamSymbol);
                foreach (var position in positions)
                {
                    position.Security.Apply(security);
                    position.Version = _versionGenerator.NextPositionVersion(position.PositionId);
                    Publish(position.Clone());
                }

                var sod = _sodPositions.MultiLookupBy("Security.BamSymbol", item.BamSymbol);
                foreach (var position in sod)
                {
                    position.Security.Apply(security);
                    Publish(position.Clone());
                }
            }
        }

        #endregion

        #region Order

        public void Execute(OrdersCreated input)
        {
            var missingSymbols = new HashSet<string>();

            foreach (var item in input.Items)
            {
                string traderLogin;

                Portfolio portfolio;
                PortfolioDetails details;
                if (_referenceData.TryGetPortfolioDetails(Infrastructure.Portfolio.Parse(item.Portfolio), out details))
                {
                    portfolio = new Portfolio
                    {
                        Strategy = details.Portfolio.Strategy,
                        PMCode = details.Portfolio.PMCode,
                        SubStrategy = details.Portfolio.SubStrategy,
                        ComplianceGroup = details.ComplianceGroup,
                        AggregationUnit = details.AggregationUnit,
                    };
                }
                else
                {
                    portfolio = Portfolio.Parse(item.Portfolio);
                }

                Security sec;
                if (!TryGetSecurityFromCache(item.Symbol, item.SecurityType, out sec))
                    missingSymbols.Add(item.Symbol);

                var order = new Order
                {
                    SubmissionId = item.SubmissionId,
                    OrderTimeStamp = item.Created,
                    LastModified = item.Created,
                    BatchId = item.BatchName,
                    Side = item.Side.ToSideType(),
                    Size = item.Quantity,
                    ClientOrderId = Convert.ToString(item.OrderId),
                    OrderStatus = item.Status,
                    TradeDate = item.BusinessDay,
                    TraderId = item.TraderId,
                    Custodian = "UNKNOWN",
                    TraderLogin = _referenceData.TryGetTraderLogin(item.TraderId, out traderLogin) ? traderLogin : "UND",
                    LastUpdated = item.Created,
                    Portfolio = portfolio,
                    Urgency = (OrderUrgency) Enum.Parse(typeof(OrderUrgency), item.Urgency.ToString()),
                    Price = item.LimitPrice,
                    ExecutionInstructions = item.ExecutionInstructions.Select(kvp =>
                            new ExecutionInstruction {Code = kvp.Key, Value = kvp.Value})
                        .ToList(),
                    CreatedUser = item.CreatedUser,
                    ModifiedUser = item.CreatedUser,
                    OriginalOrderId = item.OriginalOrderId != null ? Convert.ToString(item.OriginalOrderId) : null,
                    Security = sec,
                    OrderSetId = item.OrderSetId,
                    IsComplete = item.Status == OrderStatus.Error,
                    ExternalId = item.ExternalId,
                    Version = _versionGenerator.NextOrderVersion(Convert.ToString(item.OrderId))
                };

                _orders.Insert(order);
                Publish(order.Clone());
            }
        }

        private bool TryGetSecurityFromCache(string symbol, string securityType, out Security sec)
        {
            CachedSecurity securityUpdatesItem;
            if (!_internalSecurityCache.TryGetSecurity(symbol, out securityUpdatesItem))
            {
                sec = new Security
                {
                    BamSymbol = symbol,
                    Ticker = symbol,
                    SecurityType = securityType == null
                        ? SecurityType.Unknown
                        : (SecurityType) Enum.Parse(typeof(SecurityType), securityType)
                };
                return false;
            }

            sec = new Security {Created = _clock.Now};
            sec.Apply(securityUpdatesItem);
            return true;
        }

        public void Execute(OrderModified input)
        {
            UpdateOrder(input.OrderId, order =>
            {
                order.ModifiedUser = input.ModifiedBy;
                order.LastModified = input.ModifiedAt;
            }, input.Header.Timestamp);
        }

        public void Execute(OrderStatusChanged input)
        {
            foreach (var item in input.Items)
            {
                UpdateOrder(item.OrderId, order =>
                {
                    if (item.Status == OrderStatus.Finalized)
                        FinalizeTrades(order.ClientOrderId, true, input.Header.Timestamp);
                    else if (order.OrderStatus == OrderStatus.Finalized && item.Status != OrderStatus.Finalized && item.Status != OrderStatus.Deleted)
                        FinalizeTrades(order.ClientOrderId, false, input.Header.Timestamp);

                    order.OrderStatus = item.Status;
                }, input.Header.Timestamp);
            }
        }

        public void Execute(OrderSideChanged input)
        {
            UpdateOrder(input.OrderId, order =>
            {
                order.Side = input.Side.ToSideType();
            }, input.Header.Timestamp);
        }

        public void Execute(OrderQuantityChanged input)
        {
            UpdateOrder(input.OrderId, order =>
            {
                order.Size = input.Quantity;
            }, input.Header.Timestamp);
        }

        public void Execute(TargetAllocationChanged input)
        {
            foreach (var item in input.Items)
            {
                UpdateOrder(item.OrderId, order =>
                {
                    order.Size = item.Allocations.Sum(a => a.Quantity);
                    var custodianIds = item.Allocations.Select(a => a.CustodianId).Distinct().ToList();

                    if (custodianIds.Count == 1)
                    {
                        string custodian;
                        if (!_referenceData.TryGetBroker(custodianIds[0], out custodian))
                        {
                            custodian = "UNKNOWN";
                        }

                        order.Custodian = custodian;
                    }
                    else if (item.Allocations.Count > 1)
                    {
                        order.Custodian = "Multiple";
                    }
                    else
                    {
                        order.Custodian = "UNKNOWN";
                    }

                    order.TargetAllocation.Clear();
                    foreach (var alloc in item.Allocations)
                    {
                        string fund;
                        if (!_referenceData.TryGetFund(alloc.FundId, out fund))
                        {
                            fund = "UNKNOWN";
                        }

                        string custodian;
                        if (!_referenceData.TryGetBroker(alloc.CustodianId, out custodian))
                        {
                            custodian = "UNKNOWN";
                        }

                        PortfolioDetails details;
                        var portfolio = Infrastructure.Portfolio.Parse(alloc.Portfolio);
                        if (!_referenceData.TryGetPortfolioDetails(portfolio, out details))
                        {
                            details = null;
                        }

                        order.TargetAllocation.Add(new OrderAllocation
                        {
                            Fund = fund,
                            Custodian = custodian,
                            Portfolio = new Portfolio
                            {
                                PMCode = portfolio.PMCode,
                                Strategy = portfolio.Strategy,
                                SubStrategy = portfolio.SubStrategy,
                                AggregationUnit = details?.AggregationUnit,
                                ComplianceGroup = details?.ComplianceGroup
                            },
                            Quantity = alloc.Quantity
                        });
                    }
                }, input.Header.Timestamp);
            }
        }

        public void Execute(OrderExecutionDetailsChanged input)
        {
            UpdateOrder(input.OrderId, order =>
            {
                order.TradeCurrency = input.TradingCurrency;
                order.SettleDate = input.SettlementDate ?? DateTime.MinValue;
                order.SettlementCurrency = input.SettlementCurrency;
            }, input.Header.Timestamp);

            UpdateTrade(input.OrderId.ToString(), trade =>
            {
                trade.TradeCurrency = input.TradingCurrency;
            }, input.Header.Timestamp);
        }

        public void Execute(OrderStatusMessageChanged input)
        {
            UpdateOrder(input.OrderId, order =>
            {
                if (input.Remove)
                {
                    order.StatusMessages.Remove(input.Message);
                }
                else if (!order.StatusMessages.Contains(input.Message))
                {
                    order.StatusMessages.Add(input.Message);
                }
            }, input.Header.Timestamp);
        }

        public void Execute(OrderNotesChanged input)
        {
            UpdateOrder(input.OrderId, o => o.Note = input.Notes, input.Header.Timestamp);
        }

        public void Execute(OrderLocateStatusChanged input)
        {
            foreach (var item in input.Items)
            {
                UpdateOrder(item.OrderId, o => o.LocateStatus = item.Status, input.Header.Timestamp);
            }
        }

        public void Execute(OrdersRouted input)
        {
            foreach (var item in input.Items)
            {
                UpdateOrder(item.OrderId, o => o.RoutedSize = item.RoutedQuantity, input.Header.Timestamp);
            }
        }

        public void Execute(OrderLocateDetailsChanged input)
        {
            foreach (var item in input.Items)
            {
                UpdateOrder(item.OrderId, o =>
                {
                    var existing = o.Locate.FirstOrDefault(l => l.LocateId == item.LocateId);
                    if (existing == null)
                    {
                        o.Locate.Add(existing = new Locate
                        {
                            LocateId = item.LocateId
                        });
                    }

                    string broker;
                    if (!_referenceData.TryGetBroker(item.BrokerId, out broker))
                    {
                        broker = "UNKNOWN";
                    }

                    existing.Size = item.Quantity;
                    existing.AssignmentId = item.AssignmentId;
                    existing.PrimeBroker = broker;
                    existing.Rate = item.Rate;
                    existing.TimeReceived = item.ApprovalTime;
                    existing.RateType = item.RateType == null
                        ? null
                        : item.RateType == "R"
                            ? (RateType?) RateType.Rebate
                            : item.RateType == "F"
                                ? RateType.Fee
                                : RateType.Unknown;
                }, input.Header.Timestamp);
            }
        }

        public void Execute(TraderIdChanged input)
        {
            foreach (var item in input.Items)
            {
                UpdateOrder(item.OrderId, o =>
                {
                    string login;
                    if (!_referenceData.TryGetTraderLogin(item.TraderId, out login))
                        login = "UND";

                    o.TraderLogin = login;
                    o.TraderId = item.TraderId;
                }, input.Header.Timestamp);
            }
        }

        public void Execute(ExternalOrderIdChanged input)
        {
            UpdateOrder(input.OrderId, o =>
            {
                o.ExternalId = input.ExternalId;
            }, input.Header.Timestamp);
        }

        public void Execute(LimitPriceChanged input)
        {
            UpdateOrder(input.OrderId, o =>
            {
                o.Price = input.LimitPrice;
            }, input.Header.Timestamp);
        }

        public void Execute(ComplianceViolationChanged input)
        {
            UpdateOrder(input.OrderId, order =>
            {
                order.ComplianceFailures.Clear();
                order.MaxComplianceErrorLevel = input.MaxComplianceViolationLevel != null
                    ? input.MaxComplianceViolationLevel.ToString()
                    : null;

                foreach (var violation in input.Items)
                {
                    var message = $"{violation.RuleName} : {violation.Description}";

                    if (!order.StatusMessages.Contains(message))
                        order.StatusMessages.Add(message);

                    order.ComplianceFailures.Add(new ComplianceIssue()
                    {
                        RuleName = violation.RuleName,
                        Description = violation.Description,
                        IsOverridden = violation.IsSuppressed,
                        Level = violation.ComplianceViolationLevel.ToString(),
                    });
                }
            }, input.Header.Timestamp);
        }

        public void Execute(ComplianceOverrideMessageChanged input)
        {
            UpdateOrder(input.OrderId, order =>
            {
                order.ComplianceOverrideMessage = input.Message;
            }, input.Header.Timestamp);
        }

        private void UpdateOrder(long id, Action<Order> action, int timestamp)
        {
            UpdateOrder(Convert.ToString(id), action, timestamp);
        }

        private void UpdateOrder(string id, Action<Order> action, int timestamp)
        {
            var order = _orders.LookupBy(nameof(Order.Key), id);
            UpdateOrder(order, action, timestamp);
        }

        private void UpdateOrder(Order order, Action<Order> action, int timestamp)
        {
            if (order != null)
            {
                action(order);
                _clock.SetTimestamp(timestamp);
                order.LastUpdated = _clock.Now;
                order.Version = _versionGenerator.NextOrderVersion(order.ClientOrderId);
                Publish(order.Clone());
            }
        }

        #endregion

        #region Positions

        public void Execute(PositionCreated input)
        {
            var missingSymbols = new HashSet<string>();

            foreach (var p in input.Items)
            {
                Portfolio portfolio;
                PortfolioDetails details;
                if (_referenceData.TryGetPortfolioDetails(Infrastructure.Portfolio.Parse(p.Portfolio), out details))
                {
                    portfolio = new Portfolio
                    {
                        Strategy = details.Portfolio.Strategy,
                        PMCode = details.Portfolio.PMCode,
                        SubStrategy = details.Portfolio.SubStrategy,
                        ComplianceGroup = details.ComplianceGroup,
                        AggregationUnit = details.AggregationUnit
                    };
                }
                else
                {
                    portfolio = Portfolio.Parse(p.Portfolio);
                }


                Security sec;
                if (!TryGetSecurityFromCache(p.Symbol, "Unknown", out sec))
                    missingSymbols.Add(p.Symbol);

                var position = new Position
                {
                    PositionId = p.PositionId,
                    Portfolio = portfolio,
                    Security = sec,
                    ActualQuantity = p.ActualQuantity,
                    TheoreticalQuantity = p.TheoreticalQuantity,
                    EntryDate = _clock.Now,
                    LastUpdated = _clock.Now
                };

                var detailedPosition = new DetailedPosition
                {
                    PositionId = p.PositionId,
                    Portfolio = p.Portfolio,
                    LongMarkingQuantity = p.LongMarkingQuantity,
                    ShortMarkingQuantity = p.ShortMarkingQuantity,
                    BamSymbol = p.Symbol,
                    LastUpdated = _clock.Now,
                };

                position.CustodianName = Position.NotAvailable;
                position.FundCode = Position.NotAvailable;

                foreach (var alloc in p.ActualAllocations)
                {
                    string fund, custodian;
                    if (!_referenceData.TryGetFund(alloc.FundId, out fund))
                    {
                        Logger?.LogWarning($"Received position '{position.PositionId}' with allocation for unknown fund {alloc.FundId}");
                        continue;
                    }

                    if (!_referenceData.TryGetBroker(alloc.CustodianId, out custodian))
                    {
                        Logger?.LogWarning($"Received position '{position.PositionId}' with allocation for unknown custodian {alloc.CustodianId}");
                        continue;
                    }

                    if (position.CustodianName == Position.NotAvailable)
                    {
                        position.CustodianName = custodian;
                    }
                    else if (position.CustodianName != custodian)
                    {
                        position.CustodianName = Position.Multiple;
                    }

                    if (position.FundCode == Position.NotAvailable)
                    {
                        position.FundCode = fund;
                    }
                    else if (position.FundCode != fund)
                    {
                        position.FundCode = Position.Multiple;
                    }

                    detailedPosition.SetActualAllocation(
                        new PositionAllocationKey(fund, custodian), alloc.Quantity);
                }

                foreach (var alloc in p.TheoreticalAllocations)
                {
                    string custodian;
                    if (!_referenceData.TryGetBroker(alloc.CustodianId, out custodian))
                    {
                        Logger?.LogWarning($"Received position '{position.PositionId}' with allocation for unknown custodian {alloc.CustodianId}");
                        continue;
                    }

                    string fund;
                    if (!_referenceData.TryGetFund(alloc.FundId, out fund))
                    {
                        Logger?.LogWarning($"Received position '{position.PositionId}' with allocation for unknown fund {alloc.CustodianId}");
                        continue;
                    }

                    detailedPosition.SetTheoreticalAllocation(
                        new PositionAllocationKey(fund, custodian), alloc.Quantity);
                }

                _positions.Insert(position);
                _detailedPositions.Insert(detailedPosition);
                Publish(position.Clone());
                Publish(detailedPosition.Clone());
            }

            if (missingSymbols.Count > 0)
            {
                var msg = new EnrichSecurities();
                foreach (var symbol in missingSymbols)
                    msg.Items.Add(symbol);
                Publish(msg);
            }
        }

        public void Execute(ComplianceGroupPositionCreated input)
        {
            foreach (var p in input.Items)
            {
                var position = new ComplianceGroupPosition
                {
                    PositionId = p.PositionId,
                    BamSymbol = p.Symbol,
                    ComplianceGroup = p.ComplianceGroup,
                    ShortMarkingQuantity = p.ShortMarkingQuantity,
                    LongMarkingQuantity = p.LongMarkingQuantity
                };
                _complianceGroupPositions.Insert(position);
                Publish(position.Clone());
            }
        }

        public void Execute(AggUnitPositionCreated input)
        {
            foreach (var p in input.Items)
            {
                var position = new AggUnitPosition
                {
                    PositionId = p.PositionId,
                    BamSymbol = p.Symbol,
                    AggregationUnit = p.AggregationUnit,
                    ShortMarkingQuantity = p.ShortMarkingQuantity
                };
                _aggUnitPositions.Insert(position);
                Publish(position.Clone());
            }
        }

        public void Execute(ShortMarkingPositionUpdated input)
        {
            foreach (var item in input.Items)
            {
                UpdatePosition(item.PositionId,
                    p => { },
                    dp => dp.ShortMarkingQuantity = item.Quantity,
                    cgp => cgp.ShortMarkingQuantity = item.Quantity,
                    aup => aup.ShortMarkingQuantity = item.Quantity);
            }
        }

        public void Execute(LongMarkingPositionUpdated input)
        {
            foreach (var item in input.Items)
            {
                UpdatePosition(item.PositionId,
                    p => { },
                    dp => dp.LongMarkingQuantity = item.Quantity,
                    cgp => cgp.LongMarkingQuantity = item.Quantity,
                    aup => { });
            }
        }

        public void Execute(TheoreticalPositionUpdated input)
        {
            foreach (var item in input.Items)
            {
                UpdatePosition(item.PositionId,
                    p =>
                    {
                        p.TheoreticalQuantity = 0;
                        foreach (var alloc in item.Allocations)
                        {
                            p.TheoreticalQuantity += alloc.Quantity;
                        }
                    },
                    dp =>
                    {
                        dp.ClearTheoreticalAllocations();
                        foreach (var alloc in item.Allocations)
                        {
                            string custodian;
                            if (!_referenceData.TryGetBroker(alloc.CustodianId, out custodian))
                            {
                                Logger?.LogWarning($"Received position '{item.PositionId}' with allocation for unknown custodian {alloc.CustodianId}");
                                continue;
                            }

                            string fund;
                            if (!_referenceData.TryGetFund(alloc.FundId, out fund))
                            {
                                Logger?.LogWarning($"Received position '{item.PositionId}' with allocation for unknown fund {alloc.CustodianId}");
                                continue;
                            }

                            dp.SetTheoreticalAllocation(new PositionAllocationKey(fund, custodian), alloc.Quantity);
                        }
                    },
                    cgp => { },
                    aup => { });
            }
        }

        public void Execute(ActualPositionUpdated input)
        {
            var funds = new HashSet<int>();
            var custodians = new HashSet<int>();

            foreach (var item in input.Items)
            {
                UpdatePosition(item.PositionId,
                    p =>
                    {
                        p.ActualQuantity = 0;
                        funds.Clear();
                        custodians.Clear();
                        foreach (var alloc in item.Allocations)
                        {
                            if (alloc.Quantity != 0)
                            {
                                funds.Add(alloc.FundId);
                                custodians.Add(alloc.CustodianId);
                            }
                            p.ActualQuantity += alloc.Quantity;
                        }

                        if (funds.Count == 1)
                        {
                            string fund;
                            if (!_referenceData.TryGetFund(item.Allocations[0].FundId, out fund))
                            {
                                Logger?.LogWarning(
                                    $"Received position '{item.PositionId}' with allocation for unknown fund {item.Allocations[0].FundId}");
                            }
                            else
                            {
                                p.FundCode = fund;
                            }
                        }
                        else if (funds.Count == 0)
                        {
                            p.FundCode = p.FundCode ?? Position.NotAvailable;
                        }
                        else
                        {
                            p.FundCode = Position.Multiple;
                        }

                        if (custodians.Count == 1)
                        {
                            string custodian;
                            if (!_referenceData.TryGetBroker(item.Allocations[0].CustodianId, out custodian))
                            {
                                Logger?.LogWarning(
                                    $"Received position '{item.PositionId}' with allocation for unknown custodian {item.Allocations[0].CustodianId}");
                            }
                            else
                            {
                                p.CustodianName = custodian;
                            }
                        }
                        else if (custodians.Count == 0)
                        {
                            p.CustodianName = p.CustodianName ?? Position.NotAvailable;
                        }
                        else
                        {
                            p.CustodianName = Position.Multiple;
                        }
                    },
                    dp =>
                    {
                        dp.ClearActualAllocations();
                        foreach (var alloc in item.Allocations)
                        {
                            string fund, custodian;
                            if (!_referenceData.TryGetFund(alloc.FundId, out fund))
                            {
                                Logger?.LogWarning($"Received position '{item.PositionId}' with allocation for unknown fund {alloc.FundId}");
                                continue;
                            }

                            if (!_referenceData.TryGetBroker(alloc.CustodianId, out custodian))
                            {
                                Logger?.LogWarning($"Received position '{item.PositionId}' with allocation for unknown custodian {alloc.CustodianId}");
                                continue;
                            }

                            dp.SetActualAllocation(new PositionAllocationKey(fund, custodian), alloc.Quantity);
                        }
                    },
                    cgp => { },
                    aup => { });
            }
        }

        private void UpdatePosition(long positionId,
            Action<Position> positionAction,
            Action<DetailedPosition> detailedPositionAction,
            Action<ComplianceGroupPosition> compGroupPostionAction,
            Action<AggUnitPosition> aggUnitPositionAction)
        {
            var position = _positions.LookupBy(
                nameof(Position.PositionId), positionId);
            if (position != null)
            {
                positionAction(position);
                position.Version = _versionGenerator.NextPositionVersion(position.PositionId);
                Publish((Position) position.Clone());

                var detailedPosition = _detailedPositions.LookupBy(
                    nameof(DetailedPosition.PositionId), positionId);
                if (detailedPosition != null)
                {
                    detailedPositionAction(detailedPosition);
                    Publish((DetailedPosition) detailedPosition.Clone());
                }
            }
            else
            {
                var compPosition = _complianceGroupPositions.LookupBy(
                    nameof(ComplianceGroupPosition.PositionId), positionId);
                if (compPosition != null)
                {
                    compGroupPostionAction(compPosition);
                    Publish((ComplianceGroupPosition) compPosition.Clone());
                }
                else
                {
                    var aggUnitPosition = _aggUnitPositions.LookupBy(
                        nameof(AggUnitPosition.PositionId), positionId);
                    if (aggUnitPosition != null)
                    {
                        aggUnitPositionAction(aggUnitPosition);
                        Publish((AggUnitPosition) aggUnitPosition.Clone());
                    }
                }
            }
        }

        #endregion

        #region SOD Positions

        public void Execute(SodPositionLoaded input)
        {
            foreach (var item in input.SodPositions)
            {
                Portfolio portfolio;
                PortfolioDetails details;
                if (_referenceData.TryGetPortfolioDetails(Infrastructure.Portfolio.Parse(item.Strategy), out details))
                {
                    portfolio = new Portfolio
                    {
                        Strategy = details.Portfolio.Strategy,
                        PMCode = details.Portfolio.PMCode,
                        SubStrategy = details.Portfolio.SubStrategy,
                        ComplianceGroup = details.ComplianceGroup,
                        AggregationUnit = details.AggregationUnit
                    };
                }
                else
                {
                    portfolio = Portfolio.Parse(item.Strategy);
                }

                Security sec;
                if (!TryGetSecurityFromCache(item.Symbol, null, out sec))
                {
                    sec = new Security
                    {
                        BamSymbol = item.Symbol
                    };
                }

                var position = new SodPosition
                {
                    Portfolio = portfolio,
                    Security = sec,
                    ActualQuantity = item.Quantity,
                    CustodianName = item.Custodian,
                    EntryDate = item.AsOf,
                    FundCode = item.Fund,
                    LastUpdated = item.AsOf,
                    TheoreticalQuantity = item.Quantity
                };

                var existing = _sodPositions.LookupBy(nameof(SodPosition.Id), position.Id);
                if (existing != null)
                {
                    _sodPositions.Remove(existing);
                }

                _sodPositions.Insert(position);
                Publish(position.Clone());
            }
        }

        #endregion

        #region Trade

        public void Execute(OrderAllocationChanged input)
        {
            string id = Convert.ToString(input.OrderId);

            var order = _orders.LookupBy(nameof(Order.Key), id);
            if (order != null)
            {
                var qty = input.Allocations.Sum(a => a.Quantity);
                decimal price = qty != 0 ? input.Allocations.Sum(a => a.Quantity * a.AveragePrice) / qty : 0;

                UpdateOrder(order, o =>
                {
                    order.FillQuantity = qty;
                    order.AveragePrice = price;
                }, input.Header.Timestamp);

                foreach (var alloc in input.Allocations)
                {
                    string fund, custodian, executionBroker;

                    if (!_referenceData.TryGetFund(alloc.FundId, out fund))
                    {
                        Logger?.LogWarning($"Received order allocations for unknown fund '{alloc.FundId}'.");
                        return;
                    }

                    if (!_referenceData.TryGetBroker(alloc.CustodianId, out custodian))
                    {
                        Logger?.LogWarning(
                            $"Received order allocations for unknown custodian '{alloc.CustodianId}'.");
                        return;
                    }

                    if (!_referenceData.TryGetBroker(alloc.ExecutionBrokerId, out executionBroker))
                    {
                        Logger?.LogWarning(
                            $"Received order allocations for unknown execution broker '{alloc.ExecutionBrokerId}'.");
                        return;
                    }

                    string tradeId =
                        $"{order.ClientOrderId}-{alloc.Portfolio}-{alloc.StreetOrderId}-{fund}-{custodian}-{executionBroker}";
                    var trade = _trades.LookupBy(nameof(Trade.TradeId), tradeId);

                    if (trade == null && alloc.Quantity != 0)
                    {
                        var tradeDate = order.TradeDate.AddHours(6).ToLocalTime();

                        Infrastructure.Portfolio portfolio;
                        PortfolioDetails details = null;
                        if (!Infrastructure.Portfolio.TryParse(alloc.Portfolio, out portfolio) ||
                            !_referenceData.TryGetPortfolioDetails(portfolio, out details))
                        {
                            Logger?.LogWarning($"Unable to look up portfolio details for '{portfolio}'.");
                        }

                        _trades.Insert(trade = new Trade
                        {
                            TradeTimeStamp = _clock.Now,
                            Portfolio = new Portfolio
                            {
                                PMCode = portfolio.PMCode,
                                Strategy = portfolio.Strategy,
                                SubStrategy = portfolio.SubStrategy,
                                AggregationUnit = details?.AggregationUnit,
                                ComplianceGroup = details?.ComplianceGroup
                            },
                            Security = order.Security,
                            AveragePrice = alloc.AveragePrice,
                            Trader = order.Trader,
                            Side = order.Side,
                            TradeDate = tradeDate.ToString("o"),
                            ClientOrderId = order.ClientOrderId,
                            Commissions =
                            {
                                new Fee
                                {
                                    Currency = order.TradeCurrency,
                                    Name = "Commission",
                                    RateType = RateType.Fee,
                                    Rate = alloc.Commissions
                                }
                            },
                            CounterParty = executionBroker,
                            PrimeBroker = custodian,
                            Fund = fund,
                            TradedQuantity = alloc.Quantity,
                            SettleDate = order.SettleDate,
                            TradeCurrency = order.TradeCurrency,
                            ParentTradeId = order.ClientOrderId,
                            isFinalized = order.OrderStatus == OrderStatus.Finalized,
                            TradeStatus = _tradeStatusService.GetStatus(
                                tradeId, alloc.Quantity, order.OrderStatus == OrderStatus.Finalized),
                            TradeId = tradeId,
                            LastUpdated = _clock.Now,
                            DataSource = order.EmsDestination,
                        });
                    }
                    else if (trade != null)
                    {
                        trade.LastUpdated = _clock.Now;
                        trade.TradedQuantity = alloc.Quantity;
                        trade.AveragePrice = alloc.AveragePrice;
                        trade.Commissions[0].Rate = alloc.Commissions;
                        trade.SettleDate = order.SettleDate;
                        trade.TradeStatus = _tradeStatusService.GetStatus(
                            tradeId, alloc.Quantity, order.OrderStatus == OrderStatus.Finalized);
                    }

                    if (trade != null)
                    {
                        trade.Fees.Clear();
                        foreach (var fee in alloc.Fees)
                        {
                            string name;
                            if (!_referenceData.TryGetFeeCategory(fee.Key, out name))
                            {
                                Logger?.LogWarning($"Unknown fee category id '{fee.Key}'");
                                name = "UNKNOWN";
                            }

                            trade.Fees.Add(new Fee
                            {
                                Name = name,
                                Currency = trade.TradeCurrency,
                                Rate = fee.Value,
                                RateType = RateType.Fee
                            });
                        }

                        Publish((Trade) trade.Clone());
                    }
                }
            }
        }

        private void FinalizeTrades(string orderId, bool finalized, int timestamp)
        {
            UpdateTrade(orderId, trade =>
            {
                trade.isFinalized = finalized;
                trade.TradeStatus =
                    trade.isFinalized && trade.TradedQuantity == 0
                        ? TradeStatus.Deleted
                        : TradeStatus.Modified;
            }, timestamp);
        }

        private void UpdateTrade(string id, Action<Trade> action, int timestamp)
        {
            var trades = _trades.MultiLookupBy(nameof(Trade.ClientOrderId), id);
            foreach (var trade in trades)
            {
                action(trade);
                _clock.SetTimestamp(timestamp);
                trade.LastUpdated = _clock.Now;
                Publish(trade.Clone());
            }
        }

        #endregion

        public void Execute(FinalPositionChanged input)
        {
            foreach (var item in input.Items)
            {
                UpdateOrder(item.OrderId, order => order.IsComplete = item.IsComplete, input.Header.Timestamp);
            }
        }

        public void Execute(NewOrderScalingRule input)
        {
            foreach (var item in input.Items)
            {
                Portfolio sourcePortfolio;
                PortfolioDetails details;
                if (_referenceData.TryGetPortfolioDetails(Infrastructure.Portfolio.Parse(item.SourceStrategy), out details))
                {
                    sourcePortfolio = new Portfolio
                    {
                        Strategy = details.Portfolio.Strategy,
                        PMCode = details.Portfolio.PMCode,
                        SubStrategy = details.Portfolio.SubStrategy,
                        ComplianceGroup = details.ComplianceGroup,
                        AggregationUnit = details.AggregationUnit
                    };
                }
                else
                {
                    sourcePortfolio = Portfolio.Parse(item.SourceStrategy);
                }

                Portfolio targetPortfolio;
                if (_referenceData.TryGetPortfolioDetails(Infrastructure.Portfolio.Parse(item.TargetStrategy), out details))
                {
                    targetPortfolio = new Portfolio
                    {
                        Strategy = details.Portfolio.Strategy,
                        PMCode = details.Portfolio.PMCode,
                        SubStrategy = details.Portfolio.SubStrategy,
                        ComplianceGroup = details.ComplianceGroup,
                        AggregationUnit = details.AggregationUnit
                    };
                }
                else
                {
                    targetPortfolio = Portfolio.Parse(item.SourceStrategy);
                }

                OrderScalingRule rule;
                Publish(rule = new OrderScalingRule
                {
                    Id = item.Id,
                    SecurityType = item.SecurityType != null
                        ? (SecurityType?) Enum.Parse(typeof(SecurityType), item.SecurityType, true)
                        : null,
                    SourceStrategy = sourcePortfolio,
                    TargetStrategy = targetPortfolio,
                    Ratio = item.Ratio,
                    IsActive = item.IsActive
                });

                rule.ExcludedSymbols.AddRange(item.ExcludedSymbols);
            }
        }

        public void Execute(EmsDestinationChanged input)
        {
            UpdateOrder(input.OrderId, order => order.EmsDestination = input.EmsSystem.ToString(), input.Header.Timestamp);
        }

        #region Compliance

        public void Execute(OwnershipHeadroomChanged input)
        {
            foreach (var item in input.Items)
            {
                var key = new OwnershipHeadroomKey(item.RuleId, item.Identifier);
                var rule = _ownershipHeadroom.LookupBy(nameof(OwnershipHeadroom.Key), key);
                if (rule == null)
                {
                    rule = new OwnershipHeadroom(key);
                    _ownershipHeadroom.Insert(rule);
                }

                rule.RuleName = item.RuleName;
                rule.Direction = item.Direction;
                rule.IsExempt = item.IsExempt;
                rule.IdentifierType = item.IdentifierType;
                rule.ReportingEntity = item.ReportingEntity;
                rule.IsContingency = item.IsContingency;
                rule.HeadRoomThresholds.Clear();
                rule.Ratios.Clear();

                item.Ratios.CopyTo(rule.Ratios);
                foreach (var threshold in item.HeadRoomThresholds)
                {
                    rule.HeadRoomThresholds.Add(new OwnershipHeadroom.HeadroomThreshold()
                    {
                        AlertLevel = threshold.AlertLevel.ToString(),
                        FireOnce = threshold.FireOnce,
                        HeadRoom = threshold.HeadRoom,
                        Threshold = threshold.Threshold
                    });
                }

                Publish(rule.Clone());
            }
        }

        public void Execute(OwnershipIntradayQuantityChanged input)
        {
            foreach (var item in input.Items)
            {
                var key = new OwnershipHeadroomKey(item.RuleId, item.Identifier);
                var rule = _ownershipHeadroom.LookupBy(nameof(OwnershipHeadroom.Key), key);

                if (rule == null)
                {
                    Logger?.LogWarning($"Received intraday quantity update for unknown headroom rule.  RuleId '{key.RuleId}', Id '{key.Identifier}'");
                    continue;
                }

                rule.IntradayQuantity = item.Quantity;
                rule.MaxIntradayQuantity = item.MaxQuantity;
                Publish(rule.Clone());
            }
        }

        public void Execute(OwnershipHeadroomRatiosAdjusted input)
        {
            var key = new OwnershipHeadroomKey(input.RuleId, input.Identifier);
            var rule = _ownershipHeadroom.LookupBy(nameof(OwnershipHeadroom.Key), key);

            if (rule == null)
            {
                Logger?.LogWarning($"Received intraday adjustment update for unknown headroom rule.  RuleId '{key.RuleId}', Id '{key.Identifier}'");
                return;
            }

            rule.Ratios.Clear();
            input.Ratios.CopyTo(rule.Ratios);
            Publish(rule.Clone());
        }

        public void Execute(OwnershipHeadroomRemoved input)
        {
            foreach (var item in input.Items)
            {
                var key = new OwnershipHeadroomKey(item.RuleId, item.Identifier);
                var headroom = _ownershipHeadroom.LookupBy(nameof(OwnershipHeadroom.Key), key);
                if (headroom != null)
                {
                    _ownershipHeadroom.Remove(headroom);
                    headroom.Kill();

                    Publish(headroom.Clone());
                }
            }
        }

        #endregion
    }
}