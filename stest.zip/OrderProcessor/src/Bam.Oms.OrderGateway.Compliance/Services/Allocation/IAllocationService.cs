﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public interface IAllocationService
    {
        bool TryAllocate(Order order, Dictionary<int, long> custodianAssignments,
            List<OrderAllocation> opening, List<OrderAllocation> closing,
            out string message);

        void SetOpeningClosingAllocation(Order order, List<OrderAllocation> targetAllocations);
    }
}