﻿namespace Bam.Oms.MarketData
{
    public interface IMarketDataService
    {
        void SendRequest(Request request);

        IMarketDataServiceCallbacks Callbacks { get; set; }

    }
}
