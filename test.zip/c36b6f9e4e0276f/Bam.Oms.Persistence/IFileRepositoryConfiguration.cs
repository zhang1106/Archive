﻿namespace Bam.Oms.Persistence
{
    public interface IFileRepositoryConfiguration
    {
        string Path { get;  }
        string FileName { get; }
        /// <summary>
        /// The joined file name and path
        /// </summary>
        string FullPath { get; }
    }
}