﻿namespace Bam.EventQ.Snapshot
{
    public interface ISnapshot
    {
        // marker interface
    }
}
