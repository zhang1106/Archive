﻿using System.Runtime.Serialization;

namespace Bam.Oms.Data.Enumerators
{
    [DataContract]
    public enum SideType
    {
        [EnumMember]
        [Enum(StringValue = "Unknown")]
        Unknown = 0,

        [EnumMember]
        [Enum(StringValue = "Buy")]
        Buy = 1,

        [EnumMember]
        [Enum(StringValue = "Sell")]
        Sell = 2,

        [EnumMember]
        [Enum(StringValue = "Cover Short")]
        Cover = 3,

        [EnumMember]
        [Enum(StringValue = "Sell Short")]
        SellShort = 4,

        [EnumMember]
        [Enum(StringValue = "Short")]
        Short = 5,

        [EnumMember]
        [Enum(StringValue = "Long")]
        Long = 6,

        [EnumMember]
        [Enum(StringValue = "Repo")]
        Repo = 7,

        [EnumMember]
        [Enum(StringValue = "Reverse Repo")]
        ReverseRepo = 8,

        [EnumMember]
        [Enum(StringValue = "NetLong")]
        NetLong = 9,
        
        [EnumMember]
        [Enum(StringValue = "NetShort")]
        NetShort = 10,

        [EnumMember]
        [Enum(StringValue = "Net")]
        Net = 11,
    }
}
