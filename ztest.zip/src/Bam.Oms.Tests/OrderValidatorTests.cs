﻿using System.Collections.Generic;
using Bam.Oms.Data.Orders;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class OrderValidatorTests
    {
        [TestCase(false, false)]
        [TestCase(true, true)]
        public void VerifyStrategyCheck(bool serviceResponse, bool expected)
        {
            // arrange
            var accountMock = new Mock<IAccountService>();

            var mapping = new Dictionary<string, bool>();
            mapping["strategy"] = serviceResponse;
            mapping["strategy1"] = true;

            accountMock.Setup(r => r.IsValidStrategy(It.IsAny<IList<string>>())).Returns(mapping);
            var sm = new Mock<ISecurityMasterService>();
            sm.Setup(r => r.IsValidSecurity(It.IsAny<IList<string>>())).Returns(mapping);

            var validator = new OrderValidator(accountMock.Object, sm.Object, new Mock<ILogger>().Object, new Mock<ILoggingSerializer>().Object);

            // act
            var unit = validator.IsValidOrder(new List<IOrder>());

            // assert
            Assert.That(unit, Is.EqualTo(expected));
        }
    }
}