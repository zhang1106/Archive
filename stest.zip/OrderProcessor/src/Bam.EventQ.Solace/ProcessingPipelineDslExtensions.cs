﻿using System;
using Bam.EventQ.Pipeline.Dsl;
using Bam.EventQ.Solace;
using Bam.EventQ.Throttling;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pipeline
{
    public static class ProcessingPipelineDslExtensions
    {
        public static ThrottledPipelineQueueItemHandlerDsl<TItem> ConflatedPublishToSolace<TItem, TKey, TMsg>(
            this ThrottledPipelineQueueItemHandlerDsl<TItem> chain, Func<TMsg, TKey> keyFunc,
            SolaceContextWrapper contextWrapper, ISolaceTopicProvider<TMsg> topicProvider,
            ISolaceMessageSerializer<TMsg> messageSerializer, bool skipReplay)
            where TMsg : TItem
        {
            IThrottledBatchHandler<TMsg> publisher =
                new SolaceThrottledBatchHandler<TMsg>(contextWrapper, topicProvider, messageSerializer);
            return chain.Add(new ConflationStrategy<TKey, TMsg>(keyFunc), publisher, skipReplay);
        }
    }
}
