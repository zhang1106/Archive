﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;
using Bam.Oms.OrderGateway.Compliance.Services.Headroom;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.Compliance
{
    public class InitialSodHeadroomLoad : QueueItemProducerBase<PipelineQueueItem<IMessage>>, IPipelineStepInitializer<IMessage>
    {
        private readonly IDbHeadroomLookup _dbHeadroomLookup;
        private readonly IQueueMessageDispatcher _dispatcher;
        private readonly IBackgroundWorker _sodLoadWorker;
        private bool _isLoaded;
        private static readonly TimeSpan RetryInterval = TimeSpan.FromSeconds(5);

        public InitialSodHeadroomLoad(IDbHeadroomLookup dbHeadroomLookup, IQueueMessageDispatcher dispatcher)
        {
            _dbHeadroomLookup = dbHeadroomLookup;
            _dispatcher = dispatcher;
            _sodLoadWorker = BackgroundWorkerFactory.Current.Create("Initial EOD Headroom");
        }

        public override void Start()
        {
            _sodLoadWorker.Start(Load);
        }

        public override void Stop()
        {
            _sodLoadWorker.Stop();
        }

        public void Execute(IQueue<PipelineQueueItem<IMessage>> queue, CancellationToken cancellationToken)
        {
            TryLoad(queue);
        }

        private void Load(CancellationToken cancellationToken)
        {
            do
            {
                if (_isLoaded)
                    break;

                TryLoad(Queue);
            } while (!cancellationToken.WaitHandle.WaitOne(RetryInterval));
        }

        private void TryLoad(IQueue<PipelineQueueItem<IMessage>> queue)
        {
            if (!_isLoaded)
            {
                try
                {
                    var headroom = GetSodHeadroom();
                    if (headroom.Items.Count > 0)
                    {
                        _dispatcher.Dispatch(queue, headroom);
                    }
                    else
                    {
                        Logger?.LogWarning("No headroom available to load from database.");
                    }

                    _isLoaded = true;
                }
                catch (Exception ex)
                {
                    Logger?.LogWarning($"Unable to retrieve contingency positions, retrying in {RetryInterval}", ex);
                }
            }
        }

        private HeadroomLoaded GetSodHeadroom()
        {
            DateTime businessDate;
            var headRoom = _dbHeadroomLookup.GetHeadroom(out businessDate);
            var ratios = _dbHeadroomLookup.GetHeadroomRatios(businessDate);

            var ratioDictionary = new Dictionary<int, List<HeadroomRatioDto>>();
            foreach (var ratio in ratios)
            {
                if(!ratioDictionary.ContainsKey(ratio.RuleId))
                    ratioDictionary[ratio.RuleId] = new List<HeadroomRatioDto>();

                ratioDictionary[ratio.RuleId].Add(ratio);
            }

            var grouped = from h in headRoom
                group h by new
                {
                    h.RuleId,
                    h.Identifier,
                    h.IdentifierType,
                    h.RuleName,
                    LegalEntity = h.ReportingEntity,
                    h.Direction,
                    h.IsExempt,
                }
                into grp
                select new
                {
                    grp.Key.RuleId,
                    grp.Key.Identifier,
                    grp.Key.IdentifierType,
                    grp.Key.RuleName,
                    grp.Key.LegalEntity,
                    grp.Key.Direction,
                    grp.Key.IsExempt,
                };

            var sodLoad = new HeadroomLoaded();
            var itemHash = new Dictionary<Tuple<int, string>, HeadroomLoaded.Item>();

            foreach (var item in grouped)
            {
                var sodLoadItem = new HeadroomLoaded.Item
                {
                    RuleId = item.RuleId,
                    Identifier = item.Identifier,
                    IdentifierType = item.IdentifierType,
                    RuleName = item.RuleName,
                    Entity = item.LegalEntity,
                    Side = item.Direction,
                    IsExempt = item.IsExempt,
                    IsContingency = true
                };
                sodLoad.Items.Add(sodLoadItem);
                itemHash[new Tuple<int, string>(item.RuleId, item.Identifier)] = sodLoadItem;

                List<HeadroomRatioDto> ratioList;
                if (ratioDictionary.TryGetValue(item.RuleId, out ratioList))
                {
                    foreach (var ratioDto in ratioList)
                    {
                        sodLoadItem.Ratio[ratioDto.AggregationUnit] = ratioDto.Ratio;
                    }
                }
            }

            foreach (var headRoomRow in headRoom)
            {
                HeadroomLoaded.Item item;
                if (itemHash.TryGetValue(new Tuple<int, string>(headRoomRow.RuleId, headRoomRow.Identifier), out item))
                {
                    item.Headrooms.Add(new HeadroomLoaded.Headroom()
                    {
                        AlertLevel = headRoomRow.AlertLevel,
                        Threshold = headRoomRow.Threshold,
                        HeadRoom = headRoomRow.Headroom + headRoomRow.IntradayQuantity,
                        FireOnce = headRoomRow.FireOnce,
                    });
                }
                else
                {
                    Logger?.LogError($"Unable to find matching headroom for rule id '{headRoomRow.RuleId}' and id '{headRoomRow.Identifier}'.");
                }
            }

            return sodLoad;
        }
    }
}