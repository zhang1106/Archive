﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;

namespace Bam.Oms.OrderGateway.Compliance.Services.Marking
{
    public abstract class OrderMarkerBase : IOrderMarker
    {
        private readonly Scope _scope;

        protected OrderMarkerBase()
        {
            _scope = new Scope(CompleteScope);
        }

        private class Scope : IDisposable
        {
            private readonly Action _dispose;

            public Scope(Action dispose)
            {
                _dispose = dispose;
            }

            public void Dispose()
            {
                _dispose();
            }
        }

        public virtual IDisposable Scoped()
        {
            return _scope;
        }

        protected abstract void CompleteScope();
        public abstract ISet<string> SupportedSecurityTypes { get; }
        public abstract List<Mark> MarkOrder(MarkingEntity entity, PositionSet set);
    }
}
