﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Http;
using Bam.Oms.Data;
using Bam.Oms.Data.RestApi;
using Bam.Oms.Data.Trades;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.EndPoints.PermissionService;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.Trades
{
    public class TradeController : BaseController, ITradeController
    {
        private readonly ITradeRepository _repository;
        private readonly IFlowManager _flowManager;

        public TradeController(ITradeRepository repository, IHostConfiguration hostConfiguration, IFlowManager flowManager, ILogger logger)
            : base(hostConfiguration, logger)
        {
            _repository = repository;
            _flowManager = flowManager;
        }

        [AccessRequire("Function.OrderGateway.Trade.Read, Function.OrderGateway.BlockTrade.Write")]
        public List<Trade> Get()
        {
            return Get(null);
        }

        [AccessRequire("Function.OrderGateway.Trade.Read, Function.OrderGateway.BlockTrade.Write")]
        public List<Trade> Get(DateTime? cutoffTimeUtc)
        {
            if (!cutoffTimeUtc.HasValue)
            {
                cutoffTimeUtc = DateTime.Today.ToUniversalTime(); // Beginning of the day in UTC
            }

            var matchedTrades = _repository.Get(cutoffTimeUtc.GetValueOrDefault()).ToList();

            var permisionedTrades = FilterPermissionedEntities(matchedTrades).ToList();
            var allocations = Utility.GetAllocations(permisionedTrades);
            return allocations.Cast<Trade>().Select(t => t).ToList();
        }

        [AccessRequire("Function.OrderGateway.Trade.Write")]
        public int Delete(DateTime? cutoffTimeUtc)
        {
            if (!cutoffTimeUtc.HasValue)
            {
                cutoffTimeUtc = DateTime.UtcNow;
            }
            return _repository.Clear(cutoffTimeUtc.GetValueOrDefault());
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Admin")]
        public string Publish(bool eod)
        {
            _flowManager.PublishTrades(eod, FlowClientScope.Both);
            return "publishing all trades to downstream systems";
        }

        private IEnumerable<BlockTrade> FilterPermissionedEntities(IEnumerable<BlockTrade> trades)
        {
            if (!PermissionChecker.IsPermissionEnabled())
            {
                _logger.Warn("DEV or QA. Skipping permisions.");
                return trades;
            }
            StrategyInfo[] strategiesInfos = GetPermissionedStrategies(User.Identity);
            _logger.Debug($"The user {User.Identity.Name} is permissiond for {String.Concat(strategiesInfos, ",")}.");
            return trades.Where(
                    order => strategiesInfos.Any(s => order.Portfolio.ToString().Contains(s.StrategyCode)))
                    .ToList();
        }
    }
}
