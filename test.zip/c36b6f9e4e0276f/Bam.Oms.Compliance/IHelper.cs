﻿using System;
using System.Collections.Generic;
using Bam.Oms.Compliance.Results;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance
{
    public interface IHelper
    {
        object ConvertBaseToChild(IExtensible item);
        void DumpToDb(IEnumerable<IPosition> positions, PositionType type);
        OwnershipFilingResult CreateFilingResult(ICompliancePosition input, IRule<ICompliancePosition> rule, SideType side,
            string entity, string identityType);
        HeadRoom.HeadRoomUnit CreateHeadRoomUnit(IRule<ICompliancePosition> rule, OwnershipFilingResult result, ThreshholdWarning threshhold, SideType side);

        IList<HeadRoom.HeadRoomUnit> CreateErrHeadRoomUnit(OwnershipFilingResult result, IEnumerable<ThreshholdWarning> threshholds);

        IEnumerable<IRuleResult> CreateNoInfoFilingResult(IEnumerable<string> underlyings, string description);

        IRuleResult CreateNoRuleHeadRoomForAll(string symbol, int policyId);
        
        DateTime GetBusinessDate(DateTime now);

        DateTime GetEodBusinessDate();

        IEnumerable<IPosition> Convert(IEnumerable<DtdPosition> positions, PositionType type);

        IEnumerable<Security> Convert(IEnumerable<MarketData> bbData);
        ICompliancePosition CreateCompliancePosition(ISecurity security, IPolicy<ICompliancePosition> policy, PositionType pType);

        void LogEvent(string resultKey, string context);
     
        void LogErrorEvent(string resultKey, string context);
        

    }
}
