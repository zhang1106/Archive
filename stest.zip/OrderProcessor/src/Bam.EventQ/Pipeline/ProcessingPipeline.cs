﻿using System.Threading;
using Bam.EventQ.Hosting;
using Bam.EventQ.Pipeline.Dsl;

namespace Bam.EventQ.Pipeline
{
    public class ProcessingPipeline : IProcessingPipeline
    {
        private readonly IProcessingPipelineStep[] _steps;
        private readonly IBackgroundWorker _startupWorker;

        public ProcessingPipeline(params IProcessingPipelineStep[] steps)
        {
            _steps = steps;
            _startupWorker = BackgroundWorkerFactory.Current.Create("Processing Pipeline Startup");
        }

        public void Start()
        {
            foreach (var step in _steps)
            {
                step.Initialize();
            }

            _startupWorker.Start(InternalStart);
        }

        public void Stop()
        {
            _startupWorker.Stop();
            foreach (var step in _steps)
            {
                step.Stop();
            }
        }

        private void InternalStart(CancellationToken cancellationToken)
        {
            foreach (var step in _steps)
            {
                step.Start(cancellationToken);
            }
        }

        public static ProcessingPipelineDsl New()
        {
            return new ProcessingPipelineDsl();
        }
    }
}
