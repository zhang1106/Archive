﻿CREATE TABLE [intg].[OrderSource] (
    [OrderSourceId]     INT              IDENTITY (1, 1) NOT NULL,
    [Security]          VARCHAR (100)    NOT NULL,
    [Side]              VARCHAR (10)     NOT NULL,
    [Amount]            DECIMAL (28, 12) NOT NULL,
    [TAlpha2]           VARCHAR (100)    NOT NULL,
    [Manager]           VARCHAR (50)     NOT NULL,
    [Custodian]         VARCHAR (50)     NOT NULL,
    [SourceDescription] VARCHAR (200)    NULL,
    [User_Updated]      VARCHAR (50)     NOT NULL,
    [Date_Updated]      DATETIME         NOT NULL,
    CONSTRAINT [PK_OrderSource] PRIMARY KEY CLUSTERED ([OrderSourceId] ASC)
);

