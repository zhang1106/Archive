﻿using System;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Bam.Oms.Data.Positions
{
    [DataContract]
    public class Position : IPosition
    {
        public Position(IPortfolio portfolio, ISecurity security, string primeBroker)
        {
            Portfolio = (Portfolio)portfolio;
            Security = (Security)security;
            CustodianName = primeBroker;

        }

        public Position()
        {
        }

        [DataMember(Order = 7)]
        public int PositionId { get; set; }

        [DataMember(Order = 8)]
        public string FundCode { get; set; }

        [DataMember(Order = 9)]
        public string CustodianAccountCode { get; set; }

        [DataMember(Order = 12)]
        public string Stream { get; set; }

        [DataMember(Order = 13)]
        public DateTime EntryDate { get; set; }

        [DataMember(Order = 14)]
        public int? ActionLogId { get; set; }

        [DataMember(Order = 15)]
        public int AuditSequence { get; set; }

        [DataMember(Order = 16)]
        public string LastModifiedBy { get; set; }

        [DataMember(Order = 17)]
        public DateTime LastModifiedOn { get; set; }

        [DataMember(Order = 18)]
        public DateTime CreatedOn { get; set; }

        [DataMember(Order = 19)]
        public string CustodianName { get; set; }

        [DataMember(Order = 20)]
        public decimal? Cost { get; set; }

        [DataMember(Order = 0)]
        public string Key => $"Portfolio:{Portfolio.Key} Security:{Security.Key}";

        [DataMember(Order = 1)]
        public Portfolio Portfolio { get; set; }

        [DataMember(Order = 2)]
        public Security Security { get; set; }

        [DataMember(Order = 3)]
        public decimal TheoreticalQuantity { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        [DataMember(Order = 4, IsRequired = true)]
        public SideType TheoreticalSide { get; set; }

        [DataMember(Order = 5)]
        public decimal ActualQuantity { get; set; }

        [DataMember(Order = 6, IsRequired = true)]
        [JsonConverter(typeof(StringEnumConverter))]
        public SideType ActualSide { set; get; }

        [DataMember(Order = 10)]
        public decimal? Price { get; set; }

        [DataMember(Order = 11)]
        public decimal? FXRate { get; set; }
        
        public string ParentSymbol { get; set; }
        public decimal? NetExposure { get; set; }
        public string Currency { get; set; }
        public string CustodianAccount { get; set; }
        public long EquivalentQuantity { get; set; }

        public override string ToString()
        {
            return
                $"{Portfolio}:{Security}: Actual {ActualQuantity}[{ActualSide}];Theo {TheoreticalQuantity}[{TheoreticalSide}].";
        }
 
        public override int GetHashCode()
        {
            return unchecked(Portfolio.GetHashCode() * Security.GetHashCode());
        }

        public IPosition InitPosition()
        {
            if (Security.IsEquityOption())
            {
                if(ActualQuantity >= 0 && Security.OptionType == OptionType.Call)
                    ActualSide = SideType.Long;
                else if(ActualQuantity < 0 && Security.OptionType == OptionType.Call)
                    ActualSide = SideType.Short;
                else if(ActualQuantity >= 0 && Security.OptionType == OptionType.Put)
                    ActualSide = SideType.Short;
                else
                    ActualSide = SideType.Long;

                EquivalentQuantity = (long)(Math.Abs(ActualQuantity * (Security.ContractSize ?? 1)));
                if (ActualSide == SideType.Short) EquivalentQuantity = (-1)*EquivalentQuantity;
            }
            else
            {
                ActualSide = ActualQuantity >= 0 ? SideType.Long : SideType.Short;
                EquivalentQuantity = (long)ActualQuantity;
            }
            return this;
        }
    }
}