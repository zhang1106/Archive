﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Persistence.Positions
{
    public class EodPositionRepository : DBRepository<EodPosition>, IEodPositionRepository
    {
        private readonly IAccountService _referenceData;
        private readonly ISecurityMasterService _securityController;

        public int Save(IReadOnlyList<IPosition> positions, DateTime businessDay)
        {
            var records = (
                from p in positions
                from d in p.DistributedPositions
                let eod = new EodPosition
                {
                    BamSymbol = p.Security.BamSymbol,
                    Custodian = d.CustodianName,
                    Fund = d.FundCode,
                    Portfolio = p.Portfolio.Key,
                    Quantity = Convert.ToInt64(d.Quantity)
                }
                group eod by new {eod.BamSymbol, eod.Portfolio, eod.Custodian, eod.Fund}
                into g
                select new EodPosition
                {
                    BamSymbol = g.Key.BamSymbol,
                    Custodian = g.Key.Custodian,
                    Fund = g.Key.Fund,
                    Portfolio = g.Key.Portfolio,
                    Quantity = g.Sum(i => i.Quantity),
                    TradeDate = businessDay.Date,
                    SysDate = DateTime.Now
                }).ToList();

            return SaveItems(records);
        }

        public IReadOnlyList<IPosition> Load(DateTime businessDay)
        {
            var portfolios = _referenceData.GetAllPortfolios().ToDictionary(p => p.Key);
            var records = Get("TradeDate = @TradeDate", new {TradeDate = businessDay.Date}).ToList();

            var symbols = records.Select(r => r.BamSymbol).Distinct().ToList();
            var securities = _securityController.GetSecurities(symbols).ToDictionary(s => s.Key);

            var positions = new List<IPosition>(records.Count);
            foreach (var record in records)
            {
                Portfolio portfolio;
                if (!portfolios.TryGetValue(record.Portfolio, out portfolio))
                {
                    _log.WarnFormat($"Skipping unknown portfolio {record.Portfolio}");
                    continue;
                }

                IUpdateSecurity security;
                if (!securities.TryGetValue(record.BamSymbol, out security))
                {
                    _log.WarnFormat($"Skipping unknown security {record.BamSymbol}");
                    continue;
                }

                positions.Add(new Position(portfolio, security)
                {
                    ActualQuantity = record.Quantity,
                    TheoreticalQuantity = record.Quantity,
                    LongMarkingQuantity = record.Quantity,
                    ShortMarkingQuantity = record.Quantity,
                    Stream = portfolio.OmsStream,
                    FundCode = record.Fund,
                    CustodianName = record.Custodian,
                    EntryDate = record.TradeDate,
                    CreatedOn = record.SysDate
                });
            }

            return positions.ToArray();
        }

        public EodPositionRepository(ISettings settings, ILogger logger,
            IAccountService referenceData, ISecurityMasterService securityController) 
            : base(settings, logger, "og", "EodPosition")
        {
            _referenceData = referenceData;
            _securityController = securityController;
        }

        private int SaveItems(IEnumerable<EodPosition> items)
        {
            DataTable dataTable;
            try
            {
                dataTable = ToDataTable(items.ToList());
            }
            catch
            {
                return 0;
            }

            using (var connection = ((SqlConnection) Connection))
            {
                connection.Open();
                using (var trans = connection.BeginTransaction())
                {
                    using (var cmd = connection.CreateCommand())
                    {
                        cmd.Transaction = trans;
                        cmd.CommandText = $"DELETE FROM {FullyQualifiedTableName} WHERE [TradeDate] = @Date";
                        cmd.Parameters.AddWithValue("Date", items.First().TradeDate.Date);
                        cmd.ExecuteNonQuery();
                    }

                    using (var bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, trans))
                    {
                        bulkCopy.DestinationTableName = FullyQualifiedTableName;

                        // Write from the source to the destination.
                        bulkCopy.WriteToServer(dataTable);
                    }
                    trans.Commit();
                }
            }

            return dataTable.Rows.Count;
        }

        private DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            var props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }
            foreach (T item in items)
            {
                var values = new object[props.Length];
                for (int i = 0; i < props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }
    }
}