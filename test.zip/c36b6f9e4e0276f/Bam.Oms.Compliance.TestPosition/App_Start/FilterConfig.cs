﻿using System.Web;
using System.Web.Mvc;

namespace Bam.Oms.Compliance.TestPosition
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
