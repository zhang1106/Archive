﻿using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Persistence.Compliance
{
    public class FactRepository : DBRepository<Fact>, IFactRepository
    {
        public  FactRepository(ISettings settings, ILogger logger) : base(settings, logger, "cp", "Fact")
        { }
    }
}
