﻿using System.Collections.Generic;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IMarketDataProvider : IDataProvider
    {
        IDictionary<string, IMarketData> MarketData { get;}
        decimal? GetSharesOutstanding(string bamSymbol);
    }
}
