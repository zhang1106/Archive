﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;

namespace Bam.Oms.RefData.OMS
{
    internal class OrderScaleKey : IComparable<OrderScaleKey>, IEquatable<OrderScaleKey>
    {
        public OrderScaleKey(IPortfolio sourcePortfolio, SecurityType? securityType)
        {
            SourcePortfolio = sourcePortfolio;
            SecurityType = securityType;
        }

        public IPortfolio SourcePortfolio { get; }
        public SecurityType? SecurityType { get; }

        public int CompareTo(OrderScaleKey other)
        {
            int portfolioCompare = this.SourcePortfolio.CompareTo(other.SourcePortfolio);
            return portfolioCompare == 0 ? (SecurityType?.CompareTo(other.SecurityType)).GetValueOrDefault() : portfolioCompare;
        }

        public bool Equals(OrderScaleKey other)
        {
            if (other == null) return false;
            return other.SourcePortfolio.IsMatch(SourcePortfolio) && other.SecurityType.Equals(SecurityType);
        }

        public override bool Equals(object obj)
        {
            OrderScaleKey key = obj as OrderScaleKey;
            return this.Equals(key);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return SourcePortfolio.PMCode.GetHashCode();
            }
        }
    }
}
