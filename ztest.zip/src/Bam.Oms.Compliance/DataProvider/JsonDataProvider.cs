﻿using System;
using System.Net.Http;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.DataProvider
{
    /// <summary>
    /// get intraday data from the pomo restful data svc
    /// </summary>
    public class JsonDataProvider : IJsonDataProvider
    {
        /// <summary>
        /// get position data string from pomo svc
        /// </summary>
        /// <param name="svcUrl"></param>
        /// <returns></returns>
        public string GetDataInJson(string svcUri)
        {
            var pomoData = string.Empty;
            var handler = new HttpClientHandler()
            {
                UseDefaultCredentials = true,
            };

            try
            {

                using (var httpClient = new HttpClient(handler))
                {
                    httpClient.DefaultRequestHeaders.Accept.Clear();

                    var response = httpClient.GetAsync(svcUri).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        pomoData = response.Content.ReadAsStringAsync().Result;
                    }
                }
            }
            catch (Exception ex)
            {
                var logger = Container.Instance.Resolve<ILogger>();
                logger.Error($"Error in getting data from {svcUri}: {ex.Message}");
            };

            return pomoData;
        }
    }

}
