﻿using System;
using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public interface IDbPositionLookup
    {
        IList<T> Get<T>(out DateTime businessDay);
    }
}