﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class SodPositionController : BaseController
    {
        private readonly ICache<string, SodPosition> _sodPositionCache;
        private readonly ISodSubmission _sodSubmission;

        public SodPositionController(
            IPermissionedEntityFilter entityFilter, 
            ICache<string, SodPosition> sodPositionCache,
            ISodSubmission sodSubmission) 
            : base(entityFilter)
        {
            _sodPositionCache = sodPositionCache;
            _sodSubmission = sodSubmission;
        }
        
        [RequiredPermissions("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public Task<List<SodPosition>> Get()
        {
            using (_sodPositionCache.AcquireReadAccess())
            {
                return FilterEntitiesAsync(_sodPositionCache.GetItems()
                    .OrderBy(p => p.Id));
            }
        }

        [RequiredPermissions("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public Task<List<SodPosition>> Get(string bamSymbol)
        {
            using (_sodPositionCache.AcquireReadAccess())
            {
                bamSymbol = bamSymbol.ToUpper();

                return FilterEntitiesAsync(_sodPositionCache.GetItems()
                    .Where(p => string.Equals(p.Security.Key, bamSymbol, StringComparison.OrdinalIgnoreCase))
                    .OrderBy(p => p.Id));
            }
        }

        [RequiredPermissions("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public Task<List<SodPosition>> Get(string bamSymbol, string portfolio)
        {
            using (_sodPositionCache.AcquireReadAccess())
            {
                bamSymbol = bamSymbol.ToUpper();

                return FilterEntitiesAsync(_sodPositionCache.GetItems()
                    .Where(p => string.Equals(p.Security.Key, bamSymbol, StringComparison.OrdinalIgnoreCase) &&
                                string.Equals(p.Portfolio.ToString(), portfolio, StringComparison.OrdinalIgnoreCase))
                    .OrderBy(p => p.Id));
            }
        }

        [RequiredPermissions("Function.OrderGateway.Position.Write")]
        public string Load(List<SodPositionSlim> positions)
        {
            Logger?.LogInformation($"{User.GetLogin()} loaded {positions.Count} SOD positions");

            var submission = new Dictionary<KeyValuePair<string, DateTime>, List<SodPositionSlim>>();
            foreach (var grp in positions.GroupBy(p => p.Stream, StringComparer.OrdinalIgnoreCase))
            {
                var stream = grp.Key?.ToUpperInvariant();

                var dates = new HashSet<DateTime>(grp.Select(p => p.AsOf));
                if (dates.Count > 1)
                {
                    Logger?.LogError($"Received SOD positions with inconsistent as-of dates for stream '{stream}'");
                    BadRequest();
                    return string.Empty;
                }

                submission.Add(new KeyValuePair<string, DateTime>(stream, dates.First()), grp.ToList());
            }

            foreach (var item in submission)
            {
                _sodSubmission.Load(item.Key.Value, item.Value.Select(
                    p => new LoadSodPositions.SodItem 
                    {
                        Quantity = Convert.ToInt64(p.Quantity),
                        Strategy = p.Portfolio.ToString(),
                        Symbol = p.BamSymbol,
                        Custodian = p.Custodian,
                        Fund = p.Fund
                    }), User.GetLogin());
            }

            return string.Empty;
        }

        [RequiredPermissions("Function.OrderGateway.Position.Write")]
        public string Update(List<SodPositionSlim> positions)
        {
            Logger?.LogInformation($"{User.GetLogin()} updated {positions.Count} SOD positions");

            var dates = new HashSet<DateTime>(positions.Select(p => p.AsOf));
            if (dates.Count > 1)
            {
                Logger?.LogError("Received SOD positions with inconsistent as-of dates");
                BadRequest();
                return string.Empty;
            }

            _sodSubmission.Update(dates.First(), positions.Select(
                p => new UpdateSodPositions.SodItem
                {
                    Quantity = Convert.ToInt64(p.Quantity),
                    Strategy = p.Portfolio.ToString(),
                    Symbol = p.BamSymbol,
                    Custodian = p.Custodian,
                    Fund = p.Fund,
                }), User.GetLogin());

            return string.Empty;
        }
    }
}
