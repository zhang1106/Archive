﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Orders;
using Bam.Oms.Persistence.Orders;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.TradeMarker
{
    public class OrderIdGenerator 
    {
        private readonly IClientOrderIdRepository _orderIdRepository;
        private readonly ILogger _logger;

        public OrderIdGenerator(IClientOrderIdRepository orderIdRepository, ILogger logger)
        {
            if (orderIdRepository == null) throw new ArgumentNullException("orderIdRepository");
            if (logger == null) throw new ArgumentNullException("logger");

            _orderIdRepository = orderIdRepository;
            _logger = logger;
        }

        public void AssignOrderIds(IList<IOrder> orders)
        {
            var orderIds = _orderIdRepository.GenerateOrderIds(orders.Count());

            _logger.Info($"Batched {orderIds.Count} order id(s)");

            for (int i = 0; i < orders.Count(); i++)
            {
                orders[i].ClientOrderId = orderIds[i];
                _logger.Info($"Generated order id {orderIds[i]} - {orders[i]}");
            }
        }
    }
}