﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Diagnostics
{
    public class TimeInQueueHandler<TItem> : IQueueItemHandler<PipelineQueueItem<TItem>>
    {
        private readonly ITelemetry _telemetry;
        private readonly TimeSpan _publishInterval;
        private readonly List<TimeSpan> _batch;
        private DateTime _lastPublish = DateTime.MinValue;

        public TimeInQueueHandler(ITelemetry telemetry, TimeSpan publishInterval)
        {
            _telemetry = telemetry;
            _publishInterval = publishInterval;
            _batch = new List<TimeSpan>(4096);
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            _batch.Add(item.TimeInQueue);
            if (_lastPublish + _publishInterval < DateTime.UtcNow)
            {
                _telemetry.Record("AverageProcessingTime", _batch.Average(t => t.TotalMilliseconds));
                _batch.Clear();
                _lastPublish = DateTime.UtcNow;
            }
        }
    }
}
