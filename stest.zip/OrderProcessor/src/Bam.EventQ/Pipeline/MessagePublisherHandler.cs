﻿using Bam.EventQ.Queue;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Pipeline
{
    public class MessagePublisherHandler<TItem> : IQueueItemHandler<PipelineQueueItem<TItem>>
    {
        private readonly IMessagePublisher _messagePublisher;

        public MessagePublisherHandler(IMessagePublisher messagePublisher)
        {
            _messagePublisher = messagePublisher;
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            if (item.IsReplay || !item.IsValid)
                return;

            _messagePublisher.Publish(item.Topic, item.Buffer.Array, item.Buffer.Offset, item.Length);
        }
    }
}
