﻿using System;
using Newtonsoft.Json;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Compliance.Results;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;
using BAM.Infrastructure.DataFlowLogging.Client;

namespace Bam.Oms.Compliance.Rules
{
    [JsonObject(MemberSerialization.OptIn)]
    public class ShortOwnershipFiling :  FirmRuleBase 
    {
       [JsonProperty]
        public string CurrencyCode { get; set; }
        public ShortOwnershipFiling(IFactProvider factProvider,  ILogger logger, ILoggingAgent eventLogger) : 
            base(factProvider, logger, eventLogger)
        {
         
        }
        public override IRuleResult CheckViolation(CompliancePosition input, bool isPreCheck)
        {
            var result = new ShortOwnershipFilingResult()
            {
                RuleId = this.Id,
                BamSymbol = input.BamSymbol,
                Type = "ShortOwnershipFilingResult",
                RuleName = this.Name,
                Description = "No violation",
                PolicyId = input.PolicyId,
                IsViolationOverriden = false,
                AlertLevel = ComplianceAlertLevel.NoViolation
            };

            var context = string.Empty;
            try
            {
                var security = input.Security;
                //appy filters first
                if (IsActive && _factProvider.GetList("EUShourtCountries").Contains(security.Currency)) 
                {
                    result.AlertLevel = ComplianceAlertLevel.Violated;
                    result.Currency = security.Currency;
                    result.Description = "TradeCurrency is in Short Restriction";
                }
                //log to dataflow
                LogEvent(result.Key, context);
            }
            catch (Exception ex)
            {
                result.AlertLevel = ComplianceAlertLevel.Error;
                result.Description = ex.Message;
                _logger.Error(ex.Message);
                //log to dataflow
                LogErrorEvent(result.Key, context);
            }

            return result;
        }
    }
}
