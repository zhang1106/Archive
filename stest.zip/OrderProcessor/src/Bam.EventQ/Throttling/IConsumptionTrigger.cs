﻿using System;

namespace Bam.EventQ.Throttling
{
    public interface IConsumptionTrigger<in TItem>
    {
        void Throttled(TItem item, long sequence, bool endOfBatch);
        event EventHandler Consume;
    }
}
