﻿using System;
using System.Collections.Generic;

namespace Bam.EventQ.Snapshot
{
    public interface ISnapshotTypeRegistry
    {
        IEnumerable<ISnapshotRecoverable> Recoverables { get; }
        IEnumerable<Type> GetTypes(ISnapshotRecoverable recoverable);
        Type GetType(string snapshotName);
        string GetName(ISnapshot snapshot);
    }
}
