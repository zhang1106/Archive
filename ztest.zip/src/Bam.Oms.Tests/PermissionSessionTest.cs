﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Moq;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.EndPoints.PermissionService;
using Bam.Oms.EndPoints.Http;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class PermissionSessionTest
    {
        [Test]
        public void TestGetPermissions()
        {
            var setting = new Mock<ISettings>();
            setting.SetupGet(s => s.PermissionedApplications).Returns("PMUI,OrderGateway");
            var pSvc = new Mock<IPermissionSvcClient>();
            pSvc.Setup(f => f.GetPermissions(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(new PermissionInfo[]{new PermissionInfo() { PermissionPath= "Function.PMUI.Write" }, new PermissionInfo() { PermissionPath = "Function.OrderGateway.Trade.Read" } });
          
            Container.Instance.RegisterInstance<ISettings>(setting.Object);
            Container.Instance.RegisterInstance<IPermissionSvcClient>(pSvc.Object);

            var permissions = PermissionServiceSession.GetPermissions("test");

            Assert.IsTrue(permissions != null && permissions.Count == 2 );
        }

        [Test]
        public void TestGetStrategies()
        {
            var setting = new Mock<ISettings>();
            setting.SetupGet(s => s.PermissionedApplications).Returns("PMUI,OrderGateway");
            setting.SetupGet(s => s.EnablePermission).Returns("YES");
            var pSvc = new Mock<IPermissionSvcClient>();
            pSvc.Setup(f => f.GetStrategies(It.IsAny<string>()))
                .Returns(new StrategyInfo[] { new StrategyInfo() { StrategyCode = "QIAN-GENERALIST" }, new StrategyInfo() { StrategyCode = "GREE-GENERALIST" } });

            Container.Instance.RegisterInstance<ISettings>(setting.Object);
            Container.Instance.RegisterInstance<IPermissionSvcClient>(pSvc.Object);

            var strategies = PermissionServiceSession.GetStategies("test");

            Assert.IsTrue(strategies != null && strategies.Count == 2);
        }

        [Test]
        public void TestReset()
        {
            var setting = new Mock<ISettings>();
            setting.SetupGet(s => s.PermissionedApplications).Returns("PMUI,OrderGateway");
            var pSvc = new Mock<IPermissionSvcClient>();
            pSvc.Setup(f => f.GetPermissions(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(new PermissionInfo[] { new PermissionInfo() { PermissionPath = "Function.PMUI.Write" }, new PermissionInfo() { PermissionPath = "Function.OrderGateway.Trade.Read" } });

            Container.Instance.RegisterInstance<ISettings>(setting.Object);
            Container.Instance.RegisterInstance<IPermissionSvcClient>(pSvc.Object);

            var permissions = PermissionServiceSession.GetPermissions("test");

            //reduce test permissions to 1
            pSvc.Setup(f => f.GetPermissions(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(new PermissionInfo[] { new PermissionInfo() { PermissionPath = "Function.OrderGateway.Trade.Read" } });

            
            //before reset test should still have two permissions
            Assert.IsTrue(permissions != null && permissions.Count == 2);

            PermissionServiceSession.ResetPermissions("test");
            permissions = PermissionServiceSession.GetPermissions("test");

            //after reset, test will only have one permission
            Assert.IsTrue(permissions != null && permissions.Count == 1);
        }
    }
}
