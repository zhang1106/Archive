﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Bam.Oms.Data.Orders;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using CsvHelper;
using Newtonsoft.Json;

namespace Bam.Oms.EndPoints.File
{
    public class OrderListener : AbstractListener
    {
        public OrderListener(IFileConfiguration fileConfiguration, ILogger logger, IOrderPrepUtility orderPrepUtility,
            IOrderValidator orderValidator, ILoggingSerializer loggingSerializer, IAccountService accountService)
            : base(fileConfiguration, logger, orderPrepUtility, orderValidator, loggingSerializer, accountService)
        {
        }

        protected override List<IOrder> ParseFile(string path)
        {
            var stream = OpenFileStream(path);

            string headerLine = string.Empty;
            if (stream != null)
            {
                using (StreamReader sr = new StreamReader(stream))
                {
                    headerLine = sr.ReadLine();
                }
            }
            stream?.Dispose();
            

            List<IOrder> orders = new List<IOrder>();

            if ((headerLine?.Contains("TAlpha2")).GetValueOrDefault())
            {
                using (var reader = new CsvReader(System.IO.File.OpenText(path)))
                {
                    reader.Configuration.RegisterClassMap<OrderMapping>();

                    while (reader.Read())
                    {
                        try
                        {
                            var order = reader.GetRecord<Order>();

                            //there are set number of required columns
                            //the first 6 are required, so any execution instructions will be additional optional 
                            //columns
                            for (var i = 6; i < reader.FieldHeaders.Length; i++)
                            {
                                string field;
                                if (reader.TryGetField(i, out field))
                                {
                                    var header = reader.FieldHeaders[i];
                                    var inst = new ExecutionInstruction(header, field);
                                    order.ExecutionInstructions.Add(inst);
                                }
                            }

                            orders.Add(order);
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Unable to read record row {JsonConvert.SerializeObject(reader.CurrentRecord)}; {ex.Message} - {ex.StackTrace}");
                            //Do not proceed even if one record is not parsable
                            throw;
                        }
                    }
                }
            }
            else
            {
                IList<OrderRecord> orderRecords;
                using (var reader = new CsvReader(System.IO.File.OpenText(path)))
                {
                    reader.Configuration.RegisterClassMap<OrderRecordMapping>();
                    reader.Configuration.WillThrowOnMissingField = false;
                    reader.Configuration.HasHeaderRecord = true;
                    reader.Configuration.IgnoreReadingExceptions = true;
                    reader.Configuration.ReadingExceptionCallback = ReadingExceptionCallback;
                    orderRecords = reader.GetRecords<OrderRecord>().ToList();
                }

                IDictionary<OrderGroupingKey, IOrder> groupedOrders = new Dictionary<OrderGroupingKey, IOrder>();
                foreach (OrderRecord orderRecord in orderRecords)
                {
                    try
                    {
                        if (!String.IsNullOrWhiteSpace(orderRecord.GroupingKey) &&
                            !String.IsNullOrWhiteSpace(orderRecord.Fund))
                        // Are we enforcing pre-allocation? DO we really want to?
                        {
                            AllocationInfo allocationInfo = new AllocationInfo()
                            {
                                AllocationId =
                                    $"{orderRecord.Portfolio} {orderRecord.PrimeBroker.Substring(0, 2)}-{orderRecord.Fund}",
                                Fund = orderRecord.Fund,
                                PrimeBroker = orderRecord.PrimeBroker,
                                PrimeBrokerAccount = orderRecord.PrimeBrokerAccount,
                                Quantity = orderRecord.Quantity
                            };

                            OrderGroupingKey ogpKey = new OrderGroupingKey(orderRecord.GroupingKey,
                                orderRecord.Security.BamSymbol, orderRecord.Side);
                            IOrder groupedOrder;
                            if (!groupedOrders.TryGetValue(ogpKey, out groupedOrder))
                            {
                                groupedOrder = CreateOrder(orderRecord);
                                groupedOrders.Add(ogpKey, groupedOrder);
                            }
                            else
                            {
                                groupedOrder.Size += orderRecord.Quantity;
                                if (!String.IsNullOrWhiteSpace(orderRecord.ExecutionInstructions))
                                {
                                    groupedOrder.ExecutionInstructions.Add(
                                        new ExecutionInstruction(orderRecord.ExecutionInstructions?.Split(';')[0],
                                            orderRecord.ExecutionInstructions?.Split(';')[1]));
                                }
                            }
                            groupedOrder.Allocations.Add(allocationInfo);
                        }
                        else
                        {
                            orders.Add(CreateOrder(orderRecord));
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.Error($"Exception processing order record {orderRecord}.", ex);
                    }
                }
                orders.AddRange(groupedOrders.Values);
            }
            return orders;
        }

        protected override string PopulateBatchId(List<IOrder> orderList)
        {
            DateTime now = DateTime.Now;
            orderList.ForEach(o => o.BatchId = _orderPrepUtility.CreateBatchId(o.Portfolio.PMCode, now));
            return orderList.First().BatchId;
        }

        private void ReadingExceptionCallback(Exception exception, ICsvReader csvReader)
        {
            _logger.Error("Error reading a record in the order file. The record would be ignored.", exception);
        }

        private static Order CreateOrder(OrderRecord orderRecord)
        {
            Order order = new Order()
            {
                Portfolio = orderRecord.Portfolio,
                Security = orderRecord.Security,
                Side = orderRecord.Side,
                Size = orderRecord.Quantity,
                Custodian = orderRecord.PrimeBroker,
                Urgency = orderRecord.Urgency,
            };
            if (!String.IsNullOrWhiteSpace(orderRecord.ExecutionInstructions))
            {
                order.ExecutionInstructions.Add(
                        new ExecutionInstruction(orderRecord.ExecutionInstructions?.Split(';')[0],
                            orderRecord.ExecutionInstructions?.Split(';')[1]));
            }
            return order;
        }
        #region IDisposable Support       

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {

            }

            // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
            // TODO: set large fields to null.                
        }
        #endregion
    }
}
