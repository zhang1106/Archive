﻿namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class OrderFileListenerSettings : FileListenerSettings
    {
        public OrderFileListenerSettings()
            : base("OrderFileListener")
        {
        }
    }
}
