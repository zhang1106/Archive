﻿using System;

namespace Bam.EventQ.Time
{
    // Special implementation for UTC for performance benefits
    public class UtcClock : Clock
    {
        public UtcClock() : base("UTC", TimeZoneInfo.Utc)
        {

        }

        public override DateTime Now => DateTime.UtcNow;
    }
}
