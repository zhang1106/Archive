﻿namespace Bam.EventQ.Diagnostics
{
    public enum LogLevel
    {
        Debug,
        Information,
        Warning,
        Error
    }
}
