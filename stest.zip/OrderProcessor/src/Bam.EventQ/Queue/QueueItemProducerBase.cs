﻿using System;
using System.Threading;
using Bam.EventQ.Diagnostics;

namespace Bam.EventQ.Queue
{
    public abstract class QueueItemProducerBase<TItem> : IQueueItemProducer<TItem>
    {
        private readonly ManualResetEventSlim _startedEvent;
        private bool _stopped;

        protected QueueItemProducerBase()
        {
            _startedEvent = new ManualResetEventSlim(false);
        }

        public ILogger Logger { get; set; }
        protected IQueue<TItem> Queue { get; private set; }
        protected WaitHandle Started => _startedEvent.WaitHandle;
        protected bool Stopped => Volatile.Read(ref _stopped);

        public virtual void Initialize(IQueue<TItem> queue)
        {
            Queue = queue;
        }

        public virtual void Start()
        {
            _startedEvent.Set();
        }

        public virtual void Stop()
        {
            Volatile.Write(ref _stopped, true);
            _startedEvent.Reset();
        }

        public virtual bool CanPause => false;

        public virtual void Pause()
        {
            throw new NotImplementedException();
        }

        public virtual void Resume()
        {
            throw new NotImplementedException();
        }
    }
}
