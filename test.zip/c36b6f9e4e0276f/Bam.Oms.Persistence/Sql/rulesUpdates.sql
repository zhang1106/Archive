﻿
declare @ruleId int
declare @policyId int

Select @policyId = (select Id from [OrderGateway].[cp].[Policy2]  where Name = 'Firm Position Limit Policy')

--1--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Australia: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"}, "0.05":{"LowLimit":0.05,"UpLimit":null,"SubsequentChange":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"AU","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 --2--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Austria: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03,"AlertLevel":"Overrideable"},"0.03":{"LowLimit":0.03,"UpLimit":0.04,"AlertLevel":"ComplianceOverrideable"},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"ComplianceOverrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"} ,"0.25":{"LowLimit":0.25,"UpLimit":0.26,"AlertLevel":"ComplianceOverrideable"},"0.26":{"LowLimit":0.26,"UpLimit":0.30,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.35,"AlertLevel":"ComplianceOverrideable"},"0.35":{"LowLimit":0.35,"UpLimit":0.40,"AlertLevel":"ComplianceOverrideable"},"0.40":{"LowLimit":0.40,"UpLimit":0.45,"AlertLevel":"ComplianceOverrideable"},"0.45":{"LowLimit":0.45,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.75,"AlertLevel":"ComplianceOverrideable"},"0.75":{"LowLimit":0.75,"UpLimit":0.90,"AlertLevel":"ComplianceOverrideable"},"0.90":{"LowLimit":0.90,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"AT","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 --3--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Belgium: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.1,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.1,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.2,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.30,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.6666,"AlertLevel":"ComplianceOverrideable"},"0.6666":{"LowLimit":0.6666,"UpLimit":null,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"BE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

  --4--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Brazil: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"BR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 --5--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Bulgaria: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"BG","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId


 --7--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Canada: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.09}, "0.09":{"LowLimit":0.09, "UpLimit":0.10,"AlertLevel":"Overrideable"}, "0.10":{"LowLimit":0.10, "SubsequentChange":0.025,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"CA","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 --8--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Canada: Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04}, "0.04":{"LowLimit":0.04, "UpLimit":0.05,"AlertLevel":"Overrideable"}, "0.05":{"LowLimit":0.05,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"ISIN","Value":"TAKEOVERCAOFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 --9--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Cayman Islands: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.14}, "0.14":{"LowLimit":0.14, "UpLimit":0.15,"AlertLevel":"Overrideable"}, "0.15":{"LowLimit":0.15, "SubsequentChange":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"KY","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 --12--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Denmark: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04, "UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"DK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 --13--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Finland: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.30,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.66,"AlertLevel":"ComplianceOverrideable"},"0.66":{"LowLimit":0.66,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"FI","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 --14--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'France:Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05, "SubsequentChange":0.05,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"ISIN","Value":"TAKEOVERFROFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

  --15--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'France: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.30,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.3333,"AlertLevel":"ComplianceOverrideable"},"0.33":{"LowLimit":0.3333,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.6666,"AlertLevel":"ComplianceOverrideable"},"0.6666":{"LowLimit":0.6666,"UpLimit":0.90,"AlertLevel":"ComplianceOverrideable"},"0.90":{"LowLimit":0.90,"UpLimit":0.95,"AlertLevel":"ComplianceOverrideable"},"0.95":{"LowLimit":0.95,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"FR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

   --16--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Germany: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03,"AlertLevel":"Overrideable"},"0.03":{"LowLimit":0.03,"UpLimit":0.05,"AlertLevel":"ComplianceOverrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.39,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.70,"AlertLevel":"ComplianceOverrideable"},"0.70":{"LowLimit":0.70,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"DE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

    --17--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Greece: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.3333,"AlertLevel":"ComplianceOverrideable"},"0.33":{"LowLimit":0.3333,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.6666,"AlertLevel":"ComplianceOverrideable"},"0.66":{"LowLimit":0.6666,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"GR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

  --44--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Greece: Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.004},"0.004":{"LowLimit":0.004,"UpLimit":0.005,"AlertLevel":"Overrideable"},"0.005":{"LowLimit":0.005,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Isin","Value":"TAKEOVERGROFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

    --18--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Hong Kong: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"IncludeConstituent":true,"IncludeAdr":true,"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"HK","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

    --19--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Hong Kong: Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"IncludeConstituent":true,"IncludeAdr":true,"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"ISIN","Value":"TAKEOVERHKOFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

     --20--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Ireland: Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.007},"0.007":{"LowLimit":0.007,"UpLimit":0.01,"AlertLevel":"Overrideable"},"0.01":{"LowLimit":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"ISIN","Value":"TAKEOVERIEOFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
 
       --22--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Italy: Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0125},"0.0125":{"LowLimit":0.0125,"UpLimit":0.02,"AlertLevel":"Overrideable"},"0.02":{"LowLimit":0.02,"UpLimit":0.03,"AlertLevel":"ComplianceOverrideable"},"0.03":{"LowLimit":0.03,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"ISIN","Value":"TAKEOVERITOFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

       --23--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Italy: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0125},"0.0125":{"LowLimit":0.0125,"UpLimit":0.02,"AlertLevel":"Overrideable"},"0.02":{"LowLimit":0.02,"UpLimit":0.05,"AlertLevel":"ComplianceOverrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.30,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.35,"AlertLevel":"ComplianceOverrideable"},"0.35":{"LowLimit":0.35,"UpLimit":0.40,"AlertLevel":"ComplianceOverrideable"},"0.40":{"LowLimit":0.40,"UpLimit":0.45,"AlertLevel":"ComplianceOverrideable"},"0.45":{"LowLimit":0.45,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.6666,"AlertLevel":"ComplianceOverrideable"},"0.66":{"LowLimit":0.6666,"UpLimit":0.75,"AlertLevel":"ComplianceOverrideable"},"0.75":{"LowLimit":0.75,"UpLimit":0.90,"AlertLevel":"ComplianceOverrideable"},"0.90":{"LowLimit":0.90,"UpLimit":0.95,"AlertLevel":"ComplianceOverrideable"},"0.95":{"LowLimit":0.95,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"IT","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

        --24--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Japan: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05, "SubsequentChange":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"JP","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
         
		 --25--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Luxembourg: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.3334,"AlertLevel":"ComplianceOverrideable"},"0.33":{"LowLimit":0.3334,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.6667,"AlertLevel":"ComplianceOverrideable"},"0.66":{"LowLimit":0.6667,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"LU","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
  
     	--28--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Netherlands: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03,"AlertLevel":"Overrideable"},"0.03":{"LowLimit":0.03,"UpLimit":0.05,"AlertLevel":"ComplianceOverrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.30,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.40,"AlertLevel":"ComplianceOverrideable"},"0.40":{"LowLimit":0.40,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.60,"AlertLevel":"ComplianceOverrideable"},"0.60":{"LowLimit":0.60,"UpLimit":0.75,"AlertLevel":"ComplianceOverrideable"},"0.75":{"LowLimit":0.75,"UpLimit":0.95,"AlertLevel":"ComplianceOverrideable"},"0.95":{"LowLimit":0.95,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"NL","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

      	--29--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'New Zealand: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"NZ","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

       	--30--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Norway: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.3333,"AlertLevel":"ComplianceOverrideable"},"0.33":{"LowLimit":0.3333,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.6666,"AlertLevel":"ComplianceOverrideable"},"0.66":{"LowLimit":0.6666,"UpLimit":0.90,"AlertLevel":"ComplianceOverrideable"},"0.90":{"LowLimit":0.90,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"NO","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

       	--31--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Singapore: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"SG","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
        
		--32--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'South Korea: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"SubsequentChange":0.01,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"SubsequentChange":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"KR","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 		--33--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Spain: Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.007},"0.007":{"LowLimit":0.007,"UpLimit":0.01,"AlertLevel":"Overrideable"},"0.01":{"LowLimit":0.01,"UpLimit":0.03,"AlertLevel":"ComplianceOverrideable"},"0.03":{"LowLimit":0.03,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"ISIN","Value":"TAKEOVERESOFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

  		--34--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Spain: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03,"AlertLevel":"Overrideable"},"0.03":{"LowLimit":0.03,"UpLimit":0.05,"AlertLevel":"ComplianceOverrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.30,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.35,"AlertLevel":"ComplianceOverrideable"},"0.35":{"LowLimit":0.35,"UpLimit":0.40,"AlertLevel":"ComplianceOverrideable"},"0.40":{"LowLimit":0.40,"UpLimit":0.45,"AlertLevel":"ComplianceOverrideable"},"0.45":{"LowLimit":0.45,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.60,"AlertLevel":"ComplianceOverrideable"},"0.60":{"LowLimit":0.60,"UpLimit":0.70,"AlertLevel":"ComplianceOverrideable"},"0.70":{"LowLimit":0.70,"UpLimit":0.75,"AlertLevel":"ComplianceOverrideable"},"0.75":{"LowLimit":0.75,"UpLimit":0.80,"AlertLevel":"ComplianceOverrideable"},"0.80":{"LowLimit":0.80,"UpLimit":0.90,"AlertLevel":"ComplianceOverrideable"},"0.90":{"LowLimit":0.90,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"ES","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

   		--35--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Sweden: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.30,"AlertLevel":"ComplianceOverrideable"},"0.30":{"LowLimit":0.30,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.6666,"AlertLevel":"ComplianceOverrideable"},"0.66":{"LowLimit":0.6666,"UpLimit":0.90,"AlertLevel":"ComplianceOverrideable"},"0.90":{"LowLimit":0.90,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"SE","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
    	
		--36--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Switzerland: Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03,"AlertLevel":"Overrideable"},"0.03":{"LowLimit":0.03,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"ISIN","Value":"TAKEOVERCHOFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 		--37--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Switzerland: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03,"AlertLevel":"Overrideable"},"0.03":{"LowLimit":0.03,"UpLimit":0.05,"AlertLevel":"ComplianceOverrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.10,"AlertLevel":"ComplianceOverrideable"},"0.10":{"LowLimit":0.10,"UpLimit":0.15,"AlertLevel":"ComplianceOverrideable"},"0.15":{"LowLimit":0.15,"UpLimit":0.20,"AlertLevel":"ComplianceOverrideable"},"0.20":{"LowLimit":0.20,"UpLimit":0.25,"AlertLevel":"ComplianceOverrideable"},"0.25":{"LowLimit":0.25,"UpLimit":0.3333,"AlertLevel":"ComplianceOverrideable"},"0.33":{"LowLimit":0.3333,"UpLimit":0.50,"AlertLevel":"ComplianceOverrideable"},"0.50":{"LowLimit":0.50,"UpLimit":0.6666,"AlertLevel":"ComplianceOverrideable"},"0.66":{"LowLimit":0.6666,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Country","Value":"CH","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

  		--38--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'United Kingdom: Takeover Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.007},"0.007":{"LowLimit":0.007,"UpLimit":0.01,"AlertLevel":"Overrideable"},"0.01":{"LowLimit":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"ISIN","Value":"TAKEOVERUKOFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
  
  		--39--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'United Kingdom: Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.0225},"0.0225":{"LowLimit":0.0225,"UpLimit":0.03,"AlertLevel":"Overrideable"},"0.03":{"LowLimit":0.03,"SubsequentChange":0.01,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"Country","Value":"GB","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"BeneficialOwnershipSecTypes","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

 	  --40--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'United States: Long Ownership Filing (13G)'  

 Update r
 Set 
 ParamsInJson = '{"OwnershipType":"LONG","Threshholds":{"0":{"UpLimit":0.04},"0.04":{"LowLimit":0.04,"UpLimit":0.05,"AlertLevel":"Overrideable"},"0.05":{"LowLimit":0.05,"UpLimit":0.09,"AlertLevel":"ComplianceOverrideable"},"0.09":{"LowLimit":0.09,"UpLimit":0.098,"AlertLevel":"ComplianceOverrideable"},"0.098":{"LowLimit":0.098,"UpLimit":null,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"Country","Value":"US","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"BamSymbol","Value":"OIH","Type":null,"Operator":{"OperatorType":"NotEqual"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

  	  --41--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'ETF Long Ownership Filing'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"LowLimit":null,"UpLimit":0.02},"0.02":{"LowLimit":0.02,"UpLimit":0.03,"AlertLevel":"Overrideable"},"0.03":{"LowLimit":0.03,"AlertLevel":"ComplianceOverrideable"}}, "FilterParams":[{"Property":"InvestmentType","Value":"ETF","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

   	  --42--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'REITs Ownership Restriction(Long)'  

 Update r
 Set 
 ParamsInJson = '{"IncludeConstituent":false, "OwnerShipType":"NetLong","Entity":"FIRM","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.045,"AlertLevel":"Overrideable"},"0.045":{"LowLimit":0.045,"AlertLevel":"ComplianceOverrideable"}}, "FilterParams":[{"Property":"Industry","Value":"REIT","Type":null,"Operator":{"OperatorType":"Contains"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

      --43--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'REITs Ownership Restriction(Short)'  

 Update r
 Set 
 Type = 'Bam.Oms.Compliance.Rules.ShortOwnershipFiling',
 ParamsInJson = '{"IncludeConstituent":false, "OwnerShipType":"NetShort","Entity":"FIRM","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.03},"0.03":{"LowLimit":0.03,"UpLimit":0.045,"AlertLevel":"Overrideable"},"0.045":{"LowLimit":0.045,"AlertLevel":"ComplianceOverrideable"}}, "FilterParams":[{"Property":"Industry","Value":"REIT","Type":null,"Operator":{"OperatorType":"Contains"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
    

       --45--
 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = ' Potential Takeover Rule'  

 Update r
 Set 
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.004},"0.004":{"LowLimit":0.004,"UpLimit":0.005,"AlertLevel":"Overrideable"},"0.005":{"LowLimit":0.005,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"Isin","Value":"TAKEOVERPTCOFFERLIST","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId

        --46--
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule2] where Name = 'European Union: Short Ownership Filing (BAM)'))
Begin
  Insert Into [OrderGateway].[cp].[Rule2]
  Values ('European Union: Short Ownership Filing (BAM)', 'Bam.Oms.Compliance.Rules.ShortOwnershipFiling', 'Eu Short', 1, '1-1-2015', '1-1-2020', 
'{"CheckBy":"ISIN","IncludeConstituent":true,"Ratio":{"AQTF":0.20,"MAIN":0.80}, "Entity":"BAM","OwnershipType":"NETSHORT","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.0045},"0.0045":{"LowLimit":0.0045,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"EuIsinList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule2] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule2]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'European Union: Short Ownership Filing (BAM)'  

 Update r
 Set 
 ParamsInJson = '{"CheckBy":"ISIN","IncludeConstituent":true,"Ratio":{"AQTF":0.20,"MAIN":0.80}, "Entity":"BAM","OwnershipType":"NETSHORT","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.0045},"0.0045":{"LowLimit":0.0045,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"EuIsinList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
End

       --47--
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule2] where Name = 'European Union: Short Ownership Filing (BAMHK)'))
Begin
  Insert Into [OrderGateway].[cp].[Rule2]
  Values ('European Union: Short Ownership Filing (BAMHK)', 'Bam.Oms.Compliance.Rules.ShortOwnershipFiling', 'Eu Short', 1, '1-1-2015', '1-1-2020', 
'{"CheckBy":"ISIN","IncludeConstituent":true,"Ratio":{"AQTF":0.20,"MAIN":0.80}, "Entity":"BAM HK","OwnershipType":"NETSHORT","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.0045},"0.0045":{"LowLimit":0.0045,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"EuIsinList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule2] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule2]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'European Union: Short Ownership Filing (BAMHK)'  

 Update r
 Set 
 ParamsInJson = '{"CheckBy":"ISIN","IncludeConstituent":true,"Ratio":{"AQTF":0.20,"MAIN":0.80},"Entity":"BAM HK","OwnershipType":"NETSHORT","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.0045},"0.0045":{"LowLimit":0.0045,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"EuIsinList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
End

       --48--
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule2] where Name = 'European Union: Short Ownership Filing (BEAM)'))
Begin
  Insert Into [OrderGateway].[cp].[Rule2]
  Values ('European Union: Short Ownership Filing (BEAM)', 'Bam.Oms.Compliance.Rules.ShortOwnershipFiling', 'Eu Short', 1, '1-1-2015', '1-1-2020', 
'{"CheckBy":"ISIN","IncludeConstituent":true,"Ratio":{"AQTF":0.20,"MAIN":0.80},"Entity":"BEAM","OwnershipType":"NETSHORT","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.0045},"0.0045":{"LowLimit":0.0045,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"EuIsinList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule2] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule2]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'European Union: Short Ownership Filing (BEAM)'  

 Update r
 Set 
 ParamsInJson = '{"CheckBy":"ISIN","IncludeConstituent":true,"Ratio":{"AQTF":0.20,"MAIN":0.80},"Entity":"BEAM","OwnershipType":"NETSHORT","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.0045},"0.0045":{"LowLimit":0.0045,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"EuIsinList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
End

       --49--
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule2] where Name = 'European Union: Short Ownership Filing (BAMSG)'))
Begin
  Insert Into [OrderGateway].[cp].[Rule2]
  Values ('European Union: Short Ownership Filing (BAMSG)', 'Bam.Oms.Compliance.Rules.ShortOwnershipFiling', 'Eu Short', 1, '1-1-2015', '1-1-2020', 
'{"CheckBy":"ISIN","IncludeConstituent":true,"Ratio":{"AQTF":0.20,"MAIN":0.80},"Entity":"BAM SG","OwnershipType":"NETSHORT","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.0045},"0.0045":{"LowLimit":0.0045,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"EuIsinList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule2] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule2]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'European Union: Short Ownership Filing (BAMSG)'  

 Update r
 Set 
 ParamsInJson = '{"CheckBy":"ISIN","IncludeConstituent":true,"Ratio":{"AQTF":0.20,"MAIN":0.80},"Entity":"BAM SG","OwnershipType":"NETSHORT","Threshholds":{"0":{"LowLimit":null,"UpLimit":0.0045},"0.0045":{"LowLimit":0.0045,"AlertLevel":"ComplianceOverrideable"}},"FilterParams":[{"Property":"SecurityType","Value":"Equity","Type":null,"Operator":{"OperatorType":"Equal"}},{"Property":"ISIN","Value":"EuIsinList","Type":null,"Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
End

--50--
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule2] where Name = 'Hong Kong: 30m Short Rule'))
Begin
  Insert Into [OrderGateway].[cp].[Rule2]
  Values ('Hong Kong: 30m Short Rule', 'Bam.Oms.Compliance.Rules.NetownershipLimit', 'HK 30m', 0, '1-1-2015', '1-1-2020', 
  '{"OwnerShipType":"NetLong","IncludeConstituent":true,"Threshhold":-30000000,"ThreshHoldType":"LocalCurrency", "Currency":"HKD", "FilterParams":[{"Property":"Country","Value":"Hk","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule2] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule2]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'Hong Kong: 30m Short Rule'  
 Update r
 Set 
 r.IsActive = 0,
 ParamsInJson = '{"OwnerShipType":"NetLong","IncludeConstituent":true,"Threshhold":-30000000,"ThreshHoldType":"LocalCurrency", "Currency":"HKD", "FilterParams":[{"Property":"Country","Value":"Hk","Type":null,"Operator":{"OperatorType":"Equal"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
End


--53--
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule2] where Name = '4.5% Long Ownerhsip Rule'))
Begin
  Insert Into [OrderGateway].[cp].[Rule2]
  Values ('4.5% Long Ownerhsip Rule', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', '4.5% Long Ownership Limit', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.045},"0.045":{"LowLimit":0.045, "AlertLevel":"ComplianceOverrideable"}}, "FilterParams":[{"Property":"BamSymbol","Value":"4.5%LongList","Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule2] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule2]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = '4.5% Long Ownerhsip Rule'  
 Update r
 Set 
 IsActive = 1,
 Type='Bam.Oms.Compliance.Rules.LongOwnerShipFiling',
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.045},"0.045":{"LowLimit":0.045, "AlertLevel":"ComplianceOverrideable"}}, "FilterParams":[{"Property":"BamSymbol","Value":"4.5%LongList","Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
END

--54--
IF (Not Exists (select 1 from  [OrderGateway].[cp].[Rule2] where Name = '4.9% Long Ownerhsip Rule'))
Begin
  Insert Into [OrderGateway].[cp].[Rule2]
  Values ('4.9% Long Ownerhsip Rule', 'Bam.Oms.Compliance.Rules.LongOwnerShipFiling', '4.9% Long Ownership Limit', 1, '1-1-2015', '1-1-2020', 
'{"Threshholds":{"0":{"UpLimit":0.049},"0.049":{"LowLimit":0.049, "AlertLevel":"ComplianceOverrideable"}}, "FilterParams":[{"Property":"BamSymbol","Value":"4.9%LongList","Operator":{"OperatorType":"InTheList"}}]}'
,getdate(), 'dev', getdate(), 'dev')
	
	Select @ruleId = @@Identity;
	If (Not Exists (Select 1 from [OrderGateway].[cp].[PolicyRule2] where ruleId = @ruleId and PolicyId = @policyId))
	Begin
	  Insert Into [OrderGateway].[cp].[PolicyRule2]
	  Values (@policyId, @ruleId, getdate(), 'dev')
	End
End
Else
Begin
Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = '4.9% Long Ownerhsip Rule'  
 Update r
 Set 
 Type='Bam.Oms.Compliance.Rules.LongOwnerShipFiling',
 IsActive = 1,
 ParamsInJson = '{"Threshholds":{"0":{"UpLimit":0.049},"0.049":{"LowLimit":0.049, "AlertLevel":"ComplianceOverrideable"}}, "FilterParams":[{"Property":"BamSymbol","Value":"4.9%LongList","Operator":{"OperatorType":"InTheList"}}]}'
 From [OrderGateway].[cp].[Rule2] r
 where  Id = @ruleId
END

--add list
IF(NOT EXISTS(SELECT 1 FROM [OrderGateway].[cp].[Fact] WHERE name='4.5%LongList'))
BEGIN
	INSERT INTO [OrderGateway].[cp].[Fact]
	values ('4.5%LongList', 'KATE,AA,SHAK', GETDATE(), 'dev', GETDATE(), 'dev')
END
ELSE
BEGIN
Update f
set f.Value='KATE,AA,SHAK'
From [OrderGateway].[cp].[Fact] f
Where name = '4.5%LongList'
END
  
IF(NOT EXISTS(SELECT 1 FROM [OrderGateway].[cp].[Fact] WHERE name='4.9%LongList'))
BEGIN
	INSERT INTO [OrderGateway].[cp].[Fact]
	values ('4.9%LongList', 'OLN', GETDATE(), 'dev', GETDATE(), 'dev')
End
BEGIN
Update f
set f.Value='OLN'
From [OrderGateway].[cp].[Fact] f
Where name = '4.9%LongList'
END
  

 --remove extra rules
 IF (Exists (select 1 from  [OrderGateway].[cp].[Rule2] where Name = 'BWP Ownership Limit Filing'))
 Begin
	 Select @ruleId = Id from [OrderGateway].[cp].[Rule2] where Name = 'BWP Ownership Limit Filing'
 
	 delete p 
	 from [OrderGateway].cp.PolicyRule p where policyId = @policyId and ruleId = @ruleId
  

	 Delete r
	 From [OrderGateway].[cp].[Rule2] r
	 where  id = @ruleId
 End
