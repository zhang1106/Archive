﻿using System;
using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public class HeadroomEffectCache : IHeadroomEffectCache
    {
        private readonly Dictionary<HeadroomEffectKey, HeadroomEffects> _effects
            = new Dictionary<HeadroomEffectKey, HeadroomEffects>();

        public HeadroomEffects GetEffect(long orderId, int ruleId, string identifier)
        {
            var key = new HeadroomEffectKey(orderId, ruleId, identifier);

            HeadroomEffects effect;
            if (!_effects.TryGetValue(key, out effect))
            {
                effect = default(HeadroomEffects);
            }

            return effect;
        }

        public void SetEffect(long orderId, int ruleId, string identifier, HeadroomEffects effect)
        {
            var key = new HeadroomEffectKey(orderId, ruleId, identifier);
            _effects[key] = effect;
        }

        public void Reset(long orderId, int ruleId, string identifier)
        {
            var key = new HeadroomEffectKey(orderId, ruleId, identifier);
            _effects.Remove(key);
        }

        private struct HeadroomEffectKey : IEquatable<HeadroomEffectKey>
        {
            public static bool operator ==(HeadroomEffectKey left, HeadroomEffectKey right)
            {
                return left.Equals(right);
            }

            public static bool operator !=(HeadroomEffectKey left, HeadroomEffectKey right)
            {
                return !left.Equals(right);
            }

            private long OrderId { get; }
            private int RuleId { get; }
            private string Identifier { get; }

            public HeadroomEffectKey(long orderId, int ruleId, string identifier)
            {
                OrderId = orderId;
                RuleId = ruleId;
                Identifier = identifier;
            }

            public bool Equals(HeadroomEffectKey other)
            {
                return OrderId == other.OrderId && RuleId == other.RuleId && string.Equals(Identifier, other.Identifier);
            }

            public override bool Equals(object obj)
            {
                if (ReferenceEquals(null, obj)) return false;
                return obj is HeadroomEffectKey && Equals((HeadroomEffectKey)obj);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    var hashCode = OrderId.GetHashCode();
                    hashCode = (hashCode * 397) ^ RuleId;
                    hashCode = (hashCode * 397) ^ (Identifier != null ? Identifier.GetHashCode() : 0);
                    return hashCode;
                }
            }
        }
    }
}