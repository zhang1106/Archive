﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Bam.Oms.Compliance.TestPosition.Models
{
    public class PositionModels
    { 
    //{
    //    [DataType(DataType.MultilineText)]
    //    public   string JsonPosition => "{" +
    //                                  "\"RefreshTime\": \"2016-1-1\"," +
    //                                  "\"Positions\":" +
    //                                  $"[{{\"SecurityId\": {SecurityId},\"Quantity\": {Quantity},\"LastModified\": \"2016-1-1\"}} ]," +
    //                                  "\"Securities\":" +
    //                                  $"[{{\"MarketDataInfo\": {{\"SharesOutstanding\": {ShareOutsanding}}},\"SecurityId\": {SecurityId},\"AssetType\": \"{AssetType}\",\"DisplayCode\": \"{DisplayCode}\",\"UnderlyingSecurityId\": {UnderlyingSecurityId}}}]" +
    //                                  "}";
        public  int SecurityId { get; set; }
        public   int Quantity { get; set; }
        public   int ShareOutsanding { get; set; }
        public   string AssetType { get; set; }
        public   string DisplayCode { get; set; }
        public   int? UnderlyingSecurityId { get; set; }

        public   string Industry { get; set; }

        public void Clone(PositionModels model)
        {
            SecurityId = model.SecurityId;
            Quantity = model.Quantity;
            ShareOutsanding = model.ShareOutsanding;
            AssetType = model.AssetType;
            DisplayCode = model.DisplayCode;
            UnderlyingSecurityId = model.UnderlyingSecurityId;
            Industry = model.Industry;
        }

        public PositionModels()
        {
            SecurityId = 214;
            Quantity = 210;
            ShareOutsanding = 10000;
            AssetType = "ETF";
            DisplayCode = "SIL";
            Industry = "REITs";
        }

        public PositionMock GetDataMock()
        {
            var mock = new PositionMock
            {
                Securities = new List<Security>(),
                Positions = new List<Position>()
            };
            var marketInfo = new MarketDataInfo()
            {
                SharesOutstanding = this.ShareOutsanding
            };
            var security = new Security()
            {
                SecurityId = this.SecurityId,
                DisplayCode = this.DisplayCode,
                MarketDataInfo = marketInfo,
            };
            var pos = new Position()
            {
                SecurityId = this.SecurityId,
                Quantity = this.Quantity
            };
            mock.Securities.Add(security);
            mock.Positions.Add(pos);
            return mock;
        }


 
    }
}