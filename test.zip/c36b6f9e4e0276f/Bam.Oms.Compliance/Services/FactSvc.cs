﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance.Services
{
    public class FactSvc:IFactSvc
    {
        private readonly IFactRepository _factRepository;
        public FactSvc (IFactRepository factRepository)
        {
            _factRepository = factRepository;
        }

        public IList<Fact> GetAll()
        {
            return _factRepository.GetAll().ToList();
        }

        public Fact Get(int id)
        {
            return _factRepository.GetById(id);
        }

        public void Save(Fact fact)
        {
            _factRepository.Update(fact);
        }
    }
}
