﻿using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Results
{
    public class OwnershipLimitResult : RuleResult 
    {
        public decimal? Limit { get; set; }
        public override string ToString()
        {
            return
                $"Policly:{PolicyId},RuleName:{RuleName},Limit:{Limit},PositionQty:{PositionQty}";
        }
    }
}
