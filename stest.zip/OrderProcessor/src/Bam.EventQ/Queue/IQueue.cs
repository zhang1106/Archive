﻿using System;

namespace Bam.EventQ.Queue
{
    public interface IQueue<out TItem>
    {
        QueueSlotBatch AllocateBatch(int size);
        void PublishBatch(QueueSlotBatch batch);
        TItem this[long sequence] { get; }

        void AddErrorHandler(IQueueErrorHandler handler);
        void AddSubscriptionChain(params IQueueItemHandler<TItem>[] handlers);

        bool ReplayMessages(Predicate<TItem> startPredicate, Predicate<TItem> filterPredicate,
            IQueueItemHandler<TItem> replayHandler);

        void Start();
        void Stop();
        bool IsAvailable(QueueSlotBatch range);
        bool HasBacklog();

        long Capacity { get; }
        long Count { get; }
        long MaxSequence { get; }
    }
}
