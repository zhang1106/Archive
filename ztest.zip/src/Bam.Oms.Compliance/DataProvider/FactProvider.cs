﻿using System.Collections.Generic;
using System.IO;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance.DataProvider
{
    //need rewrite
    public class FactProvider : IFactProvider
    {
       private readonly IFactRepository _factRepository;
       private Dictionary<string, HashSet<string>> _factList;
          
       public FactProvider(IFactRepository factRepository)
       {
           _factRepository = factRepository;
       }
       public void RefreshData()
       {
            var list = _factRepository.GetAll();
            _factList = new Dictionary<string, HashSet<string>>();
            foreach (var fact in list)
            {
                if (_factList.ContainsKey(fact.Name)) continue;
                _factList.Add(fact.Name, fact.GetList());
            }
       }
       public HashSet<string> GetList(string name)
       {
           if (_factList.ContainsKey(name)) return _factList[name];
           return new HashSet<string>();
       }
    }
}
