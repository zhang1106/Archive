﻿using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.PositionTracker;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public class OrderStrategyAllocation : ModelBase<IMessage>
    {
        private readonly Dictionary<PositionAllocationKey, long> _actualAllocations;
        private readonly Dictionary<PositionAllocationKey, long> _theoreticalAllocations;

        private readonly HashSet<PositionAllocationKey> _actualKeys;
        private readonly HashSet<PositionAllocationKey> _theoreticalKeys;

        public OrderStrategyAllocation(Order order, PositionKey key)
        {
            Order = order;
            Key = key;

            _actualAllocations = new Dictionary<PositionAllocationKey, long>();
            _theoreticalAllocations = new Dictionary<PositionAllocationKey, long>();
            _actualKeys = new HashSet<PositionAllocationKey>();
            _theoreticalKeys = new HashSet<PositionAllocationKey>();
        }

        public Order Order { get; }
        public PositionKey Key { get; }
        public long Size { get; private set; }
        public long FilledQuantity { get; private set; }

        public IReadOnlyDictionary<PositionAllocationKey, long> ActualAllocations => _actualAllocations;
        public IReadOnlyDictionary<PositionAllocationKey, long> TheoreticalAllocations => _theoreticalAllocations;

        public OrderStrategyAllocation Clone(Order clonedOrder)
        {
            var clone = new OrderStrategyAllocation(clonedOrder, Key);

            foreach (var key in _actualKeys)
            {
                clone._actualKeys.Add(key);
                long value;
                if (_actualAllocations.TryGetValue(key, out value))
                {
                    clone._actualAllocations[key] = value;
                }
            }

            foreach (var key in _theoreticalKeys)
            {
                clone._theoreticalKeys.Add(key);
                long value;
                if (_theoreticalAllocations.TryGetValue(key, out value))
                {
                    clone._theoreticalAllocations[key] = value;
                }
            }

            return clone;
        }

        public void ChangeSize(long size)
        {
            if (Size == size)
                return;

            Size = size;

            // pro-rata reallocate to custodians
            long total = 0;
            foreach (var item in _theoreticalAllocations)
            {
                total += item.Value;
            }

            long sum = 0;
            int count = 0;
            foreach (var key in _theoreticalKeys)
            {
                long qty = ++count == _theoreticalAllocations.Count
                    ? Size - sum
                    : (long)(_theoreticalAllocations[key] / (decimal)total * Size);

                sum += qty;
                _theoreticalAllocations[key] = qty;
            }
        }

        public void UpdateActualAllocations(List<OrderAllocation> allocations)
        {
            FilledQuantity = 0;

            foreach (var key in _actualKeys)
            {
                _actualAllocations[key] = 0;
            }

            foreach (var item in allocations)
            {
                FilledQuantity += item.Quantity;
                var key = new PositionAllocationKey(item.FundId, item.CustodianId);

                if (_actualKeys.Add(key))
                {
                    _actualAllocations[key] = item.Quantity;
                }
                else
                {
                    _actualAllocations[key] += item.Quantity;
                }
            }
        }

        public void UpdateTheoreticalAllocations(List<OrderAllocation> allocations)
        {
            foreach (var key in _theoreticalKeys)
            {
                _theoreticalAllocations[key] = 0;
            }

            long total = 0;
            foreach (var item in allocations)
            {
                var key = new PositionAllocationKey(item.FundId, item.CustodianId);

                if (_theoreticalKeys.Add(key))
                {
                    _theoreticalAllocations[key] = item.Quantity;
                }
                else
                {
                    _theoreticalAllocations[key] += item.Quantity;
                }

                total += item.Quantity;
            }

            Size = total;
        }

        public void ApplyEffects(PositionSet set, IPositionEffectCache cache, IPositionEffectCalculator calculator)
        {
            ApplyComplianceEffect(set, cache, calculator);
            ApplyTheoreticalEffects(set, cache, calculator);
            ApplyActualEffects(set, cache, calculator);
        }

        private void ApplyComplianceEffect(PositionSet set, IPositionEffectCache cache, IPositionEffectCalculator calculator)
        {
            var info = new OrderInfo
            {
                FillQuantity = FilledQuantity,
                IsLive = Order.IsLive,
                IsDead = Order.IsDead,
                OrderSize = Size,
                Side = Order.Side,
                IsOmni = Order.IsOmni,
            };

            // What was the previous effect?
            var previousEffects = cache.GetComplianceEffects(new EffectKey(Order.OrderId, Key));

            // What's the current effect?
            var effects = calculator.CalculateComplianceEffects(info);

            // Apply the delta
            var delta = effects - previousEffects;

            delta.Apply(set);

            // Memorize last effect
            cache.SetComplianceEffects(new EffectKey(Order.OrderId, Key), effects);
        }

        private void ApplyActualEffects(PositionSet set, IPositionEffectCache cache, IPositionEffectCalculator calculator)
        {
            var actualEffects = new Dictionary<PositionAllocationKey, long>();
            foreach (var allocKey in _actualKeys)
            {
                long actual;
                if (!_actualAllocations.TryGetValue(allocKey, out actual))
                {
                    _actualKeys.Add(allocKey);
                    actual = 0;
                }

                var allocInfo = new AllocationInfo
                {
                    Side = Order.Side,
                    FundId = allocKey.FundId,
                    FillQuantity = actual,
                    TotalQuantity = 0, // this is not used by the algo
                    IsLive = Order.IsLive,
                    IsDead = Order.IsDead,
                };

                // What was the previous effect?
                var prevAllocEffects = cache.GetActualEffects(new EffectKey(Order.OrderId, Key), allocKey);

                // What's the current effect?
                var allocEffects = calculator.CalculateActualEffects(allocInfo);

                // Apply the delta
                var delta = allocEffects - prevAllocEffects;
                actualEffects[allocKey] = delta.Quantity;

                // Memorize last effect
                cache.SetActualEffects(new EffectKey(Order.OrderId, Key), allocKey, allocEffects);
            }

            set.Position.ApplyActualQuantityEffect(actualEffects);
        }

        private void ApplyTheoreticalEffects(PositionSet set, IPositionEffectCache cache, IPositionEffectCalculator calculator)
        {
            var theoreticalEffects = new Dictionary<PositionAllocationKey, long>();
            foreach (var key in _theoreticalKeys)
            {
                long theoretical;
                if (!_theoreticalAllocations.TryGetValue(key, out theoretical))
                {
                    _theoreticalKeys.Add(key);
                    theoretical = 0;
                }

                long actual;
                if (!_actualAllocations.TryGetValue(key, out actual))
                {
                    _actualKeys.Add(key);
                    actual = 0;
                }

                var allocInfo = new AllocationInfo
                {
                    Side = Order.Side,
                    FundId = -1,
                    FillQuantity = actual,
                    TotalQuantity = theoretical,
                    IsLive = Order.IsLive,
                    IsDead = Order.IsDead,
                };

                // What was the previous effect?
                var prevAllocEffects = cache.GetTheoreticalEffects(new EffectKey(Order.OrderId, Key), key);

                // What's the current effect?
                var allocEffects = calculator.CalculateTheoreticalEffects(allocInfo);

                // Apply the delta
                var delta = allocEffects - prevAllocEffects;
                theoreticalEffects[key] = delta.Quantity;

                // Memorize last effect
                cache.SetTheoreticalEffects(new EffectKey(Order.OrderId, Key), key, allocEffects);
            }

            set.Position.ApplyTheoreticalQuantityEffect(theoreticalEffects);
        }
    }
}
