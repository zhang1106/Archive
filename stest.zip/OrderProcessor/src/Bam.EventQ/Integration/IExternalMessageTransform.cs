﻿using System.Collections.Generic;

namespace Bam.EventQ.Integration
{
    public interface IExternalMessageTransform<in TIn, out TOut>
    {
        IEnumerable<TOut> Transform(TIn input);
    }
}
