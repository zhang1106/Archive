﻿using System;
using Bam.Oms.OrderGateway.Compliance.Model;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public struct EffectKey : IEquatable<EffectKey>
    {
        public bool Equals(EffectKey other)
        {
            return OrderId == other.OrderId && PositionKey.Equals(other.PositionKey);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is EffectKey && Equals((EffectKey) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (OrderId.GetHashCode()*397) ^ PositionKey.GetHashCode();
            }
        }

        public static bool operator ==(EffectKey left, EffectKey right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(EffectKey left, EffectKey right)
        {
            return !left.Equals(right);
        }

        public long OrderId { get; }
        public PositionKey PositionKey { get; }

        public EffectKey(long orderId, PositionKey positionKey)
        {
            OrderId = orderId;
            PositionKey = positionKey;
        }
    }
}
