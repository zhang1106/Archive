﻿using System.Threading;
using System.Threading.Tasks;

namespace Bam.EventQ.Sequencing
{
    public interface IAsyncMessageRpcClient<in TIn> where TIn : IMessage
    {
        Task<IMessage> Invoke(TIn input, CancellationToken cancellationToken);
    }
}
