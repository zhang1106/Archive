﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Snapshot;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.ApiGateway.Models.Snapshot;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public class TradeStatusService : ITradeStatusService, ISnapshotRecoverable<TradesSnapshot>
    {
        private readonly HashSet<string> _knownTradeIds;

        public TradeStatusService()
        {
            _knownTradeIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        }

        public TradeStatus GetStatus(string tradeId, long filledQuantity, bool isFinalized)
        {
            bool isNew = _knownTradeIds.Add(tradeId);

            if (filledQuantity == 0 && isFinalized)
                return TradeStatus.Deleted;

            return isNew ? TradeStatus.New : TradeStatus.Modified;
        }

        TradesSnapshot ISnapshotRecoverable<TradesSnapshot>.Persist()
        {
            var snapshot = new TradesSnapshot();
            snapshot.TradeIds.AddRange(_knownTradeIds);
            return snapshot;
        }

        void ISnapshotRecoverable<TradesSnapshot>.Recover(TradesSnapshot snapshot)
        {
            foreach (string id in snapshot.TradeIds)
            {
                _knownTradeIds.Add(id);
            }
        }
    }
}
