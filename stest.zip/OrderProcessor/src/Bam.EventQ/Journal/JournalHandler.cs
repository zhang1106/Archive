﻿using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Journal
{
    public class JournalHandler<TItem> : IQueueItemHandler<PipelineQueueItem<TItem>>
    {
        private readonly IJournal _journal;
        private bool _flushRequired;

        public JournalHandler(IJournal journal)
        {
            _journal = journal;
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            if (!item.IsReplay && item.IsValid)
            {
                _journal.Append(item.Buffer.Array, item.Buffer.Offset, item.Length);
                _flushRequired = true;
            }

            if (endOfBatch && _flushRequired)
            {
                _journal.Flush();
                _flushRequired = false;
            }
        }
    }
}
