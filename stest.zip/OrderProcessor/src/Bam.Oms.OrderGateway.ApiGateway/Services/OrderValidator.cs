using System;
using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Time;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public class OrderValidator : IOrderValidator
    {
        private readonly IReferenceDataService _referenceDataService;
        private readonly IClock _clock;
        private readonly ISecurityCache _securityCache;

        public ILogger Logger { get; set; }

        public OrderValidator(
            IReferenceDataService referenceDataService,
            IClock clock, ISecurityCache securityCache)
        {
            if (referenceDataService == null) throw new ArgumentNullException(nameof(referenceDataService));
            if (clock == null) throw new ArgumentNullException(nameof(clock));
            if (referenceDataService == null) throw new ArgumentNullException(nameof(referenceDataService));

            _referenceDataService = referenceDataService;
            _clock = clock;
            _securityCache = securityCache;
            _referenceDataService = referenceDataService;
        }

        public void ValidateOrders(SubmitOrders orders)
        {
            ValidateStrategies(orders);
        }

        public IList<string> PopulateReferenceData(SubmitOrders orders)
        {
            var missingSecurities = new List<string>();

            foreach (var order in orders.Items)
            {
                CachedSecurity security;
                if (_securityCache.TryGetSecurity(order.Symbol, out security))
                {
                    order.SecurityType = security.SecurityType;
                    order.BloombergSymbol = security.BloombergSymbol;
                    order.UnderlyingSymbol = security.UnderlyingSymbol;
                    order.TradingCurrency = security.TradingCurrency;
                }
                else
                {
                    order.SecurityType = "Unknown";
                    order.StatusMessages.Add("Unable to validate security."); 
                    missingSecurities.Add(order.Symbol);
                }

                int traderId;
                if (!_referenceDataService.TryGetTraderId(orders.User, out traderId))
                {
                    Portfolio portfolio;
                    if (order.SecurityType != "Unknown" && Portfolio.TryParse(order.Portfolio, out portfolio))
                    {
                        var assetType = _referenceDataService.ConvertToCoverageAssetType(
                            security.SecurityType);

                        traderId = _referenceDataService.GetTraderCoverageId(
                            portfolio, security.Currency, assetType);
                    }
                    else
                    {
                        traderId = 0;
                    }
                }

                order.TraderId = traderId;
            }

            SetBusinessDay(orders);
            return missingSecurities;
        }

        private void ValidateStrategies(SubmitOrders orders)
        {
            foreach (var item in orders.Items)
            {
                Portfolio portfolio;
                if (!Portfolio.TryParse(item.Portfolio, out portfolio))
                {
                    item.FailedValidation = true;
                    Logger?.LogError($"Unable to parse strategy '{portfolio}'");
                    continue;
                }

                PortfolioDetails details;
                if (!_referenceDataService.TryGetPortfolioDetails(portfolio, out details))
                {
                    item.FailedValidation = true;
                    Logger?.LogError($"Unable to find strategy '{portfolio}' in reference data cache.");
                }

                StrategyAllocationRule rule;
                if (item.FundAllocationOverride != null &&
                    _referenceDataService.TryGetStrategyAllocationRule(portfolio, out rule))
                {
                    item.FailedValidation = true;
                    Logger?.LogError("Fund override is not supported for split strategies.");
                }
            }
        }

        private void SetBusinessDay(SubmitOrders orders)
        {
            foreach (var order in orders.Items)
            {
                order.Created = _clock.Now;
                order.BusinessDay = _clock.BusinessDate;
            }
        }
    }
}