﻿
namespace Bam.Oms.Compliance
{
    public enum ComplianceViolationLevel
    {
        NotApplicable = -1,
        NoViolation = 0,
        Warning = 1,
        UserOverrideable = 2,
        Violated = 3
    }
}
