﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Configuration;
using Bam.Oms.MarketData.Enumerators;
using BAM.Common.Messaging;
using BAM.Common.Messaging.Publishers;
using BAM.Common.Messaging.Subscribers;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.MarketData
{
    public sealed class MarketDataService : IMarketDataService, IDisposable
    {
        private readonly ISettings _settings;
        private readonly ILogger _logger;
        private IConnection _mqConnection;
        private ISubscriber<SymbolData> _subscriber;
        private IPublisher _publisher;

        private readonly HashSet<string> _subscribedSymbols = new HashSet<string>();

        public MarketDataService(ISettings settings, ILogger logger)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            _settings = settings;
            _logger = logger;
        }

        public void Initialize()
        {
            _mqConnection = new Connection();
            _mqConnection.OnConnected += MqConnectionOnConnected;
            _mqConnection.OnError += MqConnectionOnError;
            _mqConnection.OnDisconnected += MqConnectionOnDisconnected;
            _mqConnection.OnLog += MqConnectionOnLog;
            _mqConnection.Connect(_settings.MqConnectionString);
        }

        public void SendRequest(Request request)
        {
            switch (request.Type)
            {
                case RequestType.Subscribe:
                case RequestType.Snapshot:
                    {
                        foreach (SecurityGroup sg in request.SecurityGroups)
                        {
                            _subscribedSymbols.Add(sg.Security.Id);
                        }
                    }
                    break;
                case RequestType.Unsubscribe:
                    {
                        foreach (SecurityGroup sg in request.SecurityGroups)
                        {
                            _subscribedSymbols.Remove(sg.Security.Id);
                        }
                        break;
                    }
            }
            _publisher.SendMessage(new Message<Request>(request), Mode.Json);

        }

        private void MqConnectionOnLog(string obj)
        {
            _logger.Info(obj);
        }

        private void MqConnectionOnDisconnected()
        {
        }

        private void MqConnectionOnError(string obj)
        {
            _logger.Error(obj);
        }

        public IMarketDataServiceCallbacks Callbacks { get; set; }

        private void MqConnectionOnConnected()
        {
            string marketDataExchange = _settings.MqMarketDataTopic;
            _subscriber = _mqConnection.GetSubscriber<SymbolData>(marketDataExchange, "#");

            _subscriber.OnMessage += MqSubscriberOnMessage;
            _subscriber.OnError += MqSubscriberOnError;
            _subscriber.OnLog += MqSubscriberOnLog;
            _subscriber.Subscribe();

            _publisher = _mqConnection.GetPublisher(_settings.MqMarketDataSubscribeQueue, true);
        }

        private void MqSubscriberOnLog(string obj)
        {
            _logger.Info(obj);
        }

        private void MqSubscriberOnError(string obj)
        {
            _logger.Error(obj);
        }

        private void MqSubscriberOnMessage(Message<SymbolData> obj)
        {
            try
            {
                SymbolData symbolData = obj.Data;
                if (!_subscribedSymbols.Contains(symbolData.Symbol)) return;

                _logger.Debug(symbolData.ToString());
                if (Callbacks != null)
                {
                    QuoteData quoteData = new QuoteData(symbolData.Symbol, SecurityIdSource.Bam,
                        symbolData.LastUpdate.ToLongTimeString(), symbolData.Bid, symbolData.BidSize, symbolData.Ask,
                        symbolData.AskSize, symbolData.Last, symbolData.Volume, symbolData.Change);
                    Callbacks.ProcessData(quoteData);
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Error processing data {obj}.", ex);
            }
        }

        #region IDisposable Support
        private bool _disposedValue; // To detect redundant calls

        private void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {

                    if (_subscriber != null)
                    {
                        _subscriber.UnSubscribe();
                        _subscriber.OnMessage -= MqSubscriberOnMessage;
                        _subscriber.OnError -= MqSubscriberOnError;
                        _subscriber.OnLog -= MqSubscriberOnLog;
                        _subscriber.Dispose();
                    }
                    if (_mqConnection != null)
                    {
                        _mqConnection.Disconnect();
                        _mqConnection.OnConnected -= MqConnectionOnConnected;
                        _mqConnection.OnError -= MqConnectionOnError;
                        _mqConnection.OnDisconnected -= MqConnectionOnDisconnected;
                        _mqConnection.OnLog -= MqConnectionOnLog;
                        _mqConnection.Dispose();
                    }
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                _disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~MarketDataService() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
