﻿namespace Bam.Oms.EMSAdapters.Contracts
{
    public interface IInstructionToEmsTagMapper
    {
        /// <summary>
        /// Takes an instruction code, e.g. Vol, and returns a FIX tag 
        /// </summary>
        /// <param name="instructionCode"></param>
        /// <returns></returns>
        string GetTag(string instructionCode);
    }
}