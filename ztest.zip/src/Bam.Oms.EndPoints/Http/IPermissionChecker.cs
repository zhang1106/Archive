﻿using System;
using System.Web.Http;
using Microsoft.Owin;

namespace Bam.Oms.EndPoints.Http
{
    public interface IPermissionChecker
    {
        HttpConfiguration Config { get;}
        bool IsAllowed(IOwinRequest request);

    }
}
