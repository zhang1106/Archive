﻿using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public struct Mark
    {
        public Side Side { get; set; }
        public long Quantity { get; set; }
    }
}
