﻿using Bam.Oms.Data;

namespace Bam.Oms.Persistence.Orders
{
    public class ClientOrderId : IPersistentItem
    {
        public string Key { get; set; }
        public int CurrentIndex { get; set; }

        public ClientOrderId(string key)
        {
            Key = key;
        }

        public ClientOrderId()
        {
            
        }
    }
}