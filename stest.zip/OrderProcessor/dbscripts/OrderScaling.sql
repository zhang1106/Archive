USE [OrderGatewayMain]
GO

IF COL_LENGTH('[dbo].[OrderScaleFactor]', 'IsActive') IS NULL
	ALTER TABLE [dbo].[OrderScaleFactor]
	ADD [IsActive] [bit] NULL,
	    [LastModifiedBy] [varchar](50) NULL,
	    [LastModifiedOn] [datetime] NULL
GO

UPDATE [dbo].[OrderScaleFactor]
SET [IsActive] = 1
WHERE [IsActive] IS NULL
GO

ALTER TABLE [dbo].[OrderScaleFactor]
ALTER COLUMN [IsActive] [bit] NOT NULL
GO

IF OBJECT_ID('[dbo].[OrderScaleFactorAudit]') IS NOT NULL
	DROP TRIGGER [dbo].[OrderScaleFactorAudit]
GO

IF OBJECT_ID('[dbo].[OrderScaleFactorHistory]') IS NOT NULL
	DROP TABLE [dbo].[OrderScaleFactorHistory]
GO

CREATE TABLE [dbo].[OrderScaleFactorHistory](
    [Action] [char](1) NOT NULL,
	[Id] [int] NOT NULL,
	[SourcePortfolio] [varchar](50) NOT NULL,
	[DestinationPortfolio] [varchar](50) NOT NULL,
	[SecurityType] [varchar](50) NULL,
	[ScaleFactor] [numeric](18, 2) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[LastModifiedBy] [varchar](50) NULL,
	[LastModifiedOn] [datetime] NULL
)
GO

CREATE TRIGGER [dbo].[OrderScaleFactorAudit] ON [dbo].[OrderScaleFactor] FOR UPDATE, DELETE AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Action CHAR(1) = 'U'
	IF NOT EXISTS(SELECT * FROM INSERTED) SET @Action = 'D'
	INSERT INTO [dbo].[OrderScaleFactorHistory]
	([Action], [Id], [SourcePortfolio], [DestinationPortfolio], [SecurityType], [ScaleFactor], [IsActive], [LastModifiedBy], [LastModifiedOn])
	SELECT @Action, * FROM DELETED
END
GO