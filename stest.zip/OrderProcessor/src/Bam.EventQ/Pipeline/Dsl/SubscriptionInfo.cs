﻿using System;

namespace Bam.EventQ.Pipeline.Dsl
{
    public class SubscriptionInfo : IEquatable<SubscriptionInfo>
    {
        public bool Equals(SubscriptionInfo other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return Source == other.Source && Topic == other.Topic;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != GetType()) return false;
            return Equals((SubscriptionInfo) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Source*397) ^ Topic;
            }
        }

        public static bool operator ==(SubscriptionInfo left, SubscriptionInfo right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(SubscriptionInfo left, SubscriptionInfo right)
        {
            return !Equals(left, right);
        }

        public int Source { get; }
        public int Topic { get; }

        public SubscriptionInfo(int source, int topic)
        {
            Source = source;
            Topic = topic;
        }
    }
}
