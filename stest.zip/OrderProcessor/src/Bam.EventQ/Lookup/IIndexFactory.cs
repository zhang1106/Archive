﻿namespace Bam.EventQ.Lookup
{
    public interface IIndexFactory
    {
        IModelIndex<TModel> For<TModel>();
    }
}