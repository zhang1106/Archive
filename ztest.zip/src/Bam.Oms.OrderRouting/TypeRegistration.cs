﻿using System;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.EMSAdapters.Contracts;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using Ft;
using Grpc.Core;
using Bam.Oms.OrderRouting.EZE;

namespace Bam.Oms.OrderRouting
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            try
            {
                ISettings settings = container.Resolve<ISettings>();    
                container.RegisterType<ISubscriptionHost, SubscriptionHost>(RegistrationType.Singleton);
                container.RegisterType<IMappingAgent, MappingAgent>(RegistrationType.Singleton);
                container.RegisterType<INotificationCache, NotificationCache>(RegistrationType.Singleton);
                container.RegisterType<ISecurityMasterService, SecurityMasterService>(RegistrationType.Singleton);
                
                switch (settings.EmsName)
                {
                    case EmsSystem.Eze:
#if _BAM_WITH_LOGGING_INTERCEPTOR
                container.RegisterTypeWithLoggingInterfaceInterceptor<IEmsRouter, Eze.EmsRouter>(RegistrationType.Singleton);
#else
                        container.RegisterType<IEmsRouter, EZE.EmsRouter>(RegistrationType.Singleton);
#endif
                        break;

                    case EmsSystem.Flex:
                        
                        container.RegisterType<Flex.IStreamParser, Flex.GrpcStreamParser>(RegistrationType.Singleton);
#if _BAM_WITH_LOGGING_INTERCEPTOR
                container.RegisterTypeWithLoggingInterfaceInterceptor<IEmsRouter, Flex.EmsRouter>(RegistrationType.Singleton);
#else
                        container.RegisterType<IEmsRouter, Flex.EmsRouter > (RegistrationType.Singleton);
#endif
                        container.RegisterType<IGrpcServices, Flex.GrpcFacade>(RegistrationType.Singleton/*, new InjectionMethod("EnablePing")*/);                        
                        break;
                }

                container.RegisterType<IInstructionToEmsTagMapper, InstructionToEmsTagMapper>(RegistrationType.Singleton);

            }
            catch (Exception ex)
            {
                var logger = container.Resolve<ILogger>();
                logger.Fatal($"Fatal error {ex.Message} - {ex.StackTrace}");
            }
        }
    }
}