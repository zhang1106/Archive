﻿using Bam.Oms.OrderRouting;
using Bam.Oms.OrderRouting.Flex;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class InstructionToFixMapperTests
    {
        [Test]
        public void VerifyInstructionConfigMapsIntoDictionarySameCase()
        {
            // arrange
            var mapper = new InstructionToEmsTagMapper(new Mock<ILogger>().Object);

            // act
            var unit = mapper.GetTag("vol");

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit, Is.EqualTo("9000"));
        }

        [Test]
        public void VerifyInstructionConfigMapsIntoDictionaryDifferentCase()
        {
            // arrange
            var mapper = new InstructionToEmsTagMapper(new Mock<ILogger>().Object);

            // act
            var unit = mapper.GetTag("vOl");

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit, Is.EqualTo("9000"));
        }
    }
}