﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Filtering
{
    public interface ICompositeFilter<T>
    {
        /// <summary>
        /// add a list filter
        /// </summary>
        /// <param name="filters"></param>
        /// <param name="isAndFilter"></param>
        void AddToFilter(string id, IEnumerable<Parameter> userCriteria, bool isUserFilterAnd
            , IEnumerable<Parameter> permissionedCriteria, bool isPermissionFilterAnd);
        /// <summary>
        /// Applies the saved filters to the item and indicates whether or not it should be filtered out
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        IEnumerable<string> ApplyFilter(T item);

        /// <summary>
        /// Checks to see a given item passes the filter for a given consumer
        /// </summary>
        /// <param name="id"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        bool ApplyFilter(string id, T item);

        /// <summary>
        /// Removes the filter list for a given caller/subscriber
        /// </summary>
        /// <param name="id"></param>
        void ClearFilter(string id);

        event Action<string> FilterChanged;

        //TODO: THIS SHOULD BE CHANGED WHEN WE ADD IN TRACKED USERS TO CONNECTION IDS...
        /// <summary>
        /// Returns all client connection ids
        /// </summary>
        IList<string> ClientConnectionIds { get; }
    }
}
