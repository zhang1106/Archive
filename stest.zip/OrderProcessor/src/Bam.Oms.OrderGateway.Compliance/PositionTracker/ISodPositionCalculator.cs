﻿using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Model;

namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public interface ISodPositionCalculator : IEventSource<IMessage>
    {
        IReadOnlyList<PositionSet> Adjust(
            IReadOnlyList<PositionSet> positionSets,
            IReadOnlyList<Position> newPositions,
            IList<OrderStrategyAllocation> orderAllocations);

        IReadOnlyList<PositionSet> Calculate(
            IReadOnlyList<Position> positions,
            IList<Order> orders);
    }
}
