﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Bam.Oms.EndPoints.File;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;
using Listener = Bam.Oms.EndPoints.File.Listener;

namespace Bam.Oms.Tests
{
    [TestFixture]    
    public class FileListenerTests
    {
        private string _testpath;
        private const string file = "QIAN-GENERALIST_20150826.csv";
        private const string malformedFile = "QIAN-GENERALIST_20150826.Malformed.csv";

        [TestFixtureSetUp]
        public void Setup()
        {
            var Assm = Assembly.GetExecutingAssembly().CodeBase;
            var split = Assm.Split('/');
            var path = split[3] + @"\";

            for (var i = 4; i < split.Length - 1; i++)
                path = Path.Combine(path, split[i]);

            _testpath = Path.Combine(path, "TestData");
        }

        [Test]
        public void VerifyParsingFile()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.Setup(s => s.SODDateTime).Returns(DateTime.Today.AddHours(1));
            settings.Setup(s => s.MaxStripedProcessors).Returns(1);
            // arrange
            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, new Mock<IOrderPrepUtility>().Object, new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);

            // act
            var unit = fileWatcher.ParseFile(Path.Combine(_testpath, file));

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.Count, Is.EqualTo(1347));

            var google = unit.First(g => g.Security.BamSymbol == "GOOG");

            Assert.That(google.Size, Is.EqualTo(260));
            Assert.That(google.Portfolio.ToString(), Is.EqualTo("QIAN-GENERALIST"));
        }

        [Ignore]
        [Test]
        public void VerifyParsingExecutionInstructions()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.Setup(s => s.SODDateTime).Returns(DateTime.Today.AddHours(1));
            settings.Setup(s => s.MaxStripedProcessors).Returns(1);
            // arrange
            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, new Mock<IOrderPrepUtility>().Object,  new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);

            // act
            var unit = fileWatcher.ParseFile(Path.Combine(_testpath, file));

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit[0].ExecutionInstructions.Count, Is.EqualTo(1));
            Assert.That(unit[0].ExecutionInstructions[0].Code, Is.EqualTo("Vol"));
            Assert.That(unit[0].ExecutionInstructions[0].Value, Is.EqualTo("0.2"));
        }

        [Ignore]
        [Test]
        public async void VerifyOrderSubmissionEventRaised()
        {
            // arrange
            var ids = new List<string>();
            for (var i = 0; i < 1347; i++)
                ids.Add("test" + i);

            var mockHandler = new Mock<IOrderHandler>();
            var mockClientIds = new Mock<IOrderPrepUtility>();
            mockClientIds.Setup(r => r.AssignOrderIds(It.IsAny<IList<IOrder>>())).Returns(ids);

            Mock<ISettings> settings = new Mock<ISettings>();
            settings.Setup(s => s.SODDateTime).Returns(DateTime.Today.AddHours(1));
            settings.Setup(s => s.MaxStripedProcessors).Returns(1);

            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, mockClientIds.Object, new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);

            fileWatcher.NewOrdersReady += mockHandler.Object.HandleOrders;

            // act
            await fileWatcher.ImportAndNotifyOfOrders(Path.Combine(_testpath, file), file);

            // assert
            mockHandler.Verify(l => l.HandleOrders(It.IsAny<IList<IOrder>>(), It.IsAny<string>(),It.IsAny<bool>()),Times.Once);
        }

        [Test]
        public void VerifyHistoryFolderCreation()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.Setup(s => s.SODDateTime).Returns(DateTime.Today.AddHours(1));
            settings.Setup(s => s.MaxStripedProcessors).Returns(1);

            // arrange
            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, new Mock<IOrderPrepUtility>().Object, new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);
            var expectedPath = Path.Combine(_testpath, "history", DateTime.Today.ToString("yyyyMMdd"));

            // act
            var unit = fileWatcher.CreateSubFolder(_testpath, "history");

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit, Is.EqualTo(expectedPath));
        }

        [Test]
        public void VerifyArchiveFileNameIsUnique()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.Setup(s => s.SODDateTime).Returns(DateTime.Today.AddHours(1));
            settings.Setup(s => s.MaxStripedProcessors).Returns(1);

            // arrange
            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, new Mock<IOrderPrepUtility>().Object, new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);

            // act
            var unit = fileWatcher.CreateArchiveName("test.csv");

            //these will be executed serially, so we can simulate that
            Thread.Sleep(1);

            var unit0 = fileWatcher.CreateArchiveName("test.csv");

            // assert
            Assert.IsNotNull(unit);
            Assert.IsNotNull(unit0);

            Assert.That(unit, Is.Not.EqualTo(unit0));
        }

        [Test]
        public void VerifyReceiptPath()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.Setup(s => s.SODDateTime).Returns(DateTime.Today.AddHours(1));
            settings.Setup(s => s.MaxStripedProcessors).Returns(1);

            // arrange
            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, new Mock<IOrderPrepUtility>().Object, new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);

            const string pathName = "QIAN-GENERALIST-2015104.178040.CSV";

            // act
            var unit = fileWatcher.CreateReceiptPath(pathName);

            // assert
            Assert.That(unit, Is.EqualTo("QIAN-GENERALIST-2015104.178040.receipt"));
        }

        [Test]
        public void VerifyWriteOrderReceipt()
        {
            Mock<ISettings> settings = new Mock<ISettings>();
            settings.Setup(s => s.SODDateTime).Returns(DateTime.Today.AddHours(1));
            settings.Setup(s => s.MaxStripedProcessors).Returns(1);

            // arrange
            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, new Mock<IOrderPrepUtility>().Object, new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);

            var order = new Order() { ClientOrderId = "1234", Portfolio = new Portfolio("QIAN", "GENERALIST"), Security = new Security() { BamSymbol = "IBM" }, Size = 1000, Side = SideType.Buy };

            const string pathName = "QIAN-GENERALIST-2015104.178040.CSV";
            const string pathName0 = "QIAN-GENERALIST-2015104.178040.RECEIPT";

            var fullPath = Path.Combine(_testpath, pathName0);

            // act
            fileWatcher.WriteOutOrderReceipt(new List<IOrder>() { order }, fullPath);
            var unit = File.Exists(fullPath);

            // assert
            Assert.True(unit);
        }

        [Test]
        public async void VerifyIncompleteOrderFileFails()
        {
            // arrange
            var handler = new Mock<IOrderHandler>();
            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, new Mock<IOrderPrepUtility>().Object, new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);

            fileWatcher.NewOrdersReady += handler.Object.HandleOrders;

            // act
            await fileWatcher.ImportAndNotifyOfOrders(Path.Combine( _testpath, malformedFile), malformedFile);

            // assert
            handler.Verify(l => l.HandleOrders(It.IsAny<IList<IOrder>>(), It.IsAny<string>(),It.IsAny<bool>()), Times.Never);
        }

        [Test]
        public async void VerifyInvalidOrderDoesNotSumbit()
        {
            // arrange
            var validator = new Mock<IOrderValidator>();
            validator.Setup(r => r.IsValidOrder(It.IsAny<List<IOrder>>())).Returns(false);

            var notifier = new Mock<IOrderNotifier>();

            var fileWatcher = new FileListenerFacade(new FileConfiguration() { Path = _testpath }, new Mock<IOrderPrepUtility>().Object, new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object);

            // act
            await fileWatcher.ImportAndNotifyOfOrders(Path.Combine(_testpath, file), file);

            // assert
            notifier.Verify(l => l.NotifyNewOrders(It.IsAny<IList<IOrder>>()), Times.Never);
        }


        public interface IOrderHandler
        {
            void HandleOrders(IList<IOrder> orders, string batch,bool fromFile);
        }

        private class FileListenerFacade : Listener
        {
            public FileListenerFacade(IFileConfiguration fileConfiguration, IOrderPrepUtility IOrderPrepUtility, IOrderValidator orderValidator,IAccountService accountService)
                : base(fileConfiguration, new Mock<ILogger>().Object, IOrderPrepUtility, orderValidator,new LoggingSerializer(), accountService)
            {
            }

            public new List<IOrder> ParseFile(string path)
            {
                return base.ParseFile(path);
            }

            public new Task ImportAndNotifyOfOrders(string path, string fileName)
            {
                return base.ImportAndNotifyOfOrders(path, fileName);
            }

            public new string CreateArchiveName(string fileName)
            {
                return base.CreateArchiveName(fileName);
            }

            public new string CreateReceiptPath(string path)
            {
                return base.CreateReceiptPathWithFileName(path);
            }

            public new string CreateSubFolder(string path, string folderName)
            {
                return base.CreateSubFolder(path, folderName);
            }

            public new void WriteOutOrderReceipt(IList<IOrder> orders, string path)
            {
                base.WriteOutOrderReceipt(orders, path);
            }
        }
    }
}