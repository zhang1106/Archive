﻿using System;
using System.Linq;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class ComplianceRulesTest
    {
        private ISettings _setting;

        private const string LongOwnershipRule =
            "{\"Ratio\":{\"AQTF\":0.25,\"MAIN\":0.75}, \"OwnershipType\":\"LONG\",\"Threshholds\":{\"0\":{\"UpLimit\":0.04},\"0.04\":{\"LowLimit\":0.04,\"UpLimit\":0.05,\"AlertLevel\":\"Overrideable\"},\"0.05\":{\"LowLimit\":0.05,\"UpLimit\":0.09,\"AlertLevel\":\"ComplianceOverrideable\",\"FireOnce\":true},\"0.09\":{\"LowLimit\":0.09,\"UpLimit\":null,\"AlertLevel\":\"ComplianceOverrideable\"}},\"FilterParams\":[{\"Property\":\"Country\",\"Value\":\"US\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Equal\"}},{\"Property\":\"BamSymbol\",\"Value\":\"OIH\",\"Type\":null,\"Operator\":{\"OperatorType\":\"NotEqual\"}}]}";

        private const string ShortOwnershipRule =
          "{\"CheckBy\":\"ISIN\",\"IncludeConstituent\":true,\"Ratio\":{\"AQTF\":0.25,\"MAIN\":0.75}, \"OwnershipType\":\"NETSHORT\",\"Entity\":\"BAM\",\"Threshholds\":{\"0\":{\"LowLimit\":null,\"UpLimit\":0.002},\"0.002\":{\"LowLimit\":0.002,\"UpLimit\":0.00485,\"AlertLevel\":\"Overrideable\"},\"0.00485\":{\"LowLimit\":0.00485,\"UpLimit\":null,\"FireOnce\":true,\"AlertLevel\":\"ComplianceOverrideable\"}},\"FilterParams\":[{\"Property\":\"ISIN\",\"Value\":\"EuIsinList\",\"Type\":null,\"Operator\":{\"OperatorType\":\"InTheList\"}}]}";

        private const string LongLimitOwnershipRule =
            "{\"Threshhold\":22000000.0,\"FilterParams\":[{\"Property\":\"BamSymbol\",\"Value\":\"BWP\",\"Operator\":{\"OperatorType\":\"Equal\"}}]}";

        private const string ReitShortRule = "{\"OwnerShipType\":\"NETSHORT\",\"Threshholds\":{\"0\":{\"LowLimit\":null,\"UpLimit\":0.03},\"0.03\":{\"LowLimit\":0.03,\"UpLimit\":0.045,\"AlertLevel\":\"Overrideable\"},\"0.045\":{\"LowLimit\":0.045,\"AlertLevel\":\"ComplianceOverrideable\"}}, \"FilterParams\":[{\"Property\":\"Industry\",\"Value\":\"REIT\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Contains\"}}]}";

        [SetUp]
        public void Setup()
        {
            _setting = Factory.GetSettings();

            Container.Instance.RegisterInstance<IFactProvider>(new Mock<IFactProvider>().Object);
            
            var ruleResultProvider = new Mock<IOwnershipRuleResultProvider>();
            ruleResultProvider.Setup(r => r.GetLowLimit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
                .Returns(0);
            ruleResultProvider.Setup(r => r.GetRatio(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
                .Returns(0);
        }

        [TestCase(100L, 10L, ComplianceAlertLevel.NoViolation)]
        public void ReitShortOwnershipResultTest(long? sharesOutstanding, long? holding, ComplianceAlertLevel alertLevel)
        {
            var marketData = new Mock<IMarketDataProvider>();
            marketData.Setup(m => m.GetCustomizedShareOutstanding(It.IsAny<string>())).Returns(sharesOutstanding);

            var positionProvider = new Mock<IPositionProvider>();
            positionProvider.Setup(m => m.GetFirmWideQuantity(It.IsAny<string>(), PositionType.Sod, SideType.Short))
                .Returns(new Tuple<string, decimal?>("Test", holding));
            positionProvider.Setup(m => m.GetFirmWideQuantity(It.IsAny<string>(), PositionType.Sod, SideType.Short))
             .Returns(new Tuple<string, decimal?>("Test", holding));
            
            var customdDataProvider = new Mock<ICustomDataProvider>();
            customdDataProvider.Setup(c => c.IsEuExempted(It.IsAny<string>())).Returns(true);

            var shortOwnershipFiling = new ShortOwnershipFiling()
            { ParamsInJson = ReitShortRule };
            shortOwnershipFiling.Init();

            var position = Factory.CreateCompliancePosition(_setting, new Security { BamSymbol = "IBM" }, new Policy<ICompliancePosition>(), true);
            position.SetupGet(p => p.MarketDataProvider).Returns(marketData.Object);
            position.SetupGet(p => p.CustomDataProvider).Returns(customdDataProvider.Object);
            position.SetupGet(p => p.MarketDataProvider).Returns(marketData.Object);
            
            var result = shortOwnershipFiling.CheckViolation(position.Object, false);

            Assert.IsTrue(result.HeadRoom.IdentifierType == "SYMBOL");
            Assert.IsTrue(result.HeadRoom.Side == "NetShort");
            Assert.IsTrue(result.AlertLevel == alertLevel);
        }


        [TestCase(null, null, ComplianceAlertLevel.NoDataAvaiable)]
        [TestCase(null, 10L, ComplianceAlertLevel.NoDataAvaiable)]
        [TestCase(100L, null, ComplianceAlertLevel.NoDataAvaiable)]
        [TestCase(100L, 10L, ComplianceAlertLevel.ComplianceOverrideable)]
        [TestCase(100L, 0L, ComplianceAlertLevel.NoViolation)]
        [TestCase(100L, -10L, ComplianceAlertLevel.NoViolation)]
        public void LongOwnershipResultTest(long? sharesOutstanding, long? holding, ComplianceAlertLevel alertLevel)
        {
            var marketData = new Mock<IMarketDataProvider>();
            marketData.Setup(m => m.GetCustomizedShareOutstanding(It.IsAny<string>())).Returns(sharesOutstanding);
            
            var longOwnershipFiling = new LongOwnerShipFiling()
            { ParamsInJson = LongOwnershipRule };

            longOwnershipFiling.Init();

            var position = Factory.CreateCompliancePosition(_setting, new Security { BamSymbol = "IBM", ActiveInd = true}, new Policy<ICompliancePosition>(), true, holding);
            position.SetupGet(p => p.MarketDataProvider).Returns(marketData.Object);

            var result = longOwnershipFiling.CheckViolation(position.Object, false);

            Assert.NotNull(result.HeadRoom);
            Assert.IsTrue(result.AlertLevel == alertLevel);
        }


        [TestCase(null, null, ComplianceAlertLevel.NoDataAvaiable)]
        [TestCase(null, -10L, ComplianceAlertLevel.NoDataAvaiable)]
        [TestCase(100L, null, ComplianceAlertLevel.NoDataAvaiable)]
        [TestCase(100L, -10L, ComplianceAlertLevel.ComplianceOverrideable)]
        [TestCase(100L, 0L, ComplianceAlertLevel.NoViolation)]
        [TestCase(100L, 10L, ComplianceAlertLevel.NoViolation)]
        public void ShortOwnershipResultTest(long? sharesOutstanding, long? holding, ComplianceAlertLevel alertLevel)
        {
            var marketData = new Mock<IMarketDataProvider>();
            marketData.Setup(m => m.GetSharesOutstanding(It.IsAny<string>())).Returns(sharesOutstanding);
            marketData.Setup(c => c.GetCustomizedShareOutstanding(It.IsAny<string>())).Returns(sharesOutstanding);
  
            var customdDataProvider = new Mock<ICustomDataProvider>();
            customdDataProvider.Setup(c => c.IsEuExempted(It.IsAny<string>())).Returns(true);

            var shortOwnershipFiling = new ShortOwnershipFiling()
            { ParamsInJson = ShortOwnershipRule };

            shortOwnershipFiling.Init();

            var postionProvider = new Mock<IPositionProvider>();
            postionProvider.Setup(
                p =>
                    p.GetEntityWideQuantityByIsin(It.IsAny<string>(), It.IsAny<PositionType>(), It.IsAny<string>(),
                        It.IsAny<SideType>())).Returns(new Tuple<string, decimal?>("test", holding));

            var security = new Security {BamSymbol = "IBM", ActiveInd = true, Isin="ISIN"};

            var securityProvider = new Mock<ISecurityProvider>();
            securityProvider.SetupGet(p => p.SecuritiesByIsin)
                .Returns(new[] {(ISecurity) security}.ToLookup(s => s.Isin));
            
            var position = Factory.CreateCompliancePosition(_setting, security, new Policy<ICompliancePosition>(), true, holding);
            position.SetupGet(p => p.MarketDataProvider).Returns(marketData.Object);
            position.SetupGet(p => p.PositionProvider).Returns(postionProvider.Object);
            position.SetupGet(p => p.CustomDataProvider).Returns(customdDataProvider.Object);
            position.SetupGet(p => p.SecurityProvider).Returns(securityProvider.Object);
            
            var result = shortOwnershipFiling.CheckViolation(position.Object, false);

            Assert.NotNull(result.HeadRoom);
            Assert.IsTrue(result.AlertLevel == alertLevel);
        }

        [TestCase(1000L, null, ComplianceAlertLevel.NoDataAvaiable)]
        [TestCase(1000L, -10L, ComplianceAlertLevel.NoViolation)]
        [TestCase(1000L, 0L, ComplianceAlertLevel.NoViolation)]
        [TestCase(1000L, 1001L, ComplianceAlertLevel.Restricted)]
        public void LongLimitOwnershipResultTest(long limit, long? holding, ComplianceAlertLevel alertLevel)
        {
            var longLimitOwnershipFiling = new LongOwnershipLimit()
            { ParamsInJson = LongLimitOwnershipRule };

            longLimitOwnershipFiling.Init();
            longLimitOwnershipFiling.Threshhold = limit;

            var position = Factory.CreateCompliancePosition(_setting, new Security { BamSymbol = "IBM" }, new Policy<ICompliancePosition>(), true, holding);   

            var result = longLimitOwnershipFiling.CheckViolation(position.Object, false);

            Assert.NotNull(result.HeadRoom);
            Assert.IsTrue(result.AlertLevel == alertLevel);
        }
    }
}
