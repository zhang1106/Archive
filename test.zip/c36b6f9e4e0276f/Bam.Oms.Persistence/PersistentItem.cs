﻿using System;
using Bam.Oms.Data;

namespace Bam.Oms.Persistence
{
    public class PersistentItem<T> : IComparable<PersistentItem<T>> where T : IPersistentItem
    {
        public DateTime LastUpdated { get; set; }
        public T Item { get; set; }

        public int CompareTo(PersistentItem<T> other)
        {
            int byDate = LastUpdated.CompareTo(other.LastUpdated);
            return byDate != 0 ? byDate : string.Compare(Item?.Key, other.Item?.Key, StringComparison.Ordinal);
        }
    }
}
