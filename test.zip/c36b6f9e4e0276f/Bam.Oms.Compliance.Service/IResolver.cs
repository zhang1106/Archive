﻿namespace Bam.Oms.Compliance.Service
{
    interface IResolver
    {
        object GetInstance<T>();
    }
}
