﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data;
using Bam.Oms.Data.Trades;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.PositionTracker;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Service.Trades
{
    public class TradeProcessor : ITradeProcessor
    {        
        private readonly IEmsRouter _emsRouter;
        private readonly IPositionTracker _positionTracker;
        private readonly ILogger _logger;

        public TradeProcessor(IEmsRouter emsRouter, IPositionTracker positionTracker, ILogger logger)
        {            
            if (emsRouter == null) throw new ArgumentNullException(nameof(emsRouter));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (positionTracker == null) throw new ArgumentNullException(nameof(positionTracker));

            _emsRouter = emsRouter;            
            _positionTracker = positionTracker;
            _logger = logger;            
            _emsRouter.TradeUpdated += TradeSubscriptionHostOnTradeUpdated;

        }

        private void TradeSubscriptionHostOnTradeUpdated(IEnumerable<IBlockTrade> trades)
        {
            foreach (IBlockTrade trade in trades)
            {
                _positionTracker.ApplyPositionUpdate(trade);
            }
        }

        public void Dispose()
        {
            _logger.Debug("Disposing trade processor...");

            _emsRouter.TradeUpdated -= TradeSubscriptionHostOnTradeUpdated;

            _logger.Debug("Disposed trade processor...");
        }
    }
}