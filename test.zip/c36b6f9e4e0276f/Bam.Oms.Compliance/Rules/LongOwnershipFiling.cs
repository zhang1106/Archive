﻿using Newtonsoft.Json;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Rules
{
    [JsonObject(MemberSerialization.OptIn)]
    public class LongOwnerShipFiling : OwnerShip
    {
        public override IRuleResult CheckViolation(ICompliancePosition input, bool isPreCheck)
        {
            var result = input.Helper.CreateFilingResult(input, this, GetOwnership(), Entity, GetIdentityType());

            CheckViolation(input, isPreCheck, result);

            return result;
        }
    }
}
