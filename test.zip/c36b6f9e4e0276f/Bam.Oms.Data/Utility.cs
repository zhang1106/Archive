﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using Bam.Oms.Data.Enumerators;
using log4net;
using Newtonsoft.Json;

namespace Bam.Oms.Data
{
    public class Utility
    {
        private static readonly ILog _logger = LogManager.GetLogger("Bam.Oms.Data.Utility");

        /// <summary>
        /// to get a default enum for string conversion
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="name"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static T TryConvertEnum<T>(string name, out bool isDefined) where T : struct
        {
            T enumValue;
            isDefined = Enum.TryParse<T>(name, true, out enumValue);

            return enumValue;
        }

        public static T ConvertEnum<T>(string name)
        {
            if (string.IsNullOrEmpty(name) || !Enum.IsDefined(typeof(T), name))
            {
                return default(T);
            }

            var enumValue = (T)Enum.Parse(typeof(T), name, true);
            return enumValue;
        }

        public static T GetEnumValue<T>(string s)
        {
            foreach (T item in Enum.GetValues(typeof(T)))
            {
                FieldInfo info = typeof(T).GetField(item.ToString());
                var attribs = info.GetCustomAttributes(typeof(EnumAttribute), false);
                if (attribs.Length > 0)
                {
                    EnumAttribute a = attribs[0] as EnumAttribute;
                    if (s == a.StringValue)
                    {
                        return item;
                    }
                }
                else
                {
                    return ConvertEnum<T>(s);
                }
            }

            return default(T);
        }

        public static string GetStringFromEnumAttribute<T>(T enumType)
        {
            var info = typeof(T).GetField(enumType.ToString());
            var attribs = info.GetCustomAttributes(typeof(EnumAttribute), false);
            if (attribs.Length > 0)
            {
                var a = attribs[0] as EnumAttribute;
                if (a != null)
                    return a.StringValue;

            }

            throw new ArgumentException("Enum does not contain string value attribute.");
        }

        public static string GetStringValue<T>(T enumValue)
        {
            return enumValue.ToString().Replace("_", " ");
        }

        public static string WildcardToRegex(string pattern)
        {
            return "^" + Regex.Escape(pattern)
                .Replace(@"\*", ".*")
                .Replace(@"\?", ".")
                   + "$";
        }

        public static void RaiseEvent<T>(T args, Action<T> action)
        {
            if (action != null)
            {
                foreach (var handler in action.GetInvocationList().Cast<Action<T>>())
                {
                    try
                    {
                        handler(args);
                    }
                    catch (Exception exception)
                    {
                        _logger.Error(exception.Message, exception);
                    }
                }
            }
        }


        public static DateTime SetSodTime(string sodTimeString = "17:00:00" /* Roll time in Chicago time*/, DateTime now = default(DateTime))
        {
            if (now.Equals(default(DateTime)))
                now = DateTime.Now;

            if (string.IsNullOrEmpty(sodTimeString))
            {
                sodTimeString = "17:00:00"; /* Roll time in Chicago time*/
            }
            
            var ts = TimeSpan.Parse(sodTimeString);
            var sodDateTime = now.TimeOfDay >= ts  ? now.Date.Add(TimeSpan.Parse(sodTimeString)) : now.Date.AddDays(-1).Add(TimeSpan.Parse(sodTimeString));

            return sodDateTime;
        }

        public static string GetMemberName<T>(Expression<Func<T>> memberExpression)
        {
            var expressionBody = (MemberExpression)memberExpression.Body;
            return expressionBody.Member.Name;
        }
    }
}
