using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Time;

namespace Bam.Oms.OrderGateway.ApiGateway.File
{
    public abstract class FileListener
    {
        private readonly string _watchPath;
        private readonly string _archivePath;
        private readonly string _errorPath;
        private readonly IBackgroundWorker _fileMonitorWorker;

        public string Name { get; set; }
        public ILogger Logger { get; set; }
        protected IClock Clock { get; }

        protected FileListener(IClock clock, string watchPath, string archivePath, string errorPath)
        {
            Clock = clock;
            _watchPath = watchPath;
            _archivePath = archivePath;
            _errorPath = errorPath;
            _fileMonitorWorker = BackgroundWorkerFactory.Current.Create($"Watching {_watchPath}");
        }

        public void Start()
        {
            _fileMonitorWorker.Start(MonitorDirectory);
        }

        public void Stop()
        {
            _fileMonitorWorker.Stop();
        }

        private void MonitorDirectory(CancellationToken cancellationToken)
        {
            while (!cancellationToken.WaitHandle.WaitOne(TimeSpan.FromSeconds(1)))
            {
                try
                {
                    if (!Directory.Exists(_watchPath))
                    {
                        Directory.CreateDirectory(_watchPath);
                    }

                    foreach (var path in GetPendingFiles())
                    {
                        Logger?.LogInformation($"Processing {path}");
                        try
                        {
                            var entryUser = System.IO.File.GetAccessControl(path)?.GetOwner(typeof(System.Security.Principal.NTAccount))?.ToString().Replace("FOUNTAINHEAD\\", "");
                            ProcessFile(path, entryUser);
                            ArchiveFile(path, _archivePath);
                        }
                        catch (IOException)
                        {
                            Logger?.LogWarning("Waiting on for file handle");
                        }
                        catch (Exception ex)
                        {
                            Logger?.LogError("Error processing file", ex);
                            ArchiveFile(path, _errorPath, ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger?.LogError("Error scanning files", ex);
                }
            }
        }

        private IEnumerable<string> GetPendingFiles()
        {
            foreach (var file in Directory.EnumerateFiles(_watchPath, "*.csv", SearchOption.TopDirectoryOnly))
                yield return file;

            foreach (var file in Directory.EnumerateFiles(_watchPath, "*.json", SearchOption.TopDirectoryOnly))
                yield return file;
        }

        private void ArchiveFile(string path, string folderLocation, string optionalErrorMessage = null)
        {
            // ReSharper disable once AssignNullToNotNullAttribute
            string folder = Path.Combine(folderLocation, Clock.Today.ToString("yyyyMMdd"));
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string suffix = string.Empty;
            string archivePath = Path.Combine(folder, Path.GetFileName(path) + $".{DateTime.Now:yyyyMMddHHmmss}");

            while (System.IO.File.Exists(archivePath + suffix))
            {
                suffix = suffix == string.Empty ? "2" : Convert.ToString(Convert.ToInt32(suffix) + 1);
            }

            System.IO.File.Move(path, archivePath + suffix);
            if (optionalErrorMessage != null)
            {
                System.IO.File.AppendAllText(archivePath + suffix, optionalErrorMessage);
            }
        }

        protected abstract void ProcessFile(string path, string entryUser);
    }
}
