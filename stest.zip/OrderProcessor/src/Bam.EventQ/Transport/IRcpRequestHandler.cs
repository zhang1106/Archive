﻿namespace Bam.EventQ.Transport
{
    public interface IRcpRequestHandler
    {
        byte[] Invoke(string inquiry, byte[] payload);
        bool CanHandle(string inquiry);
    }
}
