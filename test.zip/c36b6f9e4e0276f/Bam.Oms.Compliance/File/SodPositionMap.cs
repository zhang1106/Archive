﻿using System;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using CsvHelper.Configuration;

namespace Bam.Oms.Compliance.File
{
    public sealed class SodPositionMap:CsvClassMap<Position>
    {
        public SodPositionMap()
        {
            Map(m => m.ActualQuantity).Name("Qty");
            Map(m => m.Price).Name("Price");
            Map(m => m.Currency).Name("Currency");
            Map(m => m.FXRate).Name("FxRate");
            Map(m => m.CustodianAccount).ConvertUsing(row =>
            {
                string acct;
                if (row.TryGetField("CustodianAccount", out acct))
                    return acct;
                acct = row.GetField("Custodian").ToString();
                return acct;
            });
            Map(m => m.Portfolio).ConvertUsing(row =>
            {
                var strategy = row.GetField("Strategy").ToString();
                return Portfolio.Parse(strategy);
            });
            Map(m => m.Security).ConvertUsing(row =>
            {
                var symbol = row.GetField("Symbol").ToString();
                var security = new Security() {BamSymbol = symbol};
                return security;
            });
        }
    }
}
