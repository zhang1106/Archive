﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.EndPoints.File
{
    internal class OrderGroupingKey
    {
        public OrderGroupingKey(string groupingKey, string bamSymbol, SideType side)
        {
            GroupingKey = groupingKey;
            BAMSymbol = bamSymbol;
            Side = side;
        }

        public string GroupingKey { get; }
        public string BAMSymbol { get; }
        public SideType Side { get; }

        public int CompareTo(OrderGroupingKey other)
        {
            return this.GroupingKey.Equals(other.GroupingKey) ? this.BAMSymbol.Equals(other.BAMSymbol) ? this.Side.CompareTo(other.Side) : String.Compare(this.BAMSymbol, other.BAMSymbol, StringComparison.Ordinal) : String.Compare(other.GroupingKey, this.GroupingKey, StringComparison.Ordinal);
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;

            var other = obj as OrderGroupingKey;
            if (other == null)
                return false;

            return GroupingKey.Equals(other.GroupingKey)
                   && BAMSymbol.Equals(other.BAMSymbol)
                   && Side.Equals(other.Side);
        }

        public override int GetHashCode()
        {
            return unchecked(GroupingKey.GetHashCode() * BAMSymbol.GetHashCode() * Side.GetHashCode());
        }

        public override string ToString()
        {
            return
                $"{GroupingKey}:{BAMSymbol}:{Side}";
        }
    }
}
