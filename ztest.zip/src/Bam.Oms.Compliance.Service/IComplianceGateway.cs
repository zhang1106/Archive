﻿namespace Bam.Oms.Compliance.Service
{
    interface IComplianceGateway
    {
    }
}
