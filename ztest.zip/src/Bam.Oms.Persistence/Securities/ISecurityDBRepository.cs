﻿using System.Collections.Generic;
using Bam.Oms.Data.Securities;
using Bam.Oms.Filtering;
namespace Bam.Oms.Persistence.Securities
{
    public interface ISecurityDBRepository : IDBRepository<Security>
    {
        IEnumerable<Security> GetSecurities(IFilter<ISecurity> filter);
    }
}
