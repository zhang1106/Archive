﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Bam.Oms.Data.Enumerators;
using EzeEi = Eze.Common.Integration;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Securities;
using BamTrades = Bam.Oms.Data.Trades;
using BAM.Infrastructure.Ioc;
using BamOrders=Bam.Oms.Persistence.Orders;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.RefData;
using Castle.Core.Internal;

namespace Bam.Oms.OrderRouting.EZE
{
    public class MappingAgent : IMappingAgent
    {
        private readonly ILogger _logger;
        private readonly BamOrders.IClientOrderIdRepository _clientOrderIdRepository;
        private readonly BamOrders.IOrderRepository _orderRepository;
        private readonly INotificationCache _notificationCache;
        private readonly IAccountService _accountService;
        private readonly ITradeRepository _tradeRepository;
        
        private readonly object _lockTranslate;

        public MappingAgent(IAccountService accountService, INotificationCache notificationCache, 
            BamOrders.IClientOrderIdRepository clientOrderIdRepository, ITradeRepository tradeRepository, BamOrders.IOrderRepository orderRepository,
            ILogger logger)
        {
            if (notificationCache == null) throw new ArgumentNullException(nameof(notificationCache));
            if (clientOrderIdRepository == null) throw new ArgumentNullException(nameof(clientOrderIdRepository));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));
            if (tradeRepository == null) throw new ArgumentNullException(nameof(tradeRepository));
            if (orderRepository == null) throw new ArgumentNullException(nameof(orderRepository));
            
            _accountService = accountService;
            _notificationCache = notificationCache;
            _clientOrderIdRepository = clientOrderIdRepository;
            _tradeRepository = tradeRepository;
            _orderRepository = orderRepository;
            _logger = logger;

            _lockTranslate = new object();

        }
       
        public void Translate(EzeEi.Trade trade, out IList<Order> ogOrders, out IList<BamTrades.BlockTrade> ogTrades)
        {
            //output
            ogTrades = new List<BamTrades.BlockTrade>();
            ogOrders = new List<Order>();
            
            //first custodian
            var custodian = trade.Allocations.Count>0?trade.Allocations[0].Custodian:string.Empty;
            
            //group the allocations in terms of strategy and tradeid, custondian is ignored
            var group = from a in trade.Allocations
                        group a by new OrderIndexKey(trade.TradeId, a.Strategy, trade.Symbol)
                        into grp
                        select new
                        {
                            grp.Key.Strategy,
                            grp.Key.Symbol,
                            Qty = grp.Sum(t => t.Quantity),
                            FilledQuantity = grp.Sum(t => t.Filled),  
                            SumPrice = grp.Sum(t => t.Filled * t.AveragePrice),
                            TradeCurrency = grp.First().FromCurrency,
                            NetMoney = grp.Sum(t=>t.NetMoney)
                        };

            //prevent create dups
            lock (_lockTranslate)
            {
                //cancel existing orders which are not in the new notification
                var orders = _notificationCache.GetOrdersByEzeTradeId(trade.TradeId);
                if (orders != null)
                {
                    foreach (var order in orders)
                    {
                        if (group.Any(g => string.Compare(g.Strategy, order.Value.Portfolio.ToString(), StringComparison.CurrentCultureIgnoreCase) == 0 &&
                        string.Compare(g.Symbol, order.Value.Security.BamSymbol, StringComparison.CurrentCultureIgnoreCase) == 0
                        )) continue;

                        //set order in cacel status
                        var ogOrder = (Order)order.Value;
                        ogOrder.OrderStatus = BamOrderStatus.Deleted;
                        ogOrders.Add(ogOrder);

                        //set trades in deleted status
                        var trades = _tradeRepository.GetByClientOrderId(ogOrder.ClientOrderId);
                        foreach (var ogTrade in trades)
                        {
                            ogTrade.TradedQuantity = 0;
                            ogTrade.TradeStatus = BamTradeStatus.Deleted;
                            ogTrade.AveragePrice = 0;
                            ogOrder.AveragePrice = 0;

                            foreach (var a in ogTrade.Allocations)
                            {
                                a.AveragePrice = 0;
                                a.Quantity = 0;
                            }
                            ogTrades.Add(ogTrade);
                        }
                    }
                }

                //create an order and an trade if filled for each group
                foreach (var g in group)
                {
                    var key = new OrderIndexKey(trade.TradeId, g.Strategy, g.Symbol);
                    var orderId = GetOrderId(key);

                    var portfolio = IsNewOrder(orderId) ? GetPortfolio(g.Strategy) : null;

                    if (IsNewOrder(orderId))
                    {
                        if (portfolio == null)
                        {
                            _logger.Error("cant get portfolio for " + g.Strategy + " in EZE trade: " + trade.TradeId);
                            continue;
                        }
                    }
                                        
                    var order = new Order()
                    {
                        BatchId = portfolio?.PMCode + "-" + DateTime.Now.ToString("yyyyMMdd"),
                        Portfolio = portfolio,
                        Security = new Security() {BamSymbol = trade.Symbol},
                        Custodian = custodian,
                        Size = g.Qty,
                        Side = GetSideType(trade.Action),
                        ClientOrderId = GetOrderId(orderId, trade, _clientOrderIdRepository, _orderRepository),
                        ExternalId = trade.TradeId,
                        Trader = trade.Trader,
                        OrderStatus = GetOrderStatus(trade),
                        TradeDate = trade.TradeDate,
                        SettleDate = trade.SettleDate,
                        Note = trade.Note,
                        Price = trade.LimitPrice,
                        OrderTimeStamp = ConvertToUtc(trade.RTBlotterTimeStamp, "Central Standard Time"),
                        CreatedDateTime = ConvertToUtc(trade.TradeIndex, "Central Standard Time"), 
                        Urgency = ParseUrgency(trade),
                        TradeCurrency = g.TradeCurrency,
                        AveragePrice = g.FilledQuantity == 0 ? 0 : g.SumPrice / g.FilledQuantity,
                        FillQuantity = g.FilledQuantity
                    };
                    

                    ogOrders.Add(order);
                    //add new order to cache index
                    if (IsNewOrder(orderId))
                    {
                        _notificationCache.AddToOrderIdIndex(order);
                        _logger.Info("Received a trade message from EZE that was not in OG: Eze TradeId: " + trade.TradeId);
                    }

                    var blocktrade = new BamTrades.BlockTrade()
                    {
                        Portfolio = order.Portfolio,
                        Security = order.Security,
                        TradedQuantity = g.FilledQuantity,
                        AveragePrice = g.FilledQuantity == 0 ? 0 : g.SumPrice/g.FilledQuantity,
                        Side = order.Side,
                        FxRate = Constants.DefaultFixRate, // Default
                        TradeCurrency = g.TradeCurrency,
                        TradeTimeStamp = ConvertToUtc(trade.RTBlotterTimeStamp, "Central Standard Time"),
                        DataSource = Constants.Eze,
                        ClientOrderId = order.ClientOrderId,
                        TradeId = trade.TradeId + "-" + order.ClientOrderId,
                        TradeStatus = GetTradeStatus(trade),
                        TradeDate = trade.TradeDate,
                        NetAmount = g.NetMoney
                    };

                    //get related allocations
                    var tAllocs = trade.Allocations.Where(a => a.Strategy == g.Strategy).ToList();
                    //create ogtrade allocations
                    CreateAllocations(order.ClientOrderId, blocktrade, tAllocs, trade);
                    //set filled qty for special case
                    if (IsTradeDeleted(trade))
                    {
                        blocktrade.TradedQuantity = 0;
                        blocktrade.AveragePrice = 0;
                        order.AveragePrice = 0;
                    }
                    //
                    ogTrades.Add(blocktrade);
                }
            }
        }

        public static DateTime ConvertToUtc(DateTime? time, string timezone)
        {
            if (!time.HasValue) return DateTime.UtcNow;

            var zone = TimeZoneInfo.FindSystemTimeZoneById(timezone);

            var utc = TimeZoneInfo.ConvertTimeToUtc(time.Value, zone);

            return utc;
        }

        private bool IsNewOrder(string orderId)
        {
            return orderId == null;
        }

        //to prevent the case that orders were not created by stripe processor for any reason
        private string GetOrderId(OrderIndexKey key)
        {
            var orderId = _notificationCache.GetOrderId(key);
            return orderId;
            }

        private static Urgency ParseUrgency(EzeEi.Trade trade)
        {
            Urgency urgency = Urgency.Low;
            string[] userDefinedFields = trade.UserDefinedFields;
            if (userDefinedFields != null && userDefinedFields.Any())
            {
                string urgencyString = userDefinedFields.FirstOrDefault(udf => udf.StartsWith("Urgency", StringComparison.CurrentCultureIgnoreCase));
                if (!string.IsNullOrWhiteSpace(urgencyString))
                {
                    string[] s = urgencyString.Split('=');
                    if (s.Length == 2)
                    {
                        urgency = Utility.ConvertEnum<Urgency>(s[1]);
                    }
                }
            }
            return urgency;
        }

        private static void CreateAllocations(string clientOrderId, BamTrades.IBlockTrade blockTrade, IEnumerable<EzeEi.Allocation> allocations, EzeEi.Trade eTrade)
        {
            foreach (var alloc in allocations)
            {
                var trade = new BamTrades.Allocation
                {
                    Fund = GetFund(alloc.Account),
                    PrimeBroker = alloc.Custodian,
                    CounterParty = alloc.Broker,
                    PrimeBrokerAccount = alloc.Custodian,
                };

                //TODO: Lookup PB Account from Reference Data Service
                trade.AllocationId = $"{clientOrderId}-{alloc.TradeID}-{trade.Fund}-{trade.PrimeBroker}";
                trade.ParentTradeId = blockTrade.TradeId;
                trade.Quantity =  IsAllocationDeleted(alloc) ? 0 : Convert.ToDecimal(alloc.Filled);
                trade.AveragePrice = IsAllocationDeleted(alloc) ? 0 :Convert.ToDecimal(alloc.AveragePrice);
                trade.SettleDate = eTrade.SettleDate;
                trade.Commissions = new[]
                {
                        new Data.Trades.Fee
                        {
                            Currency = Constants.USD,
                            Name = "Commission",
                            Rate = Convert.ToDecimal(alloc.TotalCommission),
                            RateType = RateType.Fee
                        }
                };
                trade.Fees = ParseFees(alloc.TotalFees);
                blockTrade.Allocations.Add(trade);
            }
        }

        private string GetOrderId(string orderId, EzeEi.Trade trade, BamOrders.IClientOrderIdRepository clientOrderIdRepository, BamOrders.IOrderRepository orderRepository)
        {
            //if order exist, use current one
            if (!string.IsNullOrEmpty(orderId)) return orderId;

            //try to see if it is in Eze external field and has not been used
            if (!string.IsNullOrEmpty(trade.ExternalBlockID) 
                && !(_notificationCache.GetOrdersByEzeTradeId(trade.TradeId).Any(o=>o.Value.ClientOrderId == trade.ExternalBlockID)) 
                && orderRepository.Get(trade.ExternalBlockID)!=null)
            {
                return trade.ExternalBlockID;
            }
            
            //gnerate a new one
            var clientOrderId = clientOrderIdRepository.GenerateOrderIds(1)[0];

            return clientOrderId;
        }

        private Portfolio GetPortfolio(string strategy)
        {
            try
            {
                var portfolio = _accountService.GetPortfolioByStrategy(strategy);
                return portfolio;
            }
            catch (Exception ex)
            {
                _logger.Error("Unable to get portfolio from reference data service for strategy: " + strategy, ex);
                return null;
            }
        }

        private static string GetFund(string strategy)
        {
            var ary = strategy.Split('-');
            return ary[ary.Length-1];
        }

        private static BamTrades.Fee[] ParseFees(decimal fee)
        {
            var tradeFees = new List<Data.Trades.Fee>();
           
            var tradeFee = new Data.Trades.Fee()
            {
                Currency = Constants.USD,
                Name = "Total",
                Rate = Convert.ToDecimal(fee),
                RateType = RateType.Fee
            };
            tradeFees.Add(tradeFee);
             
            return tradeFees.ToArray();
        }

        private static SideType GetSideType(EzeEi.TradeAction action)
        {
            switch (action)
            {
                case EzeEi.TradeAction.Buy:
                    return SideType.Buy;
                case EzeEi.TradeAction.Cover:
                    return SideType.Cover;
                case EzeEi.TradeAction.Sell:
                    return SideType.Sell;
                case EzeEi.TradeAction.Short:
                    return SideType.SellShort;
                default:
                    return SideType.Unknown;
             }
        }

        private BamOrderStatus GetOrderStatus(EzeEi.Trade trade)
        {
            if (IsTradeDeleted(trade)) return BamOrderStatus.Deleted;

            if (trade.State == "A") return BamOrderStatus.Finalized;
            switch (trade.Status.ToUpperInvariant())
            {
                case "NEW":
                    return BamOrderStatus.New;
                case "OPEN":
                    return BamOrderStatus.Working;
                case "DONE":
                    return BamOrderStatus.Filled;
                case "PROPOSED":
                    return BamOrderStatus.PendingValidation;
                default:
                    _logger.Error($"Received Invalid Trade Status From EZE -  TradeID: {trade.TradeId}, EZE Status: {trade.Status}");
                    return BamOrderStatus.Error;
            }
        }

        private static BamTradeStatus GetTradeStatus(EzeEi.Trade trade)
        {
            return  BamTradeStatus.Modified;
        }

        private static bool IsTradeDeleted(EzeEi.Trade trade)
        {
            return string.Compare(trade.MessageType, "DELETE", StringComparison.InvariantCultureIgnoreCase) == 0 || IsOPSTrade(trade);
        }

        private static bool IsOPSTrade(EzeEi.Trade trade)
        {
            return string.Compare(trade.Trader, "OPS", StringComparison.InvariantCultureIgnoreCase) == 0;
        }

        private static bool IsAllocationDeleted(EzeEi.Allocation allocation)
        {
            return  string.Compare(allocation.MessageType, "DELETE", StringComparison.InvariantCultureIgnoreCase) == 0;
        }

        public static void CopyBasicEzeTrade(EzeEi.Trade src, EzeEi.Trade dest)
        {
            dest.RTBlotterTimeStamp = src.RTBlotterTimeStamp;
            dest.Status = src.Status;
            dest.State = src.State;
            dest.TradeId = src.TradeId;
            dest.Symbol = src.Symbol;
            dest.LimitPrice = src.LimitPrice;
            dest.Trader = src.Trader;
        }
    }
}
