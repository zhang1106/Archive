using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Threading.Tasks;
using Bam.Oms.Configuration;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Orders;
using Bam.Oms.EndPoints.Hub.Signals;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Service.Security;
using Bam.Oms.SodPosition.Svc;
using BAM.Infrastructure.Ioc;
using log4net;
using log4net.Config;
using Newtonsoft.Json;

namespace Bam.Oms.Service
{
    public partial class OrderGateway : ServiceBase, IOrderGateway
    {
        private static readonly ILog _logger = LogManager.GetLogger("Bam.Oms.Service");
        private readonly IFlowManager _flowManager;
        private readonly ISettings _settings;
        private readonly ISodPositionEdit _sodPositionEdit;

        [Log]
        public OrderGateway(IOrderSubmission[] orderClients, ISodPositionEdit sodPositionEdit,
            IFlowManager flowManager,
            ISecurityProcessor securityProcessor,
            ISettings settings,
            OrderHubSignal orderHubSignal,
            TradeHubSignal tradeHubSignal
            //,PositionHubSignal positionHubSignal
            ) //TODO: REMOVE THESE INTO THEIR CORRESPONDING PROCESSOR
        {

            //NOTE: Do NOT remove any of these *HubSignal args as they are used for initialization purposes
            if (orderHubSignal == null) throw new ArgumentNullException(nameof(orderHubSignal));
            if (tradeHubSignal == null) throw new ArgumentNullException(nameof(tradeHubSignal));
            //if (positionHubSignal == null) throw new ArgumentNullException(nameof(positionHubSignal));
            if (securityProcessor == null) throw new ArgumentNullException(nameof(securityProcessor));

            InitializeComponent();
            _settings = settings;
            _logger.Info("***BEGIN SETTINGS DUMP");
            _logger.Info(ObjectDumper.Dump(_settings));
            _logger.Info("***END SETTINGS DUMP");
            IEnumerable<IOrderSubmission> orderSubmissions = orderClients as IList<IOrderSubmission> ??
                                                             orderClients.ToList();
            OrderClients = orderSubmissions;
            _sodPositionEdit = sodPositionEdit;
            _flowManager = flowManager;            

            _flowManager.FlowManagerInitialized += FlowManagerOnFlowManagerInitialized;
        }

        public IEnumerable<IOrderSubmission> OrderClients { get; protected set; }

        private void OrderClientOnNewCancelOrdersReady(IList<string> orderIds)
        {
            try
            {
                _flowManager.ProcessCancelOrders(orderIds);
            }
            catch (AggregateException exceptions)
            {
                foreach (var exception in exceptions.InnerExceptions)
                {
                    _logger.ErrorFormat("Error processing cancel orders ({2}) {0}-{1}", exception.Message,
                        exception.StackTrace, JsonConvert.SerializeObject(orderIds.ToList()));
                }
            }
        }

        private void OrderClientOnNewDeleteOrdersReady(IList<string> orderIds)
        {
            try
            {
                _flowManager.ProcessDeleteOrders(orderIds);
            }
            catch (AggregateException exceptions)
            {
                foreach (var exception in exceptions.InnerExceptions)
                {
                    _logger.ErrorFormat("Error processing cancel orders ({2}) {0}-{1}", exception.Message,
                        exception.StackTrace, JsonConvert.SerializeObject(orderIds.ToList()));
                }
            }
        }

        private void OrderClientNewOrdersToRouteReady(Tuple<IList<string>, string> arguments)
        {
            try
            {
                _flowManager.RouteOrders(arguments.Item1, arguments.Item2);
            }
            catch (AggregateException exceptions)
            {
                foreach (var exeception in exceptions.InnerExceptions)
                {
                    _logger.ErrorFormat("Error processing routing orderids {2} {0}-{1}", exeception.Message,
                        exeception.StackTrace, string.Concat(arguments.Item1, ','));
                }
            }
        }

        private void OrderClientOnNewOrdersReady(IList<IOrder> orders, string batchId, bool fromFile)
        {
            if (orders == null || orders.Count == 0)
            {
                _logger.InfoFormat("No orders to process.");
                return;
            }
            _logger.InfoFormat("Processing new orders for batch {0}.", batchId);
            _flowManager.ProcessOrders((List<IOrder>)orders, batchId, fromFile);
            _logger.InfoFormat("Completed processing new orders for batch {0}.", batchId);
        }

        private void FlowManagerOnFlowManagerInitialized()
        {            
            Task.Run(() =>
            {
                foreach (var orderClient in OrderClients)
                {
                    try
                    {
                        orderClient.NewOrdersReady += OrderClientOnNewOrdersReady;
                        orderClient.NewCancelOrdersReady += OrderClientOnNewCancelOrdersReady;
                        orderClient.NewDeleteOrdersReady += OrderClientOnNewDeleteOrdersReady;
                        orderClient.NewOrdersToRouteReady += OrderClientNewOrdersToRouteReady;
                        orderClient.LocateRequestReceived += OrderClientLocateRequestReceived;
                        orderClient.AcceptOrders();
                    }
                    catch (Exception ex)
                    {
                        _logger.Error($"Error while setting up an Order Client. {orderClient}.", ex);                        
                    }                    
                }                
            });

            _logger.Info("Gateway Service initialization complete. Service is ready to process orders.");            
        }

        private void OrderClientLocateRequestReceived(IList<string> orderIds)
        {
            try
            {
                _flowManager.RequestLocates(orderIds);
            }
            catch (AggregateException exceptions)
            {
                _logger.Error($"Error attempting to re-request locates for OrderIds {JsonConvert.SerializeObject(orderIds)}");

                foreach (var ex in exceptions.InnerExceptions)
                {
                    _logger.Error($"Error attempting to re-request locates {ex.Message}\n {ex.StackTrace}");
                }
            }
        }

        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        private static void Main(string[] args)
        {
            var currentDomain = AppDomain.CurrentDomain;
            currentDomain.UnhandledException += OrderGateway_UnhandledException;
            Directory.SetCurrentDirectory(currentDomain.BaseDirectory);
            XmlConfigurator.Configure();
            _logger.Info($"Order Gateway Version: {typeof (OrderGateway).Assembly.GetName().Version}");            

            try
            {
                var service = (OrderGateway)BAM.Infrastructure.Ioc.Container.Instance.Resolve<IOrderGateway>();

                if (Environment.UserInteractive)
                {
                    service.OnStart(args);
                    Console.WriteLine("Press any key to stop program");
                    Console.Read();
                    service.OnStop();
                }
                else
                {
                    Run(service);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Error instantiating the gateway.", ex);

                throw;
            }
        }

        private static void OrderGateway_UnhandledException(object sender, UnhandledExceptionEventArgs args)
        {
            var e = args.ExceptionObject as Exception;
            if (e == null)
            {
                _logger.ErrorFormat("Unknown exception thrown. Exception: {0}", args.ExceptionObject);
            }
            else
            {
                _logger.ErrorFormat("Exception unhandled. Exception {0}", e);
            }

            if (args.IsTerminating)
            {
                _logger.FatalFormat("Service terminating due to an unhandled fatal exception.");
            }

            BAM.Infrastructure.Ioc.Container.Instance.Dispose(); //this should flush the repositories
        }

        [Log]
        protected override async void OnStart(string[] args)
        {
            try
            {
                _logger.Info($"Starting...{Assembly.GetExecutingAssembly().FullName}");

                //start wcf for sodPosition update
                _logger.Info("Starting position edit wcf ......");
                _sodPositionEdit.Start();

                _logger.Info("Gateway Service Started. Initializing.....");
            }
            catch (Exception ex)
            {
                _logger.FatalFormat("Unable to start service {0} - {1}", ex.Message, ex.StackTrace);
            }
        }

        protected override void OnStop()
        {
            _logger.Info("Stopping......");

            if (OrderClients != null)
            {
                foreach (var orderClient in OrderClients)
                {
                    orderClient.NewOrdersReady -= OrderClientOnNewOrdersReady;
                    orderClient.NewCancelOrdersReady -= OrderClientOnNewCancelOrdersReady;
                }
            }

            _flowManager.FlowManagerInitialized -= FlowManagerOnFlowManagerInitialized;
            try
            {
                // This would call the dispose on all the injected disposable objects, including the persistence repositories. The persistence caches are flushed at dispose.
                BAM.Infrastructure.Ioc.Container.Instance.Dispose();
            }
            catch (Exception ex)
            {
                _logger.Warn("Exception disposing IOC container.", ex);
            }


            _logger.Info("Stopped service.");
        }
    }
}