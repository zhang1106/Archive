﻿using System;
using Bam.Oms.Data.Portfolios;

namespace Bam.Oms.RefData
{
    public class MissingPortfolioException : Exception
    {
        public MissingPortfolioException(IPortfolio portfolio) : base($"No matching portfolio for {portfolio}")
        {
        }
    }
}