﻿using System.Web.Http.Dependencies;
using Microsoft.AspNet.SignalR.Hubs;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.SignalR
{
    public class HubActivator : IHubActivator
    {
        private readonly IDependencyResolver _resolver;

        public HubActivator(IDependencyResolver resolver)
        {
            _resolver = resolver;
        }

        public IHub Create(HubDescriptor descriptor)
        {
            return (IHub)_resolver.GetService(descriptor.HubType);
        }
    }
}
