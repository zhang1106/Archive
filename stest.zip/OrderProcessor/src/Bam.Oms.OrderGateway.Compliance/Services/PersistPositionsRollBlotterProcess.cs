﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Time;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;
using Bam.Oms.OrderGateway.Infrastructure.Persistence;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Infrastructure.Roll;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class PersistPositionsRollBlotterProcess : PersistingRollBlotterProcess
    {
        private readonly IIndexFactory _indexFactory;
        private readonly IReferenceDataService _referenceDataService;
        private readonly IClock _clock;

        public PersistPositionsRollBlotterProcess(
            IIndexFactory indexFactory,
            IDbPersistence dbPersistence,
            IReferenceDataService referenceDataService,
            IClock clock)
            : base(dbPersistence)
        {
            _indexFactory = indexFactory;
            _referenceDataService = referenceDataService;
            _clock = clock;
        }

        public ILogger Logger { get; set; }

        public override void Roll(DateTime rolledAt, BusinessDayChanged msg)
        {
            BeginTransaction();

            try
            {
                var positions = _indexFactory.For<Position>().GetAll();
                RemoveActualEffect();
                SavePositions(positions, msg.BusinessDay);
                SaveHeadroom(msg.BusinessDay);
                SaveHeadroomRatios(msg.BusinessDay);

                Commit();

                Logger?.LogInformation($"Saved {positions.Count} EOD positions with rolledAt {rolledAt:o}");
            }
            catch (Exception ex)
            {
                Logger?.LogError("Unable to persist EOD positions", ex);
            }
        }

        private void SavePositions(IReadOnlyList<Position> positions, DateTime nextBusinessDay)
        {
            var now = _clock.Now;
            var flatten = positions.SelectMany(r => r.ActualAllocations.Values);

            string fund = null, custodian = null;
            var result =
                from o in flatten
                where _referenceDataService.TryGetFund(o.Key.FundId, out fund)
                where _referenceDataService.TryGetBroker(o.Key.CustodianId, out custodian)
                select new
                {
                    BamSymbol = o.Position.Key.Symbol,
                    Quantity = o.Quantity,
                    Portfolio = o.Position.Key.Portfolio.ToString(),
                    Fund = fund,
                    Custodian = custodian,
                    TradeDate = nextBusinessDay,
                    SysDate = now,
                    Stream = (string) null,
                };

            foreach (var missingStream in result.Where(r => r.Stream == "UNKNOWN"))
            {
                Logger?.LogError($"Persisting position with unknown stream.  '{missingStream.BamSymbol}-{missingStream.Portfolio}-{missingStream.Fund}-{missingStream.Custodian}'");
            }

            DeletePreviousDataSet(() => result.Select(r => new { r.TradeDate }).Distinct(), "[og].[EodPosition2]", "eodPosition", "TradeDate", "Date");
            SaveItems(result, "[og].[EodPosition2]");
        }

        public void RemoveActualEffect()
        {
            var positions = _indexFactory.For<Position>();
            var unfinalizedOrders = _indexFactory.For<Order>().GetAll().Where(r => r.Status != OrderStatus.Finalized && r.FilledQuantity > 0);
            foreach (var order in unfinalizedOrders)
            {
                foreach (var allocation in order.Allocations)
                {
                    var position = positions.LookupBy(nameof(Position.Key), allocation.Key);

                    if (position == null)
                    {
                        Logger?.LogError($"Unable to find position for order '{order.OrderId}'.");
                        continue;
                    }

                    foreach (var actual in position.ActualAllocations)
                    {
                        if (allocation.Value.ActualAllocations.ContainsKey(actual.Key))
                        {
                            var previous = actual.Value.Quantity;
                            var orderAllocation = allocation.Value.ActualAllocations[actual.Key];
                            actual.Value.Quantity -= order.Side.IsSellSide() ? -1 * orderAllocation : orderAllocation;

                            Logger?.LogInformation($"Backing out order actual allocation '{orderAllocation}' from position allocation key '{actual.Key}' for position key '{position.Key}'.  Previous:{previous}; Current:{actual.Value.Quantity}");
                        }
                    }
                }
            }
        }

        private void SaveHeadroom(DateTime nextBusinessDay)
        {
            var headrooms = _indexFactory.For<HeadroomRule>().GetAll();
            var result = headrooms
                .SelectMany(r => r.Headrooms.Values.Where(h => !h.IsContingency)
                    .SelectMany(a => a.Thresholds.Select(n =>
                        new
                        {
                            RuleId = r.Id,
                            a.Key.Identifier,
                            BusinessDate = nextBusinessDay,
                            RuleName = r.Name,
                            IdentifierType = r.IdentifierType.ToString(),
                            a.IsExempt,
                            Direction = r.Direction.ToString(),
                            r.ReportingEntity,
                            n.Threshold,
                            Headroom = n.Quantity,
                            AlertLevel = n.ViolationLevel.ToString(),
                            n.FireOnce,
                            a.IntradayQuantity
                        })));

            DeletePreviousDataSet(() => result.Select(r => new { r.BusinessDate }).Distinct(), "[og].[EodHeadroom]", "eodheadroom", "BusinessDate", "Date");
            SaveItems(result, "[og].[EodHeadroom]");
        }

        private void SaveHeadroomRatios(DateTime nextBusinessDay)
        {
            var headrooms = _indexFactory.For<HeadroomRule>().GetAll();
            var result = headrooms
                .SelectMany(r => r.Headrooms.Values.Where(h => !h.IsContingency)
                    .SelectMany(a => a.AggregationUnitRatios.Select(n =>
                        new
                        {
                            RuleId = r.Id,
                            AggregationUnit = n.Key,
                            Ratio = n.Value,
                            BusinessDate = nextBusinessDay
                        })));

            DeletePreviousDataSet(() => result.Select(r => new { r.BusinessDate }).Distinct(), "[og].[EodHeadroomRatio]", "eodheadroom", "BusinessDate", "Date");
            SaveItems(result, "[og].[EodHeadroomRatio]");
        }
    }
}