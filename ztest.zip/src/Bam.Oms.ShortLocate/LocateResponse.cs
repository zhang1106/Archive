﻿using System.Collections.Generic;

namespace Bam.Oms.ShortLocate
{
    public class LocateResponse : ILocateResponse
    {
        public decimal RequestedSize { get; set; }
        public string Error { get; set; }
        public ILocateRequest OriginalRequest { get; set; }
    }
}