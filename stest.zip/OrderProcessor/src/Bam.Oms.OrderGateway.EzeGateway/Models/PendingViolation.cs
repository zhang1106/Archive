﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public class PendingViolation : ModelBase<PendingViolation>
    {
        public long OrderId { get; set; }
        public HashSet<Guid> RuleIds { get; } = new HashSet<Guid>();
    }
}