﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class Fee : ICloneable
    {
        public string Currency { get; set; }
        public string Name { get; set; }
        public decimal Rate { get; set; }
        public RateType RateType { get; set; }

        public object Clone()
        {
            return new Fee
            {
                Name = Name,
                Rate = Rate,
                Currency = Currency,
                RateType = RateType
            };
        }
    }
}
