﻿using System.Collections.Generic;

namespace Bam.EventQ.Sequencing
{
    public interface IBatchMessage : IMessage
    {
        
    }

    public interface IBatchMessage<TItem> : IBatchMessage
    {
        List<TItem> Items { get; }
    }
}
