﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.OrderRouting.Flex;
using Ft;
using Security = Bam.Oms.Data.Securities.Security;

namespace Bam.Oms.OrderRouting.Contracts
{
    public interface IGrpcServices
    {
        bool Connect();

        void Stop();

        bool Subscribe();

        bool Unsubscribe();

        OrderService.IOrderServiceClient OrderServiceClient { get; }        

        ISecuritySubscriptionHost SecuritySubscriptionHost { get; }

        ITradeSubscriptionHost TradeSubscriptionHost { get; }

        ISystemSubscriptionHost SystemSubscriptionHost { get; }

        event Action<IEnumerable<IPosition>> PositionUpdated;
        event Action<IEnumerable<IBlockTrade>> TradeUpdated;
        /// <summary>
        /// OrderId, OrderStaus
        /// </summary>
        event Action<IEnumerable<IOrder>> OrderStatusChanged;

        event Action<ISecurity> SecurityChanged;

        event Action<string> RollStarted;
        event Action<string> RollCompleted;        
    }
}