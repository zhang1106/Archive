﻿

CREATE procedure [dbo].[usp_createdbschema] as 
DECLARE 
@DayOfWeek		char(3), 
@Device			char(20), 
@FileStr		char (60),
@Filepath		nvarchar(200),
@Cleanup		varchar(100),
@Cmd            varchar(500),
@Server			varchar(20)

--set @Server = 'FH1-DEV1'
IF @Server is null
begin
	select    @Server = @@ServerName
end 
------------------------------------------------------
set @DayOfWeek =DATEname(dw,GETDATE())
CREATE TABLE #CmdOutput(outputdir varchar(1000)) 
insert into #CmdOutput
exec master..xp_cmdshell 'dir d:\databaseschema'

if ( select count(*) from #CmdOutput ) < 10
BEGIN
	exec master..xp_cmdshell 'md d:\databaseschema \a'
END
drop table #CmdOutput
------------------------------------------------------
declare @Version int, @Bit varchar(10)

select @Version = CONVERT (INT, right ('0' + REPLACE(substring(@@VERSION, patindex('%-%',@@Version)+2,2),'.',''), 2))
,@Bit = case when right ('0' + REPLACE(substring(@@VERSION, patindex('%-%',@@Version)+17,2),'.',''), 2) <> '64' then 32 else 64 end

select @Version Version, @Bit Bit

------------------------------------------------------

DECLARE @databases TABLE(ident INT IDENTITY(1,1) PRIMARY KEY, database_name VARCHAR(256))
INSERT @databases(database_name)
SELECT name FROM master..sysdatabases where dbid > 4 and name <> 'temp' order by name

------------------------------------------------------
DECLARE @min INT, @max INT, @database VARCHAR(256)
SELECT @min = 1, @max = (SELECT MAX(ident) FROM @databases)

WHILE @min <= @max
BEGIN

	SELECT @database = (SELECT database_name FROM @databases WHERE ident = @min)

	set @Filepath =  'd:\databaseschema\' + @database + @DayOfWeek + '.sql'
	set @Cleanup = 'del ' + @Filepath 
	exec master..xp_cmdshell  @Cleanup, No_Output
--C:\Program Files (x86)\Microsoft SQL Server\90\Tools\Publishing
--C:\Program Files (x86)\Microsoft SQL Server\90\Tools\Publishing\1.2
	IF @Version = 10 and @Bit = 64
	BEGIN
		Select @Cmd = 'C:\"Program Files (x86)"\"Microsoft SQL Server"\90\Tools\Publishing\1.2\sqlpubwiz.exe ' + ' script -d ' + @database + ' -S tcp:' + @Server + ' "' +  'd:\databaseschema\' + @database + @DayOfWeek + '.sql" ' + '-schemaonly'
		PRINT  @Cmd
		Exec master..xp_cmdshell @Cmd--, No_Output
	END
	ELSE IF @Version = 10 and @Bit = 32
	BEGIN
		Select @Cmd = 'C:\"Program Files"\"Microsoft SQL Server"\90\Tools\Publishing\1.2\sqlpubwiz.exe ' + ' script -d ' + @database + ' -S ' + @Server + ' "' +  'd:\databaseschema\' + @database + @DayOfWeek + '.sql" ' + '-schemaonly'
		Exec master..xp_cmdshell @Cmd, No_Output
	END
	
	ELSE IF @Version = 9 and @Bit = 64
	BEGIN
		Select @Cmd = 'C:\"Program Files (x86)"\"Microsoft SQL Server"\90\Tools\Publishing\sqlpubwiz.exe ' + ' script -d ' + @database + ' -S ' + @Server + ' "' +  'd:\databaseschema\' + @database + @DayOfWeek + '.sql" ' + '-schemaonly'
		Exec master..xp_cmdshell @Cmd, No_Output
	END
	ELSE IF @Version = 9 and @Bit = 32
	BEGIN
		Select @Cmd = 'C:\"Program Files"\"Microsoft SQL Server"\90\Tools\Publishing\sqlpubwiz.exe ' + ' script -d ' + @database + ' -S ' + @Server + ' "' +  'd:\databaseschema\' + @database + @DayOfWeek + '.sql" ' + '-schemaonly'
		Exec master..xp_cmdshell @Cmd, No_Output
	END
	
	ELSE IF @Version = 8 and @Bit = 64
	BEGIN
		Select @Cmd = 'C:\"Program Files (x86)"\"Microsoft SQL Server"\90\Tools\Publishing\sqlpubwiz.exe ' + ' script -d ' + @database + ' -S ' + @Server + ' "' +  'd:\databaseschema\' + @database + @DayOfWeek + '.sql" ' + '-schemaonly'
		Exec master..xp_cmdshell @Cmd, No_Output
	END
	ELSE IF @Version = 8 and @Bit = 32
	BEGIN

		Select @Cmd = 'C:\"Program Files"\"Microsoft SQL Server"\90\Tools\Publishing\sqlpubwiz.exe ' + ' script -d ' + @database + ' -S ' + @Server + ' "' +  'd:\databaseschema\' + @database + @DayOfWeek + '.sql" ' + '-schemaonly'
		Exec master..xp_cmdshell @Cmd--, No_Output
		print @Cmd
	END


	SELECT @min = @min + 1
END
------------------------------------------------------

--Exec master..xp_cmdshell 'C:\"Program Files"\"Microsoft SQL Server"\90\Tools\Publishing\sqlpubwiz.exe  script -d BAMAPP -S FH1-DEV1 "d:\databaseschema\BAMAPPMon.sql" -schemaonly'
