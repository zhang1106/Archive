﻿using System;
using System.Collections.Generic;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Filters;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using Bam.Oms.Filtering;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class ComplianceFirmPositionRulesTest
    { 
        IMarketDataProvider _marketDataProvider;
        private ISettings _settings;

        [SetUp]
        public void Setup()
        {
            //shares outstanding
            var marketDataProvider = new Mock<IMarketDataProvider>();
            marketDataProvider.Setup(n => n.GetSharesOutstanding(It.IsAny<string>())).Returns(1000000);
            _marketDataProvider = marketDataProvider.Object;

            _settings = Factory.GetSettings();
        }

        [Test]
        [TestCase(1000, "ANTO LN",  ComplianceAlertLevel.Restricted)]
        [TestCase(3000, "ANTO LN",  ComplianceAlertLevel.NoViolation)]
        [TestCase(3000, "Test", ComplianceAlertLevel.NoViolation)]
        public void TestLongOnwershipLimitCheckViolation(decimal threshhold, string symbol, Data.Enumerators.ComplianceAlertLevel vLevel)
        {
            //arr
            var rule = new LongOwnershipLimit() {Threshhold = threshhold, IsActive=true};
            //act
            var target = Factory.CreateCompliancePosition(_settings, new Security { BamSymbol = symbol}, new Policy<ICompliancePosition>(),true, 1500);
            var result = rule.CheckViolation(target.Object, false);
            //ass
            Assert.IsTrue(result.AlertLevel == vLevel);
        }
        
        [Test]
        [TestCase(-300000, ComplianceAlertLevel.Warning)]
        [TestCase(-130000, ComplianceAlertLevel.NoViolation)]
        public void TestShortSharesOutstandingWarning(decimal position, ComplianceAlertLevel expectedAlertLevel)
        {
            //arr
            //share outstanding is set to 1,000,000
            var factProvider = new Mock<IFactProvider>();
            factProvider.Setup(n => n.GetList(It.IsAny<string>())).Returns(new HashSet<string>());
           

            var parms = new List<Parameter>
            {
                new Parameter()
                {
                    Property = "Country",
                    Value = "AU",
                    Operator = new ComplianceOperator(factProvider.Object) {OperatorType = OperatorType.Equal}
                }
            };

            var rule = new ShortSharesOutstandingWarning ()
            { Threshhold = -0.25m, IsActive = true, FilterParams = parms};
            var target = Factory.CreateCompliancePosition(_settings, new Security { BamSymbol = "ANTO LN" }, new Policy<ICompliancePosition>(), true, position);
            target.SetupGet(t => t.MarketDataProvider).Returns(_marketDataProvider);

            //act
            var result = rule.CheckViolation(target.Object, false);
            //ass
            Assert.IsTrue(result.AlertLevel == expectedAlertLevel);
        }
    }
}
