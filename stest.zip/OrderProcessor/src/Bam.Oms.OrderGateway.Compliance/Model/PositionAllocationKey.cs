using System;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public struct PositionAllocationKey : IEquatable<PositionAllocationKey>
    {
        private readonly int _hashCode;

        public PositionAllocationKey(int fundId, int custodianId)
        {
            FundId = fundId;
            CustodianId = custodianId;
            _hashCode = unchecked(CustodianId.GetHashCode()*FundId.GetHashCode());
        }

        public int FundId { get; }
        public int CustodianId { get; }

        public bool Equals(PositionAllocationKey other)
        {
            return other.CustodianId == CustodianId && other.FundId == FundId;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is PositionAllocationKey))
                return false;

            return Equals((PositionAllocationKey) obj);
        }

        public override int GetHashCode()
        {
            return _hashCode;
        }

        public override string ToString()
        {
            return $"Fund={FundId}, Custodian={CustodianId}";
        }
    }
}