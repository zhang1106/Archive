﻿namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public struct FundAllocation
    {
        public FundAllocation(long quantity, long quantitySansOmni)
        {
            Quantity = quantity;
            QuantitySansOmni = quantitySansOmni;
        }
        
        public long Quantity { get; set; }
        public long QuantitySansOmni { get; set; }
    }
}
