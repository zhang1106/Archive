﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using Bam.Oms.Compliance;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.EndPoints.Compliance;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.EndPoints.PermissionService;
using Bam.Oms.EndPoints.SodPosition;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.RefData;
using Bam.Oms.SodPosition.Svc;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class HttpListenerTests //todo: honestly, most of this api is pass thru, not sure if we even need any tests
    {
        [Test]
        public void VerifySubmitOrder()
        {
            // arrange
            Container.Instance.RegisterInstance(new Mock<ISettings>().Object);

            var validator = new Mock<IOrderValidator>();
            validator.Setup(r => r.IsValidOrder(It.IsAny<IList<IOrder>>())).Returns(true);

            IList<IOrder> orderList = null;
            var portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");

            var settings = new Mock<ISettings>();
            settings.SetupGet(s => s.PermissionedApplications).Returns("PMUI,OrderGateway");
            settings.SetupGet(s => s.EnablePermission).Returns("NO");
            Container.Instance.RegisterInstance<ISettings>(settings.Object);

            var notifier = new Mock<IOrderNotifier>();
            notifier.Setup(n => n.NotifyNewOrders(It.IsAny<IList<IOrder>>()))
                .Callback<IList<IOrder>>((orders) => { orderList = orders; });

            Order[] ordersToSubmit = new[] { new Order { Portfolio = portfolio }, new Order { Portfolio = portfolio }, new Order { Portfolio = portfolio } };


            var prepUtil = new Mock<IOrderPrepUtility>();
            prepUtil.Setup(r => r.AssignOrderIds(It.IsAny<List<Order>>())).Returns(new List<string> { "123", "456", "789" });
            prepUtil.Setup(svc => svc.ScaleOrders(It.IsAny<List<Order>>())).Returns(ordersToSubmit);

            var permissionService = new Mock<PermissionService>();
            permissionService.Setup(svc => svc.GetStrategies(It.IsAny<string>()))
                .Returns(new[] { new StrategyInfo { StrategyCode = "MYPORT-MYSTRATEGY" } });            

            var accountService = new Mock<IAccountService>();
            accountService.Setup(svc => svc.SetAccountAttributes(It.IsAny<List<Order>>())).Returns(ordersToSubmit);
            var flowManager = new Mock<IFlowManager>();

            var controller = new OrderController(notifier.Object, new Mock<IOrderRepository>().Object,
                new Mock<IHostConfiguration>().Object, prepUtil.Object, new Mock<ILogger>().Object,
                validator.Object, accountService.Object, flowManager.Object); var myIdentity = WindowsIdentity.GetCurrent();
            controller.User = new WindowsPrincipal(myIdentity);


            // act
            var unit = controller.PostOrders(ordersToSubmit);

            // assert
            Assert.That(unit.Count, Is.EqualTo(3));
            Assert.That(orderList.Count, Is.EqualTo(3));
            Assert.That(unit.Contains("123"), Is.True);
        }

        [Test]
        public void VerifyAmendOrder()
        {
            // arrange
            Container.Instance.RegisterInstance(new Mock<ISettings>().Object);

            IList<IOrder> orderList = null;
            Portfolio portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");

            var notifier = new Mock<IOrderNotifier>();
            notifier.Setup(n => n.NotifyNewOrders(It.IsAny<IList<IOrder>>()))
                .Callback<IList<IOrder>>((orders) => { orderList = orders; });

            var settings = new Mock<ISettings>();
            settings.SetupGet(s => s.PermissionedApplications).Returns("PMUI,OrderGateway");
            settings.SetupGet(s => s.EnablePermission).Returns("NO");
            Container.Instance.RegisterInstance<ISettings>(settings.Object);

            var validator = new Mock<IOrderValidator>();
            validator.Setup(r => r.IsValidOrder(It.IsAny<IList<IOrder>>())).Returns(true);

            var flowManager = new Mock<IFlowManager>();

            IEnumerable<IContainsPortfolio> enrichedOrders = null;

            var acctSvc = new Mock<IAccountService>();
            acctSvc.Setup(r => r.SetAccountAttributes(It.IsAny<IEnumerable<IContainsPortfolio>>()));

            var prepUtil = new Mock<IOrderPrepUtility>();
            prepUtil.Setup(r => r.AssignOrderIds(It.IsAny<IEnumerable<IOrder>>())).Returns(new[] {"456"});

            var repo = new Mock<IOrderRepository>();
            repo.Setup(r => r.Get(It.IsAny<string>())).Returns(new Order() {Portfolio = portfolio, ClientOrderId = "123", OrderStatus = BamOrderStatus.PendingSend});

            var controller = new OrderController(notifier.Object, repo.Object,
                new Mock<IHostConfiguration>().Object,prepUtil.Object, new Mock<ILogger>().Object,
                validator.Object, acctSvc.Object, flowManager.Object);
            WindowsIdentity myIdentity = WindowsIdentity.GetCurrent();
            controller.User = new WindowsPrincipal(myIdentity);
            // act
            var unit = controller.PostAmendedOrder(new Order() { Portfolio = portfolio, OrderStatus = BamOrderStatus.PendingSend});

            // assert
            Assert.That(unit, Is.Not.Null);
            Assert.That(orderList[0].OriginalOrderId, Is.EqualTo("123"));
        }

        [Test]
        public void VerifyCancelOrder()
        {
            // arrange
            Container.Instance.RegisterInstance(new Mock<ISettings>().Object);

            IList<string> orderList = null;
            Portfolio portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");

            var settings = new Mock<ISettings>();
            settings.SetupGet(s => s.PermissionedApplications).Returns("PMUI,OrderGateway");
            settings.SetupGet(s => s.EnablePermission).Returns("NO");
            Container.Instance.RegisterInstance<ISettings>(settings.Object);

            var notifier = new Mock<IOrderNotifier>();
            notifier.Setup(n => n.NotifyCancelOrders(It.IsAny<IList<string>>()))
                .Callback<IList<string>>((orders) => { orderList = orders; });

            var orderRepository = new Mock<IOrderRepository>();
            orderRepository.Setup(rep => rep.Get(It.IsAny<String>())).Returns(new Order() { ClientOrderId = "123", Portfolio = portfolio });

            var permissionService = new Mock<PermissionService>();
            permissionService.Setup(svc => svc.GetStrategies(It.IsAny<String>()))
                .Returns(new StrategyInfo[] { new StrategyInfo() { StrategyCode = "MYPORT-MYSTRATEGY" } });

            var flowManager = new Mock<IFlowManager>();
            var controller = new OrderController(notifier.Object, orderRepository.Object,
                new Mock<IHostConfiguration>().Object, new Mock<IOrderPrepUtility>().Object, new Mock<ILogger>().Object,
                new Mock<IOrderValidator>().Object, new Mock<IAccountService>().Object, flowManager.Object);
            WindowsIdentity myIdentity = WindowsIdentity.GetCurrent();
            controller.User = new WindowsPrincipal(myIdentity);
            // act
            var unit = controller.DeleteOrders(new[] { "123", "123" });

            // assert
            Assert.That(unit, Is.EqualTo(2));
            Assert.That(orderList.Count, Is.EqualTo(2));
        }

        [Test]
        public void VerfiyGetSodPositionUpdates()
        {
            //arrange
            var sodPositionSvc = new Mock<ISodPositionEdit>();
            sodPositionSvc.Setup(n => n.GetSodPositions(It.IsAny<DateTime?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(SodPositionTestDataProvider.SodPositionUpdates);

            //try to override the dependency resolution, hopefully the RegisterTypes.Register does not fire after this call
            Container.Instance.RegisterInstance<ISettings>(new Settings(new Mock<IDateProvider>().Object, new Mock<ILogger>().Object) { EnablePermission = "DOESNT MATTER!" });

            var controller = new SodPositionController(sodPositionSvc.Object, new Mock<IHostConfiguration>().Object, new Mock<ILogger>().Object);
            WindowsIdentity myIdentity = WindowsIdentity.GetCurrent();
            controller.User = new WindowsPrincipal(myIdentity);
            //act
            var positions = controller.GetUpdates(new DateTime(2015, 12, 11, 12, 10, 0, 0, DateTimeKind.Utc));

            //assert
            Assert.That(positions.Count, Is.EqualTo(1));
        }

        [Test]
        public void VerfiyGetSodPositions()
        {
            //arrange
            var sodPositionSvc = new Mock<ISodPositionEdit>();
            sodPositionSvc.Setup(n => n.GetSodPositions(It.IsAny<DateTime?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(SodPositionTestDataProvider.SodPositionUpdates);

            //try to override the dependency resolution, hopefully the RegisterTypes.Register does not fire after this call
            Container.Instance.RegisterInstance<ISettings>(new Settings(new Mock<IDateProvider>().Object, new Mock<ILogger>().Object) { EnablePermission = "DOESNT MATTER!" });

            var controller = new SodPositionController(sodPositionSvc.Object, new Mock<IHostConfiguration>().Object, new Mock<ILogger>().Object);
            WindowsIdentity myIdentity = WindowsIdentity.GetCurrent();
            controller.User = new WindowsPrincipal(myIdentity);
            //act
            var positions = controller.Get(new DateTime(2015, 12, 11, 1, 1, 0, 0, DateTimeKind.Utc));

            //assert
            Assert.That(positions.Count, Is.EqualTo(3));
        }

        [Test]
        public void VerfiyGetRules()
        {
            //arrange
            var sampleRule = new ShortOwnershipFiling(null, null, null) { Id = 0, Name = "Test", Type = typeof(ShortOwnershipFiling).FullName, Description = "Test", IsActive = true };
            var ruleRepository = new Mock<IRuleRepository<CompliancePosition>>();
            ruleRepository.Setup(n => n.GetAll())
                .Returns(new List<Rule<CompliancePosition>> { sampleRule });

            var permissionService = new Mock<PermissionService>();
            permissionService.Setup(svc => svc.GetStrategies(It.IsAny<String>()))
                .Returns(new StrategyInfo[] { new StrategyInfo() { StrategyCode = "MYPORT-MYSTRATEGY" } });

            var controller = new RuleController(ruleRepository.Object, new Mock<IHostConfiguration>().Object, new Mock<ILogger>().Object);
            WindowsIdentity myIdentity = WindowsIdentity.GetCurrent();
            controller.User = new WindowsPrincipal(myIdentity);
            //act
            var rules = controller.Get(false);

            //assert
            Assert.That(rules.Count, Is.EqualTo(1));
        }

        [Test]
        public void VerfiyGetRuleResults()
        {
            //arrange
            var repository = new Mock<IRuleResultRepository>();
            repository.Setup(n => n.Get(It.IsAny<DateTime>())).Returns(new List<RuleResult>()
            {
                new RuleResult()
            });

            var permissionService = new Mock<PermissionService>();
            permissionService.Setup(svc => svc.GetStrategies(It.IsAny<String>()))
                .Returns(new StrategyInfo[] { new StrategyInfo() { StrategyCode = "MYPORT-MYSTRATEGY" } });

            var controller = new RuleResultController(repository.Object, new Mock<IHostConfiguration>().Object, new Mock<ILogger>().Object);
            WindowsIdentity myIdentity = WindowsIdentity.GetCurrent();
            controller.User = new WindowsPrincipal(myIdentity);
            //act
            var rules = controller.Get(DateTime.UtcNow);

            //assert
            Assert.That(rules.Count, Is.EqualTo(1));
        }
    }
}