﻿using System;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Recovery
{
    public class ReplayFromPipelineStepRecoveryProcess<TItem> : IRecoveryProcess
    {
        private readonly IProcessingPipelineStep<TItem> _pipelineStep;
        private readonly Func<PipelineQueueItem<TItem>, SequenceInfo> _seqInfoAccessor;
        private readonly IQueueItemHandler<PipelineQueueItem<TItem>> _handler;

        public ILogger Logger { get; set; }

        public ReplayFromPipelineStepRecoveryProcess(
            IProcessingPipelineStep<TItem> pipelineStep,
            Func<PipelineQueueItem<TItem>, SequenceInfo> seqInfoAccessor,
            IQueueItemHandler<PipelineQueueItem<TItem>> handler)
        {
            if (pipelineStep == null) throw new ArgumentNullException(nameof(pipelineStep));
            if (seqInfoAccessor == null) throw new ArgumentNullException(nameof(seqInfoAccessor));
            if (handler == null) throw new ArgumentNullException(nameof(handler));

            _pipelineStep = pipelineStep;
            _seqInfoAccessor = seqInfoAccessor;
            _handler = handler;
        }

        public bool Execute(int? topic, long sequence)
        {
            if (!_pipelineStep.Pause())
                return false;

            try
            {
                return _pipelineStep.Queue.ReplayMessages(
                    item =>
                    {
                        var seqInfo = _seqInfoAccessor(item);
                        return (topic == null || seqInfo.Topic == topic) &&
                               (seqInfo.Sequence == sequence);
                    },
                    item =>
                    {
                        if (topic == null) return true;
                        var seqInfo = _seqInfoAccessor(item);
                        return seqInfo.Topic == topic;
                    }, _handler);
            }
            finally
            {
                _pipelineStep.Resume();
            }
        }
    }
}
