﻿using System;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;


namespace Bam.Oms.Persistence.Compliance
{
    public class FactRepository : DBRepository<Fact>, IFactRepository
    {
        internal static readonly Func<Fact, dynamic> ParamMap = item => new 
        {
            FactId = item.FactId,
            Name = item.Name,
            Value = item.Value, 
        };

        //(ISettings settings, ILogger logger, String schemaName, String tableName, String idColumnName, Func<dynamic, T> resultMap, Func<T, dynamic> parameterMap)
        public FactRepository(ISettings settings, ILogger logger) : base(settings, logger, "cp", settings.FactTable, "FactId", null, ParamMap)
        { }
        
    }
}
