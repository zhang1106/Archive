﻿using System.Collections.Generic;
using Bam.EventQ.Snapshot;

namespace Bam.Oms.OrderGateway.Compliance.Model.Snapshot
{
    public class OpeningClosingAllocationSnapshot : ISnapshot
    {
        public Dictionary<long, List<Allocation>> Items { get; } = new Dictionary<long, List<Allocation>>();

        public class Allocation
        {
            public bool IsOpening { get; set; }
            public string Portfolio { get; set; }
            public int FundId { get; set; }
            public int CustodianId { get; set; }
            public string Side { get; set; }
            public long Quantity { get; set; }
            public long ClosingPortionSansOmni { get; set; }
        }
    }
}
