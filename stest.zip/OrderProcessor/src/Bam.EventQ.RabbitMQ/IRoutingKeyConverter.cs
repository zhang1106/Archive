﻿namespace Bam.EventQ.RabbitMQ
{
    public interface IRoutingKeyConverter
    {
        int GetTopic(string routingKey);
    }
}
