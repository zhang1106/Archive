﻿namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public struct ActualEffects
    {
        public long Quantity;
        
        public static ActualEffects operator -(ActualEffects a, ActualEffects b)
        {
            return new ActualEffects
            {
                Quantity = a.Quantity - b.Quantity,
            };
        }
    }
}