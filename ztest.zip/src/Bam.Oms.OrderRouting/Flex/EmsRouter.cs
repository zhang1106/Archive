﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.EMSAdapters.Contracts;
using Bam.Oms.Filtering;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using Ft;
using Google.ProtocolBuffers;
using Grpc.Core;
using Microsoft.Practices.ObjectBuilder2;
using Microsoft.Practices.Unity.ObjectBuilder;
using Newtonsoft.Json;
using ComplianceIssue = Bam.Oms.Data.ComplianceIssue;
using Order = Ft.Order;
using Security = Bam.Oms.Data.Securities.Security;

namespace Bam.Oms.OrderRouting.Flex
{
    public class EmsRouter : IEmsRouter
    {
        private const string FixTagBatchId = "99120";
        private const string FixTagBorrowRate = "99007";
        private const string LocateDatetimeFormat = "yyyy - MM - dd HH:mm:ss";

        // ReSharper disable NotAccessedField.Local
        private readonly IAccountService _accountService;
        private readonly ISecurityMasterService _securityMasterService;
        // ReSharper restore NotAccessedField.Local
        private readonly IGrpcServices _grpcServices;
        private readonly IInstructionToEmsTagMapper _instructionToEmsTagMapper;
        private readonly ILogger _logger;
        private readonly IStreamParser _streamParser;        

        public EmsRouter(IGrpcServices grpcServices, IStreamParser streamParser, ILogger logger, IInstructionToEmsTagMapper instructionToEmsTagMapper, IAccountService accountService, ISecurityMasterService securityMasterService)
        {
            if (grpcServices == null) throw new ArgumentNullException(nameof(grpcServices));
            if (instructionToEmsTagMapper == null) throw new ArgumentNullException(nameof(instructionToEmsTagMapper));
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));
            if (streamParser == null) throw new ArgumentNullException(nameof(streamParser));
            if (logger == null) throw new ArgumentNullException(nameof(logger));

            _grpcServices = grpcServices;
            _streamParser = streamParser;
            _logger = logger;
            _instructionToEmsTagMapper = instructionToEmsTagMapper;
            _accountService = accountService;
            _securityMasterService = securityMasterService;

            _grpcServices.OrderStatusChanged += HandleOrderStatusChanged;
            _grpcServices.TradeUpdated += HandleTradeUpdated;
            _grpcServices.RollStarted += HandleRollStarted;
            _grpcServices.RollCompleted += HandleRollCompleted;
            _grpcServices.SecurityChanged += HandleSecurityChanged;        
        }        

        public event Action<IEnumerable<IOrder>> OrderStatusChanged;
        public event Action<IEnumerable<IBlockTrade>> TradeUpdated;
        public event Action<Data.Securities.ISecurity> SecurityUpdated;
        public event Action<string> RollStarted;
        public event Action<string> RollCompleted;
        public event Action<string> Connected;
        public event Action<string> Disconnected;

        public bool Connect()
        {
            return _grpcServices.Connect();
        }

        public void Disconnect()
        {
            _grpcServices.Stop();
        }

        public bool Subscribe(IFilter<EmsSubscription> filter = null)
        {
            return _grpcServices.Subscribe();
        }

        public bool Unsubscribe()
        {
            return _grpcServices.Unsubscribe();
        }

        public IEnumerable<IOrder> SubmitOrders(IEnumerable<IOrder> orders, bool stageOrders = false)
        {
            var ordersList = orders as IList<IOrder> ?? orders.ToList();

            HashSet<IOrder> returnList = new HashSet<IOrder>();
            if (!ordersList.Any()) return returnList;
            string batchId = ordersList.First().BatchId;

            _logger.Debug($"[BatchId:{batchId}] Submitting {ordersList.Count()} orders to EMS {JsonConvert.SerializeObject(ordersList.ToList())} ");

            var flexOrders = ordersList.Select(CreateFlexOrder).ToList();

            var flexOrderBatch = CreateOrderRequestBatch(flexOrders, stageOrders, ordersList.First().Trader);

            using (var stream = _grpcServices.OrderServiceClient.CreateOrders(flexOrderBatch))
            {
                _logger.Info($"[BatchId:{batchId}] Finished submitting {ordersList.Count()} orders to EMS.");
                ordersList.ForEach(o => o.OrderStatus = BamOrderStatus.PendingAck);
                var response = ParseStreamReturnFirst(stream);

                if (response != null)
                {
                    _logger.Debug($"[BatchId: {batchId}] OrderResponse {response}.");
                    if (response.Status.Success)
                    {
                        _logger.Info($"[BatchId:{batchId}] Submitted {ordersList.Count()} orders successfully orders to EMS.");
                        returnList = ProcessOrderResponse(response, ordersList, batchId);

                        var ordersWithNoResponse = ordersList.Except(returnList).ToList();
                        _logger.Info($"[BatchId:{batchId}] No synchronous response received from FLEX on {ordersWithNoResponse.Count} orders.");

                        foreach (IOrder ord in ordersWithNoResponse)
                        {
                            _logger.Info(
                                $"[BatchId:{batchId},OrderId:{ord.ClientOrderId}] No synchronous response received from FLEX.");
                            returnList.Add(ord);
                        }
                    }
                    else
                    {
                        _logger.Error($"[BatchId {batchId}] failed with the following error: {response.Status.Description}");
                        returnList = ProcessOrderResponse(response, ordersList, batchId);

                        var ordersWithNoResponse = ordersList.Except(returnList).ToList();                        
                        ordersWithNoResponse.ForEach(o =>
                        {
                            o.OrderStatus = BamOrderStatus.Error;
                            returnList.Add(o);
                            var otherErrorMessage =
                            $"[BatchId {batchId}] Order [{response.BatchId}][{o.ClientOrderId}] rejected by Flex because {response.Status.Description}.";                            
                            o.StatusMessages.Add($"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}:{response.Status.Description}");
                            _logger.Info(otherErrorMessage);
                        });                       

                    }
                }                
                _logger.Info($"Completed reading the response from FLEX EMS.");
            }

            var idsToReturn = returnList.Select(o => o.ClientOrderId).ToList();
            _logger.Info($"OrderStatusChanged raised with Ids {string.Join(", ", idsToReturn)}");
            Utility.RaiseEvent(returnList, OrderStatusChanged);
            return returnList;
        }

        public IList<string> CancelOrders(IList<string> orderIds)
        {
            if (!orderIds.Any()) return null;

            var cancelRejectCount = 0;

            var idsToCancel = orderIds.Count > 1 ? string.Join(", ", orderIds) : orderIds.FirstOrDefault();
            _logger.Info($"Cancelling {idsToCancel}");

            //place holder waiting on flex to give us prob use case for user field on request

            var cancelRequests = CreateCancelOrderRequestBatch(orderIds, Constants.DefaultTrader);

            var response = ParseStreamReturnFirst(_grpcServices.OrderServiceClient.CancelOrders(cancelRequests));

            List<string> returnList = null;

            if (response != null)
            {
                returnList = response.Results.Where(r => r.Success).Select(result => result.OrderId).ToList();

                if (returnList.Count == 0)
                {
                    _logger.Warn("None of the orders have been successfully cancelled");

                }

                var listToRaiseOrderStatusChangedOn = new List<IOrder>();
                foreach (var cancelOrderResult in response.Results)
                {
                    var order = new Data.Orders.Order
                    {
                        ClientOrderId = cancelOrderResult.OrderId,
                    };

                    if (cancelOrderResult.Success)
                    {
                        order.OrderStatus = BamOrderStatus.Cancelled;
                    }
                    else
                    {
                        cancelRejectCount++;
                        var errorMessage = $"Unable to cancel order id {cancelOrderResult.OrderId}. {cancelOrderResult.Reason}";
                        order.OrderStatus = BamOrderStatus.CancelReject;
                        _logger.Warn(errorMessage);
                        order.StatusMessages.Add($"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}:{errorMessage}");
                    }

                    listToRaiseOrderStatusChangedOn.Add(order);
                }

                if(cancelRejectCount > 0)
                    _logger.Error($"Unable to cancel {cancelRejectCount} of {cancelRequests.OrderIds.Count} orders");

                Utility.RaiseEvent(listToRaiseOrderStatusChangedOn, OrderStatusChanged);
            }
            return returnList;
        }

        public bool CancelOrders(IFilter<IOrder> orderFilter)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IOrder>  AmendOrders(IEnumerable<IOrder> orders)
        {
            return orders.Select(order => AmendOrder(order, order.OriginalOrderId, false)).ToList();
        }

        public IOrder AmendOrder(IOrder order, string originalClientOrderId, bool isStaged = false)
        {
            if (string.IsNullOrEmpty(originalClientOrderId)) throw new ArgumentNullException(nameof(originalClientOrderId));
            if (order == null) throw new ArgumentNullException(nameof(order));

            var replaceRequest = CreateReplaceOrderRequestBatch(order, originalClientOrderId, isStaged); //place holder waiting on flex to give us prob use case for user field on request
            order.OrderStatus = BamOrderStatus.PendingAck;

            var response = ParseStreamReturnFirst(_grpcServices.OrderServiceClient.ReplaceOrder(replaceRequest));

            if (response != null) //may need to handle compliance issues
            {
                if (!response.Success)
                {
                    _logger.Error($"Batched failue with the following error {response}");

                    if (response.ComplianceIssues.Count > 0)
                    {
                        order.OrderStatus = BamOrderStatus.Error;
                        order.StatusMessages.AddRange(response.ComplianceIssues.Select(ci => $"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}:{CreateComplianceIssue(ci).ToString()}")); //prob want something better
                    }
                    else
                    {
                        string msg = $"Order [{order.BatchId}][{order.ClientOrderId}] rejected by Flex because of an unknown reason.";
                        _logger.Info(msg);
                        order.OrderStatus = BamOrderStatus.Error;
                        order.StatusMessages.Add($"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}:{msg}");
                    }
                }
                else
                {
                    order.OrderStatus = BamOrderStatus.New;
                    order.RoutedSize = order.Size;
                    order.SettleDate = order.SettleDate;
                }

                Utility.RaiseEvent(new List<IOrder> { order }, OrderStatusChanged);
                return order;
            }
            return null;
        }

        public IList<IPosition> GetSodPositions(IPortfolio portfolio = null)
        {
            var request = new ReplayPositionsRequest() { SodOnly = true };
            return GetEmsPositions(request);
        }

        public void GetOpenOrders(out IReadOnlyList<IOrder> orders, out IReadOnlyList<IBlockTrade> trades)
        {
            var request = new ReplayOrdersRequest();

            var returnOrderList = new List<IOrder>();
            var tradeList = new List<IBlockTrade>();

            var allOrders = ParseStream(_grpcServices.OrderServiceClient.ReplayOrders(request));

            foreach (var order in allOrders)
            {
                _logger.Info($"[OrderId:{order.OrderId} Received order recovery message {order}.");
                if (order.Status != OrderStatus.CANCELLED && order.Status != OrderStatus.COMPLIANCE_FAILED)
                {
                    var emsOrder = new Data.Orders.Order();
                    returnOrderList.Add(emsOrder);
                    emsOrder.ClientOrderId = order.OrderId;
                    emsOrder.OrderStatus = Utilities.ConvertStatus(order);
                    emsOrder.StreetOrders = Utilities.ParseStreetOrders(order);                    
                    if (order.FilledQuantity > 0)
                    {
                        IBlockTrade trade = Utilities.Parse(order);
                        tradeList.Add(trade);
                    }
                }
            }

            orders = returnOrderList.ToArray();
            trades = tradeList.ToArray();
        }

        public IEnumerable<IBlockTrade> GetTradesForTradeDate(DateTime tradeDate)
        {
            var request = new TradeActivityRequest()
            {
                TradeDate = tradeDate.ToString("yyyy-MM-dd")
            };

            var tradeList = new List<IBlockTrade>();
            var allTrades = ParseStream(_grpcServices.OrderServiceClient.ListTradeActivity(request));
            foreach (var trade in allTrades)
            {
                _logger.Info($"[OrderId:{trade.OrderId} Received trade recovery message {trade}.");

                tradeList.Add(Utilities.Parse(trade));
            }
            Utility.RaiseEvent(tradeList, TradeUpdated);
            return tradeList;
        }

        public DateTime GetBusinessDate()
        {
            var request = new BusinessDayRequest()
            {
                Region = Region.NAUS
            };

            var response = ParseStream(_grpcServices.OrderServiceClient.GetCurrentBusinessDay(request));
            if (response != null && response.Any())
            {
                return DateTime.Parse(response.First().Date);
            }
            return DateTime.MinValue;
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            //todo 
        }

        private void HandleSecurityChanged(Data.Securities.ISecurity security)
        {
            Utility.RaiseEvent(security, SecurityUpdated);
        }
        private void HandleTradeUpdated(IEnumerable<IBlockTrade> trades)
        {
            Utility.RaiseEvent(trades, TradeUpdated);
        }

        private void HandleOrderStatusChanged(IEnumerable<IOrder> orders)
        {
            Utility.RaiseEvent(orders, OrderStatusChanged);
        }

        private void HandleRollStarted(string data)
        {
            Utility.RaiseEvent(data, RollStarted);
        }

        private void HandleRollCompleted(string data)
        {
            Utility.RaiseEvent(data, RollCompleted);
        }       

        private Position ParsePosition(PositionUpdateResponse flexPosition, Security security)
        {
            Position position = new Position
            {
                //need figure out how these map
                Portfolio = (Portfolio)Portfolio.Parse(flexPosition.Account),
                Security = new Security { BamSymbol = flexPosition.Symbol },
                CustodianName = flexPosition.PrimeBroker,
                TheoreticalQuantity = (decimal)flexPosition.Quantity,
                ActualQuantity = (decimal)flexPosition.Quantity,
                ShortMarkingQuantity = (decimal)flexPosition.Quantity,
                LongMarkingQuantity = (decimal)flexPosition.Quantity
            };
            position.Security.SecurityType = security.SecurityType;
            return position;
        }

        //todo: consider breaking out the parsing or mapping functions into a separate class
        private CreateOrdersRequest CreateOrderRequestBatch(IList<Order> orders, bool stageOrders, string trader)
        {
            var requestBuilder = new CreateOrdersRequest
            {
                User = trader,
                SendToEms = !stageOrders,
                ComplianceInputs = new ComplianceInputs()
            };

            requestBuilder.Orders.Add(orders);
            return requestBuilder;
        }

        private CancelOrdersRequest CreateCancelOrderRequestBatch(IList<string> orderIds, string trader)
        {
            var requestBuilder = new CancelOrdersRequest { User = trader };

            requestBuilder.OrderIds.Add(orderIds);
            return requestBuilder;
        }

        private ReplaceOrderRequest CreateReplaceOrderRequestBatch(IOrder order, string originalClientOrderId, bool isStaged)
        {
            var requestBuilder = new ReplaceOrderRequest { User = order.Trader, SendToEms = !isStaged, Order = CreateFlexOrder(order), OriginalOrderId = originalClientOrderId };
            return requestBuilder;
        }

        private ComplianceIssue CreateComplianceIssue(Ft.ComplianceIssue issue)
        {
            return new ComplianceIssue
            {
                IssueType = issue.IssueType.ToString(),
                Description = issue.Description,
                RuleName = issue.RuleName
            };
        }

        private Order CreateFlexOrder(IOrder order)
        {
            var baseOrder = CreateBaseOrderBuilder();

            var trader = _accountService.GetFlexTraderCode(order.TraderId);

            baseOrder.OriginId = order.ClientOrderId;
            baseOrder.User = trader;
            baseOrder.Symbol = order.Security.BamSymbol;
            baseOrder.Side = MapSideTypeToMarketSide(order.Side);
            if (order.Price.HasValue && order.Price != 0)
            {
                baseOrder.Price = Convert.ToDouble(order.Price.Value);
                baseOrder.OrderType = OrderType.LIMIT;
            }
            baseOrder.Strategy = order.Portfolio.ToString();
            baseOrder.Quantity = (int)order.RoutedSize;
            baseOrder.FixTags = BuildAlgoInstructions(order.ExecutionInstructions);
            baseOrder.AutoRoute = SetAutoRouteInstruction(order);

            baseOrder.FixTags = GetSupraBatchId(order, baseOrder.FixTags);
            baseOrder.FixTags = GetActualBorrowRate(order, baseOrder.FixTags);

            if (!string.IsNullOrWhiteSpace(order.Note))
            {
                baseOrder.Notes = order.Note;
            }

            var brokerOverride = new AllocationRatio
            {
                Name = order.Custodian,
                Ratio = 1.0d
            };

            baseOrder.OverridePrimeBrokerAllocations.Add(brokerOverride);

            if (order.Locate != null)
            {
                foreach (var locateInfo in order.Locate)
                {
                    if (locateInfo.Size <= 0) continue;
                    var flexLocateInfo = new LocateInfo
                    {
                        DateTime = locateInfo.TimeReceived?.ToString(LocateDatetimeFormat) ?? DateTime.Now.ToString(LocateDatetimeFormat),
                        Id = locateInfo.AssignmentId,
                        PrimeBroker = locateInfo.PrimeBroker,
                        Quantity = Convert.ToDouble(locateInfo.Size)
                    };
                    baseOrder.Locates.Add(flexLocateInfo);
                }
            }

            var sec = new OrderSecurityDetails
            {
                SecurityType = Utility.GetStringFromEnumAttribute(order.Security.SecurityType)
            };

            baseOrder.SecurityDetails = sec;

            _logger.Info($"Created flex Order {baseOrder} from IOrder {JsonConvert.SerializeObject(order)}\n");

            return baseOrder;
        }

        private bool SetAutoRouteInstruction(IOrder order)
        {
            var autoRouteInst = order.ExecutionInstructions.FirstOrDefault(r => r.Code.ToUpper() == "AUTOROUTE");
            if (!default(ExecutionInstruction).Equals(autoRouteInst))
            {
                bool shouldAutoRoute;
                if (bool.TryParse(autoRouteInst.Value, out shouldAutoRoute))
                    return shouldAutoRoute;
            }

            return false;
        }

        private string GetSupraBatchId(IOrder order, string fixTags)
        {
            if (!String.IsNullOrWhiteSpace(order.BatchId))
            {
                return !String.IsNullOrWhiteSpace(fixTags)
                    ? $"{fixTags};{GetFIXTag(FixTagBatchId, order.BatchId)}"
                    : $"{GetFIXTag(FixTagBatchId, order.BatchId)}";
            }
            else
                return fixTags;
        }

        private string GetActualBorrowRate(IOrder order, string fixTags)
        {
            if (order.Locate != null)
            {
                string rateString = order.Locate.Aggregate<Locate, string>(null, (current, locate) => String.IsNullOrWhiteSpace(current) ? locate.Rate.ToString("G") : $"{current},{locate.Rate.ToString("G")}");
                if (String.IsNullOrWhiteSpace(rateString)) return fixTags;

                return !String.IsNullOrWhiteSpace(fixTags)
                    ? $"{fixTags};{GetFIXTag(FixTagBorrowRate, rateString)}"
                    : $"{GetFIXTag(FixTagBatchId, rateString)}";
            }

            return fixTags;
        }

        private string BuildAlgoInstructions(IList<ExecutionInstruction> executionInstructions)
        {
            var sb = new StringBuilder();
            for (var i = 0; i < executionInstructions.Count; i++)
            {
                var inst = executionInstructions[i];
                if(inst.Code.ToUpper() == "AUTOROUTE") //special instruction to send the orders to flex
                    continue;

                var fixTag = _instructionToEmsTagMapper.GetTag(inst.Code);
                if (string.IsNullOrEmpty(fixTag))
                {
                    _logger.WarnFormat("Not adding execution instruction {0}", inst.Code);
                    continue;
                }

                sb.Append(fixTag);
                sb.Append("=");
                sb.Append(inst.Value);
                if (i != executionInstructions.Count - 1)
                    sb.Append(";");
            }

            return sb.ToString();
        }

        private string GetFIXTag<T>
            (string tag, T value)
        {
            return $"{tag}={value}";
        }

        private Order CreateBaseOrderBuilder()
        {
            var builder = new Order
            {
                OrderType = OrderType.MARKET,
                TimeInForce = TimeInForce.GFD,
                Notes = "Default Order",
                AutoRoute = true
            };

            return builder;
        }

        private MarketSide MapSideTypeToMarketSide(SideType type)
        {
            switch (type)
            {
                case SideType.Buy:
                    return MarketSide.BUY;
                case SideType.Sell:
                    return MarketSide.SELL;
                case SideType.SellShort:
                    return MarketSide.SHORT;
                case SideType.Cover:
                    return MarketSide.COVER;
            }

            throw new Exception($"No Flex Market Side for Bam SideType {type}");
        }

        private T ParseStreamReturnFirst<T>(AsyncServerStreamingCall<T> asyncCall) where T : class
        {
            try
            {
                return Task.Run(() =>
                {
                    _logger.Info("Reading the response from FLEX EMS......");
                    return _streamParser.ParseStreamReturnFirst(asyncCall);
                }).Result;
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error("Error while reading the response from FLEX EMS.", ex);
                    return true;
                });
                return null;
            }
        }

        private IEnumerable<T> ParseStream<T>(AsyncServerStreamingCall<T> asynchCall) where T : class
        {
            return Task.Run(() => _streamParser.ParseStream(asynchCall)).Result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="portfolio"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        private IList<IPosition> GetEmsPositions(ReplayPositionsRequest request)
        {
            var positions = new List<IPosition>();

            var response = ParseStream(_grpcServices.OrderServiceClient.ReplayPositions(request));
            var uniqueSecurities = response.Select(r => r.Symbol).Distinct().ToList();

            var securityList = _securityMasterService.GetSecurities(uniqueSecurities);
            
            foreach (var responseMsg in response)
            {
                var security = securityList.FirstOrDefault(r => r.BamSymbol == responseMsg.Symbol) as Security;
                if (security == null)
                {
                    _logger.Error($"Unable to find security for symbol {responseMsg.Symbol}");
                }
                else
                {
                    positions.Add(ParsePosition(responseMsg, security));
                }

            }

            var originalCount = positions.Count;


            positions =  _accountService.SetAccountAttributes(positions).Cast<IPosition>().ToList();

            if(originalCount != positions.Count)
                _logger.Error($"SOD position count after validation has changed from {originalCount} to {positions.Count} from EMS");

            return positions;
        }

        private HashSet<IOrder> ProcessOrderResponse(CreateOrdersResponse response, IList<IOrder> ordersList, string batchId)
        {
            HashSet<IOrder> returnList = new HashSet<IOrder>();
            foreach (var orderResponse in response.Results)
            {
                var order = ordersList.FirstOrDefault(o => o.ClientOrderId == orderResponse.OrderId);

                if (order != null)
                {
                    order.TradeCurrency = orderResponse.TradingCurrency;
                    order.SettlementCurrency = orderResponse.SettlementCurrency;

                    if (orderResponse.Success)
                    {
                        _logger.Info(
                            $"[BatchId: {batchId}] Order [{response.BatchId}][{orderResponse.OrderId}] accepted by Flex successfully.");
                        order.OrderStatus = BamOrderStatus.New;

                        order.SettleDate = DateTime.Parse(orderResponse.SettleDate);
                    }
                    else if (orderResponse.ComplianceIssues.Count > 0)
                    {
                        order.OrderStatus =
                            orderResponse.ComplianceIssues.Any(
                                ci => ci.IssueType == ComplianceIssueType.FAILURE)
                                ? BamOrderStatus.Error
                                : BamOrderStatus.New;
                        string complianceFailureMessage = order.OrderStatus == BamOrderStatus.Error
                            ? $"[BatchId {batchId}] Order [{response.BatchId}][{orderResponse.OrderId}] rejected by Flex for complaince check failure."
                            : $"[BatchId {batchId}] Order [{response.BatchId}][{orderResponse.OrderId}] accepted by Flex with compliance warning(s).";
                        order.StatusMessages.AddRange(
                            orderResponse.ComplianceIssues.Select(
                                ci => $"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}:{CreateComplianceIssue(ci).ToString()}"));
                        _logger.Info(complianceFailureMessage);
                    }
                    else
                    {
                        var otherErrorMessage =
                            $"[BatchId {batchId}] Order [{response.BatchId}][{orderResponse.OrderId}] rejected by Flex because {orderResponse.Description}.";
                        order.OrderStatus = BamOrderStatus.Error;
                        order.StatusMessages.Add($"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}:{orderResponse.Description}");
                        _logger.Info(otherErrorMessage);
                    }

                    returnList.Add(order);
                }
            }
            return returnList;
        }

        public bool RequestFullRefresh()
        {
            return true;
        }
    }
}