﻿using System.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    [DebuggerDisplay("({Key}) = (Long={LongMarkingQuantity}, Short={ShortMarkingQuantity})")]
    public class CompliancePosition : ModelBase<IMessage>
    {
        public CompliancePosition(ComplianceGroupKey key, long id, long shortMarkingQty = 0, long longMarkingQty = 0)
        {
            Key = key;
            PositionId = id;
            ShortMarkingQuantity = shortMarkingQty;
            LongMarkingQuantity = longMarkingQty;
        }

        public long PositionId { get; set; }
        public ComplianceGroupKey Key { get; }
        public long LongMarkingQuantity { get; private set; }
        public long ShortMarkingQuantity { get; private set; }
        public bool IsFlat => LongMarkingQuantity == 0 && ShortMarkingQuantity == 0;

        public long ApplyLongMarkingEffect(long effect)
        {
            if (effect != 0)
            {
                LongMarkingQuantity += effect;
                Publish(new LongMarkingPositionUpdated(PositionId, LongMarkingQuantity));
            }

            return LongMarkingQuantity;
        }

        public long ApplyShortMarkingEffect(long effect)
        {
            if (effect != 0)
            {
                ShortMarkingQuantity += effect;
                Publish(new ShortMarkingPositionUpdated(PositionId, ShortMarkingQuantity));
            }

            return ShortMarkingQuantity;
        }
    }
}
