﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.SodPosition.Svc.File
{
    /// <summary>
    /// Class that maps Sod file record
    /// </summary>
    public class PositionRecord
    {
        public string FundCode { get; set; }
        public string CustodianName { get; set; }
        public string StrategyCode { get; set; }
        public string AssetType { get; set; }
        public string BAMSymbol { get; set; }
        public string CustodianAccountCode { get; set; }
        public decimal Qty { get; set; }
        public decimal Price { get; set; }
        public Nullable<decimal> Cost { get; set; }
        public string Ccy { get; set; }
        public decimal FXRate { get; set; }
    }
}
