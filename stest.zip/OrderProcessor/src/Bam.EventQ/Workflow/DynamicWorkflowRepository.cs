﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Bam.EventQ.Workflow
{
    public class DynamicWorkflowRepository : IWorkflowRepository
    {
        private readonly WorkflowActivator _activator;
        private readonly Dictionary<Type, IWorkflow> _items = new Dictionary<Type, IWorkflow>();

        public DynamicWorkflowRepository(Assembly searchAssembly, WorkflowActivator activator)
        {
            _activator = activator;
            DiscoverAllWorkflows(searchAssembly);
        }

        public IReadOnlyList<KeyValuePair<Type, IWorkflow>> GetAll()
        {
            return _items.ToList();
        }

        private void DiscoverAllWorkflows(Assembly searchAssembly)
        {
            foreach (var type in searchAssembly.GetTypes().OrderBy(t => t.Name))
            {
                if (!type.IsClass || type.IsAbstract)
                    continue;

                var interfaceTypes = type.GetInterfaces();
                foreach (var it in interfaceTypes.Where(i => i.IsGenericType))
                {
                    if (typeof(IWorkflow<>) == it.GetGenericTypeDefinition())
                    {
                        var inputType = it.GetGenericArguments()[0];
                        _items[inputType] = _activator(type);
                    }
                }
            }
        }
    }
}
