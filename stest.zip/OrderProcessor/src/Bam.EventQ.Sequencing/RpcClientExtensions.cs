﻿using System;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Sequencing
{
    public static class RpcClientExtensions
    {
        public static bool TryInvoke(this IRpcClient client, string inquiry, IMessage payload, TimeSpan timeout, out byte[] result)
        {
            var buffer = new byte[1024*1024];
            int length = MessageSerializer.Current.Serialize(payload, buffer, 0);
            Array.Resize(ref buffer, length);
            return client.TryInvoke(inquiry, buffer, timeout, out result);
        }
    }
}
