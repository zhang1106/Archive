﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Diagnostics
{
    public class TelemetryQueue<TItem> : IQueue<TItem>
    {
        private readonly IQueue<TItem> _inner;
        private readonly ITelemetry _telemetry;

        private int _allocationCount;
        private int _desiredSlots, _actualSlots;
        private readonly Stopwatch _stopwatch = new Stopwatch();
        private readonly TimeSpan _publishInterval;
        private readonly string _name;

        private readonly LinkedList<long> _queueLengths = new LinkedList<long>();
        private readonly CasLock _publishingLock = new CasLock();

        // ReSharper disable once StaticMemberInGenericType
        private static int _queueCounter;

        public TelemetryQueue(IQueue<TItem> inner, ITelemetry telemetry, TimeSpan publishInterval)
        {
            _inner = inner;
            _telemetry = telemetry;
            _publishInterval = publishInterval;
            _name = inner.GetType().GetDisplayName() + "#" + Interlocked.Increment(ref _queueCounter);
            _stopwatch.Start();
        }

        public QueueSlotBatch AllocateBatch(int size)
        {
            _allocationCount++;
            _desiredSlots += size;
            var batch = _inner.AllocateBatch(size);
            _actualSlots += unchecked ((int)(batch.End - batch.Start));

            PublishTelemetry();

            return batch;
        }

        public void PublishBatch(QueueSlotBatch batch)
        {
            _inner.PublishBatch(batch);
        }

        public TItem this[long sequence] => _inner[sequence];

        public void AddErrorHandler(IQueueErrorHandler handler)
        {
            _inner.AddErrorHandler(handler);
        }

        public void AddSubscriptionChain(params IQueueItemHandler<TItem>[] handlers)
        {
            _inner.AddSubscriptionChain(handlers);
        }

        public bool ReplayMessages(Predicate<TItem> startPredicate, Predicate<TItem> filterPredicate,
            IQueueItemHandler<TItem> replayHandler)
        {
            return _inner.ReplayMessages(startPredicate, filterPredicate, replayHandler);
        }

        public void Start()
        {
            _inner.Start();
        }

        public void Stop()
        {
            _inner.Stop();
        }

        public bool IsAvailable(QueueSlotBatch range)
        {
            return _inner.IsAvailable(range);
        }

        public bool HasBacklog()
        {
            return _inner.HasBacklog();
        }

        public long Capacity => _inner.Capacity;
        public long Count => _inner.Count;
        public long MaxSequence => _inner.MaxSequence;

        private void PublishTelemetry()
        {
            if (_stopwatch.Elapsed > _publishInterval)
            {
                long depth = _inner.Count;
                bool backlog = false;

                using (_publishingLock.Acquire())
                {
                    _queueLengths.AddLast(depth);
                    if (_queueLengths.Count == 10)
                    {
                        _queueLengths.RemoveFirst();

                        backlog = true;
                        var current = _queueLengths.First;
                        long count = current.Value;
                        while (current != null)
                        {
                            if (count > current.Value)
                            {
                                backlog = false;
                                break;
                            }
                            count = current.Value;
                            current = current.Next;
                        }
                    }
                }

                _stopwatch.Stop();
                var allocRate = _allocationCount/_stopwatch.Elapsed.TotalSeconds;
                var desiredAvg = _desiredSlots/(double) _allocationCount;
                var actualAvg = _actualSlots/(double) _allocationCount;

                _telemetry.Record($"{_name}-Depth", depth);
                _telemetry.Record($"{_name}-Allocations", allocRate);
                _telemetry.Record($"{_name}-DesiredBatchSize", desiredAvg);
                _telemetry.Record($"{_name}-AvailableBatchSize", actualAvg);
                _telemetry.Record($"{_name}-Backlog", backlog);

                _allocationCount = 0;
                _desiredSlots = 0;
                _actualSlots = 0;

                _stopwatch.Restart();
            }
        }
    }
}
