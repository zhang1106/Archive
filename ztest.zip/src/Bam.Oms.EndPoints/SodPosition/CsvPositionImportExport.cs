﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using CsvHelper.Configuration;

namespace Bam.Oms.EndPoints.SodPosition
{
    public class CsvPositionImportExport : IPositionImportExport
    {
        private readonly IAccountService _accountService;
        private readonly ISecurityMasterService _securityMasterService;
        private readonly ILogger _logger;

        public CsvPositionImportExport(
            IAccountService accountService, 
            ISecurityMasterService securityMasterService,
            ILogger logger)
        {
            _accountService = accountService;
            _securityMasterService = securityMasterService;
            _logger = logger;
        }

        public IReadOnlyList<IPosition> Import(string path)
        {
            var portfolios = _accountService.GetAllPortfolios().ToDictionary(p => p.Key);

            var result = new List<IPosition>();
            using (var file = new StreamReader(path))
            using (var reader = new CsvHelper.CsvReader(file, CreateConfig()))
            {
                while (reader.Read())
                {
                    var record = reader.GetRecord<dynamic>();
                    var dict = (IDictionary<string, object>)record;

                    string portfolioKey = record.Portfolio;

                    Portfolio p;
                    if (!portfolios.TryGetValue(portfolioKey, out p))
                    {
                        _logger.Warn($"Unknown portfolio '{portfolioKey}'");
                        continue;
                    }

                    var item = new Position
                    {
                        ShortMarkingQuantity = Convert.ToDecimal(record.ShortMarkingQuantity),
                        LongMarkingQuantity = Convert.ToDecimal(record.LongMarkingQuantity),
                        Security = new Security
                        {
                            BamSymbol = record.BamSymbol
                        },
                        Portfolio = p,
                        TheoreticalQuantity = Convert.ToDecimal(record.TheoreticalQuantity),
                        LastModifiedOn = DateTime.Now,
                        Stream = p.OmsStream
                    };

                    foreach (var key in dict.Keys.Where(k => k.Contains("@")).ToList())
                    {
                        if (!string.IsNullOrEmpty(dict[key] as string))
                        {
                            string fund = key.Substring(0, key.IndexOf('@'));
                            var custodian = key.Substring(key.IndexOf('@') + 1);
                            item.DistributedPositions.Add(new DistributedPosition
                            {
                                FundCode = fund,
                                CustodianName = custodian,
                                Quantity = Convert.ToDecimal(dict[key])
                            });
                        }
                    }

                    item.ActualQuantity = item.DistributedPositions.Sum(d => d.Quantity);
                    result.Add(item);
                }
            }

            var symbols = result.Select(p => p.Security.BamSymbol).Distinct().ToList();
            var securities = _securityMasterService.GetSecurities(symbols).Cast<UpdateSecurity>().ToDictionary(s => s.Key);

            foreach (var p in result)
            {
                UpdateSecurity sec;
                if (securities.TryGetValue(p.Security.Key, out sec))
                {
                    p.Security = sec;
                }
                else
                {
                    _logger.Warn($"Unable to populate security details for symbol '{p.Security.Key}'");
                }
            }

            return result;
        }

        public void Export(IReadOnlyList<IPosition> positions, string path)
        {
            var allocKeys =
                positions.SelectMany(
                    p => p.DistributedPositions.Select(a => new KeyValuePair<string, string>(a.FundCode, a.CustodianName)))
                    .Distinct()
                    .ToList();

            using (var file = new StreamWriter(path))
            using (var writer = new CsvHelper.CsvWriter(file, CreateConfig()))
            {
                writer.WriteField("Portfolio");
                writer.WriteField("BamSymbol");
                writer.WriteField("TheoreticalQuantity");
                writer.WriteField("ShortMarkingQuantity");
                writer.WriteField("LongMarkingQuantity");
                foreach (var key in allocKeys)
                {
                    writer.WriteField($"{key.Key}@{key.Value}");
                }
                writer.NextRecord();

                foreach (var p in positions)
                {
                    writer.WriteField(p.Portfolio);
                    writer.WriteField(p.Security.BamSymbol);
                    writer.WriteField(p.TheoreticalQuantity);
                    writer.WriteField(p.ShortMarkingQuantity);
                    writer.WriteField(p.LongMarkingQuantity);
                    foreach (var item in allocKeys)
                    {
                        var alloc = p.DistributedPositions.FirstOrDefault(
                            d => d.FundCode == item.Key && d.CustodianName == item.Value);
                        if (alloc != null)
                            writer.WriteField(alloc.Quantity);
                        else
                            writer.WriteField(null);
                    }
                    writer.NextRecord();
                }
            }
        }

        private static CsvConfiguration CreateConfig()
        {
            return new CsvConfiguration();
        }
    }
}
