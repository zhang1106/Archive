﻿using Bam.Oms.Data.Positions;

namespace Bam.Oms.Persistence.Positions
{
    public interface IActionRepository : IDBRepository<SodAction>
    {
        // Any action repository specific methods to go here.
    }
}