﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Pooling;
using Bam.EventQ.Queue;
using Bam.EventQ.Recovery;
using Bam.EventQ.Throttling;
using Bam.EventQ.Time;
using Bam.EventQ.Workflow;

namespace Bam.EventQ.Pipeline.Dsl
{
    public class PipelineQueueItemHandlerChainDsl<TItem>
    {
        public ProcessingPipelineStepDsl<TItem> Step { get; }

        private readonly List<IQueueItemHandler<PipelineQueueItem<TItem>>> _handlers =
            new List<IQueueItemHandler<PipelineQueueItem<TItem>>>();

        public PipelineQueueItemHandlerChainDsl(ProcessingPipelineStepDsl<TItem> step)
        {
            Step = step;
        }
        
        public PipelineQueueItemHandlerChainDsl<TItem> ForwardToNextStep<TOut>(int batchSize = 4096) where TOut : class
        {
            var forwarder = new PipelineQueueItemForwarder<TItem, TOut>(
                new MessageFilterTransform<TItem, TOut>(), batchSize);
            _handlers.Add(forwarder);
            return this;
        }

        public PipelineQueueItemHandlerChainDsl<TItem> AddHandler(IQueueItemHandler<PipelineQueueItem<TItem>> handler)
        {
            _handlers.Add(handler);
            return this;
        }
        
        public PipelineQueueItemHandlerChainDsl<TItem> ReleasePayload(IObjectPool pool)
        {
            AddHandler(new ReleasePayloadHandler<TItem>(pool));
            return this;
        }

        public ThrottledPipelineQueueItemHandlerDsl<TItem> Throttle(IConsumptionTrigger<TItem> trigger)
        {
            return new ThrottledPipelineQueueItemHandlerDsl<TItem>(this, trigger);
        }

        public PipelineQueueItemHandlerChainDsl<TItem> Publish(string fromEndpoint)
        {
            AddHandler(new MessagePublisherHandler<TItem>(Step.MessagePublisherFactory.Create(fromEndpoint)));
            return this;
        }

        public PipelineQueueItemHandlerChainDsl<TItem> ValidateSequenceNumbers(IClock clock, TimeSpan recoveryTimeout, int selfSourceId)
        {
            AddHandler(new ValidateSequenceNumberHandler<TItem>(
                clock, Step.Pipeline.RecoveryInvoker, recoveryTimeout, Step.SequenceInfoAccessor, selfSourceId));
            return this;
        }


        public PipelineQueueItemHandlerChainDsl<TItem> DispatchToWorkflow<TOut>(
            IWorkflowDispatcher<TItem, TOut> dispatcher, int batchSize = 4096)
        {
            IQueueItemTransformer<TItem, TOut> transformer = new WorkflowItemTransformer<TItem, TOut>(dispatcher);
            transformer = Step.Pipeline.ObjectDecorator.Decorate(transformer);
            AddHandler(new PipelineQueueItemForwarder<TItem, TOut>(transformer, batchSize));
            return this;
        }

        public IQueueItemHandler<PipelineQueueItem<TItem>>[] Build()
        {
            return _handlers.ToArray();
        }

        public IReadOnlyList<IQueueItemHandler<PipelineQueueItem<TItem>>> Handlers => _handlers;
    }
}
