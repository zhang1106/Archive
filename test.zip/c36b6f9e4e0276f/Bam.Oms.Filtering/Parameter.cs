﻿using System;

namespace Bam.Oms.Filtering
{
    public class Parameter
    {
        public string Property { get; set; }

        public object Value { get; set; }

        public Type Type { get; set; }

        //todo: operator

        public Operator Operator
        {
            get { return _Operator; }
            set { _Operator = value; }
        }
        Operator _Operator = new Operator() { OperatorType = OperatorType.Equal };
    }
}
