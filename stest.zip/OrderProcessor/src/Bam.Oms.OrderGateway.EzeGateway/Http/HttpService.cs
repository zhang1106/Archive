﻿using System;
using System.Web.Http.Dependencies;
using Bam.EventQ.Hosting;
using Microsoft.Owin.Hosting;

namespace Bam.Oms.OrderGateway.EzeGateway.Http
{
    public class HttpService : IService
    {
        private readonly string _baseUrl;
        private readonly IDependencyResolver _dependencyResolver;
        private IDisposable _web;

        public HttpService(string baseUrl, IDependencyResolver dependencyResolver)
        {
            _baseUrl = baseUrl;
            _dependencyResolver = dependencyResolver;
        }

        public string Name => "HTTP";

        public void Start() 
        {
            _web = WebApp.Start(_baseUrl, app => new StartUp(_dependencyResolver).Configuration(app));
        }

        public void Stop() 
        {
            _web.Dispose();
        }
    }
}
