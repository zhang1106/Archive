﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Web.Http;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.Persistence.Orders;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Configuration;
using Bam.Oms.EndPoints.Orders;

namespace Bam.Oms.EndPoints.Admin
{
    public class AdminController : BaseController
    {
        private readonly ISettings _settings;
        private readonly IClientOrderIdRepository _clientOrderIdRepository;
        private readonly IFlowManager _flowManager;        

        private readonly ILogger _log;
        private readonly CancellationTokenSource _sodRollTaskCancellation = new CancellationTokenSource();

        public AdminController(IClientOrderIdRepository clientOrderIdRepository, IFlowManager flowManager, IHostConfiguration hostConfiguration, ISettings settings, ILogger logger)
            : base(hostConfiguration, logger)
        {

            if (clientOrderIdRepository == null) throw new ArgumentNullException(nameof(clientOrderIdRepository));            
            if (flowManager == null) throw new ArgumentNullException(nameof(flowManager));
            if (logger == null) throw new ArgumentNullException(nameof(logger));

            _clientOrderIdRepository = clientOrderIdRepository;                        
            _flowManager = flowManager;            
            _settings = settings;
            _log = logger;
            
        }

        [HttpGet]        
        public string Ping()
        {
            var user = string.Empty;
            if (User != null)
                user = User.Identity.Name + ", ";

            return user + "I'm here, { " + DateTime.Now.ToString("o") + " }";
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Admin")]
        public string Reseed(int seed)
        {
            return _clientOrderIdRepository.ResetOrderIdIndex(seed);
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Admin")]
        public string RollSod()
        {
            return RollSod(null);
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Admin")]
        public string RollSod(DateTime? dateTimeToRollTo)
        {
            _logger.Info(dateTimeToRollTo.HasValue
                ? $"Roll request received with rolldate {dateTimeToRollTo.Value:MM/dd/yy H:mm:ss zzz}."
                : "Roll request received with no date time.");

            _flowManager.RollSod(dateTimeToRollTo);

            _logger.Info("Roll complete.");

            return $"New SOD DateTime {_settings.SODDateTime:MM/dd/yy H:mm:ss zzz}";
        }

        [HttpGet]
        [AccessRequire("Function.OrderGateway.Admin")]
        public string FreeMemory()
        {
            long current = Process.GetCurrentProcess().VirtualMemorySize64;
            GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced, true);
            long delta = current - Process.GetCurrentProcess().VirtualMemorySize64;
            return $"Released {delta/1024/1024:N2} MB";
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _sodRollTaskCancellation.Cancel();
            }
            base.Dispose(disposing);
        }
    }
}