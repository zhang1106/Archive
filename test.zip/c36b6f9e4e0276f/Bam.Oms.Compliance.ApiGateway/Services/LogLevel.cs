﻿namespace Bam.Oms.Compliance.ApiGateway.Services
{
    public enum LogLevel
    {
        Debug,
        Information,
        Warning,
        Error
    }
}
