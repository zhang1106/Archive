﻿using Bam.Oms.OrderGateway.Compliance.Model;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public interface IOrderEffectMediator
    {
        void ApplyEffects(Order order);
    }
}
