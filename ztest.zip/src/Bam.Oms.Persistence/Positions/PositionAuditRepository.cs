﻿using Bam.Oms.Data.Positions;
using BAM.Infrastructure.Ioc;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Bam.Oms.Data.Configuration;
using Dapper;

namespace Bam.Oms.Persistence.Positions
{
    public sealed class PositionAuditRepository : DBRepository<PositionAudit>, IPositionAuditRepository
    {
        /// <summary>
        /// Function to map DB Columns to PositionAudit object fields
        /// </summary>
        private static readonly Func<dynamic, PositionAudit> ResultMap = (item) => new PositionAudit
        {
            Position = PositionDBRepository.ResultMap(item),
            PositionAuditId = item.PositionAuditId
        };

        /// <summary>
        /// Function to map PositionAudit fields to DB columns
        /// </summary>
        private static readonly Func<PositionAudit, dynamic> ParameterMap = positionAudit =>
            PositionDBRepository.ParameterMap(positionAudit.Position);

        public PositionAuditRepository(ISettings settings, ILogger logger) : base(settings, logger, "sod", "PositionAudit", ResultMap, ParameterMap)
        {
            _includeColumnPredicate = (column => !column.Equals("Key"));
        }

        public IList<PositionAudit> GetOlderAudits(int actionLogId)
        {
            IList<PositionAudit> result = null;
            string sql = @"SELECT aud.* FROM sod.PositionAudit aud
                           JOIN sod.Position pos ON aud.PositionId = pos.PositionId
                           WHERE pos.AuditSequence = aud.AuditSequence + 1
                           AND pos.ActionLogId = @ActionLogId";

            try
            {
                using (IDbConnection cn = Connection)
                {
                    cn.Open();
                    result = cn.Query<dynamic>(sql, new { ActionLogId = actionLogId }).Select(ResultMap).ToList();
                }
            }
            catch (Exception e)
            {
                string errorMessage =
                    $"Error occurred while retrieving records from table {FullyQualifiedTableName}\nQuery : {sql}\nActionLogId : {actionLogId}";
                _log.Error(errorMessage, e);
                throw;
            }
            return result;
        }
    }
}
