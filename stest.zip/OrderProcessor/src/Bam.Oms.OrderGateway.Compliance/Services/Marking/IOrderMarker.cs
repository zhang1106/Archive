﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Marking
{
    public interface IOrderMarker
    {
        ISet<string> SupportedSecurityTypes { get; }
        IDisposable Scoped();
        List<Mark> MarkOrder(MarkingEntity entity, PositionSet set);
    }

    public struct MarkingEntity
    {
        public Side Side { get; set; }
        public long Size { get; set; }
        public bool IsOmni { get; set; }
    }
}
