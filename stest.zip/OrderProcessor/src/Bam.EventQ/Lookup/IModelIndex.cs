﻿using System.Collections.Generic;

namespace Bam.EventQ.Lookup
{
    public interface IModelIndex<T>
    {
        T LookupBy<TProp>(string property, TProp value);
        LookupList<T> MultiLookupBy<TProp>(string property, TProp value);
        void Insert(T item);
        void Remove(T item);
        IReadOnlyList<T> GetAll();
        void Clear();
    }
}
