﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IMarketDataProvider : IDataProvider
    {
        long? GetCustomizedShareOutstanding(string bamSymbol);
        long? GetSharesOutstanding(string bamSymbol);

        decimal? GetPrice(string bamSymbol);

        ConcurrentDictionary <string, MarketData> CurrentMarketData { get;}

        HashSet<string> CheckedInBb { get; }

        IEnumerable<MarketData> GetBbData(IEnumerable<string> symbols);

        bool CheckBbData { get; set; }

        void CheckMarketData(IEnumerable<string> underlyings, out IList<string> notExist);
    }
}
