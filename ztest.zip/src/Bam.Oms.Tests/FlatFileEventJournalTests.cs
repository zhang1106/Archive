﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Bam.Oms.Data.Orders;
using Bam.Oms.Persistence.Journal;
using Bam.Oms.Persistence.Serialization;
using FluentAssertions;
using NUnit.Framework;
using Ploeh.AutoFixture;

namespace Bam.Oms.Tests
{
    public class FlatFileEventJournalTests
    {
        public class SimpleItem
        {
            public int FieldA { get; set; }
            public string FieldB { get; set; }
        }

        public class OrderFilledEvent
        {
            public Guid OrderId { get; set; }
            public int FilledQuantity { get; set; }
            public double AveragePrice { get; set; }
        }

        [Test]
        public async Task VerifyAppendToNewFile()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();

            var item1 = fixture.Create<SimpleItem>();
            var item2 = fixture.Create<SimpleItem>();
            var item3 = fixture.Create<SimpleItem>();

            try
            {
                // act
                await sut.AppendAsync(item1);
                await sut.AppendAsync(item2);
                await sut.AppendAsync(item3);

                // assert
                var fi = new FileInfo(path);
                fi.Length.Should().BeGreaterThan(0);
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Test]
        public async Task VerifyAppendToExistingFile()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();

            var item1 = fixture.Create<SimpleItem>();
            var item2 = fixture.Create<SimpleItem>();
            var item3 = fixture.Create<SimpleItem>();

            try
            {
                // act
                await sut.AppendAsync(item1);
                sut.Dispose();
                long current = new FileInfo(path).Length;

                sut = new FlatFileEventJournal(path, new JsonSerializer());
                await sut.AppendAsync(item2);
                await sut.AppendAsync(item3);

                // assert
                var fi2 = new FileInfo(path);
                fi2.Length.Should().BeGreaterThan(current);
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Test]
        public async Task VerifyRetrieve()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();

            var item1 = fixture.Create<SimpleItem>();
            var item2 = fixture.Create<SimpleItem>();
            var item3 = fixture.Create<SimpleItem>();

            try
            {
                await sut.AppendAsync(item1);
                await sut.AppendAsync(item2);
                await sut.AppendAsync(item3);

                // act
                var items = (await sut.RetrieveAsync()).Select(kvp => kvp.Value).Cast<SimpleItem>();

                // assert
                items.ShouldAllBeEquivalentTo(new[] { item1, item2, item3 });
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Test]
        public async Task VerifyDoesNotCorruptFileWithParallelWriters()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();
            const int itemCount = 500;

            try
            {
                var expected = Enumerable.Range(0, itemCount)
                    .Select(i => fixture.Create<SimpleItem>())
                    .ToArray();

                // act
                var tasks = new Task[itemCount];
                Parallel.For(0, itemCount, i =>
                {
                    tasks[i] = sut.AppendAsync(expected[i]);
                });
                Task.WaitAll(tasks);

                // assert
                var items = (await sut.RetrieveAsync()).Select(kvp => kvp.Value).ToList();
                items.Count.Should().Be(expected.Length);
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Test]
        public async Task VerifyAppendsToCorruptedFileAtLastGoodPosition()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();

            var item1 = fixture.Create<SimpleItem>();
            var item2 = fixture.Create<SimpleItem>();

            await sut.AppendAsync(item1);
            await sut.AppendAsync(item2);
            sut.Dispose();

            // corrupt item2
            byte[] data = File.ReadAllBytes(path);
            Array.Resize(ref data, data.Length - 5);
            File.WriteAllBytes(path, data);

            sut = new FlatFileEventJournal(path, new JsonSerializer());

            try
            {
                // act
                var item3 = fixture.Create<SimpleItem>();
                await sut.AppendAsync(item3);

                // assert
                var items = await sut.RetrieveAsync();
                var actual = items.Select(m => m.Value).OfType<SimpleItem>().ToList();
                actual.ShouldAllBeEquivalentTo(new[] { item1, item3 });
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Test]
        public async Task VerifyReadsFromCorruptedFile()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();

            var item1 = fixture.Create<SimpleItem>();
            var item2 = fixture.Create<SimpleItem>();

            try
            {
                await sut.AppendAsync(item1);
                await sut.AppendAsync(item2);
                sut.Dispose();
                File.AppendAllText(path, "this is invalid data");

                sut = new FlatFileEventJournal(path, new JsonSerializer());

                // act
                var actual = (await sut.RetrieveAsync()).Select(kvp => kvp.Value).Cast<SimpleItem>();

                // assert
                actual.ShouldAllBeEquivalentTo(new[] { item1, item2 });
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Test]
        public async Task VerifyTruncatesFile()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();

            var item = fixture.Create<SimpleItem>();

            try
            {
                // act
                await sut.AppendAsync(item);
                await sut.AppendAsync(item);
                await sut.TruncateAsync();
                await sut.AppendAsync(item);

                // assert
                var actual = (await sut.RetrieveAsync()).Select(kvp => kvp.Value).ToList();
                actual.Should().HaveCount(1);
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Test]
        public async Task VerifyTruncatesFileByDate()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();

            var item = fixture.Create<SimpleItem>();

            try
            {
                // act
                item.FieldA = 1;
                await sut.AppendAsync(item);
                await Task.Delay(TimeSpan.FromMilliseconds(100));

                var cutOffTime = DateTime.UtcNow;
                await Task.Delay(TimeSpan.FromMilliseconds(100));

                item.FieldA = 2;
                await sut.AppendAsync(item);
                await Task.Delay(TimeSpan.FromMilliseconds(100));

                item.FieldA = 3;
                await sut.AppendAsync(item);
                await Task.Delay(TimeSpan.FromMilliseconds(100));

                await sut.TruncateAsync(cutOffTime);

                // assert
                var actual = (await sut.RetrieveAsync()).Select(kvp => kvp.Value).ToList();
                actual.Should().HaveCount(2);
                actual.OfType<SimpleItem>().Should().OnlyContain(i => i.FieldA > 1);
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }
        [Category("Integration")]
        [Test]
        public async Task VerifySerialThroughput()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            try
            {
                const int count = 100;
                var fixture = new Fixture();                
                var items = fixture.CreateMany<Order>(count);

                // first call does initialization, don't take that into account for benchmark
                await sut.AppendAsync(new SimpleItem());

                // act
                var sw = Stopwatch.StartNew();
                foreach (var item in items)
                {
                    await sut.AppendAsync(item);
                }
                sw.Stop();

                // assert
                var fi = new FileInfo(path);
                double mbPerSecond = fi.Length/sw.Elapsed.TotalSeconds/(1024*1024);
                Console.Write($"{mbPerSecond:N} MB/s throughput");
                mbPerSecond.Should().BeGreaterThan(10); // at least 10 MB/s
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Category("Integration")]
        [TestCase(1000, 500, 50000)]
        [TestCase(100, 1000, 50000)]
        [TestCase(5, 5000, 50000)]
        [TestCase(25, 1000, 50000)]
        [TestCase(1, 10000, 50000)]
        public async Task VerifyBatchThroughput(int batchSize, int batches, int expected)
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new ProtoBufSerializer(
                model =>
                {
                    model.Add<OrderFilledEvent>().Add(m => m.OrderId, m => m.FilledQuantity, m => m.AveragePrice);
                }));

            try
            {
                var fixture = new Fixture();
                var items = fixture.CreateMany<OrderFilledEvent>(batchSize).ToArray();

                // first call does initialization, don't take that into account for benchmark
                await sut.AppendAsync(new OrderFilledEvent());

                // act
                var sw = Stopwatch.StartNew();
                for (int i = 0; i < batches; i++)
                {
                    await sut.AppendAsync(items);
                }
                sw.Stop();

                // assert
                var fi = new FileInfo(path);
                double mbPerSecond = fi.Length / sw.Elapsed.TotalSeconds / (1024 * 1024);
                double itemsPerSecond = (batchSize * batches) / sw.Elapsed.TotalSeconds;
                Console.WriteLine($"{mbPerSecond:N} MB/s throughput");
                Console.WriteLine($"{itemsPerSecond:N} items/s throughput");
                itemsPerSecond.Should().BeGreaterThan(expected);
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }

        [Test]
        public async Task VerifyLargeObjects()
        {
            // arrange
            string path = Path.Combine(Path.GetTempPath(), Path.GetTempFileName());
            var sut = new FlatFileEventJournal(path, new JsonSerializer());
            var fixture = new Fixture();

            var item1 = fixture.Create<Order>();
            var item2 = fixture.Create<Order>();
            var item3 = fixture.Create<Order>();

            try
            {
                await sut.AppendAsync(item1);
                await sut.AppendAsync(item2);
                await sut.AppendAsync(item3);

                // act
                var items = (await sut.RetrieveAsync()).Select(kvp => kvp.Value).Cast<Order>();

                // assert
                items.ShouldAllBeEquivalentTo(new[] { item1, item2, item3 });
            }
            finally
            {
                sut.Dispose();
                File.Delete(path);
            }
        }
    }
}
