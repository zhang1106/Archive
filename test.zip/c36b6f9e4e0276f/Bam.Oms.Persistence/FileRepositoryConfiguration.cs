﻿namespace Bam.Oms.Persistence
{
    public class FileRepositoryConfiguration : IFileRepositoryConfiguration
    {
        public string Path { get; set; }

        public string FileName { get; set; }

        public string FullPath
        {
            get { return System.IO.Path.Combine(Path, FileName); }
        }
    }
}