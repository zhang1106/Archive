﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Compliance.Results;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Persistence.Journal;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class CompliancePersistentDataTest
    {
        RuleResultRepository _ruleResultRepository;

        [TestFixtureSetUp]
        public void Initialize()
        {
            _ruleResultRepository = new RuleResultRepository(new Mock<ILogger>().Object, new Mock<ISettings>().Object, new Mock<IEventJournalFactory>().Object);
            _ruleResultRepository.ClearAll();
        }

        [Test]
        //test persistence usaage of  compliance result
        public void TestRuleResultPutGet()
        {
            //arragne
            var currentTime = DateTime.UtcNow;
            var ruleResult = new RuleResult() { PolicyId = 1, RuleId = 1, BamSymbol = "IBM" };

            //act
            var savedRuleResult = _ruleResultRepository.Save(ruleResult);
            var ruleResultSet = _ruleResultRepository.Get(currentTime);
            var getRuleResult = _ruleResultRepository.Get(ruleResult.Key);

            //assert
            Assert.AreEqual(ruleResult.BamSymbol, savedRuleResult.BamSymbol);
            Assert.IsTrue(ruleResultSet.ToList().Count == 1);
            Assert.AreEqual(getRuleResult.Key, ruleResult.Key);
        }


        [Test]
        //test persistence usaage of  compliance result
        public void TestLongOwnershipFilingRuleResultPutGet()
        {
            //arragne
            var lResult = new OwnershipFilingResult() {RuleId=1, PolicyId=1, BamSymbol = "IBM", Ratio = 0.05m, IsViolationOverriden = false, LowLimit = 0.05m, BusinessDate=DateTime.Today};

            //act
            var result = _ruleResultRepository.Save(lResult);

            //assert
            Assert.AreEqual(result.BamSymbol, lResult.BamSymbol);
        }
    }
}
