﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.Messages.ApiGateway;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public interface IComplianceSubmission
    {
        void SubmitHeadroom(HeadroomLoaded headroom);
        void AdjustHeadroomRatios(int ruleId, string identifier, Dictionary<string, double> ratios, string user);
        void DisableComplianceRules(List<DisableComplianceRuleRequest> rules, string user);
    }
}