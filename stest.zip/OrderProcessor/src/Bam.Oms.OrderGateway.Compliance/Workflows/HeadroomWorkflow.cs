﻿using System.Collections.Generic;
using Bam.EventQ;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.Compliance.Services.Headroom;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using Bam.Oms.OrderGateway.Messages.Compliance;
using Bam.Oms.OrderGateway.Messages.RefDataGateway;

namespace Bam.Oms.OrderGateway.Compliance.Workflows
{
    public class HeadroomWorkflow : Workflow,
        IHandle<HeadroomLoaded>,
        IHandle<LoadIntradayHeadroom>,
        IHandle<AdjustHeadroomRatios>
    {
        private readonly IHeadroomService _headroomService;
        private readonly List<HeadroomLoaded> _pending;

        public HeadroomWorkflow(IHeadroomService headroomService)
        {
            _headroomService = headroomService;
            _pending = new List<HeadroomLoaded>();
        }
        
        public void Execute(HeadroomLoaded input)
        {
            if (input.IsWipeAndLoad)
            {
                if (input.Chunk == 1)
                {
                    _pending.Clear();
                }

                if (input.Chunk != input.TotalChunks)
                {
                    _pending.Add(input.Clone());
                    return;
                }

                foreach (var item in _pending)
                {
                    input.Items.AddRange(item.Items);
                }

                _pending.Clear();
            }

            using (Attach(_headroomService))
            {
                _headroomService.Load(input);
            }
        }

        public void Execute(AdjustHeadroomRatios input)
        {
            using (Attach(_headroomService))
            {
                _headroomService.AdjustRatios(input);
            }
        }

        public void Execute(LoadIntradayHeadroom input)
        {
            var convert = new HeadroomLoaded { Chunk = 1, TotalChunks = 1 };
            var msg = new IntradayHeadroomAvailable();
            convert.Items.AddRange(input.Items);
            msg.Items.AddRange(input.UnderlyingSymbols);

            Execute(convert);
            Publish(msg);
        }
    }
}
