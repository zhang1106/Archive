﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Bam.Oms.Data.Configuration;


namespace Bam.Oms.Compliance.Service
{
    public class ComplianceSetting : ISettings
    {
        public void Initialize()
        {
            OrderGatewayConnectionString = ConfigurationManager.ConnectionStrings["OrderGateway"].ConnectionString;
            if (string.IsNullOrWhiteSpace(OrderGatewayConnectionString))
            {
                throw new ApplicationException("Order Gateway connection string is required in the app.config.");
            }

        }

        public string BaseUrl { get; set; }
        public string BasePort { get; set; }

        public DateTime SODDateTime { get; set; }

        public DateTime DefaultSODDateTime { get; set; }
        public string OrderGatewayConnectionString { get; set; }
        public string ContingencyConnectionString { get; set; }
        public string BamCoreLiteConnectionString { get; set; }
        public int ContingencyTimerInterval { get; set; }
        public int MaxResubscribeAttempt { get; set; }
        public int MaxStripedProcessors { get; set; }
        public int EmsResubscribeWaitInterval { get; set; }

        public string MqConnectionString { get; set; }
        public string MqEODTradeTopic { get; set; }

        public string MqEODOrderTopic { get; set; }

        public string MqEODPositionTopic { get; set; }

        public string MqTradeTopic { get; set; }

        public string MqOrderTopic { get; set; }

        public string MqPositionTopic { get; set; }

        public IDictionary<string, string> PortfolioToTrader { get; }

        public IDictionary<string, string> PortfolioToComplianceGroup { get; }

        public string FlexHost { get; set; }
        public string FlexPort { get; set; }

        public int ConnectionRetryInterval { get; set; }

        public int EMSPingInterval { get; set; }

        public string PermissionedApplications { get; set; }
    }
}
