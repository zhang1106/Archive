﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data.Compliance
{
    public class Constituent
    {
        public string Symbol { get; set; }
        public string Parent { get; set; }
        public decimal? Allocation { get; set; }
    }
}
