﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.PositionTracker;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class PositionEffectCache : IPositionEffectCache
    {
        private struct AllocationEffectKey : IEquatable<AllocationEffectKey>
        {
            public bool Equals(AllocationEffectKey other)
            {
                return Effect.Equals(other.Effect) && Allocation.Equals(other.Allocation);
            }

            public override bool Equals(object obj)
            {
                if (ReferenceEquals(null, obj)) return false;
                return obj is AllocationEffectKey && Equals((AllocationEffectKey) obj);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    return (Effect.GetHashCode()*397) ^ Allocation.GetHashCode();
                }
            }

            public static bool operator ==(AllocationEffectKey left, AllocationEffectKey right)
            {
                return left.Equals(right);
            }

            public static bool operator !=(AllocationEffectKey left, AllocationEffectKey right)
            {
                return !left.Equals(right);
            }

            private EffectKey Effect { get; }
            private PositionAllocationKey Allocation { get; }

            public AllocationEffectKey(EffectKey effect, PositionAllocationKey allocation)
            {
                Effect = effect;
                Allocation = allocation;
            }
        }

        private readonly Dictionary<EffectKey, ComplianceEffects> _positionEffects;
        private readonly Dictionary<AllocationEffectKey, ActualEffects> _allocationEffects;
        private readonly Dictionary<AllocationEffectKey, TheoreticalEffects> _theoreticalEffects;

        public PositionEffectCache()
        {
            _positionEffects = new Dictionary<EffectKey, ComplianceEffects>();
            _allocationEffects = new Dictionary<AllocationEffectKey, ActualEffects>();
            _theoreticalEffects = new Dictionary<AllocationEffectKey, TheoreticalEffects>();
        }

        public ComplianceEffects GetComplianceEffects(EffectKey orderKey)
        {
            ComplianceEffects pe;
            _positionEffects.TryGetValue(orderKey, out pe);
            return pe;
        }

        public void SetComplianceEffects(EffectKey orderKey, ComplianceEffects effects)
        {
            _positionEffects[orderKey] = effects;
        }

        public ActualEffects GetActualEffects(EffectKey orderKey, PositionAllocationKey key)
        {
            var aek = new AllocationEffectKey(orderKey, key);
            ActualEffects ae;
            _allocationEffects.TryGetValue(aek, out ae);
            return ae;
        }

        public void SetActualEffects(EffectKey orderKey, PositionAllocationKey key, ActualEffects effects)
        {
            var aek = new AllocationEffectKey(orderKey, key);
            _allocationEffects[aek] = effects;
        }

        public TheoreticalEffects GetTheoreticalEffects(EffectKey orderKey, PositionAllocationKey key)
        {
            var tek = new AllocationEffectKey(orderKey, key);
            TheoreticalEffects te;
            _theoreticalEffects.TryGetValue(tek, out te);
            return te;
        }

        public void SetTheoreticalEffects(EffectKey orderKey, PositionAllocationKey key, TheoreticalEffects effects)
        {
            var tek = new AllocationEffectKey(orderKey, key);
            _theoreticalEffects[tek] = effects;
        }
    }
}