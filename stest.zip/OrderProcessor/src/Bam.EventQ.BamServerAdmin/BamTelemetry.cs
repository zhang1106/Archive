﻿using System;
using System.ComponentModel;
using Bam.EventQ.Diagnostics;
using BAM.Servers.Admin.Client;

namespace Bam.EventQ.BamServerAdmin
{
    public class BamTelemetry : ITelemetry, IDisposable
    {
        private readonly AdminClient _client;

        public BamTelemetry(string applicationName, Guid instanceId)
        {
            _client = new AdminClient();
            _client.Initialize(applicationName, instanceId);
        }

        public void Record<T>(string key, T value)
        {
            var converter = TypeDescriptor.GetConverter(typeof(T));
            _client.SetAppProperty(key, converter.ConvertToString(value));
        }

        public void Dispose()
        {
            _client.Dispose();
        }
    }
}
