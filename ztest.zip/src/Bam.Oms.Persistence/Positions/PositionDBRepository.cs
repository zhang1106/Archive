﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;
using System.Dynamic;
using Bam.Oms.Data.Configuration;

namespace Bam.Oms.Persistence.Positions
{
    public sealed class PositionDBRepository : DBRepository<Position>, IPositionDBRepository
    {
        /// <summary>
        /// <summary>
        /// Function to map DB Columns to Position object fields
        /// </summary>
        /// </summary>
        // Note : Access modifier is "internal" so that it can be reused by PositionAuditRepository and PositionArchiveRepository's mappers
        internal static readonly Func<dynamic, Position> ResultMap = item => new Position
        {
            PositionId = item.PositionId,
            ActionLogId = item.ActionLogId,
            ActualQuantity = item.Qty,
            AuditSequence = item.AuditSequence,
            Cost = item.Cost,
            CreatedOn = item.CreatedOn,
            CustodianAccountCode = item.CustodianAccountCode,
            CustodianName = item.CustodianName,
            EntryDate = item.EntryDate,
            FundCode = item.FundCode,
            FXRate = item.FXRate,
            LastModifiedBy = item.LastModifiedBy,
            LastModifiedOn = item.LastModifiedOn,
            Portfolio = Portfolio.Parse(item.StrategyCode),
            Price = item.Price,
            Security = new Security
            {
                BamSymbol = item.BAMSymbol,
                SecurityType =
                    Enum.IsDefined(typeof (SecurityType), item.AssetType)
                        ? Data.Utility.ConvertEnum<SecurityType>(item.AssetType)
                        : default(SecurityType),
                Currency = item.Ccy
            },
            Stream = item.Stream,
            TheoreticalQuantity = item.Qty,
            ShortMarkingQuantity = item.Qty,
            LongMarkingQuantity = item.Qty
        };

        /// <summary>
        /// Function to map Position fields to DB columns
        /// </summary>
        internal static readonly Func<Position, dynamic> ParameterMap = position => new
        {
            position.PositionId,
            position.ActionLogId,
            position.AuditSequence,
            position.Cost,
            position.CreatedOn,
            position.CustodianAccountCode,
            position.CustodianName,
            position.EntryDate,
            position.FundCode,
            position.FXRate,
            position.LastModifiedBy,
            position.LastModifiedOn,
            position.Price,
            position.Stream,
            StrategyCode = position.Portfolio.ToString(),
            BAMSymbol = position.Security.BamSymbol,
            AssetType = position.Security.SecurityType.ToString(),
            Qty = position.ActualQuantity,
            Ccy = position.Security.Currency
        };

        public PositionDBRepository(ISettings settings, ILogger logger) : base(settings, logger, "sod", "Position", ResultMap, ParameterMap)
        {
            _includeColumnPredicate = (column => !column.Equals("Key"));
        }

        public IList<Position> GetPositions(DateTime? asofdate, string stream, string fundCode, string custodianName, string strategyCode, string securityType, string bamSymbol)
        {
            dynamic parameters = new ExpandoObject();
            if (asofdate != null)
            {
                parameters.EntryDate = asofdate;
            }
            if (!String.IsNullOrWhiteSpace(stream))
            {
                parameters.Stream = stream;
            }
            if (!String.IsNullOrWhiteSpace(fundCode))
            {
                parameters.FundCode = fundCode;
            }
            if (!String.IsNullOrWhiteSpace(custodianName))
            {
                parameters.CustodianName = custodianName;
            }
            if (!String.IsNullOrWhiteSpace(strategyCode))
            {
                parameters.StrategyCode = strategyCode;
            }
            if (!String.IsNullOrWhiteSpace(securityType))
            {
                parameters.AssetType = securityType;
            }
            if (!String.IsNullOrWhiteSpace(bamSymbol))
            {
                parameters.BAMSymbol = bamSymbol;
            }

            return new List<Position>(Get(parameters));
        }
    }
}
