﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.DataProvider
{
    public class CompositeDecomposer : ICompositeDecomposer
    {
        private readonly ISecurityProvider _securityProvider;
        private readonly ICustomDataProvider _customDataProvider;
        private readonly IMarketDataProvider _marketDataProvider;
        private readonly ILogger _logger;
       
        
        public CompositeDecomposer(IMarketDataProvider marketDataProvider, ICustomDataProvider customDataProvider, ISecurityProvider securityProvider, ILogger logger )
        {
            _securityProvider = securityProvider;
            _customDataProvider = customDataProvider;
            _marketDataProvider = marketDataProvider;
            _logger = logger;

        }
        
        public IEnumerable<IPosition> Decompose(IPosition position)
        {
            try
            {
                if (!position.Security.IsComposite())
                {
                    return new List<IPosition>() { position };
                }

                var compositeSecurity = _securityProvider.GetSecurity(position.Security.UnderlyingSymbol);

                var compositeSymbol = compositeSecurity?.TrackIndexCode ?? compositeSecurity?.BamSymbol;

                var constituents = _customDataProvider.GetConstituents(compositeSymbol).ToList();

                if (compositeSymbol == null || !constituents.Any())
                    return new List<IPosition>() { position };

                //set netexposure
                position.NetExposure = position.NetExposure ?? position.ActualQuantity * _marketDataProvider.GetPrice(position.Security.BamSymbol);

                var decomposed = new List<IPosition>();
                
                foreach (var c in constituents)
                {
                    var security = _securityProvider.GetSecurity(c.Symbol);
                    if (security == null) continue;
                    var qty = GetEquivalentShares(position.NetExposure, c.Allocation, security);
                    if (qty == 0) continue;
                    var pos = new Position()
                    {
                        ActualQuantity = qty,
                        Security = (Security)security,
                        ParentSymbol =
                            $"{position.Security.BamSymbol}/{compositeSymbol}:{position.NetExposure}|{c.Allocation}",
                        Portfolio = position.Portfolio
                    }.InitPosition();

                    decomposed.Add(pos);
                }

                return decomposed;

            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
                return new List<IPosition>(){position};
            }
           
        }

        private decimal GetEquivalentShares(decimal? netExposure, decimal? allocation, ISecurity security)
        {
            if (!netExposure.HasValue) return 0;
            if (!allocation.HasValue) return 0;

            var price = _marketDataProvider.GetPrice(security.BamSymbol);
            if (price == null || price == 0)
            {
                _logger.Info($"Cant get price for {security.BamSymbol}");
                return 0;
            }
            var equivalentShares = netExposure*allocation/price;

            return equivalentShares.Value;
        }
    }
}
