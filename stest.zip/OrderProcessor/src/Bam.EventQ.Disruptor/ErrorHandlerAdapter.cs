﻿using System;
using Bam.EventQ.Queue;
using Disruptor;

namespace Bam.EventQ.Disruptor
{
    public class ErrorHandlerAdapter : IExceptionHandler
    {
        private readonly IQueueErrorHandler _errorHandler;

        public ErrorHandlerAdapter(IQueueErrorHandler errorHandler)
        {
            _errorHandler = errorHandler;
        }

        public void HandleEventException(Exception ex, long sequence, object evt)
        {
            _errorHandler.HandleError(ex, sequence, evt);
        }

        public void HandleOnStartException(Exception ex)
        {
            _errorHandler.HandleError(ex, null, null);
        }

        public void HandleOnShutdownException(Exception ex)
        {
            _errorHandler.HandleError(ex, null, null);
        }
    }
}
