﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Owin;
using System.Reflection;
using System.Web.Http;

namespace Bam.Oms.EndPoints.Http
{
    public class AuthorizeMiddleware : OwinMiddleware
    {
        private readonly IPermissionChecker _checker;

        public AuthorizeMiddleware(OwinMiddleware next, IPermissionChecker checker) : base(next)
        {
            _checker = checker;
        }

        public override async Task Invoke(IOwinContext context)
        {
            if (!_checker.IsAllowed(context.Request))
            {
                // 401 is the status code of unauthorized
                context.Response.StatusCode = 401;
            }
            else
            {
                await Next.Invoke(context);
            }
        }

    }
}
