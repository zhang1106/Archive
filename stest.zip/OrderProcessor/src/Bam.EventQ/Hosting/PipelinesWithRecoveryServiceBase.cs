﻿using System.Collections.Generic;
using System.Reflection;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Transport;

namespace Bam.EventQ.Hosting
{
    public abstract class PipelinesWithRpcServiceBase : IService
    {
        private readonly IEnumerable<IProcessingPipeline> _pipelines;
        private readonly IRpcServer _rpcServer;

        public ILogger Logger { get;set; }

        protected PipelinesWithRpcServiceBase(IEnumerable<IProcessingPipeline> pipelines, IRpcServer rpcServer)
        {
            _pipelines = pipelines;
            _rpcServer = rpcServer;
        }

        public abstract string Name { get; }

        public virtual void Start()
        {
            Logger?.LogInformation($"Starting version {Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version}");

            _rpcServer.Start();
            foreach (var pipeline in _pipelines)
            {
                pipeline.Start();
            }
        }

        public virtual void Stop()
        {
            _rpcServer.Stop();
            foreach (var pipeline in _pipelines)
            {
                pipeline.Stop();
            }
        }
    }
}
