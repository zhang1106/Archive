﻿namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public interface IHeadroomEffectCache
    {
        HeadroomEffects GetEffect(long orderId, int ruleId, string identifier);
        void SetEffect(long orderId, int ruleId, string identifier, HeadroomEffects effect);
        void Reset(long orderId, int ruleId, string identifier);
    }
}
