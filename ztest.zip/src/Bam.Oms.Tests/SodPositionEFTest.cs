﻿using NUnit.Framework;
using Bam.Oms.SodPosition.Svc;
using System.Data.Entity;
using System.Collections;
using Moq;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Enumerators;
using System;
using DBModel = Bam.Oms.DBModel;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.Infrastructure;
using AutoMapper;
using System.Configuration;
using Bam.Oms.SodPosition.Svc.File;
using System.Threading;

namespace Bam.Oms.Tests
{
    [Category("Integration")]
    [TestFixture]
    public class SodPositionEFTest
    {
        private DateTime _testStartTime;

        [SetUp]
        public void Init()
        {
            _testStartTime = DateTime.Now;
        }
        [Test]
        public void TestWhatsup()
        {
            ISodPositionEdit sEdit = new SodPositionEditEF();
            string s = sEdit.Whatsup();
            Assert.That(s, Is.EqualTo("Hello World"));
        }

        [Test]
        public void TestMapperConfiguration()
        {
            ISodPositionEdit sEdit = new SodPositionEditEF();
            //Creating an instance of SodPositionEditEF sets up the automapper mapping
            Mapper.AssertConfigurationIsValid();
        }

        [Test]
        public void TestGetSodPositions()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianName="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long},

                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=201.54M, ActualSide=SideType.Short, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=35, AuditSequence=5, LastModifiedOn=now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 201.54M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, null, null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }




        [Test]
        public void TestGetSodPositionsWithEntryDateFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=201.54M, ActualSide=SideType.Short, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=35, AuditSequence=5, LastModifiedOn=now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 201.54M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, now.Date, null, null, null, null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }

        }


        [Test]
        public void TestGetSodPositionsWithStreamFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianName="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long},
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, "AS", null, null, null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }



        [Test]
        public void TestGetSodPositionsWithBamSymbolFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianName="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long},
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, null, null, null, "MSFT");
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [Test]
        public void TestGetSodPositionsWithFundCodeFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=201.54M, ActualSide=SideType.Short, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=35, AuditSequence=5, LastModifiedOn=now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 201.54M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, "Fund2", null, null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [Test]
        public void TestGetSodPositionsWithCustodianAccountFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianName="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, "GOLDMAN", null, null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [Test]
        public void TestGetSodPositionsWithInvestmentTypeFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {
                new Position { PositionId= 2, Security=new Security {BamSymbol = "GOOG", Currency="PKR", SecurityType = SecurityType.EquityOption }, Price = 7115.45M, EntryDate=now.Date, CustodianName="BARCLAYS", FXRate=104.75M, ActualQuantity=201.54M, ActualSide=SideType.Short, Portfolio=(Portfolio)Portfolio.Parse("Darth-Vader"), Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=35, AuditSequence=5, LastModifiedOn=now, LastModifiedBy="CORP\\kishore", TheoreticalQuantity = 201.54M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, null, null, "EquityOption", null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [Test]
        public void TestGetSodPositionsWithStrategyCodeFilter()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianName="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, null, null, null, null, "Obi-Wan-Kenobi", null, null);
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }


        [Test]
        public void TestGetSodPositionsWithFilters()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianName="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetSodPositions(null, yesterday.Date, "AS", "Fund1", "GOLDMAN", "Obi-Wan-Kenobi", "Equity", "MSFT");
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p in pos1)
            {
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }


        [Test]
        public void TestGetPositionsWithFilters()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="INR", SecurityType = SecurityType.Equity }, Price=75.45M, EntryDate=yesterday.Date, CustodianName="GOLDMAN", FXRate=65.5M, ActualQuantity=200.54M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=25, AuditSequence=3, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200.54M, TheoreticalSide = SideType.Long}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position {PositionId = 1, BAMSymbol = "MSFT", Ccy = "INR", CreatedOn = yesterday, ActionLogId = 25,
                AuditSequence = 3, CustodianName = "GOLDMAN", EntryDate = yesterday.Date, FundCode = "Fund1", FXRate = 65.5M,
                AssetType = "Equity", Price = 75.45M, Qty = 200.54M, StrategyCode = "Obi-Wan-Kenobi", Stream = "AS",
                LastModifiedBy = "kishore", LastModifiedOn = now},

                new DBModel.Position {PositionId = 2, BAMSymbol = "GOOG", Ccy = "PKR", CreatedOn = now, ActionLogId = 35,
                AuditSequence = 5, CustodianName = "BARCLAYS", EntryDate = now.Date, FundCode = "Fund2", FXRate = 104.75M,
                AssetType = "EquityOption", Price = 7115.45M, Qty = -201.54M, StrategyCode = "Darth-Vader", Stream = "US",
                LastModifiedBy = "CORP\\kishore", LastModifiedOn = now}
            };
            var mockSet = GetMockDbSet(positionRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var pos1 = posEdit.GetPositions(null, yesterday.Date, "AS", "Fund1", "GOLDMAN", "Obi-Wan-Kenobi", "Equity", "MSFT");
            Assert.IsTrue(pos1.Count == expectedPositions.Count());
            foreach (var p1 in pos1)
            {
                var p = p1 as Position;
                Assert.IsTrue(IsSamePosition(p, expectedPositions.First(x => x.PositionId == p.PositionId)));
            }
        }

        [Test]
        public void TestGetLatestUpdatedPositions()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);

            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 4, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 5, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = now.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "AS", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                 new Position {PositionId = 6, Security = new Security {BamSymbol = "GOOG", Currency = "USD", SecurityType = SecurityType.EquityOption }, Price = 2.5M, EntryDate = now.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},
            };
            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {

                new DBModel.Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=-200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquityOption", LastModifiedOn=now, LastModifiedBy="kishore"},

            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="US_PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };

            List<DBModel.ActionLog> actionLogRepository = new List<DBModel.ActionLog>()
            {
                new DBModel.ActionLog {ActionLogId = 1, ActionId = 2, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 2, ActionId = 3, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 3, ActionId = 4, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 4, ActionId = 5, CreatedOn = yesterday },
            };

            var mockPositionSet = GetMockDbSet(positionRepository);
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockActionLogSet = GetMockDbSet(actionLogRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            ISodPositionEdit posEdit = new SodPositionEditEF(() => mockContext.Object);
            var updatedPositions = posEdit.GetLatestUpdatedPositions(null, "US");
            // All positions except the ones with Audit sequence = 0 should be returned
            // as there are no previous action logs of type: PUBLISH_UPDATED_POSITIONS
            var expected = expectedPositions.Where(x => x.AuditSequence > 0 && x.Stream == "US").ToList();
            Assert.IsTrue(expected.Count > 0);
            Assert.IsTrue(expected.Count == updatedPositions.Count());
            foreach (var p in updatedPositions)
            {
                Assert.IsTrue(IsSamePosition(p, expected.Find(x => x.PositionId == p.PositionId)));
            }


            // Add an action log corresponding to PUBLISH_UPDATED_POSITIONS action
            actionLogRepository.Add(new DBModel.ActionLog { ActionLogId = 5, ActionId = 1, CreatedOn = now.AddHours(-1) });
            mockPositionSet = GetMockDbSet(positionRepository);
            mockActionSet = GetMockDbSet(actionRepository);
            mockActionLogSet = GetMockDbSet(actionLogRepository);
            mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            posEdit = new SodPositionEditEF(() => mockContext.Object);
            updatedPositions = posEdit.GetLatestUpdatedPositions(null, "US");
            // All positions except the ones with Audit sequence = 0 should be returned
            // as there are no previous action logs of type: PUBLISH_UPDATED_POSITIONS
            expected = expectedPositions.Where(x => x.LastModifiedOn > now.AddHours(-1) && x.AuditSequence > 0 && x.Stream == "US").ToList();
            Assert.IsTrue(expected.Count > 0);
            Assert.IsTrue(expected.Count == updatedPositions.Count());
            foreach (var p in updatedPositions)
            {
                Assert.IsTrue(IsSamePosition(p, expected.Find(x => x.PositionId == p.PositionId)));
            }
        }

        [Test]
        public void TestGetAudits()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = DateTime.Now.AddDays(-1);
            List<PositionAudit> expectedPositions = new List<PositionAudit>()
            {
                new PositionAudit {PositionAuditId = 1, Position =
                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, LastModifiedOn=yesterday, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long}
                },

                new PositionAudit {PositionAuditId = 2, Position =
                new Position {PositionId = 1, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long}
                },

                new PositionAudit {PositionAuditId = 3, Position =
                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short}
                },

                new PositionAudit {PositionAuditId = 4, Position =
                new Position {PositionId = 1, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Short}
                },

                new PositionAudit {PositionAuditId = 5, Position =
                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = now.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "AS", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long}
                },

                new PositionAudit {PositionAuditId = 6, Position =
                 new Position {PositionId = 1, Security = new Security {BamSymbol = "GOOG", Currency = "USD", SecurityType = SecurityType.EquityOption }, Price = 2.5M, EntryDate = now.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long}
                },
            };

            var positionAuditRepository = new List<DBModel.PositionAudit>()
            {
               new DBModel.PositionAudit { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore", PositionAuditId = 1},

                new DBModel.PositionAudit { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore", PositionAuditId = 2},

                new DBModel.PositionAudit { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore", PositionAuditId = 3},
                new DBModel.PositionAudit { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=-200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore", PositionAuditId = 4},
                new DBModel.PositionAudit { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore", PositionAuditId = 5},

                new DBModel.PositionAudit { PositionId= 1, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquityOption", LastModifiedOn=now, LastModifiedBy="kishore", PositionAuditId = 6},
            };

            var mockPositionAuditSet = GetMockDbSet(positionAuditRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.PositionAudits).Returns(mockPositionAuditSet.Object);
            var posEdit = new SodPositionEditEF(() => mockContext.Object);
            var auditInfo = posEdit.GetAudits(null, 1, yesterday.Date);
            var expected = auditInfo.Where(x => x.Position.PositionId == 1 && x.Position.EntryDate == yesterday.Date).ToList();
            Assert.IsTrue(expected.Count() > 0);
            Assert.IsTrue(expected.Count == auditInfo.Count());
            foreach (var audit in auditInfo)
            {
                Assert.IsTrue(IsSameAuditInfo(audit, expected.Find(x => x.PositionAuditId == audit.PositionAuditId)));
            }
        }

        [Test]
        public void TestGetBulkActions()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);
            List<SodAction> sodActions = new List<SodAction>()
            {
                new SodAction {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new SodAction {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday }
            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            var posEdit = new SodPositionEditEF(() => mockContext.Object);
            var bulkActions = posEdit.GetBulkActions(null);
            var expected = actionRepository.Where(x => x.Type == "corp").ToList();
            Assert.IsTrue(expected.Count > 0);
            Assert.IsTrue(expected.Count == bulkActions.Count());
            foreach (var cAct in bulkActions)
            {
                Assert.IsTrue(IsSameAction(cAct, sodActions.Find(x => x.ActionId == cAct.ActionId)));
            }
        }

        [Test]
        public void TestInsertPosition()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = DateTime.Now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 4, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 5, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = now.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "AS", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {

                new DBModel.Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=-200000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
            List<DBModel.ActionLog> actionLogRepository = new List<DBModel.ActionLog>()
            {
                new DBModel.ActionLog {ActionLogId = 1, ActionId = 2, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 2, ActionId = 3, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 3, ActionId = 4, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 4, ActionId = 5, CreatedOn = yesterday },
            };
            var mockPositionSet = GetMockDbSet(positionRepository);
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockActionLogSet = GetMockDbSet(actionLogRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            
            mockContext.Setup(x => x.ActionLogs.Add(It.IsAny<DBModel.ActionLog>())).Callback<DBModel.ActionLog>((actLog) =>
            {
                actLog.ActionLogId = 1000;
                actionLogRepository.Add(actLog);
            });

            var posEdit = new SodPositionEditEF(() => mockContext.Object);
            posEdit.Start();

            mockContext.Setup(x => x.Positions.Add(It.IsAny<DBModel.Position>())).Callback<DBModel.Position>((pos1) =>
            {
                pos1.PositionId = 1000;
                positionRepository.Add(pos1);
            });
            var insertPosition = new Position
            {
                Security = new Security { BamSymbol = "GOOG", Currency = "USD", SecurityType = SecurityType.EquityOption },
                Price = 2.5M,
                EntryDate = now.Date,
                CustodianName = "Deutsche Bank",
                FXRate = 1M,
                ActualQuantity = -200000M,
                ActualSide = SideType.Long,
                Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"),
                Stream = "US",
                FundCode = "Fund1",
                LastModifiedBy = "kishore",
                TheoreticalQuantity = -200000M,
                TheoreticalSide = SideType.Long
            };
            var returnedPosition = posEdit.InsertPosition(null, insertPosition);
            Assert.IsTrue(returnedPosition != null);
            Assert.IsTrue(returnedPosition.PositionId == 1000);
            Assert.IsTrue(returnedPosition.ActionLogId == 1000);
            // Assuming it takes less than a minute to execute this test case
            Assert.IsTrue(returnedPosition.EntryDate == now.Date);
            Assert.IsTrue(returnedPosition.AuditSequence == 1);
            Assert.IsTrue(returnedPosition.CreatedOn >= _testStartTime
                && returnedPosition.CreatedOn <= DateTime.Now);
            Assert.IsTrue(returnedPosition.LastModifiedOn >= _testStartTime
                && returnedPosition.LastModifiedOn <= DateTime.Now);
            Assert.IsTrue(returnedPosition.Security.BamSymbol == "GOOG");
            Assert.IsTrue(returnedPosition.Security.Currency == "USD");
            Assert.IsTrue(returnedPosition.CustodianName == "Deutsche Bank");
            Assert.IsTrue(returnedPosition.FXRate == 1M);
            Assert.IsTrue(returnedPosition.FundCode == "Fund1");
            Assert.IsTrue(returnedPosition.Security.SecurityType == SecurityType.EquityOption);
            Assert.IsTrue(returnedPosition.Price == 2.5M);
            Assert.IsTrue(returnedPosition.Portfolio.Equals(Portfolio.Parse("Darth-Vader")));
            Assert.IsTrue(returnedPosition.LastModifiedBy == "kishore");
            Assert.IsTrue(returnedPosition.TheoreticalQuantity == 200000M);
            Assert.IsTrue(returnedPosition.Stream == "US");
            Assert.IsTrue(returnedPosition.ActualQuantity == 200000M);
            Assert.IsTrue(returnedPosition.ActualSide == SideType.Short);
            Assert.IsTrue(returnedPosition.TheoreticalSide == SideType.Short);

            var actionLog = actionLogRepository.Find(x => x.ActionLogId == 1000);
            Assert.IsTrue(actionLog.ActionId == 2);
        }


        [Test]
        public void TestBulkInsertPosition()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = DateTime.Now.AddDays(-1);
            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M,
                    ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = now.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short}
            };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {

                new DBModel.Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
            List<DBModel.ActionLog> actionLogRepository = new List<DBModel.ActionLog>()
            {
                new DBModel.ActionLog {ActionLogId = 1, ActionId = 2, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 2, ActionId = 3, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 3, ActionId = 4, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 4, ActionId = 5, CreatedOn = yesterday },
            };
            var mockPositionSet = GetMockDbSet(positionRepository);
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockActionLogSet = GetMockDbSet(actionLogRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            int positionIdCounter = 1000;
            int actionLogIdCounter = 1000;

            mockContext.Setup(x => x.ActionLogs.Add(It.IsAny<DBModel.ActionLog>())).Callback<DBModel.ActionLog>((actLog) =>
            {
                actLog.ActionLogId = actionLogIdCounter++;
                actionLogRepository.Add(actLog);
            });

            var posEdit = new SodPositionEditEF(() => mockContext.Object);
            posEdit.Start();

            mockContext.Setup(x => x.Positions.AddRange(It.IsAny<IEnumerable<DBModel.Position>>())).Callback<IEnumerable<DBModel.Position>>((positions) =>
            {
                foreach (var pos1 in positions)
                {
                    pos1.PositionId = positionIdCounter++;
                }
                positionRepository.AddRange(positions);
            });
            var insertPosition1 = new Position
            {
                PositionId = 4,
                Security = new Security { BamSymbol = "IBM", Currency = "USD", SecurityType = SecurityType.EquitySwap },
                Price = 2.5M,
                EntryDate = now.Date,
                CustodianName = "Deutsche Bank",
                FXRate = 1M,
                ActualQuantity = 200000M,
                ActualSide = SideType.Short,
                Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"),
                Stream = "US",
                FundCode = "Fund2",
                CreatedOn = now,
                ActionLogId = 1,
                AuditSequence = 1,
                LastModifiedOn = yesterday,
                LastModifiedBy = "kishore",
                TheoreticalQuantity = 200000M,
                TheoreticalSide = SideType.Short
            };

            var insertPosition2 = new Position
            {
                PositionId = 5,
                Security = new Security { BamSymbol = "GOOG", Currency = "GBP", SecurityType = SecurityType.Equity },
                Price = 4.5M,
                EntryDate = yesterday.Date,
                CustodianName = "Goldman",
                FXRate = 1.15M,
                ActualQuantity = 2000M,
                ActualSide = SideType.Long,
                Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"),
                Stream = "EU",
                FundCode = "Fund1",
                CreatedOn = now,
                ActionLogId = 1,
                AuditSequence = 0,
                LastModifiedOn = now,
                LastModifiedBy = "kishore",
                TheoreticalQuantity = 2000M,
                TheoreticalSide = SideType.Long
            };
            var returnedPositions = posEdit.BulkInsertPosition(null, new List<Position> { insertPosition1, insertPosition2 });
            Assert.IsTrue(returnedPositions.Count == 2);
            var returnedPosition1 = returnedPositions.Where(x => x.Security.BamSymbol == "IBM").First();
            var returnedPosition2 = returnedPositions.Where(x => x.Security.BamSymbol == "GOOG").First();
            Assert.IsTrue(returnedPosition1.PositionId == 1000 || returnedPosition2.PositionId == 1000);
            Assert.IsTrue(returnedPosition1.PositionId == 1001 || returnedPosition2.PositionId == 1001);
            Assert.IsTrue(returnedPosition1.ActionLogId == 1000 && returnedPosition2.ActionLogId == 1000);

            // Assuming it takes less than a minute to execute this test case
            Assert.IsTrue(returnedPosition1.EntryDate == now.Date);
            Assert.IsTrue(returnedPosition1.AuditSequence == 1);
            Assert.IsTrue(returnedPosition1.CreatedOn >= _testStartTime
                && returnedPosition1.CreatedOn <= DateTime.Now);
            Assert.IsTrue(returnedPosition1.LastModifiedOn >= _testStartTime
                && returnedPosition1.LastModifiedOn <= DateTime.Now);
            Assert.IsTrue(returnedPosition1.Security.BamSymbol == "IBM");
            Assert.IsTrue(returnedPosition1.Security.Currency == "USD");
            Assert.IsTrue(returnedPosition1.CustodianName == "Deutsche Bank");
            Assert.IsTrue(returnedPosition1.FXRate == 1M);
            Assert.IsTrue(returnedPosition1.FundCode == "Fund2");
            Assert.IsTrue(returnedPosition1.Security.SecurityType == SecurityType.EquitySwap);
            Assert.IsTrue(returnedPosition1.Price == 2.5M);
            Assert.IsTrue(returnedPosition1.Portfolio.Equals(Portfolio.Parse("Obi-Wan-Kenobi")));
            Assert.IsTrue(returnedPosition1.LastModifiedBy == "kishore");
            Assert.IsTrue(returnedPosition1.ActualQuantity == 200000M);
            Assert.IsTrue(returnedPosition1.TheoreticalQuantity == 200000M);
            Assert.IsTrue(returnedPosition1.TheoreticalSide == SideType.Short);
            Assert.IsTrue(returnedPosition1.ActualSide == SideType.Short);
            Assert.IsTrue(returnedPosition1.Stream == "US");

            Assert.IsTrue(returnedPosition2.EntryDate == yesterday.Date);
            Assert.IsTrue(returnedPosition2.AuditSequence == 1);
            Assert.IsTrue(returnedPosition2.CreatedOn >= _testStartTime
                && returnedPosition2.CreatedOn <= DateTime.Now);
            Assert.IsTrue(returnedPosition2.LastModifiedOn >= _testStartTime
                && returnedPosition2.LastModifiedOn <= DateTime.Now);
            Assert.IsTrue(returnedPosition2.Security.BamSymbol == "GOOG");
            Assert.IsTrue(returnedPosition2.Security.Currency == "GBP");
            Assert.IsTrue(returnedPosition2.CustodianName == "Goldman");
            Assert.IsTrue(returnedPosition2.FXRate == 1.15M);
            Assert.IsTrue(returnedPosition2.FundCode == "Fund1");
            Assert.IsTrue(returnedPosition2.Security.SecurityType == SecurityType.Equity);
            Assert.IsTrue(returnedPosition2.Price == 4.5M);
            Assert.IsTrue(returnedPosition2.Portfolio.Equals(Portfolio.Parse("Darth-Vader")));
            Assert.IsTrue(returnedPosition2.LastModifiedBy == "kishore");
            Assert.IsTrue(returnedPosition2.ActualQuantity == 2000M);
            Assert.IsTrue(returnedPosition2.TheoreticalQuantity == 2000M);
            Assert.IsTrue(returnedPosition2.TheoreticalSide == SideType.Long);
            Assert.IsTrue(returnedPosition2.ActualSide == SideType.Long);
            Assert.IsTrue(returnedPosition2.Stream == "EU");
        }

        [Test]
        [ExpectedException(typeof(DbUpdateConcurrencyException))]
        public void TestUpdatePositionWithConcurrencyException()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = DateTime.Now.AddDays(-1);
            var positionToUpdate = new Position { PositionId = 1, Security = new Security { BamSymbol = "GOOG", Currency = "INR", SecurityType = SecurityType.EquitySwap }, Price = 3.5M, EntryDate = now.Date, CustodianName = "Karvy", FXRate = 2M, ActualQuantity = 200000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Short };

            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {
                new DBModel.Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=-200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="AS", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquityOption", LastModifiedOn=now, LastModifiedBy="kishore"},

            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_UPDATED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 6, Name="SPLIT", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 7, Name="STOCK_DIVIDEND", Type = "corp", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };
            List<DBModel.ActionLog> actionLogRepository = new List<DBModel.ActionLog>()
            {
                new DBModel.ActionLog {ActionLogId = 1, ActionId = 2, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 2, ActionId = 3, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 3, ActionId = 4, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 4, ActionId = 5, CreatedOn = yesterday },
            };
            List<DBModel.Exception> exceptionRepository = new List<DBModel.Exception>();
            var mockPositionSet = GetMockDbSet(positionRepository);
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockActionLogSet = GetMockDbSet(actionLogRepository);
            var mockExceptionSet = GetMockDbSet(exceptionRepository);
            var mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            mockContext.Setup(c => c.Exceptions).Returns(mockExceptionSet.Object);

            var posEdit = new SodPositionEditEF(() => mockContext.Object);
            posEdit.UpdatePosition(null, positionToUpdate);
        }

        private volatile int _publishFlag = 0;
        // This test case involves threads and locking. I don't want other tests to
        // keep on waiting endlessly if there are any issues with the logic.
        // Hence, I am having this timeout attribute
        [Test, Timeout(10000)]
        public void TestPublishLoadedPositions()
        {
            DateTime now = DateTime.Now;
            DateTime yesterday = now.AddDays(-1);

            var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings.Add("sodPosition_ordered_field_list", "Symbol,FundCode");
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(config.AppSettings.SectionInformation.Name);

            List<Position> expectedPositions = new List<Position>()
            {

                new Position { PositionId= 1, Security=new Security {BamSymbol = "MSFT", Currency="USD", SecurityType = SecurityType.Equity }, Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, ActualQuantity=200000M, ActualSide=SideType.Long, Portfolio=(Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream="US", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=1, AuditSequence=0, LastModifiedOn=now, LastModifiedBy="kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 2, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                new Position {PositionId = 3, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 4000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = yesterday, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 4000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 4, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.EquitySwap }, Price = 2.5M, EntryDate = yesterday.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Short, Portfolio = (Portfolio)Portfolio.Parse("Obi-Wan-Kenobi"), Stream = "EU", FundCode = "Fund2", CreatedOn = now, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = yesterday, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Short},

                new Position {PositionId = 5, Security = new Security {BamSymbol = "MSFT", Currency = "USD", SecurityType = SecurityType.Equity }, Price = 2.5M, EntryDate = now.Date, CustodianName = "Goldman", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "AS", FundCode = "Fund1", CreatedOn = yesterday, ActionLogId = 1, AuditSequence = 0, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},

                 new Position {PositionId = 6, Security = new Security {BamSymbol = "GOOG", Currency = "USD", SecurityType = SecurityType.EquityOption }, Price = 2.5M, EntryDate = now.Date, CustodianName = "Deutsche Bank", FXRate = 1M,
                ActualQuantity = 200000M, ActualSide = SideType.Long, Portfolio = (Portfolio)Portfolio.Parse("Darth-Vader"), Stream = "US", FundCode = "Fund1", CreatedOn = now, ActionLogId = 1, AuditSequence = 1, LastModifiedOn = now, LastModifiedBy = "kishore", TheoreticalQuantity = 200000M, TheoreticalSide = SideType.Long},
            };
            List<DBModel.Position> positionRepository = new List<DBModel.Position>()
            {

                new DBModel.Position { PositionId= 1, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="US", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 2, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=yesterday, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 3, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Goldman", FXRate=1M, Qty=-4000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=yesterday, ActionLogId=1, AuditSequence=0, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 4, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=yesterday.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=-200000M, StrategyCode="Obi-Wan-Kenobi", Stream="EU", FundCode="Fund2", CreatedOn=now, ActionLogId=1, AuditSequence=0, AssetType="EquitySwap", LastModifiedOn=yesterday, LastModifiedBy="kishore"},
                new DBModel.Position { PositionId= 5, BAMSymbol="MSFT", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Goldman", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="AS", FundCode="Fund1", CreatedOn=yesterday, ActionLogId=1, AuditSequence=0, AssetType="Equity", LastModifiedOn=now, LastModifiedBy="kishore"},

                new DBModel.Position { PositionId= 6, BAMSymbol="GOOG", Ccy="USD", Price=2.5M, EntryDate=now.Date, CustodianName="Deutsche Bank", FXRate=1M, Qty=200000M, StrategyCode="Darth-Vader", Stream="US", FundCode="Fund1", CreatedOn=now, ActionLogId=1, AuditSequence=1, AssetType="EquityOption", LastModifiedOn=now, LastModifiedBy="kishore"},

            };
            List<DBModel.Action> actionRepository = new List<DBModel.Action>()
            {
                new DBModel.Action {ActionId = 1, Name="PUBLISH_LOADED_POSITIONS", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 2, Name="POSITION_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 3, Name="POSITION_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 4, Name="POSITION_BULK_INSERT", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
                new DBModel.Action {ActionId = 5, Name="POSITION_BULK_UPDATE", Type = "bam", LastModifiedBy = "kishore", LastModifiedOn = yesterday },
            };

            List<DBModel.ActionLog> actionLogRepository = new List<DBModel.ActionLog>()
            {
                new DBModel.ActionLog {ActionLogId = 1, ActionId = 2, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 2, ActionId = 3, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 3, ActionId = 4, CreatedOn = yesterday },
                new DBModel.ActionLog {ActionLogId = 4, ActionId = 5, CreatedOn = yesterday },
            };

            var mockPositionSet = GetMockDbSet(positionRepository);
            var mockActionSet = GetMockDbSet(actionRepository);
            var mockActionLogSet = GetMockDbSet(actionLogRepository);
            Mock<DBModel.OrderGatewayEntities> mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);

            var mockFileLoading = new Mock<FileLoading>("C:\\", null, null);
            mockFileLoading.Setup(c => c.Process(It.IsAny<string>()));
            SodPositionEditEF posEdit = new SodPositionEditEF(() => mockContext.Object, mockFileLoading.Object);
            posEdit.Start();
            IList<Position> publishedPositions = null;

            Action<IList<Position>> posListener = (IList<Position> positions) =>
            {
                publishedPositions = positions;
                ++_publishFlag;
                
            };
            posEdit.SodPositionUpdated += posListener;
            mockFileLoading.Raise(x => x.SodPositionLoaded += null);
            while (_publishFlag == 0) ;
            _publishFlag = 0;
            
            // All positions with Audit sequence = 0 should be returned
            // as there are no previous action logs of type: PUBLISH_LOADED_POSITIONS
            var expected = expectedPositions.Where(x => x.AuditSequence == 0 && x.CreatedOn <= DateTime.Now).ToList();
            Assert.IsTrue(expected.Count > 0);
            Assert.IsTrue(expected.Count == publishedPositions.Count());
            foreach (var p in publishedPositions)
            {
                Assert.IsTrue(IsSamePosition(p, expected.Find(x => x.PositionId == p.PositionId)));
            }


            // Add an action log corresponding to PUBLISH_LOADED_POSITIONS action
            DateTime prevHour = now.AddHours(-1);
            actionLogRepository.Add(new DBModel.ActionLog { ActionLogId = 5, ActionId = 1, CreatedOn = prevHour });
            mockPositionSet = GetMockDbSet(positionRepository);
            mockActionSet = GetMockDbSet(actionRepository);
            mockActionLogSet = GetMockDbSet(actionLogRepository);
            mockContext = new Mock<DBModel.OrderGatewayEntities>();
            mockContext.Setup(c => c.Positions).Returns(mockPositionSet.Object);
            mockContext.Setup(c => c.Actions).Returns(mockActionSet.Object);
            mockContext.Setup(c => c.ActionLogs).Returns(mockActionLogSet.Object);
            mockFileLoading = new Mock<FileLoading>("C:\\", null, null);
            posEdit = new SodPositionEditEF(() => mockContext.Object, mockFileLoading.Object);
            posEdit.Start();
            publishedPositions = null;
            posEdit.SodPositionUpdated += posListener;
            mockFileLoading.Raise(x => x.SodPositionLoaded += null);
            while (_publishFlag == 0) ;
            // All positions except the ones with Audit sequence = 0 should be returned
            expected = expectedPositions.Where(x => x.CreatedOn >= prevHour && x.CreatedOn <= DateTime.Now && x.AuditSequence == 0).ToList();
            Assert.IsTrue(expected.Count > 0);
            Assert.IsTrue(expected.Count == publishedPositions.Count());
            foreach (var p in publishedPositions)
            {
                Assert.IsTrue(IsSamePosition(p, expected.Find(x => x.PositionId == p.PositionId)));
            }
            
        }

        private Mock<DbSet<T>> GetMockDbSet<T>(IList<T> entryList) where T : class
        {
            var queryable = entryList.AsQueryable();
            var mockSet = new Mock<DbSet<T>>();
            mockSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(queryable.Provider);
            mockSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(queryable.Expression);
            mockSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(queryable.ElementType);
            mockSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(queryable.GetEnumerator());
            return mockSet;
        }

        private bool IsSamePosition(Position p1, Position p2)
        {
            if (p2 == p1)
                return true;

            IPosition other = p2 as IPosition;
            if (other == null)
                return false;
            return p1.Portfolio.Equals(p2.Portfolio)
                   && p1.Security.Equals(p2.Security)
                   && p1.ActualQuantity.Equals(p2.ActualQuantity)
                   && p1.ActualSide.Equals(p2.ActualSide)
                   && p1.TheoreticalQuantity.Equals(p2.TheoreticalQuantity)
                   && p1.TheoreticalSide.Equals(p2.TheoreticalSide)
                   && p1.PositionId == p2.PositionId
                   && p1.Price == p2.Price
                   && p1.Stream == p2.Stream
                   && p1.ActionLogId == p2.ActionLogId
                   && p1.AuditSequence == p2.AuditSequence
                   && p1.CreatedOn == p2.CreatedOn
                   && p1.CustodianName == p2.CustodianName
                   && p1.EntryDate == p2.EntryDate
                   && p1.FundCode == p2.FundCode
                   && p1.FXRate == p2.FXRate
                   && p1.LastModifiedBy == p2.LastModifiedBy
                   && p1.LastModifiedOn == p2.LastModifiedOn
                   && p1.CustodianAccountCode == p2.CustodianAccountCode
                   && p1.Cost == p2.Cost;
        }

        private bool IsSameAuditInfo(PositionAudit p1, PositionAudit p2)
        {
            if (p1 == p2)
            {
                return true;
            }
            return p1.PositionAuditId == p2.PositionAuditId
                && IsSamePosition(p1.Position, p2.Position);
        }

        private bool IsSameAction(SodAction act1, SodAction act2)
        {
            if (act1 == act2)
            {
                return true;
            }
            return act1.ActionId == act2.ActionId
                && act1.Description == act2.Description
                && act1.LastModifiedBy == act2.LastModifiedBy
                && act1.LastModifiedOn == act2.LastModifiedOn
                && act1.Name == act2.Name
                && act1.Type == act2.Type;
        }
    }
}
