﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.EzeGateway
{
    public class EzeGatewaySettings : SettingsBase
    {
        public EzeGatewaySettings()
            : base("EzeGateway.")
        {
            UserDefinedFields["Algo"] = GetValue<string>("UDF.Algo");
            UserDefinedFields["Urgency"] = GetValue<string>("UDF.Urgency");
            UserDefinedFields["ActualBorrowRate"] = GetValue<string>("UDF.ActualBorrowRate");
            UserDefinedFields["IsFullyLocated"] = GetValue<string>("UDF.IsFullyLocated");
            UserDefinedFields["LocateBrokers"] = GetValue<string>("UDF.LocateBrokers");

            BrokerMarketParticipantIds = GetValueCollection("BrokerMarketParticipantIds");
        }

        public string Username
        {
            get { return GetValue(() => Username); }
        }

        public string Password
        {
            get { return GetValue(() => Password); }
        }

        public string TradingServiceUrl
        {
            get { return GetValue(() => TradingServiceUrl); }
        }

        public string HttpCallbackUrl
        {
            get { return GetValue(() => HttpCallbackUrl); }
        }

        public int SubmissionRetryCount
        {
            get { return GetValue(() => SubmissionRetryCount); }
        }

        public string PublishSubscribeUrl
        {
            get { return GetValue(() => PublishSubscribeUrl); }
        }

        public int MaxBatchSize
        {
            get { return GetValue(() => MaxBatchSize, 50); }
        }

        public RabbitMqSettings RabbitMq { get; } = new RabbitMqSettings();

        public RingBufferSettings Queue { get; } = new RingBufferSettings("EzeGateway.Queue.");

        public override string SelfPubSub => Endpoints.EzeGatewayPubSub;

        public override string SelfRpc => Endpoints.EzeGatewayRpc;

        public override Source SelfSource => Source.EzeGateway;

        public Dictionary<string, string> UserDefinedFields { get; } = new Dictionary<string, string>();

        public Dictionary<string, string> BrokerMarketParticipantIds { get; }

        public bool LogEzeMessages
        {
            get { return GetValue(() => LogEzeMessages, true); }
        }

        public int SubmissionThreadPoolSize
        {
            get { return GetValue(() => SubmissionThreadPoolSize, 4); }
        }

        public int SubmissionFastLaneCount
        {
            get { return GetValue(() => SubmissionFastLaneCount, 1); }
        }

        public int FastLaneThreshold
        {
            get { return GetValue(() => FastLaneThreshold, 5); }
        }

        public int FastLaneMaxBatchSize
        {
            get { return GetValue(() => FastLaneMaxBatchSize, 5); }
        }
    }
}
