﻿namespace Bam.EventQ.Solace
{
    public interface ISolaceTopicProvider<in TItem>
    {
        string GetTopic(TItem item);
    }
}
