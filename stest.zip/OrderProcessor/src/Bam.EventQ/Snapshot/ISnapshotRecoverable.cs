﻿namespace Bam.EventQ.Snapshot
{
    public interface ISnapshotRecoverable
    {
    }

    public interface ISnapshotRecoverable<TSnapshot> : ISnapshotRecoverable 
        where TSnapshot : ISnapshot
    {
        TSnapshot Persist();
        void Recover(TSnapshot snapshot);
    }
}
