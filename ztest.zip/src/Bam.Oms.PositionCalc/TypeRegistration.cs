﻿using BAM.Infrastructure.Ioc;

namespace Bam.Oms.PositionCalc
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            container.RegisterType<IPositionCalculator, PositionCalculator>(RegistrationType.Singleton);
        }
    }
}