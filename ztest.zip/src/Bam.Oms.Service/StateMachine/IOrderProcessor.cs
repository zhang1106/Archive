﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Bam.Oms.Data.Orders;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Service.Orders
{
    /// <summary>
    /// Service for taking an order through the order lifecycle (position tracking, trade marking, short locates, submission to EMS)
    /// </summary>
    public interface IOrderProcessor : IDisposable
    {
        [Log]
        IList<IOrder> MarkAndTrackOrder(IOrder order);

        [Log]
        IList<IOrder> LocateShorts(IList<IOrder> markedOrders);

        [Log]
        Task ProcessNewOrders(IEnumerable<IOrder> orders, string batchId = null);

        [Log]
        void ProcessNewOrder(IOrder order, string batchId = null);

        [Log]
        Task ProcessReplaceOrder(IOrder orders);

        [Log]
        Task ProcessCancelOrders(IEnumerable<string> orderIds);

        [Log]
        Task RouteOrder(string orderId);

        [Log]
        Task RebuildOrderCache();

        long TotalOrdersProcessed { get; }
    }
}