﻿using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Persistence.Compliance
{
    public interface IRuleResultRepository : IPersistentRepository<RuleResult>
    {
    }
}
