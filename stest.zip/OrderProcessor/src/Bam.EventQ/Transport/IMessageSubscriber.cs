﻿using System;

namespace Bam.EventQ.Transport
{
    public interface IMessageSubscriber
    {
        string Name { get; }
        bool TryReceive(byte[] buffer, int index, out int received, out int topic, TimeSpan timeout);
    }
}
