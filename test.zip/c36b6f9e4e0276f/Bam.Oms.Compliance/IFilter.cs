﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Compliance
{
    //this is silimiar/same from what Ryan is working on in pub/sub subject contex, 
    //Ryan will put it some common place to be shared...
    //this is temparory place holder for its usage here

    public enum FilterOperator
    {
        And,
        Or,
        Contains
    }

    public interface IFilter<TFilterPropertyValue>
    {
        string Property { get; set; }
        IList<TFilterPropertyValue> Values { get; }
        FilterOperator Operator { get; set; }
        void AddValue(TFilterPropertyValue value);        
    }
}
