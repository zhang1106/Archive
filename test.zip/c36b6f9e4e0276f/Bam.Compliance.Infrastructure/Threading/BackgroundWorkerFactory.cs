﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Compliance.Infrastructure.Logger;

namespace Bam.Compliance.Infrastructure.Threading
{
    public static class BackgroundWorkerFactory
    {
        public static ILogger Logger { get; set; }
        public static IBackgroundWorkerFactory Default { get; } = new ThreadedBackgroundWorkerFactory();
        public static IBackgroundWorkerFactory Current { get; set; } = Default;
    }
}
