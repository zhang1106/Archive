﻿using System;
using Bam.EventQ.Lookup;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class SodPosition : ModelBase<object>, ICloneable
    {
        public const string NotAvailable = "N/A";
        public const string Multiple = "Multiple";

        public SodPosition()
        {
            CustodianName = NotAvailable;
            FundCode = NotAvailable;
        }

        internal string Id => $"{Security?.BamSymbol}-{FundCode}-{Portfolio}-{CustodianName}";

        public string Key => $"Portfolio:{Portfolio} Security:{Security.Key}";
        public Portfolio Portfolio { get; set; }
        public Security Security { get; set; }
        public string FundCode { get; set; }
        public string CustodianName { get; set; }
        public DateTime EntryDate { get; set; }
        public decimal ActualQuantity { get; set; }
        public decimal TheoreticalQuantity { get; set; }
        public DateTime LastUpdated { get; set; }

        public virtual object Clone()
        {
            return new SodPosition
            {
                Portfolio = (Portfolio)Portfolio.Clone(),
                Security = (Security)Security.Clone(),
                FundCode = FundCode,
                CustodianName = CustodianName,
                EntryDate = EntryDate,
                ActualQuantity = ActualQuantity,
                TheoreticalQuantity = TheoreticalQuantity,
                LastUpdated = LastUpdated
            };
        }
    }
}
