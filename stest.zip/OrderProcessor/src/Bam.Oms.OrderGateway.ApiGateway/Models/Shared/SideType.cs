﻿namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public enum SideType
    {
        Unknown = 0,
        Buy = 1,
        Sell = 2,
        Cover = 3,
        SellShort = 4,
        Short = 5,
        Long = 6,
        Repo = 7,
        ReverseRepo = 8
    }
}
