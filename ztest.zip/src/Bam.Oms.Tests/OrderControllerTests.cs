﻿using System.Collections.Generic;
using System.Web.Http.Filters;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using log4net;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class OrderControllerTests
    {
        [Test]
        public void VerifyInvalidOrderDoesNotSumbit()
        {
            // arrange
            Container.Instance.RegisterInstance(new Mock<ISettings>().Object);

            var validator= new Mock<IOrderValidator>();
            validator.Setup(r => r.IsValidOrder(It.IsAny<List<IOrder>>())).Returns(false);

            var notifier = new Mock<IOrderNotifier>();
            var flowManager = new Mock<IFlowManager>();

            var controller = new OrderController(notifier.Object, new Mock<IOrderRepository>().Object
                ,new Mock<IHostConfiguration>().Object,new Mock<IOrderPrepUtility>().Object,new Mock<ILogger>().Object,   
                validator.Object, new Mock<IAccountService>().Object, flowManager.Object);

            var orderList = new List<Order>();
            orderList.Add(new Order() {Portfolio = (Portfolio) Portfolio.Parse("GREE-GENERALIST")});


            // act
            var unit = controller.PostOrders(orderList.ToArray());

            // assert
            Assert.Null(unit);
            notifier.Verify(l => l.NotifyNewOrders(It.IsAny<IList<IOrder>>()), Times.Never);
        }
    }
}