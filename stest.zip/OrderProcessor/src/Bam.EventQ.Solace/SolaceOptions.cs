﻿using SolaceSystems.Solclient.Messaging;
using SolaceSystems.Solclient.Messaging.Cache;

namespace Bam.EventQ.Solace
{
    public class SolaceOptions
    {
        public string Vpn { get; set; }
        public string Host { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string CacheName { get; set; }
        public bool GenerateSequenceNumbers { get; set; }

        internal SessionProperties ToSessionProperties()
        {
            return new SessionProperties
            {
                Host = Host,
                UserName = Username,
                Password = Password,
                VPNName = Vpn,
                GenerateSequenceNumber = GenerateSequenceNumbers,
                ReconnectRetries = -1,
                ReapplySubscriptions = true
            };
        }

        internal CacheSessionProperties ToCacheSessionProperties()
        {
            return new CacheSessionProperties
            {
                CacheName = CacheName
            };
        }
    }
}
