﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.Filters;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IPolicyProvider : IDataProvider
    {
        //get all policies
        IEnumerable<IPolicy<ICompliancePosition>> Get(PolicyFilter filter);
        IPolicy<ICompliancePosition> Get(string mame);
    }
}
