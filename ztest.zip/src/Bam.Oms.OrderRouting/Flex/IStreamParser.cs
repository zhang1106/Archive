﻿using System.Collections.Generic;
using Grpc.Core;

namespace Bam.Oms.OrderRouting.Flex
{
    /// <summary>
    /// Contract for parsing async streams
    /// </summary>
    public interface IStreamParser
    {
        /// <summary>
        /// Parses the Grpc stream and returns the first item.  Many of the flex api calls return a list, but are only a single response item
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="asynchCall"></param>
        /// <returns></returns>
        T ParseStreamReturnFirst<T>(AsyncServerStreamingCall<T> asynchCall) where T : class;

        /// <summary>
        /// Parses the Grpc stream and returns the entire enumerable list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="asynchCall"></param>
        /// <returns></returns>
        IEnumerable<T> ParseStream<T>(AsyncServerStreamingCall<T> asynchCall) where T : class;
    }
}