﻿using System;
using System.Linq;
using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Bam.Oms.Filtering;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class MessageFilterTests
    {
        [Test]
        public void VerifyItemNotFiltered()
        {
            // arrange
            var testOrder = new Order();
            testOrder.Portfolio = new Portfolio("QIAN", "GENERALIST");

            var filter = new OrderFilter();
            var filterParam = new Parameter() { Property = "Portfolio", Value = new Portfolio("QIAN", "GENERALIST") };

            var paramList = new ParameterBatch();
            paramList.Filters.Add(filterParam);

            filter.AddToFilter("test", paramList.Filters);

            // act
            var unit = filter.ApplyFilter(testOrder);

            // assert
            Assert.That(unit, Is.Not.Null);
            Assert.That(unit.Count(), Is.EqualTo(1));
        }

        [Test]
        public void VerifyItemFiltered()
        {
            // arrange
            var testOrder = new Order();
            testOrder.Portfolio = new Portfolio("COBI", "GENERALIST");

            var filter = new OrderFilter();
            var filterParam = new Parameter() { Property = "Portfolio", Value = new Portfolio("QIAN", "GENERALIST") };

            var paramList = new ParameterBatch();
            paramList.Filters.Add(filterParam);

            filter.AddToFilter("test", paramList.Filters);

            // act
            var unit = filter.ApplyFilter(testOrder);

            // assert
            Assert.That(unit, Is.Not.Null);
            Assert.That(unit.Count(), Is.EqualTo(0));
        }
        
        [Test]
        public void VerifyCompositeFilter()
        {
            // arrange
            var testOrder = new Order();
            testOrder.Portfolio = new Portfolio("QIAN", "GENERALIST", "sub");
            var filterParam1 = new Parameter() { Property = "Portfolio", Value = new Portfolio("QIAN", "GENERALIST") };
            var filterParam2 = new Parameter() { Property = "Portfolio", Value = new Portfolio("GREE", "GENERALIST") };
            var paramList = new List<Parameter>() { filterParam1, filterParam2 };

            var filter = new CompositeFilter<Order>();

            filter.AddToFilter("test", paramList, false, paramList, false);

            // act
            var unit = filter.ApplyFilter(testOrder);

            // assert
            Assert.That(unit, Is.Not.Null);
            Assert.That(unit.Count(), Is.EqualTo(1));
        }

        [Test]
        public void VerifyItemFilteredIsValueType()
        {
            // arrange
            var testOrder = new Order() { Size = 1.0m };

            var filter = new OrderFilter();
            var filterParam = new Parameter() { Property = "Size", Value = 1.0m };

            var paramList = new ParameterBatch();
            paramList.Filters.Add(filterParam);

            filter.AddToFilter("test", paramList.Filters);

            // act
            var unit = filter.ApplyFilter(testOrder);

            // assert
            Assert.That(unit, Is.Not.Null);
            Assert.That(unit.Count(), Is.EqualTo(1));
        }


        [Test]
        public void VerifyThatDecimalCanBeCastToIComparable()
        {
            var unit = 1.0m;

            Assert.DoesNotThrow(() => { var casted = (IComparable)unit; });

        }


        [Test]
        public void VerifyItemFilterRemoved()
        {
            // arrange
            var testOrder = new Order();
            testOrder.Portfolio = new Portfolio("COBI", "GENERALIST");

            var filter = new OrderFilter();
            var filterParam = new Parameter { Property = "Portfolio", Value = new Portfolio("QIAN", "GENERALIST") };

            var paramList = new ParameterBatch();
            paramList.Filters.Add(filterParam);

            filter.AddToFilter("test", paramList.Filters);

            // act
            filter.ClearFilter("test");
            var unit = filter.ApplyFilter(testOrder);

            // assert
            Assert.That(unit, Is.Not.Null);
            Assert.That(unit.Count(), Is.EqualTo(1));
        }

        [Test]
        public void VerifyItemFilterWithMultiplePredicates()
        {
            // arrange
            var testOrder = new Order();

            testOrder.Portfolio = new Portfolio("COBI", "GENERALIST");

            testOrder.Security = new Security();
            testOrder.Security.BamSymbol = "IBM";
            testOrder.Security.SecurityType = SecurityType.Equity;

            var testOrder0 = new Order();
            testOrder0.Portfolio = new Portfolio("COBI", "GENERALIST");
            testOrder0.Security = new Security();
            testOrder0.Security.BamSymbol = "AAPL";
            testOrder0.Security.SecurityType = SecurityType.Equity;

            var filter = new OrderFilter();
            var filterParam = new Parameter() { Property = "Portfolio", Value = new Portfolio("COBI", "GENERALIST") };
            var filterParam0 = new Parameter() { Property = "Security", Value = testOrder.Security };

            var paramList = new ParameterBatch();
            paramList.Filters.Add(filterParam);
            paramList.Filters.Add(filterParam0);

            filter.AddToFilter("test", paramList.Filters);

            // act
            var unit = filter.ApplyFilter(testOrder);

            // assert
            Assert.That(unit, Is.Not.Null);
            Assert.That(unit.Count(), Is.EqualTo(1));
        }

        [Test]
        public void VerifyExceptionThrowOnNullCriteria()
        {
            // arrange
            var filter = new OrderFilter();

            Assert.Throws<ArgumentNullException>(() => filter.AddToFilter("test", null));
        }

        [Test]
        public void VerifyNullCriteria()
        {
            // arrange
            var filter = new OrderFilter();

            var found = filter.ApplyFilter("test", new Order());

            Assert.Throws<ArgumentNullException>(() => filter.AddToFilter("test", null));
        }

        [Test]
        [TestCase(SecurityType.Equity, "Eq", OperatorType.StartsWith, true)]
        [TestCase(SecurityType.Equity, "IGO", OperatorType.StartsWith, false)]
        [TestCase(SecurityType.Equity, "qui", OperatorType.Contains, true)]
        [TestCase(SecurityType.Equity, "IG", OperatorType.Contains, false)]
        [TestCase(SecurityType.Equity, "iq", OperatorType.Contains, false)]
        public void VerifyItemFilteredWithStartswithContains(IComparable left, string right, OperatorType opType, bool result)
        {
            // arrange
            var security = new Security {  SecurityType = SecurityType.Equity};
            //
            var filter = new Filter<Security>();
            var filterParam = new Parameter() { Property = "SecurityType", Value = right, Operator = new Operator(){OperatorType= opType} };

            var paramList = new ParameterBatch();
            paramList.Filters.Add(filterParam);

            filter.AddToFilter("test", paramList.Filters);

            // act
            var unit = filter.ApplyFilter("test", security);
            // assert
            Assert.That(unit == result);
        }

        //test types
        private class OrderFilter : Filter<Order>
        {
        }
    }
}