﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;

namespace Bam.EventQ.SignalR
{
    public class SignalRSessionRepository : ISignalRSessionRepository
    {
        private readonly ConcurrentDictionary<string, IIdentity> _sessions;
        private readonly CasLock _publishingToken;

        public SignalRSessionRepository()
        {
            _sessions = new ConcurrentDictionary<string, IIdentity>();
            _publishingToken = new CasLock();
        }

        public void Add(string connectionId, IIdentity identity)
        {
            if (_sessions.TryAdd(connectionId, identity))
            {
                var handler = NewConnection;
                handler?.Invoke(connectionId);
            }
        }

        public void Remove(string connectionId)
        {
            IIdentity id;
            _sessions.TryRemove(connectionId, out id);
        }

        public IIdentity TryGet(string connectionId)
        {
            IIdentity id;
            _sessions.TryGetValue(connectionId, out id);
            return id;
        }

        public IReadOnlyList<string> GetAllConnectionIds()
        {
            return _sessions.Keys.ToList();
        }

        public event Action<string> NewConnection;

        public IDisposable AcquirePublishingToken()
        {
            return _publishingToken.Acquire();
        }
    }
}
