﻿using System.Collections.Generic;

namespace Bam.Oms.Persistence.Orders
{
    public interface IClientOrderIdRepository : IPersistentRepository<ClientOrderId>
    {
        /// <summary>
        /// Returns a list of order ids
        /// </summary>
        /// <param name="count">Number order ids to dispatch</param>
        /// <returns></returns>
        IList<string> GenerateOrderIds(int count);

        /// <summary>
        /// Resets the order id index back to the SOD value
        /// </summary>
        string ResetOrderIdIndex(int seed = 0);

        /// <summary>
        /// Takes an order id, and increments the version.  This is used when an order is split, it keeps the base order id the same, and adds a incremented version
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        string IncrementVersion(string orderId);
    }
}