﻿using Bam.Oms.Compliance.Results;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;
using Newtonsoft.Json;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class JsonSerializationTest
    {
        [Test]
        public void TestRuleResultSerialization()
        {
            var ruleResult = new OwnershipFilingResult()
            {
                PolicyId = 1,
                RuleName = "test",
                RuleId = 1,
                AlertLevel = ComplianceAlertLevel.NoDataAvaiable,
                Ratio = 0.5m,
            };

            var paramsInJson = JsonConvert.SerializeObject(ruleResult);
        }
        
    }
}
