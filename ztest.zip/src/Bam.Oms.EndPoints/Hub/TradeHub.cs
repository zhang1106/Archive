﻿using Bam.Oms.Data.Trades;
using Bam.Oms.Messaging;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;

namespace Bam.Oms.EndPoints.Hub
{
    public class TradeHub : PortfolioFilteredSignalRHub<BlockTrade>
    {
        public TradeHub(ISignalRSessions<BlockTrade> sessions, ILogger logger) : base(sessions, logger)
        {
        }

        public override IHubContext<ISignalRClient<SignalRPacket<BlockTrade>>> GetHubContext()
        {
            return GlobalHost.ConnectionManager.GetHubContext<TradeHub, ISignalRClient<SignalRPacket<BlockTrade>>>();
        }
     }
}