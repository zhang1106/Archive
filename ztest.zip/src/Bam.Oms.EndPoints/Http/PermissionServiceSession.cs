﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Bam.Oms.Data.Configuration;
using Bam.Oms.EndPoints.PermissionService;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.Http
{
    public static class PermissionServiceSession
    {
        private static readonly Dictionary<string, HashSet<string>> SessionPermission;
        public static readonly Dictionary<string, IList<StrategyInfo>> SessionStrategies;
        private static readonly ReaderWriterLockSlim LockSessionPermission = new ReaderWriterLockSlim();
        private static readonly ReaderWriterLockSlim LockSessionStrategies = new ReaderWriterLockSlim();


        static PermissionServiceSession()
        {
            SessionPermission = new Dictionary<string, HashSet<string>>(1000);
            SessionStrategies = new Dictionary<string, IList<StrategyInfo>>(1000);
        }

        public static void ResetPermissions(string userid)
        {
            LockSessionPermission.EnterWriteLock();
            try
            {
                if (SessionPermission.ContainsKey(userid))
                {
                    SessionPermission.Remove(userid);
                }
            }
            finally
            {
                LockSessionPermission.ExitWriteLock();
            }

            LockSessionStrategies.EnterWriteLock();
            try
            {
                if (SessionStrategies.ContainsKey(userid))
                {
                    SessionStrategies.Remove(userid);
                }
            }
            finally
            {
                LockSessionStrategies.ExitWriteLock();
            }
        }

        public static HashSet<string> GetPermissions(string userid)
        {
            LockSessionPermission.EnterReadLock();
            try
            {
                if (SessionPermission.ContainsKey(userid))
                {
                    return SessionPermission[userid];
                }
            }
            finally
            {
                LockSessionPermission.ExitReadLock();
            }

            using (var permissionService = Container.Instance.Resolve<IPermissionSvcClient>())
            {
                var apps = Container.Instance.Resolve<ISettings>().PermissionedApplications.Split(',');
                var permList = new HashSet<string>();
                foreach (var permissions in apps.Select(app => permissionService.GetPermissions(userid, app)))
                {
                    permList.UnionWith(permissions.Select(p => $"{p.PermissionPath}"));
                }

                LockSessionStrategies.EnterWriteLock();
                try
                {
                    SessionPermission.Add(userid, permList);
                }
                finally
                {
                    LockSessionStrategies.ExitWriteLock();
                }
                return permList;
            }
        }

        public static IList<StrategyInfo> GetStategies(string userid)
        {
            if (!PermissionChecker.IsPermissionEnabled())
            {
                var acctSvc = Container.Instance.Resolve<IAccountService>();
                var portfolios = acctSvc.GetAllPortfolios();
                return
                    portfolios.GroupBy(p => new { p.PMCode, p.Strategy })
                        .Select(p => new StrategyInfo() { StrategyCode = $"{p.Key.PMCode}-{p.Key.Strategy}" })
                        .ToList();
            }

            LockSessionPermission.EnterReadLock();
            try
            {
                if (SessionStrategies.ContainsKey(userid))
                {
                    return SessionStrategies[userid];
                }
            }
            finally
            {
                LockSessionPermission.ExitReadLock();
            }

            LockSessionPermission.EnterWriteLock();
            try
            {
                using (var permissionService = Container.Instance.Resolve<IPermissionSvcClient>())
                {
                    var strategiesInfos = permissionService.GetStrategies(userid);
                    SessionStrategies[userid] = strategiesInfos;
                    return strategiesInfos.ToList();
                }
            }
            finally
            {
                LockSessionPermission.ExitWriteLock();
            }
        }
    }
}
