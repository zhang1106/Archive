﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Bam.Oms.RefData.OMS;
using Bam.Oms.ReferenceDataGateway.Api.Http;
using Bam.Oms.ReferenceDataGateway.Api.Model;
using BAM.Infrastructure.Ioc;
using Portfolio = Bam.Oms.Data.Portfolios.Portfolio;
using SecurityType = Bam.Oms.Data.Enumerators.SecurityType;
using Bam.Oms.RefData.Eze;
using Castle.Components.DictionaryAdapter;
using EmsSystem = Bam.Oms.ReferenceDataGateway.Api.Model.EmsSystem;

namespace Bam.Oms.RefData
{
    public class AccountService : IAccountService
    {
        private readonly ReferenceDataGateway.Api.Http.IAccountController _accountService;
        private readonly ICoverageController _coverageController;
        private readonly ISqlConnectionWrapper _omsSqlConnectionWrapper;
        private readonly ILogger _logger;
        private List<TraderLogin> _allTradersTraderLogins;
        private IDictionary<OrderScaleKey, IList<OrderScale>> _orderScaleFactors;
        private readonly ConcurrentDictionary<string, Portfolio> _portfolios;
        private readonly ConcurrentDictionary<ManagerCodeLookupKey, ManagerCode> _defaultManagerCodes;
        private readonly object _managerCodeLock;

        public AccountService(ReferenceDataGateway.Api.Http.IAccountController accountService, 
            ReferenceDataGateway.Api.Http.ICoverageController coverageController, ISqlConnectionWrapper omsSqlConnectionWrapper, ILogger logger)
        {
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));
            if (coverageController == null) throw new ArgumentNullException(nameof(coverageController));
            if (omsSqlConnectionWrapper == null) throw new ArgumentNullException(nameof(omsSqlConnectionWrapper));
            if (logger == null) throw new ArgumentNullException(nameof(logger));

            _accountService = accountService;
            _coverageController = coverageController;
            _omsSqlConnectionWrapper = omsSqlConnectionWrapper;
            _logger = logger;
            _portfolios = new ConcurrentDictionary<string, Portfolio>(StringComparer.InvariantCultureIgnoreCase);
            _defaultManagerCodes = new ConcurrentDictionary<ManagerCodeLookupKey, ManagerCode>();
            _managerCodeLock = new object();
            CachePortfolio();
            CacheTraderLogins();
            RefreshOrderScaleFactors();
        }

        public IEnumerable<IContainsPortfolio> SetAccountAttributes(IEnumerable<IContainsPortfolio> items)
        {
            IList<IContainsPortfolio> enrichedItems = new List<IContainsPortfolio>();
            var uniquePorts = items.Select(r => r.Portfolio.ToString()).Distinct();
            var portfolios = _accountService.PostQueryMany(uniquePorts.ToArray());

            foreach (var item in items)
            {
                var portfolio = portfolios.FirstOrDefault(r => r.ToString() == item.Portfolio.ToString());

                if (string.IsNullOrWhiteSpace(portfolio?.ComplianceGroup) || string.IsNullOrWhiteSpace(portfolio.AggregationUnit))
                {
                    //throw new MissingPortfolioException(item.Portfolio);
                    _logger.Error($"Unknown portfolio requested from Account Master, {item.Portfolio}. Discarding {item}");
                    continue;
                }

                item.Portfolio.ComplianceGroup = portfolio.ComplianceGroup??item.Portfolio.PMCode;
                item.Portfolio.AggregationUnit = portfolio.AggregationUnit ?? item.Portfolio.PMCode;
                item.Portfolio.AllocationScheme = portfolio.AllocationScheme;
                item.Portfolio.OmsStream = portfolio.OmsStream;
                item.Portfolio.AutoSendToEms =(Data.Enumerators.AutoSendToEms) portfolio.AutoSendToEms;
                item.Portfolio.Oms = portfolio.Oms;

                enrichedItems.Add(item);
            }

            return enrichedItems;
        }

        public IList<Portfolio> GetPortfolioByPmCode(string pmCode = null)
        {
            var portfolios = _accountService.PostQueryManyByPmCode(new[] {pmCode});
            
            return portfolios.Any()?  new List<Portfolio>() { MapToLocalDomainModel(portfolios[0])} : new List<Portfolio>();
        }

        public Portfolio GetPortfolioByStrategy(string strategy)
        {
            Portfolio portfolio;

            if (!_portfolios.TryGetValue(strategy, out portfolio))
            {
                var lookup = _accountService.Get(strategy);
                if (lookup == null)
                {
                    portfolio = new Portfolio(strategy);
                    _logger.Error($"Unable to find portfolio details for strategy {strategy}.  Returning default portfolio");
                }
                else
                    portfolio = _portfolios[lookup.Key] = MapToLocalDomainModel(lookup);
            }

            return portfolio;
        }

        public IDictionary<string, bool> IsValidStrategy(IList<string> strategies)
        {
            return _accountService.PostValidateStrategy(strategies);
        }

        public string GetManagerCode(IPortfolio portfolio, string currency,string broker = null)
        {
            return GetManagerBrokerMap(portfolio.ToString(), currency, broker).Code;
        }

        public string GetFlexTraderCode(IPortfolio portfolio, ISecurity security)
        {
            var coverage =  _coverageController.GetTraderCoverage(portfolio.PMCode, security.Currency, AssetType.Equity);
            return coverage.FlexId;
        }

        private Portfolio MapToLocalDomainModel(ReferenceDataGateway.Api.Model.Portfolio apiPortfolio)
        {
            var portfolio = (Portfolio)Portfolio.Parse(apiPortfolio.ToString());
            portfolio.AggregationUnit = apiPortfolio.AggregationUnit;
            portfolio.ComplianceGroup = apiPortfolio.ComplianceGroup;
            portfolio.OmsStream = apiPortfolio.OmsStream;
            portfolio.Oms = apiPortfolio.Oms;
            return portfolio;
        }

        private void CachePortfolio()
        {
            var all = _accountService.Get();
            foreach (var portfolio in all)
            {
                _portfolios[portfolio.Key] = MapToLocalDomainModel(portfolio);
            }
        }

        public IList<Portfolio> GetAllPortfolios()
        {
            return _accountService.Get().Select(MapToLocalDomainModel).ToList();
        }

        public void RefreshOrderScaleFactors()
        {
            var orderScaleList = _omsSqlConnectionWrapper.Execute<OrderScale>(OmsQueries.SelectScaling).ToList();
            IDictionary<OrderScaleKey, IList<OrderScale>> orderScaleFactors = new Dictionary<OrderScaleKey, IList<OrderScale>>();
            foreach (OrderScale orderScale in orderScaleList)
            {
                IList<OrderScale> val;
                OrderScaleKey osKey = new OrderScaleKey(Portfolio.Parse(orderScale.SourcePortfolio), Utility.ConvertEnum<SecurityType>(orderScale.SecurityType));
                if (!orderScaleFactors.TryGetValue(osKey, out val))
                {
                    val = new List<OrderScale>();
                    orderScaleFactors.Add(osKey, val);
                }
                val.Add(orderScale);
            }
            Interlocked.Exchange(ref _orderScaleFactors, orderScaleFactors);

        }

        public IList<OrderScale> GetScaleFactor(IPortfolio portfolio, SecurityType securityType)
        {
            OrderScaleKey key = new OrderScaleKey(portfolio, securityType);
            IList<OrderScale> scaleFactors;
            if (!_orderScaleFactors.TryGetValue(key, out scaleFactors))
            {
                scaleFactors = new List<OrderScale>();
            }
            key = new OrderScaleKey(portfolio, SecurityType.Unknown);

            IList<OrderScale> wcScaleFactors;
            if (_orderScaleFactors.TryGetValue(key, out wcScaleFactors))
            {
                scaleFactors = scaleFactors.Union(wcScaleFactors).ToList();
            }
            return scaleFactors;
        }

        public string GetEzeTraderCode(int traderId)
        {
            var matchingTraderLogin = _allTradersTraderLogins.FirstOrDefault(r => r.Id == traderId);
            return matchingTraderLogin?.EzeId;
        }

        public string GetFlexTraderCode(int traderId)
        {
            return _coverageController.GetFlexTraderCode(traderId);
        }

        public bool IsValidTrader(string login)
        {
            return _allTradersTraderLogins.Any(r => r.ADLogin.Equals(login, StringComparison.InvariantCultureIgnoreCase));
        }

        public void SetTraderLogin(IOrder order)
        {
            var system = string.Compare(order.Portfolio.Oms, "EZE", StringComparison.InvariantCultureIgnoreCase) == 0
                ? EmsSystem.Eze
                : EmsSystem.Flex;

            _logger.Info($"[OrderId:{order.ClientOrderId}] Looking up trader login for trader code {order.Trader} and system {system}");

            var traderLogin = _allTradersTraderLogins.FirstOrDefault(r => system == EmsSystem.Eze ? r.EzeId == order.Trader : r.FlexId == order.Trader);

            if (traderLogin != null)
            {
                order.TraderLogin = traderLogin.ADLogin;
                order.TraderId = traderLogin.Id;
                _logger.Info($"[OrderId:{order.ClientOrderId}] TraderLogin found {traderLogin.ADLogin}:{traderLogin.Id}");
            }
            else
            {

                _logger.Error($"[OrderId:{order.ClientOrderId}] TraderLogin not found {order.Trader}:{system}");
            }
        }

        public void SetCustodian(IOrder order)
        {
            var custodian = GetManagerBrokerMap(order.Portfolio.ToString(), order.Security.Currency).Broker;

            if (string.IsNullOrEmpty(custodian))
            {
                var errorMsg = $"Unable to find default custodian mapping for strategy {order.Portfolio?.Key}, currency {order.Security?.Currency}";
                _logger.Error(errorMsg);
                order.OrderStatus = BamOrderStatus.Error;
                order.StatusMessages.Add(errorMsg);
            }
            else
            {
                order.Custodian = custodian;
            }
        }

        private ManagerCode GetManagerBrokerMap(string strategy, string currency, string broker = null)
        {
            lock (_managerCodeLock)
            {
                var key = new ManagerCodeLookupKey() {Broker = broker, Currency = currency, Strategy = strategy};
                ManagerCode code;
                if (_defaultManagerCodes.TryGetValue(key, out code))
                {
                    return code;
                }

                var associatedBroker = broker ?? _accountService.GetCustodian(strategy, currency);

                var missingManagerCode = _accountService.GetManagerCode(strategy, currency, associatedBroker);
                code = new ManagerCode() {Broker = associatedBroker, Code = missingManagerCode};

                _defaultManagerCodes[key] = code;

                return code;
            }
        }

        private void CacheTraderLogins()
        {
            _allTradersTraderLogins = _coverageController.GetAllTraderLogins().ToList();
        }

    }

    public struct ManagerCodeLookupKey : IEquatable<ManagerCodeLookupKey>
    {
        public string Strategy { get; set; }
        public string Broker { get; set; }
        public string Currency { get; set; }

        public bool Equals(ManagerCodeLookupKey other)
        {
            return Strategy == other.Strategy && Broker == other.Broker && Currency == other.Currency;
        }
    }

    public struct ManagerCode
    {
        public string Code { get; set; }
        public string Broker { get; set; }
    }
}