﻿using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Sequencing
{
    public class MessageDeserializerHandler : IQueueItemHandler<PipelineQueueItem<IMessage>>
    {
        public void Handle(PipelineQueueItem<IMessage> item, long sequence, bool endOfBatch)
        {
            if (item.IsValid)
            {
                var message = MessageSerializer.Current.Deserialize(item.Buffer.Array, item.Buffer.Offset, item.Length);
                item.SetPayload(message);
            }
        }
    }
}
