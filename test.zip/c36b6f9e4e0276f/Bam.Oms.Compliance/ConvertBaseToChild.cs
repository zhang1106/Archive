﻿using System;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance
{
    public class ConvertBaseToChild
    {
        /// <summary>
        /// Create a new object which type is defined by item.Type. 
        /// All the writable properpies will get the same value from source item.
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public static object Map(IExtensible item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            Type targetType = Type.GetType(item.Type);

            var target = BAM.Infrastructure.Ioc.Container.Instance.Resolve(targetType);

            foreach(var p in item.GetType().GetProperties())
            {
                var targetProperty = targetType.GetProperty(p.Name);
                if(targetProperty != null && targetProperty.CanWrite)
                {
                    targetProperty.SetValue(target, p.GetValue(item));
                }
            }

            return target;
        }
    }
}
