﻿using System;
using Grpc.Core.Logging;

namespace Bam.Oms.OrderRouting.Flex
{
    public class GrpcLogger : ILogger
    {
        private readonly BAM.Infrastructure.Ioc.ILogger _logger;

        public GrpcLogger(BAM.Infrastructure.Ioc.ILogger logger)
        {
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            _logger = logger;
        }

        public ILogger ForType<T>()
        {
            return this; //dont care we'll use the same logger regardless of type
        }

        public void Debug(string message)
        {
            _logger.Debug(message);
        }

        public void Debug(string format, params object[] formatArgs)
        {
            _logger.DebugFormat(format, formatArgs);
        }

        public void Info(string message)
        {
            _logger.Info( message);
        }

        public void Info(string format, params object[] formatArgs)
        {
            _logger.InfoFormat(format, formatArgs);
        }

        public void Warning(string message)
        {
            _logger.Warn(message);
        }

        public void Warning(string format, params object[] formatArgs)
        {
            _logger.WarnFormat(format, formatArgs);
        }

        public void Warning(Exception exception, string message)
        {
            _logger.Warn(message, exception);
        }

        public void Error(string message)
        {
            _logger.Error(message);
        }

        public void Error(string format, params object[] formatArgs)
        {
            _logger.ErrorFormat(format, formatArgs);
        }

        public void Error(Exception exception, string message)
        {
            _logger.Error(message, exception);
        }
    }
}