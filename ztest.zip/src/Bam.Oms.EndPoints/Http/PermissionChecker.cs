﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Security.Principal;
using System.Web.Http;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.EndPoints.PermissionService;
using Bam.Oms.Filtering;
using BAM.Infrastructure.Ioc;
using Microsoft.Owin;

namespace Bam.Oms.EndPoints.Http
{
    public class PermissionChecker : IPermissionChecker
    {
        public PermissionChecker(HttpConfiguration config)
        {
            Config = config;
        }
        public HttpConfiguration Config { get; }

        public bool IsAllowed(IOwinRequest request)
        {
            var logger = Container.Instance.Resolve<ILogger>();
            var setting = Container.Instance.Resolve<ISettings>();
            var enablePermission = IsPermissionEnabled();
            var allowAnonymous = AllowAnonymous(request.Uri.AbsoluteUri);
            //logger.Debug($"Permission Enabled: {enablePermission}, Allow Anonymous:{allowAnonymous} for URL{request.Uri.AbsoluteUri}");

            if (!enablePermission || allowAnonymous ) return true;

            var user = GetUserId(request.User.Identity);
            logger.Info($"Received request from:{user}");

            string controller;
            string action;
            GetActionInfo(request, out controller, out action);
            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(controller) || string.IsNullOrEmpty(action))
                return true;
            var requiredPrivileges = GetActionPrivilege(controller, action);
            //not enabled permission, let go now 
            if (requiredPrivileges == null) return true;
            var privileges = requiredPrivileges as string[] ?? requiredPrivileges.ToArray();
            if (!privileges.Any()) return true;

            return privileges.Any(p => PermissionServiceSession.GetPermissions(user).Contains(p));
        }

        public static string GetUserId(IIdentity identity)
        {
            try
            {
                var user = identity?.Name;
                if (string.IsNullOrEmpty(user))
                {
                    return null;
                }
                user = user.Remove(0, user.IndexOf(@"\", StringComparison.CurrentCultureIgnoreCase) + 1);
                return user;
            }
            catch (Exception ex)
            {
                var logger = Container.Instance.Resolve<ILogger>();
                logger.Error(ex.Message);
                return null;
            }
        }

        public static IEnumerable<string> GetActionPrivilege(string controller, string action)
        {
            //support case insensitive only
            var methodInfo = Assembly.GetExecutingAssembly().GetTypes()
                .Where(t => string.Compare(t.Name, controller, StringComparison.InvariantCultureIgnoreCase) == 0
                            && typeof(ApiController).IsAssignableFrom(t))
                .SelectMany(
                    type =>
                        type.GetMethods(BindingFlags.Public | BindingFlags.Instance)
                            .Where(a => string.Compare(action, a.Name, StringComparison.InvariantCultureIgnoreCase) == 0)
                ).ToArray();

            if (methodInfo.Length == 0) return null;
            var privilege = methodInfo[0].GetCustomAttributes().FirstOrDefault(a => a.GetType() == typeof(AccessRequireAttribute));

            return (privilege as AccessRequireAttribute)?.Privileges;
        }

        public void GetActionInfo(IOwinRequest request, out string controller, out string action)
        {
            try
            {
                var actionInfo = Config.Routes.GetRouteData(new HttpRequestMessage(HttpMethod.Get, request.Uri));
                controller = $"{actionInfo.Values["controller"]}Controller"; //append controller
                action = actionInfo.Values["Action"].ToString();
            }
            catch (Exception)
            {
                controller = null;
                action = null;
            }
        }

        public static StrategyInfo[] GetSupportedStrategyInfos()
        {
            var nameValueCollection = ConfigurationManager.GetSection("PortfolioToTraderMap") as NameValueCollection;
            if (nameValueCollection == null) return new StrategyInfo[] { };

            return nameValueCollection.AllKeys.Select(p => new StrategyInfo() { StrategyCode = p }).ToArray();
        }

        public static StrategyInfo[] GetPermissionedStrategies(IIdentity identity)
        {
            var user = GetUserId(identity);

            var permissioned = PermissionServiceSession.GetStategies(user);

            var strategyInfos = permissioned as StrategyInfo[] ?? permissioned.ToArray();

            return strategyInfos;
        }
        
        public static bool IsPermissionEnabled()
        {
            var setting = Container.Instance.Resolve<ISettings>();
            return "YES".Equals(setting.EnablePermission);
        }

        public static bool AllowAnonymous(string absoluteUri)
        {
            var setting = Container.Instance.Resolve<ISettings>();
            return setting.AnonymousUrls.Any(a=>absoluteUri.IndexOf(a, StringComparison.CurrentCultureIgnoreCase)>=0);
        }
    }
}