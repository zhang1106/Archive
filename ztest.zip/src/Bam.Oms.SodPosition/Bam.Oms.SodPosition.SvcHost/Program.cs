﻿using Microsoft.Owin.Hosting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.SodPosition.SvcHost
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            if (args.Length > 0 && args[0].Trim().ToUpperInvariant() == "-D")
            {
                Console.WriteLine("Wcf Service Host");

                // Start all services
                WcfServiceHostContainer container = new WcfServiceHostContainer();
                container.StartServices();

                Console.WriteLine("Hosting the following services:");
                string[] names = container.GetHostedServiceNames();

                foreach (string name in names)
                {
                    Console.WriteLine("Service: " + name);
                }

                Console.WriteLine("Press <Enter> to close.");
                Console.ReadLine();

                // Stop all services
                container.StopServices();
            }
            else if(args.Length > 0 && args[0].Trim().ToUpperInvariant() == "-R")
            {
                Console.WriteLine("Hosting RESTful services");
                string baseAddress = ConfigurationManager.AppSettings["web-api-base-address"];
                if(string.IsNullOrWhiteSpace(baseAddress))
                {
                    throw new Exception("Can't find the base address to host Web Api service; please set web-api-base-address in the config");
                }

                // Start OWIN host 
                using (WebApp.Start<Startup>(url: baseAddress))
                {
                    Console.WriteLine(string.Format("Service hosted at {0}", baseAddress));
                    Console.ReadLine();
                }

            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[]
                {
                    new SvcHost()
                };
                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}
