﻿using BAM.Infrastructure.Ioc;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Services;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Compliance;
using Bam.Compliance.Infrastructure.Logger;
using Bam.Oms.Compliance.File;
using Bam.Oms.Compliance.ServiceBroker;


namespace Bam.Oms.Compliance
{
    public class TypeRegtistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            Container.Instance.RegisterType<ISvcUtil, SvcUtil>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IJsonDataProvider, JsonDataProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<ISecurityProvider, DwSecurityProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IPolicyProvider, PolicyProvider>(RegistrationType.Singleton);
            
            Container.Instance.RegisterType<IHoldingProvider, HoldingProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IPositionProvider, PositionProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<ICustomDataProvider, CustomDataProvider>(RegistrationType.Singleton);

            Container.Instance.RegisterType<IMarketDataProvider, MarketDataProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IBbMarketDataProvider, BbMarketDataProvider>(RegistrationType.Singleton);
            
            Container.Instance.RegisterType<IDwRepository, DwRepository>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IOgDataRepository, OgDataRepository>(RegistrationType.Singleton);
            
            Container.Instance.RegisterType<ICompositeDecomposer, CompositeDecomposer>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IPositionCalculator, PositionCalculator>(RegistrationType.Singleton);
           
            Container.Instance.RegisterType<IHelper, Helper>(RegistrationType.Singleton);
            
            Container.Instance.RegisterType<IPositionSvc, PositionSvc>(RegistrationType.Singleton);
            
            Container.Instance.RegisterType<IOwnershipRuleResultProvider, OwnershipRuleResultProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IRuleResultProvider, OwnershipRuleResultProvider>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IEngine<ICompliancePosition>, FirmPositionComplianceEngine>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IFactProvider, FactProvider>(RegistrationType.Singleton);

            Container.Instance.RegisterType<IRuleRepository<ICompliancePosition>, RuleRepository<ICompliancePosition>>(RegistrationType.Singleton);
            Container.Instance.RegisterType<IPolicyRepository<ICompliancePosition>, PolicyRepository<ICompliancePosition>>(RegistrationType.Singleton);
            
            Container.Instance.RegisterType<IHeadRoomCalculator, HeadRoomCalculator>(RegistrationType.Singleton);
            
            Container.Instance.RegisterType<IFirmPositionComplianceSvc, FirmPositionComplianceSvc>(RegistrationType.Singleton);

            Container.Instance.RegisterType<IServiceBrokerListener, SqlDependencyListener>(RegistrationType.Singleton, "AQTF");
            Container.Instance.RegisterType<IServiceBrokerListener, SqlDependencyListener>(RegistrationType.Singleton, "MAIN");
            Container.Instance.RegisterType<IServiceBrokerListener, SqlDependencyListener>(RegistrationType.Singleton, "AQTFEod");
            Container.Instance.RegisterType<IServiceBrokerListener, SqlDependencyListener>(RegistrationType.Singleton, "MAINEod");

            Container.Instance.RegisterType<ICompliancePosition, CompliancePosition>(RegistrationType.Transient);
            Container.Instance.RegisterType<IRuleRepository<CompliancePosition>, RuleRepository<CompliancePosition>>(RegistrationType.Singleton);
        }
    }
}
