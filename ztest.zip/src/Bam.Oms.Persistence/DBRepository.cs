﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using System.Configuration;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Persistence.Utility;
using Bam.Oms.Data;
using System.Threading.Tasks;
using Bam.Oms.Data.Configuration;

namespace Bam.Oms.Persistence
{
    /// <summary>
    /// Abstract implementation of IDBRepository using Dapper
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class DBRepository<T> : IDBRepository<T> where T : IPersistentItem
    {
        protected readonly ILogger _log;

        // Use case : To support excluding columns (eg : Key) if not present in DB
        // Subclasses will define this predicate.
        protected Func<string, bool> _includeColumnPredicate = (column => true);

        #region Private fields
        private readonly String _schemaName;
        private readonly String _tableName;
        private readonly String _idColumnName;
        private readonly Func<dynamic, T> _resultMap;
        private readonly Func<T, dynamic> _parameterMap;
        private readonly ISettings _settings;
        #endregion

        protected virtual IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_settings.OrderGatewayConnectionString);
            }
        }

        #region Constructors
        protected DBRepository(ISettings settings, ILogger logger, String tableName) : this(settings, logger, null, tableName)
        { }

        protected DBRepository(ISettings settings, ILogger logger, String schemaName, String tableName) : this(settings, logger, schemaName, tableName, null, null)
        { }

        protected DBRepository(ISettings settings, ILogger logger, String tableName, Func<dynamic, T> resultMap, Func<T, dynamic> parameterMap)
            : this(settings, logger, null, tableName, null, resultMap, parameterMap)
        { }

        protected DBRepository(ISettings settings, ILogger logger, String schemaName, String tableName, Func<dynamic, T> resultMap, Func<T, dynamic> parameterMap)
            : this(settings, logger, schemaName, tableName, null, resultMap, parameterMap)
        { }

        protected DBRepository(ISettings settings, ILogger logger, String schemaName, String tableName, String idColumnName, Func<dynamic, T> resultMap, Func<T, dynamic> parameterMap)
        {
            this._log = logger;
            this._schemaName = (String.IsNullOrWhiteSpace(schemaName) ? "dbo" : schemaName);
            this._tableName = tableName;
            this._idColumnName = (String.IsNullOrWhiteSpace(idColumnName) ? tableName + "Id" : _idColumnName);
            this._resultMap = resultMap;
            this._parameterMap = parameterMap;
            this._settings = settings;
        }
        #endregion

        #region Parameter Mapping logic
        /// <summary>
        /// Maps Object properties to DB Columns
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        private dynamic Mapping(T item)
        {
            return _parameterMap != null ? _parameterMap(item) : item;
        }

        private IList<dynamic> Mapping(IList<T> items)
        {
            List<dynamic> mapped = new List<dynamic>();
            foreach (var item in items)
            {
                try
                {
                    mapped.Add((Mapping(item)));
                }
                catch (Exception ex)
                {
                    _log.Error((item.ToString() + ex.Message));
                    throw;
                }
            }
            return items.Select(Mapping).ToList();
        }
        #endregion

        #region Helper Method
        protected String FullyQualifiedTableName
        {
            get
            {
                return _schemaName + "." + _tableName;
            }
            
        }
        #endregion

        #region Implementation of IRepository methods

        public virtual void Update(T item)
        {
            var parameters = (object)Mapping(item);
            string sql = DynamicQuery.GetUpdateQuery(FullyQualifiedTableName, _idColumnName, parameters, _includeColumnPredicate);

            try
            {
                using (IDbConnection cn = Connection)
                {
                    cn.Open();
                    cn.Execute(sql, parameters);
                }
            }
            catch (Exception e)
            {
                string errorMessage =
                    $"Error occurred while performing Update operation on table {FullyQualifiedTableName}\nQuery : {sql}\nParams : {parameters}";
                _log.Error(errorMessage, e);
                throw;
            }
        }

        public virtual T Save(T item)
        {
            T result;

            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();
                    result = connection.Insert<T>(FullyQualifiedTableName, _idColumnName, (object)Mapping(item), _includeColumnPredicate, _resultMap);
                }
            }
            catch (Exception e)
            {
                string errorMessage = $"Error occurred while Inserting a record into table {FullyQualifiedTableName}";

                _log.Error(errorMessage, e);
                throw;
            }
            return result;
        }

        public virtual IEnumerable<T> Save(IEnumerable<T> items)
        {
            IEnumerable<T> results;
            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();
                    results = connection.InsertRange<T>(FullyQualifiedTableName, _idColumnName, Mapping(items.ToList()), _includeColumnPredicate, _resultMap);
                }
            }
            catch (Exception e)
            {
                string errorMessage = $"Error occurred while Inserting records into table {FullyQualifiedTableName}";

                _log.Error(errorMessage, e);
                throw;
            }
            return results;
        }

        public void Clear(T item)
        {
            string sql = $"DELETE FROM {FullyQualifiedTableName} WHERE {_idColumnName}=@ID";
            var param = new
            {
                ID = item.GetType().GetProperty(_idColumnName).GetValue(item, null)
            };

            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();
                    connection.Execute(sql, param);
                }
            }
            catch (Exception e)
            {
                string errorMessage =
                    $"Error occurred while deleting a record from table {FullyQualifiedTableName}\nQuery : {sql}\nParams : {param}";
                _log.Error(errorMessage, e);
                throw;
            }
        }

        private IEnumerable<T> GetRecords(string sql, object param)
        {
            IEnumerable<T> result = null;
            try
            {
                using (IDbConnection cn = Connection)
                {
                    cn.Open();
                    if (_resultMap == null)
                    {
                        result = cn.Query<T>(sql, (object)param);
                    }
                    else
                    {
                        result = cn.Query<dynamic>(sql, (object)param).Select(_resultMap);
                    }
                }
            }
            catch (Exception e)
            {
                string errorMessage =
                    $"Error occurred while retrieving records from table {FullyQualifiedTableName}\nQuery : {sql}\nParams : {param}";
                _log.Error(errorMessage, e);
                throw;
            }
            return result;
        }

        public T GetById(int id)
        {
            string sql = $"SELECT * FROM {FullyQualifiedTableName} WHERE {_idColumnName}=@ID";
            return GetRecords(sql, new { ID = id }).SingleOrDefault();
        }

        public IEnumerable<T> Get(string query, object param)
        {
            var queryBuilder = "SELECT * FROM {0} ";
            string sql;
            if (string.IsNullOrWhiteSpace(query))
            {
                sql = string.Format(queryBuilder.ToString(), FullyQualifiedTableName);
            }
            else
        {
                sql = string.Format(queryBuilder + " WHERE {1} ", FullyQualifiedTableName, query);
            }
            return GetRecords(sql, param);
        }

        public IEnumerable<T> Get(dynamic param)
        {
            if (param is string)
            {
                IList<T> returnValue = new List<T>();
                returnValue.Add(this.Get((string)param));
                return returnValue;
            }
            else if (param is DateTime)
            {
                return this.Get((DateTime) param);
            }
            return Get(DynamicQuery.GetWhereQuery(param), param);
        }

        public IEnumerable<T> GetAll()
        {
            string sql = $"SELECT * FROM {FullyQualifiedTableName}";
            return GetRecords(sql, null);
        }
        #endregion

        #region IRepository
        public virtual T Get(string key)
        {
            return Get(new { Key = key }).FirstOrDefault();
        }

        public virtual IEnumerable<T> Get(DateTime cutoffTimeUtc)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<T>> SaveAsync(IEnumerable<T> items)
        {
            IList<T> savedItems = new List<T>(await Task.Factory.StartNew(() => this.Save(items)));
            return savedItems;
        }

        public async Task<T> SaveAsync(T item)
        {
           return  await Task.Factory.StartNew(() => this.Save(item));            
        }

        public virtual int Clear(DateTime cutOffTimeUtc)
        {
            throw new NotImplementedException();
        }

        public virtual int ClearAll()
        {
            throw new NotImplementedException();
        }

        public virtual IEnumerable<T> Remove(IEnumerable<T> items)
        {
            throw new NotImplementedException();
        }

        public virtual T Remove(T item)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
        {
                    // TODO: dispose managed state (managed objects).
        }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~DBRepository() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
