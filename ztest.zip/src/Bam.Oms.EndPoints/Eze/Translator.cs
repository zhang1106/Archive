﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Eze.Common.Integration;
using System.Web.Script.Serialization;
using BP = Bam.Oms.Data.Portfolios;

namespace Bam.Oms.EndPoints.Eze
{
    public  class Translator : ITranslator
    {
        public  IList<Trade> GetTrades(string jsonUpdate)
        {
            var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(jsonUpdate);

            if (dict["Trades"] != null)
            {
                var ary = dict["Trades"];
                var tradeList = PopTrades(ary as ArrayList);
                return tradeList;
            }

            if (dict["trade"] == null) return null;
            {
                var tradeList = PopTrades(new ArrayList { dict["trade"] });
                return tradeList;
            }
        }

        private static List<Trade> PopTrades(IEnumerable tradeCollection)
        {
            var trades = new List<Trade>();
            foreach (var trade in tradeCollection)
            {
                var trd = new Trade();
                var dic = (Dictionary<string, object>)trade;
                if (dic["allocations"] != null)
                {
                    trd.Allocations = TranslateAllocations((ArrayList)dic["allocations"]);
                }
                if (dic["orders"] != null)
                {
                    trd.Orders = GetOrders((ArrayList)dic["orders"]);
                }
                trd.ExternalBlockID = (string)dic["ExternalBlockID"];
                trd.MessageType = (string)dic["MessageType"];
                trd.TradeId = (string)dic["TradeId"];
                trd.OriginalTradeId = (string)dic["OriginalTradeId"];
                trd.TradeIndex = Convert.ToDateTime((string)dic["TradeIndex"]);
                trd.Action = (TradeAction)dic["Action"];
                trd.Quantity = GetDecimal(dic["Quantity"]);
                trd.Symbol = (string)dic["Symbol"];
                trd.TraderCode = (string)dic["TraderCode"];
                trd.TradeDate = Convert.ToDateTime((string)dic["TradeDate"]);
                trd.SettleDate = Convert.ToDateTime((string)dic["SettleDate"]);
                trd.ExternalListID = (string)dic["ExternalListID"];
                trd.Duration = (Duration)dic["Duration"];
                trd.LimitPrice = GetDecimal(dic["LimitPrice"]);
                trd.TimeInForce = (string)dic["TimeInForce"];
                trd.ComplianceCheck = (bool)dic["ComplianceCheck"];
                trd.TradeEntrySource = (string)dic["TradeEntrySource"];
                trd.Note = (string)dic["Note"];
                trd.Manager = (string)dic["Manager"];
                trd.EnableAutoEx = (bool)dic["EnableAutoEx"];
                trd.TradeAlpha2 = (string)dic["TradeAlpha2"];
                trd.Trader = (string)dic["Trader"];
                trd.Status = (string)dic["Status"];
                trd.Committed = GetDecimal(dic["Committed"]);
                trd.Done = GetDecimal(dic["Done"]);
                trd.Leaves = GetDecimal(dic["Leaves"]);
                trd.AvgPrice = GetDecimal(dic["AvgPrice"]);
                trd.State = (string)dic["State"];
                trd.RTBlotterTimeStamp = Convert.ToDateTime((string)dic["RTBlotterTimeStamp"]);

                trd.UserDefinedFields = (dic["UserDefinedFields"] != null ? ConvertToStringArray(((ArrayList)dic["UserDefinedFields"])) : new[] { string.Empty });

                if (trades.FirstOrDefault(x => x.TradeId == trd.TradeId) == null)
                    trades.Add(trd);
            }

            return trades;
        }

        public IList<Allocation> GetAllocations(string jsonUpdate)
        {
            var dict = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(jsonUpdate);

            if (dict["AllocationListByTrade"] == null) return null;
            {
                var allocationList = dict["AllocationListByTrade"] as ArrayList;
                var list = new ArrayList();
                foreach (var tAlloc in allocationList)
                {
                    var x = tAlloc as Dictionary<string, object>;
                    list.AddRange(x["Allocations"] as ArrayList);
                }
                var rList = TranslateAllocations(list);
                return rList;
            }
        }

        private static List<Allocation> TranslateAllocations(IEnumerable allocations)
        {
            var allocs = new List<Allocation>();
            foreach (var alloc in allocations)
            {
                var all = new Allocation();
                var dic = (Dictionary<string, object>)alloc;

                all.MessageType = (string)dic["MessageType"];
                all.Account = (string)dic["Account"];
                //all.AccuredInterest = (decimal)dic["AccuredInterest"];
                all.ExternalBlockID = (string)dic["ExternalBlockID"];
                all.ExternalOrderID = (string)dic["ExternalOrderID"];
                all.AllocationState = (AllocationState)dic["AllocationState"];
                all.AveragePrice = GetDecimal(dic["AveragePrice"]);
                all.Filled = GetDecimal(dic["Filled"]);
                all.Quantity = GetDecimal(dic["Quantity"]);
                all.Broker = (string)dic["Broker"];
                all.BrokerOfCredit = (string)dic["BrokerOfCredit"];
                all.Custodian = (string)dic["Custodian"];
                all.OrderID = (string)dic["OrderID"];
                all.DirectedBroker = (string)dic["DirectedBroker"];
                all.ExternalAllocID = (string)dic["ExternalAllocID"];
                all.FromCurrency = (string)dic["FromCurrency"];
                all.NetMoney = GetDecimal(dic["NetMoney"]);
                all.TradeID = (string)dic["TradeID"];
                //all.SpotRate = (decimal)dic["SpotRate"];
                all.StepOutBroker = (string)dic["StepOutBroker"];
                all.StepOutCommissions = (string)dic["StepOutCommissions"];
                var idx = all.Account?.LastIndexOf(" "); //EZE DATA:BAM-FIRM HEDGE GS-ALMF
                all.Strategy = (!idx.HasValue || idx == -1) ? all.Account : all.Account.Substring(0, idx.Value);
                all.ToCurrency = (string)dic["ToCurrency"];
                all.TotalCommission = GetDecimal(dic["TotalCommission"]);
                all.TotalFees = GetDecimal(dic["TotalFees"]);
                all.AllocID = Convert.ToInt64(dic["AllocID"]);
                all.RTBlotterTimeStamp = Convert.ToDateTime((string)dic["RTBlotterTimeStamp"]);

                allocs.Add(all);
            }
            return allocs;
        }

        private static decimal GetDecimal(object data)
        {
            if (data == null) return 0;
            decimal result;
            return decimal.TryParse(data.ToString(), out result) ? result : 0;
        }

        public static List<Order> GetOrders(ArrayList orderCollection)
        {
            var orders = new List<Order>();
            foreach (var order in orderCollection)
            {
                var ord = new Order();
                var dic = (Dictionary<string, object>)order;

                ord.CommissionCode = (string)dic["CommissionCode"];
                ord.CommissionValue = Convert.ToDecimal(dic["CommissionValue"] ?? "0");
                ord.ExternalBlockID = (string)dic["ExternalBlockID"];
                ord.ExecutingBrokerCode = (string)dic["ExecutingBrokerCode"];
                ord.ExternalOrderID = (string)dic["ExternalOrderID"];
                ord.FeeCode = (string)dic["FeeCode"];
                ord.FeeValue = Convert.ToDecimal(dic["FeeValue"] ?? "0");
                ord.Quantity = Convert.ToDecimal(dic["Quantity"] ?? "0");
                ord.Limit = Convert.ToDecimal(dic["Limit"] ?? "0");
                ord.LocateID = (string)dic["LocateID"];
                ord.LocateRefID = (string)dic["LocateRefID"];
                ord.OrderID = (string)dic["OrderID"];
                ord.OrderType = (string)dic["OrderType"];
                ord.Duration = (Duration)dic["Duration"];
                ord.OriginalOrderID = (string)dic["OriginalOrderID"];
                ord.SettleCurrency = (string)dic["SettleCurrency"];
                ord.TradeID = (string)dic["TradeID"];
                ord.Note = (string)dic["Note"];

                if (orders.FirstOrDefault(x => x.OrderID == ord.OrderID) == null)
                    orders.Add(ord);
            }

            return orders;
        }

        private static string[] ConvertToStringArray(IEnumerable arrayList)
        {
            return (from object udf in arrayList select udf.ToString()).ToArray();
        }

    }
}

 
