﻿using System.Collections;
using System.Collections.Generic;

namespace Bam.EventQ.Lookup
{
    public abstract class LookupList<T> : IReadOnlyCollection<T>
    {
        protected LookupList()
        {
            List = new HashSet<T>();
        }

        public HashSet<T>.Enumerator GetEnumerator()
        {
            return List.GetEnumerator();
        }

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            return List.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return List.GetEnumerator();
        }

        public int Count => List.Count;
        protected HashSet<T> List { get; }

        public static readonly LookupList<T> Empty = new MutableLookupList<T>();
    }
}
