﻿using BAM.Infrastructure.Ioc;

namespace Bam.Oms.TradeMarker
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            container.RegisterType<IOrderMarker, OrderMarker>(RegistrationType.Singleton);
        }
    }
}