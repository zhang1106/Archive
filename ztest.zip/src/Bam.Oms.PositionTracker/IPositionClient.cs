﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.PositionTracker
{
    public interface IPositionClient
    {
        //SOD Positions
        IList<IPosition> GetSodPositions(DateTime asOfDate);
        IList<IPosition> GetSodPositionsForPortfolio(DateTime asOfDate, IPortfolio portfolio);
        IList<IPosition> GetSodPositionsForSecurity(DateTime asOfDate, ISecurity portfolio);
        IList<IPosition> GetSodPositions(DateTime asOfDate, IPortfolio porfolio, ISecurity security);

        //Current positions
        IList<IPosition> GetPositions(DateTime asOfDate);
        IList<IPosition> GetPositionsForPortfolio(DateTime asOfDate, IPortfolio portfolio);
        IList<IPosition> GetPositionsForSecurity(DateTime asOfDate, ISecurity portfolio);
        IList<IPosition> GetPositions(DateTime asOfDate, IPortfolio porfolio, ISecurity security);
        IList<IPosition> GetPositionsForPortfolio(IPortfolio portfolio);
        
        event Action<DateTime, IList<IPosition>, PositionUpdate> SodPositionUpdate;
        event Action<IList<IPosition>, PositionUpdate> PositionUpdate;

        event Action<IPosition, String> NotifyError;
        event Action<IPosition, String> NotifyWarning;
        event Action<IPosition, String> NotifyLog;
    }
}
