﻿
using System;
using System.Linq;
using Bam.Oms.Data.RestApi;
using Bam.Oms.EndPoints.Http;
using BAM.Infrastructure.Ioc;
using System.Collections.Generic;
using System.Web.Http;
using Bam.Oms.Data.Configuration;
using Bam.Oms.EndPoints.PermissionService;
using Newtonsoft.Json;


namespace Bam.Oms.EndPoints.Permission
{
    public class PermissionController : BaseController, IPermissionController
    {
        public PermissionController(IHostConfiguration hostConfiguration, ILogger logger)
            : base(hostConfiguration, logger)
        {
        }

        public IList<string> GetStrategies()
        {
            try
            {
                var user = PermissionChecker.IsPermissionEnabled() ? PermissionChecker.GetUserId(this.User.Identity) : string.Empty;
                return PermissionServiceSession.GetStategies(user).Select(s => s.StrategyCode).ToList();
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                if (ex.InnerException != null) _logger.Error(ex.InnerException.Message);
                throw ex;
            }

        }

        public IList<string> GetPermissions()
        {
            return PermissionServiceSession.GetPermissions(PermissionChecker.GetUserId(User.Identity)).ToList();
        }

        public IList<string> Get(string app)
        {
            try
            {

                if (!PermissionChecker.IsPermissionEnabled())
                {
                    return new List<string>() { "Function.PMUI.Read", "Function.PMUI.Write" };
                }

                var userId = PermissionChecker.GetUserId(User.Identity);
                var allPermissions = PermissionServiceSession.GetPermissions(userId);

                _logger.Info($"All permissions for user {userId} for app {app}, {JsonConvert.SerializeObject(allPermissions)}");

                var filtered = allPermissions.Where(r => r.Contains(app)).ToList();

                _logger.Info($"Filtered permissions for user {userId} for app {app}, {JsonConvert.SerializeObject(filtered)}");

                return filtered;
            }
            catch (Exception ex)
            {
                _logger.Error($"Unable to determine permissions for app {app}.  {ex.Message} \n {ex.StackTrace}");
                if (ex.InnerException != null)
                {
                    _logger.Error($"Inner exception {ex.InnerException.Message} \n {ex.InnerException.StackTrace}");
                }

                return new List<string>();
            }
        }

        [HttpGet]
        public string Reset(string userid)
        {
            PermissionServiceSession.ResetPermissions(userid);
            return $"have reset permission for {userid}";
        }

    }
}
