﻿namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class DisableComplianceRuleRequest
    {
        public string RuleName { get; set; }
        public bool Enabled { get; set; }
    }
}