﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Persistence.Orders
{
    public interface IOrderRepository : IPersistentRepository<Order>
    {
        //Find expects portfolio and security objects with Wid cards, export on the PMCode in Portfolio
        IEnumerable<Order> Find(IPortfolio portfolio, ISecurity security);

        IDictionary<IPositionKey, IList<IOrder>> GetAllOrders(Func<IOrder, bool> predicate = null);
    }
}