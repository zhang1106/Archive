﻿using System.Linq;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Persistence.Securities;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;


namespace Bam.Oms.Compliance.Test
{
    [Category("Integration")]
    [TestFixture]
    [Ignore("Integration")]
    public class DataProviderIntegrationTest
    {
        [Test]
        public void TestPomoHoldingProvider()
        {
            var settings = Factory.GetSettings();
            ISecurityDBRepository repo = new SecurityDBRepository(settings.BamCoreLiteConnectionString, new Mock<ILogger>().Object);

            ISecurityProvider securityProvider = new DwSecurityProvider(repo, new Mock<ILogger>().Object, new Mock<ISettings>().Object);
            securityProvider.RefreshData();
            
            var jsonProvider = new JsonDataProvider();

            var provider = new HoldingProvider(jsonProvider, securityProvider, new Mock<ICompositeDecomposer>().Object, 
                new Mock<ICustomDataProvider>().Object, new Mock<IOgDataRepository>().Object, new Mock<IMarketDataProvider>().Object, 
                new Mock<IDwRepository>().Object, 
                settings, Factory.GetHelper(settings), new Mock<ILogger>().Object);
            provider.RefreshData(PositionType.Intraday);

            var positions = provider.IntradayPositions;

            Assert.IsTrue(positions.Any());
        }
    }
}
