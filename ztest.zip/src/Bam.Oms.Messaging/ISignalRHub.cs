﻿namespace Bam.Oms.Messaging
{
    public interface ISignalRHub
    {
        void AddFilter(ParameterString[] criteria);

        void RemoveFilter();

        void Ping();
    }
}