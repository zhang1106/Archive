﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.MarketData.Enumerators
{
    public enum RequestRejectReason
    {
        UnknownSymbol = 0,
        DuplicateReqId = 1,
        UnknownReqId = 2,
        ServiceUnavailable = 254,
        Unknown = 255
    }
}
