﻿using System.Net;
using System.Web.Http;
using System.Web.Http.Dependencies;
using System.Web.Http.ExceptionHandling;
using Bam.EventQ.Diagnostics;
using Owin;

namespace Bam.Oms.OrderGateway.EzeGateway.Http
{
    public class StartUp
    {
        private readonly IDependencyResolver _dependencyResolver;

        public StartUp(IDependencyResolver dependencyResolver)
        {
            _dependencyResolver = dependencyResolver;
        }

        public void Configuration(IAppBuilder appBuilder)
        {
            var http = new HttpConfiguration();
            http.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{action}/{key}",
                defaults: new { key = RouteParameter.Optional });

            http.DependencyResolver = _dependencyResolver;
            http.Services.Replace(typeof(IExceptionHandler), new LoggingExceptionHandler(
                (ILogger) _dependencyResolver.GetService(typeof(ILogger))));

            appBuilder.UseWebApi(http);

            var listener = (HttpListener)appBuilder.Properties["System.Net.HttpListener"];
            listener.AuthenticationSchemes = AuthenticationSchemes.Anonymous;

            SwaggerConfig.Register(http);
        }
    }
}
