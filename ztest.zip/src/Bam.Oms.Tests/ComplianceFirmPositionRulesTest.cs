﻿using System;
using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Securities;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Compliance;
using Bam.Oms.Filtering;
using Bam.Oms.Compliance.Filters;
using Bam.Oms.Compliance.Policies;
using BAM.Infrastructure.Ioc;
using BAM.Infrastructure.DataFlowLogging.Client;
using Microsoft.Practices.Unity;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class ComplianceFirmPositionRulesTest
    {
        IIntradayPositionProvider _positionProvider;
        IMarketDataProvider _marketDataProvider;
        ISecurityProvider _securityProvider;
        IFactProvider _factProvider;
        string _testSymbol;

        [SetUp]
        public void Setup()
        {
            //firm position
            var positionProvider = new Mock<IIntradayPositionProvider>();
            positionProvider.Setup(n => n.GetFirmWideLongQuantity(It.IsAny<string>())).Returns(Tuple.Create<string, decimal?>("test", 2000));

            //shares outstanding
            var marketDataProvider = new Mock<IMarketDataProvider>();
            marketDataProvider.Setup(n => n.GetSharesOutstanding(It.IsAny<string>())).Returns(1000000);

            //security
            var securityProvider = new Mock<ISecurityProvider>();
            securityProvider.Setup(n => n.GetSecurity(It.IsAny<string>())).Returns(new Security { BamSymbol = "IBM", Country= "AU", SecurityType = SecurityType.Equity });

            _positionProvider = positionProvider.Object;
            _marketDataProvider = marketDataProvider.Object;
            _securityProvider = securityProvider.Object;
            _factProvider = new FactProvider(null);

            _testSymbol = "ANTO LN";
        }

        [Test]
        [TestCase(1000, "ANTO LN", Data.Enumerators.ComplianceAlertLevel.Violated)]
        [TestCase(3000, "ANTO LN", Data.Enumerators.ComplianceAlertLevel.NoViolation)]
        [TestCase(3000, "Test", Data.Enumerators.ComplianceAlertLevel.NoViolation)]
        public void TestLongOnwershipLimitCheckViolation(decimal threshhold, string symbol, Data.Enumerators.ComplianceAlertLevel vLevel)
        {
            //arr
            var rule = new LongOwnershipLimit(_positionProvider, new Mock<IFactProvider>().Object, new Mock<ILogger>().Object, new Mock<ILoggingAgent>().Object) { BamSymbol = _testSymbol, Threshhold = threshhold, IsActive=true};
            //act
            var target = new CompliancePosition() { Security= new Security {  BamSymbol = symbol}, Policy=new Policy<CompliancePosition>() };
            var result = rule.CheckViolation(target, false);
            //ass
            Assert.IsTrue(result.AlertLevel == vLevel);
        }

        [Test]
        [TestCase(80000.0, 0.06, 0.05, "AU", ComplianceAlertLevel.SubWarning)]
        [TestCase(40000.0, 0.06, 0.05, "AU", ComplianceAlertLevel.FallBelowWarning)]
        [TestCase(150000.0, 0.06, 0.05, "AU", ComplianceAlertLevel.ExceedWarning)]
        [TestCase(200000.0, 0.06, 0, "AT", ComplianceAlertLevel.ExceedWarning)]
        public void TestLongOwnershipFilingCheckViolation(decimal position, decimal lastRatio, decimal lastLowLimit, string country, ComplianceAlertLevel expectedAlertLevel)
        {
            //arrange
            //arr
            var ruleResultProvider = new Mock<ILongOwnershipRuleResultProvider>();
            ruleResultProvider.Setup(n => n.GetIsRuleOverriden(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(false);
            ruleResultProvider.Setup(n => n.GetRatio(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(lastRatio);
            ruleResultProvider.Setup(n => n.GetLowLimit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(lastLowLimit);
            //
            var positionProvider = new Mock<IIntradayPositionProvider>();
            positionProvider.Setup(n => n.GetFirmWideLongQuantity(It.IsAny<string>())).Returns(Tuple.Create("test", (decimal?)position));

            var list = new SortedList<decimal, ThreshholdWarning>();
            var noWarning = new ThreshholdWarning()
            {
                UpLimit = 0.05m,
                LowLimit = 0.0m
            };
            var warning1 = new ThreshholdWarning()
            {
                LowLimit = 0.05m,
                UpLimit = 0.10m,
                SubsequentChange = 0.01m
            };
            var warning2 = new ThreshholdWarning()
            {
                LowLimit = 0.10m,
                SubsequentChange = 0.01m
            };
            list.Add(warning2.LowLimit.Value, warning2);
            list.Add(warning1.LowLimit.Value, warning1);
            list.Add(noWarning.LowLimit.Value, noWarning);
            //
            var factProvider = new Mock<IFactProvider>();
            factProvider.Setup(n => n.GetList(It.IsAny<string>())).Returns(new HashSet<string>());

            var parms = new List<Parameter>
            {
                new Parameter()
                {
                    Property = "Country",
                    Value = "AU",
                    Operator = new ComplianceOperator(factProvider.Object) {OperatorType = OperatorType.Equal}
                }
            };
            var rule = new LongOwnerShipFiling(positionProvider.Object, _marketDataProvider, factProvider.Object, ruleResultProvider.Object,
                  new Mock<ILogger>().Object, new Mock<ILoggingAgent>().Object)
            {  Description = "Test", Threshholds = list, IsActive=true, FilterParams=parms};
            //
            var target = new CompliancePosition() {Policy = new Policy<CompliancePosition>() {Id=2}, Security=new Security() { BamSymbol = _testSymbol} };
            //act
            var result = rule.CheckViolation(target, false);
            //Assert
            Assert.IsTrue(result.AlertLevel == expectedAlertLevel);
        }

        [Test]
        [TestCase(-300000, ComplianceAlertLevel.Warning)]
        [TestCase(-130000, ComplianceAlertLevel.NoViolation)]
        public void TestShortSharesOutstandingWarning(decimal position, ComplianceAlertLevel expectedAlertLevel)
        {
            //arr
            //share outstanding is set to 1,000,000
            var factProvider = new Mock<IFactProvider>();
            factProvider.Setup(n => n.GetList(It.IsAny<string>())).Returns(new HashSet<string>());
            var positionProvider = new Mock<IIntradayPositionProvider>();
            positionProvider.Setup(n => n.GetFirmWideNetQuantity(It.IsAny<string>())).Returns(Tuple.Create("test", (decimal?)position));

            var parms = new List<Parameter>
            {
                new Parameter()
                {
                    Property = "Country",
                    Value = "AU",
                    Operator = new ComplianceOperator(factProvider.Object) {OperatorType = OperatorType.Equal}
                }
            };
            var rule = new ShortSharesOutstandingWarning(new Mock<IFactProvider>().Object, positionProvider.Object, 
                _marketDataProvider, new Mock<ILogger>().Object, new Mock<ILoggingAgent>().Object)
            { Threshhold = -0.25m, IsActive = true, FilterParams = parms};
            var target = new CompliancePosition() { Security = new Security() {BamSymbol = _testSymbol}, Policy=new Policy<CompliancePosition>()};

            //act
            var result = rule.CheckViolation(target, false);
            //ass
            Assert.IsTrue(result.AlertLevel == expectedAlertLevel);
        }
    }
}
