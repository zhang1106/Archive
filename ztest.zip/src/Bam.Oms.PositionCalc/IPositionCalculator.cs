﻿using System.Collections.Generic;
using Bam.Oms.Data;

namespace Bam.Oms.PositionCalc
{
    public interface IPositionCalculator
    {
        IEnumerable<IPosition> CalculatePositions(IEnumerable<IPosition> currentPositions,
            IEnumerable<Data.ITrade> fills);
        IEnumerable<IOrder> CalculatePositionAndMarkOrders(IEnumerable<IPosition> currentPositions, IEnumerable<IOrder> orders, out IEnumerable<IPosition> finalPositions);

        IPosition CalculatePosition(IEnumerable<IPosition> currentPositions, ITrade trade);
        IEnumerable<IOrder> CalculatePositionAndMarkOrder(IEnumerable<IPosition> currentPositions, IOrder order, out IPosition finalPosition);
        IPosition CancelOrder(IPosition position, IOrder order);
    }
}