using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using log4net.Appender;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using NUnit.Framework;
using ProtoBuf.Meta;
using WebApiContrib.Formatting;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class PerformanceTests
    {
        const int size = 100000;
        
        [Ignore("Perf tests are only run on demand")]
        [Test]
        public void TestSerializingJsonVersusProto()
        {
            // arrange
            var list = new List<Position>();

            var typeModel = TypeModel.Create();
            typeModel.UseImplicitZeroDefaults = false;
            

            for (var i = 0; i < size; i++)
            {
                list.Add(CreatePosition());
            }

            // act
            var stream0 = new MemoryStream();

            var start = DateTime.Now;

            var json = JsonConvert.SerializeObject(list, Formatting.Indented, new IsoDateTimeConverter());
            var buf = System.Text.Encoding.Default.GetBytes(json);
            stream0.Write(buf, 0, buf.Length);
            stream0.Flush();
            var diff = DateTime.Now.Subtract(start).Milliseconds;
            

            var stream = new MemoryStream();
            var startP = DateTime.Now;
            typeModel.Serialize(stream,list);
            var diffP = DateTime.Now.Subtract(startP).Milliseconds;


            // assert
            Debug.Write($"JSON {diff}; PROTO {diffP}");
        }

        [Ignore("Perf tests are only run on demand")]
        [Test]
        public void TestDeserializingJsonVersusProto()
        {
            // arrange
            var list = new List<Position>();


            var typeModel = TypeModel.Create();
            typeModel.UseImplicitZeroDefaults = false;


            for (var i = 0; i < size; i++)
            {
                list.Add(CreatePosition());
            }

            // act
            var stream0 = new MemoryStream();

            var json = JsonConvert.SerializeObject(list, Formatting.Indented, new IsoDateTimeConverter());
            var buf = System.Text.Encoding.Default.GetBytes(json);
            stream0.Write(buf, 0, buf.Length);
            stream0.Flush();

            var sr = new StreamReader(stream0);
            var jreader = new JsonTextReader(sr);

            var ser = new JsonSerializer();
            ser.Converters.Add(new IsoDateTimeConverter());

            var stream = new MemoryStream();
            typeModel.Serialize(stream, list);



            var start = DateTime.Now;
            var val = ser.Deserialize(jreader, typeof(List<Position>)); 
            var diff = DateTime.Now.Subtract(start).Milliseconds;
            
            var startP = DateTime.Now;
            typeModel.Deserialize(stream, null, typeof(List<Position>));
            var diffP = DateTime.Now.Subtract(startP).Milliseconds;


            // assert
            Debug.Write($"JSON {diff}; PROTO {diffP}");
        }

        private Position CreatePosition()
        {
            return new Position
            {
                PositionId = 4,
                Security = new Security { BamSymbol = "IBM", Currency = "USD", SecurityType = SecurityType.EquitySwap },
                Price = 2.5M,
                EntryDate = DateTime.Now,
                CustodianName = "Deutsche Bank",
                FXRate = 1M,
                ActualQuantity = -200000M,
                Portfolio = (Portfolio)Portfolio.Parse("QIAN-GENERALIST"),
                Stream = "US",
                FundCode = "Fund2",
                CreatedOn = DateTime.Now,
                ActionLogId = 1,
                AuditSequence = 1,
                LastModifiedOn = DateTime.Now,
                LastModifiedBy = "kishore",
                TheoreticalQuantity = -200000M
            };
        }
    }
}
