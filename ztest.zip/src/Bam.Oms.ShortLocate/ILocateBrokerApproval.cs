﻿using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.ShortLocate
{
    public interface ILocateBrokerApproval
    {
        RateType RateType { get;  }
        decimal Rate { get; }
        decimal AssignedSize { get; }
        string AssignmentId { get; }
        string Broker { get; }

    }
}