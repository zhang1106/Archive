﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using BAM.Infrastructure.Ioc;
using Newtonsoft.Json;

namespace Bam.Oms.Compliance.DataProvider
{
    /// <summary>
    /// get intraday data from the pomo restful data svc
    /// </summary>
    public class JsonDataProvider : IJsonDataProvider
    {
        private const string TokenCall = "/oauth/token";
        private const string PositionCall = "/api/Position/Get";
        private static Dictionary<string, KeyValuePair<string, string>> _dateToken;

        public JsonDataProvider()
        {
            _dateToken=new Dictionary<string, KeyValuePair<string, string>>();
        }
        
        public string GetToken(string baseUrl)
        {
            var todate = DateTime.Now.Date.ToString(CultureInfo.InvariantCulture);
            if (_dateToken.ContainsKey(baseUrl) && _dateToken[baseUrl].Value == todate)
            {
                return _dateToken[baseUrl].Value;
            }
               
            var req = System.Net.WebRequest.Create($"{baseUrl}{TokenCall}");
            //Add these, as we're doing a POST
            req.ContentType = "application/x-www-form-urlencoded";
            req.Method = "POST";
            req.Credentials = CredentialCache.DefaultCredentials;

            //post data
            const string parameters = "grant_type=client_credentials&expiry=1.00%3A00%3A00";
            var bytes = System.Text.Encoding.ASCII.GetBytes(parameters);
            req.ContentLength = bytes.Length;
            var os = req.GetRequestStream();
            os.Write(bytes, 0, bytes.Length); //Push it out there
            os.Close();

            //get response
            var resp = req.GetResponse();
            var sr = new System.IO.StreamReader(resp.GetResponseStream());
            var json = sr.ReadToEnd().Trim();
            var token = JsonConvert.DeserializeObject<AccessToken>(json);

            _dateToken[baseUrl] = new KeyValuePair<string, string>(todate, token.access_token);

            return token.access_token;
        }

        public string GetPositions(string baseUrl)
        {
            // Create the Request
            var request = WebRequest.Create($"{baseUrl}{PositionCall}") as HttpWebRequest;
            request.Method = "GET";
            request.Headers.Add("Authorization", "Bearer " + GetToken(baseUrl));

            // Get the Response
            using (var webResponse = request.GetResponse() as HttpWebResponse)
            {
                // Extract ResponseStream from Response
                var reader = new StreamReader(webResponse.GetResponseStream());
                var json = reader.ReadToEnd();
                return json;
            }
        }
        /// <summary>
        /// get position data string from pomo svc
        /// </summary>
        /// <param name="svcUrl"></param>
        /// <returns></returns>
        public string GetDataInJson(string svcUri)
        {
            var pomoData = string.Empty;
            var handler = new HttpClientHandler()
            {
                UseDefaultCredentials = true,
            };

            try
            {

                using (var httpClient = new HttpClient(handler))
                {
                    httpClient.DefaultRequestHeaders.Accept.Clear();

                    var response = httpClient.GetAsync(svcUri).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        pomoData = response.Content.ReadAsStringAsync().Result;
                    }
                }
            }
            catch (Exception ex)
            {
                var logger = Container.Instance.Resolve<ILogger>();
                logger.Error($"Error in getting data from {svcUri}: {ex.Message}");
            };

            return pomoData;
        }

        public struct AccessToken 
        {
            public string access_token { get; set; }
        }
    }

}
