﻿namespace Bam.EventQ.Lookup
{
    public interface IModelEventHandler<in TEvent>
    {
        void Handle(TEvent @event);
    }
}
