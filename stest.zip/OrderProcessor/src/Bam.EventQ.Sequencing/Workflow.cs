﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Sequencing;
using Bam.EventQ.Time;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Workflow
{
    public abstract class Workflow : Workflow<IMessage>
    {
        private readonly FrozenClock _timestampClock 
            = new FrozenClock(Clock.Utc.ZoneId, Clock.Utc.GetTimeZoneInfo());

        private static readonly BatchMessageConflation Conflation = new BatchMessageConflation();

        public override IReadOnlyList<IMessage> Result
        {
            get
            {
                var result = GetResults();
                Conflation.Conflate(result);
                return result;
            }
        }

        protected DateTime GetMessageTimestamp(IMessage message)
        {
            _timestampClock.SetTimestamp(message.Header.Timestamp);
            return _timestampClock.Now;
        }
    }
}
