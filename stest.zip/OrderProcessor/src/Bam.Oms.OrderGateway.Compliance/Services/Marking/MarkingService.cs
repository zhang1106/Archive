﻿using System;
using System.Collections.Generic;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Marking
{
    public class MarkingService : IMarkingService
    {
        private readonly List<OrderAllocation> _splitSide1 = new List<OrderAllocation>();
        private readonly List<OrderAllocation> _splitSide2 = new List<OrderAllocation>();
        private readonly List<Order> _splitResult = new List<Order>();
        private readonly List<KeyValuePair<OrderAllocation, long>> _proRated 
            = new List<KeyValuePair<OrderAllocation, long>>();

        private readonly IOrderMarkerFactory _markerFactory;
        private readonly IComplianceCache _complianceCache;
        private readonly IReferenceDataService _referenceDataService;

        public MarkingService(
            IOrderMarkerFactory markerFactory,
            IComplianceCache complianceCache,
            IReferenceDataService referenceDataService)
        {
            _markerFactory = markerFactory;
            _complianceCache = complianceCache;
            _referenceDataService = referenceDataService;
        }

        public void Mark(CachedSecurity security, List<OrderAllocation> opening, List<OrderAllocation> closing)
        {
            bool isOmni = false;
            foreach (var alloc in opening)
            {
                isOmni |= _referenceDataService.IsOmni(alloc.CustodianId);
            }

            if (!isOmni)
            {
                foreach (var alloc in closing)
                {
                    isOmni |= _referenceDataService.IsOmni(alloc.CustodianId);
                }
            }

            var marker = _markerFactory.Create(security.SecurityType);

            long closingQty = 0;
            using (marker.Scoped())
            {
                closingQty += Mark(marker, security, isOmni, closing);
                closingQty += Mark(marker, security, isOmni, opening);
            }

            AllocateMarkedQuantity(closingQty, opening, closing);
        }

        private void AllocateMarkedQuantity(long closingQty, List<OrderAllocation> opening, List<OrderAllocation> closing)
        {
            long closingAllocSum = 0, openingAllocSum = 0, closingSansOmniFromClosing = 0, closingSansOmniFromOpening = 0;
            foreach (var alloc in closing)
            {
                closingAllocSum += alloc.Quantity;
                closingSansOmniFromClosing += alloc.ClosingPortionSansOmni;
            }

            foreach (var alloc in opening)
            {
                openingAllocSum += alloc.Quantity;
                closingSansOmniFromOpening += alloc.ClosingPortionSansOmni;
            }

            if (closingQty >= closingAllocSum)
            {
                for (var i = 0; i < closing.Count; i++)
                {
                    closing[i] = new OrderAllocation(closing[i]) {Side = closing[i].Side.ToClosingSide()};
                }

                var remainder = closingQty - closingAllocSum;
                long delta = remainder;
                var openingCount = opening.Count;

                _proRated.Clear();
                for (int i = 0; i < openingCount; i++)
                {
                    var current = opening[i];

                    var proRated = (long) Math.Floor(current.Quantity / (double) openingAllocSum * remainder);
                    _proRated.Add(new KeyValuePair<OrderAllocation, long>(current, proRated));
                    delta -= proRated;
                }

                for (int i = 0; i < _proRated.Count; i++)
                {
                    if (delta == 0)
                        break;

                    var item = _proRated[i];
                    var itemDelta = item.Key.Quantity - item.Value;
                    if (itemDelta > 0)
                    {
                        var addition = Math.Min(delta, itemDelta);
                        delta -= addition;
                        _proRated[i] = new KeyValuePair<OrderAllocation, long>(item.Key, item.Value + addition);
                    }
                }

                for (int i = 0; i < _proRated.Count; i++)
                {
                    var alloc = _proRated[i].Key;
                    var assigned = _proRated[i].Value;

                    if (alloc.Quantity == assigned)
                    {
                        alloc.Side = alloc.Side.ToClosingSide();
                    }
                    else if (assigned == 0)
                    {
                        alloc.Side = alloc.Side.ToOpeningSide();
                    }
                    else
                    {
                        var copy = new OrderAllocation(alloc)
                        {
                            Quantity = assigned,
                            Side = alloc.Side.ToClosingSide()
                        };

                        alloc.Side = alloc.Side.ToOpeningSide();
                        alloc.Quantity -= copy.Quantity;
                        opening.Add(copy);
                    }

                    opening[i] = alloc;
                }

                var remainingSansOmni = closingSansOmniFromOpening;
                for (int j = 0; j < 2; j++)
                for (int i = 0; i < opening.Count; i++)
                {
                    var current = opening[i];
                    if (j == 0 && !current.Side.IsClosing() ||
                        j == 1 && current.Side.IsClosing())
                        continue;

                    current.ClosingPortionSansOmni = Math.Min(current.Quantity, remainingSansOmni);
                    remainingSansOmni -= current.ClosingPortionSansOmni;
                    opening[i] = current;
                }
            }
            else // if (closingQty < closingAllocSum)
            {
                var closingCount = closing.Count;
                long delta = closingQty;

                _proRated.Clear();
                for (int i = 0; i < closingCount; i++)
                {
                    var current = closing[i];
                    if (closingQty > 0)
                    {
                        var proRated = (long) Math.Floor(current.Quantity / (double) closingAllocSum * closingQty);
                        _proRated.Add(new KeyValuePair<OrderAllocation, long>(current, proRated));
                        delta -= proRated;
                    }
                    else
                    {
                        _proRated.Add(new KeyValuePair<OrderAllocation, long>(current, 0));
                    }
                }

                for (int i = 0; i < _proRated.Count; i++)
                {
                    if (delta == 0)
                        break;

                    var item = _proRated[i];
                    var itemDelta = item.Key.Quantity - item.Value;
                    if (itemDelta > 0)
                    {
                        var addition = Math.Min(delta, itemDelta);
                        delta -= addition;
                        _proRated[i] = new KeyValuePair<OrderAllocation, long>(item.Key, item.Value + addition);
                    }
                }

                for (int i = 0; i < _proRated.Count; i++)
                {
                    var alloc = _proRated[i].Key;
                    var assigned = _proRated[i].Value;

                    if (alloc.Quantity == assigned)
                    {
                        alloc.Side = alloc.Side.ToClosingSide();
                    }
                    else if (assigned == 0)
                    {
                        alloc.Side = alloc.Side.ToOpeningSide();
                    }
                    else
                    {
                        var copy = new OrderAllocation(alloc)
                        {
                            Quantity = assigned,
                            Side = alloc.Side.ToClosingSide()
                        };

                        alloc.Side = alloc.Side.ToOpeningSide();
                        alloc.Quantity -= copy.Quantity;
                        closing.Add(copy);
                    }

                    closing[i] = alloc;
                }

                var remainingSansOmni = closingSansOmniFromClosing;
                for (int j = 0; j < 2; j++)
                for (int i = 0; i < closing.Count; i++)
                {
                    var current = closing[i];
                    if (j == 0 && !current.Side.IsClosing() ||
                        j == 1 && current.Side.IsClosing())
                        continue;

                    current.ClosingPortionSansOmni = Math.Min(current.Quantity, remainingSansOmni);
                    remainingSansOmni -= current.ClosingPortionSansOmni;
                    closing[i] = current;
                }

                for (var i = 0; i < opening.Count; i++)
                {
                    opening[i] = new OrderAllocation(opening[i]) {Side = opening[i].Side.ToOpeningSide()};
                }
            }
        }

        private long Mark(IOrderMarker marker, CachedSecurity security, bool isOmni, List<OrderAllocation> allocations)
        {
            long closingQty = 0;

            int count = allocations.Count;
            Portfolio portfolio = null;
            PositionSet set = default(PositionSet);

            for (int i = 0; i < count; i++)
            {
                var alloc = allocations[i];
                if (!alloc.Portfolio.Equals(portfolio))
                {
                    portfolio = alloc.Portfolio;
                    set = _complianceCache.GetPositionSet(new PositionKey(portfolio, security.Symbol));
                }

                var marks = marker.MarkOrder(new MarkingEntity
                {
                    Side = alloc.Side,
                    Size = alloc.Quantity,
                    IsOmni = isOmni
                }, set);

                foreach (var mark in marks)
                {
                    if (mark.Side.IsClosing())
                    {
                        closingQty += mark.Quantity;
                    }
                }
            }

            return closingQty;
        }

        public List<Order> Split(Order order, IOrderFactory factory,
            List<OrderAllocation> openingAllocations,
            List<OrderAllocation> closingAllocations,
            List<OrderAllocation> mergedAllocations,
            long approvedShortLocate)
        {
            _splitResult.Clear();

            var entireShortQty = 0L;
            var side1 = mergedAllocations[0].Side;
            var side2 = mergedAllocations[0].Side;
            bool split = false;
            foreach (var alloc in mergedAllocations)
            {
                if (alloc.Side == Side.Short)
                    entireShortQty += alloc.Quantity;

                if (alloc.Side != side1)
                {
                    side2 = alloc.Side;
                    split = true;
                }
            }

            if (entireShortQty > approvedShortLocate)
                return _splitResult;

            if (!split)
            {
                order.ChangeSide(side1);
                order.SetOpeningAllocations(openingAllocations);
                order.SetClosingAllocations(closingAllocations);
                order.UpdateTheoreticalAllocations(mergedAllocations);
                _splitResult.Add(order);
            }
            else
            {
                var order1 = order;
                var order2 = factory.CreateSplit(order.OrderId, order1);
                _splitResult.Add(order1);
                _splitResult.Add(order2);

                order1.ChangeSide(side1);
                order2.ChangeSide(side2);

                _splitSide1.Clear();
                _splitSide2.Clear();
                foreach (var alloc in openingAllocations)
                {
                    if (alloc.Side == side1)
                        _splitSide1.Add(alloc);
                    else
                        _splitSide2.Add(alloc);
                }

                order1.SetOpeningAllocations(_splitSide1);
                order2.SetOpeningAllocations(_splitSide2);

                _splitSide1.Clear();
                _splitSide2.Clear();
                foreach (var alloc in closingAllocations)
                {
                    if (alloc.Side == side1)
                        _splitSide1.Add(alloc);
                    else
                        _splitSide2.Add(alloc);
                }

                order1.SetClosingAllocations(_splitSide1);
                order2.SetClosingAllocations(_splitSide2);

                _splitSide1.Clear();
                _splitSide2.Clear();
                foreach (var alloc in mergedAllocations)
                {
                    if (alloc.Side == side1)
                        _splitSide1.Add(alloc);
                    else
                        _splitSide2.Add(alloc);
                }

                order1.UpdateTheoreticalAllocations(_splitSide1);
                order2.UpdateTheoreticalAllocations(_splitSide2);
            }

            return _splitResult;
        }
    }
}
