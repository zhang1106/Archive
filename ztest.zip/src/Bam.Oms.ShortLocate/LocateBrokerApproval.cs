﻿using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.ShortLocate
{
    public class LocateBrokerApproval : ILocateBrokerApproval
    {
        public RateType RateType { get; set; }
        public decimal Rate { get; set; }
        public decimal AssignedSize { get; set; }
        public string AssignmentId { get; set; }
        public string Broker { get; set; }
    }
}