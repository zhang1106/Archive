﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class Locate : ICloneable
    {
        public string LocateId { get; set; }
        public string AssignmentId { get; set; }
        public decimal Rate { get; set; }
        public RateType? RateType { get; set; }
        public DateTime? TimeReceived { get; set; }
        public string PrimeBroker { get; set; }
        public decimal Size { get; set; }

        public object Clone()
        {
            return new Locate
            {
                LocateId = LocateId,
                Size = Size,
                AssignmentId = AssignmentId,
                Rate = Rate,
                PrimeBroker = PrimeBroker,
                RateType = RateType,
                TimeReceived = TimeReceived
            };
        }
    }
}
