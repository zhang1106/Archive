﻿namespace Bam.EventQ.Pipeline.Dsl
{
    internal class NullObjectDecorator : IObjectDecorator
    {
        public T Decorate<T>(T obj)
        {
            return obj;
        }
    }
}
