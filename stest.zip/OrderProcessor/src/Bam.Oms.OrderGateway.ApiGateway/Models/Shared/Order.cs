﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.LocateGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class Order : ModelBase<object>, ICloneable
    {
        public Order()
        {
            StatusMessages = new List<string>(4);
            ExecutionInstructions = new List<ExecutionInstruction>(4);
            Locate = new List<Locate>(4);
            ComplianceFailures = new List<ComplianceIssue>(4);
            Errors = new List<string>(4);
            TargetAllocation = new List<OrderAllocation>(4);
        }
        
        public int OrderSetId { get; set; }
        public string Key => ClientOrderId;
        public string OriginalOrderId { get; set; }
        public string BatchId { get; set; }
        public Portfolio Portfolio { get; set; }
        public Security Security { get; set; }
        public SideType Side { get; set; }
        public decimal Size { get; set; }
        public decimal? Price { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public string Trader { get; set; }
        public int TraderId { get; set; }
        public string TraderLogin { get; set; }
        public string Custodian { get; set; }
        public List<OrderAllocation> TargetAllocation { get; set; }
        public List<Locate> Locate { get; set; }
        public LocateStatus? LocateStatus { get; set; }
        public string ClientOrderId { get; set; }
        public decimal RoutedSize { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime SettleDate { get; set; }
        public DateTime TradeDate { get; set; }
        public string Note { get; set; }
        public List<ExecutionInstruction> ExecutionInstructions { get; set; }
        public DateTime OrderTimeStamp { get; set; }
        public List<string> StatusMessages { get; set; }
        public string TradeCurrency { get; set; }
        public string SettlementCurrency { get; set; }
        public List<string> Errors { get; set; }
        public List<ComplianceIssue> ComplianceFailures { get; set; }
        public string ComplianceOverrideMessage { get; set; }
        public string MaxComplianceErrorLevel { get; set; }
        public Guid SubmissionId { get; set; }
        public decimal FillQuantity { get; set; }
        public decimal AveragePrice { get; set; }
        public OrderUrgency Urgency { get; set; }
        public string CreatedUser { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime LastModified { get; set; }
        public string ExternalId { get; set; }
        public string EmsDestination { get; set; }
        public int Version { get; set; }

        public bool CanBeCancelled()
        {
            return !(OrderStatus == OrderStatus.Error
                     || OrderStatus == OrderStatus.Cancelled
                     || OrderStatus == OrderStatus.Filled
                     || OrderStatus == OrderStatus.Finalized
                     || OrderStatus == OrderStatus.Deleted);
        }

        public bool IsComplete { get; set; }

        public object Clone()
        {
            var o = new Order
            {
                Side = Side,
                LastUpdated = LastUpdated,
                Trader = Trader,
                Custodian = Custodian,
                LocateStatus = LocateStatus,
                Size = Size,
                OrderStatus = OrderStatus,
                Portfolio = (Portfolio) Portfolio.Clone(),
                BatchId = BatchId,
                TradeDate = TradeDate,
                SettlementCurrency = SettlementCurrency,
                ClientOrderId = ClientOrderId,
                Note = Note,
                OrderTimeStamp = OrderTimeStamp,
                OriginalOrderId = OriginalOrderId,
                Price = Price,
                RoutedSize = RoutedSize,
                Security = (Security)Security.Clone(),
                SettleDate = SettleDate,
                TradeCurrency = TradeCurrency,
                SubmissionId = SubmissionId,
                Urgency = Urgency,
                TraderId = TraderId,
                TraderLogin = TraderLogin,
                CreatedUser = CreatedUser,
                ModifiedUser = ModifiedUser,
                LastModified = LastModified,
                AveragePrice = AveragePrice,
                FillQuantity = FillQuantity,
                OrderSetId = OrderSetId,
                IsComplete = IsComplete,
                ExternalId = ExternalId,
                EmsDestination = EmsDestination,
                ComplianceOverrideMessage = ComplianceOverrideMessage,
                MaxComplianceErrorLevel = MaxComplianceErrorLevel,
                Version = Version
            };

            foreach (var l in Locate)
            {
                o.Locate.Add((Locate) l.Clone());
            }

            foreach (var ei in ExecutionInstructions)
            {
                o.ExecutionInstructions.Add(new ExecutionInstruction
                {
                    Value = ei.Value,
                    Code = ei.Code
                });
            }

            foreach (var cf in ComplianceFailures)
            {
                o.ComplianceFailures.Add((ComplianceIssue) cf.Clone());
            }

            foreach (var alloc in TargetAllocation)
            {
                o.TargetAllocation.Add((OrderAllocation) alloc.Clone());
            }

            o.Errors.AddRange(Errors);
            o.StatusMessages.AddRange(StatusMessages);

            return o;
        }

        public string GetRoutingKey()
        {
            return $"{Portfolio.AggregationUnit}.{Portfolio}";
        }

        public override string ToString()
        {
            return $"Id: {ClientOrderId}, Strategy: {Portfolio}, Qty: {Size}";
        }
    }
}
