﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq.Expressions;
using Bam.EventQ.Lookup;

namespace Bam.EventQ.Snapshot
{
    public class SnapshotRecoveryService<TMessage> : EventRelay<TMessage>, ISnapshotRecoveryService<TMessage>
    {
        private readonly ISnapshotMarshaller _marshaller;
        private readonly List<Func<ISnapshot>> _persist;
        private readonly Dictionary<Type, Action<ISnapshot>> _recover;

        public SnapshotRecoveryService(ISnapshotMarshaller marshaller,
            ISnapshotTypeRegistry registry)
        {
            _marshaller = marshaller;
            _persist = new List<Func<ISnapshot>>();
            _recover = new Dictionary<Type, Action<ISnapshot>>();

            foreach (var item in registry.Recoverables)
            {
                var types = registry.GetTypes(item);
                foreach (var type in types)
                {
                    _persist.Add(BuildPersistCall(item, type));
                    _recover.Add(type, BuildRestoreCall(item, type));
                }
            }
        }

        public void Persist(Stream stream)
        {
            var data = new List<ISnapshot>();
            foreach (var item in _persist)
            {
                data.Add(item());
            }

            _marshaller.Write(data, stream);
        }

        public void Recover(Stream stream)
        {
            var data = _marshaller.Read(stream);
            foreach (var item in data)
            {
                Action<ISnapshot> a;
                if (_recover.TryGetValue(item.GetType(), out a))
                {
                    a(item);
                }
            }
        }
        
        private Func<ISnapshot> BuildPersistCall(ISnapshotRecoverable instance, Type snapshotType)
        {
            var arg = Expression.Constant(instance, typeof(ISnapshotRecoverable));
            var castArg = Expression.Convert(arg, typeof(ISnapshotRecoverable<>).MakeGenericType(snapshotType));
            var result = Expression.Call(castArg, nameof(ISnapshotRecoverable<ISnapshot>.Persist), new Type[] { });
            var castResult = Expression.Convert(result, typeof(ISnapshot));

            return Expression.Lambda<Func<ISnapshot>>(castResult).Compile();
        }

        private Action<ISnapshot> BuildRestoreCall(ISnapshotRecoverable instance, Type snapshotType)
        {
            var p = Expression.Parameter(typeof(ISnapshot), "memento");
            var castP = Expression.Convert(p, snapshotType);
            var arg = Expression.Constant(instance, typeof(ISnapshotRecoverable));
            var castArg = Expression.Convert(arg, typeof(ISnapshotRecoverable<>).MakeGenericType(snapshotType));
            var call = Expression.Call(castArg, nameof(ISnapshotRecoverable<ISnapshot>.Recover),
                new Type[] { }, castP);

            Expression body = call;

            // ReSharper disable once SuspiciousTypeConversion.Global
            if (instance is IEventSource<TMessage>)
            {
                var thisInstance = Expression.Constant(this);
                var castEventSource = Expression.Convert(arg, typeof(IEventSource<TMessage>));
                var disposable = Expression.Variable(typeof(IDisposable), "disp");
                var attachCall = Expression.Assign(disposable,
                    Expression.Call(thisInstance, nameof(Attach), new Type[] { }, castEventSource));
                var disposeCall = Expression.Call(disposable, nameof(IDisposable.Dispose), new Type[] { });
                body = Expression.Block(new[] {disposable}, attachCall, Expression.TryFinally(call, disposeCall));
            }

            return Expression.Lambda<Action<ISnapshot>>(body, p).Compile();
        }
    }
}
