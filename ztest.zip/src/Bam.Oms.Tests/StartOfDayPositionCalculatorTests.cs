﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Contingency;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.PositionTracker;
using BAM.Infrastructure.Ioc;
using FluentAssertions;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class StartOfDayPositionCalculatorTests
    {
        [Test]
        public void VerifyMultiPbPosUpdates()
        {
            var port = (Portfolio)Portfolio.Parse("JELL-TECH");
            port.AggregationUnit = "MAIN";
            port.ComplianceGroup = "JELL";
            var security = new Security { BamSymbol = "MSFT", SecurityType = SecurityType.Equity };
 
            var p1 = new Position
            {
                Security = security,
                CustodianAccountCode = "GOLDMAN_ACC",
                CustodianName = "GOLDMAN",
                ActualQuantity = 200.00M,
                Portfolio = port,
                Stream = "US-EU",
                FundCode = "Fund1",
                TheoreticalQuantity = 200.0M
            };
            var p2 = new Position
            {
                Security = security,
                CustodianAccountCode = "Morgan_ACC",
                CustodianName = "Morgan",
                ActualQuantity = 100.00M,
                Portfolio = port,
                Stream = "US-EU",
                FundCode = "Fund1",
                TheoreticalQuantity = 100.0M
            };

            var sods = new List<Position>()
            {
               p1, p2
            };

            var effectsCalculator = new PositionEffectCalculator();
            var sodCalculator = new StartOfDayPositionCalculator(effectsCalculator, new Mock<ILogger>().Object);
            
            var tradeRepo = new Mock<ITradeRepository>();
            tradeRepo.Setup(n => n.GetAllTrades(It.IsAny<Func<IBlockTrade, Boolean>>())).Returns(new ConcurrentDictionary<IPositionKey, IList<IBlockTrade>>());

            var orderRepo = new Mock<IOrderRepository>();
            orderRepo.Setup(n => n.GetAllOrders(It.IsAny<Func<IOrder,Boolean>>())).Returns(new ConcurrentDictionary<IPositionKey, IList<IOrder>>());

            var positionRepository = new PositionRepository();
            var positionSet = Helper.CreatePositionSet(port, security, "GOLDMAN");
            positionRepository.Save(new List<IPositionSet>() { positionSet });
            
            using (var positionTracker =
                    new PositionTracker.PositionTracker(effectsCalculator, sodCalculator,
                        positionRepository,
                        tradeRepo.Object, orderRepo.Object,
                        new Mock<IContingencyDbRepository>().Object,
                        new Mock<ILogger>().Object))
            {
                positionTracker.UpdateSODPositions(sods);
                var newPosSet = positionRepository.Get(new List<IPositionKey>() {new PositionKey(port, security)});

                Assert.IsTrue(newPosSet.Any());
                Assert.IsTrue(newPosSet[0].Position.ActualQuantity == 300 );
                Assert.IsTrue(newPosSet[0].Position.LongMarkingQuantity == 300);
                Assert.IsTrue(newPosSet[0].Position.ShortMarkingQuantity == 300);
                Assert.IsTrue(newPosSet[0].CompliancePosition.LongMarkingQuantity == 300);
                Assert.IsTrue(newPosSet[0].CompliancePosition.ShortMarkingQuantity == 300);
                Assert.IsTrue(newPosSet[0].AggUnitPosition.ShortMarkingQuantity == 300);
            }
        }

        [Test]
        public void VerifyCalculateSodWithOminPositions()
        {
            var port = (Portfolio) Portfolio.Parse("JELL-TECH");
            port.AggregationUnit = "MAIN";
            port.ComplianceGroup = "JELL"; 
            var sods = new List<Position>()
            {
                new Position
                {
                    Security = new Security {BamSymbol = "MSFT", SecurityType = SecurityType.Equity},
                    CustodianAccountCode = "GOLDMAN_ACC",
                    CustodianName = "GOLDMAN",
                    ActualQuantity = 200.00M,
                    Portfolio = port,
                    Stream = "US-EU",
                    FundCode = "Fund1",
                    TheoreticalQuantity = 200.0M
                },
                new Position
                {
                    Security = new Security {BamSymbol = "MSFT", SecurityType = SecurityType.Equity},
                    CustodianAccountCode = "OMNI_ACC",
                    CustodianName = "OMNI",
                    ActualQuantity = 100.00M,
                    Portfolio = port,
                    Stream = "US-EU",
                    FundCode = "Fund1",
                    TheoreticalQuantity = 100.0M
                }
            };
            var effectCalc = new Mock<IPositionEffectCalculator>();
            effectCalc.Setup(e=>e.ApplyEffects(It.IsAny<IPositionSet>(), It.IsAny<IOrder>(), 
                It.IsAny<IBlockTrade>(), It.IsAny<IOrder>(), It.IsAny<IBlockTrade>())).Verifiable();
            var calculator = new StartOfDayPositionCalculator(effectCalc.Object, new Mock<ILogger>().Object);
            var positionSet = calculator.Calculate(sods, new ConcurrentDictionary<IPositionKey, IList<IOrder>>(), new ConcurrentDictionary<IPositionKey, IList<IBlockTrade>>());

            Assert.AreEqual(1, positionSet.Count);
            Assert.AreEqual(200,positionSet[0].AggUnitPosition.ShortMarkingQuantity);
            Assert.AreEqual(200,positionSet[0].CompliancePosition.ShortMarkingQuantity );
            Assert.AreEqual(200, positionSet[0].CompliancePosition.LongMarkingQuantity );
            Assert.AreEqual(300, positionSet[0].Position.ActualQuantity );
            Assert.AreEqual(300, positionSet[0].Position.TheoreticalQuantity);
            Assert.AreEqual(200, positionSet[0].Position.LongMarkingQuantity);
            Assert.AreEqual(200, positionSet[0].Position.ShortMarkingQuantity);
        }
    
        [Test]
        public void VerifyCalculatesAggUnitPositionWhenPositionDoesNotExistInStartOfDay_RegressionEms771()
        {
            // arrange
            var sut = new StartOfDayPositionCalculator(new PositionEffectCalculator(), new Mock<ILogger>().Object);

            var security = new Security
            {
                BamSymbol = "AA"
            };

            var kramer = new Portfolio("KRAM", "GENERALIST", "M1US");
            kramer.ComplianceGroup = "KKR";
            kramer.AggregationUnit = "AQTF";

            var green = new Portfolio("GREE", "GENERALIST", "USSC");
            green.ComplianceGroup = "GRE";
            green.AggregationUnit = "AQTF";

            var qian = new Portfolio("QIAN", "GENERALIST");
            qian.ComplianceGroup = "QIAN";
            qian.AggregationUnit = "AQTF";

            var positions = new IPosition[]
            {
                new Position(kramer, security, "CSPB")
                {
                    LongMarkingQuantity = 1917,
                    ShortMarkingQuantity = 1917,
                    TheoreticalQuantity = 1917,
                    ActualQuantity = 1917
                },
                new Position(qian, security, "CSPB")
                {
                    LongMarkingQuantity = -24800,
                    ShortMarkingQuantity = -24800,
                    TheoreticalQuantity = -24800,
                    ActualQuantity = -24800
                }
            };

            var orders = new IOrder[]
            {
                new Order
                {
                    ClientOrderId = "2CA3",
                    Security = security,
                    Portfolio = green,
                    Side = SideType.Buy,
                    Size = 1000,
                    OrderStatus = BamOrderStatus.Finalized,
                    Custodian = "UBSW"
                },
                new Order
                {
                    ClientOrderId = "2CA2",
                    Security = security,
                    Portfolio = green,
                    Side = SideType.SellShort,
                    Size = 2000,
                    OrderStatus = BamOrderStatus.Cancelled,
                    Custodian = "UBSW"
                },
                new Order
                {
                    ClientOrderId = "2CA1",
                    Security = security,
                    Portfolio = kramer,
                    Side = SideType.Buy,
                    Size = 500,
                    OrderStatus = BamOrderStatus.Finalized,
                    Custodian = "CSPB"
                },
                new Order
                {
                    ClientOrderId = "2CA0",
                    Security = security,
                    Portfolio = qian,
                    Side = SideType.SellShort,
                    Size = 1000,
                    OrderStatus = BamOrderStatus.Cancelled,
                    Custodian = "CSPB"
                }
            };

            var trades = new IBlockTrade[]
            {
                new BlockTrade
                {
                    Allocations = new List<Allocation>(new[]
                    {
                        new Allocation
                        {
                            PrimeBroker = "UBSW"
                        }
                    }),
                    ClientOrderId = "2CA3",
                    TradedQuantity = 300,
                    TradeStatus = BamTradeStatus.New,
                    Portfolio = green,
                    Security = security
                },
                new BlockTrade
                {
                    Allocations = new List<Allocation>(new[]
                    {
                        new Allocation
                        {
                            PrimeBroker = "CSPB"
                        }
                    }),
                    ClientOrderId = "2CA1",
                    TradedQuantity = 300,
                    TradeStatus = BamTradeStatus.New,
                    Portfolio = kramer,
                    Security = security
                }
            };

            var orderLookup =
                orders.ToLookup(o => (IPositionKey)new PositionKey(o.Portfolio, o.Security))
                    .ToDictionary(g => g.Key, g => (IList<IOrder>)g.ToList());
            var tradeLookup =
                trades.ToLookup(
                    t => (IPositionKey)new PositionKey(t.Portfolio, t.Security))
                    .ToDictionary(g => g.Key, g => (IList<IBlockTrade>)g.ToList());

            // act
            var actual = sut.Calculate(positions, orderLookup, tradeLookup);

            // assert
            actual.Should().OnlyContain(set => set.AggUnitPosition.ShortMarkingQuantity == -22283.0m);
        }

        private const int AsiaSodQty = 100;
        private const int AsiaEodQty = 80;
        private const int UsSodQty = 110;
        private const int UsEodQty = 90;

        [TestCase("8/31/2016", "8/31/2016", "8/31/2016", "8/31/2016", AsiaSodQty, UsSodQty)] // e.g. 8/31/16 10:45 AM regular intra day
        [TestCase("9/01/2016", "9/01/2016", "8/31/2016", "8/31/2016", AsiaEodQty, UsEodQty)] // e.g. 8/31/16 6:01 PM a minute after roll
        [TestCase("9/01/2016", "9/01/2016", "9/01/2016", "8/31/2016", AsiaSodQty, UsEodQty)] // e.g. 8/31/16 7:00 PM Asia positions have been loaded after roll
        [TestCase("9/01/2016", "9/01/2016", "9/01/2016", "9/01/2016", AsiaSodQty, UsSodQty)] // e.g. 9/01/16 1:00 AM Asia+US positions have been loaded after roll
        public void VerifyPicksSodPositions(
            string businessDayStr, string snapshotDateStr, 
            string asiaDateStr, string usDateStr,
            int expectedAsiaQty, int expectedUsQty)
        {
            var businessDay = DateTime.Parse(businessDayStr);
            var snapshotDate = DateTime.Parse(snapshotDateStr);
            var asiaDate = DateTime.Parse(asiaDateStr);
            var usDate = DateTime.Parse(usDateStr);

            var snapshot = new IPosition[]
            {
                new Position(Portfolio.Parse("QIAN-GENERALIST"), new Security { BamSymbol = "IBM" })
                {
                    Stream = "USEU",
                    ActualQuantity = UsEodQty,
                    TheoreticalQuantity = UsEodQty,
                    LongMarkingQuantity = UsEodQty,
                    ShortMarkingQuantity = UsEodQty,
                    EntryDate = snapshotDate
                },
                new Position(Portfolio.Parse("XYZ-GENERALIST"), new Security { BamSymbol = "IBM" })
                {
                    Stream = "ASIA",
                    ActualQuantity = AsiaEodQty,
                    TheoreticalQuantity = AsiaEodQty,
                    LongMarkingQuantity = AsiaEodQty,
                    ShortMarkingQuantity = AsiaEodQty,
                    EntryDate = snapshotDate
                }
            };

            var sod = new IPosition[]
            {
                new Position(Portfolio.Parse("QIAN-GENERALIST"), new Security { BamSymbol = "IBM" })
                {
                    Stream = "USEU",
                    ActualQuantity = UsSodQty,
                    TheoreticalQuantity = UsSodQty,
                    LongMarkingQuantity = UsSodQty,
                    ShortMarkingQuantity = UsSodQty,
                    EntryDate = usDate
                },
                new Position(Portfolio.Parse("XYZ-GENERALIST"), new Security { BamSymbol = "IBM" })
                {
                    Stream = "ASIA",
                    ActualQuantity = AsiaSodQty,
                    TheoreticalQuantity = AsiaSodQty,
                    LongMarkingQuantity = AsiaSodQty,
                    ShortMarkingQuantity = AsiaSodQty,
                    EntryDate = asiaDate
                }
            };

            var sut = new StartOfDayPositionCalculator(
                new Mock<IPositionEffectCalculator>().Object, new Mock<ILogger>().Object);

            var actual = sut.Pick(sod, snapshot, businessDay);
            actual.Should().HaveCount(2);
            actual.First(p => p.Stream == "ASIA").ActualQuantity.Should().Be(expectedAsiaQty);
            actual.First(p => p.Stream == "USEU").ActualQuantity.Should().Be(expectedUsQty);
        }
    }
}
