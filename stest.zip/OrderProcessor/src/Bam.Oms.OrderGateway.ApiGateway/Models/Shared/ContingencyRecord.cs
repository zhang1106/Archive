﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class ContingencyRecord
    {
        public ContingencyRecord()
        {
            
        }

        public ContingencyRecord(Position position)
        {
            Portfolio = position.Portfolio.ToString();
            SymbolType = position.Security.SecurityType.ToString();
            Symbol = position.Security.Key;
            SymbolDesc = position.Security.BloombergSymbol;
            SymbolPricing = position.Security.Ticker ?? position.Security.BloombergSymbol ?? position.Security.BamSymbol;
            Quantity = position.ActualQuantity;
            SodPriceNative = 0;
            SodMarketValueNative = Quantity * SodPriceNative;
            Multiplier = 1.0m;
            Currency = position.Security.Currency;
            FxRate = 1;
            Country = position.Security.Country ?? "N/A";
            Industry = position.Security.Industry ?? "N/A";
            UnderlyingSymbol = position.Security.UnderlyingSymbol;
            SysDate = DateTime.Now;
        }

        public string Portfolio { get; set; }
        public string SymbolType { get; set; }
        public string Symbol { get; set; }
        public string SymbolDesc { get; set; }
        public string SymbolPricing { get; set; }
        public decimal Quantity { get; set; }
        public decimal? SodPriceNative { get; set; }
        public decimal? SodMarketValueNative { get; set; }
        public decimal? Multiplier { get; set; }
        public string Currency { get; set; }
        public decimal? FxRate { get; set; }
        public string Country { get; set; }
        public string Industry { get; set; }
        public string UnderlyingSymbol { get; set; }
        public DateTime SysDate { get; set; }
    }
}
