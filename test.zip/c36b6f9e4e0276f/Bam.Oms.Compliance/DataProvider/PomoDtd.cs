﻿//DTD

using System;
using System.Collections.Generic;

namespace Bam.Oms.Compliance.DataProvider
{
    public class HoldingContainerInfo
    {
        public IEnumerable<HoldingInfo> Holdings { get; set; }
        public IEnumerable<SecurityInfo> Securities { get; set; }
        public DateTime LiveDate { get; set; }
        public DateTime RefreshTime { get; set; }
    }

    public class ContainerInfo
    {
        public IEnumerable<SecurityInfo> Securities { get; set; }
        public IEnumerable<PositionInfo> Positions { get; set; }
        public DateTime LiveDate { get; set; }
        public DateTime RefreshTime { get; set; }
    }

    public struct PositionInfo
    {
        public int AcuId { get; set; }
        public decimal Quantity { get; set; }
        public decimal QuantityStart { get; set; }
        public decimal NetExposure { get; set; }
        public string StrategyGroup { get; set; }
        public int SecurityId { get; set; }
    }

    public struct HoldingInfo
    {
        public int AcuId { get; set; }
        public decimal Quantity { get; set; }
        public decimal QuantityStart { get; set; }
        public decimal NetExposure { get; set; }
        public string CustodianAccountCode { get; set; }
        public string StrategyGroup { get; set; }
        public string StrategyCode { get; set; }
        public int SecurityId { get; set; }
        public string FundCode { get; set; }
    }

    public struct SecurityInfo
    {
        public string DisplayCode { get; set; }
        public int SecurityId { get; set; }
        public MarketDataInfo MarketDataInfo { get; set; }
    }

    public struct MarketDataInfo
    {
        public decimal? StartPrice { get; set; }
        public decimal? SharesOutstanding { get; set; }
    }
}
