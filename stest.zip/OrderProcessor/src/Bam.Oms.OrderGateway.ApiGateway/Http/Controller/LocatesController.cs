﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class LocatesController : BaseController
    {
        private readonly ILocateSubmission _locateSubmission;

        public LocatesController(IPermissionedEntityFilter entityFilter, ILocateSubmission locateSubmission) : base(entityFilter)
        {
            if (locateSubmission == null) throw new ArgumentNullException(nameof(locateSubmission));
            _locateSubmission = locateSubmission;
        }

        public string PostLocateRequest(IList<string> orderIds)
        {
            Logger.LogInformation($"{User.GetLogin()} requested locates for orders {orderIds.Stringify()}");
            _locateSubmission.AcquireLocate(orderIds.Select(id => Convert.ToInt64(id)).ToArray(), User.GetLogin());
            return string.Empty;
        }
    }
}