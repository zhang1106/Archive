﻿namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public interface IVersionGenerator
    {
        int NextOrderVersion(string clientOrderId);
        int NextPositionVersion(long positionId);
    }
}
