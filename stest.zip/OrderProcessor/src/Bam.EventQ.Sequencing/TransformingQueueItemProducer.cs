﻿using Bam.EventQ.Integration;

namespace Bam.EventQ.Sequencing
{
    public class TransformingQueueItemProducer<TIn> : TransformingQueueItemProducer<TIn, IMessage>
    {
        private readonly IQueueMessageDispatcher _dispatcher;

        public TransformingQueueItemProducer(
            IExternalMessageSource<TIn> source, 
            IExternalMessageTransform<TIn, IMessage> transform,
            IQueueMessageDispatcher dispatcher) : base(source, transform)
        {
            _dispatcher = dispatcher;
        }

        protected override void Handle(IMessage transformed)
        {
            _dispatcher.Dispatch(Queue, transformed);
        }
    }
}
