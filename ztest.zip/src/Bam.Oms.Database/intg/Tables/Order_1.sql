﻿CREATE TABLE [intg].[Order] (
    [ClientOrderId] VARCHAR (50)     NOT NULL,
    [Side]          VARCHAR (50)     NOT NULL,
    [Size]          DECIMAL (28, 12) NULL,
    [RoutedSize]    DECIMAL (28, 12) NULL,
    [OrderStatus]   VARCHAR (50)     NULL,
    [LocateStatus]  VARCHAR (50)     NULL,
    [Trader]        VARCHAR (50)     NULL,
    [PrimeBroker]   VARCHAR (50)     NULL,
    [AssignmentId]  VARCHAR (50)     NOT NULL,
    [LocateSize]    DECIMAL (28, 12) NULL,
    [BamSymbol]     VARCHAR (50)     NOT NULL,
    [PMCode]        VARCHAR (50)     NOT NULL,
    [CreatedAt]     DATETIME         NOT NULL,
    [CreatedBy]     VARCHAR (50)     NOT NULL,
    [UpdatedAt]     DATETIME         NOT NULL,
    [UpdatedBy]     VARCHAR (50)     NOT NULL,
    PRIMARY KEY CLUSTERED ([ClientOrderId] ASC)
);

