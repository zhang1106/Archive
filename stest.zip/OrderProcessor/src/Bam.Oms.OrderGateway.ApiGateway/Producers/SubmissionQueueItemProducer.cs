﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Integration;
using Bam.EventQ.Sequencing;
using Bam.EventQ.Transport;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.Roll;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;
using Bam.Oms.OrderGateway.Messages.RefDataGateway;

namespace Bam.Oms.OrderGateway.ApiGateway.Producers
{
    public class SubmissionQueueItemProducer : ExternalMessageSourceBase<IMessage>,
        ISodSubmission, IRollBlotterSubmission, IRouteSubmission,
        ICancelSubmission, ILocateSubmission, IOrderSubmission, IPositionSubmission,
        ISecuritySubmission, IComplianceSubmission, IAllocationSubmission
    {
        private readonly IRpcClientFactory _rpcClientFactory;

        public SubmissionQueueItemProducer(IRpcClientFactory rpcClientFactory)
        {
            _rpcClientFactory = rpcClientFactory;
        }

        public ILogger Logger { get; set; }

        private void Publish(IMessage message)
        {
            Handler?.Invoke(message);
        }

        public Guid Submit(SubmitOrders message)
        {
            message.BatchName = message.BatchName?.Trim();

            foreach (var order in message.Items)
            {
                order.Symbol = order.Symbol?.Trim();
                order.BloombergSymbol = order.BloombergSymbol?.Trim();
                order.UnderlyingSymbol = order.UnderlyingSymbol?.Trim();
                order.SecurityType = order.SecurityType?.Trim();
                order.Custodian = order.Custodian?.Trim();
                order.Portfolio = order.Portfolio?.Trim();
                order.TradingCurrency = order.TradingCurrency?.Trim();
                order.Notes = order.Notes?.Trim();
                order.FundAllocationOverride = order.FundAllocationOverride?.Trim();
                order.ReplaceOrderId = order.ReplaceOrderId;
            }

            Publish(message);
            return message.SubmissionId;
        }

        public void ConvertToSwap(long orderId, string counterPartyCode, string user)
        {
            Publish(new CreateSwapConversion
            {
                User = user,
                Items =
                {
                    new CreateSwapConversion.LineItem
                    {
                        OrderId = orderId,
                        CounterPartyCode = counterPartyCode
                    }
                }
            });
        }

        public void ReplacePositions(IReadOnlyList<DetailedPosition> positions, string user)
        {
            var message = new DumpedReplacePositions
            {
                User = user
            };

            foreach (var detailedPosition in positions)
            {
                var item = new DumpedReplacePositions.LineItem
                {
                    PositionId = detailedPosition.PositionId,
                    ShortMarkingQuantity = detailedPosition.ShortMarkingQuantity,
                    LongMarkingQuantity = detailedPosition.LongMarkingQuantity,
                    Portfolio = detailedPosition.Portfolio,
                    BamSymbol = detailedPosition.BamSymbol,
                    TheoreticalQuantity = detailedPosition.TheoreticalQuantity
                };

                foreach (var detailedPositionActualAllocation in detailedPosition.ActualAllocations)
                {
                    var allocation = new DumpedReplacePositions.Allocation
                    {
                        Quantity = detailedPositionActualAllocation.Quantity,
                        Custodian = detailedPositionActualAllocation.Custodian,
                        Fund = detailedPositionActualAllocation.Fund
                    };

                    item.ActualAllocations.Add(allocation);
                }

                message.Items.Add(item);
            }

            Publish(message);
        }

        public void Cancel(long[] orderIds, string user)
        {
            var message = new CancelOrders {User = user};
            foreach (var id in orderIds)
            {
                message.OrderIds.Add(id);
            }

            Publish(message);
        }

        public void Rollback(long[] orderIds, string user)
        {
            var message = new RollbackOrders {User = user};
            foreach (var id in orderIds)
            {
                message.OrderIds.Add(id);
            }

            Publish(message);
        }

        public void AcquireLocate(long[] orderIds, string user)
        {
            var message = new RequestLocate {User = user};
            foreach (var id in orderIds)
            {
                message.OrderIds.Add(id);
            }

            Publish(message);
        }

        public void Route(long[] orderIds, string user)
        {
            var message = new TriggerRouteOrders {User = user};
            foreach (var id in orderIds)
            {
                message.OrderIds.Add(id);
            }

            Publish(message);
        }

        public void ToggleOrderScalingRule(int id, bool active, string user)
        {
            Publish(new ToggleOrderScalingRule
            {
                OrderScalingRuleId = id,
                User = user,
                IsActive = active
            });
        }

        public void OverrideCompliance(long orderId, string messages, string user)
        {
            var complianceOverride = new OverrideCompliance
            {
                User = user,
                OrderId = orderId,
                OverrideMessage = messages
            };

            Publish(complianceOverride);
        }

        public void Load(DateTime asOf, IEnumerable<LoadSodPositions.SodItem> sodItems, string user)
        {
            var message = new LoadSodPositions(sodItems)
            {
                User = user,
                AsOf = asOf
            };

            Publish(message);
        }

        public void Update(DateTime asOf, IEnumerable<UpdateSodPositions.SodItem> sodItems, string user)
        {
            var message = new UpdateSodPositions(sodItems)
            {
                User = user,
                AsOf = asOf
            };

            Publish(message);
        }

        public void ChangeBusinessDay(DateTime businessDay, string user)
        {
            Publish(new BusinessDayChanged
            {
                User = user,
                BusinessDay = businessDay
            });
        }

        public void PrepareSnapshotRecovery(string userId)
        {
            if (!_rpcClientFactory.TriggerSnapshotRecovery())
            {
                Logger?.LogError("Failed to trigger snapshot recovery");
            }
        }

        public void StartRoll(DateTime rollTime, string user, bool force, DateTime? nextBusinessDay)
        {
            if (!_rpcClientFactory.TriggerRoll(
                Source.ApiGateway,
                new RollBlotter
                {
                    User = user,
                    RollTime = rollTime,
                    ForceRoll = force,
                    NextBusinessDay = nextBusinessDay
                }))
            {
                Logger?.LogError("Failed to trigger roll");
            }
        }

        public void Submit(SecurityInsert updates)
        {
            Publish(updates);
        }

        public void SubmitHeadroom(HeadroomLoaded input)
        {
            Publish(input);
        }

        public void AdjustHeadroomRatios(int ruleId, string identifier, Dictionary<string, double> ratios, string user)
        {
            var msg = new AdjustHeadroomRatios
            {
                User = user,
                Identifier = identifier,
                RuleId = ruleId
            };

            ratios.CopyTo(msg.Ratios);
            Publish(msg);
        }

        public void RedirectPbAllocation(long orderId, string user, Dictionary<string, long> allocations)
        {
            var copy = new RedirectPbAllocation() {OrderId = orderId, User = user};
            copy.CustodianRedirection.CopyFrom(allocations);
            Publish(copy);
        }
		
        public void DisableComplianceRules(List<DisableComplianceRuleRequest> rules, string user)
        {
            var message = new DisableComplianceRules {User = user};
            foreach (var rule in rules)
            {
                message.Items.Add(
                    new DisableComplianceRules.Item
                    {
                        Rule = rule.RuleName,
                        IsEnabled = rule.Enabled
                    });
            }

            Publish(message);
        }
    }
}