﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.DataProvider
{
    public class PositionProvider: IPositionProvider
    {
        private readonly IHoldingProvider _holdingProvider;
        private readonly IPositionCalculator _positionCalculator;
        private readonly ISecurityProvider _securityProvider;
        public PositionProvider(IHoldingProvider holdingProvider, IPositionCalculator positionCalculator, ISecurityProvider securityProvider, ILogger logger)
            
        {
            _holdingProvider = holdingProvider;
            _positionCalculator = positionCalculator;
            _securityProvider = securityProvider;

        }

        public void RefreshData()
        {}

        public IEnumerable<string> GetUnderlyingSecurities(PositionType pType)
        {
            return _holdingProvider.GetUnderlyingSecurities(pType);
        }
 
        public Tuple<string, decimal?> GetFirmWideQuantity(string underlying, PositionType pType, SideType side)
        {
            var data = _holdingProvider.GetData(pType, PositionIndex.Underlying);
            return _positionCalculator.GetFirmWideQuantityByUnderlying(underlying, side, data);
        }

        public Tuple<string, decimal?> GetFirmWideQuantityWithAdr(string underlying, PositionType pType, SideType side)
        {
            var data = _holdingProvider.GetData(pType, PositionIndex.Underlying);
            return _positionCalculator.GetFirmWideQuantityByUnderlyingWithAdr(underlying, side, data);
        }

        public Tuple<string, decimal?> GetEntityWideQuantityByIsin(string underlying, PositionType pType, string entity, SideType side)
        {
            var data = _holdingProvider.GetData(pType, PositionIndex.Isin);
            return _positionCalculator.GetEntityWideQuantityByIsin(underlying, side, entity, data);
        }

        public ILookup<string, IPosition> GetData(PositionType pType, PositionIndex pIndex)
        {
            return _holdingProvider.GetData(pType, pIndex);
        }

    }

    public enum PositionIndex
    {
        Isin,
        Underlying
    }
}
