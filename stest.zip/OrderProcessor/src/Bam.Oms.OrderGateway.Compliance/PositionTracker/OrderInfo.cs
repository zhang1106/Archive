﻿using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public struct OrderInfo
    {
        public bool IsLive;
        public bool IsDead;
        public Side Side;
        public long OrderSize;
        public long FillQuantity;
        public bool IsOmni;
    }
}