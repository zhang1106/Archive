﻿using System.Collections.Generic;
using System.Linq;
using System;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Policies;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Persistence.Securities;
using BAM.Infrastructure.Ioc;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;

namespace Bam.Oms.Compliance.Test
{
    [Category("Integration")]
    [TestFixture()]
    public class ComplianceIntegrationTest
    {
       
        private IEnumerable<Security> _securities;
        private IPolicy<ICompliancePosition> _policy;
        private ISettings _settings;
        private IHelper _helper;

        [SetUp]
        public void Setup()
        {
            _settings = Factory.GetSettings();
            
            //securities
            ISecurityDBRepository repoSecurities = new SecurityDBRepository(_settings.BamCoreLiteConnectionString, new Mock<ILogger>().Object);
            _securities = repoSecurities.GetSecurities();
            
            //
            //load rules
            _helper = Factory.GetHelper(_settings);
            Container.Instance.RegisterInstance<IHelper>(_helper);
            Container.Instance.RegisterInstance<ISettings>(_settings);
 
            var repoPolicy = new PolicyRepository<CompliancePosition>(_settings, new Mock<ILogger>().Object);
            var policy = repoPolicy.GetAll().FirstOrDefault();
             _policy = (IPolicy<ICompliancePosition>)(_helper).ConvertBaseToChild(policy);
            
        }

        [Test]
        public void TestGetSecurities()
        {
            ISecurityDBRepository repoSecurities = new SecurityDBRepository(_settings.BamCoreLiteConnectionString, new Mock<ILogger>().Object);
            var securities = repoSecurities.GetSecurities(new string[]{"IBM", "A"});
            Assert.IsTrue(securities.Any());
        }

        [Test]
        public void TestAccessToPomoHoldingContainer()
        {
            var jasonDataAccess = new JsonDataProvider();
            var holding = jasonDataAccess.GetDataInJson("http://pomo-app/PoMoWebServices/api/HoldingContainerInfo?Acu=DODD");
            var holdingData = JsonConvert.DeserializeObject<HoldingContainerInfo>(holding);
            Assert.IsTrue(holdingData.Holdings.Any());
        }

        [Test]
        public void TestAccessToPomoContainer()
        {
            var jasonDataAccess = new JsonDataProvider();
            var holding = jasonDataAccess.GetDataInJson("http://pomo-app/PoMoWebServices/api/ContainerInfo?ACU=JELL");
            var holdingData = JsonConvert.DeserializeObject<ContainerInfo>(holding);
            Assert.IsTrue(holdingData.Positions.Any());
        }

        [Test]
        public void TestGetPolicyRules()
        {
            IPolicyRepository<CompliancePosition> repo = new PolicyRepository<CompliancePosition>(_settings, new Mock<ILogger>().Object);
            IRuleRepository<CompliancePosition> repoRules = new RuleRepository<CompliancePosition>(_settings, new Mock<ILogger>().Object);

            IEnumerable<IPolicy<CompliancePosition>> policies = repo.GetAll();
            IEnumerable<IRule<CompliancePosition>> rules = repoRules.GetRules(policies.ToList()[0].Id);

            Assert.IsTrue(policies.Count() > 0);
            Assert.IsTrue(rules.Count() > 0);
        }

        [Test]
        public void TestGetRulePopulation()
        {
       
            IPolicyRepository<ICompliancePosition> repo = new PolicyRepository<ICompliancePosition>(_settings, new Mock<ILogger>().Object);
            IRuleRepository<ICompliancePosition> repoRules = new RuleRepository<ICompliancePosition>(_settings, new Mock<ILogger>().Object);
            var fPolicy = new FirmPositionLimitPolicy();
            IEnumerable<IPolicy<ICompliancePosition>> policies = repo.GetAll();
            
            var policy = policies.FirstOrDefault();
            fPolicy.Id = policy.Id;

            fPolicy.PopulateRules(repoRules);

            Assert.IsTrue(fPolicy.Rules.Any());
        }


        [Test]
        public void TestGetFacts()
        {
           
            IFactRepository facts = new FactRepository(_settings, new Mock<ILogger>().Object);
            var list = facts.GetAll();

            Assert.IsTrue(list.Any());
        }

        [Test]
        public void TestDwData()
        {
           
            var dwRepo = new DwRepository(_settings, new Mock<ILogger>().Object);
            var pmMap = dwRepo.GetPmRegionMapping();
            var custSharesOutstanding = dwRepo.GetCustomSharesOutstandings();
            var constituents = dwRepo.GetConstitents();
            var isins = dwRepo.GetEuMonitoredIsins();

            Assert.IsTrue(pmMap.Any());
            Assert.IsTrue(custSharesOutstanding.Any());
            Assert.IsTrue(constituents.Any());
            Assert.IsTrue(isins.Any());

        }

        [Test]
        public void TestIsinData()
        {
           
            var custRepo = new OgDataRepository(_settings, new Mock<ILogger>().Object);
            var isins = custRepo.GetEuExemptedIsins();

            Assert.IsTrue(isins.Any());
        }

        [Test]
       // [TestCase(701, "TCSA3 BZ", 15, 0, 100, "", ComplianceAlertLevel.ComplianceOverrideable, "Bulgaria: Long Ownership Filing")]
       // [TestCase(229105, "RTL LX", 15, 0, 100, "LU0061462528", ComplianceAlertLevel.ComplianceOverrideable, "Cayman Islands: Long Ownership Filing")]
       // [TestCase(3858, "BWP", 23000000, 0, 100, "US0966271043",  ComplianceAlertLevel.Restricted, "BWP Ownership Limit")]
       // [TestCase(3858, "CPS", 7, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Max 4.75% Shares Outstanding-CPS")]
       // [TestCase(3858, "CCL", 23000000, 0, 100, "US0966271043", ComplianceAlertLevel.Restricted, "CCL Ownership Limit")]
       // [TestCase(3858, "CCXI", 23000000, 0, 100, "US0966271043", ComplianceAlertLevel.Restricted, "CCXI Ownership Limit")]
        [TestCase(5326, "FDR FP", 5, 0, 100, "FR0000064578", ComplianceAlertLevel.ComplianceOverrideable, "France:Takeover Filing")]
        [TestCase(699, "TCM CN", 6, 0, 100, "CA8847681027", ComplianceAlertLevel.ComplianceOverrideable, "Canada: Takeover Filing")]
        [TestCase(1933, "1044 HK", 6, 0, 100, "KYG4402L1510", ComplianceAlertLevel.ComplianceOverrideable, "Hong Kong: Takeover Filing")]
        [TestCase(6938, "KYG ID", 2, 0, 100, "IE0004906560", ComplianceAlertLevel.ComplianceOverrideable, "Ireland: Takeover Filing")]
        [TestCase(3070, "ANA SM", 2, 0, 100, "ES0125220311", ComplianceAlertLevel.ComplianceOverrideable, "Spain: Takeover Filing")]
        [TestCase(503, "STMN SW", 5, 0, 100, "CH0012280076", ComplianceAlertLevel.ComplianceOverrideable, "Switzerland: Takeover Filing")]
        [TestCase(1077, "UBI IM", 10, 0, 100, "IT0003487029", ComplianceAlertLevel.ComplianceOverrideable, "Italy: Takeover Filing")]
        [TestCase(287, "SMIN LN", 2, 0, 100, "GB00B1WY2338", ComplianceAlertLevel.ComplianceOverrideable, "United Kingdom: Takeover Filing")]
        [TestCase(229105, "RTL LX", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Luxembourg: Long Ownership Filing")]
        [TestCase(198, "SIA SP", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Singapore: Long Ownership Filing")]
        [TestCase(1813, "002380 KS", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "South Korea: Long Ownership Filing")]
        [TestCase(1933, "1044 HK", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Hong Kong: Long Ownership Filing")]
        [TestCase(1156, "UPM1V FH", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Finland: Long Ownership Filing")]
        [TestCase(2022, "1801 JP", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Japan: Long Ownership Filing")]
        [TestCase(5395, "FLS DC", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Denmark: Long Ownership Filing")]
        [TestCase(503, "STMN SW", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Switzerland: Long Ownership Filing")]
        [TestCase(2695, "ABI BB", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Belgium: Long Ownership Filing")]
        [TestCase(186599, "FSF NZ", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "New Zealand: Long Ownership Filing")]
        [TestCase(2897, "AH NA", 6, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Netherlands: Long Ownership Filing")]
        [TestCase(3070, "ANA SM", 5, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Spain: Long Ownership Filing")]
        [TestCase(1717, "YAR NO", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Norway: Long Ownership Filing")]
        [TestCase(701, "TCSA3 BZ", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Brazil: Long Ownership Filing")]
        [TestCase(5326, "FDR FP", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "France: Long Ownership Filing")]
        [TestCase(1077, "UBI IM", 13, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Italy: Long Ownership Filing")]
        [TestCase(5167, "ETE GA", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Greece: Long Ownership Filing")]
        [TestCase(5167, "ETE GA", 1, 0, 100, "GRS003003027", ComplianceAlertLevel.ComplianceOverrideable, "Greece: Takeover Filing")]
        [TestCase(3805, "BRS", 10, 0, 100, "US1103941035", ComplianceAlertLevel.ComplianceOverrideable, "Greece: Takeover Filing")]
        [TestCase(579, "SWMA SS", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Sweden: Long Ownership Filing")]
        [TestCase(1525, "WIE AV", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Austria: Long Ownership Filing")]
        [TestCase(508, "STO AU", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Australia: Long Ownership Filing")]
        [TestCase(699, "TCM CN", 16, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "Canada: Long Ownership Filing")]
        [TestCase(287, "SMIN LN", 5, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "United Kingdom: Long Ownership Filing")]
        [TestCase(203, "SID", 15, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "United States: Long Ownership Filing (13G)")]
        [TestCase(129346, "EXX1 TH", 10, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "ETF Long Ownership Filing")]
        [TestCase(319, "SNH", 10, 0, 100, "Equity", ComplianceAlertLevel.ComplianceOverrideable, "REITs Ownership Restriction(Long)")]
        [TestCase(125835, "BOL SS", 0, 10, 100, "SE0000869646", ComplianceAlertLevel.ComplianceOverrideable, "European Union: Short Ownership Filing (BAM)")]
        public void EnsureAllImplementation(int securityId, string displayCode, int longPos, int shortPos,
            int sharesoutstanding, string ISIN, ComplianceAlertLevel expected, string ruleName)
        {
            //set position provider
            var positionProvider = new Mock<IPositionProvider>();
            positionProvider.Setup(n => n.GetFirmWideQuantity(It.IsAny<string>(), It.IsAny<PositionType>(), SideType.Long))
                .Returns(Tuple.Create("test", (decimal?) longPos));
            positionProvider.Setup(n => n.GetFirmWideQuantity(It.IsAny<string>(), It.IsAny<PositionType>(), SideType.Net))
               .Returns(Tuple.Create("test", (decimal?)longPos + shortPos));
            positionProvider.Setup(n => n.GetFirmWideQuantity(It.IsAny<string>(), It.IsAny<PositionType>(),SideType.Short))
                .Returns(Tuple.Create("test", (decimal?) shortPos));
            positionProvider.Setup(
                n => n.GetEntityWideQuantityByIsin(It.IsAny<string>(),PositionType.Sod,  It.IsAny<string>(),  SideType.Net)).Returns(Tuple.Create("test", (decimal?)longPos - shortPos));

            //set up market data provider
            var marketProvider = new Mock<IMarketDataProvider>();
            marketProvider.Setup(n => n.GetSharesOutstanding(It.IsAny<string>())).Returns(sharesoutstanding);
            marketProvider.Setup(n => n.GetCustomizedShareOutstanding(It.IsAny<string>()))
                .Returns(sharesoutstanding);
            //set up fact provider
            var factProvider = new Mock<IFactProvider>();
            factProvider.Setup(n => n.GetList(It.IsAny<string>())).Returns(new HashSet<string>() {ISIN});

           
            var providerRuleResult = new Mock<IOwnershipRuleResultProvider>();
            providerRuleResult.Setup(n => n.GetRuleResult(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
                .Returns(new RuleResult());


            var customdDataProvider = new Mock<ICustomDataProvider>();
            customdDataProvider.Setup(c => c.IsEuExempted(It.IsAny<string>())).Returns(true);

            //register instances
            var security = _securities.FirstOrDefault(s => s.BamSymbol == displayCode);

            ((FirmPositionLimitPolicy)_policy).PopulateRules(new RuleRepository<ICompliancePosition>(_settings, new Mock<ILogger>().Object));

            var rulesRelated =
                _policy.Rules.FirstOrDefault(r => string.Compare(r.Name.Trim(), ruleName, StringComparison.InvariantCultureIgnoreCase) == 0);
            //
            Assert.NotNull(rulesRelated);

            var compliancePos = Factory.CreateCompliancePosition(_settings, security, _policy, true);
            compliancePos.SetupGet(p => p.PositionProvider).Returns(positionProvider.Object);
            compliancePos.SetupGet(p => p.MarketDataProvider).Returns(marketProvider.Object);
            compliancePos.SetupGet(p => p.FactProvider).Returns(factProvider.Object);
            compliancePos.SetupGet(p => p.RuleResultProvider).Returns(providerRuleResult.Object);
            compliancePos.SetupGet(p => p.CustomDataProvider).Returns(customdDataProvider.Object);

            var result = rulesRelated.CheckViolation(compliancePos.Object, false);
            //
            Assert.IsTrue(result.AlertLevel == expected);
        }
    }
}
