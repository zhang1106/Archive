﻿using Bam.EventQ.Sequencing;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Workflow
{
    public interface IHandle<in TIn> : IWorkflow<TIn, IMessage> where TIn : class
    {
    }
}
