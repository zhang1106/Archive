﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Persistence.Compliance
{
    public interface IDwRepository
    {
        ILookup<string, Constituent> GetConstitents();
        Dictionary<string, string> GetPmRegionMapping();
        Dictionary<string, decimal> GetCustomSharesOutstandings();
        Dictionary<string, MarketData> GetMarketData();
        HashSet<string> GetEuMonitoredIsins();
        IEnumerable<DtdPosition> GetEodPositions(DateTime date);
        IDictionary<string, HashSet<string>> GetCustomMergeSymbols();
     }
}
