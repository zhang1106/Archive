﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.OrderRouting.Contracts
{
    public interface IEmsBaseAdapter : IDisposable
    {
        /// <summary>
        /// Initiate connection to EMS
        /// </summary>
        /// <returns>Returns true if connection is successful. False otherwise.</returns>
        bool Connect();

        /// <summary>
        /// Disconnect from EMS
        /// </summary>
        void Disconnect();

        /// <summary>
        /// Gets the current business date. This can also be used to determine if the EMS rolled.
        /// </summary>
        /// <returns></returns>
        DateTime GetBusinessDate();

        event Action<string> Connected;

        event Action<string> Disconnected;

        event Action<string> RollStarted;

        event Action<string> RollCompleted;

        event Action<IEnumerable<IOrder>> OrderStatusChanged;
    }
}
