﻿using System.CodeDom;
using System.Linq;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using Newtonsoft.Json;

namespace Bam.Oms.Compliance.Policies
{
    public class FirmPositionLimitPolicy: Policy<CompliancePosition>, IFirmPositionLimitPolicy 
    {
        private readonly IRuleResultRepository _ruleResultRepository;
        private readonly IRuleRepository<CompliancePosition> _ruleRepository;
        public FirmPositionLimitPolicy(IRuleResultRepository ruleResultRepository,
            IRuleRepository<CompliancePosition> ruleRepository)
        {
            _ruleRepository = ruleRepository;
            _ruleResultRepository = ruleResultRepository;
        }
        public override void AddRule(IRule<CompliancePosition>  rule)
        {
            if (!(rule is FirmRuleBase))
            {
                var mRule = (FirmRuleBase) ConvertBaseToChild.Map(rule);
                mRule.Init();
                base.AddRule(mRule);
            }
            else
            {
                base.AddRule(rule);
            }
        }
        public void PopulateRules()
        {
            foreach(var rule in _ruleRepository.GetRules(Id))
            {
                this.AddRule(rule);
            }
        }
        public override IPolicyResult CheckViolations(CompliancePosition input, bool isPreCheck)
        {
            PolicyResult result = new PolicyResult() { PolicyId = Id, PolicyName = Name };
            ISecurity security = input.Security;
            foreach (var rule in Rules.Where(r=>((FirmRuleBase)r).SecurityFilter == null
            || ((FirmRuleBase)r).SecurityFilter.ApplyFilter(r.GetType().FullName, security)))
             //   foreach (var rule in Rules)
              {
                var ruleResult = (RuleResult)rule.CheckViolation(input, false);
                ruleResult.PolicyId = this.Id;
                result.Alerts.Add(ruleResult);
                if (ruleResult.AlertLevel != ComplianceAlertLevel.NoViolation && ruleResult.AlertLevel != ComplianceAlertLevel.NotApplicable)
                {
                    ruleResult.ParamsInJson = JsonConvert.SerializeObject(ruleResult);
                    var cResult = (RuleResult) ruleResult.Clone();
                    _ruleResultRepository.Save(cResult);
                }
            }
            return result;
        }
    }
}
