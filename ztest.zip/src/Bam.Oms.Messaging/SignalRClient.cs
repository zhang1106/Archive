﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR.Client;

namespace Bam.Oms.Messaging
{
    public class SignalRClient<T> : IMessagingClient<T>, IDisposable
    {
        private readonly List<ParameterString> _filterParameters;
        private readonly IConnection _hubConnection;
        private readonly IHubProxy<ISignalRHub, ISignalRClient<T>> _hubProxy;

        public SignalRClient(IConnection connection, IHubProxy<ISignalRHub, ISignalRClient<T>> hubProxy)
        {
            if (connection == null) throw new ArgumentNullException(nameof(connection));
            if (hubProxy == null) throw new ArgumentNullException(nameof(hubProxy));

            _hubConnection = connection;
            _hubProxy = hubProxy;
            _filterParameters = new List<ParameterString>();

            RegisterCallback();

            //this is only in place for the unit testing
            var reconnectableHub = connection as HubConnection;
            if (reconnectableHub != null)
                reconnectableHub.Reconnected += ReApplyFilters;
        }

        public void Dispose()
        {
            _hubConnection.Stop();
        }

        public Action<T> ReceiveMessageCallback { get; set; }


        public Task ApplyFilter(IEnumerable<ParameterString> criteria)
        {
            var parameterStrings = criteria as IList<ParameterString> ?? criteria.ToList();
            _filterParameters.AddRange(parameterStrings);
            return _hubProxy.CallAsync(r => r.AddFilter(parameterStrings.ToArray()));
        }

        public Task RemoveFilter()
        {
            _filterParameters.Clear();
            return _hubProxy.CallAsync(r => r.RemoveFilter());
        }

        public Task Ping()
        {
            return _hubProxy.CallAsync(r => r.Ping());
        }

        public event Action OrderGatewayInitialized;

        public event Action<DateTime> SodRollCompletedOnGateway;


        public long LastPong { get; set; }

        private void RegisterCallback()
        {
            _hubProxy.SubscribeOn<T>(hub => hub.ReceiveMessage, order => ReceiveMessageCallback?.Invoke(order));
            _hubProxy.SubscribeOn<long>(hub => hub.Pong, ticks => LastPong = ticks);
            _hubProxy.SubscribeOn(hub => hub.OrderGatewayInitializedMessage, OnOrderGatewayInitialized);
            _hubProxy.SubscribeOn<DateTime>(hub => hub.SodRolledMessage, dt => SodRollCompletedOnGateway?.Invoke(dt));
        }

        private void ReApplyFilters()
        {
            ApplyFilter(_filterParameters); //need to batch this
        }

        private void OnOrderGatewayInitialized()
        {
            OrderGatewayInitialized?.Invoke();
        }
    }
}