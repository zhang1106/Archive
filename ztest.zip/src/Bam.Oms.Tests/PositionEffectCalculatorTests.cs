﻿using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.PositionTracker;
using FluentAssertions;
using NUnit.Framework;
using Ploeh.AutoFixture;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class PositionEffectCalculatorTests
    {
        [Test]
        public void VerifyOmniOrderEffects()
        {
            // arrange
            var fixture = new Fixture();
            var sut = new PositionEffectCalculator();
            var set = Helper.CreatePositionSet();
            var order = fixture.Create<Order>();
            order.Size = 1000;
            order.Side = SideType.Buy;
            order.OrderStatus = BamOrderStatus.Working;
            order.Custodian = "OMNI-test";
            var trade = fixture.Create<BlockTrade>();
            trade.TradeStatus= BamTradeStatus.Modified;
            trade.TradedQuantity = 500;
            // act
            sut.ApplyEffects(set, null, null, order, trade);
            // assert
            set.Position.TheoreticalQuantity.Should().Be(1000);
            set.Position.ActualQuantity.Should().Be(500);
            set.Position.LongMarkingQuantity.Should().Be(0);
            set.Position.ShortMarkingQuantity.Should().Be(0);
        }
        
        [Test]
        public void VerifyNewOrderForNewPosition()
        {
            // arrange
            var fixture = new Fixture();
            var sut = new PositionEffectCalculator();
            var set = Helper.CreatePositionSet();
            var order = fixture.Create<Order>();
            order.Size = 1000;
            order.Side = SideType.Buy;
            order.OrderStatus = BamOrderStatus.New;

            // act
            sut.ApplyEffects(set, null, null, order, null);

            // assert
            set.Position.TheoreticalQuantity.Should().Be(1000);
            set.Position.ActualQuantity.Should().Be(0);
            set.Position.LongMarkingQuantity.Should().Be(1000);
            set.Position.ShortMarkingQuantity.Should().Be(0);
        }

        [Test]
        public void VerifyFirstFillForOrder()
        {
            // arrange
            var fixture = new Fixture();
            var sut = new PositionEffectCalculator();
            var set = Helper.CreatePositionSet();

            var order = fixture.Create<Order>();
            order.Size = 1000;
            order.Side = SideType.Buy;
            order.OrderStatus = BamOrderStatus.New;

            var trade = fixture.Create<BlockTrade>();
            trade.Side = SideType.Buy;
            trade.TradedQuantity = 500;

            // act
            sut.ApplyEffects(set, null, null, order, trade);

            // assert
            set.Position.TheoreticalQuantity.Should().Be(1000);
            set.Position.ActualQuantity.Should().Be(500);
            set.Position.LongMarkingQuantity.Should().Be(1000);
            set.Position.ShortMarkingQuantity.Should().Be(500);
        }

        [Test]
        public void VerifyTwoFillsForOrder()
        {
            // arrange
            var fixture = new Fixture();
            var sut = new PositionEffectCalculator();
            var set = Helper.CreatePositionSet();

            var order = fixture.Create<Order>();
            order.Size = 1000;
            order.Side = SideType.Buy;
            order.OrderStatus = BamOrderStatus.New;

            var trade1 = fixture.Create<BlockTrade>();
            trade1.Side = SideType.Buy;
            trade1.TradedQuantity = 500;

            var trade2 = fixture.Create<BlockTrade>();
            trade2.Side = SideType.Buy;
            trade2.TradedQuantity = 700;

            // act
            sut.ApplyEffects(set, null, null, order, trade1);
            sut.ApplyEffects(set, order, trade1, order, trade2);

            // assert
            set.Position.TheoreticalQuantity.Should().Be(1000);
            set.Position.ActualQuantity.Should().Be(700);
            set.Position.LongMarkingQuantity.Should().Be(1000);
            set.Position.ShortMarkingQuantity.Should().Be(700);
        }

        [Test]
        public void VerifyCancelPartiallyFilledOrder()
        {
            // arrange
            var fixture = new Fixture();
            var sut = new PositionEffectCalculator();
            var set = Helper.CreatePositionSet();

            var order = fixture.Create<Order>();
            order.Size = 1000;
            order.Side = SideType.Buy;
            order.OrderStatus = BamOrderStatus.New;

            var trade1 = fixture.Create<BlockTrade>();
            trade1.Side = SideType.Buy;
            trade1.TradedQuantity = 500;

            var order2 = fixture.Create<Order>();
            order2.Size = 1000;
            order2.Side = SideType.Buy;
            order2.OrderStatus = BamOrderStatus.Cancelled;

            // act
            sut.ApplyEffects(set, null, null, order, trade1);
            sut.ApplyEffects(set, order, trade1, order2, trade1);

            // assert
            set.Position.TheoreticalQuantity.Should().Be(500);
            set.Position.ActualQuantity.Should().Be(500);
            set.Position.LongMarkingQuantity.Should().Be(500);
            set.Position.ShortMarkingQuantity.Should().Be(500);
        }

        [Test]
        public void VerifyCancelOrder()
        {
            // arrange
            var fixture = new Fixture();
            var sut = new PositionEffectCalculator();
            var set = Helper.CreatePositionSet();
            set.Position.ActualQuantity = 1000;
            set.Position.TheoreticalQuantity = 1000;
            set.Position.ShortMarkingQuantity = 1000;
            set.Position.LongMarkingQuantity = 1000;

            var order = fixture.Create<Order>();
            order.Size = 1000;
            order.Side = SideType.Buy;
            order.OrderStatus = BamOrderStatus.New;

            var order2 = fixture.Create<Order>();
            order2.Size = 1000;
            order2.Side = SideType.Buy;
            order2.OrderStatus = BamOrderStatus.Cancelled;

            // act
            sut.ApplyEffects(set, null, null, order, null);
            sut.ApplyEffects(set, order, null, order2, null);

            // assert
            set.Position.TheoreticalQuantity.Should().Be(1000);
            set.Position.ActualQuantity.Should().Be(1000);
            set.Position.LongMarkingQuantity.Should().Be(1000);
            set.Position.ShortMarkingQuantity.Should().Be(1000);
        }

        [Test]
        public void VerifyCrossingSide()
        {
            // arrange
            var sut = new PositionEffectCalculator();
            var set = Helper.CreatePositionSet(
                new Portfolio("KRAM", "GENERALIST", "M1US")
                {
                    AggregationUnit = "AQTF",
                    ComplianceGroup = "KKR1"
                }, 
                new Security
                {
                    BamSymbol = "BCR"
                }, 
                "MSCO");

            set.Position.ActualQuantity = 13;
            set.Position.TheoreticalQuantity = 13;
            set.Position.ShortMarkingQuantity = 13;
            set.Position.LongMarkingQuantity = 13;

            var order1 = new Order
            {
                Portfolio = set.Position.Portfolio,
                Security = set.Position.Security,
                Custodian = set.Position.CustodianName,
                Side = SideType.Sell,
                Size = 13,
                OrderStatus = BamOrderStatus.New
            };

            var order2 = new Order
            {
                Portfolio = set.Position.Portfolio,
                Security = set.Position.Security,
                Custodian = set.Position.CustodianName,
                Side = SideType.SellShort,
                Size = 10,
                OrderStatus = BamOrderStatus.New
            };

            // act
            sut.ApplyEffects(set, null, null, order1, null);
            sut.ApplyEffects(set, null, null, order2, null);

            // assert
            set.Position.ActualQuantity.Should().Be(13);
            set.Position.TheoreticalQuantity.Should().Be(-10);
            set.Position.ShortMarkingQuantity.Should().Be(-10);
            set.Position.LongMarkingQuantity.Should().Be(13);
        }

        [Test]
        public void VerifyCancelSideChange()
        {
            // arrange
            var fixture = new Fixture();
            var sut = new PositionEffectCalculator();
            var set = Helper.CreatePositionSet();
            set.Position.ActualQuantity = -1000;
            set.Position.TheoreticalQuantity = -1000;
            set.Position.ShortMarkingQuantity = -1000;
            set.Position.LongMarkingQuantity = -1000;

            var order1v1 = fixture.Create<Order>();
            order1v1.Size = 1000;
            order1v1.Side = SideType.Cover;
            order1v1.OrderStatus = BamOrderStatus.New;

            var order2v1 = fixture.Create<Order>();
            order2v1.Size = 1000;
            order2v1.Side = SideType.Buy;
            order2v1.OrderStatus = BamOrderStatus.New;

            var order1v2 = fixture.Create<Order>();
            order1v1.ClientOrderId = "1";
            order1v2.Size = 1000;
            order1v2.Side = SideType.Buy;
            order1v2.OrderStatus = BamOrderStatus.Cancelled;

            var order2v2 = fixture.Create<Order>();
            order1v1.ClientOrderId = "2";
            order2v2.Size = 1000;
            order2v2.Side = SideType.Cover;
            order2v2.OrderStatus = BamOrderStatus.Cancelled;

            // act
            sut.ApplyEffects(set, null, null, order1v1, null);
            sut.ApplyEffects(set, null, null, order2v1, null);

            // assert
            set.Position.TheoreticalQuantity.Should().Be(1000);
            set.Position.ActualQuantity.Should().Be(-1000);
            set.Position.LongMarkingQuantity.Should().Be(1000);
            set.Position.ShortMarkingQuantity.Should().Be(-1000);

            // more acting
            sut.ApplyEffects(set, order1v1, null, order1v2, null);
            sut.ApplyEffects(set, order2v1, null, order2v2, null);

            // assert
            set.Position.TheoreticalQuantity.Should().Be(-1000);
            set.Position.ActualQuantity.Should().Be(-1000);
            set.Position.LongMarkingQuantity.Should().Be(-1000);
            set.Position.ShortMarkingQuantity.Should().Be(-1000);
        }
    }
}
