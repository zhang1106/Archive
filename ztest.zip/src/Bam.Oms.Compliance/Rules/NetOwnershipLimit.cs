﻿using System;
using System.Runtime.InteropServices;
using Newtonsoft.Json;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Compliance.Results;
using BAM.Infrastructure.Ioc;
using BAM.Infrastructure.DataFlowLogging.Client;

namespace Bam.Oms.Compliance.Rules
{
    [JsonObject(MemberSerialization.OptIn)]
    public class NetOwnershipLimit : FirmRuleBase 
    {
        //rule specific
        [JsonProperty]
        public decimal Threshhold { get; set; }
        [JsonProperty]
        public string BamSymbol { get; set; }
        //
        readonly  IIntradayPositionProvider _intradayPositionProvider;
        
        public NetOwnershipLimit(IIntradayPositionProvider intradayPositionProvider, IFactProvider factProvider,
            ILogger logger, ILoggingAgent eventLogger) : base(factProvider, logger, eventLogger)
        {
            _intradayPositionProvider = intradayPositionProvider;
        }

        public override IRuleResult CheckViolation(CompliancePosition input, bool isPreCheck)
        {
            var result = new OwnershipLimitResult()
            {
                RuleId = this.Id,
                BamSymbol = input.BamSymbol,
                PolicyId = input.PolicyId,
                RuleName = this.Name,
                Description = "No violation",
                IsViolationOverriden = false,
                PositionQty = 0m,
                Type= typeof(OwnershipLimitResult).FullName,
                AlertLevel = ComplianceAlertLevel.NoViolation
            };
            var context = string.Empty;
            try
            {
                //appy filters first
                if (IsActive && String.Compare(BamSymbol, input.BamSymbol, StringComparison.OrdinalIgnoreCase) == 0)
                {
                    var netQuantityInfo = _intradayPositionProvider.GetFirmWideNetQuantity(input.BamSymbol);
                    var netQuantity = netQuantityInfo.Item2;
                    context = netQuantityInfo.Item1;
                    if (!netQuantity.HasValue)
                    {
                        result.AlertLevel = ComplianceAlertLevel.NoDataAvaiable;
                        result.Description = "Net Position not available";
                    }
                    else
                    {
                        result.AlertLevel = netQuantity.Value >= Threshhold ? ComplianceAlertLevel.Violated : ComplianceAlertLevel.NoViolation;
                        result.Description = result.AlertLevel == ComplianceAlertLevel.Violated ?
                            $"Going above {netQuantity.Value.ToString("N0")} Net Ownership"
                            : "No Violation";
                        result.PositionQty = netQuantity;
                    }
                   LogEvent(result.Key, context);
                }
            }catch(Exception ex)
            {
                result.AlertLevel = ComplianceAlertLevel.Error;
                result.Description = ex.Message;
                _logger.Error(ex.Message);
                LogErrorEvent(result.Key, context);
            }

            return result;
        }
    }
}
