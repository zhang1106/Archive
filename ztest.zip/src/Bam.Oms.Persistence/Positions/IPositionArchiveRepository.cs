﻿using Bam.Oms.Data.Positions;

namespace Bam.Oms.Persistence.Positions
{
    public interface IPositionArchiveRepository : IDBRepository<PositionArchive>
    {
        // Any Position Archive repository related methods to go here.
        void ArchivePositions (string stream);
    }
}