﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using SolaceSystems.Solclient.Messaging;

namespace Bam.EventQ.Solace
{
    public class KeyValuePairSolaceMessageSerializer<TItem> : ISolaceMessageSerializer<TItem>
    {
        private readonly IReadOnlyDictionary<string, string> _headers;
        private readonly Func<TItem, string> _serializer;
        private readonly Encoding _encoding;

        public KeyValuePairSolaceMessageSerializer(
            IReadOnlyDictionary<string, string> propToKeyMap,
            IReadOnlyDictionary<string, string> headers = null,
            string assignment = "=", string delimiter = "|")
        {
            _headers = headers ?? new Dictionary<string, string>();
            _serializer = CompileSerializer(propToKeyMap, assignment, delimiter);
            _encoding = new UTF8Encoding(false, false);
        }

        public void Serialize(IMessage target, TItem payload)
        {
            target.BinaryAttachment = _encoding.GetBytes(_serializer(payload));
            target.HttpContentType = "text/plain";
            target.HttpContentEncoding = "utf-8";

            foreach (var header in _headers)
            {
                if (target.UserPropertyMap == null)
                {
                    target.UserPropertyMap = target.CreateUserPropertyMap();
                }

                target.UserPropertyMap.AddString(header.Key, header.Value);
            }
        }

        private Func<TItem, string> CompileSerializer(
            IReadOnlyDictionary<string, string> propToKeyMap,
            string assignment, string delimiter)
        {
            var param = Expression.Parameter(typeof(TItem), "p");
            var stringBuilder = Expression.Constant(new StringBuilder(), typeof(StringBuilder));
            var assignmentExpr = Expression.Constant(assignment);
            var delimiterExpr = Expression.Constant(delimiter);

            var calls = new List<Expression>
            {
                Expression.Call(stringBuilder, typeof(StringBuilder).GetMethod(nameof(StringBuilder.Clear)))
            };

            int count = 0;
            foreach (var item in propToKeyMap)
            {
                count++;

                string path = item.Key;
                Expression pathBase = param;
                int index;
                while ((index = path.IndexOf('.')) >= 0)
                {
                    pathBase = Expression.PropertyOrField(param, path.Substring(0, index));
                    path = path.Substring(index + 1);
                }

                var prop = Expression.PropertyOrField(pathBase, path);
                MethodCallExpression stringProp;
                if (prop.Type == typeof(DateTime))
                {
                    stringProp = Expression.Call(prop,
                        prop.Type.GetMethod(nameof(ToString), new[] { typeof(string) }),
                        Expression.Constant("o"));
                }
                else
                {
                    stringProp = Expression.Call(prop,
                        typeof(TItem).GetMethod(nameof(ToString)));
                }

                var key = Expression.Constant(item.Value);
                var mi = typeof(StringBuilder).GetMethod(
                    nameof(StringBuilder.Append), new[] {typeof(string)});

                calls.Add(Expression.Call(stringBuilder, mi, key));
                calls.Add(Expression.Call(stringBuilder, mi, assignmentExpr));
                calls.Add(Expression.Call(stringBuilder, mi, stringProp));

                if (count < propToKeyMap.Count)
                {
                    calls.Add(Expression.Call(stringBuilder, mi, delimiterExpr));
                }
            }

            calls.Add(Expression.Call(stringBuilder, typeof(StringBuilder)
                .GetMethod(nameof(ToString), new Type[] { })));

            return Expression.Lambda<Func<TItem, string>>(
                Expression.Block(calls), param).Compile();
        }
    }
}
