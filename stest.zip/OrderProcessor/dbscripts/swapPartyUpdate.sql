USE OrderGatewayMain;



DELETE FROM dbo.SwapCounterparty;


INSERT INTO dbo.SwapCounterparty(Code, Name, IsStandard)
VALUES('MS','MSCO',1),
('JP','JPMC',1),
('UB','UBSW',1),
('CS','CSPB',1),
('BA','BAML',0),
('BC','BARC',0),
('BP','BNPS',0),
('CC','CICC',0),
('CI','CGMI',0),
('DB','DBAB',0),
('HS','HSBC',0),
('MQ','MACQ',0),
('NM','NMRA',0),
('SE','SEBB',0),
('SG','SOCG',0),
('WF','WFPB',0),
('GS','GSCO',1),
('CA','LYON',0)