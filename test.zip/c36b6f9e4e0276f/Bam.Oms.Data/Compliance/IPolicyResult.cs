﻿using System.Collections.Generic;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Data.Compliance
{
    public interface IPolicyResult
    {
        int PolicyId { get; set; }
        string PolicyName { get; set; }
        IList<IRuleResult> Alerts { get; set; }
        //highest violation level
        ComplianceAlertLevel AlertLevel { get; }
    }
}
