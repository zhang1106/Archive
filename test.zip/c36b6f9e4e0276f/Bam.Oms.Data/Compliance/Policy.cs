﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Filtering;

namespace Bam.Oms.Data.Compliance
{
    public class Policy<T> : IPolicy<T>
    {
        public string Key { get { return Id.ToString(); } }
        public int Id { get; set; }
        public string Name { get; set; }
        public  string Type{ get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }   //turn on/off a rule
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ParamsInJson { get; set; }

        public IList<IRule<T>> Rules { get;}

        public Policy()
        {
            Rules = new List<IRule<T>>();
        }

        public virtual void AddRule(IRule<T> t)
        {
            Rules.Add(t);
        }
        /// <summary>
        /// data repository needs a concrete class of Policy
        /// so will leave it for now
        public virtual void AddFilter(IFilter<T> filter)
        {
            throw new NotImplementedException();
        }
        /// data repository needs a concrete class of Policy
        /// so will leave it for now
        public virtual IPolicyResult CheckViolations(T input, bool isPreCheck)
        {
            throw new NotImplementedException();
        }
    }
}
