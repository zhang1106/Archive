﻿namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    public enum HeadroomIdentifierType
    {
        UnderlyingSymbol,
        Isin
    }
}
