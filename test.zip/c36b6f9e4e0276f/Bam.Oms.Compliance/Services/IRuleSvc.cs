﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Services
{
    public interface IRuleSvc
    {
        IList<Rule<CompliancePosition>> GetAll(int policyId);
    }
}
