﻿// ReSharper disable once CheckNamespace
namespace System
{
    public static class BufferExtensions
    {
        public static int ToInt32(this byte[] buffer, int index)
        {
            return buffer[index] << 24 |
                   buffer[index + 1] << 16 |
                   buffer[index + 2] << 8 |
                   buffer[index + 3] << 0;
        }

        public static long ToInt64(this byte[] buffer, int index)
        {
            return 
                (long)buffer[index] << 56 |
                (long)buffer[index + 1] << 48 |
                (long)buffer[index + 2] << 40 |
                (long)buffer[index + 3] << 32 |
                (long)buffer[index + 4] << 24 |
                (long)buffer[index + 5] << 16 |
                (long)buffer[index + 6] << 8 |
                (long)buffer[index + 7] << 0;
        }

        public static void CopyToBuffer(this int value, byte[] buffer, int index)
        {
            buffer[index] = (byte) ((value >> 24) & 0xFF);
            buffer[index + 1] = (byte) ((value >> 16) & 0xFF);
            buffer[index + 2] = (byte) ((value >> 8) & 0xFF);
            buffer[index + 3] = (byte) ((value >> 0) & 0xFF);
        }

        public static void CopyToBuffer(this long value, byte[] buffer, int index)
        {
            buffer[index] = (byte)((value >> 56) & 0xFF);
            buffer[index + 1] = (byte)((value >> 48) & 0xFF);
            buffer[index + 2] = (byte)((value >> 40) & 0xFF);
            buffer[index + 3] = (byte)((value >> 32) & 0xFF);
            buffer[index + 4] = (byte)((value >> 24) & 0xFF);
            buffer[index + 5] = (byte)((value >> 16) & 0xFF);
            buffer[index + 6] = (byte)((value >> 8) & 0xFF);
            buffer[index + 7] = (byte)((value >> 0) & 0xFF);
        }
    }
}
