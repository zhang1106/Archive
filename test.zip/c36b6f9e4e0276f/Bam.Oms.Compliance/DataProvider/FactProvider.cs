﻿using System.Collections.Generic;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance.DataProvider
{
    //need rewrite
    public class FactProvider : IFactProvider
    {
       private readonly IFactRepository _factRepository;
       private readonly IDwRepository _customDataRepository;
       private Dictionary<string, HashSet<string>> _factList;
    
       public FactProvider(IFactRepository factRepository, IDwRepository customDataRepository)
       {
           _factRepository = factRepository;
           _customDataRepository = customDataRepository;
       }
       public void RefreshData()
       {
            var list = _factRepository.GetAll();
            var factList = new Dictionary<string, HashSet<string>>();
            foreach (var fact in list)
            {
                if (factList.ContainsKey(fact.Name)) continue;
                factList.Add(fact.Name, fact.GetList());
            }
            factList.Add("EuIsinList", _customDataRepository.GetEuMonitoredIsins());
           
            _factList = factList;
           
       }
       public HashSet<string> GetList(string name)
       {
           return _factList.ContainsKey(name) ? _factList[name] : new HashSet<string>();
       }
    }
}
