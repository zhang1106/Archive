﻿
namespace Bam.Oms.OrderRouting.Contracts
{
    /// <summary>
    /// Contract that contains the connection information.  This will be injected into the IEmsRouter to allow unit testing
    /// </summary>
    public interface IEmsConnection
    {
        string Host { get; }
        int Port { get; }
        
    }
}