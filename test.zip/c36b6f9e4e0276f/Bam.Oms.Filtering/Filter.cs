﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace Bam.Oms.Filtering
{
    public class Filter<T> : IFilter<T>
    {
        private readonly ConcurrentDictionary<string, Tuple<ParameterBatch, Func<T, bool>>> _filters;
        private bool _isAndFilter;

        public Filter()
        {
            _filters = new ConcurrentDictionary<string, Tuple<ParameterBatch, Func<T, bool>>>();
        }


        private Func<T, ParameterBatch, bool> DelegateBuilder(ParameterBatch subject)
        {
            if (subject == null || !subject.Filters.Any()) //if there are no filter, then always return true
                return (i, filters) => true;

            //( item => ... )
            var item = Expression.Parameter(typeof(T), "item");

            //( filter => ... )
            var filter = Expression.Parameter(typeof(ParameterBatch), "filter");

            Expression finalExp = null;

           //enumerate through each filter, and apply it to the expression
            for (int i = 0; i < subject.Filters.Count; i++)
            {
                // ( ... item.Property ..)
                var itemProperty = Expression.Property(item, subject.Filters[i].Property);
                //todo: figure out other types of comparisons
                var method = subject.Filters[i].Operator.GetType().GetMethod(subject.Filters[i].Operator.OperatorType.ToString());

                var itemPropertyAsComparable = Expression.TypeAs(itemProperty, typeof(IComparable));
                var itemValueAsComparable = Expression.TypeAs(Expression.Constant(subject.Filters[i].Value), typeof(IComparable));


                if (method == null) throw new ArgumentNullException(
                    $"Cant find method {subject.Filters[i].Operator.OperatorType.ToString()}");
                var methodCall = Expression.Call(Expression.Constant(subject.Filters[i].Operator), method, itemPropertyAsComparable, itemValueAsComparable);

                if (finalExp == null)
                    finalExp = methodCall;
                else
                {
                    finalExp = _isAndFilter ? Expression.AndAlso(finalExp, methodCall) : Expression.OrElse(finalExp, methodCall);
                }
            }

            return Expression.Lambda<Func<T, ParameterBatch, bool>>(finalExp, item, filter).Compile();
        }

        public IEnumerable<Parameter> GetParameters(string id)
        {
            Tuple<ParameterBatch, Func<T, bool>> filterTuple;
            return _filters.TryGetValue(id, out filterTuple) ? filterTuple.Item1.Filters : null;
        }

        public void AddToFilter(string id, IEnumerable<Parameter> criteria)
        {
            AddToFilter(id, criteria, true);
        }

        public void AddToFilter(string id, IEnumerable<Parameter> criteria, bool isAndFilter)
        {
            if (criteria == null) throw new ArgumentNullException(nameof(criteria));

            _isAndFilter = isAndFilter;

            Tuple<ParameterBatch, Func<T, bool>> filterFunc;
            var filterList = !_filters.TryGetValue(id, out filterFunc) ? new ParameterBatch() : filterFunc.Item1;

            //always clear the previous set of filters.  For now we'll only allow a batch of filters to be submitted at once
            //this exists to keep the UI from getting too many back to back updates (update on clear and update on re-apply)
            filterList.Filters.Clear();

            foreach (var filterCriteria in criteria)
            {
                if (string.IsNullOrWhiteSpace(filterCriteria.Property)) throw new ArgumentNullException(nameof(filterCriteria.Property));
                if (filterCriteria.Value == null) throw new ArgumentNullException(nameof(filterCriteria.Value));
                filterList.Filters.Add(filterCriteria);
            }

            var filterDelegate = DelegateBuilder(filterList);
            Func<T, bool> filter = (item) => filterDelegate(item, filterList);

            var newFilter = new Tuple<ParameterBatch, Func<T, bool>>(filterList, filter);
            _filters[id] = newFilter;

            FilterChanged?.Invoke(id);
        }

        public IEnumerable<string> ApplyFilter(T item)
        {
            var connectionMatches = new List<string>();

            foreach (var filter in _filters)
            {
                if (filter.Value.Item2(item))
                    connectionMatches.Add(filter.Key);
            }

            return connectionMatches;
        }

        public bool ApplyFilter(string id, T item)
        {
            Tuple<ParameterBatch, Func<T, bool>> filterTuple;
            if (_filters.TryGetValue(id, out filterTuple))
            {
                return filterTuple.Item2(item);
            }

            return true;
        }

        public void ClearFilter(string id)
        {
            Tuple<ParameterBatch, Func<T, bool>> filterFunc;
            if (_filters.TryRemove(id, out filterFunc))
            {
                var filterDelegate = DelegateBuilder(null);
                Func<T, bool> filter = (item) => filterDelegate(item, null);
                _filters[id] = new Tuple<ParameterBatch, Func<T, bool>>(new ParameterBatch(), filter);
            }

            FilterChanged?.Invoke(id);
        }

        public event Action<string> FilterChanged;
        public IReadOnlyCollection<string> ClientConnectionIds => _filters.Keys.ToList();
    }
}