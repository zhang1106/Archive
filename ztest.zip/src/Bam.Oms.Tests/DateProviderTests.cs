﻿using System;
using Bam.Oms.Data.Configuration;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class DateProviderTests
    {
        [TestCase("18:00:10",10)]        
        public void TestSodTimeLandsOnSatRevertsToFriday(string time, int seconds)
        {
            // arrange
            var now = new DateTime(2015, 12, 26, 0, 0, 0); //sat            
            var settings = new Mock<ISettings>();
            settings.SetupGet(pos => pos.DefaultSODDateTime).Returns(DateTime.Today.AddHours(18));

            var util = new DateProvider();

            // act
            var unit = util.SetSodTime(time, now);

            // assert
            Assert.That(unit, Is.EqualTo(new DateTime(2015, 12, 25, 18, 0, seconds)));
        }

        [TestCase("18:00:10", 10)]        
        public void TestSodTimeLandsOnSunRevertsToFriday(string time, int seconds)
        {
            // arrange
            var now = new DateTime(2015, 12, 27, 0, 0, 0); //sat
            var settings = new Mock<ISettings>();
            settings.SetupGet(pos => pos.DefaultSODDateTime).Returns(DateTime.Today.AddHours(18));

            var util = new DateProvider();

            // act
            var unit = util.SetSodTime(time, now);

            // assert
            Assert.That(unit, Is.EqualTo(new DateTime(2015, 12, 25, 18, 0, seconds)));
        }

        [TestCase("18:00:10", 10)]            
        public void TestSodTimeLandsOnMonRevertsToFriday(string time, int seconds)
        {
            // arrange
            var now = new DateTime(2015, 12, 28, 11, 0, 0); //Mon
            var settings = new Mock<ISettings>();
            settings.SetupGet(pos => pos.DefaultSODDateTime).Returns(DateTime.Today.AddHours(18));

            var util = new DateProvider();

            // act
            var unit = util.SetSodTime(time, now);

            // assert
            Assert.That(unit, Is.EqualTo(new DateTime(2015, 12, 25, 18, 0, seconds)));
        }

        [TestCase("18:00:10", 10)]        
        public void TestSodTimeLandsOnMonAfterRollTime(string time, int seconds)
        {
            // arrange
            var now = new DateTime(2015, 12, 28, 19, 0, 0); //monday
            var settings = new Mock<ISettings>();
            settings.SetupGet(pos => pos.DefaultSODDateTime).Returns(DateTime.Today.AddHours(18));

            var util = new DateProvider();

            // act
            var unit = util.SetSodTime(time, now);

            // assert
            Assert.That(unit, Is.EqualTo(new DateTime(2015, 12, 28, 18, 0, seconds)));
        }

        [TestCase("18:00:10", 10)]        
        public void TestSodTimeRollBeforeRollTime(string time, int seconds)
        {
            // arrange
            var now = new DateTime(2015, 12, 29, 11, 0, 0); //Tuesday
            var settings = new Mock<ISettings>();
            settings.SetupGet(pos => pos.DefaultSODDateTime).Returns(DateTime.Today.AddHours(18));

            var util = new DateProvider();

            // act
            var unit = util.SetSodTime(time, now);

            // assert
            Assert.That(unit, Is.EqualTo(new DateTime(2015, 12, 28, 18, 0, seconds)));
        }

        [TestCase("18:00:10", 10)]        
        public void TestSodTimeRollAfterRollTime(string time, int seconds)
        {
            // arrange
            var now = new DateTime(2015, 12, 29, 19, 0, 0); //Tuesday
            var settings = new Mock<ISettings>();
            settings.SetupGet(pos => pos.DefaultSODDateTime).Returns(DateTime.Today.AddHours(18));

            var util = new DateProvider();

            // act
            var unit = util.SetSodTime(time, now);

            // assert
            Assert.That(unit, Is.EqualTo(new DateTime(2015, 12, 29, 18, 0, seconds)));
        }

        [TestCase("18:00:10", 10)]        
        public void TestSodTimeRollBeforeRollTimeFriday(string time, int seconds)
        {
            // arrange
            var now = new DateTime(2016, 1, 1, 11, 0, 0); //Friday
            var settings = new Mock<ISettings>();
            settings.SetupGet(pos => pos.DefaultSODDateTime).Returns(DateTime.Today.AddHours(18));

            var util = new DateProvider();

            // act
            var unit = util.SetSodTime(time, now);

            // assert
            Assert.That(unit, Is.EqualTo(new DateTime(2015, 12, 31, 18, 0, seconds)));
        }

        [TestCase("18:00:10", 10)]        
        public void TestSodTimeRollAfterRollTimeFriday(string time, int seconds)
        {
            // arrange
            var now = new DateTime(2016, 1, 1, 19, 0, 0); //Friday
            var settings = new Mock<ISettings>();
            settings.SetupGet(pos => pos.DefaultSODDateTime).Returns(DateTime.Today.AddHours(18));

            var util = new DateProvider();

            // act
            var unit = util.SetSodTime(time, now);

            // assert
            Assert.That(unit, Is.EqualTo(new DateTime(2016, 1, 1, 18, 0, seconds)));
        }
    }
}