﻿using System.Collections.Generic;
using Bam.EventQ.Snapshot;

namespace Bam.Oms.OrderGateway.EzeGateway.Models.Snapshot
{
    public class SplitStrategyOrdersSnapshot : ISnapshot
    {
        public Dictionary<long, string> Items { get; } = new Dictionary<long, string>();
    }
}
