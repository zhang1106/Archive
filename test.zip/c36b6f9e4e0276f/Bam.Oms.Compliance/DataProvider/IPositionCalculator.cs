﻿using System;
using System.Linq;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface IPositionCalculator
    {
        Tuple<string, decimal?> GetFirmWideQuantityByUnderlying(string underlying, SideType side, ILookup<string, IPosition> positionsByUnderlying);

        Tuple<string, decimal?> GetFirmWideQuantityByUnderlyingWithAdr(string underlying, SideType side, ILookup<string, IPosition> positionsByUnderlying);

        Tuple<string, decimal?> GetEntityWideQuantityByIsin(string symbol, SideType side, string entity, ILookup<string, IPosition> decomposedbyIsin);
    }
}
