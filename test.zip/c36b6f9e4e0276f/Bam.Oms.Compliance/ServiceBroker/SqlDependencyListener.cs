﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Positions;
using System.Data.SqlClient;
using System.Linq;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.ServiceBroker
{
    public enum MonitorTarget
    {
        SodMonitor,
        EodAqtfMonitor,
        EodMainMonitor
    }

    public class SqlDependencyListener : IServiceBrokerListener
    {
        private string _connectionString;
        private readonly IOgDataRepository _customDataRepository;
        private readonly ILogger _logger;
        private readonly ISettings _settings;

        public string SodMonitor
            =>
            $"SELECT ActionLogId From sod.ActionLog where (ActionDetails = 'Publish loaded positions' or ActionDetails='Saving positions to CSV')"
            ;

        public string EodAqtfMonitor => $"SELECT tradedate From og.EodPosition";
        public string EodMainMonitor => $"SELECT tradedate From og.EodPosition2";

        public SqlDependencyListener(IOgDataRepository customDataRepository,   ILogger logger, ISettings settings)
        {
            _customDataRepository = customDataRepository;
            _logger = logger;
            _settings = settings;
        }

        public string Query { get; set; }

        public event Action<IList<IPosition>> SodPositionChanged;
        public event Action Positionchanged;

        public void Start(string connectionString, MonitorTarget target)
        {
            if (!_settings.EnableSqlMonitoring) return;

            _connectionString = connectionString;
            // Create a dependency connection.  
            switch (target)
            {
                case MonitorTarget.SodMonitor:
                    Query = SodMonitor;
                    break;
                case MonitorTarget.EodAqtfMonitor:
                    Query = EodAqtfMonitor;
                    break;
                case MonitorTarget.EodMainMonitor:
                    Query = EodMainMonitor;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(target), target, null);
            }

            SqlDependency.Start(_connectionString);
            ListenToEvents();
        }

        public void Stop()
        {
            SqlDependency.Stop(_connectionString);
        }


        private void ListenToEvents()
        {
            // Assume connection is an open SqlConnection.  
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Create a new SqlCommand object.  
                using (var command = new SqlCommand(Query, connection))
                {
                    // Create a dependency and associate it with the SqlCommand.  
                    var dependency = new System.Data.SqlClient.SqlDependency(command);
                    // Maintain the refence in a class member.  

                    // Subscribe to the SqlDependency event.  
                    dependency.OnChange += new OnChangeEventHandler(OnDependencyChange);
                    // Execute the command.  
                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.HasRows) return;

                        // Process the DataReader.  
                        reader.Read();
                        // Process the DataReader.  
                    }

                }
            }
        }

        // Handler method  
        private void OnDependencyChange(object sender,
            SqlNotificationEventArgs e)
        {
            try
            {
                Positionchanged?.Invoke();
            }
            catch (Exception ex)
            {
                
                _logger.Error(ex.Message);
            }
            
            ListenToEvents();
        }
    }
}
