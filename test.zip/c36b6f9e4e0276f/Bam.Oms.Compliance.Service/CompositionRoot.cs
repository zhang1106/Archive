﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http.Dependencies;
using Bam.Compliance.Infrastructure.Hosting;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Persistence.Journal;
using Bam.Oms.Persistence.Securities;
using Bam.Oms.Persistence.Serialization;
using BAM.Infrastructure.Ioc;
using StructureMap;
using ProtoBuf.Meta;
using Container = StructureMap.Container;
 

namespace Bam.Oms.Compliance.Service
{
    public class CompositionRoot : ICompositionRoot<IService>, IResolver
    {
        private readonly IContainer _container;
        private readonly ComplianceServiceSettings _settings;

        public CompositionRoot()
        {
            _settings = new ComplianceServiceSettings();
            _container = new Container(
                config =>
                {
                    config.For<ILogger>().Use((Logger)BAM.Infrastructure.Ioc.Container.Instance.Resolve(typeof(Logger)));
                    config.For<ISecurityDBRepository>()
                        .Use<SecurityDBRepository>()
                        .Ctor<string>()
                        .Is(_settings.BamCoreLite);
                    config.For<IEventJournalFactory>().Use<FlatFileEventJournalFactory>();

                    config.For<ISerializer>().Use<ProtoBufSerializer>().Ctor<Action<RuntimeTypeModel>>().Is((m => { }));
                    //data
                    config.For<ISettings>().Use<Settings>();
                    config.For<IDateProvider>().Use<DateProvider>();
                }
            );

            _container.Inject(typeof(IDependencyResolver), new StructureMapDependencyResolver(_container));
        }
        
        public object GetInstance<T>()
        {
            return _container.GetInstance<T>();
        }
      
        public IService Initialize()
        {
            var svc = _container.GetInstance<IService>();
            return svc;
        }

        public void Dispose()
        { }

        private class StructureMapDependencyResolver : IDependencyResolver
        {
            private readonly IContainer _container;

            public StructureMapDependencyResolver(IContainer container)
            {
                _container = container;
            }

            public void Dispose()
            {
                // nothing
            }

            public object GetService(Type serviceType)
            {
                return serviceType.Namespace != null && serviceType.Namespace.Contains("Bam.Oms")
                    ? BAM.Infrastructure.Ioc.Container.Instance.Resolve(serviceType) : _container.TryGetInstance(serviceType);
            }

            public IEnumerable<object> GetServices(Type serviceType)
            {
                return _container.GetAllInstances(serviceType).Cast<object>();
            }

            public IDependencyScope BeginScope()
            {
                return new StructureMapDependencyScope(_container.GetNestedContainer());
            }

            private class StructureMapDependencyScope : IDependencyScope
            {
                private readonly IContainer _container;

                public StructureMapDependencyScope(IContainer container)
                {
                    _container = container;
                }

                public void Dispose()
                {
                    _container.Dispose();
                }

                public object GetService(Type serviceType)
                {
                    return serviceType.Namespace != null && serviceType.Namespace.Contains("Bam.Oms")
                        ? BAM.Infrastructure.Ioc.Container.Instance.Resolve(serviceType) : _container.GetInstance(serviceType);
                }

                public IEnumerable<object> GetServices(Type serviceType)
                {
                    return _container.GetAllInstances(serviceType).Cast<object>();
                }
            }
        }
    }
}
