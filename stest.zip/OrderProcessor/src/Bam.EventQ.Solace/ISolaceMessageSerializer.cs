﻿using SolaceSystems.Solclient.Messaging;

namespace Bam.EventQ.Solace
{
    public interface ISolaceMessageSerializer<in TItem>
    {
        void Serialize(IMessage target, TItem payload);
    }
}
