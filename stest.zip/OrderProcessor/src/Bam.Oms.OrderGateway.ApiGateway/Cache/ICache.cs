﻿using System;
using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.ApiGateway.Cache
{
    public interface ICache<in TKey, TValue>
    {
        void Add(TKey key, TValue value);
        void Update(TKey key, TValue value);
        TValue Get(TKey key);
        IDisposable AcquireReadAccess();
        IDisposable AcquireWriteAccess();
        IReadOnlyList<TValue> GetItems();
    }
}