﻿using System;
using System.Collections.Generic;
using System.Data;
using Dapper;

namespace Bam.Oms.RefData.Eze
{
    public class SqlConnectionWrapper : ISqlConnectionWrapper 
    {
        private readonly IDbConnection _connection;

        public SqlConnectionWrapper(IDbConnection connection, string connectionString)
        {
            if (connection == null) throw new ArgumentNullException(nameof(connection));
            _connection = connection;
            _connection.ConnectionString = connectionString;
            _connection.Open();
        }

        public IDbTransaction BeginTransaction()
        {
            EnsureConnectionOpen();
            return _connection.BeginTransaction();
        }

        public string ConnectionString
        {
            get { return _connection.ConnectionString; }
            set { _connection.ConnectionString = value; }
        }

        public void Open()
        {
            //retry 3 times
            int numOfAttempts = 0;
            while (numOfAttempts < 3)
            {
                try
                {
                    _connection.Open();
                    numOfAttempts = 3;
                }
                catch
                {
                    numOfAttempts++;
                }
            }

        }

        public IEnumerable<T> Execute<T>(string executeSql)
        {
            EnsureConnectionOpen();
            return _connection.Query<T>(executeSql);
        }
        public void Close()
        {
            _connection.Close();
        }

        public virtual void EnsureConnectionOpen()
        {
            if (_connection.State != ConnectionState.Open)
            {
                // Microsoft states that Closing, and then Re-opening the connection "will refresh the value of State." See here http://msdn.microsoft.com/en-us/library/system.data.sqlclient.sqlconnection.state(v=vs.110).aspx
                try { Close(); } catch { /* log as Info here*/}
                Open();
            }
        }

        public IDbConnection Connection => _connection;
    }
}