﻿namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public struct TheoreticalEffects
    {
        public long Quantity;
        
        public static TheoreticalEffects operator -(TheoreticalEffects a, TheoreticalEffects b)
        {
            return new TheoreticalEffects
            {
                Quantity = a.Quantity - b.Quantity,
            };
        }
    }
}