﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;
using Bam.Oms.OrderGateway.EzeGateway.Models;
using Bam.Oms.OrderGateway.Infrastructure.Audit;

namespace Bam.Oms.OrderGateway.EzeGateway.Services
{
    public class EzeSubmissionService : IEzeSubmissionService
    {
        private readonly IMessageAudit _messageAudit;
        private readonly IEzeClient _serviceClient;
        private readonly int _maxBatchSize;
        private readonly int _submissionRetryCount;

        private static readonly string[] RetryErrors =
        {
            "Could not satisfy the holding's constraints",
            "All portfolios have a zero basis",
            "Potential Oversell",
            "Potential Overcover"
        };

        public ILogger Logger { get; set; }

        public EzeSubmissionService(IMessageAudit messageAudit, IEzeClient serviceClient, int maxBatchSize, int submissionRetryCount)
        {
            _messageAudit = messageAudit;
            _serviceClient = serviceClient;
            _maxBatchSize = maxBatchSize;
            _submissionRetryCount = submissionRetryCount;
        }

        public TradeCreateResponse Submit(CancellationToken cancellationToken, List<SubmissionQueueItem> queueItems)
        {
            var batches = CreateOrderBatches(queueItems, _maxBatchSize);
            var result = new List<TradeMap>();
            var failed = new List<Trade>();
            var tradeRequest = new TradeCreateRequest() { isAllOrNothing = false };

            foreach (var ezeOrderBatch in batches)
            {
                var count = 0;
                var remainder = ezeOrderBatch.Trades.ToList();
                tradeRequest.trades = ezeOrderBatch.Trades.ToArray();
                tradeRequest.isComplianceOverriding = ezeOrderBatch.IsComplianceOverride;
                tradeRequest.runCompliance = !ezeOrderBatch.IsComplianceOverride;

                if (cancellationToken.IsCancellationRequested)
                    return null;

                while (remainder.Any())
                {
                    tradeRequest.userCredentials = null;
                    _messageAudit.HandleOut(tradeRequest);

                    TradeCreateResponse response;
                    try
                    {
                        response = (TradeCreateResponse)_serviceClient.CreateTrade(tradeRequest);
                    }
                    catch (Exception ex)
                    {
                        Logger?.LogError(
                            "CreateTrade request failed. Unable to determine order status. Orders will remain in PendingAck.",
                            ex);
                        response = null;
                    }

                    if (response == null)
                    {
                        Logger?.LogError("Received NULL response from EZE");
                    }
                    else
                    {
                        _messageAudit.HandleIn(response);
                    }

                    if (response?.responseMap?.tradeResponses != null &&
                        response.responseMap.tradeResponses.Any())
                    {
                        foreach (var tradeResponse in response.responseMap.tradeResponses)
                        {
                            if (tradeResponse.ErrorCode == ErrorCode.Success)
                            {
                                result.Add(tradeResponse);
                                continue;
                            }

                            if (count < _submissionRetryCount &&
                                RetryErrors.Any(msg => tradeResponse.ErrorMessage?.Contains(msg) ?? false))
                            {
                                var trade = tradeRequest.trades.FirstOrDefault(
                                    t => t.ExternalBlockID == tradeResponse.ExternalId);
                                if (trade != null) failed.Add(trade);
                            }
                            else
                            {
                                result.Add(tradeResponse);
                            }
                        }

                        remainder.Clear();
                        remainder.AddRange(failed);
                        failed.Clear();
                        tradeRequest.trades = remainder.ToArray();
                        count++;

                        if (remainder.Any())
                        {
                            Thread.Sleep(100);
                        }
                    }
                    else
                    {
                        foreach (var trade in tradeRequest.trades)
                        {
                            var tradeMap = new TradeMap() { ExternalId = trade.ExternalBlockID };
                            result.Add(tradeMap);

                            if (response?.responseType == ResponseType.Success)
                            {
                                Logger?.LogWarning("Received EZE response in SUCCESS with no trade responses.");
                                tradeMap.ErrorCode = ErrorCode.Success;
                            }
                            else if (response != null &&
                                response.responseType == ResponseType.SuccessWithWarning &&
                                response.CreatedTradeIds != null && 
                                response.CreatedTradeIds.Contains(trade.ExternalBlockID))
                            {
                                tradeMap.ErrorCode = ErrorCode.Success;
                            }
                            else
                            {
                                tradeMap.ErrorCode = ErrorCode.ValidationFailure;
                                tradeMap.ErrorMessage = response?.message; //prob not the best since this has all the order ids
                            }
                        }

                        remainder.Clear();
                        failed.Clear();
                    }
                }
            }

            return new TradeCreateResponse
            {
                responseMap = new TradeResponseMap
                {
                    tradeResponses = result.ToArray()
                }
            };
        }

        public static List<EzeOrderBatch> CreateOrderBatches(List<SubmissionQueueItem> submissionItems, int maxBatchSize)
        {
            var orderBatches = new List<EzeOrderBatch>();

            foreach (var item in submissionItems)
            {
                if (orderBatches.Count == 0)
                    orderBatches.Add(new EzeOrderBatch(item.Request.isComplianceOverriding));

                var i = 0;
                while (!orderBatches[i].TryAddOrder(item.Trade, item.Request.isComplianceOverriding))
                {
                    if (i == orderBatches.Count - 1)
                        orderBatches.Add(new EzeOrderBatch(item.Request.isComplianceOverriding));
                    i++;
                }
            }

            return orderBatches;
        }
    }
}