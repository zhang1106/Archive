﻿using System;
using log4net.Config;

namespace Bam.Service.Template
{
    public class HostProgram  //: WcfServiceHost<T> // If you are using WCF, T is just your service.  If not, just user AbstractService
    {
        static void Main(string[] args)
        {
            XmlConfigurator.Configure();
            var service = new HostProgram();

            if (Environment.UserInteractive)
            {
//                service.OnStart(args);

                Console.WriteLine("Press any key to stop program");
                Console.Read();

//                service.OnStop();
            }
            else
            {
//                Run(service);
            }

            Console.Read();
        }
    }
}
