﻿using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public class RestrictedListRule : EventRelay<IMessage>, IRule
    {
        private readonly HashSet<string> _symbols;
        private readonly Side? _side;

        public RestrictedListRule(string name, IEnumerable<string> symbols, Side? side = null)
        {
            Name = name;
            _symbols = new HashSet<string>(symbols);
            _side = side;
        }

        public string Name { get; }

        public void Execute(RuleContext context, List<RuleViolation> violations)
        {
            if (_side != null && context.Order.Side != _side.Value)
                return;

            if (_symbols.Contains(context.Order.Security.Symbol))
            {
                violations.Add(new RuleViolation
                {
                    RuleName = Name,
                    Message = $"Symbol '{context.Order.Security.Symbol}' is restricted",
                    Level = ComplianceViolationLevel.Restricted,
                    Status = ComplianceStatus.RuleFailure
                });
            }
        }
    }
}
