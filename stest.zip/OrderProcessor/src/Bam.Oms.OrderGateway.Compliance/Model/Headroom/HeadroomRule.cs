﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Services.Headroom;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    [DebuggerDisplay("'{Name,nq}' for '{ReportingEntity,nq}' ({Id})")]
    public class HeadroomRule : EventRelay<IMessage>
    {
        public const string FirmReportingEntity = "FIRM";

        public Dictionary<string, Headroom> Headrooms { get; } 
            = new Dictionary<string, Headroom>(StringComparer.OrdinalIgnoreCase);

        public HeadroomRule(int id)
        {
            Id = id;
        }

        public int Id { get; }
        public string Name { get; private set; }
        public string ReportingEntity { get; private set; }
        public HeadroomDirection Direction { get; private set; }
        public HeadroomIdentifierType IdentifierType { get; private set; }

        public void ApplyDetails(string name, string reportingEntity, 
            HeadroomDirection direction, HeadroomIdentifierType identifierType)
        {
            Name = name;
            ReportingEntity = reportingEntity;
            Direction = direction;
            IdentifierType = identifierType;
        }

        public bool ApplyHeadroomEffects(string identifier, HeadroomEffects effects)
        {
            return ApplyEffects(identifier, GetEffect(effects));
        }

        public bool TryCheck(Order order, HeadroomEffects currentOrderEffect, 
            decimal? suppressedThreshold, out bool breached, out HeadroomCheck result)
        {
            Headroom headroom;
            string identifier = GetIdentifier(order.Security);
            if (identifier == null || !Headrooms.TryGetValue(identifier, out headroom))
            {
                breached = false;
                result = default(HeadroomCheck);
                return false;
            }

            if (!headroom.IsExempt)
            {
                breached = headroom.WouldBreach(order.AggregationUnit, GetQuantity(order),
                    GetEffect(currentOrderEffect), suppressedThreshold, out result);
            }
            else
            {
                result = default(HeadroomCheck);
                breached = false;
            }

            return true;
        }

        public bool Handles(CachedSecurity security)
        {
            string identifier = GetIdentifier(security);
            return identifier != null && Headrooms.ContainsKey(identifier);
        }

        public void SetHeadroom(Headroom headroom)
        {
            Headroom existingHeadroom;
            if (Headrooms.TryGetValue(headroom.Key.Identifier, out existingHeadroom))
            {
                headroom.UpdateIntradayQuantities(existingHeadroom.IntradayQuantity, existingHeadroom.MaxIntradayQuantity);
            }

            Headrooms[headroom.Key.Identifier] = headroom;
        }

        public void RemoveHeadroom(HashSet<string> identifiers)
        {
            OwnershipHeadroomRemoved msg = null;

            foreach (var identifier in identifiers)
            {
                if (msg == null)
                    msg = new OwnershipHeadroomRemoved();

                msg.Items.Add(new OwnershipHeadroomRemoved.Item()
                {
                    Identifier = identifier,
                    RuleId = Id
                });

                Headrooms.Remove(identifier);
            }

            if(msg != null)
                Publish(msg);
        }

        private bool ApplyEffects(string identifier, long effect)
        {
            Headroom headroom;
            if (identifier != null && Headrooms.TryGetValue(identifier, out headroom))
            {
                using (Attach(headroom))
                {
                    headroom.ApplyEffect(effect);
                    return true;
                }
            }

            return false;
        }

        public void AdjustRatios(string identifier, Dictionary<string, double> ratios)
        {
            Headroom headroom;
            if (identifier != null && Headrooms.TryGetValue(identifier, out headroom))
            {
                using (Attach(headroom))
                {
                    headroom.AdjustRatios(ratios);
                }
            }
        }

        private long GetEffect(HeadroomEffects effects)
        {
            switch (Direction)
            {
                case HeadroomDirection.Long:
                    return effects.Long;
                case HeadroomDirection.Short:
                    return effects.Short;
                case HeadroomDirection.NetShort:
                    return effects.NetShort;
            }

            return 0;
        }

        public string GetIdentifier(CachedSecurity security)
        {
            if (IdentifierType == HeadroomIdentifierType.Isin)
            {
                return security.FindUltimateUnderlying().Isin;
            }

            return security.FindUltimateUnderlying().Symbol;
        }

        private long GetQuantity(Order order)
        {
            double size;
            if (Direction == HeadroomDirection.Long || Direction == HeadroomDirection.Short)
                size = order.OpeningQuantity;
            else
                size = order.Size;

            return (long) Math.Floor(order.Security.ConversionRatio * size);
        }

        public override string ToString()
        {
            return $"'{Name}' for '{ReportingEntity}' ({Id})";
        }
    }
}
