﻿using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Persistence.Compliance
{
    public class PolicyRepository<T> : DBRepository<Policy<T>>, IPolicyRepository<T>
    {
        public PolicyRepository(ISettings settings, ILogger logger) : base(settings, logger, "cp", settings.PolicyTable)
        {
        }
    }
}
