﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Orders;

namespace Bam.Oms.EndPoints.Orders
{
    public interface IOrderPrepUtility
    {
        IList<string> AssignOrderIds(IEnumerable<IOrder> orders);

        void SetTradeDate(IEnumerable<IOrder> orders, DateTime now = default(DateTime));

        void SetSecurityInformation(IEnumerable<IOrder> orders);
        void SetTrader(IEnumerable<IOrder> orders, string entryUser = null);

        string CreateBatchId(string pmCode, DateTime dt);

        void SetOrderStatus(IEnumerable<IOrder> orders);

        IEnumerable<IOrder> ScaleOrders(IEnumerable<IOrder> orders);

        IOrder CreateSwapOrder(IOrder equityOrder, string broker);

        void SetCustodian(IEnumerable<IOrder> orders);
        IOrder CloneOrder(IOrder order);

        void SetCreatedUser(IEnumerable<IOrder> orders, string user = "UND");
    }
}