﻿using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Integration;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;
using Bam.Oms.OrderGateway.EzeGateway.Models;
using Bam.Oms.OrderGateway.EzeGateway.Services;

namespace Bam.Oms.OrderGateway.EzeGateway.Producers
{
    public class AsyncRpc : ExternalMessageSourceBase<TradeCreateResponse>, IAsyncRpc
    {
        private readonly IFastLaneQueue<SubmissionQueueItem> _queue;
        private readonly IEnumerable<IEzePooledWorker> _workerPool;

        public AsyncRpc(IFastLaneQueue<SubmissionQueueItem> queue, IEnumerable<IEzePooledWorker> workerPool)
        {
            _queue = queue;
            _workerPool = workerPool;
        }

        public ILogger Logger { get; set; }

        public void CreateOrders(TradeCreateRequest request)
        {
            Logger?.LogInformation($"[EZESTAT] Enqueuing batch of {request.trades.Length} trades.");
            for (int i = 0; i < request.trades.Length; i++)
            {
                _queue.Enqueue(new SubmissionQueueItem(request, i));
            }
        }
        
        public override void Start()
        {
            foreach (var worker in _workerPool)
            {
                worker.Start(Handler);
            }
        }
    }
}
