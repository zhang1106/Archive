﻿using System;
using BAM.Common.Messaging;

namespace Bam.Oms.Compliance.Services
{
    public interface IMqClient : IDisposable
    {
        void SubscribeOgOrders();

        event Action<Message<string>> ObjectUpdated;

    }
}
