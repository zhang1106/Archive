USE OrderGateway;
 
 ALTER TABLE [og].[EmsOrderAllocation] ADD StreetOrderId INT NULL
