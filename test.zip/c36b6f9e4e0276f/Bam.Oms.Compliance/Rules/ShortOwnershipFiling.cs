﻿using Newtonsoft.Json;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Compliance.Rules
{
    [JsonObject(MemberSerialization.OptIn)]
    public class ShortOwnershipFiling :  OwnerShip
    { 
        public override IRuleResult CheckViolation(ICompliancePosition input, bool isPreCheck)
        {
            var result = input.Helper.CreateFilingResult(input, this, GetOwnership(), Entity, GetIdentityType());
           
            //need move this logic into rule filter
            result.HeadRoom.IsExempt = IncludeConstituent && input.CustomDataProvider.IsEuExempted(input.Security.Isin);

            CheckViolation(input, isPreCheck, result);

            return result;
        }
    }
}
