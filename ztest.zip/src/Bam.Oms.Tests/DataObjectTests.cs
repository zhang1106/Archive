﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using NUnit.Framework;
using ProtoBuf.Meta;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class DataObjectTests
    {
        private Position CreatePositionWithNullPrices()
        {
            return new Position()
            {
                PositionId = 4,
                Security = new Security {BamSymbol = "IBM", Currency = "USD", SecurityType = SecurityType.EquitySwap},                
                EntryDate = DateTime.Now,
                CustodianName = "Deutsche Bank",
                ActualQuantity = -200000M,
                Portfolio = (Portfolio) Portfolio.Parse("MYPORTFOLIO-MYSTRATEGY-MYSUBSTRATEGY"),
                Stream = "US",
                FundCode = "AQTF",
                CreatedOn = DateTime.Now,
                ActionLogId = 1,
                AuditSequence = 1,
                LastModifiedOn = DateTime.Now,
                LastModifiedBy = "kishore",
                TheoreticalQuantity = -200000M,
                Price = null,
                FXRate = null,
                DistributedPositions = new List<DistributedPosition>()
            };
        }       

        [Test]
        public void TestPositionSerializeToJson()
        {
            // arrange
            var expected = CreatePositionWithNullPrices();                   
            var json = JsonConvert.SerializeObject(expected, Formatting.Indented, new IsoDateTimeConverter());            
            Position actual = (Position) JsonConvert.DeserializeObject(json, typeof (Position), new IsoDateTimeConverter());
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TestPositionSerializeToProto()
        {
            // arrange
            var expected = CreatePositionWithNullPrices();

            var typeModel = TypeModel.Create();
            typeModel.UseImplicitZeroDefaults = false;                     

            var stream = new MemoryStream();
            typeModel.Serialize(stream, expected);
            stream.Seek(0, SeekOrigin.Begin);
            Position actual = (Position) typeModel.Deserialize(stream, null, typeof (Position));
            Assert.AreEqual(expected, actual);
        }
    }
}
