﻿using System;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using CsvHelper.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway.File
{
    public sealed class OrderMapping : CsvClassMap<SubmitOrders.SubmitOrderLineItem>
    {
        public OrderMapping()
        {
            Map(m => m.Symbol).Name("Security");

            Map(m => m.Portfolio).Name("Strategy").ConvertUsing(row =>
            {
                string portfolio;
                if (row.TryGetField("Strategy", out portfolio))
                {
                    return portfolio;
                }

                if (row.TryGetField("TAlpha2", out portfolio))
                {
                    return portfolio;
                }

                throw new Exception($"Unable to submit order without 'Strategy' or 'TAlpha2' set. Row #{row.CurrentRecord.Stringify()}");
            });

            Map(m => m.Quantity).Name("Amount").ConvertUsing(row =>
            {
                decimal amount;
                if (row.TryGetField("Amount", out amount))
                    return Convert.ToInt64(Math.Abs(amount));

                throw new Exception($"Missing or invalid order size. Row #{row.CurrentRecord.Stringify()}");
            });

            Map(m => m.Side).Name("Side").ConvertUsing(row =>
            {
                string side;
                decimal amount;

                if (!row.TryGetField("Side", out side) && row.TryGetField("Amount", out amount))
                {
                    return amount < 0 ? Side.Sell : Side.Buy;
                }

                if (row.TryGetField("Amount", out amount))
                {
                    if (amount > 0)
                        return Enum.Parse(typeof(Side), side, true);
                }

                throw new Exception($"Side/Amount combination not valid. Side '{side}', Amount '{amount}'. Row #{row.CurrentRecord.Stringify()}");
            });

            Map(m => m.Custodian).Name("Cust").ConvertUsing(row =>
            {
                string custodian;
                return row.TryGetField("Cust", out custodian) && string.Empty != custodian ? custodian : null;
            });

            Map(m => m.FundAllocationOverride).Name("Fund").ConvertUsing(row =>
            {
                string fund;
                return row.TryGetField("Fund", out fund) && string.Empty != fund ? fund : null;
            });

            Map(m => m.Notes).Name("Note").ConvertUsing(row =>
            {
                string note;
                return row.TryGetField("Note", out note) && string.Empty != note ? note : null;
            });

            Map(m => m.Urgency).Name("Urgency").ConvertUsing(row =>
            {
                Urgency urgency;
                string urgencyStr;
                if (row.TryGetField("Urgency", out urgencyStr) && Enum.TryParse(urgencyStr, true, out urgency))
                    return urgency;

                return Urgency.Low;
            });

            Map(m => m.LimitPrice).Name("Limit").ConvertUsing(row =>
            {
                decimal limit;
                if (row.TryGetField("Limit", out limit))
                {
                    return limit;
                }

                return (decimal?) null;
            });
        }
    }
}
