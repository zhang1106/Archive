﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class Trade : ModelBase<object>, ICloneable
    {
        public Trade()
        {
            FxRate = 1;
            Fees = new List<Fee>();
            Commissions = new List<Fee>();
        }

        public string TradeId { get; set; }
        public Portfolio Portfolio { get; set; }
        public Security Security { get; set; }
        public SideType Side { get; set; }
        public decimal TradedQuantity { get; set; }
        public decimal? AveragePrice { get; set; }
        public string ClientOrderId { get; set; }
        public TradeStatus TradeStatus { get; set; }
        public string Trader { get; set; }
        public string Key => TradeId;
        public string Fund { get; set; }
        public string PrimeBroker { get; set; }
        public string PrimeBrokerAccount { get; set; }
        public string CounterParty { get; set; }
        public string TradeDate { get; set; }
        public DateTime? SettleDate { get; set; }
        public string Currency => TradeCurrency;
        public string TradeCurrency { get; set; }
        public string BaseCurrency { get; set; }
        public decimal FxRate { get; set; }
        public decimal? GrossAmount { get; set; }
        public decimal? NetAmount { get; set; }
        public decimal? NetAmountBase { get; set; }
        public List<Fee> Commissions { get; set; }
        public List<Fee> Fees { get; set; }
        public string Note { get; set; }
        public DateTime TradeTimeStamp { get; set; }
        public string ParentTradeId { get; set; }
        public string DataSource { get; set; }
        public decimal? RepoRate { get; set; }
        public decimal? HairCut { get; set; }
        public decimal? AccruedInterest { get; set; }
        public DateTime LastUpdated { get; set; }
        public bool isFinalized { get; set; }

        public string Status => isFinalized ? OrderStatus.Finalized.ToString() : OrderStatus.Working.ToString();

        public object Clone()
        {
            var t = new Trade
            {
                Security = (Security) Security.Clone(),
                Portfolio = (Portfolio)Portfolio.Clone(),
                Side = Side,
                Trader = Trader,
                AveragePrice = AveragePrice,
                TradeDate = TradeDate,
                ClientOrderId = ClientOrderId,
                AccruedInterest = AccruedInterest,
                BaseCurrency = BaseCurrency,
                CounterParty = CounterParty,
                DataSource = DataSource,
                Fund = Fund,
                FxRate = FxRate,
                GrossAmount = GrossAmount,
                HairCut = HairCut,
                NetAmount = NetAmount,
                NetAmountBase = NetAmountBase,
                Note = Note,
                ParentTradeId = ParentTradeId,
                PrimeBroker = PrimeBroker,
                PrimeBrokerAccount = PrimeBrokerAccount,
                RepoRate = RepoRate,
                SettleDate = SettleDate,
                TradeCurrency = TradeCurrency,
                TradeId = TradeId,
                TradeStatus = TradeStatus,
                TradeTimeStamp = TradeTimeStamp,
                TradedQuantity = TradedQuantity,
                isFinalized = isFinalized,
                LastUpdated = LastUpdated
            };

            foreach (var fee in Fees)
            {
                t.Fees.Add((Fee)fee.Clone());
            }

            foreach (var comm in Commissions)
            {
                t.Commissions.Add((Fee)comm.Clone());
            }

            return t;
        }

        public string GetRoutingKey() 
        {
            return $"{DataSource}.{Portfolio}";
        }

        public override string ToString()
        {
            return $"Id: {TradeId}, Qty: {TradedQuantity}, Status: {Status}";
        }
    }
}
