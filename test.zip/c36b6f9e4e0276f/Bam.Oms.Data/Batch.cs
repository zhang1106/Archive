﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Bam.Oms.Data
{
    public class Batch<T>
    {
        public int TotalExpectedPackets { get; set; }
        public int Sequence { get; set; }
        public IEnumerable<T> Data { get; set; }
        public Guid Id { get; set; }

        public static IEnumerable<Batch<T>> Partition(IEnumerable<T> items, int size)
        {
            var id = Guid.NewGuid();
            var enumerable = items as T[] ?? items.ToArray();
            var numofpackets = Math.Ceiling(enumerable.Count() / (double)size);
            var splits = enumerable.Select((x, i) => new
            {
                Index = i,
                Value = x
            }).GroupBy(x => x.Index / size)
                .Select(
                    g =>
                        new Batch<T>()
                        {
                            Id = id,
                            TotalExpectedPackets = (int)numofpackets,
                            Sequence = g.Key,
                            Data = g.Select(x => x.Value)
                        });

            return splits;
        }
    }
}
