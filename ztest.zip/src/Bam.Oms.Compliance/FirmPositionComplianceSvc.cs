﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Bam.Oms.Compliance.Actions;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Filters;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;
using Castle.Components.DictionaryAdapter;

namespace Bam.Oms.Compliance
{
    public class FirmPositionComplianceSvc : IFirmPositionComplianceSvc
    {
        private readonly IEngine<CompliancePosition> _engine;
        private readonly IFactProvider _factProvider;
        private readonly ILogger _logger;
        private readonly IPolicyProvider _policyProvider;
        private readonly IIntradayPositionProvider _positionProvider;
        private readonly IRuleResultRepository _ruleResultRepository;
        private readonly ISecurityProvider _securityProvider;
        private readonly ISettings _setting;
        private IEnumerable<IRuleResult> _previousRuleResults;

        public FirmPositionComplianceSvc(ISettings setting, IPolicyProvider policyProvider, IIntradayPositionProvider positionProvider,
            IEngine<CompliancePosition> engine, IRuleResultRepository ruleResultRepository,
            ISecurityProvider securityProvider, IFactProvider factProvider, ILogger logger)
        {
            _policyProvider = policyProvider;
            _positionProvider = positionProvider;
            _engine = engine;
            _setting = setting;
            _ruleResultRepository = ruleResultRepository;
            _securityProvider = securityProvider;
            _factProvider = factProvider;
            _logger = logger;
            //
            FirmWideComplianceResult = new List<IRuleResult>();
            _previousRuleResults = new List<IRuleResult>();
        }

        public PolicyResult PolicyResult { get; private set; }
        public bool IsInitialized { get; private set; }

        public List<IRuleResult> FirmWideComplianceResult { get; private set; }

        public void Init()
        {
            //config string
            _setting.Initialize();
            //get the policy
            _policyProvider.RefreshData();
            _factProvider.RefreshData();
            _ruleResultRepository.ClearAll();
            _securityProvider.RefreshData();
            //
            var policies = _policyProvider.Get(new PolicyFilter());
            foreach (var policy in policies)
            {
                var fPolicy = (IPolicy<CompliancePosition>) ConvertBaseToChild.Map(policy);
                _engine.RegisterPolicy(fPolicy);
            }
            IsInitialized = true;
        }

        public void Run()
        {
            if (!IsInitialized) Init();
            //reset the result container
            FirmWideComplianceResult = new EditableList<IRuleResult>();
            ////get intraday positions
            _positionProvider.RefreshData();
            var intradayUnderlyingSecurities = _positionProvider.GetUnderlyingSecurities();
            var underlyingSecurities = intradayUnderlyingSecurities as ISecurity[] ?? intradayUnderlyingSecurities.ToArray();
            foreach (var policy in _engine.Policies.Values)
            {
                //verify positions against the policy
                var violations = new List<IRuleResult>();
                PolicyResult = new PolicyResult {PolicyId = policy.Id, PolicyName = policy.Name, Alerts = violations};
                //check all the underliers
                foreach (var security in underlyingSecurities)
                {
                    //check underlying security only
                    var pTarget = new CompliancePosition {Security = security, Policy = policy};
                    var result = _engine.CheckViolations(policy, pTarget, false);
                    violations.AddRange(result.Alerts);
                }
                FirmWideComplianceResult.AddRange(violations);
            }
            //act
            Act(FirmWideComplianceResult);
        }

        public void ClearRepository()
        {
            _ruleResultRepository.ClearAll();
            _previousRuleResults = new List<IRuleResult>();
        }

        protected void Act(IEnumerable<IRuleResult> ruleResults)
        {
            var thisResult = ruleResults.Where(r => r.AlertLevel != ComplianceAlertLevel.NoViolation && r.PositionQty.HasValue && r.PositionQty > 0);
            var newAlerts = thisResult.Where(r => !_previousRuleResults.Any(p => p.Same(r))).Select(r=>r);

            var previousResult = thisResult as IRuleResult[] ?? thisResult.ToArray();
            
            string templatePath = ConfigurationManager.AppSettings["compliance_emailTemplate"];
            string from = ConfigurationManager.AppSettings["compliance_emailFrom"];
            string to = ConfigurationManager.AppSettings["compliance_emailTo"];
            string cc = ConfigurationManager.AppSettings["compliance_emailCC"];
            string bcc = ConfigurationManager.AppSettings["compliance_emailBCC"];
            string title = ConfigurationManager.AppSettings["compliance_emailTitle"];

            string template = FirmPositionAlertEmail.GetTemplate(templatePath);
            string html = FirmPositionAlertEmail.BuildHtml(template, thisResult);
            
            //send out email only when there are new alerts
            if (newAlerts.Any())
            {
                _logger.Info("send email...");
                FirmPositionAlertEmail.SendEmail(title, html, from, to, cc, bcc, null, null);
            }
            else
            {
                _logger.Info("not send email...no new alerts.");
                _logger.Info(html);
            }

            _previousRuleResults = previousResult;
        }
    }
}