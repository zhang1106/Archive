﻿using System;
using Bam.EventQ.Lookup;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class ComplianceGroupPosition : ModelBase<object>, ICloneable
    {
        public long PositionId { get; set; }
        public string BamSymbol { get; set; }
        public string ComplianceGroup { get; set; }
        public long ShortMarkingQuantity { get; set; }
        public long LongMarkingQuantity { get; set; }

        public object Clone()
        {
            return new ComplianceGroupPosition
            {
                PositionId = PositionId,
                BamSymbol = BamSymbol,
                ComplianceGroup = ComplianceGroup,
                ShortMarkingQuantity = ShortMarkingQuantity,
                LongMarkingQuantity = LongMarkingQuantity
            };
        }
    }
}
