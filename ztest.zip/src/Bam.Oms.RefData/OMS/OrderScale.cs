﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.RefData.OMS
{
    public class OrderScale
    {
        public string SourcePortfolio { get; set; }
        public string DestinationPortfolio { get; set; }
        public string SecurityType { get; set; }
        public decimal ScaleFactor { get; set; }
    }
}
