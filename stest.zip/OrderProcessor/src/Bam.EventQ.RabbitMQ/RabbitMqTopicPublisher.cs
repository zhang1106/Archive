﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Throttling;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using RabbitMQ.Client;
using RabbitMQ.Client.Framing;

namespace Bam.EventQ.RabbitMQ
{
    public class RabbitMqTopicPublisher<TItem> : IThrottledBatchHandler<TItem>, IDisposable
    {
        private readonly string _exchange;
        private readonly Func<TItem, string> _routingKeyFunc;
        private readonly TimeSpan _retryInterval;
        private readonly ConnectionFactory _connectionFactory;
        private readonly JsonSerializer _serializer;
        private readonly BlockingCollection<TItem> _outgoing;
        private readonly IBackgroundWorker _publishWorker;
        private readonly Encoding _encoding;

        public RabbitMqTopicPublisher(string endpoint, string exchange, Func<TItem, string> routingKeyFunc, TimeSpan retryInterval)
        {
            _exchange = exchange;
            _routingKeyFunc = routingKeyFunc;
            _retryInterval = retryInterval;

            _encoding = new UnicodeEncoding(false, false);
            _connectionFactory = new ConnectionFactory
            {
                Uri = endpoint,
                AutomaticRecoveryEnabled = true,
                TopologyRecoveryEnabled = true,
                UseBackgroundThreadsForIO = true,
                NetworkRecoveryInterval = TimeSpan.FromSeconds(5),
                RequestedHeartbeat = 500
            };

            _serializer = new JsonSerializer();
            _serializer.Converters.Add(new StringEnumConverter());
            _outgoing = new BlockingCollection<TItem>();
            _publishWorker = BackgroundWorkerFactory.Current.Create($"RMQ Publish {typeof(TItem).GetDisplayName()}");
            _publishWorker.Start(Publish);
        }

        public ILogger Logger { get; set; }

        public void Handle(IReadOnlyList<TItem> batch)
        {
            foreach (var item in batch)
            {
                _outgoing.Add(item);
            }
        }

        private void Publish(CancellationToken token)
        {
            using (var connection = _connectionFactory.CreateConnection())
            using (var model = connection.CreateModel())
            {
                var props = new BasicProperties
                {
                    Headers = new Dictionary<string, object>
                    {
                        {"SerializationMode", "Json"}
                    },
                    ContentType = "application/json",
                    ContentEncoding = _encoding.ToString(),
                    DeliveryMode = 2
                };

                var consumer = _outgoing.GetConsumingEnumerable();
                foreach (var item in consumer)
                {
                    retry:
                    try
                    {
                        model.BasicPublish(_exchange, _routingKeyFunc(item), props, Serialize(item));
                    }
                    catch (Exception ex)
                    {
                        if (token.IsCancellationRequested)
                        {
                            Logger?.LogError($"Failed to publish {item.GetType().GetDisplayName()} ([{item}]) to RMQ", ex);
                        }
                        else
                        {
                            Logger?.LogWarning(
                                $"Failed to publish {item.GetType().GetDisplayName()} ([{item}]) to RMQ, retrying in {_retryInterval}",
                                ex);
                            token.WaitHandle.WaitOne(_retryInterval);
                            goto retry;
                        }
                    }
                }
            }
        }
        
        private byte[] Serialize(TItem item)
        {
            using (var ms = new MemoryStream())
            using (var writer = new StreamWriter(ms, _encoding))
            {
                _serializer.Serialize(writer, item);
                writer.Flush();
                return ms.ToArray();
            }
        }

        public void Dispose()
        {
            _outgoing.CompleteAdding();
            _publishWorker.Dispose();
        }
    }
}
