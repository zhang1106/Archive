﻿using System;

namespace Bam.EventQ.Integration
{
    public interface IExternalMessageSource<out TItem>
    {
        void Initialize(Action<TItem> handler);
        void Start();
        void Stop();
    }
}
