﻿using System;
using System.Collections.Generic;
using Bam.EventQ;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;
using Bam.Oms.OrderGateway.Compliance.Services.Marking;
using Bam.Oms.OrderGateway.Compliance.Services.Rules;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using Bam.Oms.OrderGateway.Messages.Compliance;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;
using Bam.Oms.OrderGateway.Messages.RefDataGateway;

namespace Bam.Oms.OrderGateway.Compliance.Workflows
{
    public class RunComplianceWorkflow : Workflow, 
        IHandle<RunCompliance>, 
        IHandle<DisableComplianceRules>,
        IHandle<SecurityUpdates>
    {
        private readonly HashSet<RunCompliance> _pendingRuns = new HashSet<RunCompliance>();
        private readonly HashSet<RunCompliance> _runsToSend = new HashSet<RunCompliance>();
        private readonly HashSet<string> _disabledRules = new HashSet<string>();
        private readonly RuleContext _ruleContext = new RuleContext();
        private readonly HashSet<string> _audits = new HashSet<string>();
        private readonly List<RuleViolation> _violations = new List<RuleViolation>();
        private readonly List<OrderAllocation> _openingAllocations = new List<OrderAllocation>();
        private readonly List<OrderAllocation> _closingAllocations = new List<OrderAllocation>();
        private readonly List<OrderAllocation> _mergedAllocations = new List<OrderAllocation>();

        private readonly IOrderEffectMediator _orderEffectMediator;
        private readonly IComplianceCache _complianceCache;
        private readonly IOrderFactory _orderFactory;
        private readonly IAllocationService _allocationService;
        private readonly IRuleRepository _rulesRepository;
        private readonly IMarkingService _markingService;
        private readonly ISecurityCache _securityCache;

        public RunComplianceWorkflow(
            IOrderEffectMediator orderEffectMediator,
            IComplianceCache complianceCache,
            IOrderFactory orderFactory,
            IAllocationService allocationService,
            IRuleRepository rulesRepository,
            IMarkingService markingService,
            ISecurityCache securityCache)
        {
            _orderEffectMediator = orderEffectMediator;
            _complianceCache = complianceCache;
            _orderFactory = orderFactory;
            _allocationService = allocationService;
            _rulesRepository = rulesRepository;
            _markingService = markingService;
            _securityCache = securityCache;
        }

        public void Execute(RunCompliance input)
        {
            if (input.DryRun)
            {
                var missingSecurity = false;
                foreach (var item in input.Items)
                {
                    CachedSecurity cached;
                    if (!_securityCache.TryGetSecurity(item.Symbol, out cached) || cached.IsPlaceholder)
                    {
                        missingSecurity = true;
                        break;
                    }
                }

                if (missingSecurity)
                {
                    _pendingRuns.Add(input.Clone());
                    return;
                }
            }

            ExecuteRun(input);
        }

        public void Execute(SecurityUpdates input)
        {
            _securityCache.AddSecurityUpdates(input);
            _runsToSend.Clear();

            var stillMissing = false;
            foreach (var pending in _pendingRuns)
            {
                foreach (var item in pending.Items)
                {
                    CachedSecurity sec;
                    if (!_securityCache.TryGetSecurity(item.Symbol, out sec) || sec.IsPlaceholder)
                    {
                        stillMissing = true;
                        break;
                    }
                }

                if(!stillMissing)
                    _runsToSend.Add(pending);
            }

            foreach (var run in _runsToSend)
            {
                _pendingRuns.Remove(run);
                ExecuteRun(run);
            }
        }

        private void ExecuteRun(RunCompliance input)
        {
            var result = new ComplianceResult {WasDryRun = input.DryRun};
            using (Attach(_complianceCache))
            {
                input.Items.Sort(OrderIdComparer.Instance);
                foreach (var item in input.Items)
                {
                    ComplianceResult.LineItem lineItem;
                    result.Items.Add(lineItem = new ComplianceResult.LineItem
                    {
                        OrderId = item.OrderId,
                        Status = 0
                    });

                    Portfolio portfolio;
                    if (!Portfolio.TryParse(item.Portfolio, out portfolio))
                    {
                        Logger?.LogWarning($"Received order with unknown portfolio '{item.Portfolio}'");
                        lineItem.Status = ComplianceStatus.GeneralFailure;
                        continue;
                    }

                    Order order;
                    if (!GetOrAddOrder(item, portfolio, out order))
                    {
                        lineItem.Status = ComplianceStatus.GeneralFailure;
                        continue;
                    }

                    if (input.DryRun)
                    {
                        Allocate(order, item, lineItem);
                        if (lineItem.Violations.Count > 0)
                        {
                            lineItem.Status = ComplianceStatus.RuleFailure;
                            continue;
                        }
                    }

                    Mark(order, lineItem);
                    lineItem.Status |= ExecuteRules(order, input.DryRun, item, lineItem);

                    if (input.DryRun)
                    {
                        if (lineItem.Status == ComplianceStatus.Success)
                        {
                            order.Status = OrderStatus.Marked;
                        }

                        using (Attach(order))
                        {
                            _orderEffectMediator.ApplyEffects(order); // theoretical effects
                        }
                    }
                    else if (lineItem.Status == ComplianceStatus.Success)
                    {
                        SplitAndApplyEffects(order,
                            _openingAllocations, _closingAllocations,
                            _mergedAllocations, item.ApprovedLocateQuantity);
                    }
                }

                if (result.Items.Count > 0)
                {
                    Publish(result);
                }
            }
        }

        private bool GetOrAddOrder(RunCompliance.ComplianceLineItem item, Portfolio portfolio, out Order order)
        {
            order = _complianceCache.GetOrder(item.OrderId);
            if (order == null)
            {
                long size = 0;
                foreach (var qty in item.CustodianAssignment.Values)
                {
                    size += qty;
                }

                order = _orderFactory.Create(item.OrderId,
                    item.Symbol, item.SecurityType,
                    portfolio, size, item.Side);

                if (order == null)
                {
                    return false;
                }
            }
            order.FundAllocationOverride = item.FundAllocationOverride;

            return true;
        }

        private ComplianceStatus ExecuteRules(Order order, 
            bool dryRun, RunCompliance.ComplianceLineItem input,
            ComplianceResult.LineItem result)
        {
            ComplianceStatus status = 0;

            long originalSize = 0;
            foreach (var qty in input.CustodianAssignment.Values)
            {
                originalSize += qty;
            }

            _violations.Clear();
            _ruleContext.Quantity = originalSize;
            _ruleContext.Order = order;
            _ruleContext.IsDryRun = dryRun;
            _ruleContext.SuppressedRules.Clear();
            _ruleContext.AuditTrail.Clear();
            foreach (var item in input.SuppressedRules)
            {
                _ruleContext.SuppressedRules.Add(item);
            }

            foreach (var rule in _rulesRepository.GetAll())
            {
                if (_disabledRules.Contains(rule.Name) ||
                    _ruleContext.SuppressedRules.Contains(rule.Name))
                    continue;

                using (Attach(rule))
                {
                    rule.Execute(_ruleContext, _violations);
                }
            }

            _ruleContext.AuditTrail.CopyTo(result.AuditTrail);

            foreach (var v in _violations)
            {
                if (!dryRun || v.Status != ComplianceStatus.RequireHeadroom)
                {
                    result.Violations.Add(new ComplianceResult.RuleResult
                    {
                        Message = v.Message,
                        Level = v.Level,
                        RuleName = v.RuleName
                    });
                }

                if (v.Level != ComplianceViolationLevel.Warning)
                {
                    status |= v.Status;
                }
            }

            return status;
        }

        private void Allocate(Order order, 
            RunCompliance.ComplianceLineItem input, ComplianceResult.LineItem result)
        {
            _openingAllocations.Clear();
            _closingAllocations.Clear();
            string message;

            if (!_allocationService.TryAllocate(order, input.CustodianAssignment, 
                    _openingAllocations, _closingAllocations, out message))
            {
                result.Violations.Add(new ComplianceResult.RuleResult
                {
                    Message = message,
                    RuleName = "Order Allocation",
                    Level = ComplianceViolationLevel.Restricted
                });
            }

            order.SetOpeningAllocations(_openingAllocations);
            order.SetClosingAllocations(_closingAllocations);
        }

        private void Mark(Order order, ComplianceResult.LineItem lineItem)
        {
            _openingAllocations.Clear();
            _closingAllocations.Clear();
            order.GetAllocations(_openingAllocations, _closingAllocations);

            _markingService.Mark(order.Security, _openingAllocations, _closingAllocations);
            var merged = Merge(_openingAllocations, _closingAllocations);

            _audits.Clear();
            foreach (var alloc in merged)
            {
                lineItem.Allocations.Add(new ComplianceResult.Allocation
                {
                    Portfolio = alloc.Portfolio.Key,
                    Quantity = alloc.Quantity,
                    FundId = alloc.FundId,
                    Side = alloc.Side,
                    CustodianId = alloc.CustodianId
                });

                var pk = new PositionKey(alloc.Portfolio, order.Security.Symbol);
                var set = _complianceCache.GetPositionSet(pk);

                if (_audits.Add(alloc.Portfolio.Key))
                {
                    lineItem.AuditTrail[$"{alloc.Portfolio} AggUnit Short Marking Quantity"]
                        = set.AggUnitPosition.ShortMarkingQuantity;
                    lineItem.AuditTrail[$"{alloc.Portfolio} Compliance Group Short Marking Quantity"]
                        = set.CompliancePosition.ShortMarkingQuantity;
                    lineItem.AuditTrail[$"{alloc.Portfolio} Compliance Group Long Marking Quantity"]
                        = set.CompliancePosition.LongMarkingQuantity;
                }
            }

            order.UpdateTheoreticalAllocations(merged);
        }
        
        private void SplitAndApplyEffects(Order order, 
            List<OrderAllocation> openingAllocations,
            List<OrderAllocation> closingAllocations,
            List<OrderAllocation> mergedAllocations,
            long approvedShortLocate)
        {
            var orders = _markingService.Split(order, _orderFactory, openingAllocations,
                closingAllocations, mergedAllocations, approvedShortLocate);

            foreach (var o in orders)
            {
                using (Attach(o))
                {
                    o.Status = OrderStatus.Working;
                    _orderEffectMediator.ApplyEffects(o);
                }
            }
        }

        private List<OrderAllocation> Merge(List<OrderAllocation> source1, List<OrderAllocation> source2)
        {
            _mergedAllocations.Clear();
            _mergedAllocations.AddRange(source2);

            int count = _mergedAllocations.Count;
            foreach (var item in source1)
            {
                bool merged = false;
                for (int i = 0; i < count; i++)
                {
                    var target = _mergedAllocations[i];
                    if (target.FundId == item.FundId &&
                        target.CustodianId == item.CustodianId &&
                        target.Side == item.Side &&
                        target.Portfolio.Equals(item.Portfolio))
                    {
                        _mergedAllocations[i] = new OrderAllocation
                        {
                            Portfolio = target.Portfolio,
                            FundId = target.FundId,
                            Side = target.Side,
                            CustodianId = target.CustodianId,
                            Quantity = target.Quantity + item.Quantity
                        };

                        merged = true;
                        break;
                    }
                }

                if (!merged)
                {
                    _mergedAllocations.Add(item);
                }
            }

            _mergedAllocations.Sort(ShortBeforeSellComparer.Instance);
            return _mergedAllocations;
        }

        public void Execute(DisableComplianceRules input)
        {
            foreach (var item in input.Items)
            {
                if (item.IsEnabled)
                {
                    _disabledRules.Remove(item.Rule);
                }
                else
                {
                    _disabledRules.Add(item.Rule);
                }
            }
        }
    }
}