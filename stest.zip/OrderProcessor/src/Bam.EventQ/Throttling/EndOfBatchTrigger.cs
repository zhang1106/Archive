﻿using System;
using Bam.EventQ.Diagnostics;

namespace Bam.EventQ.Throttling
{
    public class EndOfBatchTrigger : IConsumptionTrigger<object>
    {
        public ILogger Logger { get; set; }

        public void Throttled(object item, long sequence, bool endOfBatch)
        {
            if (endOfBatch)
            {
                var handler = Consume;
                if (handler != null)
                {
                    foreach (var dlg in handler.GetInvocationList())
                    {
                        try
                        {
                            dlg?.DynamicInvoke(this, EventArgs.Empty);
                        }
                        catch (Exception ex)
                        {
                            Logger?.LogError("Error triggering throttled consumption", ex);
                        }
                    }
                }
            }
        }

        public event EventHandler Consume;
    }
}
