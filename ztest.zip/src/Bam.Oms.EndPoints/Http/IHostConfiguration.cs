﻿namespace Bam.Oms.EndPoints.Http
{
    public interface IHostConfiguration
    {
        string BaseUrl { get; } 
    }
}