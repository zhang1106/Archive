﻿namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    public enum HeadroomDirection
    {
        All,
        Long,
        Short,
        NetShort,
        NetLong
    }
}
