using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.EndPoints.Database;
using Bam.Oms.EndPoints.Eze;
using Bam.Oms.EndPoints.File;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.EndPoints.Hub.Signals;
using Bam.Oms.EndPoints.MQ;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.EndPoints.SodPosition;
using Bam.Oms.Filtering;
using BAM.Common.Messaging;
using Bam.Oms.Messaging;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints
{
    public class TypeRegistration : ITypeRegistration
    {
        public void RegisterTypes(Container container)
        {
            ISettings settings = container.Resolve<ISettings>();
            container.RegisterType<ILogger, Logger>(RegistrationType.Singleton);
            container.RegisterType<IPermissionSvcClient, PermissionSvcClient>(RegistrationType.Transient, new InjectionConstructor());
            
            var baseUrl = settings.BaseUrl;
            var basePort = settings.BasePort;

            var host = new HostConfiguration() { BaseUrl = $"http://{baseUrl}:{basePort}"}; 
            container.RegisterInstance<IHostConfiguration>(host);

            container.RegisterType<IOrderPrepUtility, OrderPrepUtility>(RegistrationType.Singleton);
            
            var fileConfig = new FileConfiguration { Path = settings.OrderFileLocation };
            container.RegisterInstance<IFileConfiguration>(fileConfig);
            container.RegisterTypeLoggingVirtualInterceptor<IOrderSubmission, Http.Listener>(RegistrationType.Singleton, "http");
            if (settings.EmsName.Equals(EmsSystem.Eze))
            {
                container.RegisterType<IOrderSubmission, File.OrderListener>(RegistrationType.Singleton, "file");
            }
            else
            {
                container.RegisterType<IOrderSubmission, File.Listener>(RegistrationType.Singleton, "file");
            }
            var http = container.Resolve<IOrderSubmission>("http") as IOrderNotifier;
            container.RegisterInstance(http);

            //hub speicific pieces
            container.RegisterType<ISignalRSessions<Order>, SignalRSessions<Order>>(RegistrationType.Singleton);
            container.RegisterType<ISignalRSessions<BlockTrade>, SignalRSessions<BlockTrade>>(RegistrationType.Singleton);
            container.RegisterType<ISignalRSessions<Position>, SignalRSessions<Position>>(RegistrationType.Singleton);

            container.RegisterType<OrderHubSignal, OrderHubSignal>(RegistrationType.Singleton);
            //container.RegisterType<PositionHubSignal, PositionHubSignal>(RegistrationType.Singleton);
            container.RegisterType<TradeHubSignal, TradeHubSignal>(RegistrationType.Singleton);

            if (!string.IsNullOrWhiteSpace(settings.MqConnectionString))
            {
                container.RegisterType<IConnection, Connection>(
                    RegistrationType.Singleton, new InjectionConstructor(settings.MqConnectionString, true));
                container.RegisterType<IFlowClient, MQFlowClient>(RegistrationType.Singleton, "mq",
                    new InjectionConstructor(typeof(IConnection), settings.MqTradeTopic, settings.MqOrderTopic, settings.MqPositionTopic, settings.MqEzeOrderTopic, typeof(ISettings), typeof(ILogger)));
                container.RegisterType<IRollClient, MQRollClient>(RegistrationType.Singleton, "mqEOD",
                    new InjectionConstructor(typeof(IConnection), settings.MqEODTradeTopic, settings.MqEODOrderTopic, settings.MqEODPositionTopic, typeof(ISettings), typeof(ILogger)));
            }            

            container.RegisterType<IRollClient, DBRollClient>(RegistrationType.Singleton, "dbEOD");       
            
            container.RegisterType<ITranslator, Translator>(RegistrationType.Singleton);

            container.RegisterType<IMessageHandler, MessageHandler>(RegistrationType.Singleton);
            container.RegisterType<IPositionImportExport, CsvPositionImportExport>(RegistrationType.Singleton);
        }
    }
}