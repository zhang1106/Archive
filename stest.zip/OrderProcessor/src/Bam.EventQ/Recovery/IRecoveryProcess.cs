﻿namespace Bam.EventQ.Recovery
{
    public interface IRecoveryProcess
    {
        bool Execute(int? topic, long sequence);
    }
}
