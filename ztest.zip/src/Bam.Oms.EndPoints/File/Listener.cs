﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Data.Orders;
using Bam.Oms.EndPoints.Orders;
using BAM.Infrastructure.Ioc;
using CsvHelper;
using Bam.Oms.Data.Configuration;
using Bam.Oms.RefData;
using Newtonsoft.Json;

namespace Bam.Oms.EndPoints.File
{
    public class Listener : AbstractListener, IOrderSubmission, IDisposable
    {
        public Listener(IFileConfiguration fileConfiguration, ILogger logger, IOrderPrepUtility orderPrepUtility,
            IOrderValidator orderValidator, ILoggingSerializer loggingSerializer, IAccountService accountService)
            : base(fileConfiguration, logger, orderPrepUtility, orderValidator, loggingSerializer, accountService)
        {
        }

        protected override List<IOrder> ParseFile(string path)
        {
            if (path == null) throw new ArgumentNullException("path");

            var orderList = new List<IOrder>();

            //validates the file has completed copying
            OpenFileStream(path); 

            using (var reader = new CsvReader(System.IO.File.OpenText(path)))
            {
                reader.Configuration.RegisterClassMap<OrderMapping>();

                while (reader.Read())
                {
                    try
                    {
                        var order = reader.GetRecord<Order>();

                        //there are set number of required columns
                        //the first 6 are required, so any execution instructions will be additional optional 
                        //columns
                        for (var i = 6; i < reader.FieldHeaders.Length; i++)
                        {
                            string field;
                            if (reader.TryGetField(i, out field))
                            {
                                var header = reader.FieldHeaders[i];
                                var inst = new ExecutionInstruction(header, field);
                                order.ExecutionInstructions.Add(inst);
                            }
                        }

                        orderList.Add(order);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error($"Unable to read record row {JsonConvert.SerializeObject(reader.CurrentRecord)}; {ex.Message} - {ex.StackTrace}");
                        //Do not proceed even if one record is not parsable
                        throw;
                    }
                }
            }

            return orderList;
        }

        #region IDisposable Support       

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);

            // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
            // TODO: set large fields to null.                
        }
        #endregion
    }
}
