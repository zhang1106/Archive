﻿using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public class PositionEffectCalculator : IPositionEffectCalculator
    {       
        public ComplianceEffects CalculateComplianceEffects(OrderInfo orderInfo)
        {
            long longMarkingEffect = 0;
            long shortMarkingEffect = 0;

            if (!orderInfo.IsOmni)
            {
                var sellSide = orderInfo.Side.IsSellSide();
                var orderQty = orderInfo.OrderSize;
                var filledQty = orderInfo.FillQuantity;

                if (sellSide)
                {
                    orderQty = -orderQty;
                    filledQty = -filledQty;
                }

                if (orderInfo.IsLive)
                {
                    longMarkingEffect = sellSide ? filledQty : orderQty;
                    shortMarkingEffect = sellSide ? orderQty : filledQty;
                }
                else
                { 
                    longMarkingEffect = filledQty;
                    shortMarkingEffect = filledQty;
                }
            }

            return new ComplianceEffects
            {
                LongMarkingQuantity = longMarkingEffect,
                ShortMarkingQuantity = shortMarkingEffect
            };
        }

        public ActualEffects CalculateActualEffects(AllocationInfo allocInfo)
        {
            var isShortSide = allocInfo.Side.IsSellSide();
            var filledQty = allocInfo.FillQuantity;
            if (isShortSide)
            {
                filledQty = -filledQty;
            }

            return new ActualEffects
            {
                Quantity = filledQty
            };
        }

        public TheoreticalEffects CalculateTheoreticalEffects(AllocationInfo allocInfo)
        {
            var isShortSide = allocInfo.Side.IsSellSide();

            var orderQty = allocInfo.TotalQuantity;
            var filledQty = allocInfo.FillQuantity;
            if (isShortSide)
            {
                orderQty = -orderQty;
                filledQty = -filledQty;
            }

            var theoreticalEffect = allocInfo.IsDead ? filledQty : orderQty;

            return new TheoreticalEffects
            {
                Quantity = theoreticalEffect
            };
        }
    }
}
