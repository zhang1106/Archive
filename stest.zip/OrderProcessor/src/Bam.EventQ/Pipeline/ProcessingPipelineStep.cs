﻿using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Pipeline
{
    public class ProcessingPipelineStep<TIn> : IProcessingPipelineStep<TIn>
    {
        private readonly ManualResetEventSlim _initialized;
        private readonly ManualResetEventSlim _stopped;

        private IPipelineStepInitializer<TIn> Initializer { get; }
        public IQueue<PipelineQueueItem<TIn>> Queue { get; }
        public IQueueItemProducer<PipelineQueueItem<TIn>> Producer { get; }
        public ILogger Logger { get; set; }

        public ProcessingPipelineStep(
            IQueue<PipelineQueueItem<TIn>> queue,
            IPipelineStepInitializer<TIn> initializer,
            IQueueItemProducer<PipelineQueueItem<TIn>> producer)
        {
            Initializer = initializer;
            Queue = queue;
            Producer = producer;
            _initialized = new ManualResetEventSlim(false);
            _stopped = new ManualResetEventSlim(false);
        }

        public void Initialize()
        {
            Producer.Initialize(Queue);
            Queue.Start();
        }

        public void Start(CancellationToken cancellationToken)
        {
            Initializer.Execute(Queue, cancellationToken);
            if (!cancellationToken.IsCancellationRequested)
            {
                Producer.Start();
            }
            _initialized.Set();
        }
        
        public void Stop()
        {
            _stopped.Set();
            _initialized.Set();
            Producer.Stop();
            Queue.Stop();
        }

        public bool Pause()
        {
            _initialized.Wait();
            if (_stopped.IsSet)
            {
                Logger?.LogInformation("Cannot pause pipeline step after it was stopped");
                return false;
            }
            
            Logger?.LogDebug("Pausing producer");
            Producer.Pause();
            Logger?.LogDebug("Paused producer");

            Logger?.LogDebug("Waiting for event handlers to complete");
            while (Queue.HasBacklog())
            {
                Thread.Sleep(0);
            }
            Logger?.LogDebug("Event handlers completed");

            return true;
        }

        public void Resume()
        {
            if (_stopped.IsSet)
            {
                Logger?.LogInformation("Cannot resume pipeline step after it was stopped");
                return;
            }

            Logger?.LogDebug("Resuming producer");
            Producer.Resume();
        }
        
        public void AddErrorHandler(IQueueErrorHandler handler)
        {
            Queue.AddErrorHandler(handler);
        }

        public void AddSubscriptionChain(params IQueueItemHandler<PipelineQueueItem<TIn>>[] handlers)
        {
            Queue.AddSubscriptionChain(handlers);
        }
    }
}
