USE OrderGatewayMain;

IF COL_LENGTH('[og].[PmOrder]', 'TargetSubId') IS NOT NULL
BEGIN
	ALTER TABLE [og].[PmOrder]
	DROP COLUMN TargetSubId, SenderSubId
END
GO

IF COL_LENGTH('[og].[EmsOrder]', 'TargetSubId') IS NOT NULL
BEGIN
	ALTER TABLE [og].[EmsOrder]
	DROP COLUMN TargetSubId, SenderSubId
END
GO

IF COL_LENGTH('[og].[PmOrder]', 'ComplianceOverrideMessage') IS NULL
BEGIN
	ALTER TABLE [og].[PmOrder]
	ADD ComplianceOverrideMessage VARCHAR(MAX) NULL
END
GO

IF COL_LENGTH('[og].[PmOrder]', 'StatusMessages') IS NULL
BEGIN
	ALTER TABLE [og].[PmOrder]
	ADD StatusMessages VARCHAR(MAX) NULL
END
GO

IF COL_LENGTH('[og].[PmOrder]', 'ModifiedUser') IS NULL
BEGIN
	ALTER TABLE [og].[PmOrder]
	ADD ModifiedUser VARCHAR(100) NULL,
	    LastModified DATE NULL,
		CreatedUser VARCHAR(100) NULL,
		Destination VARCHAR(100) NULL,
		SubmissionMethod VARCHAR(100) NULL
END
GO

IF OBJECT_ID('[og].[PmOrderLocate]') IS NULL
BEGIN
	CREATE TABLE [og].[PmOrderLocate]
	(
		[PmOrderId]			BIGINT NOT NULL,
		[AssignmentId]		VARCHAR(100) NULL,
		[Quantity]			BIGINT NULL,
		[Broker]			VARCHAR(100) NULL,
		[ApprovalTime]		DATETIME NULL,
		[Status]			VARCHAR(100) NULL,
		[Rate]				DECIMAL(10,6) NULL,
		[RateType]			VARCHAR(100) NULL
	)
END