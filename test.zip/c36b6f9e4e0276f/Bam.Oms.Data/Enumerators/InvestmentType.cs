﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data.Enumerators
{
    public enum InvestmentType
    {
        [Enum(StringValue = "NOT SPECIFIED")]
        NotSpecified,
        [Enum(StringValue = "FXO")]
        Fxo,
        [Enum(StringValue = "MLP")]
        MLP,
        [Enum(StringValue = "Commodity Calendar Spread")]
        CommodityCalendarSpread,
        [Enum(StringValue = "Swap Rate")]
        SwapRate,
        [Enum(StringValue = "Basket")]
        Basket,
        [Enum(StringValue = "Currency")]
        Currency,
        [Enum(StringValue = "Future Commodity Option")]
        FutureCommodityOption,
        [Enum(StringValue = "Depository Receipt")]
        DepositoryReceipt,
        [Enum(StringValue = "VOLSWAP")]
        VOLSWAP,
        [Enum(StringValue = "Pair")]
        Pair,
        [Enum(StringValue = "Credit Default Munis Index")]
        CreditDefaultMunisIndex,
        [Enum(StringValue = "ETF")]
        ETF,
        [Enum(StringValue = "Credit Default Index")]
        CreditDefaultIndex,
        [Enum(StringValue = "Depositary Receipt")]
        DepositaryReceipt,
        [Enum(StringValue = "Commodity")]
        Commodity,
        [Enum(StringValue = "VARSWAP")]
        VARSWAP,
        [Enum(StringValue = "Index")]
        Index,
        [Enum(StringValue = "Forward Point")]
        ForwardPoint,
        [Enum(StringValue = "Municipal Bond")]
        MunicipalBond,
        [Enum(StringValue = "Government Bond")]
        GovernmentBond,
        [Enum(StringValue = "Calendar Spread Option")]
        CalendarSpreadOption,
        [Enum(StringValue = "Corporate Bond")]
        CorporateBond,
        [Enum(StringValue = "Repo And Reverse")]
        RepoAndReverse,
        [Enum(StringValue = "144A")]
        _144A,
        [Enum(StringValue = "Restricted")]
        Restricted,
        [Enum(StringValue = "Credit Default")]
        CreditDefault,
        [Enum(StringValue = "Cap And Floor")]
        CapAndFloor,
        [Enum(StringValue = "Option Commodity Exotic")]
        OptionCommodityExotic,
        [Enum(StringValue = "Future Bond Option")]
        FutureBondOption,
        [Enum(StringValue = "Credit Default Sovereign")]
        CreditDefaultSovereign,
        [Enum(StringValue = "Option Index Exotic")]
        OptionIndexExotic,
        [Enum(StringValue = "Index Option")]
        IndexOption,
        [Enum(StringValue = "FX EXOTIC,")]
        FxExotic,
        [Enum(StringValue = "Mutual Fund")]
        MutualFund,
        [Enum(StringValue = "Warrant And Right")]
        WarrantAndRight,
        [Enum(StringValue = "Future IR Option")]
        FutureIrOption,
        [Enum(StringValue = "Implied Vol")]
        ImpliedVol,
        [Enum(StringValue = "Bond")]
        Bond,
        [Enum(StringValue = "Equity")]
        Equity,
        [Enum(StringValue = "Convertible Bond")]
        ConvertibleBond,
        [Enum(StringValue = "CDS Option")]
        CdsOption,
        [Enum(StringValue = "Credit Default Munis")]
        CreditDefaultMunis,
        [Enum(StringValue = "Equity Swap Fully Funded")]
        EquitySwapFullyFunded,
        [Enum(StringValue = "FLEX")]
        Flex,
        [Enum(StringValue = "Option Equity Exotic")]
        OptionEquityExotic,
        [Enum(StringValue = "FVA")]
        FVA,
        [Enum(StringValue = "Spot")]
        Spot,
        [Enum(StringValue = "Asset Backed")]
        AssetBacked,
        [Enum(StringValue = "Cash")]
        Cash,
        [Enum(StringValue = "Forward")]
        Forward,
        [Enum(StringValue = "Future Currency Option")]
        FutureCurrencyOption,
        [Enum(StringValue = "Floating Rate")]
        FloatingRate,
        [Enum(StringValue = "FSO")]
        FSO,
        [Enum(StringValue = "Equity Swap")]
        EquitySwap,
        [Enum(StringValue = "Cap And Floor Spread")]
        CapAndFloorSpread,
        [Enum(StringValue = "Fixed Rate")]
        FixedRate,
        [Enum(StringValue = "Option Multi-Asset Exotic")]
        OptionMultiAssetExotic,
        [Enum(StringValue = "Base Rate")]
        BaseRate,
        [Enum(StringValue = "FRA")]
        FRA,
        [Enum(StringValue = "Preferred")]
        Preferred,
        [Enum(StringValue = "Future Index Option")]
        FutureIndexOption,
        [Enum(StringValue = "Swap Spread")]
        SwapSpread,
        [Enum(StringValue = "Interest Rate")]
        InterestRate,
        [Enum(StringValue = "CORSWAPFX")]
        CORSWAPFX,
        [Enum(StringValue = "Future")]
        Future,
        [Enum(StringValue = "Swaption Exotic")]
        SwaptionExotic,
        [Enum(StringValue = "Ordinary Share")]
        OrdinaryShare,
        [Enum(StringValue = "PNote")]
        PNote,
        [Enum(StringValue = "Swaption")]
        Swaption,
        [Enum(StringValue = "Unit")]
        Unit,
        [Enum(StringValue = "Option Rates Exotic")]
        OptionRatesExotic,
        [Enum(StringValue = "Future Single Stock")]
        FutureSingleStock,
        [Enum(StringValue = "Private")]
        Private
    }
}
