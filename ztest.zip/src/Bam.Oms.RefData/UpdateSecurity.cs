using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.RefData
{
    public class UpdateSecurity : Security, IUpdateSecurity
    {
        public string SettlementCurrency { get; set; }
        public string UnderlyingCurrency { get; set; }
        public string TradingCurrency { get; set; }
    }
}