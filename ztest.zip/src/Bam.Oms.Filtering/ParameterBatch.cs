﻿using System.Collections.Generic;

namespace Bam.Oms.Filtering
{
    public class ParameterBatch
    {
        public IList<Parameter> Filters { get; } = new List<Parameter>();
    }
}