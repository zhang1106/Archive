﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Securities;
namespace Bam.Oms.Persistence.Securities
{
    public interface ISecurityDBRepository
    {
        IEnumerable<Security> GetSecurities(string[] underlyings=null, DateTime lastUpdated = default(DateTime));
    }
}
