﻿using System;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Diagnostics
{
    public class LogErrorHandler : IQueueErrorHandler
    {
        private readonly ILogger _logger;

        public LogErrorHandler(ILogger logger)
        {
            _logger = logger;
        }

        public void HandleError(Exception ex, long? sequence, object evt)
        {
            if (sequence != null)
            {
                _logger.LogError("Error while processing item at sequence " + sequence, ex);
            }
            else
            {
                _logger.LogError(ex.ToString());
            }
        }
    }
}
