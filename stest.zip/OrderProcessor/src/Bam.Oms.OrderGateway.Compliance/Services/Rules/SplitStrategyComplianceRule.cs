﻿using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public class SplitStrategyComplianceRule : EventRelay<IMessage>, IRule
    {
        private readonly Dictionary<Portfolio, HashSet<Portfolio>> _seenSplitRuleConnections;
        private readonly IReferenceDataService _referenceService;
        private readonly IModelIndex<Order> _orders;

        public string Name => "Split Strategy";

        public SplitStrategyComplianceRule(IReferenceDataService referenceService, IIndexFactory index)
        {
            _seenSplitRuleConnections = new Dictionary<Portfolio, HashSet<Portfolio>>();
            _referenceService = referenceService;
            _orders = index.For<Order>();
        }

        public void Execute(RuleContext context, List<RuleViolation> violations)
        {
            int conflicts = 0;

            StrategyAllocationRule rule;
            if (_referenceService.TryGetStrategyAllocationRule(context.Order.TopLevelPortfolio, out rule))
            {
                conflicts += CountActiveOrders(context.Order.TopLevelPortfolio, context.Order, true);

                foreach (var item in rule.Ratios.Keys)
                {
                    conflicts += CountActiveOrders(item, context.Order);

                    HashSet<Portfolio> connections;
                    if (_seenSplitRuleConnections.TryGetValue(item, out connections))
                    {
                        connections.Add(context.Order.TopLevelPortfolio);
                    }
                    else
                    {
                        _seenSplitRuleConnections.Add(item,
                            new HashSet<Portfolio> { context.Order.TopLevelPortfolio });
                    }
                }
            }
            else
            {
                HashSet<Portfolio> connections;
                if (_seenSplitRuleConnections.TryGetValue(context.Order.TopLevelPortfolio, out connections))
                {
                    foreach (var splitStrategy in connections)
                    {
                        conflicts += CountActiveOrders(splitStrategy, context.Order);
                    }
                }
            }

            if (conflicts > 0)
            {
                violations.Add(new RuleViolation
                {
                    Message = $"There can be only one active order for strategy '{context.Order.TopLevelPortfolio.Key}' or its constituents at a time.",
                    RuleName = Name,
                    Level = ComplianceViolationLevel.Restricted,
                    Status = ComplianceStatus.RuleFailure
                });
            }
        }

        private int CountActiveOrders(Portfolio portfolio, Order order, bool ignoreSameSide = false)
        {
            var all = _orders.MultiLookupBy(nameof(Order.TopLevelPortfolio), portfolio);
            int count = 0;
            foreach (var item in all)
            {
                if (item.OrderId == order.OrderId || item.IsDead || item.IsComplete || 
                    item.Security.Symbol != order.Security.Symbol)
                    continue;

                bool bothOpening = order.ContainsOpeningAllocations && item.ContainsOpeningAllocations;
                bool bothClosing = order.ContainsClosingAllocations && item.ContainsClosingAllocations;

                if (ignoreSameSide && (bothClosing || bothOpening))
                    continue;

                count++;
            }

            return count;
        }
    }
}
