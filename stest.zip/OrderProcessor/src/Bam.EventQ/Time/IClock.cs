﻿using System;

namespace Bam.EventQ.Time
{
    public interface IClock
    {
        DateTime BusinessDate { get; }
        DateTime Now { get; }
        DateTime Today { get; }
        string ZoneId { get; }
        int Timestamp { get; }

        DateTime From(DateTime utc);
        DateTime From(DateTimeOffset dateTime);
        TimeZoneInfo GetTimeZoneInfo();
        DateTime GetNextBusinessDay(TimeSpan minimumTimeToRollToNextDay);
        void SetBusinessDay(DateTime businessDateTime);
    }
}
