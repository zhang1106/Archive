﻿using System;
using Newtonsoft.Json;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.Results;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.Rules
{
    public class ShortSharesOutstandingWarning : FirmRuleBase
    {
        [JsonProperty]
        public decimal? Threshhold{ get; set; }
        public override IRuleResult CheckViolation(ICompliancePosition input, bool isPreCheck)
        {
            var result = new ShortSharesOutstandingWarningResult()
            {
                RuleId = this.Id,
                BamSymbol = input.BamSymbol,
                Type = "ShortSharesOutstandingWarningResult",
                RuleName = this.Name,
                Description = "No violation",
                PolicyId = input.PolicyId,
                IsViolationOverriden = false,
                AlertLevel = ComplianceAlertLevel.NoViolation
            };

            try
            {
                var context = string.Empty;
                ISecurity security = input.Security;
                //appy filters first
                if (IsActive && (SecurityFilter == null || SecurityFilter.ApplyFilter(this.GetType().FullName, security)))
                {
                    var currentHeld = input.PositionProvider.GetFirmWideQuantity(input.BamSymbol, input.PositionType, SideType.Short);
                    var sharesOutstanding = input.MarketDataProvider.GetSharesOutstanding(input.BamSymbol);
                    var ratio = currentHeld.Item2 / sharesOutstanding;
                    context = currentHeld.Item1;
                    result.Ratio = ratio;
                    if (ratio.HasValue)
                    {
                        result.AlertLevel = ratio < Threshhold ? ComplianceAlertLevel.Warning : ComplianceAlertLevel.NoViolation;
                        result.Description = result.AlertLevel == ComplianceAlertLevel.NoViolation ? "No Violation" :
                            $"Going below {Threshhold*100}%";
                    }
                    else
                    {
                        result.AlertLevel = ComplianceAlertLevel.NoDataAvaiable;
                        result.Description = "No data avaiable to calculate ratio";
                    }
                    input.Helper.LogEvent(result.Key, context);
                }
            }
            catch (Exception ex)
            {
                result.AlertLevel = ComplianceAlertLevel.Error;
                result.Description = ex.Message;
                input.Logger.Error(ex.Message);
            }

            return result;
        }
    }
}
