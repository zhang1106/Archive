﻿using System.Threading;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Pipeline
{
    public interface IProcessingPipelineStep
    {
        void Initialize();
        void Start(CancellationToken cancellationToken);
        void Stop();
        bool Pause();
        void Resume();
    }

    public interface IProcessingPipelineStep<TIn> : IProcessingPipelineStep
    {
        IQueue<PipelineQueueItem<TIn>> Queue { get; }
        IQueueItemProducer<PipelineQueueItem<TIn>> Producer { get; }

        void AddErrorHandler(IQueueErrorHandler handler);
        void AddSubscriptionChain(params IQueueItemHandler<PipelineQueueItem<TIn>>[] handlers);
    }
}