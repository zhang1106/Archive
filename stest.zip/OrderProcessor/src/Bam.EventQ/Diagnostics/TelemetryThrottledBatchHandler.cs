﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Bam.EventQ.Throttling;

namespace Bam.EventQ.Diagnostics
{
    public class TelemetryThrottledBatchHandler<TItem> : IThrottledBatchHandler<TItem>, IDisposable
    {
        private readonly IThrottledBatchHandler<TItem> _inner;
        private readonly ITelemetry _telemetry;
        private readonly Stopwatch _sw;

        public TelemetryThrottledBatchHandler(IThrottledBatchHandler<TItem> inner, ITelemetry telemetry)
        {
            _inner = inner;
            _telemetry = telemetry;
            _sw = new Stopwatch();
        }

        public void Handle(IReadOnlyList<TItem> batch)
        {
            _sw.Restart();
            try
            {
                _inner.Handle(batch);
            }
            finally
            {
                _sw.Stop();
                var type = _inner.GetType().GetDisplayName();
                _telemetry.Record($"{type}-Capacity", batch.Count / _sw.Elapsed.TotalSeconds);
                _telemetry.Record($"{type}-BatchSize", batch.Count);
                _telemetry.Record($"{type}-CpuTime", _sw.Elapsed.TotalMilliseconds);
            }
        }

        public void Dispose()
        {
            (_inner as IDisposable)?.Dispose();
        }
    }
}
