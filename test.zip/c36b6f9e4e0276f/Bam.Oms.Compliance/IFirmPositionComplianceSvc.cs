﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Compliance
{
    public interface IFirmPositionComplianceSvc
    {
        void Init();
        void RefreshRefData();

        List<IRuleResult> Run(PositionType type);
        IEnumerable<IRuleResult> CheckViolations(IList<string> securities, PositionType pType);
      
        List<IRuleResult> RunEod(DateTime data);

        bool SodPositionReady { get; }
    }
}
