﻿namespace Bam.Oms.EndPoints.Http
{
    public class HostConfiguration : IHostConfiguration
    {
        public string BaseUrl { get; set; }
    }
}