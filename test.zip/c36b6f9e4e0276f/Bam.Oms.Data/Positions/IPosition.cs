﻿using System;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Data.Positions
{
    public interface IPosition : IPersistentItem
    {
        Portfolio Portfolio { get; }
        Security Security { get; }

        string CustodianName { get; set; }

        DateTime EntryDate { get; set; }

        //Unsigned
        [Obsolete("Use the signed property")]
        decimal TheoreticalQuantity { get; set; }
        SideType TheoreticalSide { get; set; }

        //Unsigned
        decimal ActualQuantity { get; set; }

        SideType ActualSide { get; }
        
        decimal? Price { get; set; }
        decimal? FXRate { get; set; }

        decimal? NetExposure { get; set; }

        string ParentSymbol { get; set; }
        string Currency { get; set; }
        string CustodianAccount { get; set; }
        long EquivalentQuantity { get; set; }

        IPosition InitPosition();
    }
}
