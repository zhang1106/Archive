﻿using System;

namespace Bam.EventQ.Time
{
    public class ClockFactory : IClockFactory
    {
        public IClock Create(string zoneId)
        {
            if (zoneId.Equals("UTC", StringComparison.OrdinalIgnoreCase))
            {
                return Clock.Utc;
            }

            var zone = TimeZoneInfo.FindSystemTimeZoneById(zoneId);
            return new Clock(zoneId, zone);
        }
    }
}
