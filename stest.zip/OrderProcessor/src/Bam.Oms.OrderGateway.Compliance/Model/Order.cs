﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;
using Bam.Oms.OrderGateway.Compliance.PositionTracker;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;
using Bam.Oms.OrderGateway.Compliance.Services.Headroom;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public class Order : EventRelay<IMessage>
    {
        private readonly List<OrderStrategyAllocation> _allocations;
        private readonly Dictionary<PositionKey, OrderStrategyAllocation> _allocationMap;
        private readonly List<OrderAllocation> _openingAllocations, _closingAllocations;

        public Order(long id, CachedSecurity security, Portfolio topLevelPortfolio, 
            long size, Side side, string reportingEntity, string aggUnit)
        {
            OrderId = id;
            Size = size;
            Side = side;
            ReportingEntity = reportingEntity;
            Security = security;
            TopLevelPortfolio = topLevelPortfolio;
            Status = OrderStatus.PendingValidation;
            AggregationUnit = aggUnit;

            _allocations = new List<OrderStrategyAllocation>();
            _allocationMap = new Dictionary<PositionKey, OrderStrategyAllocation>();
            _openingAllocations = new List<OrderAllocation>();
            _closingAllocations = new List<OrderAllocation>();
        }
        
        public long OrderId { get; }
        public CachedSecurity Security { get; }
        public bool IsOmni { get; set; }
        public Portfolio TopLevelPortfolio { get; }
        public string ReportingEntity { get; }
        public string AggregationUnit { get; }
        public Side Side { get; private set; }
        public OrderStatus Status { get; set; }
        public int? FundAllocationOverride { get; set; }

        public long Size { get; private set; }
        public long FilledQuantity { get; private set; }
        public long OpeningQuantity { get; private set; }
        public long ClosingQuantity { get; private set; }
        public long OpeningQuantitySansOmni => Size - ClosingQuantitySansOmni;
        public long ClosingQuantitySansOmni { get; private set; }

        public bool ContainsOpeningAllocations => _openingAllocations.Count > 0;
        public bool ContainsClosingAllocations => _closingAllocations.Count > 0;

        public IReadOnlyDictionary<PositionKey, OrderStrategyAllocation> Allocations => _allocationMap;
        
        public Order Clone(long id)
        {
            var order = new Order(id, Security, TopLevelPortfolio, Size, Side, ReportingEntity, AggregationUnit)
            {
                FilledQuantity = FilledQuantity,
                Status = Status,
                IsOmni = IsOmni,
                FundAllocationOverride = FundAllocationOverride
            };

            foreach (var alloc in _allocations)
            {
                var copy = alloc.Clone(order);
                order._allocations.Add(copy);
                order._allocationMap[copy.Key] = copy;
            }

            return order;
        }

        public void ChangeSide(Side side)
        {
            Side = side;
        }
        
        public bool IsDead =>
            Status == OrderStatus.Error ||
            Status == OrderStatus.ComplianceError ||
            Status == OrderStatus.Finalized ||
            Status == OrderStatus.Deleted ||
            Status == OrderStatus.PendingValidation ||
            Status == OrderStatus.Filled ||
            Status == OrderStatus.Cancelled;

        public bool IsLive => 
            Status == OrderStatus.ComplianceWarning ||
            Status == OrderStatus.Filled ||
            Status == OrderStatus.Working ||
            Status == OrderStatus.New ||
            Status == OrderStatus.PendingAck ||
            Status == OrderStatus.PendingCancel;

        public bool IsComplete => 
            Status == OrderStatus.Error || 
            Status == OrderStatus.Cancelled || 
            Status == OrderStatus.Finalized || 
            Status == OrderStatus.Deleted;

        public void ChangeSize(long size)
        {
            Size = size;
        }

        public void SetOpeningAllocations(List<OrderAllocation> allocations)
        {
            _openingAllocations.Clear();
            _openingAllocations.AddRange(allocations);
            OpeningQuantity = 0;
            foreach (var alloc in _openingAllocations)
            {
                OpeningQuantity += alloc.Quantity;
            }
        }

        public void SetClosingAllocations(List<OrderAllocation> allocations)
        {
            _closingAllocations.Clear();
            _closingAllocations.AddRange(allocations);
            ClosingQuantity = 0;
            ClosingQuantitySansOmni = 0;
            foreach (var alloc in _closingAllocations)
            {
                ClosingQuantity += alloc.Quantity;
                ClosingQuantitySansOmni += alloc.ClosingPortionSansOmni;
            }
        }

        public void UpdateActualAllocations(List<OrderAllocation> allocations)
        {
            FilledQuantity = 0;
            var keyed = new Dictionary<PositionKey, List<OrderAllocation>>();

            foreach (var item in allocations)
            {
                var pk = new PositionKey(item.Portfolio, Security.Symbol);
                FilledQuantity += item.Quantity;

                List<OrderAllocation> slice;
                if (!keyed.TryGetValue(pk, out slice))
                {
                    slice = keyed[pk] = new List<OrderAllocation>();
                }

                slice.Add(item);

                if (!_allocationMap.ContainsKey(pk))
                {
                    var alloc = new OrderStrategyAllocation(this, pk);
                    _allocations.Add(alloc);
                    _allocationMap.Add(pk, alloc);
                }
            }

            foreach (var alloc in _allocations)
            {
                List<OrderAllocation> slice;
                alloc.UpdateActualAllocations(
                    keyed.TryGetValue(alloc.Key, out slice)
                        ? slice
                        : new List<OrderAllocation>());
            }
        }

        public void UpdateTheoreticalAllocations(List<OrderAllocation> allocations)
        {
            Size = 0;
            var keyed = new Dictionary<PositionKey, List<OrderAllocation>>();

            foreach (var item in allocations)
            {
                var pk = new PositionKey(item.Portfolio, Security.Symbol);
                Size += item.Quantity;

                List<OrderAllocation> slice;
                if (!keyed.TryGetValue(pk, out slice))
                {
                    slice = keyed[pk] = new List<OrderAllocation>();
                }

                slice.Add(item);

                if (!_allocationMap.ContainsKey(pk))
                {
                    var alloc = new OrderStrategyAllocation(this, pk);
                    _allocations.Add(alloc);
                    _allocationMap.Add(pk, alloc);
                }
            }

            foreach (var alloc in _allocations)
            {
                List<OrderAllocation> slice;
                alloc.UpdateTheoreticalAllocations(
                    keyed.TryGetValue(alloc.Key, out slice)
                        ? slice
                        : new List<OrderAllocation>());
            }
        }

        public void GetAllocations(List<OrderAllocation> opening, List<OrderAllocation> closing)
        {
            opening.AddRange(_openingAllocations);
            closing.AddRange(_closingAllocations);
        }

        public void ApplyPositionEffects(Func<PositionKey, PositionSet> setAccessor,
            IPositionEffectCache cache, IPositionEffectCalculator calculator)
        {
            foreach (var item in _allocations)
            {
                var set = setAccessor(item.Key);
                using (Attach(set.Position))
                using (Attach(set.CompliancePosition))
                using (Attach(set.AggUnitPosition))
                {
                    item.ApplyEffects(set, cache, calculator);
                }
            }
        }

        public void ApplyHeadroomEffects(HeadroomRule rule,
            IHeadroomEffectCache cache, IHeadroomEffectCalculator calculator)
        {
            if (rule.ReportingEntity != HeadroomRule.FirmReportingEntity &&
                rule.ReportingEntity != ReportingEntity)
            {
                return;
            }

            using (Attach(rule))
            {
                var info = new HeadroomInfo
                {
                    Side = Side,
                    FilledQuantity = FilledQuantity,
                    IsOmni = IsOmni,
                    OpeningQuantity = OpeningQuantitySansOmni,
                    IsDead = IsDead,
                    ClosingQuantity = ClosingQuantitySansOmni,
                    TotalQuantity = Size
                };

                var identifier = rule.GetIdentifier(Security);
                var previousEffect = cache.GetEffect(OrderId, rule.Id, identifier);
                var effect = calculator.Calculate(info) * Security.ConversionRatio;
                var delta = effect - previousEffect;

                if (rule.ApplyHeadroomEffects(identifier, delta))
                {
                    cache.SetEffect(OrderId, rule.Id, identifier, effect);
                }
            }
        }
    }
}
