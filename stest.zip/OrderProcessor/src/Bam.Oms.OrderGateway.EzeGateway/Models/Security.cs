﻿using Bam.Oms.OrderGateway.Messages.RefDataGateway;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public class Security
    {
        public Security()
        {
            
        }

        public Security(SecurityUpdates.SecurityUpdatesItem item)
        {
            Symbol = item.BamSymbol;
            SecurityType = item.SecurityType;
            Currency = item.Currency;
        }

        public string Symbol { get; set; }
        public string SecurityType { get; set; }
        public string Currency { get; set; }
    }
}
