﻿using System.Collections.Generic;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Workflow
{
    public class WorkflowItemTransformer<TIn, TOut> : IQueueItemTransformer<TIn, TOut>
    {
        private readonly IWorkflowDispatcher<TIn, TOut> _workflowDispatcher;

        public WorkflowItemTransformer(IWorkflowDispatcher<TIn, TOut> workflowDispatcher)
        {
            _workflowDispatcher = workflowDispatcher;
        }

        public IReadOnlyList<TOut> Transform(TIn item, long sequence, bool isReplay)
        {
            return _workflowDispatcher.Dispatch(item, sequence, isReplay);
        }
    }
}
