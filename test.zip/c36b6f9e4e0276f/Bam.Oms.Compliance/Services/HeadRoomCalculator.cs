﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.Services
{
    public class HeadRoomCalculator : IHeadRoomCalculator
    {
        private readonly IFirmPositionComplianceSvc _firmPositionComplianceSvc;
        private readonly ISecurityProvider _securityProvider;
        private readonly IMarketDataProvider _marketDataProvider;
        private IHelper _helper;
        private readonly ILogger _logger;
        

        public HeadRoomCalculator(IFirmPositionComplianceSvc firmPositionComplianceSvc, ISecurityProvider securityProvider,
            IMarketDataProvider marketDataProvider, IHelper helper
            , ILogger logger)
        {
            _firmPositionComplianceSvc = firmPositionComplianceSvc;
            _securityProvider = securityProvider;
            _marketDataProvider = marketDataProvider;
            _logger = logger;
            _helper = helper;

        }

        public IEnumerable<HeadRoom> GetHeadRooms(IEnumerable<string> symbols, bool sod)
        {
            var results = GetNewHeadRooms(symbols, false);
            return results;
        }

        private void PreProcssSymbols(IEnumerable<string> symbols, out IList<string> notExists, out IList<string> noData, out IList<string> related  )
        {
            IList<string> noCurrentMarketData;
            _securityProvider.RetriveRelatedSecurites(symbols, out notExists, out related);
            _marketDataProvider.CheckMarketData(related, out noCurrentMarketData);
            noData = noCurrentMarketData;
        }

        public IEnumerable<HeadRoom> GetNewHeadRooms(IEnumerable<string> symbols, bool dump)
        {
            if (!_firmPositionComplianceSvc.SodPositionReady)
            {
                _logger.Info("Sod position is in the middle of updating");
                return _helper.CreateNoInfoFilingResult(symbols, "Service not available. Sod position is in the middle of updating").Select(r=>r.HeadRoom);
            }

            IList<string> notExists, noData, related;

            PreProcssSymbols(symbols, out notExists, out noData, out related);

            var tasks = new List<Task>();

            if (notExists.Any())
            {
                tasks.Add(Task.Factory.StartNew(() =>
                {
                    _logger.Info($"Securites: Querying DW for the {notExists.Count}");
                    _securityProvider.RetrieveSecurities(notExists.ToArray());
                }));
            }

            var bbSyms = notExists.Union(noData);
            IEnumerable<MarketData> bbData = null;

            if (bbSyms.Any())
            {
                tasks.Add(Task.Factory.StartNew(() =>
                {
                    bbData =_marketDataProvider.GetBbData(bbSyms);
                }));
            }

            Task.WaitAll(tasks.ToArray());

            //add to securites buff
            if (bbData != null && bbData.Any())
            {
               var lookup = notExists.ToLookup(s=>s);
               var newSecurities = _helper.Convert(
                    bbData.Where(b => b.SharesOutstanding.HasValue && lookup.Contains(b.Symbol)));

                _securityProvider.UpdateSecurites(newSecurities);
            }
            
            //do not check bloomberg data
            var results = _firmPositionComplianceSvc.CheckViolations(related, PositionType.Sod);
            
            var headRooms = results.Where(r => r.HeadRoom != null).Select(r => r.HeadRoom);
           

            return headRooms;
        }

        public IEnumerable<HeadRoom> CheckEodPosition(string symbol)
        {
            var results = _firmPositionComplianceSvc.CheckViolations(new List<string>(){symbol}, PositionType.Eod);

            var headRooms = results.Where(r => r.HeadRoom != null).Select(r => r.HeadRoom);
            
            return headRooms;
        }

        public void RefreshRefData()
        {
            _firmPositionComplianceSvc.RefreshRefData();
        }
    }
}
