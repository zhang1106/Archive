﻿using System.Collections.Generic;
using System.Linq;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance.Services
{
    public class RuleSvc : IRuleSvc
    {
        private IRuleRepository<CompliancePosition> _ruleRepository;

        public RuleSvc(IRuleRepository<CompliancePosition> ruleRepository)
        {
            _ruleRepository = ruleRepository;
        }

        public IList<Rule<CompliancePosition>> GetAll(int policyId)
        {
            return   _ruleRepository.GetRules(policyId).ToList();
        }
    }
}
