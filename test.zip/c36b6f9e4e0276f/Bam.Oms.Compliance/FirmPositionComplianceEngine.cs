﻿using System.Collections.Generic;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Filters;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.Policies;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance
{
    public class FirmPositionComplianceEngine : IEngine<ICompliancePosition>
    {
        private readonly IRuleRepository<ICompliancePosition> _ruleRepository;
        private readonly IPolicyProvider _policyProvider;
        private readonly IHelper _helper;
        public Dictionary<string, IPolicy<ICompliancePosition>> Policies { get; private set; }
        public FirmPositionComplianceEngine(IRuleRepository<ICompliancePosition> ruleRepository, IPolicyProvider policyProvider, IHelper helper)
        {
            _ruleRepository = ruleRepository;
            _policyProvider = policyProvider;
            _helper = helper;
            Policies = new Dictionary<string, IPolicy<ICompliancePosition>>();
        }
        public void Refresh()
        {
            Policies = new Dictionary<string, IPolicy<ICompliancePosition>>();
            var policies = _policyProvider.Get(new PolicyFilter());
            foreach (var policy in policies)
            {
                var fPolicy = (IPolicy<ICompliancePosition>)_helper.ConvertBaseToChild(policy);
                 RegisterPolicy(fPolicy);
            }
        }
        public void RegisterPolicy (IPolicy<ICompliancePosition> policy)
        {
            ((FirmPositionLimitPolicy)policy).PopulateRules(_ruleRepository);
            Policies.Add(policy.Name, policy);
        }
        /// <summary>
        /// check for violations against a policy by speicify policy ID or name
        /// </summary>
        public IPolicyResult CheckViolations(IPolicy<ICompliancePosition> policy, ICompliancePosition input, bool isPreCheck)
        {
            return policy.CheckViolations(input, isPreCheck);
        }
        public IPolicy<ICompliancePosition> GetPolicy(string name)
        {
            return Policies[name];
        }
    }
}
