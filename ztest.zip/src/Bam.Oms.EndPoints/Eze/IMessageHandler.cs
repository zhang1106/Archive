﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.EndPoints.Eze
{
    public interface IMessageHandler
    {
        void ProcessMessage(string message, string route);

        void SubscribeMqMessages();
    }
}
