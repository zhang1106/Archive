﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.Results;
using Microsoft.Practices.Unity;

namespace Bam.Oms.Compliance.DataProvider
{
    public class OwnershipRuleResultProvider : IOwnershipRuleResultProvider
    {
        readonly IRuleResultRepository _resultResultRepository;
        public OwnershipRuleResultProvider(IRuleResultRepository resultResultRepository)
        {
            _resultResultRepository = resultResultRepository;
        }
        public IRuleResult GetLastRuleResult(IRuleResult ruleResult, DateTime date)
        {
            //for monday, eod thurdays (stard friday) result will be used - 4
            //for tuesday, eod fri (start mondy) result will be used -3
            var days = DateTime.Today.DayOfWeek == DayOfWeek.Monday
                ? -3 : -1;
            var result = GetLongOwnershipRuleResult(ruleResult.PolicyId, ruleResult.RuleId, ruleResult.BamSymbol, date.AddDays(days));
            return result;
        }

        public IEnumerable<IRuleResult> GetHistory(string bamSysmbol)
        {
            var results = _resultResultRepository.Get(DateTime.MinValue);
            return results.Where(r => r.BamSymbol == bamSysmbol);
        }

        public IRuleResult GetRuleResult(int policyId, int ruleId, string bamSymbol)
        {
            var result = _resultResultRepository.Get(RuleResult.FormatKey(policyId, ruleId, bamSymbol, DateTime.Today));
            return result;
        }
        public decimal? GetRatio(int policyId, int ruleId, string bamSymbol)
        {
            var lResult = GetLongOwnershipRuleResult(policyId, ruleId, bamSymbol, DateTime.Today);
            return lResult?.Ratio;
        }
        public decimal? GetLowLimit(int policyId, int ruleId, string bamSymbol)
        {
            var lResult = GetLongOwnershipRuleResult(policyId, ruleId, bamSymbol, DateTime.Today);
            return lResult?.LowLimit;
        }
        public bool GetIsRuleOverriden(int policyId, int ruleId, string bamSymbol)
        {
            var result = _resultResultRepository.Get(RuleResult.FormatKey(policyId, ruleId, bamSymbol, DateTime.Today));
            return result?.IsViolationOverriden ?? true;
        }
        private OwnershipFilingResult GetLongOwnershipRuleResult(int policyId, int ruleId, string bamSymbol, DateTime date)
        {
           // var history = GetHistory(bamSymbol);

            var result = _resultResultRepository.Get(RuleResult.FormatKey(policyId, ruleId, bamSymbol, date));
            if (result == null) { return null; }
            var lResult = new OwnershipFilingResult();
            JsonConvert.PopulateObject(result.ParamsInJson, lResult);
            return lResult;
        }

        public void Clear(DateTime utc)
        {
            _resultResultRepository.Clear(utc);
        }
    }
}
