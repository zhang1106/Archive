﻿using System.Collections.Generic;
using Bam.Oms.Data.Orders;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.Orders
{
    public interface IOrderNotifier
    {
        [Log]
        void NotifyNewOrders(IList<IOrder> orders);
        [Log]
        void NotifyCancelOrders(IList<string> orderIds);
        [Log]
        void NotifyDeleteOrders(IList<string> orderIds);
        [Log]
        void NotifyReplaceOrders(IOrder order);

        void NotifyOrdersToRoute(IList<string> orderIds, string entryUser);

        void NotifyLocateRequestReceived(IList<string> orderIds);
    }
}