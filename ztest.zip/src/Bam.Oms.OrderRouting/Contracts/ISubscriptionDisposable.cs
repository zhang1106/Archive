﻿
namespace Bam.Oms.OrderRouting.Contracts
{
    public interface ISubscriptionDisposable
    {
        /// <summary>
        /// Unsubscribes and cleans up a subscription
        /// </summary>
        void DisposeSubscription();
    }
}