﻿using System;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using Dapper;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Persistence.Securities
{
    public class SecurityDBRepository: ISecurityDBRepository
    {
        internal static readonly Func<dynamic, Security> ResultMap = item => new Security
        {
            BamSymbol = item.DisplayCode,
            Country = item.Countrycode,
            Currency = item.TradingCurrencyCode,
            UnderlyingSymbol = ParseUnderlying(item.UnderlyingSymbol),
            Isin = string.IsNullOrEmpty(item.ISIN)?"isin"+item.DisplayCode:item.ISIN,
            Cusip = item.Cusip,
            Industry = item.GICS_Industry,
            ContractSize = item.ContractSize,
            SecurityType = Data.Utility.GetEnumValue<SecurityType>(item.SecurityType),
            OptionType = item.OptionType == null ? OptionType.None : Data.Utility.ConvertEnum<OptionType>(item.OptionType?"Put":"Call"),
            InvestmentType = Data.Utility.GetEnumValue<InvestmentType>(item.InvestmentTypeCode),
            AssetType = Data.Utility.GetEnumValue<AssetType>(item.AssetTypeCode),
            AdrCode = item.ADRCode,
            AdrRatio = Convert.ToDecimal(item.AdrConversionRatio),
            TrackIndexCode = item.TrackIndexCode,
            ActiveInd = item.ActiveInd
        };

        private static string ParseUnderlying(string symbol)
        {
            if (symbol.Contains(" DO NOT TRADE")) return symbol.Replace(" DO NOT TRADE", "");
            if (symbol.Contains("-DO NOT TRADE")) return symbol.Replace("-DO NOT TRADE", "");
            if (symbol.Contains("_DO_NOT_TRADE")) return symbol.Replace("_DO_NOT_TRADE", "");
            return symbol;
        }

        private readonly string _securitiesQuery = @"  
                       IF OBJECT_ID('tempdb.dbo.#securities') IS NOT NULL DROP TABLE #securities;
                        IF OBJECT_ID('tempdb.dbo.#isins') IS NOT NULL DROP TABLE #isins;

                        Declare @onlySpecified int
                        
                        Select @onlySpecified = {0}

                        Select isin
                         Into #isins
                        From [BamCoreLite].[sm].[Security] (nolock)
                        Where displaycode in ({1})

                        SELECT 
                            s0.[DisplayCode]
	                        ,SecurityType = Case 
				                        When s0.AssetTypeCode = 'Equity'  and (s0.InvestmentTypeCode = 'Ordinary Share' or s0.InvestmentTypeCode = 'Preferred' or s0.InvestmentTypeCode = 'MLP')  Then 'Equity'
                                        Else 'NotOrdinaryShare'
                                        End
                            ,s0.AssetTypeCode
                            ,s0.InvestmentTypeCode                           
                            ,s0.[Countrycode]
	                        ,UnderlyingSymbol = isnull(s1.[UltimateUnderlyingDisplayCode], s0.[displaycode])
                            ,s0.TradingCurrencyCode
                            ,ContractSize=IsNULL(s0.ContractSize, 1)
                            ,OptionType = s0.[Option_PutCall]
                            ,ISIN= isnull(s4.Isin,s0.ISIN) 
                            ,s0.Cusip
                            ,s0.GICS_Industry 
	                        ,ADRCode = s2.displaycode
                            ,TrackIndexCode = s3.displaycode 
	                        ,s0.Sysdate
                            ,AdrConversionRatio= isnull(s0.AdrConversionRatio, 1.0)
                            ,s0.ActiveInd

                        Into #securities
                        FROM [BamCoreLite].[sm].[Security] s0 (nolock)
                        Left Join [BamCoreLite].[sm].[Security] (nolock) s2 on  s0.AdrRelationship_SecurityID = s2.securityid
                        Left Join [BamCoreLite].[sm].[Security] (nolock) s3 on  s0.TracksIndex_SecurityID = s3.securityid
                        Left Join [BamCoreLite].[sm].[tblGetUltimateUnderlierTable] (nolock) s1 on  s0.securityid = s1.securityid
                        Left Join [BamCoreLite].[sm].[security] (nolock) s4 on  s4.securityid = s1.UltimateUnderlyingSecurityId
                        Where   s0.sysdate > '{2}' and (@onlySpecified = 0  or (exists (Select isin from #isins where isin = s0.isin) ))   

                        Select * from #securities
                        where
                                AssetTypeCode in ( 'Equity')
                                OR (AssetTypeCode = 'Future' AND InvestmentTypeCode IN('Index', 'Future Single Stock'))
                                OR (AssetTypeCode = 'Option' AND InvestmentTypeCode IN('Equity', 'ETF', 'Index', 'Index Option', 'Warrant And Right'))
                                OR (AssetTypeCode = 'Swap' AND InvestmentTypeCode IN('Basket', 'Equity Swap', 'Equity Swap Fully Funded', 'Future Single Stock', 'Index', 'Ordinary Share', 'Perferred', 'Warrant And Right'))

        ";

        private string _bamCoreliteConnectionString;
        
        public SecurityDBRepository(string bamCorelite, ILogger logger) 
        {
            _bamCoreliteConnectionString = bamCorelite;
        }

        protected IDbConnection Connection => new SqlConnection(_bamCoreliteConnectionString);

        public IEnumerable<Security> GetSecurities(string[] underlyings=null,  DateTime lastUpdated = default(DateTime))
        {
            var quoted = underlyings == null ? "''" : underlyings.Select(s=>$"'{s}'").Aggregate((i, j) => i + ","+j);
            using (var cn = Connection)
            {
                if (lastUpdated == default(DateTime)) lastUpdated = DateTime.Now.AddYears(-100);
                cn.Open();
                var qry = string.Format(_securitiesQuery, underlyings==null?0:1, quoted, lastUpdated.ToUniversalTime());
                var result = cn.Query<dynamic>(qry).Select(ResultMap);
                return result;
            }
        }
    }
}
