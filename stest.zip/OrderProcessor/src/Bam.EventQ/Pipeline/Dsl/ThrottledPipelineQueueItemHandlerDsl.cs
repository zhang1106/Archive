﻿using System;
using Bam.EventQ.Throttling;

namespace Bam.EventQ.Pipeline.Dsl
{
    public class ThrottledPipelineQueueItemHandlerDsl<TItem>
    {
        private readonly PipelineQueueItemHandlerChainDsl<TItem> _chain;
        private readonly ThrottlingQueueItemHandler<TItem> _handler;

        public ThrottledPipelineQueueItemHandlerDsl(PipelineQueueItemHandlerChainDsl<TItem> chain, IConsumptionTrigger<TItem> trigger)
        {
            _chain = chain;
            _handler = new ThrottlingQueueItemHandler<TItem>(trigger);
        }

        public ThrottledPipelineQueueItemHandlerDsl<TItem> Add<TMsg>(
            IThrottlingStrategy<TMsg> strategy,
            IThrottledBatchHandler<TMsg> handler,
            bool skipReplay = true) where TMsg : TItem
        {
            _chain.Step.Pipeline.ObjectInitializer(strategy);
            _chain.Step.Pipeline.ObjectInitializer(handler);
            _handler.Add(
                _chain.Step.Pipeline.ObjectDecorator.Decorate(strategy),
                _chain.Step.Pipeline.ObjectDecorator.Decorate(handler),
                skipReplay);
            return this;
        }

        public ThrottledPipelineQueueItemHandlerDsl<TItem> If(bool predicate,
            Action<ThrottledPipelineQueueItemHandlerDsl<TItem>> then)
        {
            if (predicate)
            {
                then(this);
            }

            return this;
        }

        public ThrottledPipelineQueueItemHandlerDsl<TItem> Conflate<TMsg, TKey>(
            Func<TMsg, TKey> keyFunc, IThrottledBatchHandler<TMsg> handler, 
            bool skipReplay = true) where TMsg : TItem
        {
            return Add(
                new ConflationStrategy<TKey, TMsg>(keyFunc),
                handler, skipReplay);
        }

        public PipelineQueueItemHandlerChainDsl<TItem> Build()
        {
            _chain.AddHandler(_handler);
            return _chain;
        }
    }
}
