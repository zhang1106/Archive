using System;
using Bam.EventQ.Integration;
using Bam.EventQ.Pipeline.Dsl;
using Bam.EventQ.RabbitMQ;
using Bam.EventQ.Sequencing;
using Bam.EventQ.Throttling;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pipeline
{
    public static class ProcessingPipelineDslExtensions
    {
        public static ProcessingPipelineStepDsl<TItem> ReceiveJsonFromRabbitMq<TItem, TMsg>(
            this ProcessingPipelineStepDsl<TItem> step, string endpoint, string exchange, 
            string queue, IRoutingKeyConverter routingKeyConverter, int bufferSize) where TMsg : TItem
        {
            var subscriber = new RabbitMqDurableQueueSubscriber(exchange, queue, routingKeyConverter);
            subscriber.Connect(endpoint);
            step.Pipeline.ObjectInitializer(subscriber);

            var producer = new RabbitMqJsonQueueItemProducer<TItem, TMsg>(
                step.Pipeline.ObjectDecorator.Decorate(subscriber), bufferSize);
            step.Pipeline.ObjectInitializer(producer);

            step.AddProducer(producer);
            return step;
        }

        public static ProcessingPipelineStepDsl<TMsg> ReceiveJsonFromRabbitMq<TItem, TMsg>(
            this ProcessingPipelineStepDsl<TMsg> step, string endpoint, string exchange,
            string queue, IRoutingKeyConverter routingKeyConverter, int bufferSize,
            IExternalMessageTransform<TItem, TMsg> transform)
        {
            var subscriber = new RabbitMqDurableQueueSubscriber(exchange, queue, routingKeyConverter);
            subscriber.Connect(endpoint);
            step.Pipeline.ObjectInitializer(subscriber);

            var messageSource = new RabbitMqExternalMessageSource<TItem>(
                step.Pipeline.ObjectDecorator.Decorate(subscriber), bufferSize);
            step.Pipeline.ObjectInitializer(messageSource);

            var producer = new TransformingQueueItemProducer<TItem, TMsg>(messageSource, transform);
            step.Pipeline.ObjectInitializer(producer);

            step.AddProducer(producer);
            return step;
        }

        public static ProcessingPipelineStepDsl<IMessage> ReceiveJsonFromRabbitMq<TItem>(
            this ProcessingPipelineStepDsl<IMessage> step, string endpoint, string exchange,
            string queue, IRoutingKeyConverter routingKeyConverter, int bufferSize,
            IExternalMessageTransform<TItem, IMessage> transform)
        {
            var subscriber = new RabbitMqDurableQueueSubscriber(exchange, queue, routingKeyConverter);
            subscriber.Connect(endpoint);
            step.Pipeline.ObjectInitializer(subscriber);

            var messageSource = new RabbitMqExternalMessageSource<TItem>(
                step.Pipeline.ObjectDecorator.Decorate(subscriber), bufferSize);
            step.Pipeline.ObjectInitializer(messageSource);

            var producer = new TransformingQueueItemProducer<TItem>(messageSource, transform, 
                step.GetQueueMessageDispatcher());
            step.Pipeline.ObjectInitializer(producer);

            step.AddProducer(producer);
            return step;
        }

        public static ProcessingPipelineStepDsl<TItem> ReceiveJsonFromRabbitMq<TItem, TMsg>(
            this ProcessingPipelineStepDsl<TItem> step, string endpoint, string exchange, 
            string queue, int topic, int bufferSize) where TMsg : TItem
        {
            return ReceiveJsonFromRabbitMq<TItem, TMsg>(step, endpoint,
                exchange, queue, new StaticRoutingKeyConverter(topic), bufferSize);
        }

        public static ProcessingPipelineStepDsl<TMsg> ReceiveJsonFromRabbitMq<TItem, TMsg>(
            this ProcessingPipelineStepDsl<TMsg> step, string endpoint, string exchange,
            string queue, int topic, int bufferSize, IExternalMessageTransform<TItem, TMsg> transform)
        {
            return ReceiveJsonFromRabbitMq(step, endpoint, exchange, queue, 
                new StaticRoutingKeyConverter(topic), bufferSize, transform);
        }

        public static ProcessingPipelineStepDsl<IMessage> ReceiveJsonFromRabbitMq<TItem>(
            this ProcessingPipelineStepDsl<IMessage> step, string endpoint, string exchange,
            string queue, int topic, int bufferSize, IExternalMessageTransform<TItem, IMessage> transform)
        {
            return ReceiveJsonFromRabbitMq(step, endpoint, exchange, queue, 
                new StaticRoutingKeyConverter(topic), bufferSize, transform);
        }

        public static ProcessingPipelineStepDsl<TItem> ReceiveJsonFromRabbitMq<TItem, TMsg>(
            this ProcessingPipelineStepDsl<TItem> step, string endpoint, string exchange, 
            string queue, int bufferSize) where TMsg : TItem
        {
            return ReceiveJsonFromRabbitMq<TItem, TMsg>(step, endpoint,
                exchange, queue, 1, bufferSize);
        }

        public static ProcessingPipelineStepDsl<TMsg> ReceiveJsonFromRabbitMq<TItem, TMsg>(
            this ProcessingPipelineStepDsl<TMsg> step, string endpoint, string exchange,
            string queue, int bufferSize, IExternalMessageTransform<TItem, TMsg> transform)
        {
            return ReceiveJsonFromRabbitMq(step, endpoint, exchange, queue,
                new StaticRoutingKeyConverter(1), bufferSize, transform);
        }

        public static ProcessingPipelineStepDsl<IMessage> ReceiveJsonFromRabbitMq<TItem>(
            this ProcessingPipelineStepDsl<IMessage> step, string endpoint, string exchange,
            string queue, int bufferSize, IExternalMessageTransform<TItem, IMessage> transform)
        {
            return ReceiveJsonFromRabbitMq(step, endpoint, exchange, queue,
                new StaticRoutingKeyConverter(1), bufferSize, transform);
        }

        public static ThrottledPipelineQueueItemHandlerDsl<TItem> ConflatedPublishToRabbitMq<TItem, TKey, TMsg>(
            this ThrottledPipelineQueueItemHandlerDsl<TItem> chain, Func<TMsg, TKey> keyFunc, 
            string endpoint, string exchange, TimeSpan retryInterval, 
            Func<TMsg, string> routingKeyFunc, bool skipReplay)
            where TMsg : TItem
        {
            IThrottledBatchHandler<TMsg> publisher = 
                new RabbitMqTopicPublisher<TMsg>(endpoint, exchange, routingKeyFunc, retryInterval);
            return chain.Add(new ConflationStrategy<TKey, TMsg>(keyFunc), publisher, skipReplay);
        }

        public static ThrottledPipelineQueueItemHandlerDsl<TItem> ConflatedPublishToRabbitMq<TItem, TKey, TMsg>(
            this ThrottledPipelineQueueItemHandlerDsl<TItem> chain, Func<TMsg, TKey> keyFunc,
            string endpoint, string exchange, TimeSpan retryInterval, Predicate<TMsg> predicate,
            Func<TMsg, string> routingKeyFunc, bool skipReplay)
            where TMsg : TItem
        {
            IThrottledBatchHandler<TMsg> publisher =
                new RabbitMqTopicPublisher<TMsg>(endpoint, exchange, routingKeyFunc, retryInterval);
            return chain.Add(new ConflationStrategy<TKey, TMsg>(keyFunc, predicate), publisher, skipReplay);
        }
    }
}
