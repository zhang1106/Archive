﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bam.Locate.Hub.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Messaging;
using Bam.Oms.RefData;
using Bam.Oms.ShortLocate;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR.Client;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class ShortLocateFacadeTests
    {
        [Test]
        public void VerifyRequestLocateServiceCall()
        {
            // arrange
            List<TradeAssignmentRequest> responseList = null;

            var providerHub = new Mock<IInventoryController>();
            providerHub.Setup(r => r.PostInventoryAssignment(It.IsAny<List<TradeAssignmentRequest>>()))
                .Callback<List<TradeAssignmentRequest>>(
                    (requestList) => { responseList = new List<TradeAssignmentRequest>(requestList); })
                .Returns(new List<TradeAssignment>());

            var order = new Mock<IOrder>();
            order.Setup(r => r.Size).Returns(1000);
            order.Setup(r => r.Security).Returns(new Security() { BamSymbol = "IBM" });
            order.Setup(r => r.Locate).Returns(new List<Data.Orders.Locate>() { new Data.Orders.Locate() });
            order.Setup(r => r.Custodian).Returns("CSPB");

            var request = new Mock<ILocateRequest>();
            request.SetupGet(r => r.Order).Returns(order.Object);
            request.SetupGet(r => r.Broker).Returns("CSPB");

            var sm = new Mock<ISecurityMasterService>();
            sm.Setup(r => r.ExtractUnderlying(It.IsAny<SecurityType>(), It.IsAny<string>())).Returns("IBM");

            var service = new LocateService(providerHub.Object, new Mock<ILogger>().Object, new Mock<IMessagingClient<SignalRPacket<TradeAssignment>>>().Object, new Mock<IConnection>().Object, sm.Object);

            // act
            var unit = service.RequestForInventory(new[] { request.Object });

            // assert
            Assert.IsNotNull(responseList);
            Assert.That(responseList.Count, Is.EqualTo(1));
            Assert.That(responseList[0].Ticker, Is.EqualTo("IBM"));
            Assert.That(responseList[0].QuantityRequested, Is.EqualTo(1000));
            Assert.That(responseList[0].Broker, Is.EqualTo("CSPB"));
        }

        [Test]
        public void VerifyFilledLocate()
        {
            // arrange
            var response = new TradeAssignment();
            //response.QuantityRequested = 1000;
            response.TradeId = "123";
            response.PrimeBrokerRequestAllocation["CSPB"] = 1000;
            response.Approvals.Add(new ApprovedBorrow() { LocateId = "12345", ApprovalId = "APPROVED123", Broker = "CSPB", Rate = 1.2m, RateType = "R", Size = 1000, Status = BrokerLocateStatus.Approved });

            var providerHub = new Mock<IInventoryController>();
            providerHub.Setup(r => r.PostInventoryAssignment(It.IsAny<List<TradeAssignmentRequest>>()))
                .Returns(new List<TradeAssignment>() { response });

            var order = new Mock<IOrder>();
            order.SetupAllProperties();
            order.Setup(r => r.ClientOrderId).Returns("123");
            order.Setup(r => r.Size).Returns(1000);
            order.Setup(r => r.Security).Returns(new Security() { BamSymbol = "IBM" });

            var request = new Mock<ILocateRequest>();
            request.SetupGet(r => r.Broker).Returns("CSPB");
            request.SetupGet(r => r.Order).Returns(order.Object);

            var service = new LocateService(providerHub.Object, new Mock<ILogger>().Object, new Mock<IMessagingClient<SignalRPacket<TradeAssignment>>>().Object, new Mock<IConnection>().Object, new Mock<ISecurityMasterService>().Object);

            // act
            var unit = service.RequestForInventory(new[] { request.Object }).ToList();

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.Count(), Is.EqualTo(1));
            Assert.That(unit[0].Locate.Count, Is.EqualTo(1));
            Assert.That(unit[0].Locate[0].Size, Is.EqualTo(1000));
            Assert.That(unit[0].Locate[0].AssignmentId, Is.EqualTo("APPROVED123"));
            Assert.That(unit[0].Locate[0].PrimeBroker, Is.EqualTo("CSPB"));
            Assert.That(order.Object.LocateStatus, Is.EqualTo(LocateStatus.Approved));
        }

        [Test]
        public void VerifyPartialFilledLocate()
        {
            // arrange
            var response = new TradeAssignment();
            response.TradeId = "123";
            response.PrimeBrokerRequestAllocation["CSPB"] = 1000;
            response.Approvals.Add(new ApprovedBorrow() { LocateId = "12345", ApprovalId = "APPROVED123", Broker = "CSPB", Rate = 1.2m, RateType = "R", Size = 500, Status = BrokerLocateStatus.Partial });

            var providerHub = new Mock<IInventoryController>();
            providerHub.Setup(r => r.PostInventoryAssignment(It.IsAny<List<TradeAssignmentRequest>>()))
                .Returns(new List<TradeAssignment>() { response });

            var order = new Mock<IOrder>();
            order.SetupAllProperties();
            order.Setup(r => r.ClientOrderId).Returns("123");
            order.Setup(r => r.Size).Returns(1000);
            order.Setup(r => r.Security).Returns(new Security() { BamSymbol = "IBM" });

            var request = new Mock<ILocateRequest>();
            request.SetupGet(r => r.Broker).Returns("CSPB");
            request.SetupGet(r => r.Order).Returns(order.Object);

            var service = new LocateService(providerHub.Object, new Mock<ILogger>().Object, new Mock<IMessagingClient<SignalRPacket<TradeAssignment>>>().Object, new Mock<IConnection>().Object, new Mock<ISecurityMasterService>().Object);

            // act
            var unit = service.RequestForInventory(new[] { request.Object }).ToList();

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.Count(), Is.EqualTo(1));
            Assert.That(unit[0].Locate[0].Size, Is.EqualTo(500));
            Assert.That(unit[0].Locate[0].AssignmentId, Is.EqualTo("APPROVED123"));
            Assert.That(unit[0].Locate[0].PrimeBroker, Is.EqualTo("CSPB"));
            Assert.That(order.Object.LocateStatus, Is.EqualTo(LocateStatus.Partial));
        }

        [Test]
        public void VerifyDeniedLocate()
        {
            // arrange
            var response = new TradeAssignment();
            response.TradeId = "123";
            response.PrimeBrokerRequestAllocation["CSPB"] = 1000;
            response.Approvals.Add(new ApprovedBorrow() { LocateId = "12345", ApprovalId = "APPROVED123", Broker = "CSPB", Rate = 1.2m, RateType = "R", Size = 0, Status = BrokerLocateStatus.Denied });

            var providerHub = new Mock<IInventoryController>();
            providerHub.Setup(r => r.PostInventoryAssignment(It.IsAny<List<TradeAssignmentRequest>>()))
                .Returns(new List<TradeAssignment>() { response });

            var order = new Mock<IOrder>();
            order.SetupAllProperties();
            order.Setup(r => r.ClientOrderId).Returns("123");
            order.Setup(r => r.Size).Returns(1000);
            order.Setup(r => r.Security).Returns(new Security() { BamSymbol = "IBM" });

            var request = new Mock<ILocateRequest>();
            request.SetupGet(r => r.Broker).Returns("CSPB");
            request.SetupGet(r => r.Order).Returns(order.Object);

            var service = new LocateService(providerHub.Object, new Mock<ILogger>().Object, new Mock<IMessagingClient<SignalRPacket<TradeAssignment>>>().Object, new Mock<IConnection>().Object, new Mock<ISecurityMasterService>().Object);

            // act
            var unit = service.RequestForInventory(new[] { request.Object }).ToList();

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.Count(), Is.EqualTo(1));
            Assert.That(order.Object.LocateStatus, Is.EqualTo(LocateStatus.Denied));

        }

        [Test]
        public void VerifyRequestEquals()
        {
            // arrange
            var order = new Order();
            order.ClientOrderId = "123";

            var inventory0 = new LocateRequest(order, "CSFB");
            var inventory1 = new LocateRequest(order, "CSFB");

            // act
            var unit = inventory1.Equals(inventory0);

            // assert
            Assert.That(unit, Is.True);
        }

        [Test]
        public void VerifyRequestNotEquals()
        {
            // arrange
            var order = new Order();
            order.ClientOrderId = "123";

            var inventory0 = new LocateRequest(order, "CSFB");
            var inventory1 = new LocateRequest(order, "GSCO");

            // act
            var unit = inventory1.Equals(inventory0);

            // assert
            Assert.That(unit, Is.False);
        }

        [Test]
        public void VerifyInventoryRequestEquals()
        {
            // arrange
            var inventoryRequest = new LocateRequest(new Order() { ClientOrderId = "123" }, "CSFB");
            var inventoryRequest0 = new LocateRequest(new Order() { ClientOrderId = "123" }, "CSFB");

            // act
            var unit = inventoryRequest.Equals(inventoryRequest0);

            // assert
            Assert.True(unit);
        }

        [Test]
        public void VerifyInventoryRequestNotEquals()
        {
            // arrange
            var inventoryRequest = new LocateRequest(new Order() { ClientOrderId = "123" }, "CSFB");
            var inventoryRequest0 = new LocateRequest(new Order() { ClientOrderId = "456" }, "CSFB");

            // act
            var unit = inventoryRequest.Equals(inventoryRequest0);

            // assert
            Assert.False(unit);
        }

        [Test]
        public void VerifyInventoryRequestGetHashCodeValid()
        {
            // arrange
            var inventoryRequest = new LocateRequest(new Order() { ClientOrderId = "123" }, "CSFB");
            var inventoryRequest0 = new LocateRequest(new Order() { ClientOrderId = "123" }, "CSFB");

            // act
            var unit = inventoryRequest.GetHashCode();
            var unit0 = inventoryRequest0.GetHashCode();

            // assert
            Assert.That(unit, Is.EqualTo(unit0));
        }

        [Test]
        public void VerifyCancelTrade()
        {
            // arrange
            IList<CancelTradeRequest> unit = null;

            var providerHub = new Mock<IInventoryController>();
            providerHub.Setup(r => r.PostCancelTrade(It.IsAny<IList<CancelTradeRequest>>())).Returns(1).Callback<IList<CancelTradeRequest>>(c => unit = c);

            var locateService = new LocateService(providerHub.Object, new Mock<ILogger>().Object, new Mock<IMessagingClient<SignalRPacket<TradeAssignment>>>().Object, new Mock<IConnection>().Object,
                new Mock<ISecurityMasterService>().Object);

            // act
            var order = new BlockTrade() { ClientOrderId = "12345", TradedQuantity = 1500 };
            var tradeList = new Dictionary<string, IList<IBlockTrade>> { [order.ClientOrderId] = new List<IBlockTrade>() { order } };
            locateService.CancelTrades(tradeList);

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.Count, Is.EqualTo(1));
            Assert.That(unit[0].TradeId, Is.EqualTo("12345"));
            Assert.That(unit[0].ExecutedSize, Is.EqualTo(1500));
        }


        public interface IListener
        {
            Task Action(IEnumerable<ILocateResponse> list);
        }


        private class Locate : LocateService
        {
            public Locate(IInventoryController locateHub)
                : base(locateHub, new Mock<ILogger>().Object, new Mock<IMessagingClient<SignalRPacket<TradeAssignment>>>().Object, new Mock<IConnection>().Object, new Mock<ISecurityMasterService>().Object)
            {
            }
        }


    }
}