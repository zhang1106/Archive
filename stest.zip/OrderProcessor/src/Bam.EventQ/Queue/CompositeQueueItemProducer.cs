﻿using System;
using System.Linq;
using Bam.EventQ.Diagnostics;

namespace Bam.EventQ.Queue
{
    public class CompositeQueueItemProducer<TItem> : IQueueItemProducer<TItem>
    {
        private readonly IQueueItemProducer<TItem>[] _producers;
        private ILogger _logger;

        public CompositeQueueItemProducer(params IQueueItemProducer<TItem>[] producers)
        {
            _producers = producers;
            CanPause = _producers.All(p => p.CanPause);
        }

        public bool CanPause { get; }
        protected IQueue<TItem> Queue { get; private set; }

        public ILogger Logger
        {
            get { return _logger; }
            set
            {
                _logger = value;
                foreach (var p in _producers)
                {
                    p.InjectLogger(value);
                }
            }
        }

        public virtual void Initialize(IQueue<TItem> queue)
        {
            Queue = queue;
            foreach (var p in _producers)
            {
                p.Initialize(queue);
            }
        }

        public virtual void Start()
        {
            foreach (var p in _producers)
            {
                p.Start();
            }
        }

        public virtual void Stop()
        {
            foreach (var p in _producers)
            {
                p.Stop();
            }
        }

        public virtual void Pause()
        {
            if (!CanPause)
            {
                throw new InvalidOperationException("One or more producers cannot be paused.");
            }

            foreach (var p in _producers)
            {
                p.Pause();
            }
        }

        public virtual void Resume()
        {
            if (!CanPause)
            {
                throw new InvalidOperationException("One or more producers cannot be paused.");
            }

            foreach (var p in _producers)
            {
                p.Resume();
            }
        }
    }
}
