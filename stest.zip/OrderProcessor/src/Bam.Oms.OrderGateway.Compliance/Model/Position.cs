﻿using System.Collections.Generic;
using System.Diagnostics;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    [DebuggerDisplay("{Key} = (Actual={ActualQuantity}, Theoretical={TheoreticalQuantity}, Long={LongMarkingQuantity}, Short={ShortMarkingQuantity})")]
    public class Position : ModelBase<IMessage>
    {
        private readonly Dictionary<PositionAllocationKey, PositionAllocation> _actualAllocations;
        private readonly Dictionary<PositionAllocationKey, PositionAllocation> _theoreticalAllocations;

        public Position(long id, PositionKey key, string aggUnit, string complianceGroup)
        {
            Key = key;
            PositionId = id;
            AggregationUnitKey = new AggUnitKey(aggUnit, Key.Symbol);
            ComplianceGroupKey = new ComplianceGroupKey(complianceGroup, key.Symbol);
            _actualAllocations = new Dictionary<PositionAllocationKey, PositionAllocation>();
            _theoreticalAllocations = new Dictionary<PositionAllocationKey, PositionAllocation>();
        }

        public long PositionId { get; set; }
        public PositionKey Key { get; }
        public AggUnitKey AggregationUnitKey { get; }
        public ComplianceGroupKey ComplianceGroupKey { get; }

        public long ActualQuantity { get; private set; }
        public long LongMarkingQuantity { get; private set; }
        public long ShortMarkingQuantity { get; private set; }
        public long TheoreticalQuantity { get; private set; }

        public IReadOnlyDictionary<PositionAllocationKey, PositionAllocation> TheoreticalAllocations => _theoreticalAllocations;
        public IReadOnlyDictionary<PositionAllocationKey, PositionAllocation> ActualAllocations => _actualAllocations;

        public long ApplyActualQuantityEffect(IEnumerable<KeyValuePair<PositionAllocationKey, long>> effects)
        {
            bool hadEffect = false;
            foreach (var item in effects)
            {
                int fundId = item.Key.FundId;
                int custodianId = item.Key.CustodianId;
                long effect = item.Value;

                if (effect == 0)
                    continue;

                PositionAllocation allocation;
                var key = new PositionAllocationKey(fundId, custodianId);
                if (!_actualAllocations.TryGetValue(key, out allocation))
                {
                    allocation = _actualAllocations[key] = new PositionAllocation(key, this);
                }

                allocation.Quantity += effect;
                ActualQuantity += effect;
                hadEffect = true;
            }

            if (hadEffect && _actualAllocations.Count > 0)
            {
                var lineItem = new ActualPositionUpdated.LineItem
                {
                    PositionId = PositionId
                };

                foreach (var alloc in _actualAllocations.Values)
                {
                    lineItem.Allocations.Add(new ActualPositionUpdated.Allocation
                    {
                        CustodianId = alloc.Key.CustodianId,
                        FundId = alloc.Key.FundId,
                        Quantity = alloc.Quantity
                    });
                }

                Publish(new ActualPositionUpdated
                {
                    Items = {lineItem}
                });
            }

            return ActualQuantity;
        }

        public long ApplyTheoreticalQuantityEffect(IEnumerable<KeyValuePair<PositionAllocationKey, long>> effects)
        {
            bool hadEffect = false;
            foreach (var item in effects)
            {
                int fundId = item.Key.FundId;
                int custodianId = item.Key.CustodianId;
                long effect = item.Value;

                if (effect == 0)
                    continue;

                PositionAllocation allocation;
                var key = new PositionAllocationKey(fundId, custodianId);
                if (!_theoreticalAllocations.TryGetValue(key, out allocation))
                {
                    allocation = _theoreticalAllocations[key] = new PositionAllocation(key, this);
                }

                allocation.Quantity += effect;
                TheoreticalQuantity += effect;
                hadEffect = true;
            }

            if (hadEffect && _theoreticalAllocations.Count > 0)
            {
                var lineItem = new TheoreticalPositionUpdated.LineItem
                {
                    PositionId = PositionId
                };

                foreach (var alloc in _theoreticalAllocations.Values)
                {
                    lineItem.Allocations.Add(new TheoreticalPositionUpdated.Allocation
                    {
                        FundId = alloc.Key.FundId,
                        CustodianId = alloc.Key.CustodianId,
                        Quantity = alloc.Quantity
                    });
                }

                Publish(new TheoreticalPositionUpdated
                {
                    Items = {lineItem}
                });
            }

            return TheoreticalQuantity;
        }

        public long ApplyLongMarkingEffect(long effect)
        {
            if (effect != 0)
            {
                LongMarkingQuantity += effect;
                Publish(new LongMarkingPositionUpdated(PositionId, LongMarkingQuantity));
            }

            return LongMarkingQuantity;
        }

        public long ApplyShortMarkingEffect(long effect)
        {
            if (effect != 0)
            {
                ShortMarkingQuantity += effect;
                Publish(new ShortMarkingPositionUpdated(PositionId, ShortMarkingQuantity));
            }

            return ShortMarkingQuantity;
        }

        public bool IsFlat
        {
            get
            {
                if (ActualQuantity != 0 || TheoreticalQuantity != 0 ||
                    LongMarkingQuantity != 0 || ShortMarkingQuantity != 0)
                {
                    return false;
                }

                foreach (var item in _actualAllocations.Values)
                {
                    if (item.Quantity != 0)
                        return false;
                }

                foreach (var item in _theoreticalAllocations.Values)
                {
                    if (item.Quantity != 0)
                        return false;
                }

                return true;
            }
        }

        public bool ActualAllocationDiffers(Position other)
        {
            if (other.ActualQuantity != ActualQuantity ||
                other.ActualAllocations.Count != ActualAllocations.Count)
                return true;

            foreach (var key in ActualAllocations.Keys)
            {
                PositionAllocation alloc;
                if (!other.ActualAllocations.TryGetValue(key, out alloc) ||
                    ActualAllocations[key].Quantity != alloc.Quantity)
                {
                    return true;
                }
            }

            return false;
        }

        public bool TheoreticalAllocationDiffers(Position other)
        {
            if (other.TheoreticalQuantity != TheoreticalQuantity ||
                other.TheoreticalAllocations.Count != TheoreticalAllocations.Count)
                return true;

            foreach (var key in TheoreticalAllocations.Keys)
            {
                PositionAllocation alloc;
                if (!other.TheoreticalAllocations.TryGetValue(key, out alloc) ||
                    TheoreticalAllocations[key].Quantity != alloc.Quantity)
                {
                    return true;
                }
            }

            return false;
        }
    }
}