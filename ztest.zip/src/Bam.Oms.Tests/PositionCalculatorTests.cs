﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Bam.Oms.Data;
using Bam.Oms.PositionCalc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class PositionCalculatorTests
    {
        public class TupleList<T1, T2> : List<Tuple<T1, T2>>
        {
            public void Add(T1 item, T2 item2)
            {
                Add(new Tuple<T1, T2>(item, item2));
            }
        }

        [TestCase(SideType.Long, 100, SideType.Buy, 50, SideType.Long, 150)]
        [TestCase(SideType.Long, 100, SideType.Buy, 150, SideType.Long, 250)]
        [TestCase(SideType.Long, 100, SideType.Cover, 50, SideType.Long, 150)]
        [TestCase(SideType.Long, 100, SideType.Cover, 150, SideType.Long, 250)]
        [TestCase(SideType.Long, 100, SideType.Sell, 50.0, SideType.Long, 50.0)]
        [TestCase(SideType.Long, 100, SideType.Sell, 150.0, SideType.Short, 50.0)]
        [TestCase(SideType.Long, 100, SideType.SellShort, 50.0, SideType.Long, 50.0)]
        [TestCase(SideType.Long, 100, SideType.SellShort, 150.0, SideType.Short, 50.0)]
        [TestCase(SideType.Short, 100, SideType.Buy, 50, SideType.Short, 50)]
        [TestCase(SideType.Short, 100, SideType.Buy, 150, SideType.Long, 50)]
        [TestCase(SideType.Short, 100, SideType.Cover, 50, SideType.Short, 50)]
        [TestCase(SideType.Short, 100, SideType.Cover, 150, SideType.Long, 50)]
        [TestCase(SideType.Short, 100, SideType.Sell, 50.0, SideType.Short, 150.0)]
        [TestCase(SideType.Short, 100, SideType.Sell, 150.0, SideType.Short, 250.0)]
        [TestCase(SideType.Short, 100, SideType.SellShort, 50.0, SideType.Short, 150.0)]
        [TestCase(SideType.Short, 100, SideType.SellShort, 150.0, SideType.Short, 250.0)]
        public void TestCalculatePosition(SideType positionSide, double positionQuantity, SideType fillSide, double fillQuantity, SideType expectedSide, double expectedQuantity)
        {
            var portfolio = new Portfolio("MYPORT-MYSTRATEGY-MYSUBSTRATEGY");
            var security = new Security() { BamSymbol = "IBM Equity" };

            Mock<IPosition> position = new Mock<IPosition>();
            position.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            position.SetupGet(pos => pos.Security).Returns(security);
            position.SetupGet(pos => pos.ActualQuantity).Returns(Convert.ToDecimal(positionQuantity));
            position.SetupGet(pos => pos.ActualSide).Returns(positionSide);
            position.SetupGet(pos => pos.TheoreticalQuantity).Returns(Convert.ToDecimal(positionQuantity));
            position.SetupGet(pos => pos.TheoreticalSide).Returns(positionSide);
            position.Setup(pos => pos.Clone()).Returns(position.Object);

            IPosition finalPosition = new Position(portfolio, security);
            finalPosition.ActualQuantity = 0;
            finalPosition.ActualSide = SideType.Unknown;
            position.Setup(pos => pos.Clone()).Returns(finalPosition);


            Mock<ITrade> fill = new Mock<ITrade>();
            fill.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            fill.SetupGet(pos => pos.Security).Returns(security);
            fill.SetupGet(pos => pos.TradedQuantity).Returns(Convert.ToDecimal(fillQuantity));
            fill.SetupGet(pos => pos.Side).Returns(fillSide);

            IEnumerable<IPosition> positionCollection = new Collection<IPosition>() { position.Object };            

            IPosition expected = new Position(portfolio, security);
            expected.ActualQuantity = Convert.ToDecimal(expectedQuantity);
            expected.ActualSide = expectedSide;

            PositionCalculator calculator = new PositionCalculator();
            IPosition actual = calculator.CalculatePosition(positionCollection, fill.Object);

            Assert.True(expected.Equals(actual));
        }

        [TestCase(SideType.Long, 100, SideType.Buy, 50, SideType.Long, 150, 1, SideType.Buy, 50, SideType.Unknown, 0)]
        [TestCase(SideType.Long, 100, SideType.Buy, 150, SideType.Long, 250, 1, SideType.Buy, 150, SideType.Unknown, 0)]        
        [TestCase(SideType.Long, 100, SideType.Sell, 50.0, SideType.Long, 50.0, 1, SideType.Sell, 50, SideType.Unknown, 0)]
        [TestCase(SideType.Long, 100, SideType.Sell, 150.0, SideType.Short, 50.0, 2, SideType.Sell, 100, SideType.SellShort, 50 )]        
        [TestCase(SideType.Short, 100, SideType.Buy, 50, SideType.Short, 50, 1, SideType.Cover, 50, SideType.Unknown, 0)]
        [TestCase(SideType.Short, 100, SideType.Buy, 150, SideType.Long, 50, 2, SideType.Cover, 100, SideType.Buy, 50)]
        [TestCase(SideType.Short, 100, SideType.Sell, 50.0, SideType.Short, 150.0, 1, SideType.SellShort, 50, SideType.Unknown, 0)]
        [TestCase(SideType.Short, 100, SideType.Sell, 150.0, SideType.Short, 250.0, 1, SideType.SellShort, 150, SideType.Unknown, 0)]
        public void TestMarkOrders(SideType positionSide, double positionQuantity, SideType orderSide, double orderQuantity, SideType expectedSide, double expectedQuantity, int numOrders, SideType expectedOrder1Side, double expectedOrder1Size, SideType expectedOrder2Side, double expectedOrder2Size)
        {
            var portfolio = new Portfolio("MYPORT-MYSTRATEGY-MYSUBSTRATEGY");
            var security = new Security() {BamSymbol = "IBM Equity"};

            Mock<IPosition> position = new Mock<IPosition>();
            position.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            position.SetupGet(pos => pos.Security).Returns(security);
            position.SetupGet(pos => pos.TheoreticalQuantity).Returns(Convert.ToDecimal(positionQuantity));
            position.SetupGet(pos => pos.TheoreticalSide).Returns(positionSide);
            position.SetupGet(pos => pos.ActualQuantity).Returns(Convert.ToDecimal(positionQuantity));
            position.SetupGet(pos => pos.ActualSide).Returns(positionSide);
            position.Setup(pos => pos.Clone()).Returns(position.Object);

            IPosition finalPosition = new Position(portfolio, security);
            finalPosition.ActualQuantity = 0;
            finalPosition.ActualSide = SideType.Unknown;
            finalPosition.TheoreticalQuantity = 0;
            finalPosition.TheoreticalSide = SideType.Unknown;
            position.Setup(pos => pos.Clone()).Returns(finalPosition);


            Mock<IOrder> order = new Mock<IOrder>();
            order.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            order.SetupGet(pos => pos.Security).Returns(security);
            order.SetupGet(pos => pos.Size).Returns(Convert.ToDecimal(orderQuantity));
            order.SetupGet(pos => pos.Side).Returns(orderSide);

            Mock<IOrder> finalOrder1 = new Mock<IOrder>();
            finalOrder1.SetupAllProperties();
            finalOrder1.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            finalOrder1.SetupGet(pos => pos.Security).Returns(security);

            finalOrder1.SetupSet(s => s.Size = It.IsAny<decimal>()).Callback<decimal>(r =>
            {
                decimal size = r;
                finalOrder1.SetupGet(s => s.Size).Returns(size);
            });

            finalOrder1.SetupSet(s => s.Side = It.IsAny<SideType>()).Callback<SideType>(r =>
            {
                SideType side = r;
                finalOrder1.SetupGet(s => s.Side).Returns(side);
            });

            Mock<IOrder> finalOrder2 = new Mock<IOrder>();
            finalOrder2.SetupAllProperties();
            finalOrder2.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            finalOrder2.SetupGet(pos => pos.Security).Returns(security);

            finalOrder2.SetupSet(s => s.Size = It.IsAny<decimal>()).Callback<decimal>(r =>
            {
                decimal size = r;
                finalOrder2.SetupGet(s => s.Size).Returns(size);
            });

            finalOrder2.SetupSet(s => s.Side = It.IsAny<SideType>()).Callback<SideType>(r =>
            {
                SideType side = r;
                finalOrder2.SetupGet(s => s.Side).Returns(side);
            });
            
            order.SetupSequence(o => o.Clone()).Returns(finalOrder1.Object).Returns(finalOrder2.Object);

            ICollection<IPosition> positionCollection = new Collection<IPosition>();
            positionCollection.Add(position.Object);

            IPosition expected = new Position(portfolio, security);
            expected.TheoreticalQuantity = Convert.ToDecimal(expectedQuantity);
            expected.TheoreticalSide = expectedSide;

            PositionCalculator calculator = new PositionCalculator();
            IPosition actual;
            IEnumerable<IOrder> orders = calculator.CalculatePositionAndMarkOrder(positionCollection, order.Object, out actual);

            Assert.True(expected.Equals(actual));
            Assert.True(orders.ToList().Count == numOrders);
            Assert.AreEqual(orders.First().Size, Convert.ToDecimal(expectedOrder1Size));
            Assert.AreEqual(orders.First().Side, expectedOrder1Side);

            if (numOrders == 2)
            {
                Assert.AreEqual(orders.Last().Size, Convert.ToDecimal(expectedOrder2Size));
                Assert.AreEqual(orders.Last().Side, expectedOrder2Side);
            }
        }

        [TestCase(SideType.Long, 100, SideType.Buy, 50, SideType.Long, 50)]
        [TestCase(SideType.Long, 100, SideType.Buy, 150, SideType.Short, 50)]
        [TestCase(SideType.Long, 100, SideType.Cover, 50, SideType.Long, 50)]
        [TestCase(SideType.Long, 100, SideType.Cover, 150, SideType.Short, 50)]
        [TestCase(SideType.Long, 100, SideType.Sell, 50.0, SideType.Long, 150.0)]
        [TestCase(SideType.Long, 100, SideType.Sell, 150.0, SideType.Long, 250.0)]
        [TestCase(SideType.Long, 100, SideType.SellShort, 50.0, SideType.Long, 150.0)]
        [TestCase(SideType.Long, 100, SideType.SellShort, 150.0, SideType.Long, 250.0)]
        [TestCase(SideType.Short, 100, SideType.Buy, 50, SideType.Short, 150)]
        [TestCase(SideType.Short, 100, SideType.Buy, 150, SideType.Short, 250)]
        [TestCase(SideType.Short, 100, SideType.Cover, 50, SideType.Short, 150)]
        [TestCase(SideType.Short, 100, SideType.Cover, 150, SideType.Short, 250)]
        [TestCase(SideType.Short, 100, SideType.Sell, 50.0, SideType.Short, 50.0)]
        [TestCase(SideType.Short, 100, SideType.Sell, 150.0, SideType.Long, 50.0)]
        [TestCase(SideType.Short, 100, SideType.SellShort, 50.0, SideType.Short, 50.0)]
        [TestCase(SideType.Short, 100, SideType.SellShort, 150.0, SideType.Long, 50.0)]
        public void TestCancelOrder(SideType positionSide, double positionQuantity, SideType orderSide, double orderQuantity, SideType expectedSide, double expectedQuantity)
        {
            var portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");

            var security = new Security();
            security.BamSymbol = "IBM Equity";

            Mock<IPosition> position = new Mock<IPosition>();
            position.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            position.SetupGet(pos => pos.Security).Returns(security);
            position.SetupGet(pos => pos.ActualQuantity).Returns(Convert.ToDecimal(positionQuantity));
            position.SetupGet(pos => pos.ActualSide).Returns(positionSide);
            position.SetupGet(pos => pos.TheoreticalQuantity).Returns(Convert.ToDecimal(positionQuantity));
            position.SetupGet(pos => pos.TheoreticalSide).Returns(positionSide);
            position.Setup(pos => pos.Clone()).Returns(position.Object);

            IPosition finalPosition = new Position(portfolio, security);
            finalPosition.ActualQuantity = 0;
            finalPosition.ActualSide = SideType.Unknown;
            position.Setup(pos => pos.Clone()).Returns(finalPosition);


            Mock<IOrder> order = new Mock<IOrder>();
            order.SetupGet(pos => pos.Portfolio).Returns(portfolio);
            order.SetupGet(pos => pos.Security).Returns(security);
            order.SetupGet(pos => pos.Size).Returns(Convert.ToDecimal(orderQuantity));
            order.SetupGet(pos => pos.Side).Returns(orderSide);            

            IPosition expected = new Position(portfolio, security);
            expected.TheoreticalQuantity = Convert.ToDecimal(expectedQuantity);
            expected.TheoreticalSide = expectedSide;

            PositionCalculator calculator = new PositionCalculator();
            IPosition actual = calculator.CancelOrder(position.Object, order.Object);

            Assert.True(expected.Equals(actual));
        }
    }
}
