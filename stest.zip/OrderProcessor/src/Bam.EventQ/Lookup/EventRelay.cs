﻿using System;
using Bam.EventQ.Workflow;

namespace Bam.EventQ.Lookup
{
    public abstract class EventRelay<TEvent> : IEventSource<TEvent>, IModelEventHandler<TEvent>
    {
        private readonly EventAggregator<TEvent> _eventAggregator;
        private IModelEventHandler<TEvent> _eventHandler;

        protected EventRelay()
        {
            _eventAggregator = new EventAggregator<TEvent>();
            ((IEventSource<TEvent>) _eventAggregator).EventHandler = this;
        }

        protected void Publish(TEvent @event)
        {
            _eventHandler?.Handle(@event);
        }

        IModelEventHandler<TEvent> IEventSource<TEvent>.EventHandler
        {
            get { return _eventHandler; }
            set { _eventHandler = value; }
        }

        protected IDisposable Attach(IEventSource<TEvent> source)
        {
            return _eventAggregator.Attach(source);
        }

        void IModelEventHandler<TEvent>.Handle(TEvent @event)
        {
            _eventHandler?.Handle(@event);
        }
    }
}
