﻿using Bam.Oms.Data;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Persistence.Contingency
{
    public class ContingencyRecord : IPersistentItem
    {
        public ContingencyRecord()
        {
        }

        public ContingencyRecord(IPosition position)
        {
            Portfolio = position.Portfolio.ToString();
            SymbolType = position.Security.SecurityType.ToString();
            Symbol = position.Security.Key;
            SymbolDesc = position.Security.BloombergSymbol;
            SymbolPricing = position.Security.Ticker ?? position.Security.BloombergSymbol ?? position.Security.BamSymbol;
            Quantity = position.ActualQuantity;
            SodPriceNative = position.Price;
            SodMarketValueNative = Quantity * SodPriceNative;
            Multiplier = 1.0m;
            Currency = position.Security.Currency;
            FxRate = position.FXRate;
            Country = position.Security.Country;
            Industry = position.Security.Industry;
            UnderlyingSymbol = position.Security.UnderlyingSymbol;
            SysDate = DateTime.Now;
        }

        public string Portfolio { get; set; }
        public string SymbolType { get; set; }
        public string Symbol { get; set; }
        public string SymbolDesc { get; set; }
        public string SymbolPricing { get; set; }
        public decimal Quantity { get; set; }
        public decimal? SodPriceNative { get; set; }
        public decimal? SodMarketValueNative { get; set; }
        public decimal? Multiplier { get; set; }
        public string Currency { get; set; }
        public decimal? FxRate { get; set; }
        public string Country { get; set; }
        public string Industry { get; set; }
        public string UnderlyingSymbol { get; set; }
        public DateTime SysDate { get; set; }

        public string Key
        {
            get { return $"{Portfolio.Trim()};{SymbolType.Trim()};{Symbol.Trim()}"; }
        }

        public bool Equals(ContingencyRecord contingencyRecord)
        {
            return Key.Equals(contingencyRecord.Key);
        }

        public bool IsExact(ContingencyRecord contingencyRecord)
        {
            return Portfolio.Equals(contingencyRecord.Portfolio)
                   && SymbolType.Trim().Equals(contingencyRecord.SymbolType.Trim())
                   && Symbol.Equals(contingencyRecord.Symbol)
                   && SymbolDesc.Equals(contingencyRecord.SymbolDesc)
                    && SymbolPricing.Equals(contingencyRecord.SymbolPricing)
                    && Quantity.Equals(contingencyRecord.Quantity)
                    && SodPriceNative.Equals(contingencyRecord.SodPriceNative)
                    && SodMarketValueNative.Equals(contingencyRecord.SodMarketValueNative)
                    && Multiplier.Equals(contingencyRecord.Multiplier)
                    && Currency.Equals(contingencyRecord.Currency)
                    && FxRate.Equals(contingencyRecord.FxRate)
                    && Country.Equals(contingencyRecord.Country)
                    && Industry.Equals(contingencyRecord.Industry)
                    && UnderlyingSymbol.Equals(contingencyRecord.UnderlyingSymbol);
        }

        public override bool Equals(object obj)
        {
            var sec = obj as ContingencyRecord;

            return sec != null && Equals(sec);
        }

        public override int GetHashCode()
        {
            return Key.GetHashCode();
        }

    }
}
