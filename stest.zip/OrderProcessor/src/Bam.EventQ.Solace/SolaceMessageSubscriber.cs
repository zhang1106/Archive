﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Transport;
using SolaceSystems.Solclient.Messaging;
using SolaceSystems.Solclient.Messaging.Cache;

namespace Bam.EventQ.Solace
{
    public class SolaceMessageSubscriber : IMessageSubscriber
    {
        private readonly object _syncRoot;
        private readonly ConcurrentQueue<IMessage> _buffer;
        private readonly SolaceContextWrapper _contextWrapper;
        private readonly ISolaceMessageTransform _transform;
        private readonly ISession _session;
        private ICacheSession _cache;

        public string Name => "Solace";

        public SolaceMessageSubscriber(SolaceContextWrapper contextWrapper)
            : this(contextWrapper, new NullMessageTransform())
        {
        }

        public SolaceMessageSubscriber(SolaceContextWrapper contextWrapper,
            ISolaceMessageTransform transform)
        {
            _contextWrapper = contextWrapper;
            _transform = transform;
            _buffer = new ConcurrentQueue<IMessage>();
            _syncRoot = new object();
            _session = contextWrapper.CreateSession(OnMessage);
        }

        public ILogger Logger { get; set; }

        public void Connect(params string[] topics)
        {
            _session.Connect();
            _cache = _contextWrapper.CreateCacheSession(_session);

            int reqId = 0;
            foreach (var topic in topics)
            {
                var sub = ContextFactory.Instance.CreateTopic(topic);
                if (_cache == null)
                {
                    _session.Subscribe(sub, true);
                }
                else
                {
                    _cache.SendCacheRequest(reqId++, sub, true, CacheLiveDataAction.FLOW_THRU);
                }
            }
        }

        public void Dispose()
        {
            _cache?.Dispose();
            _session.Dispose();
        }
        
        public bool TryReceive(byte[] buffer, int index, out int received, out int topic, TimeSpan timeout)
        {
            retry:
            IMessage msg;
            if (_buffer.TryDequeue(out msg))
            {
                if (!Monitor.Wait(_syncRoot, timeout))
                {
                    received = 0;
                    topic = 0;
                    return false;
                }
                goto retry;
            }
            
            _transform.Transform(msg, buffer, index, out received, out topic);
            return true;
        }

        private void OnMessage(object sender, MessageEventArgs args)
        {
            _buffer.Enqueue(args.Message);
            Monitor.Pulse(_syncRoot);
        }
    }
}
