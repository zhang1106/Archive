﻿namespace Bam.EventQ.Pipeline.Dsl
{
    public interface IObjectDecorator
    {
        T Decorate<T>(T obj);
    }
}
