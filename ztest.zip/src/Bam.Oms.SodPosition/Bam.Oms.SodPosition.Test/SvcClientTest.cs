﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Bam.Oms.SodPosition.Client;

namespace Bam.Oms.SodPosition.Test
{
    [TestClass]
    public class SvcClientTest
    {
        [TestMethod]
        public void TestWhatsup()
        {
            SvcClient client = new SvcClient();
            Assert.AreNotEqual<string>(client.Whatsup(), "Hello Word");
        }
    }
}
