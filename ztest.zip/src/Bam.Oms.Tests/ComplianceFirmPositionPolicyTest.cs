﻿using System;
using System.ComponentModel.Design;
using Bam.Oms.Compliance;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Policies;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class ComplianceFirmPositionPolicyTest
    {
        string _testSymbol;
        IIntradayPositionProvider _positionProvider;
        IRuleResultRepository _ruleResultRepository;
        IFactProvider _factProvider;

        [SetUp]
        public void Setup()
        {
            _testSymbol = "ANTO LN";
            var positionProvider = new Mock<IIntradayPositionProvider>();
            positionProvider.Setup(n => n.GetFirmWideNetQuantity(It.IsAny<string>())).Returns(Tuple.Create<string, decimal?>("test", 1380000m));
            positionProvider.Setup(n => n.GetFirmWideLongQuantity(It.IsAny<string>())).Returns(Tuple.Create<string, decimal?>("Test", 1380000m));
            _positionProvider = positionProvider.Object;

            var rulesultRepository = new Mock<IRuleResultRepository>();
            rulesultRepository.Setup(n => n.ClearAll()).Verifiable();
            _ruleResultRepository = rulesultRepository.Object;

            var factProvider = new Mock<IFactProvider>();
            factProvider.Setup(n => n.GetList(It.IsAny<string>()));
            _factProvider = factProvider.Object;
         
        }

        [Test]
        public void TestFirmPositionLimitPolicyAddRule()
        {
            //arr
            FirmPositionLimitPolicy policy = new FirmPositionLimitPolicy(_ruleResultRepository, new Mock<IRuleRepository<CompliancePosition>>().Object) { Type = "FirmPositionLimitPolicy" };
            LongOwnershipLimit rule1 = new LongOwnershipLimit(_positionProvider, _factProvider, new Mock<ILogger>().Object, new Mock<ILoggingAgent>().Object)
            {
                Name = "LongOnwershipLimit1",
                BamSymbol = _testSymbol,
                IsActive = true,
                Type = "Bam.Oms.Compliance.Rules.LongOwnershipLimit",
                Threshhold = 1300000
            };
            //act
            policy.AddRule(rule1);

            //ass
            Assert.IsTrue(policy.Rules.Count == 1);
        }

        [Test]
        [TestCase("LongOnwershipLimit1", 1300000, Data.Enumerators.ComplianceAlertLevel.Violated)]
        [TestCase("LongOnwershipLimit1", 1400000, Data.Enumerators.ComplianceAlertLevel.NoViolation)]
        public void TestFirmPositionLimitPolicy(string ruleName, decimal threshhold, Data.Enumerators.ComplianceAlertLevel alertLevel)
        {
            var policyProvider = new Mock<IPolicyProvider>();
            LongOwnershipLimit rule = new LongOwnershipLimit(_positionProvider, _factProvider, new Mock<ILogger>().Object, new Mock<ILoggingAgent>().Object)
            {
                Name = ruleName,
                BamSymbol = _testSymbol,
                IsActive = true,
                Type = "Bam.Oms.Compliance.Rules.LongOwnershipLimit",
                Threshhold = threshhold
            };

            FirmPositionLimitPolicy policy = new FirmPositionLimitPolicy(_ruleResultRepository, null) { Type = "FirmPositionLimitPolicy" };
            policy.AddRule(rule);

            policyProvider.Setup(n => n.Get(It.IsAny<string>()))
                .Returns((Policy<CompliancePosition>)policy);
            //
            //act
            CompliancePosition target = new CompliancePosition() { Security = new Security() { BamSymbol = _testSymbol }, Policy = policy };
            IPolicyResult result = policy.CheckViolations(target, false);

            //assert
            Assert.IsTrue(result.Alerts[0].AlertLevel == alertLevel);
        }
    }
}
