﻿using Bam.EventQ.Disruptor;
using Bam.EventQ.Pipeline.Dsl;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pipeline
{
    public static class ProcessingPipelineDslExtensions
    {
        public static ProcessingPipelineStepDsl<TItem> UseDisruptor<TItem>(
            this ProcessingPipelineStepDsl<TItem> dsl, int ringSize, int bufferSize)
        {
            dsl.UseQueue(new DisruptorQueue<PipelineQueueItem<TItem>>(
                new PipelineQueueItemFactory<TItem>(ringSize, bufferSize), ringSize));

            return dsl;
        }
    }
}
