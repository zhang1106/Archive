﻿using System.Collections.Generic;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Workflow;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages.ApiGateway;
using Bam.Oms.OrderGateway.Messages.Compliance;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;

namespace Bam.Oms.OrderGateway.Compliance.Workflows
{
    public class PositionTrackerWorkflow : Workflow,
        IHandle<OrdersCreated>,
        IHandle<OrderStatusChanged>,
        IHandle<OrderSideChanged>,
        IHandle<OrderQuantityChanged>,
        IHandle<OrderAllocationChanged>,
        IHandle<TargetAllocationChanged>
    {
        private readonly IOrderEffectMediator _orderEffectMediator;
        private readonly IReferenceDataService _referenceDataService;
        private readonly IComplianceCache _complianceCache;
        private readonly IOrderFactory _orderFactory;

        public PositionTrackerWorkflow(IOrderEffectMediator orderEffectMediator,
            IReferenceDataService referenceDataService,
            IComplianceCache complianceCache,
            IOrderFactory orderFactory)
        {
            _orderEffectMediator = orderEffectMediator;
            _referenceDataService = referenceDataService;
            _complianceCache = complianceCache;
            _orderFactory = orderFactory;
        }

        public void Execute(OrdersCreated input)
        {
            using (Attach(_complianceCache))
            {
                foreach (var o in input.Items)
                {
                    var order = _complianceCache.GetOrder(o.OrderId);

                    if (order == null)
                    {
                        var portfolio = Portfolio.Parse(o.Portfolio);
                        order = _orderFactory.Create(o.OrderId, o.Symbol, o.SecurityType,
                            portfolio, o.Quantity, o.Side);
                    }

                    if (order != null)
                    {
                        order.Status = o.Status;

                        // If the order was entered in an external OMS then we will
                        // not perform any allocation on our end. For long ownership
                        // rules we need the order's opening quantity though. We are
                        // taking the conservative approach here of treating the entire
                        // order quantity as opening which will reduce the available
                        // headroom by the full order quantity and not return any
                        // headroom for sell orders being filled
                        if (o.SubmissionMethod == SubmissionMethod.External)
                        {
                            order.SetOpeningAllocations(new List<OrderAllocation>
                            {
                                new OrderAllocation
                                {
                                    CustodianId = -1,
                                    FundId = -1,
                                    Portfolio = order.TopLevelPortfolio,
                                    Quantity = o.Quantity,
                                    Side = o.Side
                                }
                            });
                        }
                    }
                }
            }
        }

        public void Execute(OrderStatusChanged input)
        {
            using (Attach(_complianceCache))
            {
                FinalPositionChanged finalPositionChanged = null;

                foreach (var item in input.Items)
                {
                    var order = _complianceCache.GetOrder(item.OrderId);
                    if (order == null)
                    {
                        Logger?.LogWarning($"Received order status change for unknown order '{item.OrderId}'");
                        continue;
                    }

                    var previousCompleteState = order.IsComplete;

                    using (Attach(order))
                    {
                        order.Status = item.Status;
                        _orderEffectMediator.ApplyEffects(order);
                    }

                    if (order.IsComplete || previousCompleteState)
                    {
                        if (finalPositionChanged == null)
                            finalPositionChanged = new FinalPositionChanged();

                        finalPositionChanged.Items.Add(new FinalPositionChanged.Item() {OrderId = order.OrderId, IsComplete = order.IsComplete});
                    }
                }

                if (finalPositionChanged != null)
                    Publish(finalPositionChanged);
            }
        }

        public void Execute(OrderAllocationChanged input)
        {
            using (Attach(_complianceCache))
            {
                var order = _complianceCache.GetOrder(input.OrderId);
                if (order == null)
                {
                    Logger?.LogWarning($"Received order allocation for unknown order '{input.OrderId}'");
                    return;
                }

                var allocations = new List<OrderAllocation>(input.Allocations.Count);
                using (Attach(order))
                {
                    foreach (var item in input.Allocations)
                    {
                        Portfolio portfolio;
                        if (!Portfolio.TryParse(item.Portfolio, out portfolio))
                        {
                            Logger?.LogError($"Received allocation for unknown portfolio {item.Portfolio}");
                            continue;
                        }

                        allocations.Add(new OrderAllocation
                        {
                            Portfolio = portfolio,
                            CustodianId = item.CustodianId,
                            FundId = item.FundId,
                            Quantity = item.Quantity,
                            Side = order.Side
                        });
                    }

                    order.UpdateActualAllocations(allocations);
                    _orderEffectMediator.ApplyEffects(order);
                }
            }
        }

        public void Execute(TargetAllocationChanged input)
        {
            using (Attach(_complianceCache))
            {
                foreach (var item in input.Items)
                {
                    var order = _complianceCache.GetOrder(item.OrderId);
                    if (order == null)
                    {
                        Logger?.LogWarning($"Received order quantity change for unknown order '{item.OrderId}'");
                        return;
                    }

                    var isOmni = order.IsOmni;
                    var allocations = new List<OrderAllocation>(item.Allocations.Count);
                    foreach (var alloc in item.Allocations)
                    {
                        isOmni |= _referenceDataService.IsOmni(alloc.CustodianId);

                        Portfolio portfolio;
                        if (!Portfolio.TryParse(alloc.Portfolio, out portfolio))
                        {
                            Logger?.LogError($"Received allocation for unknown portfolio {alloc.Portfolio}");
                            continue;
                        }

                        allocations.Add(new OrderAllocation
                        {
                            Portfolio = portfolio,
                            CustodianId = alloc.CustodianId,
                            FundId = alloc.FundId,
                            Quantity = alloc.Quantity,
                            Side = order.Side
                        });
                    }

                    using (Attach(order))
                    {
                        order.IsOmni = isOmni;
                        order.UpdateTheoreticalAllocations(allocations);
                        _orderEffectMediator.ApplyEffects(order);
                    }
                }
            }
        }

        public void Execute(OrderSideChanged input)
        {
            using (Attach(_complianceCache))
            {
                var order = _complianceCache.GetOrder(input.OrderId);
                if (order == null)
                {
                    Logger?.LogWarning($"Received order side change for unknown order '{input.OrderId}'");
                    return;
                }

                order.ChangeSide(input.Side);
            }
        }

        public void Execute(OrderQuantityChanged input)
        {
            using (Attach(_complianceCache))
            {
                var order = _complianceCache.GetOrder(input.OrderId);
                if (order == null)
                {
                    Logger?.LogWarning($"Received order quantity change for unknown order '{input.OrderId}'");
                    return;
                }

                order.ChangeSize(input.Quantity);
            }
        }
    }
}
