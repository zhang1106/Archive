﻿using System;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.JsonDotNet;
using Bam.EventQ.Pipeline.Dsl;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pipeline
{
    public static class ProcessingPipelineDslExtensions
    {
        public static PipelineQueueItemHandlerChainDsl<TItem> LogMessagesTo<TItem>(
            this PipelineQueueItemHandlerChainDsl<TItem> dsl, string prefix, bool log, ILogger logger, params Type[] excludedMessageTypes)
        {
            if (log)
            {
                dsl.AddHandler(new JsonMessageLogger<TItem>(logger, prefix, excludedMessageTypes));
            }
            return dsl;
        }
    }
}
