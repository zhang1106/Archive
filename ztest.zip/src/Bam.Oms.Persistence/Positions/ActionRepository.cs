﻿using System.Collections.Generic;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Positions;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Persistence.Positions
{
    public sealed class ActionRepository : DBRepository<SodAction>, IActionRepository
    {
        public ActionRepository(ISettings settings, ILogger logger) : base(settings, logger, "sod", "Action")
        {
            _includeColumnPredicate = (column => !column.Equals("Key"));
        }
    }
}
