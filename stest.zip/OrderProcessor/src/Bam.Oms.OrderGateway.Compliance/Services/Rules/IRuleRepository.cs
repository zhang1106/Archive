﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public interface IRuleRepository
    {
        List<IRule> GetAll();
    }
}
