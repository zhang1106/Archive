﻿using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class SodPositionServiceClient : ISodPositionServiceClient
    {
        private readonly string _uri;
        private readonly MediaTypeWithQualityHeaderValue _mediaTypeHeaderValue;
        private readonly MediaTypeFormatter _mediaFormatter;

        public SodPositionServiceClient(string uri)
        {
            _uri = uri;
            _mediaFormatter = new JsonMediaTypeFormatter();
            _mediaTypeHeaderValue = new MediaTypeWithQualityHeaderValue(_mediaFormatter.SupportedMediaTypes[0].MediaType);
        }

        public async Task<List<SodPositionDto>> Get()
        {
            using (var client = GetHttpClient())
            {
                var response = await client.GetAsync(_uri);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsAsync<List<SodPositionDto>>(new[] { _mediaFormatter });
            }
        }

        private HttpClient GetHttpClient()
        {
            HttpClientHandler handler = new HttpClientHandler
            {
                UseDefaultCredentials = true,
            };

            var httpClient = new HttpClient(handler);
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(_mediaTypeHeaderValue);
            return httpClient;
        }
    }
}
