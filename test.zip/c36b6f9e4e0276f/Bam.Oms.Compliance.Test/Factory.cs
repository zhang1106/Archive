﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;
using Moq;
using Ploeh.AutoFixture;

namespace Bam.Oms.Compliance.Test
{
    public class Factory
    {
        private const string ConnectionString = @"Data Source=dw-db;Initial Catalog=BamCoreLite;Integrated Security=true;Application Name=compliance";
        private const string OgwyConnectionString = @"Data Source=ems-db-qa;Initial Catalog=OrderGateway;Integrated Security=true;Application Name=compliance";
        private const string PomoUrl = "http://pomo-app/PoMoWebServices/api/ContainerInfo";
        private const string PomoHoldingUrl = "http://pomo-app/PoMoWebServices/api/HoldingContainerInfo";

        public static ISettings GetSettings()
        {
            var settings = new Mock<ISettings>();
            settings.Setup(s => s.Config()).Verifiable();
            settings.SetupGet(s => s.OrderGatewayConnectionString).Returns(OgwyConnectionString);
            settings.SetupGet(s => s.BamCoreLiteConnectionString).Returns(ConnectionString);
            settings.SetupGet(s => s.PomoUrl).Returns(PomoUrl);
            settings.SetupGet(s => s.PomoHoldingUrl).Returns(PomoHoldingUrl);
            settings.SetupGet(s => s.HeadRoomRatioAQTF).Returns(20);
            settings.SetupGet(s => s.HeadRoomRatioMAIN).Returns(80);
            settings.SetupGet(s => s.HeadRoomFilePath).Returns("c:\temp");
            settings.SetupGet(s => s.RuleTable).Returns("Rule");
            settings.SetupGet(s => s.PolicyRuleTable).Returns("PolicyRule");
            settings.SetupGet(s => s.PolicyTable).Returns("Policy");
            settings.SetupGet(s => s.FactTable).Returns("Fact");

            return settings.Object;
        }

        public static IHelper GetHelper(ISettings settings)
        {
            var ogRepoMock = new Mock<IOgDataRepository>();
            ogRepoMock.Setup(o=>o.DumpPositions(It.IsAny<IEnumerable<FlatPosition>>())).Verifiable();
            return new Helper(settings, new Mock<ICustomDataProvider>().Object, ogRepoMock.Object, new Mock<ISecurityProvider>().Object, new Mock<ILogger>().Object);
        }

        public static Mock<ICompliancePosition> CreateCompliancePosition(ISettings settings, ISecurity security, IPolicy<ICompliancePosition> policy, bool isSod, decimal? pos = 0)
        { 
            //
            var positionProvider = new Mock<IPositionProvider>();
            positionProvider.Setup(p => p.GetFirmWideQuantity(It.IsAny<string>(), It.IsAny<PositionType>(), It.IsAny<SideType>())).Returns(new Tuple<string, decimal?>("test Long", pos));
            positionProvider.Setup(p => p.GetEntityWideQuantityByIsin(It.IsAny<string>(), It.IsAny<PositionType>(), It.IsAny<string>(), It.IsAny<SideType>())).Returns(new Tuple<string, decimal?>("test Long", pos));

            var target = new Mock<ICompliancePosition>();
            target.SetupGet(t => t.Helper).Returns(Factory.GetHelper(settings));
            target.SetupGet(t => t.Security).Returns(security);
            target.SetupGet(t => t.BamSymbol).Returns(security.BamSymbol);
            target.SetupGet(t => t.Logger).Returns(new Mock<ILogger>().Object);
            target.SetupGet(t => t.PositionProvider).Returns(positionProvider.Object);
            target.SetupGet(t => t.RuleResultProvider).Returns(new Mock<IOwnershipRuleResultProvider>().Object);
 
            return target;
        }

        public static DtdPosition CreateSodPosition(string symbol,  long holding)
        {
            var fixture = new Fixture();
            var position = fixture.Create<DtdPosition>();
            position.BamSymbol = symbol;
            position.Quantity = holding;

            return position;
        }

        public static IPosition CreatePosition(string symbol, string underlying, string isin, decimal holding, InvestmentType iType = InvestmentType.OrdinaryShare)
        {
            var fixture = new Fixture();
            var security = CreateSecurity(symbol, underlying, isin, iType);

            var position = fixture.Create<Position>();
            position.Security = security;
            position.ActualQuantity = holding;
            position.Portfolio.AggregationUnit = "BAM";

            return position.InitPosition();
        }

        public static Security CreateSecurity(string symbol, string underlying, string isin, InvestmentType iType=InvestmentType.OrdinaryShare)
        {
            var fixture = new Fixture();
            var security = fixture.Create<Security>();
            security.BamSymbol = symbol;
            security.UnderlyingSymbol = symbol;
            security.Isin = isin;
            security.SecurityType = SecurityType.Equity;
            security.InvestmentType = iType;
            security.AssetType = AssetType.Equity;
            return security;
        }

        public static Security CreateAdrSecurity(string symbol, string isin, decimal adrRatio)
        {
            var security = CreateSecurity(symbol, symbol, isin, InvestmentType.DepositaryReceipt);
            security.AdrRatio = adrRatio;
            return security;
        }

        public static IPosition CreateOptionPosition(string symbol, string isin, decimal holding, OptionType type, InvestmentType iType)
        {
            var fixture = new Fixture();
            var security = CreateOptionSecurity(symbol, isin, type, iType);
            var position = fixture.Create<Position>();
            position.Security = security;
            position.ActualQuantity = holding;
            position.Portfolio.AggregationUnit = "BAM";

            return position.InitPosition();
        }

        public static Security CreateOptionSecurity(string symbol, string isin, OptionType type, InvestmentType iType)
        {
            var fixture = new Fixture();
            var security = fixture.Create<Security>();
            security.BamSymbol = symbol;
            security.UnderlyingSymbol = symbol;
            security.Isin = isin;
            security.OptionType = type;
            security.ContractSize = 100;
            security.InvestmentType = iType;
            security.AssetType = AssetType.Option;
            return security;
        }
    }
}
