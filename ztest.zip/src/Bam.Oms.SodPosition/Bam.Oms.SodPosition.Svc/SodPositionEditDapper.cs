﻿using System;
using CsvHelper;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.IO;
using System.Transactions;
using Bam.Oms.Data.Positions;
using System.Runtime.Caching;
using System.Runtime.CompilerServices;
using BAM.Infrastructure.Ioc;
using Bam.Oms.SodPosition.Svc.File;
using System.Threading.Tasks;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Persistence.DBContext;
using Bam.Oms.RefData;

namespace Bam.Oms.SodPosition.Svc
{
    /// <summary>
    /// Implementation of SodPositionEdit using repository pattern
    /// </summary>
    public class SodPositionEditDapper : ISodPositionEdit
    {
        private readonly ISecurityMasterService _securityMasterService;
        private const string EXCEPTION_SOURCE = "Web Service";

        private readonly ILogger _log;
        private readonly IFileLoading _fileLoading;
        private readonly SodPositionDBContext _sodPositionDBContext;
        private readonly IAccountService _accountService;

        private readonly IList<string> _streams;

        private readonly MemoryCache _cache = MemoryCache.Default;

        private IDictionary<string, DateTime> _streamEntryDateMap = new Dictionary<string, DateTime>();

        public SodPositionEditDapper(ILogger logger, IFileLoading fileLoading, SodPositionDBContext sodPositionDBContext, IAccountService accountService, ISecurityMasterService securityMasterService)
        {
            _securityMasterService = securityMasterService;
            if (logger == null)
            {

                throw new ArgumentNullException(nameof(logger));
            }
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));

            try
            {
                this._log = logger;
                if (fileLoading == null) throw new ArgumentNullException(nameof(fileLoading));
                if (sodPositionDBContext == null) throw new ArgumentNullException(nameof(sodPositionDBContext));
                if (accountService == null) throw new ArgumentNullException(nameof(accountService));

                _accountService = accountService;

                var streamList = ConfigurationManager.AppSettings["streams"];
                if (string.IsNullOrEmpty(streamList))
                {
                    throw new Exception("Can't find the list of streams in the configuration file.");
                }
                else
                {
                    _streams = streamList.Split(';');
                }

                this._sodPositionDBContext = sodPositionDBContext;

                this._fileLoading = fileLoading;
            }
            catch (Exception ex)
            {
                _log.Error("Exception instantating SODPosition Edit.", ex);
                throw;
            }
        }

        public virtual void Start()
        {
            RefreshStreamEntryDateMap();
            if (this._fileLoading != null)
            {
                this._fileLoading.SodPositionLoaded += PublishLoadedPositions;
                this._fileLoading.SodPositionLoaded += RefreshStreamEntryDateMap;
                _fileLoading.Start();
            }
        }

        public virtual void Dispose()
        {
        }

        public string CSVOutputPath
        {
            get
            {
                if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["sodPosition_update_path"]))
                {
                    throw new Exception("Cant find the output path for Sod position update path - [SodPosition-Update-Path] in configuration file.");
                }
                else
                {
                    return ConfigurationManager.AppSettings["sodPosition_update_path"];
                }
            }
        }

        public string Whatsup()
        {
            return "Hello World";
        }

        public IList<IPosition> GetPositions(DateTime? asofdate, string stream, string fundCode, string custodianName, string strategyCode, string securityType, string bamSymbol)
        {
           return GetSodPositions(asofdate, stream, fundCode, custodianName, strategyCode, securityType, bamSymbol).ToList<IPosition>();
        }

        public IList<Position> GetSodPositions(DateTime? asofdate, string stream, string fundCode, string custodianName, string strategyCode, string securityType, string bamSymbol)
        {
            try
            {
                IList<Position> positions = _sodPositionDBContext.Positions.GetPositions(asofdate, stream, fundCode, custodianName, strategyCode, securityType, bamSymbol);
                var originalPositionCount = positions.Count;

                positions = _accountService.SetAccountAttributes(positions).Cast<Position>().ToList();
                _securityMasterService.SetSecurityAttributes(positions);
                
                
                if(positions.Count != originalPositionCount)
                    _log.Error($"SOD position count after validation has changed from {originalPositionCount} to {positions.Count}");

                return positions;
            }
            catch (Exception ex)
            {
                LogException("POSITION_FETCH", ex);
                throw;
            }
        }

        /// <summary>
        /// get latest updated positions which have not been published
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public IList<Position> GetLatestUpdatedPositions(string stream)
        {
            List<Position> positions = null;
            try
            {

                var publishActionName = GetPublishPositionsActionName(stream);
                var action = GetAction(publishActionName, Constants.BAM_ACTION_TYPE);

                if (action == null)
                {
                    throw new Exception($"Couldn't find the action corresponding to {publishActionName}");
                }
                else
                {
                    var actionLog = _sodPositionDBContext.ActionLogs.Get(new { ActionId = action.ActionId }).OrderByDescending(x => x.CreatedOn).FirstOrDefault();

                    DateTime now = DateTime.Now;
                    string positionFilter = "";
                    object parameters = null;
                    if (actionLog == null)
                    {
                        // No previous action log present. All the records need to be exported
                        positionFilter = "Stream = @Stream AND LastModifiedOn <= @CurrentTime AND AuditSequence > 0";
                        parameters = new { Stream = stream, CurrentTime = now };
                    }
                    else
                    {
                        positionFilter = "Stream = @Stream AND LastModifiedOn > @ActionLogTime AND LastModifiedOn <= @CurrentTime AND AuditSequence > 0";
                        parameters = new { Stream = stream, ActionLogTime = actionLog.CreatedOn, CurrentTime = now };
                    }

                    positions = new List<Position>(_sodPositionDBContext.Positions.Get(positionFilter, parameters));

                    var originalPositionCount = positions.Count;

                    positions = _accountService.SetAccountAttributes(positions).Cast<Position>().ToList();

                    if (positions.Count != originalPositionCount)
                        _log.Error($"SOD position count after validation has changed from {originalPositionCount} to {positions.Count}");
                }
                return positions;
            }
            catch (Exception ex)
            {
                LogException("LATEST_UPDATED_POSITIONS_FETCH", ex);
                throw;
            }
        }

        public string GetPublishPositionsActionName(string stream)
        {
            return stream + "_PUBLISH_UPDATED_POSITIONS";
        }


        /// <summary>
        /// get list of audit trails for a poistion
        /// </summary>
        /// <param name="positionId"></param>
        /// <param name="entrydate"></param>
        /// <returns></returns>
        public IList<PositionAudit> GetAudits(int positionId, DateTime entrydate)
        {
            try
            {
                return _sodPositionDBContext.PositionAudits.Get(new { PositionId = positionId, EntryDate = entrydate }).ToList();
            }
            catch (Exception ex)
            {
                LogException("GET_AUDIT_TRAIL", ex);
                throw;
            }
        }

        /// <summary>
        /// update a position
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public Position UpdatePosition(Position position)
        {
            try
            {
                using (var tscope = new TransactionScope())
                {
                    var action = GetAction(Constants.POSITION_UPDATE_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find the action corresponding to {Constants.POSITION_UPDATE_ACTION_NAME}");
                    }
                    // action is not null
                    SodActionLog actionLogEntry = _sodPositionDBContext.ActionLogs.Save(new SodActionLog() { ActionId = action.ActionId, ActionDetails = "Updated a position", CreatedOn = DateTime.Now });
                    List<Position> positionList = new List<Position>();
                    positionList.Add(position);
                    position = UpdatePositions(positionList, actionLogEntry.ActionLogId).Single();
                    tscope.Complete();
                    return position;
                }
            }
            catch (Exception ex)
            {
                LogException("UPDATE_POSITION", ex);
                throw;
            }
        }

        /// <summary>
        /// bulk update positions
        /// </summary>
        /// <param name="positions"></param>
        /// <returns></returns>
        public IList<Position> BulkUpdatePosition(IList<Position> positions)
        {
            try
            {
                using (var tscope = new TransactionScope())
                {
                    var action = GetAction(Constants.POSITION_BULK_UPDATE_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find the action corresponding to {Constants.POSITION_BULK_UPDATE_ACTION_NAME}");
                    }
                    // action is not null
                    var actionLogEntry = new SodActionLog { ActionId = action.ActionId, ActionDetails = "Updated a position", CreatedOn = DateTime.Now };
                    actionLogEntry = _sodPositionDBContext.ActionLogs.Save(actionLogEntry);
                    var modifiedPositions = UpdatePositions(positions, actionLogEntry.ActionLogId);
                    tscope.Complete();
                    return modifiedPositions;
                }
            }
            catch (Exception ex)
            {
                LogException("BULK_UPDATE_POSITION", ex); 
                throw;
            }
        }

        /// <summary>
        /// insert a position
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public Position InsertPosition(Position position)
        {
            try
            {
                using (var tscope = new TransactionScope(TransactionScopeOption.Required,
                    new TransactionOptions() { IsolationLevel = IsolationLevel.ReadUncommitted }))
                {
                    var action = GetAction(Constants.POSITION_INSERT_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find the action corresponding to {Constants.POSITION_INSERT_ACTION_NAME}");
                    }
                    SodActionLog actionLogEntry = new SodActionLog { ActionId = action.ActionId, ActionDetails = "Inserted a position", CreatedOn = DateTime.Now };
                    actionLogEntry = _sodPositionDBContext.ActionLogs.Save(actionLogEntry);
                    PreparePositionForInsert(position, actionLogEntry.ActionLogId);
                    // Persist the position
                    var insertedPosition = InsertPositions(new[] { position }, actionLogEntry.ActionLogId).Single();
                    tscope.Complete();
                    return insertedPosition;
                }
            }
            catch (Exception ex)
            {
                LogException("INSERT_POSITION", ex);
                throw;
            }
        }

        /// <summary>
        /// bulk inert poistions
        /// </summary>
        /// <param name="positions"></param>
        /// <returns></returns>
        public IList<Position> BulkInsertPosition(IList<Position> positions)
        {
            try
            {
                using (var transactionScope = new TransactionScope())
                {
                    var action = _sodPositionDBContext.Actions.Get(new { Name = Constants.POSITION_BULK_INSERT_ACTION_NAME, Type = Constants.BAM_ACTION_TYPE }).FirstOrDefault();
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find the action corresponding to {Constants.POSITION_BULK_INSERT_ACTION_NAME}");
                    }
                    DateTime now = DateTime.Now;
                    SodActionLog actionLogEntry = new SodActionLog { ActionId = action.ActionId, ActionDetails = "Bulk inserted positions", CreatedOn = now };
                    actionLogEntry = _sodPositionDBContext.ActionLogs.Save(actionLogEntry);
                    foreach (var pos in positions)
                    {
                        PreparePositionForInsert(pos, actionLogEntry.ActionLogId);
                    }
                    positions = InsertPositions(positions, actionLogEntry.ActionLogId);
                    transactionScope.Complete();
                    return positions;
                }

            }
            catch (Exception exception)
            {
                LogException("BULK_INSERT_POSITION", exception);
                throw;
            }
        }

        /// <summary>
        /// publish changes to subscribers
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public bool PublishUpdatedPositions(string stream)
        {
            try
            {
                var changed = GetLatestUpdatedPositions(stream);
                var now = DateTime.Now;
                var publishActionName = GetPublishPositionsActionName(stream);
                var action = GetAction(publishActionName, Constants.BAM_ACTION_TYPE);
                if (action == null)
                {
                    throw new Exception($"Couldn't find the action corresponding to {publishActionName}");
                }

                var success = SaveToCSVFile("", changed);

                var actionLogEntry = new SodActionLog { ActionId = action.ActionId, ActionDetails = "Saving positions to CSV", CreatedOn = now };
                _sodPositionDBContext.ActionLogs.Save(actionLogEntry);
                
                var affectedSymbols = "'" + changed.Select(o => o.Security.BamSymbol).Distinct().Aggregate((i, j) => i + "','" + j) + "'";
                var affectedPortfolios = "'" + changed.Select(o => o.Portfolio.ToString()).Distinct().Aggregate((i, j) => i + "','" + j) + "'";

                var positionFilter = $"Stream = @Stream and BamSymbol in ({affectedSymbols}) and StrategyCode in ({affectedPortfolios})";

                var relatedPositions = new List<Position>(_sodPositionDBContext.Positions.Get(positionFilter, new { Stream = stream }));

                var toBeUpdated = relatedPositions.Where(p => changed.Any(c => c.Security.BamSymbol == p.Security.BamSymbol && c.Portfolio.Key == p.Portfolio.Key)).ToList();

                toBeUpdated = _accountService.SetAccountAttributes(toBeUpdated).Cast<Position>().ToList();

                // Raise event in a new thread
                Task.Factory.StartNew(() => RaisePositionEvent(toBeUpdated, SodPositionUpdated));
                return success;
            }
            catch (Exception exception)
            {
                LogException("PUBLISH_UPDATED_POSITIONS", exception);
                throw;
            }
        }
        
        public IList<Position> ExecuteUndo(int positionId, IList<Position> undoList)
        {
            try
            {
                using (var tscope = new TransactionScope())
                {
                    var action = GetAction(Constants.UNDO_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception($"Couldn't find the action corresponding to {Constants.UNDO_ACTION_NAME}");
                    }
                    DateTime now = DateTime.Now;
                    SodActionLog actionLogEntry = new SodActionLog { ActionId = action.ActionId, ActionDetails = "Undid operation", CreatedOn = now };
                    actionLogEntry = _sodPositionDBContext.ActionLogs.Save(actionLogEntry);
                    IList<Position> undoChanges = GetUndoChanges(positionId);

                    if (undoChanges == null || undoChanges.Count == 0) return new List<Position>();
                    if (!IsSamePositionList(undoList, undoChanges))
                    {
                        // Apparently, the some of the positions have been updated
                        return new List<Position>();
                    }

                    IList<Position> modifiedPositions = UpdatePositions(undoList, actionLogEntry.ActionLogId);
                    tscope.Complete();
                    return modifiedPositions;
                }
            }
            catch (Exception exception)
            {
                LogException("EXECUTE_UNDO", exception);
                throw;
            }

        }

        private bool IsSamePositionList(IList<Position> list1, IList<Position> list2)
        {
            if (list1 == null && list2 == null)
            {
                return true;
            }
            if (list1.Count != list2.Count)
            {
                return false;
            }
            foreach (var p in list1)
            {
                bool found = false;
                for (int i = 0; i < list2.Count; ++i)
                {
                    if (IsSamePosition(p, list2[i]))
                    {
                        list2.RemoveAt(i);
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    return false;
                }
            }
            return true;
        }

        public IList<Position> GetUndoChanges(int positionId)
        {
            try
            {
                using (var tscope = new TransactionScope())
                {
                    var position = _sodPositionDBContext.Positions.GetById(positionId);
                    if (position == null || position.AuditSequence == 0)
                    {
                        //Cannot find the position or the position has just been loaded as part of daily load
                        return new List<Position>();
                    }
                    var actionLogId = position.ActionLogId;
                    //Find all the positions associated with this actionLogId from the audit table
                    var audits = _sodPositionDBContext.PositionAudits.Get(new { ActionLogId = actionLogId }).ToList();

                    var contributingPositions = _sodPositionDBContext.Positions.Get(new { ActionLogId = actionLogId }).ToList();

                    if (audits.Count != contributingPositions.Count)
                    {
                        //Cannot undo as not all positions seem to be in the same state as they were
                        // post the operation
                        return new List<Position>();
                    }
                    // Confirm that all the positions are having different position ids.
                    // If such is not the case, it points to data corruption.
                    if (audits.Count != audits.Select(x => x.Position.PositionId).Distinct().Count())
                    {
                        return new List<Position>();
                    }
                    // All the positions are at the same state as they were post the operation
                    // Get the previous state of all those positions
                    // For each position, get the older state, or if the position was not present,
                    // set the quantity to 0 so that it can be taken as deleted
                    var olderDbAudits = _sodPositionDBContext.PositionAudits.GetOlderAudits(actionLogId.Value);

                    var existingOlderPositionIds = olderDbAudits.Select(x => x.Position.PositionId).ToList();
                    // Find all positions for which no previous positions were found.
                    // those positions need to be set to deleted i.e. Qty set to zero
                    var positionsToBeDeleted = contributingPositions.Where(x => !existingOlderPositionIds.Contains(x.PositionId)).ToList();

                    // get the positions for all these positions ids and set Qty to zero
                    foreach (var pos in positionsToBeDeleted)
                    {
                        pos.ActualQuantity = 0;
                        pos.TheoreticalQuantity = 0;
                        pos.Price = 0;
                    }
                    var olderPositions = olderDbAudits.Select(audit => audit.Position).ToList();
                    foreach (var pos in olderPositions)
                    {
                        pos.AuditSequence++;
                    }
                    List<Position> aggregatedPositions = new List<Position>();
                    aggregatedPositions.AddRange(positionsToBeDeleted);
                    aggregatedPositions.AddRange(olderPositions);

                    tscope.Complete();
                    return aggregatedPositions;
                }
            }
            catch (Exception exception)
            {
                LogException("GET_UNDO_CHANGES", exception);
                throw;
            }
        }

        public IList<SodAction> GetBulkActions()
        {
            try
            {
                return _sodPositionDBContext.Actions.Get(new { Type = Constants.CORP_ACTION_TYPE }).ToList();
            }
            catch (Exception exception)
            {
                LogException("GET_BULK_ACTIONS", exception);
                throw;
            }
        }

        public IList<string> GetStreams()
        {
            return _streams;
        }

        public string GetLatestLoadedStream()
        {
            try
            {
                var streams = GetStreams();
                IDictionary<int, string> actionIdToStreamMap = new Dictionary<int, string>();
                foreach (var stream in streams)
                {
                    var dailyLoadAction = GetAction(GetDailyLoadingActionName(stream), Constants.BAM_ACTION_TYPE);
                    if (dailyLoadAction != null)
                    {
                        actionIdToStreamMap[dailyLoadAction.ActionId] = stream;
                    }
                }
                var maxLoadTime = (from actLog in _sodPositionDBContext.ActionLogs.GetAll()
                                   where actionIdToStreamMap.Keys.Contains(actLog.ActionId)
                                   select (DateTime?)actLog.CreatedOn).Max();
                if (maxLoadTime == null)
                {
                    return null;
                }
                var actionId = _sodPositionDBContext.ActionLogs.Get(new { CreatedOn = maxLoadTime }).First().ActionId;
                return actionIdToStreamMap[actionId];
            }
            catch (Exception exception)
            {
                LogException("GET_LATEST_LOADED_STREAM", exception);
                throw;
            }

        }

        private string GetDailyLoadingActionName(string stream)
        {
            return stream + "_DAILY_LOADING";
        }

        /// <summary>
        /// output a list of positions to a csv file
        /// </summary>
        /// <param name="completeFileName"></param>
        /// <param name="positions"></param>
        /// <returns></returns>
        public bool SaveToCSVFile(string completeFileName, IList<Position> positions)
        {
            completeFileName = $"{CSVOutputPath}/FLEX_SOD_FILE_UPDATE_{DateTime.Now:yyyyMMdd_hhmmssfff}.csv";
            string formatter = "0.############";
            using (var writer = new StreamWriter(completeFileName))
            {
                var records = positions.Select(x => new
                {
                    Symbol = x.Security.BamSymbol,
                    Qty = x.ActualQuantity.ToString(formatter),
                    Price = x.Price?.ToString(formatter),
                    Currency = x.Security.Currency,
                    FxRate = x.FXRate?.ToString(formatter),
                    Custodian = x.CustodianName,
                    SecurityType = x.Security.SecurityType,
                    Strategy = x.Portfolio.ToString(),
                    Fund = x.FundCode,
                    Stream = x.Stream
                }).ToList();
                var csvWriter = new CsvWriter(writer);
                csvWriter.WriteRecords(records);
            }
            return true;
        }

        public static Func<T, bool> And<T>(params Func<T, bool>[] predicates)
        {
            return delegate (T item)
            {
                foreach (Func<T, bool> predicate in predicates)
                {
                    if (!predicate(item))
                    {
                        return false;
                    }
                }
                return true;
            };
        }

        public event Action<IList<Position>> SodPositionUpdated;
        public event Action<IList<Position>> SodPositionLoad;

        private void LogException(string data, Exception exception)
        {
            string description = exception.Message;
            // If innerexception is present, append that information as well
            var innerException = exception.InnerException;
            int count = 5; //Don't go more than 5 level deep
            while (count-- != 0)
            {
                if (innerException != null)
                {
                    description += " InnerException: " + innerException.Message;
                    innerException = innerException.InnerException;
                }
            }
            var dbException = new SodException { Source = EXCEPTION_SOURCE, Data = data, Description = Truncate(description, 300), CreatedOn = DateTime.Now };
            _sodPositionDBContext.Exceptions.Save(dbException);
        }

        private string Truncate(string str, int maxLength)
        {
            if (string.IsNullOrEmpty(str)) return str;
            return str.Length <= maxLength ? str : str.Substring(0, maxLength);
        }

        private SodAction GetAction(string name, string type)
        {
            var key = name + "||" + type;
            SodAction action = _cache.Get(key) as SodAction;
            if (action == null)
            {
                action = _sodPositionDBContext.Actions.Get(new { Name = name, Type = type }).SingleOrDefault();
                if (action != null)
                {
                    _cache.Set(key, action, new CacheItemPolicy());
                }
            }
            return action;
        }

        private void PreparePositionForUpdate(Position position, Position existingPosition, int actionLogId)
        {
            DateTime now = DateTime.Now;
            position.AuditSequence = existingPosition.AuditSequence + 1;
            position.ActionLogId = actionLogId;
            position.LastModifiedOn = now;
            position.CreatedOn = existingPosition.CreatedOn;
            position.EntryDate = existingPosition.EntryDate;
        }

        private bool IsSamePosition(Position pos1, Position pos2)
        {
            if (pos1 == pos2)
            {
                return true;
            }
            if (pos1 == null && pos2 != null)
            {
                return false;
            }
            return string.Equals(pos1.Security.BamSymbol, pos2.Security.BamSymbol)
                && string.Equals(pos1.Security.Currency, pos2.Security.Currency)
                && string.Equals(pos1.CustodianName, pos2.CustodianName)
                && string.Equals(pos1.FundCode, pos2.FundCode)
                && decimal.Equals(pos1.FXRate, pos2.FXRate)
                && pos1.Security.SecurityType == pos2.Security.SecurityType
                && decimal.Equals(pos1.Price, pos2.Price)
                && decimal.Equals(pos1.ActualQuantity, pos2.ActualQuantity)
                && pos1.Portfolio.Equals(pos2.Portfolio)
                && string.Equals(pos1.Stream, pos2.Stream)
                && string.Equals(pos1.CustodianAccountCode, pos2.CustodianAccountCode)
                && pos1.Cost == pos2.Cost;
        }


        private IList<Position> UpdatePositions(IList<Position> dbPositions, int actionLogId)
        {
            dbPositions = PreprocessPositions(dbPositions, actionLogId);
            var positionsToInsert = dbPositions.Where(x => x.PositionId == 0).ToList();
            var positionsToUpdate = dbPositions.Where(x => x.PositionId != 0).ToList();
            var insertedPositions = InsertPositions(positionsToInsert, actionLogId);
            var positionIds = positionsToUpdate.Select(x => x.PositionId).Distinct().ToList();
            if (positionIds.Count + positionsToInsert.Count != dbPositions.Count)
            {
                throw new Exception("Apparently, there are some positions with same position ids");
            }
            var existingPositions = (from pos in _sodPositionDBContext.Positions.GetAll()
                                     join pId in positionIds
                                     on pos.PositionId equals pId
                                     select pos).ToList();
            if (existingPositions.Count < positionIds.Count)
            {
                throw new InvalidOperationException("Couldn't find positions corresponding to a few position ids");
            }
            IDictionary<int, Position> idToPositionMap = new Dictionary<int, Position>();
            foreach (var pos in existingPositions)
            {
                idToPositionMap.Add(pos.PositionId, pos);
            }
            var now = DateTime.Now;
            foreach (var pos in positionsToUpdate)
            {
                var existingPosition = idToPositionMap[pos.PositionId];
                if (pos.AuditSequence != existingPosition.AuditSequence)
                {
                    throw new Exception("Cannot update the record as the new record has a different audit sequence than expected");
                }
                if (!IsSamePosition(pos, existingPosition))
                {
                    PreparePositionForUpdate(pos, existingPosition, actionLogId);
                    _sodPositionDBContext.Positions.Update(pos);
                }
            }

            var modifiedPositions = new List<Position>(insertedPositions);
            modifiedPositions.AddRange(positionsToUpdate);
            return modifiedPositions;
        }

        private IList<Position> PreprocessPositions(IList<Position> positions, int actionLogId)
        {
            // For positions with position ids as 0, we need to check if similar positions exist with quantity zeros
            // If so, they need to be updated
            foreach (var pos in positions)
            {
                if (pos.PositionId == 0)
                {
                    PreparePositionForInsert(pos, actionLogId);
                }
            }
            var existingPositions = _sodPositionDBContext.Positions.GetAll().ToList();
            var posDict = (from existingPos in existingPositions
                           join pos in positions
                           on new
                           {
                               existingPos.FundCode,
                               existingPos.CustodianName,
                               existingPos.Portfolio,
                               existingPos.Security,
                               existingPos.ActualQuantity,
                               existingPos.EntryDate
                           } equals new { pos.FundCode, pos.CustodianName, pos.Portfolio, pos.Security, ActualQuantity = 0M, pos.EntryDate }
                           select new { existingPos.PositionId, pos.FundCode, pos.CustodianName, pos.Portfolio, pos.Security, existingPos.AuditSequence }).ToDictionary(pos => new { pos.FundCode, pos.CustodianName, pos.Portfolio, pos.Security });
            foreach (var pos in positions)
            {
                var lookupKey = new { pos.FundCode, pos.CustodianName, pos.Portfolio, pos.Security };
                if (posDict.ContainsKey(lookupKey))
                {
                    var matchingExistingPos = posDict[lookupKey];
                    pos.PositionId = matchingExistingPos.PositionId;
                    pos.AuditSequence = matchingExistingPos.AuditSequence;
                }
            }
            return positions;
        }

        private Position GetMatchingPosition(Position position)
        {
            return
            _sodPositionDBContext.Positions.Get(new
            {
                FundCode = position.FundCode,
                CustodianName = position.CustodianName,
                StrategyCode = position.Portfolio.ToString(),
                AssetType = position.Security.SecurityType.ToString(),
                BAMSymbol = position.Security.BamSymbol,
                Qty = 0M,
                EntryDate = position.EntryDate
            }).FirstOrDefault();
        }


        private void PreparePositionForInsert(Position pos, int actionLogId)
        {
            DateTime now = DateTime.Now;
            pos.LastModifiedOn = now;
            if (_streamEntryDateMap.ContainsKey(pos.Stream))
            {
                pos.EntryDate = _streamEntryDateMap[pos.Stream];
            }
            else
            {
                throw new Exception("Couldn't find the entryDate corresponding to the given stream");
            }
            pos.CreatedOn = now;
            pos.AuditSequence = 1;
            pos.ActionLogId = actionLogId;
        }

        private IList<Position> InsertPositions(IList<Position> positions, int actionLogId)
        {
            if (positions == null || positions.Count == 0)
            {
                return new List<Position>();
            }
            positions = _sodPositionDBContext.Positions.Save(positions).ToList();
            return positions;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        private void RefreshStreamEntryDateMap()
        {
            try
            {
                IDictionary<string, DateTime> streamEntryDateMap = new Dictionary<string, DateTime>();

                var streamDates = _sodPositionDBContext.Positions.GetAll().Select(x => new { Stream = x.Stream, EntryDate = x.EntryDate }).Distinct();
                foreach (var streamDate in streamDates)
                {
                    if (streamEntryDateMap.ContainsKey(streamDate.Stream))
                    {
                        throw new Exception("Inconsistent data: same stream with different entry dates found");
                    }
                    else
                    {
                        streamEntryDateMap.Add(streamDate.Stream, streamDate.EntryDate);
                    }
                }

                _streamEntryDateMap = streamEntryDateMap;
            }
            catch (Exception exception)
            {
                _streamEntryDateMap.Clear();
                LogException(exception.Message, exception);
            }
        }

        private void PublishLoadedPositions()
        {
            try
            {
                IList<Position> positions;
                using (var tscope = new TransactionScope())
                {
                    var action = GetAction(Constants.PUBLISH_LOADED_POSITIONS_ACTION_NAME, Constants.BAM_ACTION_TYPE);
                    if (action == null)
                    {
                        throw new Exception(
                            $"Couldn't find an action corresponding to action name: {Constants.PUBLISH_LOADED_POSITIONS_ACTION_NAME}, and action type: {Constants.BAM_ACTION_TYPE}");
                    }
                    var latestRecordTime = _sodPositionDBContext.ActionLogs.Get(new { ActionId = action.ActionId }).Select(x => (DateTime?)x.CreatedOn).OrderByDescending(x => x).FirstOrDefault();
                    DateTime now = DateTime.Now;

                    if (latestRecordTime == null)
                    {
                        // This is the first instance. Publish all the positions
                        var positionFilter = "CreatedOn <= @CurrentTime AND AuditSequence = 0";
                        var parameters = new { CurrentTime = now };
                        positions = _sodPositionDBContext.Positions.Get(positionFilter, parameters).ToList();
                    }
                    else
                    {
                        var parameters = new { CurrentTime = now, LatestRecordTime = latestRecordTime };
                        var positionFilter = "CreatedOn > @LatestRecordTime AND CreatedOn < @CurrentTime AND AuditSequence = 0";
                        positions = _sodPositionDBContext.Positions.Get(positionFilter, parameters).ToList();
                    }

                    var originalPositionCount = positions.Count;

                    positions = _accountService.SetAccountAttributes(positions).Cast<Position>().ToList();

                    if (positions.Count != originalPositionCount)
                        _log.Error($"SOD position count after validation has changed from {originalPositionCount} to {positions.Count}");

                    _sodPositionDBContext.ActionLogs.Save(new SodActionLog { ActionId = action.ActionId, ActionDetails = "Publish loaded positions", CreatedOn = now });
                    tscope.Complete();
                }
                // This event needs to be raised on a different thread
                Task.Factory.StartNew(() => RaisePositionEvent(positions, SodPositionLoad));
            }
            catch (Exception exception)
            {
                LogException(exception.Message, exception);
            }
        }

        /// <summary>
        /// Executes the SodPositionUpdated. In case one of the handler fails,
        /// the execution of other handlers doesn't get impacted
        /// </summary>
        /// <param name="positions"></param>
        /// <param name="action">Event to trigger</param>
        private void RaisePositionEvent(IList<Position> positions, Action<IList<Position>> action)
        {
            if (action != null)
            {

                foreach (var handler in action.GetInvocationList().Cast<Action<IList<Position>>>())
                {
                    try
                    {
                        handler(positions);
                    }
                    catch (Exception exception)
                    {
                        LogException(exception.Message, exception);
                    }
                }
            }
        }        
    }
}
