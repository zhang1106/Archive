using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Schedulers;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Trades;
using Bam.Oms.EndPoints.Orders;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.PositionTracker;
using Bam.Oms.RefData;
using Bam.Oms.ShortLocate;
using Bam.Oms.TradeMarker;
using BAM.Infrastructure.Ioc;
using Microsoft.Practices.ObjectBuilder2;
using Newtonsoft.Json;

namespace Bam.Oms.Service.Orders
{
    public class StripedProcessor : IDisposable, IStripedProcessor
    {
        private readonly IPositionTracker _positionTracker;
        private readonly IOrderMarker _orderMarker;
        private readonly IOrderRepository _orderRepository;
        private readonly ITradeRepository _tradeRepository;
        private readonly IEmsRouter _emsRouter;
        private readonly ILocateService _locateService;
        private readonly ILogger _logger;
        private readonly ISettings _settings;
        private readonly IOrderPrepUtility _orderPrepUtility;
        private readonly ISecurityMasterService _securityMasterService;
        private readonly IAccountService _accountService;
        private readonly IPositionRepository _positionRepository;

        private readonly CancellationTokenSource _orderTaskCancellation = new CancellationTokenSource();
        private readonly OrderedTaskScheduler _processorScheduler = new OrderedTaskScheduler();

        private long _totalOrdersProcessed = 0;
        private volatile bool _initialized = true;
        private readonly object _locker = new Object();

        public long TotalOrdersProcessed
        {
            get { return _totalOrdersProcessed; }
            set { _totalOrdersProcessed = value; }
        }

        public HashSet<string> SubscribedSymbols { get; } = new HashSet<string>();

        public Task<IList<IOrder>> UpdateSecurityInfo(IList<IUpdateSecurity> securities)
        {
            return Task.Factory.StartNew<IList<IOrder>>(() =>
            {
                var finalOrdersList = new List<IOrder>();

                try
                {
                    foreach (var securityUpdate in securities)
                    {
                        _logger.Info("Receive security update for:"+securityUpdate.ToString());

                        var orders = _orderRepository.GetAllOrders(o => o.Security.BamSymbol == securityUpdate.BamSymbol).Values.SelectMany(r => r);
                        IList<IBlockTrade> tradesList = new List<IBlockTrade>();

                        var security = securityUpdate as Data.Securities.Security;

                        foreach (var order in orders)
                        {
                            if (!_settings.IsSecurityTypeSupported(securityUpdate.SecurityType))
                                order.OrderStatus = BamOrderStatus.Deleted;

                            if (security != null)
                                order.Security = security;

                            order.TradeCurrency = securityUpdate.TradingCurrency;
                            order.SettlementCurrency = securityUpdate.SettlementCurrency;

                            if (string.IsNullOrEmpty(order.TradeCurrency)) _logger.Error($"Unable to load trading currency for order id {order.ClientOrderId}");
                            if (string.IsNullOrEmpty(order.SettlementCurrency)) _logger.Error($"Unable to load settlement currency for order id {order.ClientOrderId}");

                            var trades = _tradeRepository.GetByClientOrderId(order.ClientOrderId);
                            foreach (var trade in trades)
                            {
                                trade.Security = security;
                                trade.TradeCurrency = securityUpdate.TradingCurrency;
                                tradesList.Add(trade);
                            }
                        }

                        //update positions 
                        var positions = _positionRepository.GetAllPositions().Where(r => r.Security.BamSymbol == securityUpdate.BamSymbol).ToList();
                        foreach (var position in positions)
                        {
                            if (security != null)
                                position.Security = security;
                        }

                        //to notify the UI
                        _tradeRepository.Save(tradesList.Cast<BlockTrade>());
                        _orderRepository.Save(orders.Cast<Order>().ToList());

                        finalOrdersList.AddRange(orders);
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Error during security update {ex.Message} {ex.StackTrace}");
                }

                return finalOrdersList;

            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public event Action<IOrder> OrderStatusChanged;
        public event Action<IList<IOrder>> OrdersStatusChanged;
        public event Action<IBlockTrade> TradeStatusChanged;
        public event Action<IList<IBlockTrade>> TradesStatusChanged;

        public StripedProcessor(IEmsRouter emsRouter, ILocateService locateService, IPositionTracker positionTracker, IOrderMarker orderMarker, 
            IOrderRepository orderRepository, ITradeRepository tradeRepository, ILogger logger, IPositionRepository positionRepository, 
            ISettings settings, IOrderPrepUtility orderPrepUtility, ISecurityMasterService securityMasterService, IAccountService accountService)
        {
            if (orderPrepUtility == null) throw new ArgumentNullException(nameof(orderPrepUtility));
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));

            _logger = logger;
            _positionRepository = positionRepository;
            _locateService = locateService;
            _emsRouter = emsRouter;
            _positionTracker = positionTracker;
            _orderMarker = orderMarker;
            _orderRepository = orderRepository;
            _tradeRepository = tradeRepository;
            _settings = settings;
            _orderPrepUtility = orderPrepUtility;
            _securityMasterService = securityMasterService;
            _accountService = accountService;
        }

        public Task RequestLocate(IOrder order)
        {
            //only permit a re-locate if the order is either partial or completely denied
            if (order.OrderStatus != BamOrderStatus.IncompleteLocate && order.OrderStatus != BamOrderStatus.PendingLocate)
            {
                _logger.Warn($"Unable to request for locate for id {order.ClientOrderId} since state is not {BamOrderStatus.IncompleteLocate} or {BamOrderStatus.PendingLocate};  Current State {order.OrderStatus}");
                return Task.FromResult<object>(null);
            }

            var task = Task.Factory.StartNew(() =>
            {
                var innerCopyOrder = _orderRepository.Get(order.ClientOrderId); //we need to this to ensure the lastest state is being saved
                if (innerCopyOrder != null)
                {
                    innerCopyOrder.OrderStatus = BamOrderStatus.PendingLocate;
                    _orderRepository.Save(innerCopyOrder);

                }
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);

            //this has to be outside the scheduler, or it ends up in a deadlock
            LocateShortForOrdersWrap(new List<IOrder>() { order }); //this doesn't need to be the latest version of the order

            return task;
        }

        public async Task<T> InvokeOnProcessor<T>(Func<T> action)
        {
            return await Task.Factory.StartNew(action, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public bool SetInitialized(bool initialized)
        {
            lock (_locker)
            {
                bool returnValue = _initialized;
                _initialized = initialized;
                if (initialized)
                {
                    Monitor.PulseAll(_locker);
                }
                return returnValue;
            }
        }

        public void AddSubscribedSymbol(string symbol)
        {
            SubscribedSymbols.Add(symbol);
        }

        public async Task<IOrder> GetOrderAsync(string orderId)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return GetOrder(orderId);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public IOrder SaveOrder(IOrder order, string batchId = null)
        {
            if (order.Size <= 0 || order.Side == SideType.Unknown)
            {
                _logger.Warn($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Ignoring an order of zero size or unknown side. Order:{order}.");
                return null;
            }

            Utility.RaiseEvent(order, OrderStatusChanged);
            return _orderRepository.Save((Order)order);
        }

        public async Task<IOrder> SaveOrderAsync(IOrder order, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                if (order.Size <= 0 || order.Side == SideType.Unknown)
                {
                    _logger.Warn($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Ignoring an order of zero size or unknown side. Order:{order}.");
                    return null;
                }
                Utility.RaiseEvent(order, OrderStatusChanged);
                return _orderRepository.Save((Order)order);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public IBlockTrade SaveTrade(IBlockTrade trade, string batchId = null)
        {
            return _tradeRepository.Save((BlockTrade)trade);
        }

        public async Task<IBlockTrade> SaveTradeAsync(IBlockTrade trade, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }

                return _tradeRepository.Save((BlockTrade)trade);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public IOrder DeleteOrder(IOrder order, string batchId = null)
        {
            Utility.RaiseEvent(order, OrderStatusChanged);
            return _orderRepository.Remove((Order)order);
        }

        public async Task<IOrder> DeleteOrderAsync(IOrder order, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                Utility.RaiseEvent(order, OrderStatusChanged);
                return _orderRepository.Remove((Order)order);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public IList<IOrder> SaveOrders(IList<IOrder> orders, string batchId = null)
        {
            Utility.RaiseEvent(orders, OrdersStatusChanged);
            foreach (IOrder order in orders)
            {
                _orderRepository.Save((Order)order);
            }
            return orders;
        }

        public async Task<IList<IOrder>> SaveOrdersAsync(IList<IOrder> orders, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return new List<IOrder>();
                }
                foreach (IOrder order in orders)
                {
                    this.SaveOrder(order, batchId);
                }
                return orders;
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }
        
        public IList<IOrder> RouteOrders(IList<IOrder> orders, string batchId = null)
        {
            try
            {
                var lookup = orders.ToDictionary(o => o.ClientOrderId);
                var latest = orders.Select(o => _orderRepository.Get(o.Key)).Cast<IOrder>().ToList();

                var routable =
                    latest.Where(o => o.OrderStatus == BamOrderStatus.PendingSend && o.RoutedSize > 0).ToList();
                var skipping = orders.Except(routable).ToList();

                foreach (var o in routable)
                {
                    o.TraderLogin = lookup[o.ClientOrderId].TraderLogin;
                    o.TraderId = lookup[o.ClientOrderId].TraderId;
                }

                if (skipping.Any())
                {
                    foreach (var o in skipping)
                    {
                        _logger.Warn("Skip routing order " + JsonConvert.SerializeObject(o));
                    }
                }

                if (routable.Any())
                {
                    routable.ForEach(o => o.OrderStatus = BamOrderStatus.PendingAck);
                    SaveOrders(routable, batchId);

                    return SubmitOrders(routable, batchId);
                }

                _logger.Warn($"[BatchId:{batchId}] No orders to route.");
                return new List<IOrder>();
            }
            catch (AggregateException ae)
            {
                throw ae.Flatten();
            }
        }        

        public async Task<IList<IOrder>> RouteOrdersAsync(IList<IOrder> orders, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (orders == null || !orders.Any() || _orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return RouteOrders(orders, orders.First().BatchId);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public IOrder CancelOrder(IOrder order)
        {
            try
            {
                if (!this.SubscribedSymbols.Contains(order.Security.BamSymbol))
                {
                    return order;
                }

                IOrder originalOrder = GetOrder(order.ClientOrderId);
                if (originalOrder == null)
                {
                    _logger.Warn(
                        $"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId} is unknown to the Gateway. Cancel request ignored.");
                    return order;
                }
                order = originalOrder;

                _logger.Debug($"Cancelling order {order}.");
                switch (originalOrder.OrderStatus)
                {
                    case BamOrderStatus.Deleted:
                        break;
                    case BamOrderStatus.PendingValidation:
                    case BamOrderStatus.Cancelled:
                        order.OrderStatus = BamOrderStatus.Cancelled;
                        break;
                    case BamOrderStatus.PendingSend:
                    case BamOrderStatus.IncompleteLocate:
                    case BamOrderStatus.PendingLocate:
                        order.OrderStatus = BamOrderStatus.Cancelled;
                        ReleaseLocates(new List<IOrder>() { originalOrder });
                        break;
                    case BamOrderStatus.Error:
                    case BamOrderStatus.Filled:
                    case BamOrderStatus.Finalized:
                        _logger.Error($"[BatchId:{order.BatchId},OrderId:{order.ClientOrderId}] Order state is {order.OrderStatus}. Order cannot be cancelled.");
                        break;
                    default:
                        order.OrderStatus = BamOrderStatus.PendingCancel;
                        //IList<string> cancelledOrderIds =
                        //    _emsRouter.CancelOrders(new List<string>() { originalOrder.ClientOrderId });
                        break;
                }

                _positionTracker.ApplyOrderUpdate(order);
                return order;
            }
            catch (Exception ex)
            {
                _logger.Error($"Exception while cancelling order {order}.", ex);
                return order;
            }
            finally
            {
                SaveOrder(order, order.BatchId);
            }
        }

        public async Task<IOrder> CancelOrderAsync(IOrder order)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return CancelOrder(order);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public async Task<IList<IOrder>> CancelOrderAsync(IList<IOrder> orders)
        {
            return await Task.Factory.StartNew(() =>
            {
                IList<IOrder> ordersCancelled = new List<IOrder>();
                foreach (IOrder order in orders)
                {
                    if (_orderTaskCancellation.Token.IsCancellationRequested)
                    {
                        _logger.Info("Cancellation requested. Aborting task...");
                        return ordersCancelled;
                    }
                    IOrder cancelledOrder = CancelOrder(order);
                    if (cancelledOrder != null)
                    {
                        ordersCancelled.Add(cancelledOrder);
                    }
                }
                return ordersCancelled;
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public IList<IOrder> MarkOrder(IOrder order, string batchId = null)
        {
            Interlocked.Increment(ref _totalOrdersProcessed);

            if (order.Size <= 0 || order.Side == SideType.Unknown)
            {
                _logger.Warn($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Ignoring an order of zero size or unknown side. Order:{order}.");
                return new List<IOrder>();
            }

            try
            {
                //_logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] begin marking order:{order}.");
                var positionSet = _positionRepository.Get(
                    new[] { new PositionKey(order.Portfolio, order.Security) })[0];

                IList<IOrder> mkdOrders = _orderMarker.MarkOrder(order, positionSet);
                //_logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] completed marking order:{order}.");

                //_logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] begin position tracking orders:{JsonConvert.SerializeObject(mkdOrders)}.");
                foreach (IOrder mkdOrder in mkdOrders)
                {
                    _positionTracker.ApplyOrderUpdate(mkdOrder);
                }
                //_logger.Info($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] completed position tracking orders:{JsonConvert.SerializeObject(mkdOrders)}.");
                //set the routed size for all these trades
                foreach (var orderToSubmit in mkdOrders.Where(o => o.Side != SideType.SellShort)) //only update routed size for non-shorts, the locates will be batched after this method
                    orderToSubmit.RoutedSize = orderToSubmit.Size;
                return mkdOrders;
            }
            catch (Exception ex)
            {
                _logger.Error($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Error while marking order {order}.", ex);
                throw;
            }
        }

        public async Task<IList<IOrder>> MarkOrderAsync(IList<IOrder> orders, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                List<IOrder> markedOrders = new List<IOrder>();
                foreach (IOrder order in orders)
                {
                    if (_orderTaskCancellation.Token.IsCancellationRequested)
                    {
                        _logger.Info("Cancellation requested. Aborting task...");
                        return markedOrders;
                    }
                    markedOrders.AddRange(MarkOrder(order, batchId));
                }
                return markedOrders;
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public async Task<IList<IOrder>> MarkOrderAsync(IOrder order, string batchId = null)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return new List<IOrder>();
                }
                return MarkOrder(order, batchId);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public async Task RevertOrderAsync(IOrder order, string batchId)
        {
            await Task.Factory.StartNew(() =>
            {
                if (order.Size <= 0 || order.Side == SideType.Unknown)
                {
                    _logger.Warn($"[BatchId:{batchId},OrderId:{order.ClientOrderId}] Ignoring RevertTheoreticalPosition of an order of zero size or unknown side. Order:{order}.");
                    return;
                }

                var copy = (Order)order.Clone();
                copy.OrderStatus = BamOrderStatus.Cancelled;
                _positionTracker.ApplyOrderUpdate(copy);

            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public IPosition TrackTrade(IBlockTrade trade)
        {
            try
            {
                return _positionTracker.ApplyPositionUpdate(trade);
            }
            catch (Exception ex)
            {
                _logger.Error($"[OrderId:{trade.ClientOrderId}] Error while tracking trade {trade}. Exception {1}.", ex);
                throw;
            }
        }

        public async Task<IPosition> TrackTradeAsync(IBlockTrade trade)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return null;
                }
                return TrackTrade(trade);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public IPosition TrackOrder(IOrder order)
        {
            try
            {
                var originalOrder = _orderRepository.Get(order.ClientOrderId);
                if (originalOrder == null)
                {
                    _logger.Info($"[OrderId:{order.ClientOrderId}] Unable to find order in cache, skipping order update");
                    return null;
                }
                originalOrder.OrderStatus = order.OrderStatus;
                return _positionTracker.ApplyOrderUpdate(originalOrder);
            }
            catch (Exception ex)
            {
                _logger.Error($"[OrderId:{order.ClientOrderId}] Error while tracking order {order}.", ex);
                throw;
            }
        }

        public async Task<IList<IOrder>> SetStateAsync(IEnumerable<string> orderIds, BamOrderStatus orderStatus)
        {
            return await Task.Factory.StartNew(() =>
            {
                IList<IOrder> orders = new List<IOrder>();
                foreach (string orderId in orderIds)
                {
                    if (_orderTaskCancellation.Token.IsCancellationRequested)
                    {
                        _logger.Info("Cancellation requested. Aborting task...");
                        return orders;
                    }
                    var originalOrder = _orderRepository.Get(orderId);
                    if (originalOrder == null)
                    {
                        _logger.Error($"[OrderId:{orderId}] Order not found in cache while processing RevertOrder.");
                        _logger.Error(
                            $"[OrderId:{orderId}] Theoretical position may be incorrect because the order was not reverted.");
                        continue;
                    }
                    if (!this.SubscribedSymbols.Contains(originalOrder.Security.BamSymbol))
                    {
                        continue;
                    }
                    originalOrder.OrderStatus = orderStatus;
                    Utility.RaiseEvent(originalOrder, OrderStatusChanged);
                    _orderRepository.Save(originalOrder);
                    orders.Add(originalOrder);
                }
                return orders;
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public async Task<IList<Position>> LoadSODPositionsAsync(IList<Position> sodPositions)
        {
            return await Task.Factory.StartNew(() =>
            {
                List<Position> positions = new List<Position>();
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return positions;
                }
                var stream = sodPositions[0].Stream;
                var orders = _orderRepository.GetAllOrders(o => o.OrderStatus != BamOrderStatus.Error &&
                            SubscribedSymbols.Contains(o.Security.BamSymbol) && 
                            string.Equals(stream, o.Portfolio.OmsStream, StringComparison.InvariantCultureIgnoreCase));
                var trades = _tradeRepository.GetAllTrades(t => SubscribedSymbols.Contains(t.Security.BamSymbol) &&
                            string.Equals(stream, t.Portfolio.OmsStream, StringComparison.InvariantCultureIgnoreCase));

                _positionTracker.ClearPositions(stream, SubscribedSymbols.ToArray());

                positions.AddRange(_positionTracker.LoadSODPositions(sodPositions, orders, trades).Cast<Position>());

                return positions;
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public async Task<IList<Position>> UpdateSODPositionsAsync(IList<Position> sodPositions)
        {
            return await Task.Factory.StartNew(() =>
            {
                List<Position> positions = new List<Position>();
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return positions;
                }
                positions.AddRange(_positionTracker.UpdateSODPositions(sodPositions).Cast<Position>());

                return positions;
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public async Task<IList<Position>> UpdatePositionsAsync(IList<Position> positions)
        {
            return await Task.Factory.StartNew(() =>
            {
                List<Position> positionsReplaced = new List<Position>();
                if (_orderTaskCancellation.Token.IsCancellationRequested)
                {
                    _logger.Info("Cancellation requested. Aborting task...");
                    return positionsReplaced;
                }

                positionsReplaced.AddRange(_positionTracker.UpdatePositions(positions).Cast<Position>());

                return positions;
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public void ProcessOrderUpdate(IReadOnlyList<IOrder> orders)
        {
            try
            {
                Task.Factory.StartNew(() =>
                {
                    Stopwatch sw = Stopwatch.StartNew();
                    if (!_initialized)
                    {
                        lock (_locker)
                        {
                            while (!_initialized)
                            {
                                Monitor.Wait(_locker, 60000);
                            }
                        }
                    }

                    var logMessage = new StringBuilder();
                    foreach (IOrder order in orders)
                    {
                        logMessage.AppendLine($"Order Update From {_settings.EmsName} for -> [BatchId:{order.BatchId},OrderId:{order.ClientOrderId},Status:{order.OrderStatus},Price={order.Price}]");
                    }
                    _logger.Info(logMessage.ToString());

                    _logger.Debug($"Requesting sec data on strip with {SubscribedSymbols.Count} symbols");
                    var securityList = GetMissingSecurities(orders);
                    _logger.Debug($"Completed sec data on strip with {SubscribedSymbols.Count} symbols");

                    var processedOrders = new List<IOrder>();
                    foreach (IOrder order in orders)
                    {
                        try
                        {
                            var existing = _orderRepository.Get(order.Key);

                            if (existing == null) //new order
                            {
                                var refDataSecurity = securityList.FirstOrDefault(r => r.BamSymbol == order.Security.BamSymbol);

                                if (refDataSecurity != null)
                                {
                                    order.Security = (Data.Securities.Security) refDataSecurity;
                                    order.TradeCurrency = order.TradeCurrency ?? refDataSecurity.TradingCurrency;
                                    order.SettlementCurrency = order.SettlementCurrency ?? refDataSecurity.SettlementCurrency;
                                }
                                else
                                    _logger.Error($"[OrderId:{order.ClientOrderId}] Unable to find security with symbol {order.Security.BamSymbol} for new order.");
                            }
                            else
                            {
                                order.Security = existing.Security;
                            }

                            //filter out not equity type
                            var supported = _settings.IsSecurityTypeSupported(order.Security.SecurityType);
                            if (!supported)
                            {
                                _logger.Warn("Security Type is not supported for " + order.ExternalId + " and security type:" + order.Security.SecurityType);
                                continue;
                            }

                            if (existing == null)
                            {
                                //lookup if the trader id
                                _accountService.SetTraderLogin(order);
                            }
                            else
                            {
                                order.Portfolio = existing.Portfolio;
                                order.BatchId = existing.BatchId;
                                order.Security = existing.Security;
                                order.TradeCurrency = order.TradeCurrency ?? existing.TradeCurrency;
                                order.TradeDate = existing.TradeDate;
                                order.Side = existing.Side;
                                order.BatchId = existing.BatchId;
                                order.ComplianceFailures =
                                    existing.ComplianceFailures.Concat(order.ComplianceFailures).ToList();
                                order.Errors = existing.Errors.Concat(order.Errors).ToList();
                                order.ExecutionInstructions = existing.ExecutionInstructions;
                                order.Locate = existing.Locate;
                                order.LocateStatus = existing.LocateStatus;
                                order.Note = existing.Note;
                                order.OriginalOrderId = existing.OriginalOrderId;
                                order.RoutedSize = existing.RoutedSize;
                                order.StatusMessages.AddRange(existing.StatusMessages);
                                order.SettlementCurrency = existing.SettlementCurrency;
                                order.CreatedUser = existing.CreatedUser;

                                foreach (var so in order.StreetOrders)
                                {
                                    so.Portfolio = existing.Portfolio;
                                    so.Security = existing.Security;
                                    so.PrimeBroker = existing.Custodian;
                                    so.TradeDate = existing.TradeDate;
                                    so.Side = existing.Side;
                                }
                                order.CreatedDateTime = existing.CreatedDateTime;

                                //only if the trader has changed, we will look it up
                                if (existing.Trader != order.Trader)
                                    _accountService.SetTraderLogin(order);
                                else
                                {
                                    order.TraderId = existing.TraderId;
                                    order.TraderLogin = existing.TraderLogin;
                                }
                            }

                            var position = _positionTracker.ApplyOrderUpdate(order);
                            this.SaveOrder(order);
                            processedOrders.Add(order);
                            logMessage.AppendLine($"{DateTime.Now} - Order Update From {_settings.EmsName} for -> [BatchId:{order.BatchId},OrderId:{order.ClientOrderId},Status:{order.OrderStatus},Price={order.Price},Position={position.ActualQuantity}]");
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Exception procesing order updates. {order}", ex);
                        }
                    }

                    _logger.Info(logMessage.ToString());
                    //send a service call to the locate service to release any unused inventory
                    var execessLocate =
                        processedOrders.Where(
                            o => (o.OrderStatus == BamOrderStatus.Cancelled || o.OrderStatus == BamOrderStatus.Deleted) && o.Side == SideType.SellShort).ToList();
                    if (execessLocate.Any())
                    {
                        ReleaseLocates(execessLocate);
                    }

                    sw.Stop();
                    _logger.Debug($"Order Update From {_settings.EmsName} Order Update took {sw.ElapsedMilliseconds} ms for {processedOrders.Count} out of {orders.Count()} orders.");
                }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error(
                        $"[BatchId:{orders.First().BatchId}] Exception {ex} while processing order status change {JsonConvert.SerializeObject(orders)}.");
                    return true;
                });
            }
        }

        private void ReleaseLocates(IList<IOrder> allOrders)
        {
            Task.Factory.StartNew(() =>
            {
                var canceledShortOrders = allOrders.Where(r => r.Side == SideType.SellShort).ToList();

                if (!canceledShortOrders.Any()) return;

                _logger.Debug($"Releasing unused locate inventory for {canceledShortOrders.Count} orders");

                var tradeList = new Dictionary<string, IList<IBlockTrade>>();

                foreach (var order in canceledShortOrders)
                    tradeList[order.ClientOrderId] = new List<IBlockTrade>(_tradeRepository.GetByClientOrderId(order.ClientOrderId));

                _locateService.CancelTrades(tradeList);
            }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
        }

        public void ProcessTradeUpdate(IReadOnlyList<IBlockTrade> trades)
        {
            try
            {
                Task.Factory.StartNew(() =>
                {
                    Stopwatch sw = Stopwatch.StartNew();
                    if (!_initialized)
                    {
                        lock (_locker)
                        {
                            while (!_initialized)
                            {
                                Monitor.Wait(_locker, 60000);
                            }
                        }
                    }

                    var logMessage = new StringBuilder();

                    var processedTrades = new List<IBlockTrade>();

                    var securityList = GetMissingSecurities(trades);

                    foreach (IBlockTrade trade in trades)
                    {
                        try
                        {
                            var existing = _orderRepository.Get(trade.ClientOrderId);

                            if (existing == null) //new order
                            {
                                var refDataSecurity = securityList.FirstOrDefault(r => r.BamSymbol == trade.Security.BamSymbol);

                                if (refDataSecurity != null)
                                {
                                    trade.Security = (Data.Securities.Security)refDataSecurity;
                                }
                                else
                                {
                                    _logger.Error($"[OrderId:{trade.ClientOrderId};TradeId{trade.TradeId}] Unable to find security with symbol {trade.Security.BamSymbol} for new trade.");
                                }
                            }
                            else
                            {
                                trade.Security = existing.Security;
                                trade.Portfolio = existing.Portfolio;
                                trade.TradeDate = existing.TradeDate;
                                trade.Trader = existing.Trader;
                                trade.Side = existing.Side;
                            }

                            //filter out not equity type
                            var supported = _settings.IsSecurityTypeSupported(trade.Security.SecurityType);
                            if (!supported)
                            {
                                _logger.Warn("Security Type is not supported for " + trade.ClientOrderId + " and security type:" + trade.Security.SecurityType);
                                continue;
                            }

                            IBlockTrade tradeFromRepo = this.GetTrade(trade.TradeId);
                            if (tradeFromRepo != null)
                            {
                                trade.TradeStatus = trade.TradedQuantity == 0 ? BamTradeStatus.Deleted : BamTradeStatus.Modified;
                                //Mark allocations that do not exist in the updated trade as deleted (set quantity to 0)
                                // n*n algorithm, it is fine as number of allocations is usually in single digits
                                foreach (Allocation allocation in tradeFromRepo.Allocations.Where(allocation => !trade.Allocations.Exists(a => a.AllocationId == allocation.AllocationId)))
                                {
                                    allocation.Quantity = 0;
                                    trade.Allocations.Add(allocation);
                                }
                            }

                            logMessage.AppendLine($"Trade Update From {_settings.EmsName}-> [OrderId:{trade.ClientOrderId},TradeId:{trade.TradeId},Filled:{trade.TradedQuantity},Price={trade.AveragePrice}]");
                            IPosition position = this.TrackTrade(trade);
                            if (position != null)
                            {
                                logMessage.AppendLine(
                                        $"Trade Update From {_settings.EmsName}-> [OrderId:{trade.ClientOrderId},TradeId:{trade.TradeId},Position:{position.ActualQuantity}]");
                            }
                            _tradeRepository.Save((BlockTrade)trade);
                        }
                        catch (Exception ex)
                        {
                            _logger.Error($"Exception procesing order updates. {trade}", ex);
                        }
                        processedTrades.Add(trade);
                    }
                    _logger.Info(logMessage.ToString());
                    Utility.RaiseEvent(processedTrades, TradesStatusChanged);
                    sw.Stop();
                    _logger.Debug($"From {_settings.EmsName} Trades Update took {sw.ElapsedMilliseconds} ms for {processedTrades.Count} out of {trades.Count()} trades. checksum: {trades.Sum(t => t.TradedQuantity)}-{trades.Sum(t => t.AveragePrice)}");
                }, _orderTaskCancellation.Token, TaskCreationOptions.HideScheduler, _processorScheduler);
            }
            catch (AggregateException aex)
            {
                aex.Handle(ex =>
                {
                    _logger.Error($"[OrderId:{trades.First().ClientOrderId},TradeId:{trades.First().TradeId}] Exception while processing trade {trades}.", ex);
                    return true;
                });
            }
        }

        private IOrder GetOrder(string orderId)
        {
            IOrder order = _orderRepository.Get(orderId);
            return order;
        }

        private IBlockTrade GetTrade(string tradeId)
        {
            IBlockTrade trade = _tradeRepository.Get(tradeId);
            return trade;
        }

        private IList<IOrder> SubmitOrders(IList<IOrder> orders, string batchId = null)
        {
            _logger.Info($"[BatchId:{batchId}] Submitting {orders.Count} orders.");
            return _emsRouter.SubmitOrders(orders).ToList();
        }

        private IList<IOrder> LocateShorts(IList<IOrder> markedOrders, string batchId = null)
        {
            _logger.InfoFormat($"[BatchId:{batchId}] Running short locate for batch.");
            try
            {
                //make a sync call to get shorts
                var shortOrders = markedOrders.Where(o => o.Side == SideType.SellShort);
                _logger.InfoFormat($"[BatchId:{batchId}] has {shortOrders.Count()} short orders for locate.");
                var fullyLocatedShortOrders = LocateShortForOrdersWrap(shortOrders);

                //set the routed size for all these trades
                foreach (var orderToSubmit in fullyLocatedShortOrders)
                    orderToSubmit.RoutedSize = orderToSubmit.Size;

                _logger.InfoFormat($"[BatchId:{batchId}] Completed running short locate{0}.");
                return markedOrders;
            }
            catch (Exception ex)
            {
                _logger.Error($"[BatchId:{batchId}] Error while locating shorts for {JsonConvert.SerializeObject(markedOrders)}.", ex);
                throw;
            }
        }

        //TODO: Move this to Short locate proxy/facade
        private IEnumerable<IOrder> LocateShortForOrdersWrap(IEnumerable<IOrder> shortOrders)
        {
            //request short locate, completely filled orders will go downstream
            var shortLocateRequests = shortOrders.Select(s => new LocateRequest(s, s.Custodian));

            if (!shortLocateRequests.Any()) return new List<IOrder>(); //return an empty list

            var locateResponses = _locateService.RequestForInventory(shortLocateRequests);
            return locateResponses;
        }

        private List<IUpdateSecurity> GetSecurities(IList<string> bamSymbols)
        {
            if (bamSymbols.Count == 0)
                return new List<IUpdateSecurity>();

            try
            {
                return _securityMasterService.GetSecurities(bamSymbols);
            }
            catch (Exception ex)
            {
                _logger.Error("Unable to get securities from reference data service", ex);
            }

            return  new List<IUpdateSecurity>();
        }

        private List<IUpdateSecurity> GetMissingSecurities(IReadOnlyList<IOrder> orders)
        {
            var securitiesToLookup = new HashSet<string>();
            foreach (var order in orders)
            {
                if (_orderRepository.Get(order.ClientOrderId) == null)
                    securitiesToLookup.Add(order.Security.BamSymbol);
            }

            return GetSecurities(securitiesToLookup.ToList());
        }

        private List<IUpdateSecurity> GetMissingSecurities(IReadOnlyList<IBlockTrade> trades)
        {
            var securitiesToLookup = new HashSet<string>();
            foreach (var trade in trades)
            {
                if (_orderRepository.Get(trade.ClientOrderId) == null)
                    securitiesToLookup.Add(trade.Security.BamSymbol);
            }

            return GetSecurities(securitiesToLookup.ToList());
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _orderTaskCancellation.Cancel();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~StripedProcessor() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }

        #endregion
    }
}
