﻿using System.Collections.Generic;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.TradeMarker
{
    public interface IOrderMarker
    {
        IList<IOrder> MarkOrder(IOrder order, IPositionSet positionSet);
        IList<IOrder> MarkOrder(IEnumerable<KeyValuePair<IOrder, IPositionSet>> items);
    }
}
