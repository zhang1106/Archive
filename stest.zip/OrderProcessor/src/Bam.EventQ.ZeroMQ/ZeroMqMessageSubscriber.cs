﻿using System;
using Bam.EventQ.Transport;
using NetMQ;
using NetMQ.Sockets;

namespace Bam.EventQ.ZeroMQ
{
    public class ZeroMqMessageSubscriber : IMessageSubscriber, IDisposable
    {
        private readonly SubscriberSocket _socket;

        public ZeroMqMessageSubscriber()
        {
            Name = "ZeroMQ Subscriber";
            _socket = new SubscriberSocket();
            _socket.Options.ReceiveHighWatermark = 0; // unlimited
        }

        public string Name { get; }

        public void Connect(string endpoint)
        {
            _socket.Connect(endpoint);
        }

        public void SubscribeAll()
        {
            _socket.SubscribeToAnyTopic();
        }

        public void Subscribe(int topic)
        {
            var buffer = new byte[4];
            topic.CopyToBuffer(buffer, 0);
            _socket.Subscribe(buffer);
        }

        public bool TryReceive(byte[] buffer, int index, out int received, out int topic, TimeSpan timeout)
        {
        skipMessage:

            var topicMsg = new Msg();
            var bodyMsg = new Msg();
            topicMsg.InitEmpty();
            bodyMsg.InitEmpty();

            try
            {
                if (_socket.TryReceive(ref topicMsg, timeout))
                {
                    if (topicMsg.HasMore)
                    {
                        _socket.Receive(ref bodyMsg);

                        bool more = bodyMsg.HasMore;
                        while (more)
                        {
                            _socket.SkipFrame(out more);
                        }
                    }

                    // this message is malformed
                    if (!topicMsg.HasMore || bodyMsg.HasMore)
                    {
                        // avoid recursion here because it generates
                        // more stack frames (slow) and might crash
                        // the client with a stack overflow if too
                        // many invalid messages are received
                        goto skipMessage;
                    }

                    topic = topicMsg.Data.ToInt32(topicMsg.Offset);
                    received = bodyMsg.Size;
                    Buffer.BlockCopy(bodyMsg.Data, bodyMsg.Offset, buffer, index, received);
                    return true;
                }
            }
            finally
            {
                topicMsg.Close();
                bodyMsg.Close();
            }

            topic = -1;
            received = -1;
            return false;
        }

        public void Dispose()
        {
            _socket.Dispose();
        }
    }
}
