﻿using System.Collections.Generic;

namespace Bam.EventQ.Workflow
{
    public interface IWorkflow
    {
        void Reset(long sequence, bool isReplay);
    }

    public interface IWorkflow<in TIn> : IWorkflow
    {
        void Execute(TIn input);
    }

    public interface IWorkflow<in TIn, out TOut> : IWorkflow<TIn>
    {
        IReadOnlyList<TOut> Result { get; }
    }
}
