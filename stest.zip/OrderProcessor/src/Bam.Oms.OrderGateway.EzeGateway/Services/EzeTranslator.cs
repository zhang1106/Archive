﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Snapshot;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;
using Bam.Oms.OrderGateway.EzeGateway.Models.Snapshot;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.OrderProcessor;

namespace Bam.Oms.OrderGateway.EzeGateway.Services
{
    public class EzeTranslator : IEzeTranslator, ISnapshotRecoverable<SplitStrategyOrdersSnapshot>
    {
        public ILogger Logger { get; set; }

        private readonly IReferenceDataService _referenceDataService;
        private readonly Dictionary<string, string> _userDefinedFields;
        private readonly Dictionary<string, string> _brokerMpids;
        private readonly Dictionary<long, string> _splitStrategyOrders;

        public EzeTranslator(
            IReferenceDataService referenceDataService,
            Dictionary<string, string> userDefinedFields,
            Dictionary<string, string> brokerMpids)
        {
            if (referenceDataService == null) throw new ArgumentNullException(nameof(referenceDataService));
            if (userDefinedFields == null) throw new ArgumentNullException(nameof(userDefinedFields));
            if (brokerMpids == null) throw new ArgumentNullException(nameof(brokerMpids));
            _referenceDataService = referenceDataService;
            _userDefinedFields = userDefinedFields;
            _brokerMpids = brokerMpids;
            _splitStrategyOrders = new Dictionary<long, string>();
        }
        
        public string GetTradeManager(StageEmsOrderBatch.StageEmsOrderLineItem bamOrder)
        {
            string custodian;
            if (_referenceDataService.TryGetBroker(bamOrder.PrimeBrokerAllocation.First().Key, out custodian))
            {
                return LookupManagerCode(Portfolio.Parse(bamOrder.Portfolio), custodian);
            }

            Logger?.LogError($"Cannot look up custodian '{bamOrder.PrimeBrokerAllocation.First()}'.");
            return null;
        }

        private string LookupManagerCode(Portfolio strategy, string custodian)
        {
            if (strategy == null)
            {
                Logger?.LogError($"Unable to find manager code recursively for custodian '{custodian}'.");
                return null;
            }

            string managerCode;
            if (_referenceDataService.TryGetManagerCode(strategy.Key, custodian, out managerCode))
            {
                return managerCode;
            }

            if (strategy.Strategy == "MACRO" || strategy.SubStrategy == "MACRO")
            {
                return LookupManagerCode(strategy.RemoveTrailingStrategy(), custodian);
            }

            return null;
        }

        public string GetActualStrategy(string externalOrderId, string strategy)
        {
            long orderId;
            string splitStrategy;
            if (long.TryParse(externalOrderId, out orderId) &&
                _splitStrategyOrders.TryGetValue(orderId, out splitStrategy))
            {
                return splitStrategy;
            }

            return strategy;
        }

        public Trade ToEzeOrder(StageEmsOrderBatch.StageEmsOrderLineItem bamOrder)
        {
            string trader;
            if (!_referenceDataService.TryGetTraderEmsCode(bamOrder.TraderId, EmsSystem.Eze, out trader))
            {
                //todo: figure out defaulting here
                Logger?.LogError($"Unable to find EZE trader code for trader id {bamOrder.TraderId}");
            }

            StrategyAllocationRule rule;
            var portfolio = Portfolio.Parse(bamOrder.Portfolio);
            if (_referenceDataService.TryGetStrategyAllocationRule(portfolio, out rule))
            {
                _splitStrategyOrders[bamOrder.ExternalOrderId] = bamOrder.Portfolio;
            }

            var trade = new Trade
            {
                ExternalBlockID = bamOrder.ExternalOrderId.ToString(),
                Trader = trader,
                TraderCode = trader,
                Action = ConvertAction(bamOrder.Side),
                Symbol = bamOrder.Symbol,
                Quantity = bamOrder.Quantity,
                Note = bamOrder.Note,
                LimitPrice = bamOrder.Price.Equals(decimal.Zero) ? (decimal?)null : bamOrder.Price,
                Duration = bamOrder.Price.Equals(decimal.Zero) ? Duration.MKT : Duration.LMT,
                ComplianceCheck = true,
                Manager = GetTradeManager(bamOrder),
            };

            if (bamOrder.FundAllocationOverride.Count == 1)
            {
                int fundId = bamOrder.FundAllocationOverride.First().Key;
                string fund;
                if (!_referenceDataService.TryGetFund(fundId, out fund))
                {
                    Logger?.LogError($"Received order for unknown fund {fundId}");
                    fund = "UNKNOWN";
                }

                var allocations = new List<Allocation>();
                foreach (var pb in bamOrder.PrimeBrokerAllocation)
                {
                    string custodian;
                    if (!_referenceDataService.TryGetBroker(pb.Key, out custodian))
                    {
                        Logger?.LogError($"Received order for unknown custodian {pb.Key}");
                        custodian = "UNKNOWN";
                    }

                    allocations.Add(new Allocation
                    {
                        Account = $"{bamOrder.Portfolio} {custodian.Substring(0, 2)}-{fund}",
                        Quantity = pb.Value
                    });
                }

                trade.allocations = allocations.ToArray();
            }

            var userDefinedFields = new List<string>();

            AddUserDefinedField("Urgency", bamOrder.Urgency, userDefinedFields);

            if (bamOrder.Side == Side.Short)
            {
                if (bamOrder.SecurityRequiresLocate)
                    SetShortUserDefinedFields(bamOrder, trade, userDefinedFields);
                else
                {
                    trade.ManagerNote = "Manual Override, no locate required for index/basket";
                    AddUserDefinedField("IsFullyLocated", 1, userDefinedFields);
                }
            }

            //add any key value pair execution instructions
            foreach (var inst in bamOrder.ExecutionInstructions)
                AddUserDefinedField(inst.Key, inst.Value, userDefinedFields);

            trade.UserDefinedFields = userDefinedFields.ToArray();

            return trade;
        }

        private void AddUserDefinedField(string key, object value, List<string> userDefinedFields)
        {
            string udfKey;
            if (_userDefinedFields.TryGetValue(key, out udfKey))
            {
                userDefinedFields.Add($"{udfKey} = {value}");
            }
            else
            {
                Logger?.LogWarning($"Unable to find UDF mapping for {key}");
            }
        }

        private void SetShortUserDefinedFields(StageEmsOrderBatch.StageEmsOrderLineItem bamOrder, Trade trade, List<string> udfs)
        {
            if (bamOrder.StageOrderLocateInfo != null && bamOrder.StageOrderLocateInfo.Any())
            {
                trade.ManagerNote = "OGLoc:Done;";

                var locateBrokers = new HashSet<string>();

                var avgRate = bamOrder.StageOrderLocateInfo.Sum(r => r.Quantity) == 0 ? 0 : bamOrder.StageOrderLocateInfo.Sum(r => r.Quantity * r.Rate) / bamOrder.StageOrderLocateInfo.Sum(r => r.Quantity);
                AddUserDefinedField("ActualBorrowRate", avgRate, udfs);
                AddUserDefinedField("IsFullyLocated", 1, udfs);

                foreach (var locateInfo in bamOrder.StageOrderLocateInfo)
                {
                    string custodian;
                    if (!_referenceDataService.TryGetBroker(locateInfo.PrimeBrokerId, out custodian))
                    {
                        Logger?.LogError($"Locate with unknown broker {locateInfo.PrimeBrokerId}");
                        custodian = "UNKNOWN";
                    }

                    if (locateInfo.Quantity <= 0) continue;
                    trade.ManagerNote += $"{custodian}:{locateInfo.AssignmentId},Qty={locateInfo.Quantity},Rate={locateInfo.Rate},Time={locateInfo.ApprovalTime:HH:mm:ss};";
                    locateBrokers.Add(custodian);
                }

                //create comma delimited broker list
                if (locateBrokers.Any())
                {
                    var brokerList = new StringBuilder();
                    foreach (var broker in locateBrokers)
                    {
                        string overrideMpid;
                        brokerList.Append(_brokerMpids.TryGetValue(broker, out overrideMpid) ? overrideMpid : broker);
                        brokerList.Append(",");
                    }

                    brokerList.Remove(brokerList.Length - 1, 1);

                    AddUserDefinedField("LocateBrokers", brokerList, udfs);
                }
            }
        }
        
        public TradeAction ConvertAction(Side side)
        {
            switch (side)
            {
                case Side.Buy:
                    return TradeAction.Buy;
                case Side.Cover:
                    return TradeAction.Cover;
                case Side.Sell:
                    return TradeAction.Sell;
                case Side.Short:
                    return TradeAction.Short;
                default:
                    throw new ArgumentOutOfRangeException(nameof(side), "Must be Buy, Sell, Cover, or Short");
            }
        }

        SplitStrategyOrdersSnapshot ISnapshotRecoverable<SplitStrategyOrdersSnapshot>.Persist()
        {
            var snapshot = new SplitStrategyOrdersSnapshot();
            _splitStrategyOrders.CopyTo(snapshot.Items);
            return snapshot;
        }

        void ISnapshotRecoverable<SplitStrategyOrdersSnapshot>.Recover(SplitStrategyOrdersSnapshot snapshot)
        {
            snapshot.Items.CopyTo(_splitStrategyOrders);
        }
    }
}
