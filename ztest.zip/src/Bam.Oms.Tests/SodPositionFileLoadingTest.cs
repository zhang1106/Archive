﻿using System.IO;
using System.Reflection;
using NUnit.Framework;
using Bam.Oms.SodPosition.Svc.File;

namespace Bam.Oms.Tests
{
   [TestFixture]
    public class SodPositionFileLoadingTest
    {
        private const string DataFile1 = "FLEX_SOD_FILE_20160113.csv";
        private const string DataFile2 = "FLEX_SOD_FILE_20160114.csv";
        private string _testpath;
        private string _testArchiveFile;

        [TestFixtureSetUp]
        public void Setup()
        {
            var assm = Assembly.GetExecutingAssembly().CodeBase;
            var split = assm.Split('/');
            var path = split[3] + @"\";
            for (var i = 4; i < split.Length - 1; i++) 
            {
                path = Path.Combine(path, split[i]);
            }
            _testpath = Path.Combine(path, "TestData");
        }
       
        [Test]
        public void TestArchiveFile()
        {
            var input = Path.Combine(_testpath, DataFile1);
            var loading = new FileLoading(_testpath, null, null);
            //
            _testArchiveFile = loading.ArchiveFile(Path.Combine(_testpath, DataFile1));
            //
            Assert.IsTrue(File.Exists(_testArchiveFile));
            //move back
            File.Move(_testArchiveFile, Path.Combine(_testpath, DataFile1));
        }
        [Test]
        public void VerifyParsingPositionFile()
        {
            // arrange
            var loading = new FileLoading(_testpath, null, null);
            // act
            var unit = loading.GetPositions(Path.Combine(_testpath, DataFile2));

            // assert
            Assert.IsNotNull(unit);
            Assert.That(unit.Count, Is.EqualTo(9));
        }
    }
}
