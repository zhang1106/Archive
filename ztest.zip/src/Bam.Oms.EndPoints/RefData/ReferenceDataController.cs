﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.RestApi;
using Bam.Oms.EndPoints.Http;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.EndPoints.RefData
{
    public class ReferenceDataController : BaseController, IReferenceDataController
    {
        private readonly IAccountService _accountService;

        public ReferenceDataController(IHostConfiguration hostConfiguration, ILogger logger, IAccountService accountService)
            : base(hostConfiguration, logger)
        {
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));
            _accountService = accountService;
        }

        public IList<Portfolio> GetPortfolios()
        {
            return _accountService.GetPortfolioByPmCode();
        }

        public IList<Portfolio> GetPortfolios(string key)
        {
            return _accountService.GetPortfolioByPmCode(key);
        }

        public string GetManagerCode(string portfolio, string broker)
        {
            return _accountService.GetManagerCode(Portfolio.Parse(portfolio), null, broker);
        }

        public void RefreshBorrowRates()
        {
            //only exists in OG A for now
        }
    }
}