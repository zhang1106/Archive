﻿using Google.Protobuf;

namespace Bam.EventQ.Solace.Protobuf
{
    public class ProtobufSolaceSerializer : ISolaceMessageSerializer<IMessage>
    {
        private readonly bool _includeMessageType;

        public ProtobufSolaceSerializer(bool includeMessageType = false)
        {
            _includeMessageType = includeMessageType;
        }

        public void Serialize(SolaceSystems.Solclient.Messaging.IMessage target, IMessage payload)
        {
            target.BinaryAttachment = payload.ToByteArray();
            target.HttpContentType = "application/octet-stream";

            if (_includeMessageType)
            {
                if (target.UserPropertyMap == null)
                {
                    target.UserPropertyMap = target.CreateUserPropertyMap();
                }

                target.UserPropertyMap.AddString("Message-Type", payload.Descriptor.FullName);
            }
        }
    }
}
