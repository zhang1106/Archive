﻿using System;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;
using SolaceSystems.Solclient.Messaging;

namespace Bam.EventQ.Solace
{
    public class SolaceQueueItemHandler<TItem, TMsg> : IQueueItemHandler<PipelineQueueItem<TItem>>, IDisposable
        where TMsg : class, TItem
    {
        private readonly IMessage[] _batch;
        private readonly ISolaceTopicProvider<TMsg> _topicProvider;
        private readonly ISolaceMessageSerializer<TMsg> _messageSerializer;
        private readonly bool _skipReplay;
        private readonly SolacePublisher _publisher;

        private int _index;
        private ILogger _logger;

        public SolaceQueueItemHandler(SolaceContextWrapper contextWrapper,
            ISolaceTopicProvider<TMsg> topicProvider) 
            : this(contextWrapper, topicProvider, null)
        {

        }

        public SolaceQueueItemHandler(SolaceContextWrapper contextWrapper,
            ISolaceTopicProvider<TMsg> topicProvider, bool skipReplay = true)
            : this(contextWrapper, topicProvider, null, skipReplay)
        {

        }

        public SolaceQueueItemHandler(SolaceContextWrapper contextWrapper, 
            ISolaceTopicProvider<TMsg> topicProvider, 
            ISolaceMessageSerializer<TMsg> messageSerializer,
            bool skipReplay = true)
        {
            _topicProvider = topicProvider;
            _messageSerializer = messageSerializer;
            _skipReplay = skipReplay;
            _batch = new IMessage[SolacePublisher.MaxBatchSize];
            _publisher = new SolacePublisher(contextWrapper);
            _publisher.Connect();
        }

        public ILogger Logger
        {
            get { return _logger; }
            set
            {
                _logger = value;
                _publisher.Logger = value;
            }
        }

        public void Dispose()
        {
            _publisher.Dispose();
        }

        public void Handle(PipelineQueueItem<TItem> item, long sequence, bool endOfBatch)
        {
            if (item.IsValid && (!_skipReplay || _skipReplay && !item.IsReplay))
            {
                if (_messageSerializer != null)
                {
                    var payload = item.Payload as TMsg;
                    if (payload != null)
                    {
                        var msg = _batch[_index++] = ContextFactory.Instance.CreateMessage();
                        msg.Destination = ContextFactory.Instance.CreateTopic(
                            _topicProvider.GetTopic(payload));
                        _messageSerializer.Serialize(msg, payload);
                    }
                }
                else
                {
                    // TODO: populate topic
                    var msg = _batch[_index++] = ContextFactory.Instance.CreateMessage();
                    msg.UserData = new byte[item.Length];
                    Buffer.BlockCopy(msg.BinaryAttachment, 0, item.Buffer.Array, 
                        item.Buffer.Offset, item.Length);
                }
            }

            if (endOfBatch && _index > 0 || 
                _index == SolacePublisher.MaxBatchSize)
            {
                int sent = _publisher.Publish(_batch, 0, _index);
                Array.Clear(_batch, 0, _index);

                if (sent != _index)
                {
                    Logger?.LogError($"Failed to publish {_index - sent} items (total: {_index})");
                }

                _index = 0;
            }
        }
    }
}
