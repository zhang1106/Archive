﻿using System;
using System.Linq.Expressions;
using Bam.Oms.Messaging;
using Microsoft.AspNet.SignalR.Client;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class SignalRClientTests
    {

        [Test]
        public void VerifyApplyFilterInvokedHubProxy()
        {
            // arrange
            Expression<Action<ISignalRHub>> testExp = null;
            ParameterString[] unit = null;

            var mockHub = new Mock<ISignalRHub>();
            mockHub.Setup(r => r.AddFilter(It.IsAny<ParameterString[]>())).Callback<ParameterString[]>(s => unit = s);

            var testHubProxy  = new Mock<IHubProxy<ISignalRHub, ISignalRClient<TestSubject>>>();
            testHubProxy.Setup(p => p.CallAsync(It.IsAny<Expression<Action<ISignalRHub>>>())).Callback<Expression<Action<ISignalRHub>>>(expression => { testExp = expression; });

            var testHub = new SignalRClientTest(new Mock<IConnection>().Object, testHubProxy.Object);
            var subject = new TestSubject() {Subject = "MATH"};

            // act
            testHub.ApplyFilter(new[] {new ParameterString("Subject", subject, typeof (TestSubject))});

            // assert
            var del = testExp.Compile();
            del.Invoke(mockHub.Object);

            Assert.That(unit, Is.Not.Null);
            Assert.That(unit[0].Property, Is.EqualTo("Subject"));
            Assert.That(unit[0].Value, Is.EqualTo(JsonConvert.SerializeObject(subject)));
            Assert.That(unit[0].Type, Is.EqualTo(typeof(TestSubject).AssemblyQualifiedName));
        }

        //todo, not sure how to/whether or not to test the subsriptions


        public class SignalRClientTest : SignalRClient<TestSubject>
        {
            public SignalRClientTest(IConnection connection, IHubProxy<ISignalRHub, ISignalRClient<TestSubject>> hubProxy) 
                : base(connection, hubProxy)
            {
            }
        }

        public class TestSubject
        {
            public string Subject { get; set; }

            public override bool Equals(object obj)
            {
                var sub = obj as TestSubject;

                return sub?.Subject.Equals(this.Subject) ?? false;
            }

            public override int GetHashCode()
            {
                return Subject.GetHashCode();
            }
        }
    }
}