﻿using System.Web.Http.ExceptionHandling;
using log4net;

namespace Bam.Oms.EndPoints.Http
{
    public class GlobalExceptionHandler : ExceptionHandler
    {
        private readonly ILog _logger;

        public GlobalExceptionHandler(ILog logger)
        {
            _logger = logger;
        }

        public override void Handle(ExceptionHandlerContext context)
        {
            _logger.Error(context.Request.RequestUri, context.Exception);
            base.Handle(context);
        }
    }
}
