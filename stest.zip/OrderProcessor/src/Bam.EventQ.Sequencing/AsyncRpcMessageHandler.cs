﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Hosting;
using Bam.EventQ.Pipeline;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Sequencing
{
    public class AsyncRpcMessageHandler<TIn> : QueueItemProducerBase<PipelineQueueItem<IMessage>>,
        IQueueItemHandler<PipelineQueueItem<IMessage>>, IDisposable
        where TIn : class, IMessage
    {
        private readonly IAsyncMessageRpcClient<TIn> _client;
        private readonly IQueueMessageDispatcher _dispatcher;
        private readonly bool _skipReplay;
        private readonly IBackgroundWorker _worker;
        private readonly ConcurrentQueue<TIn> _pending;
        private readonly ManualResetEvent _workAvailable;
        private readonly byte[] _cloneBuffer;

        public AsyncRpcMessageHandler(IAsyncMessageRpcClient<TIn> client,
            IQueueMessageDispatcher dispatcher, bool skipReplay = true)
        {
            _client = client;
            _dispatcher = dispatcher;
            _skipReplay = skipReplay;
            _cloneBuffer = new byte[1024*1024];
            _pending = new ConcurrentQueue<TIn>();
            _workAvailable = new ManualResetEvent(false);
            _worker = BackgroundWorkerFactory.Current.Create($"{typeof(TIn).GetDisplayName()} Async RPC");
            _worker.Start(ProcessRequests);
        }

        public void Handle(PipelineQueueItem<IMessage> item, long sequence, bool endOfBatch)
        {
            if (_skipReplay && item.IsReplay || !item.IsValid)
                return;

            var msg = item.Payload as TIn;
            if (msg != null)
            {
                int length = MessageSerializer.Current.Serialize(msg, _cloneBuffer, 0);
                var clone = (TIn) MessageSerializer.Current.Deserialize(_cloneBuffer, 0, length);
                _pending.Enqueue(clone);
                _workAvailable.Set();
            }
        }

        public void Dispose()
        {
            _worker.Dispose();
        }

        private void ProcessRequests(CancellationToken cancellationToken)
        {
            var started = new[] {cancellationToken.WaitHandle, Started};
            if (WaitHandle.WaitAny(started) == 0)
                return;

            var batch = new List<IMessage>();
            bool conflate = typeof(IBatchMessage).IsAssignableFrom(typeof(TIn));
            var conflation = new BatchMessageConflation();

            var handles = new[] {cancellationToken.WaitHandle, _workAvailable};
            while (_pending.Count > 0 && !cancellationToken.IsCancellationRequested ||
                   WaitHandle.WaitAny(handles) != 0)
            {
                TIn item;
                if (!_pending.TryDequeue(out item))
                    continue;

                if (conflate)
                {
                    batch.Clear();
                    batch.Add(item);
                    while (_pending.TryDequeue(out item))
                    {
                        batch.Add(item);
                    }

                    conflation.Conflate(batch);
                    item = (TIn)batch[0];
                }

                try
                {
                    var result = _client.Invoke(item, cancellationToken)
                        .ConfigureAwait(false).GetAwaiter().GetResult();
                    _dispatcher.Dispatch(Queue, result);
                }
                catch (Exception ex)
                {
                    Logger?.LogError($"Request for {typeof(TIn).GetDisplayName()} failed", ex);
                }
            }
        }
    }
}
