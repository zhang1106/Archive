﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Reflection;
using System.IO;
using System.Runtime.Remoting;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Orders;
using NUnit.Framework;
using Moq;
using Bam.Oms.EndPoints.Eze;
using Bam.Oms.OrderRouting.EZE;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Data.Trades;
using Bam.Oms.Persistence.Journal;
using Bam.Oms.Persistence.Trades;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.RefData;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;
using Castle.Components.DictionaryAdapter;
using EzeEi = Eze.Common.Integration;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class EzeSubscriptionTests
    {
        [Test]
        [TestCase("2016-10-06T11:55:11.637", "Central Standard Time", true, "2016-10-06T16:55:11.637")]
        [TestCase("2016-12-06T11:55:11.637", "Central Standard Time", false, "2016-12-06T17:55:11.637")]
        public void TestTimeConversion(string time, string zone, bool dayligntsaving, string expectedUTC)
        {
            var centralZone = TimeZoneInfo.FindSystemTimeZoneById(zone);
           
            var ct = DateTime.Parse(time);
            var isDaylightSaving = centralZone.IsDaylightSavingTime(ct);
            var convert = MappingAgent.ConvertToUtc(ct, zone);
            var utc = DateTime.Parse(expectedUTC);
            
            Assert.IsTrue(dayligntsaving == isDaylightSaving);
            Assert.IsTrue(convert == utc);
        }

        [Test]
        public void TestTradeSettlementDate()
        {
            var settlementDate = Convert.ToDateTime("2016-9-30");
            var allocation = new Allocation() {SettleDate = settlementDate };
            var blockTrade = new BlockTrade {Allocations = new EditableList<Allocation>() {allocation}};
            var trade = Utility.GetAllocations(blockTrade);
            Assert.IsTrue(trade.Any());
            Assert.IsTrue(trade[0].SettleDate == settlementDate);
        }

        [Test]
        public void TestTradesData()
        {
            //read file
            var Assm = Assembly.GetExecutingAssembly().CodeBase;
            var split = Assm.Split('/');
            var path = split[3] + @"\";
            for (var i = 4; i < split.Length - 1; i++)
                path = Path.Combine(path, split[i]);

            string testpath = Path.Combine(path, "TestData");
            using (
                var fStream = System.IO.File.Open(Path.Combine(testpath, "EzeTrades.json"), FileMode.Open, FileAccess.Read,
                    FileShare.Read))
            {
                //setup
                TextReader tr = new StreamReader(fStream);
                var data = tr.ReadToEnd();
                ITranslator translator = new Translator();
                var trades = translator.GetTrades(data);
                //
                //mockup
                var cache = new Mock<INotificationCache>();
                cache.Setup(c => c.GetOrderId(It.IsAny<OrderIndexKey>()))
                   .Returns((string)null);

                var journal = new Mock<IEventJournal>();
                journal.Setup(j => j.TruncateAsync()).Returns(Task.FromResult(0));
                journal.Setup(j => j.AppendAsync(It.IsAny<object>())).Returns(Task.FromResult(0));
                journal.Setup(j => j.RetrieveAsync()).Returns(Task.FromResult<IReadOnlyList<KeyValuePair<DateTime, object>>>(new KeyValuePair<DateTime, object>[] { }));
                var journalFactory = new Mock<IEventJournalFactory>();
                journalFactory.Setup(f => f.Create(It.IsAny<string>())).Returns(journal.Object);

                var clientOrderIdRepository = new ClientOrderIdRepository(new Mock<ILogger>().Object, journalFactory.Object);

                var acctSvc = new Mock<IAccountService>();
                acctSvc.Setup(a => a.GetPortfolioByStrategy(It.IsAny<string>())).Returns(new Portfolio("JELL", "Tech"));
                var mappingAgent = new MappingAgent(acctSvc.Object, cache.Object, clientOrderIdRepository, new Mock<ITradeRepository>().Object, new Mock<IOrderRepository>().Object,  new Mock<ILogger>().Object);

                IList<Order> ogOrders;
                IList<BlockTrade> ogTrades;
                //
                //execute
                foreach (var trade in trades)
                {
                    mappingAgent.Translate(trade, out ogOrders, out ogTrades);
                }

                Assert.IsTrue(trades.Any());
            }
            //
        }

        [Test]
        public void TestPwdStrip()
        {
            const string tradeUpdate =
              "{\"trade\":null,\"requestIdentifier\":null,\"userCredentials\":{\"userName\":\"sa\",\"Password\":\"xxxx\"},\"Trades\":[{\"allocations\":[{\"allocationLots\":[{\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"ExternalLotID\":null,\"LotID\":0,\"AllocID\":0,\"TradeID\":\"20160610000U\",\"AllocationState\":0,\"Filled\":0.0,\"Quantity\":462.0000000000,\"AnalystCode\":\"\",\"Strategy1\":\"\",\"Strategy2\":\"\",\"AveragePrice\":41.1500000000,\"TotalCommission\":0.0,\"TotalFees\":0.0,\"AccruedInt\":0.0}],\"TradeID\":\"20160610000U\",\"MessageType\":\"Update\",\"AllocID\":0,\"ExternalBlockID\":null,\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"AllocationState\":0,\"Account\":\"DODD-CONSUMER CS-AMF\",\"Filled\":0.0,\"Quantity\":462.0000000000,\"Custodian\":\"CSPB\",\"AveragePrice\":41.1500000000,\"TotalFees\":0.0,\"TotalCommission\":0.0,\"NetMoney\":0.0000000000,\"SpotRate\":1.0,\"AccuredInterest\":0.0,\"ToCurrency\":\"USD\",\"FromCurrency\":\"USD\",\"DirectedBroker\":\"\",\"BrokerOfCredit\":\"\",\"StepOutBroker\":\"\",\"StepOutCommissions\":\"\",\"Strategy\":null,\"RTBlotterTimeStamp\":\"0001-01-01T00:00:00\",\"Broker\":null,\"OrderID\":\"\"},{\"allocationLots\":[{\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"ExternalLotID\":null,\"LotID\":0,\"AllocID\":0,\"TradeID\":\"20160610000U\",\"AllocationState\":0,\"Filled\":0.0,\"Quantity\":1538.0000000000,\"AnalystCode\":\"\",\"Strategy1\":\"\",\"Strategy2\":\"\",\"AveragePrice\":41.1500000000,\"TotalCommission\":0.0,\"TotalFees\":0.0,\"AccruedInt\":0.0}],\"TradeID\":\"20160610000U\",\"MessageType\":\"Update\",\"AllocID\":0,\"ExternalBlockID\":null,\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"AllocationState\":0,\"Account\":\"DODD-CONSUMER CS-ALMF\",\"Filled\":0.0,\"Quantity\":1538.0000000000,\"Custodian\":\"CSPB\",\"AveragePrice\":41.1500000000,\"TotalFees\":0.0,\"TotalCommission\":0.0,\"NetMoney\":0.0000000000,\"SpotRate\":1.0,\"AccuredInterest\":0.0,\"ToCurrency\":\"USD\",\"FromCurrency\":\"USD\",\"DirectedBroker\":\"\",\"BrokerOfCredit\":\"\",\"StepOutBroker\":\"\",\"StepOutCommissions\":\"\",\"Strategy\":null,\"RTBlotterTimeStamp\":\"0001-01-01T00:00:00\",\"Broker\":null,\"OrderID\":\"\"}],\"orders\":null,\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"TradeId\":\"20160610000U\",\"OriginalTradeId\":\"20160610000U\",\"TradeIndex\":\"2016-06-10T08:26:11.2\",\"Action\":0,\"Quantity\":2000.0,\"Symbol\":\"BK\",\"TraderCode\":null,\"Manager\":\"DC1\",\"TradeDate\":\"2016-06-10T00:00:00\",\"SettleDate\":\"2016-06-15T00:00:00\",\"ExternalListID\":null,\"Duration\":0,\"LimitPrice\":0.0,\"TimeInForce\":\"*\",\"ComplianceCheck\":false,\"TradeEntrySource\":\"NewTrade\",\"Note\":\"test\",\"EnableAutoEx\":false,\"TradeAlpha2\":\"\",\"Trader\":\"AH\",\"ManagerNote\":null,\"ServicingClass\":null,\"RTBlotterTimeStamp\":\"2016-06-10T08:55:35.487\",\"UserDefinedFields\":[\"Bloomberg Symbol=BK US Equity\"],\"AvgPrice\":0.0,\"Committed\":0.0,\"Done\":0.0,\"Leaves\":2000.0,\"Status\":\"NEW\",\"State\":\"T\"}]}";
            const string expected =
                "{\"trade\":null,\"requestIdentifier\":null,\"userCredentials\":{\"userName\":\"sa\",\"password\":\"\"},\"Trades\":[{\"allocations\":[{\"allocationLots\":[{\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"ExternalLotID\":null,\"LotID\":0,\"AllocID\":0,\"TradeID\":\"20160610000U\",\"AllocationState\":0,\"Filled\":0.0,\"Quantity\":462.0000000000,\"AnalystCode\":\"\",\"Strategy1\":\"\",\"Strategy2\":\"\",\"AveragePrice\":41.1500000000,\"TotalCommission\":0.0,\"TotalFees\":0.0,\"AccruedInt\":0.0}],\"TradeID\":\"20160610000U\",\"MessageType\":\"Update\",\"AllocID\":0,\"ExternalBlockID\":null,\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"AllocationState\":0,\"Account\":\"DODD-CONSUMER CS-AMF\",\"Filled\":0.0,\"Quantity\":462.0000000000,\"Custodian\":\"CSPB\",\"AveragePrice\":41.1500000000,\"TotalFees\":0.0,\"TotalCommission\":0.0,\"NetMoney\":0.0000000000,\"SpotRate\":1.0,\"AccuredInterest\":0.0,\"ToCurrency\":\"USD\",\"FromCurrency\":\"USD\",\"DirectedBroker\":\"\",\"BrokerOfCredit\":\"\",\"StepOutBroker\":\"\",\"StepOutCommissions\":\"\",\"Strategy\":null,\"RTBlotterTimeStamp\":\"0001-01-01T00:00:00\",\"Broker\":null,\"OrderID\":\"\"},{\"allocationLots\":[{\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"ExternalLotID\":null,\"LotID\":0,\"AllocID\":0,\"TradeID\":\"20160610000U\",\"AllocationState\":0,\"Filled\":0.0,\"Quantity\":1538.0000000000,\"AnalystCode\":\"\",\"Strategy1\":\"\",\"Strategy2\":\"\",\"AveragePrice\":41.1500000000,\"TotalCommission\":0.0,\"TotalFees\":0.0,\"AccruedInt\":0.0}],\"TradeID\":\"20160610000U\",\"MessageType\":\"Update\",\"AllocID\":0,\"ExternalBlockID\":null,\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"AllocationState\":0,\"Account\":\"DODD-CONSUMER CS-ALMF\",\"Filled\":0.0,\"Quantity\":1538.0000000000,\"Custodian\":\"CSPB\",\"AveragePrice\":41.1500000000,\"TotalFees\":0.0,\"TotalCommission\":0.0,\"NetMoney\":0.0000000000,\"SpotRate\":1.0,\"AccuredInterest\":0.0,\"ToCurrency\":\"USD\",\"FromCurrency\":\"USD\",\"DirectedBroker\":\"\",\"BrokerOfCredit\":\"\",\"StepOutBroker\":\"\",\"StepOutCommissions\":\"\",\"Strategy\":null,\"RTBlotterTimeStamp\":\"0001-01-01T00:00:00\",\"Broker\":null,\"OrderID\":\"\"}],\"orders\":null,\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"TradeId\":\"20160610000U\",\"OriginalTradeId\":\"20160610000U\",\"TradeIndex\":\"2016-06-10T08:26:11.2\",\"Action\":0,\"Quantity\":2000.0,\"Symbol\":\"BK\",\"TraderCode\":null,\"Manager\":\"DC1\",\"TradeDate\":\"2016-06-10T00:00:00\",\"SettleDate\":\"2016-06-15T00:00:00\",\"ExternalListID\":null,\"Duration\":0,\"LimitPrice\":0.0,\"TimeInForce\":\"*\",\"ComplianceCheck\":false,\"TradeEntrySource\":\"NewTrade\",\"Note\":\"test\",\"EnableAutoEx\":false,\"TradeAlpha2\":\"\",\"Trader\":\"AH\",\"ManagerNote\":null,\"ServicingClass\":null,\"RTBlotterTimeStamp\":\"2016-06-10T08:55:35.487\",\"UserDefinedFields\":[\"Bloomberg Symbol=BK US Equity\"],\"AvgPrice\":0.0,\"Committed\":0.0,\"Done\":0.0,\"Leaves\":2000.0,\"Status\":\"NEW\",\"State\":\"T\"}]}";

            var stripped = PublishCaptureController.StripPassword(tradeUpdate);

            Assert.IsTrue(stripped==expected);
        }

        [Test]
        public void TestTranslateTrades()
        {
            const string tradeUpdate =
                "{\"trade\":null,\"requestIdentifier\":null,\"userCredentials\":{},\"Trades\":[{\"allocations\":[{\"allocationLots\":[{\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"ExternalLotID\":null,\"LotID\":0,\"AllocID\":0,\"TradeID\":\"20160610000U\",\"AllocationState\":0,\"Filled\":0.0,\"Quantity\":462.0000000000,\"AnalystCode\":\"\",\"Strategy1\":\"\",\"Strategy2\":\"\",\"AveragePrice\":41.1500000000,\"TotalCommission\":0.0,\"TotalFees\":0.0,\"AccruedInt\":0.0}],\"TradeID\":\"20160610000U\",\"MessageType\":\"Update\",\"AllocID\":0,\"ExternalBlockID\":null,\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"AllocationState\":0,\"Account\":\"DODD-CONSUMER CS-AMF\",\"Filled\":0.0,\"Quantity\":462.0000000000,\"Custodian\":\"CSPB\",\"AveragePrice\":41.1500000000,\"TotalFees\":0.0,\"TotalCommission\":0.0,\"NetMoney\":0.0000000000,\"SpotRate\":1.0,\"AccuredInterest\":0.0,\"ToCurrency\":\"USD\",\"FromCurrency\":\"USD\",\"DirectedBroker\":\"\",\"BrokerOfCredit\":\"\",\"StepOutBroker\":\"\",\"StepOutCommissions\":\"\",\"Strategy\":null,\"RTBlotterTimeStamp\":\"0001-01-01T00:00:00\",\"Broker\":null,\"OrderID\":\"\"},{\"allocationLots\":[{\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"ExternalLotID\":null,\"LotID\":0,\"AllocID\":0,\"TradeID\":\"20160610000U\",\"AllocationState\":0,\"Filled\":0.0,\"Quantity\":1538.0000000000,\"AnalystCode\":\"\",\"Strategy1\":\"\",\"Strategy2\":\"\",\"AveragePrice\":41.1500000000,\"TotalCommission\":0.0,\"TotalFees\":0.0,\"AccruedInt\":0.0}],\"TradeID\":\"20160610000U\",\"MessageType\":\"Update\",\"AllocID\":0,\"ExternalBlockID\":null,\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"AllocationState\":0,\"Account\":\"DODD-CONSUMER CS-ALMF\",\"Filled\":0.0,\"Quantity\":1538.0000000000,\"Custodian\":\"CSPB\",\"AveragePrice\":41.1500000000,\"TotalFees\":0.0,\"TotalCommission\":0.0,\"NetMoney\":0.0000000000,\"SpotRate\":1.0,\"AccuredInterest\":0.0,\"ToCurrency\":\"USD\",\"FromCurrency\":\"USD\",\"DirectedBroker\":\"\",\"BrokerOfCredit\":\"\",\"StepOutBroker\":\"\",\"StepOutCommissions\":\"\",\"Strategy\":null,\"RTBlotterTimeStamp\":\"0001-01-01T00:00:00\",\"Broker\":null,\"OrderID\":\"\"}],\"orders\":null,\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"TradeId\":\"20160610000U\",\"OriginalTradeId\":\"20160610000U\",\"TradeIndex\":\"2016-06-10T08:26:11.2\",\"Action\":0,\"Quantity\":2000.0,\"Symbol\":\"BK\",\"TraderCode\":null,\"Manager\":\"DC1\",\"TradeDate\":\"2016-06-10T00:00:00\",\"SettleDate\":\"2016-06-15T00:00:00\",\"ExternalListID\":null,\"Duration\":0,\"LimitPrice\":0.0,\"TimeInForce\":\"*\",\"ComplianceCheck\":false,\"TradeEntrySource\":\"NewTrade\",\"Note\":\"test\",\"EnableAutoEx\":false,\"TradeAlpha2\":\"\",\"Trader\":\"AH\",\"ManagerNote\":null,\"ServicingClass\":null,\"RTBlotterTimeStamp\":\"2016-06-10T08:55:35.487\",\"UserDefinedFields\":[\"Bloomberg Symbol=BK US Equity\"],\"AvgPrice\":0.0,\"Committed\":0.0,\"Done\":0.0,\"Leaves\":2000.0,\"Status\":\"NEW\",\"State\":\"T\"}]}";
            ITranslator translator = new Translator();

            var ary = translator.GetTrades(tradeUpdate);
            Assert.IsTrue(ary.Count == 1);
            Assert.IsTrue(ary[0].Symbol=="BK");
            Assert.IsTrue(ary[0].Allocations.Count == 2);
        }

        [Test]
        public void TestTranslateAllocations()
        {
            const string allocations = "{\"allocation\":null,\"requestIdentifier\":null,\"userCredentials\":{},\"AllocationList\":null,\"AllocationListByTrade\":[{\"TradeId\":\"20160610000U\",\"Allocations\":[{\"allocationLots\":[{\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"ExternalLotID\":null,\"LotID\":0,\"AllocID\":0,\"TradeID\":\"20160610000U\",\"AllocationState\":0,\"Filled\":0.0,\"Quantity\":513.0,\"AnalystCode\":\"\",\"Strategy1\":\"\",\"Strategy2\":\"\",\"AveragePrice\":41.1500000000,\"TotalCommission\":0.0,\"TotalFees\":0.0,\"AccruedInt\":0.0}],\"TradeID\":\"20160610000U\",\"MessageType\":\"Update\",\"AllocID\":0,\"ExternalBlockID\":null,\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"AllocationState\":0,\"Account\":\"DODD-CONSUMER CS-AMF\",\"Filled\":0.0,\"Quantity\":513.0,\"Custodian\":\"GSCO\",\"AveragePrice\":41.1500000000,\"TotalFees\":0.0,\"TotalCommission\":0.0,\"NetMoney\":0.0000000000,\"SpotRate\":1.0,\"AccuredInterest\":0.0,\"ToCurrency\":\"USD\",\"FromCurrency\":\"USD\",\"DirectedBroker\":\"\",\"BrokerOfCredit\":\"\",\"StepOutBroker\":\"\",\"StepOutCommissions\":\"\",\"Strategy\":null,\"RTBlotterTimeStamp\":\"0001-01-01T00:00:00\",\"Broker\":null,\"OrderID\":\"\"},{\"allocationLots\":[{\"ExternalBlockID\":null,\"MessageType\":\"Update\",\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"ExternalLotID\":null,\"LotID\":0,\"AllocID\":0,\"TradeID\":\"20160610000U\",\"AllocationState\":0,\"Filled\":0.0,\"Quantity\":1487.0,\"AnalystCode\":\"\",\"Strategy1\":\"\",\"Strategy2\":\"\",\"AveragePrice\":41.1500000000,\"TotalCommission\":0.0,\"TotalFees\":0.0,\"AccruedInt\":0.0}],\"TradeID\":\"20160610000U\",\"MessageType\":\"Update\",\"AllocID\":0,\"ExternalBlockID\":null,\"ExternalOrderID\":null,\"ExternalAllocID\":null,\"AllocationState\":0,\"Account\":\"DODD-CONSUMER CS-ALMF\",\"Filled\":0.0,\"Quantity\":1487.0,\"Custodian\":\"GSCO\",\"AveragePrice\":41.1500000000,\"TotalFees\":0.0,\"TotalCommission\":0.0,\"NetMoney\":0.0000000000,\"SpotRate\":1.0,\"AccuredInterest\":0.0,\"ToCurrency\":\"USD\",\"FromCurrency\":\"USD\",\"DirectedBroker\":\"\",\"BrokerOfCredit\":\"\",\"StepOutBroker\":\"\",\"StepOutCommissions\":\"\",\"Strategy\":null,\"RTBlotterTimeStamp\":\"0001-01-01T00:00:00\",\"Broker\":null,\"OrderID\":\"\"}]}]}";
            ITranslator translator = new Translator();
            var ary = translator.GetAllocations(allocations);

            Assert.IsTrue(ary.Count == 2);
            Assert.IsTrue(ary[0].TradeID == "20160610000U");
            Assert.IsTrue(ary[1].TradeID == "20160610000U");
        }
        
       [Test]
        public void TestNotificationCache()
       {
            var orderRepo = new Mock<IOrderRepository>();
            orderRepo.Setup(o => o.Save(It.IsAny<Order>())).Returns(new Order());

            var cache = new NotificationCache(orderRepo.Object);
            var key = new OrderIndexKey("tradeid", "strategy", "symbol" );
            cache.AddToOrderIdIndex(new Order() {ClientOrderId = "tradeid", ExternalId= "tradeid", Portfolio=new Portfolio("strategy"), Security=new Security() {BamSymbol="symbol"} });
            var gkey = new OrderIndexKey("tradeid", "strategy", "symbol" );

            var trade = new EzeEi.Trade() {TradeId = "20160610000U" };
            cache.AddEzeTrades(new List<EzeEi.Trade>() {trade});

            Assert.NotNull(cache.GetOrderId(gkey));
            Assert.IsNull(cache.GetOrderId(new OrderIndexKey()));
            Assert.NotNull(cache.GetTrade("20160610000U"));
            Assert.IsNull(cache.GetTrade("xxx"));
        }

        [Test]
        [TestCase("NEW", "M", BamOrderStatus.New)]
        [TestCase("OPEN", "M", BamOrderStatus.Working)]
        [TestCase("OPEN", "T", BamOrderStatus.Working)]
        [TestCase("PARTIAL", "T", BamOrderStatus.Error)]
        [TestCase("DONE", "T", BamOrderStatus.Filled)]
        [TestCase("DONE", "A", BamOrderStatus.Finalized)]

        public void TestMappingSinglePmCreation(string status, string state, BamOrderStatus bStatus)
        {
            //set up
            var allocations = new EzeEi.Allocation[]
           {
                new EzeEi.Allocation(){Account="JACO-TECH GS-AMF", Filled = 20, AveragePrice = 141, Custodian = "GSCO", TotalCommission = 0.61m, TotalFees = .0m, Strategy = "JACO-TECH", TradeID = "20160502000X",},
                new EzeEi.Allocation(){Account="JACO-TECH JP-ALMF",Filled = 100,AveragePrice = 141,Custodian = "JMMC",TotalCommission = 3.03m,Strategy = "JACO-TECH",TotalFees = .0m,TradeID = "20160502000X",},
                new EzeEi.Allocation(){Account="JACO-TECH JP-AMF",Filled = 80,AveragePrice = 141,Custodian = "JMMC",TotalCommission = 2.42m,TotalFees = .0m,Strategy = "JACO-TECH",TradeID = "20160502000X",},
           };
            var trade = new EzeEi.Trade(){TradeId = "20160502000X",Action = EzeEi.TradeAction.Buy,Quantity = 2000,Symbol = "IBM",Allocations = allocations.ToList(),ExternalBlockID = "20160613124603102D8B0",Status = status,State = state};

            //mockup
            var cache = new Mock<INotificationCache>();
            cache.Setup(c => c.GetOrderId(It.IsAny<OrderIndexKey>()))
               .Returns((string)null);
            cache.Setup(c => c.GetOrdersByEzeTradeId(It.IsAny<string>()))
                .Returns(new Dictionary<string, IOrder>());

            var journal = new Mock<IEventJournal>();
            journal.Setup(j => j.TruncateAsync()).Returns(Task.FromResult(0));
            journal.Setup(j => j.AppendAsync(It.IsAny<object>())).Returns(Task.FromResult(0));
            journal.Setup(j => j.RetrieveAsync()).Returns(Task.FromResult<IReadOnlyList<KeyValuePair<DateTime, object>>>(new KeyValuePair<DateTime, object>[] { }));
            var journalFactory = new Mock<IEventJournalFactory>();
            journalFactory.Setup(f => f.Create(It.IsAny<string>())).Returns(journal.Object);

            var clientOrderIdRepository = new ClientOrderIdRepository(new Mock<ILogger>().Object, journalFactory.Object);
            
            var orderRepository = new Mock<IOrderRepository>();
            orderRepository.Setup(o => o.Get(It.IsAny<string>())).Returns(new Order());
 
            var acctSvc = new Mock<IAccountService>();
            acctSvc.Setup(a => a.GetPortfolioByStrategy(It.IsAny<string>())).Returns(new Portfolio("JELL", "Tech"));

            var mappingAgent = new MappingAgent(acctSvc.Object, cache.Object, clientOrderIdRepository, new Mock<ITradeRepository>().Object, orderRepository.Object,   new Mock<ILogger>().Object);
            

            IList< Order> ogOrders;
            IList<BlockTrade> ogTrades;

            //execute
            mappingAgent.Translate(trade, out ogOrders, out ogTrades);

            //assert
            Assert.NotNull(ogOrders);
            Assert.NotNull(ogTrades);
            Assert.IsTrue(ogOrders.Count == 1);
            Assert.IsTrue(ogTrades.Count == 1);
            Assert.IsTrue(ogOrders[0].OrderStatus == bStatus);
            //assert order id is from eze external id field
            Assert.IsTrue(ogOrders[0].ClientOrderId == "20160613124603102D8B0");
        }

        [Test]
        public void TestMappingMultiPmCreation()
        {
            //set up
            var allocations = new EzeEi.Allocation[]
            {
                new EzeEi.Allocation() {Account = "JELL-TECH GS-AMF",  Filled = 20, AveragePrice = 141, Custodian = "GSCO", TotalCommission = 0.61m, TotalFees = .0m, Strategy = "JELL-TECH", TradeID = "20160502000X",},
                new EzeEi.Allocation() {Account = "JELL-TECH GS-ALMF", Filled = 100, AveragePrice = 141, Custodian = "GSCO", TotalCommission = 3.03m, Strategy = "JELL-TECH", TotalFees = .0m, TradeID = "20160502000X",},
                new EzeEi.Allocation() {Account = "JACO-TECH JP-ALMF", Filled = 100, AveragePrice = 141, Custodian = "JMMC", TotalCommission = 3.03m, Strategy = "JACO-TECH", TotalFees = .0m, TradeID = "20160502000X",},
                new EzeEi.Allocation() {Account = "JACO-TECH JP-AMF", Filled = 80, AveragePrice = 141, Custodian = "JMMC", TotalCommission = 2.42m, TotalFees = .0m, Strategy = "JACO-TECH", TradeID = "20160502000X",},
            };

            var trade = new EzeEi.Trade() {TradeId = "20160502000X", ExternalBlockID="12345", Action = EzeEi.TradeAction.Buy, Quantity = 2000, Symbol = "IBM", Status = "Proposed", Allocations = allocations.ToList()};


            //mockup
            var cache = new Mock<INotificationCache>();

            cache.Setup(c => c.GetOrderId(It.IsAny<OrderIndexKey>()))
               .Returns((string)null);
            cache.Setup(c => c.GetOrdersByEzeTradeId(It.IsAny<string>()))
              .Returns(new Dictionary<string, IOrder>());

            var journal = new Mock<IEventJournal>();
            journal.Setup(j => j.TruncateAsync()).Returns(Task.FromResult(0));
            journal.Setup(j => j.AppendAsync(It.IsAny<object>())).Returns(Task.FromResult(0));
            journal.Setup(j => j.RetrieveAsync()).Returns(Task.FromResult<IReadOnlyList<KeyValuePair<DateTime, object>>>(new KeyValuePair<DateTime, object>[] { }));

            var journalFactory = new Mock<IEventJournalFactory>();
            journalFactory.Setup(f => f.Create(It.IsAny<string>())).Returns(journal.Object);

            var clientOrderIdRepository = new ClientOrderIdRepository(new Mock<ILogger>().Object, journalFactory.Object);

            var acctSvc = new Mock<IAccountService>();
            acctSvc.Setup(a => a.GetPortfolioByStrategy(It.IsAny<string>())).Returns( new Portfolio("JELL", "Tech"));
 
            var mappingAgent = new MappingAgent(acctSvc.Object,cache.Object, clientOrderIdRepository, new Mock<ITradeRepository>().Object, 
                new Mock<IOrderRepository>().Object,  new Mock<ILogger>().Object);

            IList<Order> ogOrders;
            IList<BlockTrade> ogTrades;

            //execute
            mappingAgent.Translate(trade, out ogOrders, out ogTrades);

            //assert
            Assert.NotNull(ogOrders);
            Assert.NotNull(ogTrades);
            Assert.IsTrue(ogOrders.Count == 2);
            Assert.IsTrue(ogTrades.Count == 2);
        }

      
    }
}
