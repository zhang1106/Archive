﻿using System;

namespace Bam.EventQ.Transport
{
    public interface IRpcClient
    {
        bool TryInvoke(string inquiry, byte[] payload, out byte[] result);
        bool TryInvoke(string inquiry, byte[] payload, TimeSpan timeout, out byte[] result);
    }
}
