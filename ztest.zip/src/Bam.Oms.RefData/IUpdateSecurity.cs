﻿using Bam.Oms.Data.Securities;

namespace Bam.Oms.RefData
{
    public interface IUpdateSecurity : ISecurity
    {
        string SettlementCurrency { get; }
        string UnderlyingCurrency { get; }
        string TradingCurrency { get; set; }
    }
}