﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public class QuantityDescendingComparer : IComparer<OrderAllocation>
    {
        public int Compare(OrderAllocation x, OrderAllocation y)
        {
            return y.Quantity.CompareTo(x.Quantity);
        }

        public static readonly QuantityDescendingComparer Instance = new QuantityDescendingComparer();
    }
}
