﻿using System;
using System.Runtime.CompilerServices;
using Bam.EventQ.Transport;
using NetMQ;
using NetMQ.Sockets;

namespace Bam.EventQ.ZeroMQ
{
    public class ZeroMqRpcClient : IRpcClient, IDisposable
    {
        private readonly string _endpoint;
        private RequestSocket _socket;

        public ZeroMqRpcClient(string endpoint)
        {
            _endpoint = endpoint;
            _socket = new RequestSocket(endpoint);
        }

        public bool TryInvoke(string inquiry, byte[] payload, out byte[] result)
        {
            return TryInvoke(inquiry, payload, TimeSpan.FromMinutes(2), out result);
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public bool TryInvoke(string inquiry, byte[] payload, TimeSpan timeout, out byte[] result)
        {
            result = null;

            var request = new NetMQMessage(2);
            request.Append(inquiry);
            request.Append(payload);
            if (!_socket.TrySendMultipartMessage(timeout, request))
                return false;

            var response = new NetMQMessage(1);
            if (!_socket.TryReceiveMultipartMessage(timeout, ref response, 1))
            {
                _socket.Dispose();
                _socket = new RequestSocket(_endpoint);
                return false;
            }

            result = response.First.ToByteArray();
            return true;
        }

        public void Dispose()
        {
            _socket.Dispose();
        }
    }
}
