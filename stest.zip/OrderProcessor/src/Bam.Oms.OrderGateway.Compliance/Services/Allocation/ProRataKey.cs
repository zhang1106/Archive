﻿using System;
using Bam.Oms.OrderGateway.Infrastructure;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public struct ProRataKey : IEquatable<ProRataKey>
    {
        public bool Equals(ProRataKey other)
        {
            return Equals(Portfolio, other.Portfolio) && FundId == other.FundId;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is ProRataKey && Equals((ProRataKey) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return ((Portfolio?.GetHashCode() ?? 0)*397) ^ FundId;
            }
        }

        public static bool operator ==(ProRataKey left, ProRataKey right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(ProRataKey left, ProRataKey right)
        {
            return !left.Equals(right);
        }

        public Portfolio Portfolio { get; }
        public int FundId { get; }

        public ProRataKey(Portfolio portfolio, int fundId)
        {
            Portfolio = portfolio;
            FundId = fundId;
        }
    }
}
