﻿using System;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public struct ComplianceGroupKey : IEquatable<ComplianceGroupKey>
    {
        private readonly int _hashCode;

        public ComplianceGroupKey(string complianceGroup, string symbol)
        {
            ComplianceGroup = complianceGroup != null ? string.Intern(complianceGroup.ToUpper()) : null;
            Symbol = string.Intern(symbol.ToUpper());

            unchecked
            {
                _hashCode = 
                    ((ComplianceGroup != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(ComplianceGroup) : 0) * 397) ^
                    (Symbol != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(Symbol) : 0);
            }
        }

        public string ComplianceGroup { get; }
        public string Symbol { get; }

        public bool Equals(ComplianceGroupKey other)
        {
            return ReferenceEquals(other.ComplianceGroup, ComplianceGroup) &&
                   ReferenceEquals(other.Symbol, Symbol);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is ComplianceGroupKey && Equals((ComplianceGroupKey) obj);
        }

        public override int GetHashCode()
        {
            return _hashCode;
        }

        public static bool operator ==(ComplianceGroupKey left, ComplianceGroupKey right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(ComplianceGroupKey left, ComplianceGroupKey right)
        {
            return !left.Equals(right);
        }     

        public override string ToString()
        {
            return $"{Symbol}@{ComplianceGroup}";
        }
    }
}
