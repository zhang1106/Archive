﻿using System;

namespace Bam.Oms.OrderGateway.Compliance.Model
{
    public struct AggUnitKey : IEquatable<AggUnitKey>
    {
        private readonly int _hashCode;

        public AggUnitKey(string aggUnit, string symbol)
        {
            AggregationUnit = aggUnit != null ? string.Intern(aggUnit.ToUpper()) : null;
            Symbol = string.Intern(symbol.ToUpper());

            unchecked
            {
                _hashCode = 
                    ((AggregationUnit != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(AggregationUnit) : 0) * 397) ^
                    (Symbol != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(Symbol) : 0);
            }
        }

        public string AggregationUnit { get; }
        public string Symbol { get; }

        public bool Equals(AggUnitKey other)
        {
            return ReferenceEquals(other.AggregationUnit, AggregationUnit) &&
                   ReferenceEquals(other.Symbol, Symbol);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is AggUnitKey && Equals((AggUnitKey) obj);
        }

        public override int GetHashCode()
        {
            return _hashCode;
        }

        public static bool operator ==(AggUnitKey left, AggUnitKey right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(AggUnitKey left, AggUnitKey right)
        {
            return !left.Equals(right);
        }

        public override string ToString()
        {
            return $"{Symbol}@{AggregationUnit}";
        }
    }
}
