﻿namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public enum OrderUrgency
    {
        Low,
        Medium,
        High,
        Manual,
        Vwap
    }
}
