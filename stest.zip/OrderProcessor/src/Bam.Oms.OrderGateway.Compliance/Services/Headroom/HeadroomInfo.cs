﻿using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Headroom
{
    public struct HeadroomInfo
    {
        public Side Side { get; set; }
        public bool IsDead { get; set; }
        public bool IsOmni { get; set; }
        public long TotalQuantity { get; set; }
        public long OpeningQuantity { get; set; }
        public long ClosingQuantity { get; set; }
        public long FilledQuantity { get; set; }
    }
}
