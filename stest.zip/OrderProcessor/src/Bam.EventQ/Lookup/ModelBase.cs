﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Bam.EventQ.Lookup
{
    public abstract class ModelBase<TEvent> : INotifyPropertyChanged, INotifyPropertyChanging, IEventSource<TEvent>
    {
        protected void NotifyPropertyChanging([CallerMemberName] string propertyName = null)
        {
            PropertyChanging?.Invoke(this, new PropertyChangingEventArgs(propertyName));
        }

        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public event PropertyChangingEventHandler PropertyChanging;

        IModelEventHandler<TEvent> IEventSource<TEvent>.EventHandler
        {
            get { return EventHandler; }
            set { EventHandler = value; }
        }

        protected void Publish(TEvent @event)
        {
            EventHandler?.Handle(@event);
        }

        protected virtual IModelEventHandler<TEvent> EventHandler { get; set; }
    }
}
