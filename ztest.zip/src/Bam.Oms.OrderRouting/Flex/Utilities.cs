﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Trades;
using Ft;
using Google.Protobuf.Collections;
using log4net;
using Newtonsoft.Json;

namespace Bam.Oms.OrderRouting
{
    public static class Utilities
    {
        private static readonly ILog _logger = LogManager.GetLogger("Bam.Oms.OrderRouting.Utilities");
        public static BamOrderStatus ConvertStatus(Ft.OrderUpdateResponse flexOrder)
        {
            if (flexOrder.FinalizationStatus == FinalizationStatus.FINALIZED)
                return BamOrderStatus.Finalized;

            switch (flexOrder.Status)
            {
                case OrderStatus.STAGED: return BamOrderStatus.New;
                case OrderStatus.TRADABLE:
                    {
                        if (flexOrder.StreetOrders != null && flexOrder.StreetOrders.Any())
                        {
                            return BamOrderStatus.Working;
                        }
                        return BamOrderStatus.New;
                    }
                case OrderStatus.REJECTED: return BamOrderStatus.Error;
                case OrderStatus.FILLED: return BamOrderStatus.Filled;
                case OrderStatus.PARTIALLY_FILLED: return BamOrderStatus.Working;
                case OrderStatus.COMPLIANCE_FAILED: return BamOrderStatus.Error;
                case OrderStatus.CANCELLED: return BamOrderStatus.Cancelled;
                default:
                    //not sure about stages
                    _logger.ErrorFormat("Not matching status for the Flex trade status {0}.  Setting status to New", flexOrder.Status);
                    return BamOrderStatus.New;
            }
        }

        public static IBlockTrade Parse(OrderUpdateResponse response)
        {
            IBlockTrade blockTrade = new BlockTrade()
            {
                TradeId = response.OrderId,
                ClientOrderId = response.OrderId,
                isFinalized = (Ft.FinalizationStatus.FINALIZED == response.FinalizationStatus),
                Status = (Ft.FinalizationStatus.FINALIZED == response.FinalizationStatus) ? BamOrderStatus.Finalized.ToString() : BamOrderStatus.Working.ToString(),
                TradedQuantity = Convert.ToDecimal(response.FilledQuantity),
                AveragePrice = Convert.ToDecimal(response.WeightedAvgPrice),
                FxRate = 1.0m, // Default
                TradeCurrency = "USD",
                BaseCurrency = "USD",
                TradeTimeStamp = DateTime.UtcNow,
                DataSource = "FLEX",
                TradeStatus = Convert.ToDecimal(response.FilledQuantity) == 0 && (Ft.FinalizationStatus.FINALIZED == response.FinalizationStatus) ? BamTradeStatus.Deleted : BamTradeStatus.New,
            };


            foreach (StreetOrderUpdateResponse streetOrder in response.StreetOrders)
            {
                foreach (StreetOrderAllocationUpdateResponse alloc in streetOrder.Allocations)
                {
                    var trade = new Allocation();

                    trade.Fund = alloc.Fund;
                    trade.PrimeBroker = alloc.PrimeBroker;
                    trade.CounterParty = streetOrder.ExecutingBroker;
                    if (blockTrade.Portfolio == null)
                    {
                        blockTrade.Portfolio = (Portfolio)Portfolio.Parse(alloc.PositionGroup);
                    }
                    trade.PrimeBrokerAccount = ""; //TODO: Lookup PB Account from Reference Data Service
                    trade.AllocationId = $"{response.OrderId}-{streetOrder.OrderId}-{alloc.Fund}-{alloc.PrimeBroker}";
                    trade.ParentTradeId = blockTrade.TradeId;

                    trade.SettleDate = DateTime.ParseExact(streetOrder.SettlementDate, "MM/dd/yy",
                                CultureInfo.InvariantCulture);
                    trade.Quantity = Convert.ToDecimal(alloc.FilledQuantity);
                    trade.AveragePrice = Convert.ToDecimal(streetOrder.WeightedAvgPrice);
                    trade.Commissions = new Data.Trades.Fee[]
                    {
                                new Data.Trades.Fee()
                                {
                                    Currency = "USD",
                                    Name = "Commission",
                                    Rate = Convert.ToDecimal(alloc.Commissions),
                                    RateType = RateType.Fee
                                }
                    };
                    trade.Fees = ParseFees(alloc.Fees);                   
                    blockTrade.Allocations.Add(trade);
                }
            }

            return blockTrade;
        }

        public static StreetOrder[] ParseStreetOrders(OrderUpdateResponse orderUpdateResponse)
        {
            List<StreetOrder> streetOrders = new List<StreetOrder>();
            var logMessage = new StringBuilder();
            foreach (StreetOrderUpdateResponse streetOrder in orderUpdateResponse.StreetOrders)
            {
                logMessage.AppendLine(
                    "EMS_STREET_ORDER|OrderId" + streetOrder.OrderId + 
                    ",Executing Broker:" + streetOrder.ExecutingBroker + 
                    ",Quantity:" + streetOrder.Quantity + 
                    ",FilledQuantity:" + streetOrder.FilledQuantity + 
                    ",WeightedAvgPrice:" + streetOrder.WeightedAvgPrice);
                StreetOrder strOrder = new StreetOrder()
                {
                    ClientOrderId = orderUpdateResponse.OrderId,
                    StreetOrderId = streetOrder.OrderId,
                    ExecutingBroker = streetOrder.ExecutingBroker,
                    Size = Convert.ToDecimal(streetOrder.Quantity),
                    FilledQuantity = Convert.ToDecimal(streetOrder.FilledQuantity),
                    WeightedAvgPrice = Convert.ToDecimal(streetOrder.WeightedAvgPrice)
                };
                streetOrders.Add(strOrder);
            }
            _logger.Info(logMessage.ToString());
            return streetOrders.ToArray();
        }

        public static Data.Trades.Fee[] ParseFees(RepeatedField<Ft.Fee> fees)
        {
            List<Data.Trades.Fee> tradeFees = new List<Data.Trades.Fee>();
            if (fees != null)
            {
                foreach (Ft.Fee fee in fees)
                {
                    Data.Trades.Fee tradeFee = new Data.Trades.Fee()
                    {
                        Currency = "USD",
                        Name = fee.FeeName,
                        Rate = Convert.ToDecimal(fee.Total),
                        RateType = RateType.Fee
                    };
                    tradeFees.Add(tradeFee);
                }
            }
            return tradeFees.ToArray();
        }
    }
}
