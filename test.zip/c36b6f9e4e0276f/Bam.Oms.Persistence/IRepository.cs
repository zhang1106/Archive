﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data;

namespace Bam.Oms.Persistence
{
    public interface IRepository<T> : IDisposable where T : IPersistentItem
    {        
        /// <summary>
        /// Returns a specific item by key, null if the item does not exist
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        T Get(string key);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cutoffTimeUtc">Cut Off time as UTC</param>
        /// <returns>A collection of T instances in the cache that have been updated after the cut-off time</returns>
        [Log]
        IEnumerable<T> Get(DateTime cutoffTimeUtc);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="items">Instances of T to save.</param>
        /// <returns>Number of items successfully saved.</returns>
        [Log]
        IEnumerable<T> Save(IEnumerable<T> items);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="items">Instances of T to save.</param>
        /// <returns>Number of items successfully saved.</returns>
        [Log]
        IEnumerable<T> Remove(IEnumerable<T> items);
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="item">Instance of T to save.</param>
        /// <returns>1 if successful, 0 otherwise.</returns>
        [Log]
        T Save(T item);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="item">Instance of T to save.</param>
        /// <returns>1 if successful, 0 otherwise.</returns>
        [Log]
        T Remove(T item);
        
        /// <summary>
        /// Delete instances of T from the container that were last updated prior to cut-off time
        /// </summary>
        /// <param name="cutOffTimeUtc"></param>
        /// <returns>Number of items deleted.</returns>        
        [Log]
        int Clear(DateTime cutOffTimeUtc);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Log]
        int ClearAll();
    }
}
