﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Persistence.Positions;

namespace Bam.Oms.Tests
{
    public class Helper
    {
        public static IPositionSet CreatePositionSet(Portfolio portfolio = null, Security security = null, string custodian = null)
        {
            var repo = new PositionRepository();
            portfolio = portfolio ?? new Portfolio("QIAN", "GENERALIST");
            security = security ?? new Security { BamSymbol = "IBM" };
            custodian = custodian ?? "CSPN";

            //these should be set when the position is created
            portfolio.AggregationUnit = "AQTF";
            portfolio.ComplianceGroup = "ERG";

            var pk = new PositionKey(portfolio, security);

            return repo.Get(new[] { pk })[0];
        }
    }
}
