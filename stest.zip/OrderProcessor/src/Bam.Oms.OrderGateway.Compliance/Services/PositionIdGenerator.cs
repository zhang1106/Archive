﻿namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class PositionIdGenerator : IPositionIdGenerator
    {
        private long _counter = 1;

        public long GetNextPositionId()
        {
            return _counter++;
        }
    }
}