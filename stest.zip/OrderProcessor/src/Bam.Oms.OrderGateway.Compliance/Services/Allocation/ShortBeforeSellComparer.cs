﻿using System.Collections.Generic;
using Bam.Oms.OrderGateway.Messages;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public class ShortBeforeSellComparer : IComparer<OrderAllocation>
    {
        private readonly int[] _order;

        public ShortBeforeSellComparer()
        {
            _order = new int[4];
            _order[(int) Side.Cover] = 0;
            _order[(int) Side.Buy] = 1;
            _order[(int) Side.Short] = 2;            
            _order[(int) Side.Sell] = 3;
        }

        public int Compare(OrderAllocation x, OrderAllocation y)
        {
            int a = _order[(int) x.Side];
            int b = _order[(int) y.Side];

            if (a > b)
                return 1;

            if (b > a)
                return -1;

            return 0;
        }

        public static ShortBeforeSellComparer Instance { get; } = new ShortBeforeSellComparer();
    }
}
