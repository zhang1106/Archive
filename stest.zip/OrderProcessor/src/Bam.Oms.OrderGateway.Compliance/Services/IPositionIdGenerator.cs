﻿namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public interface IPositionIdGenerator
    {
        long GetNextPositionId();
    }
}