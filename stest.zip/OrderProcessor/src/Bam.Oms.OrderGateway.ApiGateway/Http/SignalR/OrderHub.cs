﻿using Bam.EventQ.SignalR;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.SignalR
{
    public class OrderHub : SignalRHub<Order>
    {
        public OrderHub(ISignalRSessionRepository sessionRepository) : base(sessionRepository)
        {
        }
    }
}
