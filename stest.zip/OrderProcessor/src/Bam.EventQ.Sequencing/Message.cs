﻿using Bam.EventQ.Recovery;

namespace Bam.EventQ.Sequencing
{
    public abstract class Message : IMessage
    {
        public const int HeaderSize = 16;

        public SequenceInfo Header { get; set; }
    }
}
