﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web.Http;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class TradeController : BaseController
    {
        private readonly ICache<string, Trade> _trades;
        private readonly ITradeSubmission _tradeSubmission;

        public TradeController(
            ICache<string, Trade> trades, 
            ITradeSubmission tradeSubmission,
            IPermissionedEntityFilter entityFilter)
            : base(entityFilter)
        {
            _trades = trades;
            _tradeSubmission = tradeSubmission;
        }

        [RequiredPermissions("Function.OrderGateway.Trade.Read, Function.OrderGateway.Trade.Write")]
        public Task<List<Trade>> Get()
        {
            using (_trades.AcquireReadAccess())
            {
                var trades = _trades.GetItems()
                    .OrderBy(t => t.TradeId);

                return FilterEntitiesAsync(trades);
            }
        }

        [RequiredPermissions("Function.OrderGateway.Trade.Read, Function.OrderGateway.Trade.Write")]
        public Task<List<Trade>> Get(string identifier)
        {
            identifier = identifier.ToUpper();

            using (_trades.AcquireReadAccess())
            {
                var trades = _trades.GetItems()
                    .Where(t => t.Security.BamSymbol.Equals(identifier) || t.ClientOrderId.Equals(identifier))
                    .OrderBy(t => t.TradeId);

                return FilterEntitiesAsync(trades);
            }
        }

        [RequiredPermissions("Function.OrderGateway.Trade.Read, Function.OrderGateway.Trade.Write")]
        public Task<List<Trade>> Get([FromUri(Name = "cutoffTimeUtc")] DateTime modifiedSince)
        {
            using (_trades.AcquireReadAccess())
            {
                var trades = _trades.GetItems()
                    .Where(t => t.LastUpdated >= modifiedSince)
                    .OrderBy(t => t.TradeId);

                return FilterEntitiesAsync(trades);
            }
        }

        [RequiredPermissions("Function.OrderGateway.Trade.Write")]
        public string Put(List<Trade> trades)
        {
            Logger?.LogInformation($"{User.GetLogin()} is overwriting {trades.Count} trades");

            if (!_tradeSubmission.Submit(trades))
            {
                InternalServerError();
                return null;
            }

            return
                "Done, but keep in mind this change is not persistent and needs to be redone in case the ApiGateway is restarted.";
        }
    }
}
