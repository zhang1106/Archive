﻿using System;
using System.Linq;
using System.Security.Principal;
using Bam.Oms.Messaging;
using BAM.Infrastructure.Ioc;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using Moq;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class SignalRHubTests
    {
        [Test]
        public void VerifyConnectCreatesFilter()
        {
            // arrange
            var mockFilter = new Mock<ISignalRSessions<TestSubject>>();
            var testHub = new SignalRHubTest(mockFilter.Object, new Mock<ILogger>().Object);
            var request = new Mock<IRequest>();
            testHub.Context = new HubCallerContext(request.Object, "123");

            // act
            testHub.OnConnected();

            // assert
            mockFilter.Verify(l => l.Add("123", It.IsAny<Func<TestSubject, bool>>()));
        }

        [Test]
        public void VerifyDisconnectRemovesFilter()
        {
            // arrange
            var mockFilter = new Mock<ISignalRSessions<TestSubject>>();
            var testHub = new SignalRHubTest(mockFilter.Object, new Mock<ILogger>().Object);
            var request = new Mock<IRequest>();
            testHub.Context = new HubCallerContext(request.Object, "123");

            // act
            testHub.OnDisconnected(true);

            // assert
            mockFilter.Verify(l => l.Remove("123"));
        }

        [Test]
        public void VerifyPingCallsPong()
        {
            // arrange
            var testHub = new SignalRHubTest(new Mock<ISignalRSessions<TestSubject>>().Object, new Mock<ILogger>().Object);

            var clientMock = new Mock<ISignalRClient<SignalRPacket<TestSubject>>>();

            var clientListMock = new Mock<IHubConnectionContext<ISignalRClient<SignalRPacket<TestSubject>>>>();
            clientListMock.Setup(c => c.Client(It.IsAny<string>())).Returns(clientMock.Object);

            var hubMock = new Mock<IHubContext<ISignalRClient<SignalRPacket<TestSubject>>>>();
            hubMock.Setup(c => c.Clients).Returns(clientListMock.Object);

            testHub.HubContext = hubMock.Object;

            // act
            testHub.Ping();

            // assert
            clientMock.Verify(l => l.Pong(It.IsAny<long>()));
        }

        [Test]
        public void VerifyConnectionLogged()
        {
            // arrange
            var logger = new Mock<ILogger>();
            var testHub = new SignalRHubTest(new Mock<ISignalRSessions<TestSubject>>().Object, logger.Object);
            var request = new Mock<IRequest>();
            testHub.Context = new HubCallerContext(request.Object, "123");

            // act
            testHub.OnConnected();

            // assert
            logger.Verify(l => l.DebugFormat(It.IsAny<string>(), It.IsAny<object[]>()));
        }

        [Test]
        public void VerifyReconnectedLogged()
        {
            // arrange
            var logger = new Mock<ILogger>();
            var testHub = new SignalRHubTest(new Mock<ISignalRSessions<TestSubject>>().Object, logger.Object);
            var request = new Mock<IRequest>();
            testHub.Context = new HubCallerContext(request.Object, "123");

            // act
            testHub.OnReconnected();

            // assert
            logger.Verify(l => l.DebugFormat(It.IsAny<string>(), It.IsAny<object[]>()));
        }

        [Test]
        public void VerifyDisconnectionLogged()
        {
            // arrange
            var logger = new Mock<ILogger>();
            var testHub = new SignalRHubTest(new Mock<ISignalRSessions<TestSubject>>().Object, logger.Object);

            // act
            testHub.OnDisconnected(false);

            // assert
            logger.Verify(l => l.DebugFormat(It.IsAny<string>(), It.IsAny<object[]>()));
        }

        [Test]
        public void VerifyGetSignalRPackets()
        {
            var orders = new[] { "t1", "t2", "t2", "t3", "t2" };

            var packets = SignalRPacket<string>.Partition(orders, 2).ToList();

            Assert.IsTrue(packets.Count() == 3 && packets[0].TotalExpectedPackets == 3 && packets[0].Sequence == 0);
        }

        public class TestSubject
        {
            public string Subject { get; set; }

            public override bool Equals(object obj)
            {
                var sub = obj as TestSubject;

                return sub?.Subject.Equals(this.Subject) ?? false;
            }

            public override int GetHashCode()
            {
                return Subject.GetHashCode();
            }
        }

        public class SignalRHubTest : SignalRHub<TestSubject>
        {
            public IHubContext<ISignalRClient<SignalRPacket<SignalRHubTests.TestSubject>>> HubContext { get; set; }

            public SignalRHubTest(ISignalRSessions<TestSubject> sessions, ILogger logger) : base(sessions, logger)
            {
                Context = new HubCallerContext(null, null);
            }

            public override IHubContext<ISignalRClient<SignalRPacket<SignalRHubTests.TestSubject>>> GetHubContext()
            {
                return HubContext;
            }

            protected override Func<TestSubject, bool> CreateFilter(IIdentity identity)
            {
                return s => s.Subject == "MATH";
            }
        }
    }
}