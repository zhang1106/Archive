﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Positions;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;


namespace Bam.Oms.Compliance.ServiceBroker
{
    public class ServiceBrokerListener : IServiceBrokerListener
    {
        private bool _stopping;
        private readonly ISettings _settings;
        private readonly ILogger _logger;
        private readonly IHelper _helper;
        private readonly IOgDataRepository _customDataRepository;

        public event Action<IList<IPosition>> SodPositionChanged;
        public event Action Positionchanged;

        public ServiceBrokerListener(IOgDataRepository customDataRepository, ISettings settings, ILogger logger, IHelper helper)
        {
            _customDataRepository = customDataRepository;
            _settings = settings;
            _helper = helper;
            _logger = logger;
        }

        public void Stop()
        {
            _stopping = true;
        }

        public void Start(string connectionString, MonitorTarget target)
        {
            while (!_stopping)
            {
                var to = new TransactionOptions
                {
                    IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted,
                    Timeout = TimeSpan.MaxValue
                };

                var tran = new CommittableTransaction(to);

                try
                {
                    using (var con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        con.EnlistTransaction(tran);
                        var message = ServiceBrokerUtil.GetMessage(_settings.BrokerServiceQueue, con, TimeSpan.FromSeconds(10));
                        if (message == null) //no message available
                        {
                            tran.Commit();
                            con.Close();
                            continue;
                        }

                        ProcessMessage(message);

                        tran.Commit(); // the message processing succeeded or the FailedMessageProcessor ran so commit the RECEIVE
                        con.Close();
                     }
                }
                catch (SqlException ex)
                {
                    _logger.Error("Error processing message from " + _settings.BrokerServiceQueue + ": " + ex.Message);
                    tran.Rollback();
                    tran.Dispose();
                    Thread.Sleep(1000);
                }
                //catch any other non-fatal exceptions that should not stop the listener loop.
                catch (Exception ex)
                {
                    _logger.Error("Unexpected Exception in Thread Proc for " + _settings.BrokerServiceQueue + ".  Thread Proc is exiting: " + ex.Message);
                    tran.Rollback();
                    tran.Dispose();
                    return;
                }

            }
        }

        public void ProcessMessage(byte[] messageBytes)
        {
          
        }

        private static Message Parse(byte[] message)
        {
            return new Message();
        }

        private struct Message
        {
            public string Db { get; set; }
            public int ActionId { get; set; }
        }
    }

    
}
