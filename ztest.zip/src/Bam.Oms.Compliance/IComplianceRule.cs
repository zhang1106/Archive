﻿namespace Bam.Oms.Compliance
{
    public interface IComplianceRule<in T>
    {
        int Id { get; set; }
        string Name { get; set; }
        string Description { get; set; }
        bool IsActive { get; set; }   //turn on/off a rule
        void SetAndValidateParameters(string parametersInJsonFormat);
        IComplianceRuleViolation CheckViolation(T input, bool isPreCheck);
    }
}
