using System.Collections.Generic;
using Bam.EventQ.Throttling;
using Bam.Oms.OrderGateway.ApiGateway.Cache;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class SharedCacheUpdater : 
        IThrottledBatchHandler<Order>,
        IThrottledBatchHandler<Trade>,
        IThrottledBatchHandler<Position>,
        IThrottledBatchHandler<SodPosition>,
        IThrottledBatchHandler<AggUnitPosition>,
        IThrottledBatchHandler<ComplianceGroupPosition>,
        IThrottledBatchHandler<DetailedPosition>,
        IThrottledBatchHandler<OrderScalingRule>,
        IThrottledBatchHandler<Security>,
        IThrottledBatchHandler<OwnershipHeadroom>
    {
        private readonly ICache<string, Order> _orders;
        private readonly ICache<string, Security> _securities;
        private readonly ICache<string, Trade> _trades;
        private readonly ICache<long, Position> _positions;
        private readonly ICache<long, DetailedPosition> _detailedPositions;
        private readonly ICache<string, SodPosition> _sodPositions;
        private readonly ICache<long, AggUnitPosition> _aggUnitPositions;
        private readonly ICache<long, ComplianceGroupPosition> _complianceGroupPositions;
        private readonly ICache<int, OrderScalingRule> _orderScalingRules;
        private readonly ICache<OwnershipHeadroomKey, OwnershipHeadroom> _ownershipHeadroom;

        public SharedCacheUpdater(
            ICache<string, Security> securities,
            ICache<string, Order> orders,
            ICache<string, Trade> trades,
            ICache<long, Position> positions,
            ICache<long, DetailedPosition> detailedPositions,
            ICache<string, SodPosition> sodPositions,
            ICache<long, AggUnitPosition> aggUnitPositions,
            ICache<long, ComplianceGroupPosition> complianceGroupPositions,
            ICache<int, OrderScalingRule> orderScalingRules,
            ICache<OwnershipHeadroomKey, OwnershipHeadroom> ownershipHeadroom)
        {
            _securities = securities;
            _orders = orders;
            _trades = trades;
            _positions = positions;
            _detailedPositions = detailedPositions;
            _sodPositions = sodPositions;
            _aggUnitPositions = aggUnitPositions;
            _complianceGroupPositions = complianceGroupPositions;
            _orderScalingRules = orderScalingRules;
            _ownershipHeadroom = ownershipHeadroom;
        }

        public void Handle(IReadOnlyList<Order> batch)
        {
            using (_orders.AcquireWriteAccess())
            {
                foreach (var o in batch)
                {
                    _orders.Update(o.Key, o);
                }
            }
        }

        public void Handle(IReadOnlyList<Trade> batch)
        {
            using (_trades.AcquireWriteAccess())
            {
                foreach (var t in batch)
                {
                    _trades.Update(t.Key, t);
                }
            }
        }

        public void Handle(IReadOnlyList<Position> batch)
        {
            using (_positions.AcquireWriteAccess())
            {
                foreach (var p in batch)
                {
                    _positions.Update(p.PositionId, p);
                }
            }
        }

        public void Handle(IReadOnlyList<SodPosition> batch)
        {
            using (_sodPositions.AcquireWriteAccess())
            {
                foreach (var p in batch)
                {
                    _sodPositions.Update(p.Id, p);
                }
            }
        }

        public void Handle(IReadOnlyList<AggUnitPosition> batch)
        {
            using (_aggUnitPositions.AcquireWriteAccess())
            {
                foreach (var p in batch)
                {
                    _aggUnitPositions.Update(p.PositionId, p);
                }
            }
        }

        public void Handle(IReadOnlyList<ComplianceGroupPosition> batch)
        {
            using (_complianceGroupPositions.AcquireWriteAccess())
            {
                foreach (var p in batch)
                {
                    _complianceGroupPositions.Update(p.PositionId, p);
                }
            }
        }

        public void Handle(IReadOnlyList<DetailedPosition> batch)
        {
            using (_detailedPositions.AcquireWriteAccess())
            {
                foreach (var p in batch)
                {
                    _detailedPositions.Update(p.PositionId, p);
                }
            }
        }

        public void Handle(IReadOnlyList<OrderScalingRule> batch)
        {
            using (_orderScalingRules.AcquireWriteAccess())
            {
                foreach (var r in batch)
                {
                    _orderScalingRules.Update(r.Id, r);
                }
            }
        }
        
        public void Handle(IReadOnlyList<Security> batch)
        {
            using (_securities.AcquireWriteAccess())
            {
                foreach (var p in batch)
                {
                    _securities.Update(p.Key, p);
                }
            }
        }
        
        public void Handle(IReadOnlyList<OwnershipHeadroom> batch)
        {
            using (_ownershipHeadroom.AcquireWriteAccess())
            {
                foreach (var b in batch)
                {
                    _ownershipHeadroom.Update(b.Key, b);
                }
            }
        }
    }
}
