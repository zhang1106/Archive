﻿namespace Bam.EventQ.Transport
{
    public interface IMessageTopicProvider<in TMessage>
    {
        int GetTopic(TMessage message);
    }
}
