﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Positions;

namespace Bam.Oms.Persistence.Contingency
{
    public interface IContingencyDbRepository : IDBRepository<ContingencyRecord>
    {
        IEnumerable<IPosition> Save(IEnumerable<IPosition> positions);
    }
}
