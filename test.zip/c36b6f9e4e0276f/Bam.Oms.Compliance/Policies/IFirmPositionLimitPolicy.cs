﻿using Bam.Oms.Data.Compliance;
using Bam.Oms.Persistence.Compliance;

namespace Bam.Oms.Compliance.Policies
{
    public interface IFirmPositionLimitPolicy : IPolicy<ICompliancePosition>
    {
        void PopulateRules(IRuleRepository<ICompliancePosition> ruleRepository);
    }
}
