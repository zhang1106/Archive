using System;
using Newtonsoft.Json;

namespace Bam.Oms.Messaging
{
    public class ParameterString
    {
        public ParameterString()
        {

        }

        public ParameterString(string property, object value, Type type)
        {
            Property = property;
            Value = JsonConvert.SerializeObject(value);
            Type = type.AssemblyQualifiedName;
        }

        /// <summary>
        /// Property name on the subject item, or item being filtered
        /// </summary>
        public string Property { get; set; }

        /// <summary>
        /// JSON formatted string of the object to match
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// Type of the Value object, in pattern "Fully Qualified Type, Assembly"
        /// </summary>
        public string Type { get; set; }

        //todo:
        //            Operator Operator { get; }
    }
}