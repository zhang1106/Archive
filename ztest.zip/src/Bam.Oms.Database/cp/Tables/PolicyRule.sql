﻿CREATE TABLE [cp].[PolicyRule] (
    [PolicyRuleId] INT          IDENTITY (1, 1) NOT NULL,
    [PolicyId]     INT          NOT NULL,
    [RuleId]       INT          NOT NULL,
    [CreatedOn]    DATETIME     NOT NULL,
    [CreatedBy]    VARCHAR (50) NOT NULL,
    CONSTRAINT [PK__PolicyRu__ADAAB5FE15DA3E5D] PRIMARY KEY CLUSTERED ([PolicyRuleId] ASC),
    CONSTRAINT [FK_PolicyRule_Policy] FOREIGN KEY ([PolicyId]) REFERENCES [cp].[Policy] ([Id]),
    CONSTRAINT [FK_PolicyRule_Rule] FOREIGN KEY ([RuleId]) REFERENCES [cp].[Rule] ([Id])
);

