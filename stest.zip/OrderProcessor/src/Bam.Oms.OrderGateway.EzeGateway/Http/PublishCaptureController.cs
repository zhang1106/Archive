﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using Bam.Oms.OrderGateway.EzeGateway.Models;
using Bam.Oms.OrderGateway.EzeGateway.Services;

namespace Bam.Oms.OrderGateway.EzeGateway.Http
{
    public class PublishCaptureController : ApiController
    {
        private readonly IEzeUpdateSubmission _submission;

        public PublishCaptureController(IEzeUpdateSubmission submission)
        {
            _submission = submission;
        }

        [HttpPost]
        public HttpResponseMessage Trade([FromBody] TradeUpdateDto message)
        {
            _submission.Submit(message);
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpGet]
        public string Whatup()
        {
            return "Hello";
        }

        [HttpPost]
        public HttpResponseMessage Allocation()
        {
            //dont really care, but the EZE service may require this
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]
        public HttpResponseMessage NotificationMessage()
        {
            //heartbeat 
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]
        public HttpResponseMessage Order()
        {
            //dont really care, but the EZE service may require this
            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
