﻿EXECUTE sp_addrolemember @rolename = N'db_owner', @membername = N'FOUNTAINHEAD\SQLDevs';

