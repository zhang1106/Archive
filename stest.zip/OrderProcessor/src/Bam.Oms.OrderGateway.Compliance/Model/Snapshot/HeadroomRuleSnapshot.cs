﻿using System.Collections.Generic;
using Bam.EventQ.Snapshot;

namespace Bam.Oms.OrderGateway.Compliance.Model.Snapshot
{
    public class HeadroomRuleSnapshot : ISnapshot
    {
        public List<Item> Items { get; } = new List<Item>();

        public class Item
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string ReportingEntity { get; set; }
            public string Direction { get; set; }
            public string IdentifierType { get; set; }
            public List<Headroom> Headrooms { get; } = new List<Headroom>();

            public class Headroom
            {
                public string Identifier { get; set; }
                public bool IsContingency { get; set; }
                public bool IsExempt { get; set; }
                public List<HeadroomThreshold> Thresholds { get; } = new List<HeadroomThreshold>();
                public Dictionary<string, double> AggregationUnitRatios { get; } = new Dictionary<string, double>();

                public class HeadroomThreshold
                {
                    public decimal Threshold { get; set; }
                    public long Quantity { get; set; }
                    public bool FireOnce { get; set; }
                    public string ViolationLevel { get; set; }
                }
            }
        }
    }
}
