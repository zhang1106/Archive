﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;
using Dapper;

namespace Bam.Oms.Persistence.Compliance
{
    public class DwRepository : IDwRepository
    {
        internal static readonly Func<dynamic, DtdPosition> EodMap = item => new DtdPosition()
        {
            BamSymbol = item.DisplayCode,
            Quantity = (long)item.QuantityEnd,
            Portfolio = item.StrategyCode,
            Fund = item.FundCode,
            Custodian = item.CustodianAccountCode,
            NetExposure = item.NetExposure
        };
        
        private const string CustomSharesOutstandingQuery = @"SELECT [Parent] ,[Override]
                                          FROM [BAMData].[TradeComp].[ReportingOverrides]
                                          Where Country in ('Sweden', 'Netherlands') and override != -1";

        private const string PmMapQuery = @"Select distinct Strategy = StrategyCode, ReportingEntity 
                                            From [BamData].[am].[vu_Strategy] 
                                            Where ReportingEntity is not null";

        private const string EuTradedIsins = @"SELECT distinct isin
                      FROM [BamCoreLite].[sm].[Security] s (nolock)
                      Inner Join [BamData].[TradeComp].[ReportingFilters] f (nolock) on f.Reportfilter='country' and f.ReportRegion='Europe' and f.ReportCode = s.CountryCode
                      Where s.ActiveInd = 1 and isin != '' and isin is not null";

        private const string ConstituentQuery = @"
                        Declare @AsOfDate datetime
                        select @AsOfDate=getdate()

                        SET NOCOUNT ON
                        DECLARE @MaxDate DATETIME = BamCore.[dbo].[MaxDate]()
	
                        SELECT  Parent = s.displaycode,
		                        Symbol = cs.displaycode,
		                        Allocation = bc.Allocation/100 
                        FROM BamCore.sm.Security s WITH (NOLOCK) 
                        INNER JOIN BamCore.sm.BasketSecurity bs WITH (NOLOCK) ON  s.SecurityId = bs.SecurityId
                        INNER JOIN BamCore.sm.BasketSource bsc WITH (NOLOCK) ON bsc.BasketSourceId = bs.BasketSourceId
                        INNER JOIN BamCore.sm.BasketComponentTimeSeries bst WITH (NOLOCK) ON bst.BasketSecurityId = bs.BasketSecurityId AND 
			                        @AsOfDate BETWEEN bst.EffectiveStartDate AND bst.EffectiveEndDate AND KnowledgeEndDate = @MaxDate
                        INNER JOIN BamCore.sm.BasketComponent bc WITH (NOLOCK) ON bc.BasketComponentTimeSeriesId = bst.BasketComponentTimeSeriesId
                        INNER JOIN BamCore.sm.Security cs WITH (NOLOCK) ON cs.SecurityId = bc.SecurityId";

        private const string PriceQuery = @"
                        IF OBJECT_ID('tempdb.dbo.#task') IS NOT NULL DROP TABLE #task;
                    IF OBJECT_ID('tempdb.dbo.#jobs') IS NOT NULL DROP TABLE #jobs;
                    IF OBJECT_ID('tempdb.dbo.#prices') IS NOT NULL DROP TABLE #prices;
                    IF OBJECT_ID('tempdb.dbo.#fxRate') IS NOT NULL DROP TABLE #fxRate;
                    Declare @dateid int;
                    Select @dateid = [BAMCore].[dbo].[GetCurrentDateId]() - 1;

                    SELECT
                            c.CurrencyCode
	                        ,fr.Direct
                    Into #fxRate
                        FROM [bamcore].[sm].[Currency] c (nolock) 
                        Inner Join [bamcore].[dw].FxRate fr (nolock) on fr.currencyId = c.currencyId
                        Inner join [bamcore].[sm].[Currency] c2 (nolock) on fr.RefCurrencyid = c2.currencyid
                        where  
                            c2.CurrencyCode = 'USD'
                            and fr.dateId = (select max(dateid) from [bamcore].[dw].FxRate f (nolock))

                    select  m.pxlast,  EqySharesOutReal=ISNULL(EqySharesOutReal, CurrSharesOutstanding), m.securityid, s.displayCode, s.PrincipalCurrencyCode, idx=ROW_NUMBER() Over (Partition By s.Displaycode order by m.taskrunId desc)
                    into #task
                    From [BAMCore].[mdm].[MktDataArchive] m (nolock)
	                    inner join bamcorelite.sm.security s (nolock) on m.securityid = s.securityid
                    where  s.InvestmentTypeCode = 'Ordinary Share' and assettypecode='equity' 
                    and dateid = @dateId
                    and pxlast is not null
                    --
                    SELECT  
                            [SecurityId]
	                        ,[Displaycode]
                            ,[Pxlast]
		                    ,EqySharesOutReal 
	                        ,fr.Direct
	                        ,fr.CurrencyCode
	                        ,PriceInDollar = case 
	                                when CurrencyCode = 'GBP' then Pxlast/(100 * Direct)
			                        else Pxlast/Direct
			                        end
                    into #prices
                    From   #task j  
                    Inner Join #fxRate fr on fr.CurrencyCode = j.PrincipalCurrencyCode
                    where pxlast is not null and j.idx = 1

                    Select Symbol=DisplayCode, PriceInDollar, SharesOutstanding = EqySharesOutReal, Delta=0 from #prices
                        ";
        private const string EodQuery = @"DECLARE @taskId INT, @date DATE, @asOfDate INT, @year INT
                        SELECT @Date = '{0}'
                        SELECT @asOfDate = BamCore.dbo.GetDateIdFromDate(@Date)
                        SELECT @year = @asOfDate/10000

                        SELECT @taskId = BAMCore.dbo.GetLatestTaskRunId('GenevaCalcAndArchive', @asOfDate, 1)

                        SELECT f.FundCode, st.StrategyCode,   ha.CustodianAccountCode, ha.CurrencyCode, ha.QuantityEnd, ha.NetExposure, s.DisplayCode
                        From BamCore.dw.HoldingArchive ha (NOLOCK)
                        Inner Join BamCoreLite.sm.Security s (NOLOCK) On ha.SecurityId = s.SecurityId
                        INNER JOIN BamCore.dw.Fund f WITH (NOLOCK) ON ha.FundId = f.FundId
                        INNER JOIN BamCore.dw.Strategy st WITH (NOLOCK) ON ha.StrategyId = st.StrategyId
                        where f.FundCode <> 'QNT' 
                            AND (NOT ha.CustodianAccountCode LIKE 'OMNI%')
                            AND ha.QuantityEnd <> 0 
                            AND ha.TaskRunId = @taskId And ha.Year = @year AND ha.QuantityEnd != 0
                            And ( AssetTypeCode in ( 'Equity')
                              OR AssetTypeCode = 'Future' AND InvestmentTypeCode IN('Index', 'Future Single Stock')
                              OR AssetTypeCode = 'Option' AND InvestmentTypeCode IN('Equity', 'ETF', 'Index', 'Index Option', 'Warrant And Right')
                              OR AssetTypeCode = 'Swap' AND InvestmentTypeCode IN('Basket', 'Equity Swap', 'Equity Swap Fully Funded', 'Future Single Stock', 'Index', 'Ordinary Share', 'Perferred', 'Warrant And Right'))";
                            

        private const string CustomMergeQuery = @"SELECT  [Parent]      
                                                    FROM [BAMData].[TradeComp].[ReportingOverrides]
                                                    WHERE Country = 'Merge'
                                                ";

        private readonly ISettings _settings;
        private readonly ILogger _logger;

        public DwRepository(ISettings settings, ILogger logger)
        {
            _settings = settings;
            _logger = logger;
        }

        protected IDbConnection Connection => new SqlConnection(_settings.BamCoreLiteConnectionString);

        public HashSet<string> GetEuMonitoredIsins()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var result = cn.Query<string>(EuTradedIsins);
                    var set = new HashSet<string>();
                    set.UnionWith(result);
                    return set;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving records from BamCorelite Security", e);
                throw;
            }
        }

        public ILookup<string, Constituent> GetConstitents()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    //
                    var result = cn.Query<Constituent>(ConstituentQuery);
               
                    var customMap = result.ToLookup(r => r.Parent);

                    return customMap;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving records from Constituents", e);
                throw;
            }
        }

        public Dictionary<string, string> GetPmRegionMapping()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var result = cn.Query<PmMap>(PmMapQuery);

                    var customMap = result.ToDictionary(r => r.Strategy, r => r.ReportingEntity);

                    return customMap;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving records from PM mapping", e);
                throw;
            }
        }

        public Dictionary<string, decimal> GetCustomSharesOutstandings()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var result = cn.Query<SOItem>(CustomSharesOutstandingQuery);

                    var customSO = result.ToDictionary(r => r.Parent, r=>r.Override); 
                    
                    return customSO;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving records from BamCorelite", e);
                throw;
            }
        }

        public Dictionary<string, MarketData> GetMarketData()
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var result = cn.Query<MarketData>(PriceQuery);
                
                    var data = result.ToDictionary(r => r.Symbol);
                    return data;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving records from BamCorelite", e);
            }
            return new Dictionary<string, MarketData>();
        }

        public IEnumerable<DtdPosition> GetEodPositions(DateTime date)
        {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var result = cn.Query(string.Format(EodQuery, date.Date)).Select(EodMap);
                    return result.ToList();
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving data from Holding Archive", e);
                throw;
            }
        }

        public IDictionary<string, HashSet<string>> GetCustomMergeSymbols() 
        {
            try
            {
                using (var cn = Connection)
                {
                    var dic = new Dictionary<string, HashSet<string>>();
                    cn.Open();
                    var result = cn.Query<string>(CustomMergeQuery).ToList();
                    if (!result.Any()) return null;
                    var sets = result.Select(s => new HashSet<string>(s.Split(':').Distinct()));
                    foreach (var set in sets)
                    {
                        foreach (var s in set)
                        {
                          if(!dic.ContainsKey(s))  dic.Add(s, set);
                        }
                    }

                    return dic;
                }
            }
            catch (Exception e)
            {
                _logger.Error("Error occurred while retrieving data from merge symbols", e);
                throw;
            }
        }

        //custom shares outstanding
        public struct SOItem
        {
            public string Parent;
            public decimal Override;
        }

        public struct PmMap
        {
            public string Strategy;
            public string ReportingEntity;
        }

     
    }
}
