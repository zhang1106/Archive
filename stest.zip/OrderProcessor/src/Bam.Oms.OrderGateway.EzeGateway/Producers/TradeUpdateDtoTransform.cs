﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Diagnostics;
using Bam.EventQ.Integration;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.EzeGateway.EzeApi;
using Bam.Oms.OrderGateway.EzeGateway.Models;
using Bam.Oms.OrderGateway.Infrastructure.Audit;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.EzeGateway;

namespace Bam.Oms.OrderGateway.EzeGateway.Producers
{
    public class TradeUpdateDtoTransform : IExternalMessageTransform<TradeUpdateDto, IMessage>
    {
        private readonly IMessageAudit _audit;
        private readonly TimeZoneInfo _chicagoTimeZoneInfo;

        public TradeUpdateDtoTransform(IMessageAudit audit)
        {
            _audit = audit;
            _chicagoTimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
        }

        public ILogger Logger { get; set; }

        public IEnumerable<IMessage> Transform(TradeUpdateDto input)
        {
            _audit.HandleIn(input);

            var msg = new TradeUpdate();
            foreach (var trade in input.Trades)
            {
                var line = new TradeUpdate.LineItem
                {
                    Symbol = trade.Symbol,
                    Created = trade.TradeIndex.Subtract(_chicagoTimeZoneInfo.BaseUtcOffset),
                    SettlementDate = trade.SettleDate.Date,
                    BusinessDay = trade.TradeDate.Date,
                    TradeId = trade.TradeId,
                    ExternalId = trade.ExternalBlockID,
                    LimitPrice = trade.Duration == Duration.MKT ? null : trade.LimitPrice,
                    Notes = trade.Note,
                    Side = GetSideType(trade.Action),
                    Status = GetOrderStatus(trade),
                    Trader = trade.Trader,
                    Urgency = GetUrgency(trade)
                };

                if (trade.allocations.Length > 0)
                {
                    var allocationWithFills = trade.allocations.FirstOrDefault(r => r.Filled > 0);

                    var ccy = allocationWithFills == null
                        ? trade.allocations[0].FromCurrency
                        : allocationWithFills.FromCurrency;

                    line.SettlementCurrency = line.TradeCurrency = ccy;
                }

                msg.Items.Add(line);

                foreach (var a in trade.allocations)
                {
                    bool ignore = IsAllocationDeleted(a) ||
                                  IsOpsTrade(trade) ||
                                  line.Status == OrderStatus.Deleted;
                    if (!ignore)
                    {
                        line.Allocations.Add(new TradeUpdate.Allocation
                        {
                            Portfolio = GetStrategy(a),
                            Fund = GetFund(a),
                            Custodian = GetCustodian(a),
                            ExecutionBroker = GetExecutionBroker(a),
                            Quantity = (long)a.Quantity,
                            Filled = (long)a.Filled,
                            AveragePrice = a.AveragePrice,
                            Fees = a.TotalFees,
                            Commissions = a.TotalCommission,
                            SubmissionId = Guid.NewGuid()
                        });
                    }
                }

                if (trade.Status == "DONE" && trade.Leaves > 0)
                {
                    Logger?.LogError($"Received EZE trade '{trade.TradeId}' with DONE and leaves quantity > 0.");
                }
            }

            yield return msg;
        }

        private Side GetSideType(TradeAction action)
        {
            switch (action)
            {
                case TradeAction.Buy:
                    return Side.Buy;
                case TradeAction.Cover:
                    return Side.Cover;
                case TradeAction.Sell:
                    return Side.Sell;
                case TradeAction.Short:
                    return Side.Short;
                default:
                    throw new ArgumentOutOfRangeException(nameof(action), "Must be Buy, Sell, Cover, or Short");
            }
        }

        private bool IsTradeDeleted(Trade trade)
        {
            return string.Compare(trade.MessageType, "DELETE", StringComparison.InvariantCultureIgnoreCase) == 0 || IsOpsTrade(trade)
                   || trade.allocations.All(r => string.Compare(r.MessageType, "DELETE", StringComparison.InvariantCultureIgnoreCase) == 0);
        }

        private OrderStatus GetOrderStatus(Trade trade)
        {
            if (IsTradeDeleted(trade))
                return OrderStatus.Deleted;

            if (trade.State == "A") return OrderStatus.Finalized;
            switch (trade.Status.ToUpperInvariant())
            {
                case "NEW":
                    return OrderStatus.New;
                case "OPEN":
                    return OrderStatus.Working;
                case "DONE":
                    return OrderStatus.Filled;
                case "PROPOSED":
                    return OrderStatus.PendingValidation;
                default:
                    return OrderStatus.Error;
            }
        }

        private Messages.Urgency GetUrgency(Trade trade)
        {
            var urgency = Messages.Urgency.Low;
            string[] userDefinedFields = trade.UserDefinedFields;
            if (userDefinedFields != null && userDefinedFields.Any())
            {
                string urgencyString = userDefinedFields.FirstOrDefault(
                    udf => udf.StartsWith("Urgency", StringComparison.CurrentCultureIgnoreCase));
                if (!string.IsNullOrWhiteSpace(urgencyString))
                {
                    string[] s = urgencyString.Split('=');
                    if (s.Length == 2)
                    {
                        Enum.TryParse(s[1], true, out urgency);
                    }
                }
            }

            return urgency;
        }

        private bool IsAllocationDeleted(Allocation allocation)
        {
            return string.Compare(allocation.MessageType,
                       "DELETE", StringComparison.InvariantCultureIgnoreCase) == 0;
        }

        private bool IsOpsTrade(Trade trade)
        {
            return string.Compare(trade.Trader, "OPS", StringComparison.InvariantCultureIgnoreCase) == 0;
        }

        private string GetStrategy(Allocation allocation)
        {
            var idx = allocation.Account?.LastIndexOf(" ", StringComparison.Ordinal); //EZE DATA:BAM-FIRM HEDGE GS-ALMF
            return (!idx.HasValue || idx < 0) ? allocation.Account : allocation.Account.Substring(0, idx.Value);
        }

        private string GetFund(Allocation allocation)
        {
            var ary = allocation.Account.Split('-');
            return ary[ary.Length - 1];
        }

        private string GetCustodian(Allocation allocation)
        {
            if (string.IsNullOrEmpty(allocation.Custodian))
                return "UNKNOWN";

            return allocation.Custodian;
        }

        private string GetExecutionBroker(Allocation allocation)
        {
            if (string.IsNullOrEmpty(allocation.Broker))
                return "UNKNOWN";

            return allocation.Broker;
        }
    }
}
