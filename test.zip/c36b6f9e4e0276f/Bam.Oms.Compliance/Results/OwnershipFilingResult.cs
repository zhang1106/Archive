﻿using Newtonsoft.Json;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Results
{
    [JsonObject(MemberSerialization.OptIn)]
    public class OwnershipFilingResult : RuleResult 
    {
        [JsonProperty]
        public decimal? Ratio { get; set; }
        [JsonProperty]
        public decimal? LowLimit { get; set; }
        [JsonProperty]
        public decimal? LastRatio { get; set; }
        [JsonProperty]
        public decimal? SharesOutstanding { get; set; }
        public override string ToString()
        {
            return
                $"AlertLevel:\"{AlertLevel}\",Policly:{PolicyId},RuleName:{RuleName},LastRatio:{LastRatio},Ratio:{Ratio},LowLimit:{LowLimit},PositionQty:{PositionQty},SharesOutstanding:{SharesOutstanding}";
        }

        public override bool Same(object obj)
        {
            if (obj == this)
                return true;

            var other = obj as OwnershipFilingResult;
            if (this.Equals(obj)) return true;
            if (other == null)
                return false;

            return (MiniKey == other.MiniKey)
                   && LowLimit == other.LowLimit
                ;
        }
    }
}
