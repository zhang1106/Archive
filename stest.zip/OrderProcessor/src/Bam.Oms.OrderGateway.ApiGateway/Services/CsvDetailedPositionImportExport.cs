﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using CsvHelper.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway.Services
{
    public class CsvDetailedPositionImportExport : IDetailedPositionImportExport
    {
        public IReadOnlyList<DetailedPosition> Import(string path)
        {
            var result = new List<DetailedPosition>();
            using (var file = new StreamReader(path))
            using (var reader = new CsvHelper.CsvReader(file, CreateConfig()))
            {
                while (reader.Read())
                {
                    var record = reader.GetRecord<dynamic>();
                    var dict = (IDictionary<string, object>)record;

                    var item = new DetailedPosition
                    {
                        ShortMarkingQuantity = Convert.ToInt64(record.ShortMarkingQuantity),
                        PositionId = Convert.ToInt64(record.PositionId),
                        LongMarkingQuantity = Convert.ToInt64(record.LongMarkingQuantity),
                        BamSymbol = record.BamSymbol,
                        Portfolio = record.Portfolio,
                        LastUpdated = Convert.ToDateTime(record.LastUpdated),
                    };

                    string prefix = "Actual[";
                    foreach (var key in dict.Keys.Where(k => k.StartsWith(prefix)).ToList())
                    {
                        if (!string.IsNullOrEmpty(dict[key] as string))
                        {
                            string fund = key.Substring(prefix.Length, key.IndexOf('@') - prefix.Length);
                            string custodian = key.Substring(key.IndexOf('@') + 1, key.Length - key.IndexOf('@') - 2);
                            var qty = Convert.ToInt64(dict[key]);
                            item.SetActualAllocation(new PositionAllocationKey(fund, custodian), qty);
                        }
                    }

                    prefix = "Theoretical[";
                    foreach (var key in dict.Keys.Where(k => k.StartsWith(prefix)).ToList())
                    {
                        if (!string.IsNullOrEmpty(dict[key] as string))
                        {
                            string fund = key.Substring(prefix.Length, key.IndexOf('@') - prefix.Length);
                            string custodian = key.Substring(key.IndexOf('@') + 1, key.Length - key.IndexOf('@') - 2);
                            var qty = Convert.ToInt64(dict[key]);
                            item.SetTheoreticalAllocation(new PositionAllocationKey(fund, custodian), qty);
                        }
                    }
                    
                    result.Add(item);
                }
            }

            return result;
        }

        public void Export(IReadOnlyList<DetailedPosition> positions, string path)
        {
            var actualAllocKeys =
                positions.SelectMany(
                    p => p.ActualAllocations.Select(a => new PositionAllocationKey(a.Fund, a.Custodian)))
                    .Distinct()
                    .ToList();

            var theoreticalAllocKeys =
                positions.SelectMany(
                    p => p.TheoreticalAllocations.Select(a => new PositionAllocationKey(a.Fund, a.Custodian)))
                    .Distinct()
                    .ToList();

            using (var file = new StreamWriter(path))
            using (var writer = new CsvHelper.CsvWriter(file, CreateConfig()))
            {
                writer.WriteField(nameof(DetailedPosition.PositionId));
                writer.WriteField(nameof(DetailedPosition.BamSymbol));
                writer.WriteField(nameof(DetailedPosition.Portfolio));
                writer.WriteField(nameof(DetailedPosition.ShortMarkingQuantity));
                writer.WriteField(nameof(DetailedPosition.LongMarkingQuantity));
                foreach (var key in actualAllocKeys)
                {
                    writer.WriteField($"Actual[{key.Fund}@{key.Custodian}]");
                }
                foreach (var key in theoreticalAllocKeys)
                {
                    writer.WriteField($"Theoretical[{key.Fund}@{key.Custodian}]");
                }
                writer.WriteField(nameof(DetailedPosition.LastUpdated));
                writer.NextRecord();

                foreach (var p in positions)
                {
                    writer.WriteField(p.PositionId);
                    writer.WriteField(p.BamSymbol);
                    writer.WriteField(p.Portfolio);
                    writer.WriteField(p.ShortMarkingQuantity);
                    writer.WriteField(p.LongMarkingQuantity);

                    foreach (var key in actualAllocKeys)
                    {
                        var alloc = p.GetActualAllocation(key);
                        if (alloc != null)
                            writer.WriteField(alloc.Quantity);
                        else
                            writer.WriteField(null);
                    }

                    foreach (var key in theoreticalAllocKeys)
                    {
                        var alloc = p.GetTheoreticalAllocation(key);
                        if (alloc != null)
                            writer.WriteField(alloc.Quantity);
                        else
                            writer.WriteField(null);
                    }

                    writer.WriteField(p.LastUpdated);
                    writer.NextRecord();
                }
            }
        }

        private static CsvConfiguration CreateConfig()
        {
            return new CsvConfiguration();
        }        
    }
}
