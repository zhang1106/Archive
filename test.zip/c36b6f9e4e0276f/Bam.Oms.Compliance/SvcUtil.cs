﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using Bam.Oms.Compliance.Actions;
using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Persistence.Compliance;
using BAM.Infrastructure.Ioc;
using Newtonsoft.Json;

namespace Bam.Oms.Compliance
{
    public class SvcUtil : ISvcUtil
    {
        private readonly ISettings _settings;
        private readonly ILogger _logger;
        private readonly ISecurityProvider _securityProvider;
        private readonly IHoldingProvider _holdingProvider;
        public SvcUtil(ISettings settings, ILogger logger, ISecurityProvider securityProvider, IHoldingProvider holdingProvider)
        {
            _settings = settings;
            _logger = logger;
            _securityProvider = securityProvider;
            _holdingProvider = holdingProvider;
        }
        public void ExportHeadRooms(IEnumerable<IRuleResult> ruleResults, string filename)
        {
            var headRooms =
                ruleResults.Where(r => !string.IsNullOrEmpty(r.HeadRoom.Identifier))
                    .Select(r => r.HeadRoom)
                    .GroupBy(h => new {h.Identifier, h.RuleName})
                    .Select(g => g.First());
            if (!headRooms.Any())
            {
                _logger.Info($"Sod: Not generate headrooms file cos data is empty.");
                return;
            }
            
            System.IO.File.WriteAllText(filename, JsonConvert.SerializeObject(headRooms, Formatting.Indented));
            _logger.Info($"Sod: Exported headrooms to {filename}");
        }

        public void ExportHeadRoomsToCsv(IEnumerable<IRuleResult> ruleResults)
        {
            var sb = new StringBuilder();
            var headRooms =
               ruleResults.Where(r => !string.IsNullOrEmpty(r.HeadRoom.Identifier))
                   .Select(r => r.HeadRoom)
                   .GroupBy(h => new { h.Identifier, h.RuleName })
                   .Select(g => g.First());
            

            sb.AppendLine($"Identifier,IdentifierType,RuleName,SharesOutstanding,Holding,Entity,IsExempt,");
            foreach (var h in headRooms)
            {
                sb.AppendLine($"{h.Identifier},{h.IdentifierType},{h.RuleName},{h.SharesOutstanding},{h.Holding},{h.Entity},{h.IsExempt}");
            }
            var file = _settings.DebugFilePath + "OwnershipHeadroomDump" + DateTime.UtcNow.Ticks + ".csv";
            System.IO.File.WriteAllText(file, sb.ToString());
        }

        public void ExportSodReconToCsv(IEnumerable<IRuleResult> ruleResults)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"BamSymbol,RuleName,Decription");
            var symLookup = ruleResults.ToLookup(r => r.HeadRoom.Identifier);
            foreach (var p in _holdingProvider.GetUnderlyingSecurities(PositionType.Sod))
            {
                var security = _securityProvider.GetSecurity(p);
                var results = symLookup[p].Union(symLookup[security?.Isin]).ToList();
                if (!results.Any())
                {
                    sb.AppendLine($"{p}, RuleName, No HR Generated");
                    continue;
                }
                
                sb.AppendLine($"{p},{results[0].RuleName},{results[0].HeadRoom.Side}");
            }
            var file = _settings.DebugFilePath + "SodOwnershipHeadroomDump" + DateTime.UtcNow.Ticks + ".csv";
            System.IO.File.WriteAllText(file, sb.ToString());
        }

        public void EmailReport(IEnumerable<IRuleResult> ruleResults, PositionType pType)
        {
            var templatePath = ConfigurationManager.AppSettings["compliance_emailTemplate"];
            var from = ConfigurationManager.AppSettings["compliance_emailFrom"];
            var to = ConfigurationManager.AppSettings["compliance_emailTo"];
            var cc = ConfigurationManager.AppSettings["compliance_emailCC"];
            var bcc = ConfigurationManager.AppSettings["compliance_emailBCC"];
            var title = pType == PositionType.Eod ? ConfigurationManager.AppSettings["compliance_emailTitle"] + " - T+1 EOD Report"
                : ConfigurationManager.AppSettings["compliance_emailTitle"];

            var template = FirmPositionAlertEmail.GetTemplate(templatePath);
            var html = FirmPositionAlertEmail.BuildHtml(template, ruleResults);
            
            _logger.Info("send email...");
            FirmPositionAlertEmail.SendEmail(title, html, from, to, cc, bcc, null, null);
           
        }

        public void EmailEuShortReport(IEnumerable<IRuleResult> ruleResults, PositionType pType)
        {
            var templatePath = ConfigurationManager.AppSettings["compliance_emailTemplate"];
            var from = ConfigurationManager.AppSettings["compliance_EuEmailFrom"];
            var to = ConfigurationManager.AppSettings["compliance_EuEmailTo"];
            var cc = ConfigurationManager.AppSettings["compliance_EuEmailCC"];
            var title = pType == PositionType.Eod ? ConfigurationManager.AppSettings["compliance_EuEmailTitle"] + " - T+1 EOD Report"
                : ConfigurationManager.AppSettings["compliance_EuEmailTitle"];

            var template = FirmPositionAlertEmail.GetTemplate(templatePath);
            var html = FirmPositionAlertEmail.BuildHtml(template, ruleResults);

            _logger.Info("send email...");
            FirmPositionAlertEmail.SendEmail(title, html, from, to, cc, string.Empty, null, null);

        }

        public bool IsEod()
        {
            var span = int.Parse(ConfigurationManager.AppSettings["compliance_span"]);
            var end = int.Parse(ConfigurationManager.AppSettings["compliance_end"]);
            //last run 
            return DateTime.Now.AddMinutes(span).Hour >= end;
        }

    }
}
