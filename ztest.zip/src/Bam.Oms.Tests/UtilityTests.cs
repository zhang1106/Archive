﻿using System.Web.Query.Dynamic;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class UtilityTests
    {
        [Test]
        [TestCase("Hi Ya Ya", TestEnum.UnKnown, false)]
        [TestCase("HiYa", TestEnum.Hiya, true)]
        [TestCase(null, TestEnum.UnKnown, false)]
        public void VerifyUnknownStringValueToEnum(string testString, TestEnum expectedEnum, bool expectedRslt)
        {
            //arrange
            TestEnum unit;
            bool isDefined;

            //Act
            unit = Utility.TryConvertEnum<TestEnum>(testString, out isDefined);
            
            //Assert
            Assert.That(unit, Is.EqualTo(expectedEnum));
            Assert.That(isDefined, Is.EqualTo(expectedRslt));
        }

        [Test]
        public void VerifyStringValueAttributeToEnum()
        {
            // arrange
            const string stringValue = "Hi Ya";

            // act
            var unit = Utility.GetEnumValue<TestEnum>(stringValue);

            // assert
            Assert.That(unit, Is.EqualTo(TestEnum.Hiya));
        }

        [Test]
        public void VerifyEnumToDisplayString()
        {
            // arrange
            var enumValue = TestEnum.Oh_No;

            // act
            var unit = Utility.GetStringValue(enumValue);

            // assert
            Assert.That(unit, Is.EqualTo("Oh No"));
        }

        [Test]
        public void VerifyStringToEnum()
        {
            // arrange
            const string stringValue = "Hiya";

            // act
            var unit = Utility.ConvertEnum<TestEnum>(stringValue);

            // assert
            Assert.That(unit, Is.EqualTo(TestEnum.Hiya));
        }
       
        //test enum
        public enum TestEnum
        {
            [Enum(StringValue = "Unknown")]
            UnKnown,

            [Enum(StringValue = "Hi Ya")]
            Hiya ,

            [Enum(StringValue = "Oh No")]
            Oh_No,
        }

        [Test]
        public void TestDayCountConventionStringToEnum()
        {
            const string stringValue = "ACT/360";

            // act
            var unit = Utility.GetEnumValue<DayCountConvention>(stringValue);

            // assert
            Assert.That(unit, Is.EqualTo(DayCountConvention.Actual360));

        }

        [Test]
        [TestCase("OMMM",   false)]
        [TestCase("OMNI-xx",  true)]
        [TestCase("Omni", true)]
        [TestCase("OmNi-yy", true)]
        public void VerifyOmni(string testString,  bool expectedRslt)
        {
            //Act
            bool isOmni = Utility.IsOmni(testString);
            //Assert
            Assert.That(isOmni, Is.EqualTo(expectedRslt));
        }
    }
}