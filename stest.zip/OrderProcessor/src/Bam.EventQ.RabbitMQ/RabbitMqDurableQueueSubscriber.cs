﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Transport;
using RabbitMQ.Client;

namespace Bam.EventQ.RabbitMQ
{
    public class RabbitMqDurableQueueSubscriber : IMessageSubscriber, IDisposable
    {
        private readonly string _exchange;
        private readonly string _queue;
        private readonly IRoutingKeyConverter _routingKeyConverter;
        private readonly string _bindingRoutingKey;
        private ConnectionFactory _connectionFactory;
        
        private IConnection _connection;
        private IModel _model;
        private CachingConsumer _consumer;
        private string _tag;

        public RabbitMqDurableQueueSubscriber(
            string exchange, string queue, 
            IRoutingKeyConverter routingKeyConverter,
            string bindingRoutingKey = "#")
        {
            Name = "RMQ Subscriber";
            _exchange = exchange;
            _queue = queue;
            _routingKeyConverter = routingKeyConverter;
            _bindingRoutingKey = bindingRoutingKey;
        }

        public string Name { get; }
        
        public void Connect(string endpoint)
        {
            if (_connection != null)
                return;

            _connectionFactory = new ConnectionFactory
            {
                Uri = endpoint,
                AutomaticRecoveryEnabled = true,
                TopologyRecoveryEnabled = true,
                UseBackgroundThreadsForIO = true,
                NetworkRecoveryInterval = TimeSpan.FromSeconds(5),
                RequestedHeartbeat = 500
            };

            _connection = _connectionFactory.CreateConnection();
            _model = _connection.CreateModel();
            _model.QueueDeclare(_queue, true, false, false, null);
            _model.ExchangeDeclare(_exchange, "topic", true);
            _model.QueueBind(_queue, _exchange, _bindingRoutingKey);

            _consumer = new CachingConsumer(_model, _routingKeyConverter);
            _tag = _model.BasicConsume(_queue, false, _consumer);
        }
        
        public bool TryReceive(byte[] buffer, int index, out int received, out int topic, TimeSpan timeout)
        {
            if (_consumer != null && _consumer.DataAvailable.WaitOne(timeout))
            {
                KeyValuePair<int, byte[]> data;
                if (_consumer.TryDequeue(out data))
                {
                    Buffer.BlockCopy(data.Value, 0, buffer, index, data.Value.Length);
                    topic = data.Key;
                    received = data.Value.Length;
                    return true;
                }
            }

            received = 0;
            topic = 0;
            return false;
        }

        public void Dispose()
        {
            if (_tag != null)
            {
                _model.BasicCancel(_tag);
            }

            if (_connection != null)
            {
                _model.Dispose();
                _connection.Dispose();
            }
        }
    }
}
