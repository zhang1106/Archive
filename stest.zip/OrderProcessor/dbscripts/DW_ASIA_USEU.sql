USE [BAMData]
GO
/****** Object:  StoredProcedure [exports].[CreateSODExtractForOMS]    Script Date: 3/11/2017 11:56:26 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--exports.[CreateSODExtractAsia] @AsOfDate = '11/01/2016', @Business='EQUITY', @AggregationUnit = 'MAIN'

CREATE PROCEDURE [exports].[CreateSODExtractUSEU]
	@AsOfDate DATE = NULL,
	@Business VARCHAR(20) = NULL,
	@AggregationUnit VARCHAR(20) = NULL
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 

	DECLARE @AsOfDateId INT, @PrevDateID INT

	IF @AsOfDate is null
	BEGIN
		SELECT @AsOfDateId = BamCore.dbo.GetDateIdFromDate(GETDATE())
	END
	ELSE
	BEGIN
		SELECT @AsOfDateId = BamCore.dbo.GetDateIdFromDate(@AsOfDate)
	END

	SELECT @PrevDateId = BamCore.dbo.GetPreviousBusinessDateId(@AsOfDateId)

	DECLARE @GeographicRegions TABLE (Code VARCHAR(100))
	INSERT INTO @GeographicRegions SELECT 'Americas'
	INSERT INTO @GeographicRegions SELECT 'USA and Canada'
	INSERT INTO @GeographicRegions SELECT 'Western Europe'
	
	SELECT 
		   s.DisplayCode AS Symbol,
		   sum(hd.AccountingQuantityStart) AS Qty,
		   IsNull(m.NextDayOpen, 0.000) AS Price,
		   c.CurrencyCode AS Currency,
		   fx.Direct AS FxRate,
		   b.BrokerCode AS Custodian,
		   max(ca.CustodianAccountCode) AS CustodianAccount,
   		   --s.AssetTypeCode AS SecurityType,
   		   case when s.AssetTypeCode in ('Swap') then 'EquitySwap' else s.AssetTypeCode end AS SecurityType,
		   s.InvestmentTypeCode,
		   st.StrategyCode AS Strategy,
		   f.FundCode AS Fund,
		   ROUND(max(hd.AccountingAvgCostLocal),4) AS CostPrice --,
		   /** Commenting out till export process can selectively output columns from a dataset - rpandey 2016/08/02 
		   st.StrategyCode + ' ' +
			CASE b.BrokerCode 
				WHEN 'NOTR' THEN 'NT'
				WHEN 'BONY' THEN 'BK'
				ELSE LEFT(ca.CustodianAccountCode,2)
			END + '-' + f.FundCode AS EzePortfolio,
			CASE WHEN CHARINDEX('|EZE|', '|' + ast.OMS + '|') > 0 THEN 'EZE' ELSE '' END AS OMSEze,
			CASE WHEN CHARINDEX('|FLEX|', '|' + ast.OMS + '|') > 0 THEN 'FLEX' ELSE '' END AS OMSFlex,
			ast.OMSStream,
			ast.Business,
			ast.AggregationUnit
			--**/
	FROM BamCore.dw.HoldingDate hd WITH (NOLOCK)
		   INNER JOIN BamCore.dw.Holding h WITH (NOLOCK) ON hd.HoldingId = h.HoldingId
		   INNER JOIN BamCore.dw.Strategy st WITH (NOLOCK) ON st.StrategyId = h.StrategyId
		   INNER JOIN BamCore.dw.CustodianAccount ca WITH (NOLOCK) ON ca.CustodianAccountId = h.CustodianAccountId
		   INNER JOIN BamCore.dw.Broker b WITH (NOLOCK) ON b.BrokerId = ca.BrokerId
		   INNER JOIN BamCore.sm.Currency c WITH (NOLOCK) ON c.CurrencyId = h.CurrencyId
		   INNER JOIN BamCore.dw.Fund f WITH (NOLOCK) ON f.FundId = h.FundId
		   INNER JOIN BamCoreLite.sm.Security s WITH (NOLOCK) ON s.SecurityId = h.SecurityId
		   INNER JOIN BamCore.sm.Security s1 WITH (NOLOCK) ON s1.SecurityId = h.SecurityId
		   INNER JOIN BamCoreLite.sm.Country cnt ON cnt.CountryCode = s.CountryCode
		   INNER JOIN @GeographicRegions gr ON gr.Code = cnt.GeographicRegionCode
		   LEFT JOIN BamCore.dw.Mark m WITH (NOLOCK) ON m.SecurityId = s1.SecurityId AND s1.PrincipalCurrencyId = m.CurrencyId AND m.DateId = @PrevDateID
		   INNER JOIN BamCore.dw.FxRate fx WITH (NOLOCK) ON fx.CurrencyId = h.CurrencyId AND fx.DateId = @PrevDateID AND fx.RefCurrencyId = 149
		   LEFT JOIN BamData.am.vu_AllStrategy ast ON ast.Strategy = st.StrategyCode AND ast.EntityTypeCode = 'StrategyDetailCode'
	WHERE
		hd.DateId = @AsOfDateId
		AND s.AssetTypeCode NOT IN ('Cash','Fixed Income','FX')
		AND f.FundCode != 'QNT'
		AND hd.AccountingQuantityStart <> 0
		AND (ast.Business = @Business OR @Business IS NULL)
		AND (ast.AggregationUnit = @AggregationUnit OR @AggregationUnit IS NULL)
		
	GROUP BY 
		s.DisplayCode,
		m.NextDayOpen,
		c.CurrencyCode,
		fx.Direct,
 	    b.BrokerCode,
	--	ca.CustodianAccountCode,
   		s.AssetTypeCode,
		s.InvestmentTypeCode,
		st.StrategyCode,
		f.FundCode,
	--	ROUND(hd.AccountingAvgCostLocal,4),
		b.BrokerCode,
		ast.OMS,
  		ast.OMSStream,
		ast.Business,
		ast.AggregationUnit
	
	ORDER BY
		s.DisplayCode

END









