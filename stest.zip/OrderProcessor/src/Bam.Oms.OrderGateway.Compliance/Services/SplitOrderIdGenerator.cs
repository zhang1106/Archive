﻿using Bam.EventQ.Lookup;
using Bam.Oms.OrderGateway.Compliance.Model;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class SplitOrderIdGenerator : ISplitOrderIdGenerator
    {
        private readonly IModelIndex<Order> _orders;

        public SplitOrderIdGenerator(IIndexFactory index)
        {
            _orders = index.For<Order>();
        }

        public long GetNextOrderId(long originalOrderId)
        {
            long id = originalOrderId + 1;
            while (_orders.LookupBy(nameof(Order.OrderId), id) != null)
            {
                id++;
            }

            return id;
        }
    }
}