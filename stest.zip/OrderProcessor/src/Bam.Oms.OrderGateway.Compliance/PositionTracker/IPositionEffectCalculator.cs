﻿namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public interface IPositionEffectCalculator
    {
        ComplianceEffects CalculateComplianceEffects(OrderInfo orderInfo);
        ActualEffects CalculateActualEffects(AllocationInfo orderInfo);
        TheoreticalEffects CalculateTheoreticalEffects(AllocationInfo allocInfo);
    }
}
