﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.OrderRouting.Flex;
using Bam.Oms.Persistence.Orders;
using Bam.Oms.Persistence.Trades;
using BAM.Infrastructure.DataFlowLogging.Client;
using BAM.Infrastructure.Ioc;
using Ft;
using Google.Protobuf.Collections;
using Grpc.Core;
using Microsoft.Isam.Esent.Interop;
using Moq;
using NUnit.Framework;
using Fee = Ft.Fee;
using Order = Bam.Oms.Data.Orders.Order;
using Security = Ft.Security;
using Status = Grpc.Core.Status;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class FlexSubscriptionTests
    {
        [TestCase(OrderStatus.TRADABLE, BamOrderStatus.New)]
        [TestCase(OrderStatus.CANCELLED, BamOrderStatus.Cancelled)]
        [TestCase(OrderStatus.COMPLIANCE_FAILED, BamOrderStatus.Error)]
        [TestCase(OrderStatus.FILLED, BamOrderStatus.Filled)]
        [TestCase(OrderStatus.PARTIALLY_FILLED, BamOrderStatus.Working)]
        [TestCase(OrderStatus.REJECTED, BamOrderStatus.Error)]
        [TestCase(OrderStatus.STAGED, BamOrderStatus.New)]
        public void VerifyFlexStatusChanges(OrderStatus flexStatus,BamOrderStatus status)
        {
            // arrange
            var security = new Data.Securities.Security();
            security.BamSymbol = "IBM";

            var originalOrder = new Order();
            originalOrder.ClientOrderId = "123";
            originalOrder.Security = security;
                       
            var orderService = new Mock<OrderService.IOrderServiceClient>();
            orderService.Setup(s => s.Subscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()));

            var updateResponse = new OrderAndPositionUpdateResponse();
            var order = new OrderUpdateResponse();
            order.OrderId = "1234";
            order.FilledQuantity = 100;
            order.WeightedAvgPrice = 12;
            order.Status = flexStatus;

            updateResponse.Orders.Add(order);

            var subHost = new TradeSubscriptionHostFacade(orderService.Object);

            IOrder actual = null;
            subHost.IsSubscribe = true;
            subHost.TradeUpdated += delegate {  };
            subHost.OrderStatusChanged += orders =>
            {
                actual = orders.First();
            };
            
            // act
            subHost.NewItemHandler(updateResponse);

            // assert
            Assert.That(actual.OrderStatus, Is.EqualTo(status));
        }

        [TestCase(OrderStatus.TRADABLE, BamOrderStatus.Working)]
        [TestCase(OrderStatus.CANCELLED, BamOrderStatus.Cancelled)]
        [TestCase(OrderStatus.COMPLIANCE_FAILED, BamOrderStatus.Error)]
        [TestCase(OrderStatus.FILLED, BamOrderStatus.Filled)]
        [TestCase(OrderStatus.PARTIALLY_FILLED, BamOrderStatus.Working)]
        [TestCase(OrderStatus.REJECTED, BamOrderStatus.Error)]
        [TestCase(OrderStatus.STAGED, BamOrderStatus.New)]
        public void VerifyFlexStatusChangesWithStreetOrders(OrderStatus flexStatus, BamOrderStatus status)
        {
            // arrange
            var security = new Data.Securities.Security();
            security.BamSymbol = "IBM";

            var originalOrder = new Order();
            originalOrder.ClientOrderId = "123";
            originalOrder.Security = security;

            var orderService = new Mock<OrderService.IOrderServiceClient>();
            orderService.Setup(s => s.Subscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()));

            var updateResponse = new OrderAndPositionUpdateResponse();
            var order = new OrderUpdateResponse();
            order.OrderId = "1234";
            order.FilledQuantity = 100;
            order.WeightedAvgPrice = 12;
            order.Status = flexStatus;
            
            StreetOrderUpdateResponse streetOrder = new StreetOrderUpdateResponse();
            order.StreetOrders.Add(streetOrder);
            

            updateResponse.Orders.Add(order);

            var subHost = new TradeSubscriptionHostFacade(orderService.Object);

            IOrder actual = null;
            subHost.IsSubscribe = true;
            subHost.TradeUpdated += delegate { };
            subHost.OrderStatusChanged += orders =>
            {
                actual = orders.First();
            };

            // act
            subHost.NewItemHandler(updateResponse);

            // assert
            Assert.That(actual.OrderStatus, Is.EqualTo(status));
        }


        [Test]
        public void VerifyOrderStatusChangeRaiseEvent()
        {
            // arrange
            var security = new Data.Securities.Security {BamSymbol = "IBM", SecurityType = SecurityType.Equity};

            var originalOrder = new Order();
            originalOrder.ClientOrderId = "123";
            originalOrder.Security = security;
            originalOrder.OrderStatus = BamOrderStatus.New;

            var orderRepo = new Mock<IOrderRepository>();
            orderRepo.Setup(r => r.Get(It.IsAny<string>())).Returns(originalOrder);

            var subscription = new TradeSubscriptionHostFacade(new Mock<OrderService.IOrderServiceClient>().Object);

            var mockPositionHandler = new Mock<IListener>();

            var updateResponse = new OrderAndPositionUpdateResponse();
            var order = new OrderUpdateResponse();
            order.OrderId = "1234";
            order.FilledQuantity = 100;
            order.WeightedAvgPrice = 12;
            order.Status = OrderStatus.TRADABLE;

            updateResponse.Orders.Add(order);

            subscription.IsSubscribe = true;
            subscription.OrderStatusChanged += mockPositionHandler.Object.Action;

            // act
            subscription.NewItemHandler(updateResponse);

            // assert
            mockPositionHandler.Verify(l => l.Action(It.IsAny<IEnumerable<IOrder>>()));
        }

        [Test]
        public void VerifyHandlingPositionUpdate()
        {
            // arrange
            var mockStream = new Mock<IAsyncStreamReader<OrderAndPositionUpdateResponse>>();

            var orderService = new Mock<OrderService.IOrderServiceClient>();
            orderService.Setup(s => s.Subscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()));
            //.Returns(new AsyncServerStreamingCall<OrderAndPositionUpdateResponse>(mockStream.Object, null));

            var subscription = new TradeSubscriptionHostFacade(orderService.Object);
            
            var mockPositionHandler = new Mock<IListener>();

            var updateResponse = new OrderAndPositionUpdateResponse();
            var position = new PositionUpdateResponse();
            position.Account = "123";
            position.Symbol = "IBM";
            position.Quantity = 100;
            position.Fund = "ATQF";
            position.PrimeBroker = "CSFB";
            position.PrimeBrokerAccount = "12345";

            updateResponse.Positions.Add(position);

            subscription.IsSubscribe = true;
            subscription.PositionUpdated += mockPositionHandler.Object.Action;

            // act
            subscription.NewItemHandler(updateResponse);

            // assert
            mockPositionHandler.Verify(l => l.Action(It.IsAny<IEnumerable<IPosition>>()));
        }

        [Test]
        public void VerifyHandlingOrderUpdateFiresTradeUpdateEvent()
        {
            // arrange
            var security = new Data.Securities.Security();
            security.BamSymbol = "IBM";

            var originalOrder = new Order();
            originalOrder.ClientOrderId = "123";
            originalOrder.Security = security;

            var orderRepo = new Mock<IOrderRepository>();
            orderRepo.Setup(r => r.Get(It.IsAny<string>())).Returns(originalOrder);

            var mockStream = new Mock<IAsyncStreamReader<OrderAndPositionUpdateResponse>>();

            var orderService = new Mock<OrderService.IOrderServiceClient>();
            orderService.Setup(s => s.Subscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()));
            //                .Returns(new AsyncServerStreamingCall<OrderAndPositionUpdateResponse>(mockStream.Object, null));

            var subscription = new TradeSubscriptionHostFacade(orderService.Object);

            var mockPositionHandler = new Mock<IListener>();

            var updateResponse = new OrderAndPositionUpdateResponse();
            var order = new OrderUpdateResponse();
            order.OrderId = "1234";
            order.FilledQuantity = 100;
            order.WeightedAvgPrice = 12;
            order.Status = OrderStatus.TRADABLE;

            var streetOrder = new StreetOrderUpdateResponse();
            streetOrder.ExecutingBroker = "CSFB";
            streetOrder.FilledQuantity = 500;
            streetOrder.WeightedAvgPrice = 12;
            streetOrder.SettlementDate = "04/30/16";

            var allocation = new StreetOrderAllocationUpdateResponse();
            allocation.Fund = "ATQ";            
            allocation.FilledQuantity = 100;
            allocation.PrimeBroker = "CSFB";
            allocation.PositionGroup = "QIAN-GENERALIST";

            order.StreetOrders.Add(streetOrder);
            streetOrder.Allocations.Add(allocation);            
            updateResponse.Orders.Add(order);

            subscription.IsSubscribe = true;
            subscription.TradeUpdated += mockPositionHandler.Object.Action;

            // act
            subscription.NewItemHandler(updateResponse);

            // assert
            mockPositionHandler.Verify(l => l.Action(It.IsAny<IEnumerable<IBlockTrade>>()));
        }


        [Test]
        public void VerifyHandlingOrderUpdateParsesIntoTradeAllocations()
        {
            // arrange
            IList<IBlockTrade> trades = null;

            var security = new Data.Securities.Security();
            security.BamSymbol = "IBM";

            var security0 = new Data.Securities.Security();
            security0.BamSymbol = "AAPL";

            var originalOrder = new Order();
            originalOrder.ClientOrderId = "1234";
            originalOrder.Security = security;

            var originalOrder0 = new Order();
            originalOrder0.ClientOrderId = "456";
            originalOrder0.Security = security0;                                               

            var orderService = new Mock<OrderService.IOrderServiceClient>();
            orderService.Setup(s => s.Subscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()));            

            var subscription = new TradeSubscriptionHostFacade(orderService.Object);


            subscription.IsSubscribe = true;
            subscription.TradeUpdated += delegate(IEnumerable<IBlockTrade> t) {  }; //place holder  

            var updateResponse = new OrderAndPositionUpdateResponse();
            var order = new OrderUpdateResponse();
            order.OrderId = "1234";
            order.FilledQuantity = 100;            
            order.WeightedAvgPrice = 12;
            order.Status = OrderStatus.TRADABLE;

            var streetOrder = new StreetOrderUpdateResponse();
            streetOrder.ExecutingBroker = "CSFB";
            streetOrder.FilledQuantity = 100;
            streetOrder.WeightedAvgPrice = 12;
            streetOrder.SettlementDate = "04/30/16";

            var allocation = new StreetOrderAllocationUpdateResponse();
            allocation.Fund = "ATQ";            
            allocation.FilledQuantity = 100;
            allocation.PrimeBroker = "CSFB";
            allocation.PositionGroup = "QIAN-GENERALIST";

            var allocation1 = new StreetOrderAllocationUpdateResponse();
            allocation1.Fund = "ATQ";            
            allocation1.FilledQuantity = 100;
            allocation1.PrimeBroker = "GSCO";
            allocation1.PositionGroup = "QIAN-GENERALIST";

            var order0 = new OrderUpdateResponse();
            order0.OrderId = "456";
            order0.FilledQuantity = 100;
            order0.WeightedAvgPrice = 12;
            order0.Status = OrderStatus.TRADABLE;

            var streetOrder0 = new StreetOrderUpdateResponse();
            streetOrder0.ExecutingBroker = "CSFB";
            streetOrder0.FilledQuantity = 100;
            streetOrder0.WeightedAvgPrice = 12;
            streetOrder0.SettlementDate = "04/30/16";

            var allocation0 = new StreetOrderAllocationUpdateResponse();
            allocation0.Fund = "ATQ";            
            allocation0.FilledQuantity = 100;
            allocation0.PrimeBroker = "CSFB";
            allocation0.PositionGroup = "QIAN-GENERALIST";

            order.StreetOrders.Add(streetOrder);
            streetOrder.Allocations.Add(allocation);
            streetOrder.Allocations.Add(allocation1);

            order0.StreetOrders.Add(streetOrder0);
            streetOrder0.Allocations.Add(allocation0);

            updateResponse.Orders.Add(order);
            updateResponse.Orders.Add(order0);

            subscription.IsSubscribe = true;

            subscription.TradeUpdated += tradeCollection =>
            {
                trades = tradeCollection.ToList();
            };

            // act
            subscription.NewItemHandler(updateResponse);           


            // assert
            Assert.That(trades, Is.Not.Null);
            Assert.That(trades.Count, Is.EqualTo(2));

            var trade = trades.FirstOrDefault(c=>c.ClientOrderId.Equals("1234"));
            Assert.That(trade, Is.Not.Null);
            Assert.That(trade.ClientOrderId, Is.EqualTo("1234"));
            Assert.That(trade.TradedQuantity, Is.EqualTo(100));
            //Assert.That(trade.Security.BamSymbol, Is.EqualTo("IBM"));            
            Assert.That(trade.Portfolio.Strategy, Is.EqualTo("GENERALIST"));
            Assert.That(trade.Portfolio.PMCode, Is.EqualTo("QIAN"));
        }

        [Test]
        public void VerifyFlexOrderUpdateToTrade()
        {
            // arrange
            var order = new OrderUpdateResponse();

            order.OrderId = "1234";
            order.FilledQuantity = 100;            
            order.WeightedAvgPrice = 12.0000345d;
            order.Status = OrderStatus.FILLED;

            var allocation = new StreetOrderAllocationUpdateResponse();
            allocation.Fund = "ATQ";
            allocation.FilledQuantity = 100;
            allocation.PrimeBroker = "CSFB";
            allocation.PositionGroup = "QIAN-GENERALIST";
            allocation.Commissions = 15.25;
            allocation.Fees.Add(new Fee() { Total = 1.0, FeeName = "TestFee" });
            allocation.TotalFees = 1.0;

            var streetOrder = new StreetOrderUpdateResponse();
            streetOrder.ExecutingBroker = "CSFB";
            streetOrder.OrderId = "ABCD";
            streetOrder.SettlementDate = "04/30/16";
            streetOrder.Commissions = 15.25;
            streetOrder.Fees.Add(new Fee() { Total = 1.0, FeeName = "TestFee"});
            streetOrder.FilledQuantity = 100;
            streetOrder.Status = OrderStatus.FILLED;
            streetOrder.TotalFees = 1.0;
            streetOrder.WeightedAvgPrice = 12.0000345d;
            streetOrder.Quantity = 200;  
            streetOrder.Allocations.Add(allocation);         

            var security = new Data.Securities.Security();
            security.BamSymbol = "IBM";

            var originalOrder = new Mock<IOrder>();
            originalOrder.SetupGet(r => r.ClientOrderId).Returns("123");
            originalOrder.SetupGet(r => r.Security).Returns(security);

            order.StreetOrders.Add(streetOrder);

            var subscription = new TradeSubscriptionHost(new Mock<OrderService.IOrderServiceClient>().Object, new Mock<ILogger>().Object, new Mock<IGrpcChannel>().Object, new Mock<ISettings>().Object, new Mock<ILoggingAgent>().Object);
            
            // act
            var unit = subscription.Parse(order, originalOrder.Object);

            // assert
            Assert.IsNotNull(unit);            

            Assert.That(unit.ClientOrderId, Is.EqualTo("1234"));
            Assert.That(unit.TradedQuantity, Is.EqualTo(100));
            Assert.That(unit.AveragePrice, Is.EqualTo(12.0000345m));            
            Assert.That(unit.Portfolio.PMCode, Is.EqualTo("QIAN"));
            Assert.That(unit.Portfolio.Strategy, Is.EqualTo("GENERALIST"));
            Assert.That(unit.Security.BamSymbol, Is.EqualTo("IBM"));
            Assert.NotNull(unit.Allocations);
            Assert.AreEqual(1, unit.Allocations.Count);

            Allocation resultAllocation = unit.Allocations[0];

            Assert.AreEqual("CSFB", resultAllocation.PrimeBroker);
            Assert.AreEqual("CSFB", resultAllocation.CounterParty);
            Assert.AreEqual(100, resultAllocation.Quantity);
            Assert.NotNull(resultAllocation.Commissions);
            Assert.NotNull(resultAllocation.Fees);
        }

        [Test]
        public async void VerifyListenToUpdatesFiresNewItemHandler()
        {
            // arrange
            var helper = new SubscriptionHostHelper(new Mock<IGrpcChannel>().Object, new Mock<ISettings>().Object);
            var stream = new Mock<IAsyncStreamReader<string>>();
            stream.Setup(c => c.MoveNext(It.IsAny<CancellationToken>())).Returns(Task.FromResult(true));
            stream.Setup(c => c.Current).Returns("hello world!");

            // act
            var unit = await helper.ListenToPositionUpdates(stream.Object);

            // assert
            Assert.That(unit, Is.True);
            Assert.That(helper.Value, Is.EqualTo("hello world!"));
        }        
        
        [Test]
        public void VerifyListenToUpdatesThrowsOnCancel()
        {
            // arrange
            var helper = new SubscriptionHostHelper(new Mock<IGrpcChannel>().Object, new Mock<ISettings>().Object);
            helper.IsSubscribe = true;
            var stream = new Mock<IAsyncStreamReader<string>>();
            stream.Setup(c => c.MoveNext(It.IsAny<CancellationToken>())).Returns(Task.FromResult(true));
            stream.Setup(c => c.Current).Throws(new TaskCanceledException());

            // act
            Assert.Throws<AggregateException>(()=> helper.Listener(stream.Object));
        }

        [Test]
        public void VerifyUnsubscribeSetsIsSubscribedFlagOff()
        {
            // arrange
            var helper = new SubscriptionHostHelper(new Mock<IGrpcChannel>().Object, new Mock<ISettings>().Object);
            helper.IsSubscribe = true;

            // act
            helper.Unsubscribe();

            // assert
            Assert.That(helper.IsSubscribe, Is.False);
        }

        [Test]
        public void VerifyFlexSecurityToSecurityUpdate()
        {
            // arrange
            var commonData = new CommonSecurityData();
            commonData.BloombergSymbol = "IBM Equity";
            commonData.Ticker = "IBM";
            commonData.Cusip = "1234";
            commonData.Sedol = "456";
            commonData.Currency = "USD";
            commonData.Isin = "ISIN123";
            commonData.Description = commonData.LegalEntityName = "International Business Machines";
            commonData.FlexSecurityId = 123;
            commonData.Symbol = "IBM";
            commonData.SecurityType = "Equity";

            // not really covered yet
            commonData.Country = "US";
            commonData.CountryOfRisk = "US";
            commonData.ExchangeMIC = "NYSE";
            commonData.SettlementDays = 3;
            commonData.IsActive = true;
            commonData.IsExchangeTraded = true;
            commonData.IsPrivatePlacement = false;
            
            
            var flexSecurity = new Security();
            flexSecurity.CommonData = commonData;

            // act
            var unit = SecuritySubscriptionHost.Parse(flexSecurity);

            // assert
            Assert.That(unit.BloombergSymbol, Is.EqualTo("IBM Equity"));
            Assert.That(unit.Ticker, Is.EqualTo("IBM"));
            Assert.That(unit.Currency, Is.EqualTo("USD"));
            Assert.That(unit.Cusip, Is.EqualTo("1234"));
            Assert.That(unit.Sedol, Is.EqualTo("456"));
            Assert.That(unit.Isin, Is.EqualTo("ISIN123"));
            Assert.That(unit.Issuer, Is.EqualTo("International Business Machines"));
        }

        [Test]
        public void VerifyHandlingSecurityUpdate()
        {
            // arrange
            var commonData = new CommonSecurityData();
            commonData.BloombergSymbol = "IBM Equity";
            commonData.Ticker = "IBM";
            commonData.Cusip = "1234";
            commonData.Sedol = "456";
            commonData.Currency = "USD";
            commonData.Isin = "ISIN123";
            commonData.Description = commonData.LegalEntityName = "International Business Machines";
            commonData.FlexSecurityId = 123;
            commonData.Symbol = "IBM";
            commonData.SecurityType = "Equity";

            // not really covered yet
            commonData.Country = "US";
            commonData.CountryOfRisk = "US";
            commonData.ExchangeMIC = "NYSE";
            commonData.SettlementDays = 3;
            commonData.IsActive = true;
            commonData.IsExchangeTraded = true;
            commonData.IsPrivatePlacement = false;


            var flexSecurity = new Security();
            flexSecurity.CommonData = commonData;

            var response = new SecuritySubscriptionResponse();
            response.ResponseType = new SecurityResponseType();
            response.Security = flexSecurity;

            var mockStream = new Mock<IAsyncStreamReader<SecuritySubscriptionResponse>>();

            var securityService = new Mock<SecurityService.ISecurityServiceClient>();
            securityService.Setup(s => s.Subscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<Metadata>(), It.IsAny<DateTime?>(), It.IsAny<CancellationToken>()));

            var listener = new Mock<IListener>();

            var securitySubscriber = new SecuritySubscriptionHostFacade(securityService.Object);
            securitySubscriber.SecurityUpdated += listener.Object.Action;

            // act
            securitySubscriber.IsSubscribe = true; //keep the polling thread from turing on doing the test
            securitySubscriber.NewItemHandler(response);

            // assert
            listener.Verify(l => l.Action(It.IsAny<ISecurity>()));
        }

        [Category("Integration")]
        [Test]
        public void VerifyUnsubscribeCalledOnDispose()
        {
            // arrange
            var helper = new SubscriptionHostHelper(new Mock<IGrpcChannel>().Object, new Mock<ISettings>().Object);

            // act
            helper.DisposeSubscription();

            // assert
            Assert.That(helper.IsSubscribe, Is.False);
        }

        [Category("Integration")]
        [Test]
        public void VerifyUnsubscribeSecurityUpdates()
        {
            // arrange
            var mockStream = new Mock<IAsyncStreamReader<SecurityUnsubscribeResponse>>();

            var securityService = new Mock<SecurityService.ISecurityServiceClient>();
            securityService.Setup(s => s.Unsubscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<CallOptions>()));

            var securitySubscriber = new SecuritySubscriptionHostFacade(securityService.Object);

            // act
            securitySubscriber.DisposeSubscription();

            // assert
            securityService.Verify(l => l.Unsubscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<CallOptions>()));
        }

        [Category("Integration")]
        [Test]
        public void VerifyUnsubscribeOrderUpdates()
        {
            // arrange
            var mockStream = new Mock<IAsyncStreamReader<NullResponse>>();

            var orderService = new Mock<OrderService.IOrderServiceClient>();
            orderService.Setup(s => s.Unsubscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<CallOptions>()));

            var orderSubscriber = new TradeSubscriptionHostFacade(orderService.Object);

            // act
            orderSubscriber.DisposeSubscription();

            // assert
            orderService.Verify(l => l.Unsubscribe(It.IsAny<SubscriptionRequest>(), It.IsAny<CallOptions>()));
        }


        private class TradeSubscriptionHostFacade : TradeSubscriptionHost
        {
            public TradeSubscriptionHostFacade(OrderService.IOrderServiceClient orderService)
                : base(orderService, new Mock<ILogger>().Object, new Mock<IGrpcChannel>().Object, new Mock<ISettings>().Object, new Mock<ILoggingAgent>().Object)
            {
            }

            public new void NewItemHandler(OrderAndPositionUpdateResponse response)
            {
                base.NewItemHandler(response);
            }

            new public bool IsSubscribe
            {
                set { base.IsSubscribe = value; }
            }
        }

        private class SecuritySubscriptionHostFacade : SecuritySubscriptionHost
        {
            public SecuritySubscriptionHostFacade(SecurityService.ISecurityServiceClient securityServiceClient) : base(securityServiceClient, new Mock<ILogger>().Object, new Mock<IGrpcChannel>().Object,
                new Mock<ISettings>().Object, new Mock<ILoggingAgent>().Object)
            {
            }

            public new void NewItemHandler(SecuritySubscriptionResponse response)
            {
                base.NewItemHandler(response);
            }

            new public bool IsSubscribe
            {
                set { base.IsSubscribe = value; }
            }
        }

        public interface IListener
        {
            void Action(IEnumerable<IPosition> list);
            void Action(IEnumerable<IBlockTrade> list);
            void Action(ISecurity list);
            void Action(IEnumerable<IOrder> list);
        }

        public class SubscriptionHostHelper : SubscriptionHost<string>
        {
            public string Value { get; private set; }

            public bool Resubscribed { get; private set; }

            new public CancellationTokenSource CancellationTokenSource => base.CancellationTokenSource;

            protected override void NewItemHandler(string response)
            {
                Value = response;
            }

            new public bool IsSubscribe
            {
                get { return base.IsSubscribe; }
                set { base.IsSubscribe = value; }
            }

            public new void Unsubscribe()
            {
                base.Unsubscribe();
            }

            protected override void Resubscribe()
            {
                Resubscribed = true;
            }


            public new async Task<bool> ListenToPositionUpdates(IAsyncStreamReader<string> subscription)
            {
                return await base.ListenToPositionUpdates(subscription);
            }

            public new void Listener(IAsyncStreamReader<string> stream)
            {
                Subscribe(stream);
                base.Listener();
            }

            public SubscriptionHostHelper(IGrpcChannel channel, ISettings settings)
                : base(new Mock<ILoggingAgent>().Object, new Mock<ILogger>().Object, channel, settings)
            {
            }
        }
    }
}