﻿namespace Bam.EventQ.Journal
{
    public interface IFileArchive
    {
        void Archive(string sourcePath);
        void Archive(IJournal journal);
    }
}