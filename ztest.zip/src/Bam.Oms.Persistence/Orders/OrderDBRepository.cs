﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using BAM.Infrastructure.Ioc;
using Dapper;
using Microsoft.Practices.ObjectBuilder2;
using Newtonsoft.Json;

namespace Bam.Oms.Persistence.Orders
{
    public class OrderDBRepository : DBRepository<IOrder>, IOrderDBRepository
    {
        private readonly ISettings _settings;

        internal static readonly Func<dynamic, IOrder> ResultMap = item => new Order
        {
            ClientOrderId = item.ClientOrderId,
            OriginalOrderId = item.OriginalOrderId,
            BatchId = item.BatchId,
            Portfolio = (Portfolio)Portfolio.Parse(item.Portfolio),
            Security = new Security() { BamSymbol = item.Symbol, SecurityType = Enum.Parse(typeof(SecurityType), item.SecurityType, true) },
            Size = item.Size,
            Side = item.Side,
            Price = item.Price,
            OrderStatus = Enum.Parse(typeof(BamOrderStatus), item.OrderStatus, true),
            Trader = item.Trader,
            Custodian = item.Custodian,
            Locate = new[] { new Locate() { AssignmentId = item.AssignmentId, PrimeBroker = item.PrimeBroker, Rate = item.AssignedRate, RateType = Enum.Parse(typeof(RateType), item.RateType, true), Size = item.AssignedSize, TimeReceived = item.AssignemtnTimeReceived } },
            RoutedSize = item.RoutedSize,
            SettleDate = item.SettleDateId.ToString(),
            TradeDate = item.TradeDateId.ToString(),
            Note = item.Note,
            StatusMessages = JsonConvert.DeserializeObject(item.ComplianceFailures),
            ExecutionInstructions = JsonConvert.DeserializeObject(item.ExecutionInstructions),
            OrderTimeStamp = item.OrderTimeStamp
        };

        /// <summary>
        /// Function to map Trade fields to DB columns
        /// </summary>
        internal static readonly Func<IOrder, dynamic> ParameterMap = order => new
        {
            ClientOrderId = order.ClientOrderId,
            OriginalOrderId = order.OriginalOrderId,
            BatchId = order.BatchId,
            Portfolio = order.Portfolio.ToString(),
            Symbol = order.Security.BamSymbol,
            SecurityType = order.Security.SecurityType.ToString("F"),
            SymbolDesc = order.Security.ToString(),
            Size = order.Size,
            Side = order.Side,
            Price = order.Price,
            OrderStatus = order.OrderStatus.ToString("F"),
            Trader = order.Trader,
            Custodian = order.Custodian,
            PrimeBroker = order.Locate[0].PrimeBroker,
            AssignmentId = order.Locate[0].AssignmentId,
            AssignedSize = order.Locate[0].Size,
            AssignedRate = order.Locate[0].Rate,
            RateType = order.Locate[0].RateType?.ToString("F") ?? "",
            AssignmentTimeReceived = order.Locate[0].TimeReceived,
            RoutedSize = order.RoutedSize,
            SettleDateId = Int32.Parse(order.SettleDate.ToString("yyyyMMdd", System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
            TradeDateId = Int32.Parse(order.TradeDate.ToString("yyyyMMdd", System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
            Note = order.Note,
            ComplianceFailures = JsonConvert.SerializeObject(order.StatusMessages),
            ExecutionInstructions = JsonConvert.SerializeObject(order.ExecutionInstructions),
            OrderTimeStamp = order.OrderTimeStamp
        };

        protected override IDbConnection Connection => new SqlConnection(_settings.OrderGatewayConnectionString);

        public OrderDBRepository(ISettings settings, ILogger log) : base(settings, log, "dbo", "Order")
        {
            _settings = settings;
        }

        public override int Clear(DateTime cutOffTimeUtc)
        {
            throw new NotImplementedException("Cannot delete Order records throw this reposiroity. Directly delete in the database.");
        }

        public override int ClearAll()
        {
            return this.Clear(_settings.SODDateTime);
        }

        public override IEnumerable<IOrder> Get(DateTime cutoffTimeUtc)
        {
            //Database is local time. The implicit assumption is the database server and the application server are in the same local timezone.
            DateTime cutOffTimeLocal = cutoffTimeUtc.ToLocalTime();
            return base.Get("TradeTimeStamp >= @TradeTimeStamp", new { @TradeTimeStamp = cutOffTimeLocal }).ToList();
        }

        public override IOrder Get(string key)
        {
            return base.Get(new { ClientOrderId = key }).FirstOrDefault();
        }

        public override IOrder Save(IOrder order)
        {
            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();
                    IDbTransaction transaction = connection.BeginTransaction();
                    int recordCount = connection.Execute("dbo.usp_InsertOrder", new
                    {
                        ClientOrderId = order.ClientOrderId,
                        OriginalOrderId = order.OriginalOrderId,
                        BatchId = order.BatchId,
                        Portfolio = order.Portfolio.ToString(),
                        Symbol = order.Security.BamSymbol,
                        SecurityType = order.Security.SecurityType.ToString("F"),
                        SymbolDesc = order.Security.ToString(),
                        Size = order.Size,
                        Side = order.Side,
                        Price = order.Price,
                        OrderStatus = order.OrderStatus.ToString("F"),
                        Trader = order.Trader,
                        Custodian = order.Custodian,
                        ExternalStatus = order.OrderStatus.ToString("F"),
                        PrimeBroker = order.Locate != null && order.Locate.Count > 0 ? order.Locate[0].PrimeBroker : null,
                        AssignmentId = order.Locate != null && order.Locate.Count > 0 ? order.Locate[0].AssignmentId : null,
                        AssignedSize = order.Locate != null && order.Locate.Count > 0 ? order.Locate[0].Size : 0,
                        AssignedRate = order.Locate != null && order.Locate.Count > 0 ? order.Locate[0].Rate : 0,
                        RateType = order.Locate != null && order.Locate.Count > 0 ? order.Locate[0].RateType?.ToString("F") : null,
                        AssignmentTimeReceived = order.Locate != null && order.Locate.Count > 0 ? order.Locate[0].TimeReceived : DateTime.Now, //rl: not sure if this is null how to handle it                        
                        RoutedSize = order.RoutedSize,
                        SettleDateId = Int32.Parse(order.SettleDate.ToString("yyyyMMdd", System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
                        TradeDateId = Int32.Parse(order.TradeDate.ToString("yyyyMMdd", System.Globalization.CultureInfo.GetCultureInfo("en-US"))),
                        Note = order.Note,
                        ComplianceFailures = JsonConvert.SerializeObject(order.StatusMessages),
                        ExecutionInstructions = JsonConvert.SerializeObject(order.ExecutionInstructions),
                        OrderTimeStamp = order.OrderTimeStamp
                    }, commandType: CommandType.StoredProcedure, transaction: transaction);
                    if (recordCount == 1)
                    {
                        SaveStreetOrders(order, connection, transaction);
                        transaction.Commit();
                        return order;
                    }
                    transaction.Rollback();
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error saving order record.", ex);
                return null;
            }
            return null;
        }

        public override IEnumerable<IOrder> Save(IEnumerable<IOrder> items)
        {
            if (!items.Any()) return items;
            try
            {
                using (IDbConnection connection = Connection)
                {
                    connection.Open();
                    var itemsToInsert = new List<DynamicParameters>();
                    using (IDbTransaction transaction = connection.BeginTransaction())
                    {
                        foreach (var item in items)
                        {
                            var param = new DynamicParameters();
                            param.Add("@clientOrderId", value: item.ClientOrderId, dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@originalOrderId", value: item.OriginalOrderId, dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@batchId", value: item.BatchId, dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@portfolio", value: item.Portfolio.ToString(), dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@securityType", value: item.Security.SecurityType.ToString("F"),
                                dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@symbol", value: item.Security.BamSymbol, dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@symbolDesc", value: item.Security.ToString(), dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@size", value: item.Size, dbType: DbType.Decimal,
                                direction: ParameterDirection.Input);
                            param.Add("@side", value: item.Side.ToString("F"), dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@price", value: item.Price, dbType: DbType.Decimal,
                                direction: ParameterDirection.Input);
                            param.Add("@orderStatus", value: item.OrderStatus.ToString("F"), dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@trader", value: item.Trader, dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@custodian", value: item.Custodian, dbType: DbType.String,
                                direction: ParameterDirection.Input);

                            if (item.Locate != null && item.Locate.Count > 0)
                            {
                                if (item.Locate.Count > 1)
                                    _log.Warn(
                                        $"Order contains more than a single locate, only the first will be saved; order id {item.ClientOrderId}");

                                param.Add("@primeBroker", value: item.Locate[0].PrimeBroker, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@assignmentId", value: item.Locate[0].AssignmentId, dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@assignedSize", value: item.Locate[0].Size, dbType: DbType.Decimal,
                                    direction: ParameterDirection.Input);
                                param.Add("@assignedRate", value: item.Locate[0].Rate, dbType: DbType.Decimal,
                                    direction: ParameterDirection.Input);
                                param.Add("@rateType", value: item.Locate[0].RateType?.ToString("F") ?? "",
                                    dbType: DbType.String,
                                    direction: ParameterDirection.Input);
                                param.Add("@assignmentTimeReceived", value: item.Locate[0].TimeReceived,
                                    dbType: DbType.DateTime, direction: ParameterDirection.Input);
                            }

                            param.Add("@externalOrderStatus", value: item.OrderStatus.ToString("F"),
                                dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@routedSize", value: item.RoutedSize, dbType: DbType.Decimal,
                                direction: ParameterDirection.Input);
                            param.Add("@settleDateId",
                                value:
                                    Int32.Parse(item.TradeDate.ToString("yyyyMMdd",
                                        System.Globalization.CultureInfo.GetCultureInfo("en-US"))), dbType: DbType.Int32,
                                direction: ParameterDirection.Input);
                            param.Add("@tradeDateId",
                                value:
                                    Int32.Parse(item.TradeDate.ToString("yyyyMMdd",
                                        System.Globalization.CultureInfo.GetCultureInfo("en-US"))), dbType: DbType.Int32,
                                direction: ParameterDirection.Input);
                            param.Add("@note", value: item.Note, dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@complianceFailures", value: JsonConvert.SerializeObject(item.StatusMessages),
                                dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@executionInstructions",
                                value: JsonConvert.SerializeObject(item.ExecutionInstructions), dbType: DbType.String,
                                direction: ParameterDirection.Input);
                            param.Add("@orderTimeStamp", value: item.OrderTimeStamp, dbType: DbType.DateTime,
                                direction: ParameterDirection.Input);
                            itemsToInsert.Add(param);
                        }
                        int recordCount = connection.Execute("dbo.usp_InsertOrder", itemsToInsert,
                            commandType: CommandType.StoredProcedure, transaction:transaction);
                        if (recordCount == items.Count())
                        {
                            SaveStreetOrders(items, connection, transaction);
                            transaction.Commit();
                            return items;
                        }
                        transaction.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error saving order records.", ex);
                return new List<IOrder>();
            }
            return new List<IOrder>();
        }

        private int SaveStreetOrders(IOrder item, IDbConnection connection, IDbTransaction transaction)
        {
            var itemsToInsert = GetStreetOrdersToInsert(item);

            int streetOrderCount = connection.Execute("dbo.usp_InsertStreetOrder", itemsToInsert,
                commandType: CommandType.StoredProcedure, transaction: transaction);
            if (streetOrderCount != item.StreetOrders.Length)
            {
                _log.Warn(
                    $"[OrderId:{item.ClientOrderId}] - Only {streetOrderCount} street orders saved out of {item.StreetOrders.Length}.");
            }

            return streetOrderCount;
        }

        private int SaveStreetOrders(IEnumerable<IOrder> items, IDbConnection connection, IDbTransaction transaction)
        {
            List<DynamicParameters> dynamicParameters = new List<DynamicParameters>();
            foreach (var item in items)
            {
                dynamicParameters.AddRange(GetStreetOrdersToInsert(item));
            }

            int streetOrderCount = connection.Execute("dbo.usp_InsertStreetOrder", dynamicParameters,
                commandType: CommandType.StoredProcedure, transaction: transaction);
            if (streetOrderCount != dynamicParameters.Count)
            {
                _log.Warn(
                    $"Only {streetOrderCount} street orders saved out of {dynamicParameters.Count}.");
            }

            return streetOrderCount;
        }

        private static List<DynamicParameters> GetStreetOrdersToInsert(IOrder item)
        {
            var itemsToInsert = new List<DynamicParameters>();
            item.StreetOrders?.ForEach(streetOrder =>            
            {
                var param = new DynamicParameters();
                param.Add("@clientOrderId", value: streetOrder.ClientOrderId, dbType: DbType.String,
                    direction: ParameterDirection.Input);
                param.Add("@primeBroker", value: streetOrder.PrimeBroker, dbType: DbType.String,
                    direction: ParameterDirection.Input);
                param.Add("@streetOrderId", value: streetOrder.StreetOrderId, dbType: DbType.String,
                    direction: ParameterDirection.Input);
                param.Add("@executingBroker", value: streetOrder.ExecutingBroker, dbType: DbType.String,
                    direction: ParameterDirection.Input);
                param.Add("@portfolio", value: streetOrder.Portfolio.ToString(), dbType: DbType.String,
                    direction: ParameterDirection.Input);
                param.Add("@bamSymbol", value: streetOrder.Security.BamSymbol, dbType: DbType.String,
                    direction: ParameterDirection.Input);
                param.Add("@tradeDateId",
                    value:
                        Int32.Parse(streetOrder.TradeDate.ToString("yyyyMMdd",
                            System.Globalization.CultureInfo.GetCultureInfo("en-US"))), dbType: DbType.Int32,
                    direction: ParameterDirection.Input);
                param.Add("@side", value: streetOrder.Side.ToString("F"), dbType: DbType.String,
                    direction: ParameterDirection.Input);
                param.Add("@size", value: streetOrder.Size, dbType: DbType.Decimal,
                    direction: ParameterDirection.Input);
                param.Add("@filledQuantity", value: streetOrder.FilledQuantity, dbType: DbType.Decimal,
                    direction: ParameterDirection.Input);
                param.Add("@weightedAvgPrice", value: streetOrder.WeightedAvgPrice, dbType: DbType.Decimal,
                    direction: ParameterDirection.Input);
                itemsToInsert.Add(param);
            });

            return itemsToInsert;
        }
    }
}
