﻿using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Services.Allocation;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;
using Bam.Oms.OrderGateway.Messages;
using Bam.Oms.OrderGateway.Messages.Compliance;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public class PreValidationRule : EventRelay<IMessage>, IRule
    {
        private readonly IReferenceDataService _referenceDataService;
        private readonly long _maximumOrderSize;
        private readonly List<OrderAllocation> _allocations;

        public PreValidationRule(IReferenceDataService referenceDataService, long maximumOrderSize)
        {
            _referenceDataService = referenceDataService;
            _maximumOrderSize = maximumOrderSize;
            _allocations = new List<OrderAllocation>();
        }

        public string Name => "Pre-Validation";

        public void Execute(RuleContext context, List<RuleViolation> violations)
        {
            _allocations.Clear();

            if (context.Quantity <= 0)
            {
                AddFailure(violations,
                    $"Invalid order size {context.Quantity:N0}");
            }

            if (context.Quantity != context.Order.ClosingQuantity + context.Order.OpeningQuantity)
            {
                AddFailure(violations,
                    $"Opening {context.Order.OpeningQuantity:N0} / Closing {context.Order.ClosingQuantity:N0} quantities don't sum up to order size {context.Quantity:N0}");
            }

            if (context.Quantity > _maximumOrderSize)
            {
                AddFailure(violations,
                    $"Order exceeds maximum order size ({context.Quantity:N0} vs. {_maximumOrderSize:N0})");
            }

            long allocSum = 0;
            context.Order.GetAllocations(_allocations, _allocations);
            foreach (var alloc in _allocations)
            {
                allocSum += alloc.Quantity;
                if (alloc.Quantity <= 0 || 
                    alloc.ClosingPortionSansOmni > alloc.Quantity || 
                    alloc.ClosingPortionSansOmni < 0)
                {
                    AddFailure(violations,
                        $"Detected invalid order allocation: Quantity:{alloc.Quantity:N0}, Sans Omni:{alloc.ClosingPortionSansOmni:N0} (Portfolio:{alloc.Portfolio}/Fund:{alloc.FundId}/Custodian:{alloc.CustodianId}/Side:{alloc.Side})");
                }

                PortfolioDetails details;
                if (!_referenceDataService.TryGetPortfolioDetails(alloc.Portfolio, out details))
                {
                    AddFailure(violations,
                        $"Unknown portfolio '{alloc.Portfolio}'");
                }
                else
                {
                    if (details.AggregationUnit == null)
                    {
                        AddFailure(violations,
                            $"Aggregation unit is not populated for '{alloc.Portfolio}'");
                    }

                    if (details.ComplianceGroup == null)
                    {
                        AddFailure(violations,
                            $"Compliance group is not populated for '{alloc.Portfolio}'");
                    }

                    if (details.ReportingEntity == null)
                    {
                        AddFailure(violations,
                            $"Reporting entity is not populated for '{alloc.Portfolio}'");
                    }
                }
            }

            if (allocSum != context.Quantity)
            {
                AddFailure(violations,
                    $"Order allocations don't sum up to order quantity ({allocSum:N0} vs. {context.Quantity:N0})");
            }
        }

        private void AddFailure(List<RuleViolation> violations, string msg)
        {
            violations.Add(new RuleViolation
            {
                Message = msg,
                RuleName = Name,
                Status = ComplianceStatus.RuleFailure,
                Level = ComplianceViolationLevel.Restricted
            });
        }
    }
}
