﻿namespace Bam.Oms.Data.Enumerators
{
    public enum BamOrderStatus//Prelim status, most likely to be changed, but setting up for short locate status
    {
        /// <summary>
        /// Received in the Gateway, but has not been marked, and thus cannot be routed.
        /// </summary>
        PendingValidation,

        /// <summary>
        /// Indicates an order has been marked and added to our theoretical position
        /// </summary>
        Marked,

        /// <summary>
        /// Indicates an order is short and awaiting locate assignment
        /// </summary>
        PendingLocate,

        /// <summary>
        /// Indicates an order that is short and received incomplete locate, whether partial, or completely timeout/denied
        /// </summary>
        IncompleteLocate,

        /// <summary>
        /// State when the order received and Marked but not sent OMS/EMS. This includes orders not sent because of Locate issues.
        /// </summary>
        PendingSend,

        /// <summary>
        /// Order sent to Flex, Pending acknowledgment from Flex.
        /// </summary>
        PendingAck,

        /// <summary>
        /// Order failed validation or Flex rejected. Status message must show the detail.
        /// </summary>
        Error,

        /// <summary>
        /// Order passed compliance and is in workable/tradeable state in OMS. This includes Flex status TRADABLE, PARTIALLY_FILLED
        /// </summary>
        Working,

        /// <summary>
        /// An order cancel request is sent to FlexTrade and pending acknowledgment from FlexTrade
        /// </summary>
        PendingCancel,

        /// <summary>
        /// Cancelled order
        /// </summary>
        Cancelled,

        /// <summary>
        /// Indicates the order cannot be moved into a canceled state
        /// </summary>
        CancelReject,

        /// <summary>
        /// Order completely filled
        /// </summary> 
        Filled,         

        /// <summary>
        /// Trade has become immutable
        /// </summary>
        Finalized,

        /// <summary>
        /// Order has been accepted by EMS/OMS
        /// </summary>  
        New,
    }
}