﻿using System.Collections.Generic;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Compliance.DataProvider
{
    public interface ICustomDataProvider : IDataProvider
    {
        HashSet<string> GetEuExemptedIsins();
        HashSet<string> GetEuMonitoredIsins();
        string GetEntity(string strategy);
        decimal? GetSharesOutstanding(string symbol);
        bool IsEuExempted(string isin);
        IEnumerable<Constituent> GetConstituents(string symbol);
        IEnumerable<DtdPosition> GetEodPositions();
        IDictionary<string, IList<ISecurity>> LinkedSecurities { get; }
    }
}
