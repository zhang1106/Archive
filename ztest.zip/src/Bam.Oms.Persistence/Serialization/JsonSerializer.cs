﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Text;
using Newtonsoft.Json;

namespace Bam.Oms.Persistence.Serialization
{
    public class JsonSerializer : ISerializer
    {
        private readonly Newtonsoft.Json.JsonSerializer _serializer;

        public JsonSerializer()
        {
            _serializer = Newtonsoft.Json.JsonSerializer.Create(new JsonSerializerSettings
            {
                MissingMemberHandling = MissingMemberHandling.Ignore
            });
        }

        public byte[] Serialize<T>(T item)
        {
            using (var ms = new MemoryStream())
            {
                using (var writer = new StreamWriter(ms, Encoding.UTF8))
                using (var json = new JsonTextWriter(writer))
                {
                    try
                    {
                        _serializer.Serialize(json, item);
                        writer.Flush();
                    }
                    catch (Exception ex)
                    {
                        throw new SerializationException("Unable to serialize entity.", ex);
                    }
                }

                return ms.ToArray();
            }
        }

        public T Deserialize<T>(byte[] input)
        {
            return Deserialize<T>(input, 0, input.Length);
        }

        public T Deserialize<T>(byte[] input, int startIndex, int length)
        {
            using (var ms = new MemoryStream(input, startIndex, length))
            using (var reader = new StreamReader(ms, Encoding.UTF8))
            using (var json = new JsonTextReader(reader))
            {
                try
                {
                    return _serializer.Deserialize<T>(json);
                }
                catch (Exception ex)
                {
                    throw new SerializationException($"Unable to deserialize buffer of size {length} for entity {typeof(T).Name}.", ex);
                }
            }
        }

        public object Deserialize(byte[] input, int startIndex, int length, Type type)
        {
            using (var ms = new MemoryStream(input, startIndex, length))
            using (var reader = new StreamReader(ms, Encoding.UTF8))
            using (var json = new JsonTextReader(reader))
            {
                try
                {
                    return _serializer.Deserialize(json, type);
                }
                catch (Exception ex)
                {
                    throw new SerializationException($"Unable to deserialize buffer of size {length} for entity {type.Name}.", ex);
                }
            }
        }
    }
}
