using System;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public struct HeadroomCheckKey : IEquatable<HeadroomCheckKey>
    {
        public long OrderId { get; }
        public int RuleId { get; }

        public HeadroomCheckKey(long orderId, int ruleId)
        {
            OrderId = orderId;
            RuleId = ruleId;
        }

        public bool Equals(HeadroomCheckKey other)
        {
            return OrderId == other.OrderId && RuleId == other.RuleId;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is HeadroomCheckKey && Equals((HeadroomCheckKey) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (OrderId.GetHashCode() * 397) ^ RuleId;
            }
        }
    }
}