﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Bam.Oms.Messaging
{
    public class SignalRSessions<T> : ISignalRSessions<T>
    {
        private readonly ConcurrentDictionary<string, Func<T, bool>> _filters;

        public SignalRSessions()
        {
            _filters = new ConcurrentDictionary<string, Func<T, bool>>();
        }

        public void Add(string connectionId, Func<T, bool> filter)
        {
            _filters.AddOrUpdate(connectionId, key => filter, (key, old) => filter);

            var handler = NewSession;
            handler?.BeginInvoke(connectionId, handler.EndInvoke, null);
        }

        public void Remove(string connectionId)
        {
            Func<T, bool> fiter;
            _filters.TryRemove(connectionId, out fiter);
        }

        public IEnumerable<string> ConnectionIds => _filters.Keys.ToArray();

        public IEnumerable<T> Filter(IEnumerable<T> items, string connectionId)
        {
            Func<T, bool> filter;
            if (!_filters.TryGetValue(connectionId, out filter))
            {
                return Enumerable.Empty<T>();
            }

            return items.Where(filter).ToArray();
        }

        public IReadOnlyDictionary<string, IEnumerable<T>> Filter(IEnumerable<T> items)
        {
            var result = new Dictionary<string, IEnumerable<T>>();
            foreach (string connectionId in ConnectionIds)
            {
                result[connectionId] = Filter(items, connectionId);
            }

            return result;
        }

        public event Action<string> NewSession;
    }
}