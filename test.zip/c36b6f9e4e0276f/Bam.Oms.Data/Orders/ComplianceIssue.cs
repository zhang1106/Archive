﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data.Orders
{
    public class ComplianceIssue : ICloneable
    {
        public string Description { get; set; }
        public string Level { get; set; }
        public string RuleName { get; set; }
        public object Clone()
        {
            return new ComplianceIssue
            {
                Description = Description,
                Level = Level,
                RuleName = RuleName
            };
        }
    }
}
