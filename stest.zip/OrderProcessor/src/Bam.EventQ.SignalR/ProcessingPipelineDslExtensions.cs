using Bam.EventQ.Integration;
using Bam.EventQ.Pipeline.Dsl;
using Bam.EventQ.SignalR;
using Bam.EventQ.Sequencing;

// ReSharper disable once CheckNamespace
namespace Bam.EventQ.Pipeline
{
    public static class ProcessingPipelineDslExtensions
    {
        public static ProcessingPipelineStepDsl<TItem> ReceiveFromSignalR<TItem, TMsg>(
            this ProcessingPipelineStepDsl<TItem> step, string host, int port, string hubName,
            IExternalMessageTransform<TMsg[], TItem> transform)
        {
            var source = new SignalRExternalMessageSource<TMsg>(host, port, hubName);
            step.Pipeline.ObjectInitializer(source);

            var producer = new TransformingQueueItemProducer<TMsg[], TItem>(source,
                step.Pipeline.ObjectDecorator.Decorate(transform));
            step.Pipeline.ObjectInitializer(producer);

            step.AddProducer(producer);
            return step;
        }

        public static ProcessingPipelineStepDsl<IMessage> ReceiveFromSignalR<TMsg>(
            this ProcessingPipelineStepDsl<IMessage> step, string host, int port, string hubName,
            IExternalMessageTransform<TMsg[], IMessage> transform)
        {
            var source = new SignalRExternalMessageSource<TMsg>(host, port, hubName);
            step.Pipeline.ObjectInitializer(source);

            var producer = new TransformingQueueItemProducer<TMsg[]>(source,
                step.Pipeline.ObjectDecorator.Decorate(transform), step.GetQueueMessageDispatcher());
            step.Pipeline.ObjectInitializer(producer);

            step.AddProducer(producer);
            return step;
        }
    }
}
