﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Portfolios;

namespace Bam.Oms.RefData.OMS
{
    public class OrderScalePortfolioEqualityComparer : IEqualityComparer<IPortfolio>
    {
        public bool Equals(IPortfolio x, IPortfolio y)
        {
            return y.IsMatch(x);
        }

        public int GetHashCode(IPortfolio obj)
        {
            return obj.PMCode.GetHashCode();
        }
    }
}
