﻿namespace Bam.Oms.EndPoints
{
    public interface IRollClient : IFlowClient
    {
    }
}

