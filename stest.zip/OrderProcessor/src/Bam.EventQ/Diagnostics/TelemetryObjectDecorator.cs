﻿using System;
using Bam.EventQ.Pipeline.Dsl;
using Bam.EventQ.Queue;
using Bam.EventQ.Throttling;

namespace Bam.EventQ.Diagnostics
{
    public class TelemetryObjectDecorator : IObjectDecorator
    {
        private readonly ITelemetry _telemetry;
        private readonly TimeSpan _publishInterval;

        public TelemetryObjectDecorator(ITelemetry telemetry, TimeSpan publishInterval)
        {
            _telemetry = telemetry;
            _publishInterval = publishInterval;
        }

        private bool IsEnabled => _publishInterval != TimeSpan.Zero &&
                                  _publishInterval != TimeSpan.MaxValue &&
                                  _publishInterval != TimeSpan.MinValue;

        public T Decorate<T>(T obj)
        {
            var type = obj.GetType();
            if (!IsEnabled || (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(TimeInQueueHandler<>)))
                return obj;

            Type[] args;

            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(PipelineQueueItemHandlerChainDsl<>))
            {
                var t = type.GetGenericArguments()[0];
                var mi = type.GetMethod("AddHandler");
                var handler = Activator.CreateInstance(typeof(TimeInQueueHandler<>).MakeGenericType(t), 
                    _telemetry, _publishInterval);
                mi.Invoke(obj, new[] { handler });
                return obj;
            }

            if (ImplementsOpenGenericInterface(type, typeof(IQueueItemHandler<>), out args) &&
                typeof(T) == typeof(IQueueItemHandler<>).MakeGenericType(args))
            {
                var dt = typeof(TelemetryHandler<>).MakeGenericType(args);
                return (T) Activator.CreateInstance(dt, obj, _telemetry, _publishInterval);
            }

            if (ImplementsOpenGenericInterface(type, typeof(IQueue<>), out args) &&
                typeof(T) == typeof(IQueue<>).MakeGenericType(args))
            {
                var dt = typeof(TelemetryQueue<>).MakeGenericType(args);
                return (T)Activator.CreateInstance(dt, obj, _telemetry, _publishInterval);
            }

            if (ImplementsOpenGenericInterface(type, typeof(IQueueItemTransformer<,>), out args) &&
                typeof(T) == typeof(IQueueItemTransformer<,>).MakeGenericType(args))
            {
                var dt = typeof(TelemetryTransformer<,>).MakeGenericType(args);
                return (T)Activator.CreateInstance(dt, obj, _telemetry, _publishInterval);
            }

            if (ImplementsOpenGenericInterface(type, typeof(IThrottledBatchHandler<>), out args) &&
                typeof(T) == typeof(IThrottledBatchHandler<>).MakeGenericType(args))
            {
                var dt = typeof(TelemetryThrottledBatchHandler<>).MakeGenericType(args);
                return (T)Activator.CreateInstance(dt, obj, _telemetry);
            }

            return obj;
        }

        public static bool ImplementsOpenGenericInterface(Type candidateType, Type openGenericInterfaceType, out Type[] genericTypeArgs)
        {
            if (candidateType == openGenericInterfaceType)
            {
                genericTypeArgs = candidateType.GetGenericArguments();
                return true;
            }

            if (candidateType.IsGenericType && candidateType.GetGenericTypeDefinition() == openGenericInterfaceType)
            {
                genericTypeArgs = candidateType.GetGenericArguments();
                return true;
            }

            foreach (var iface in candidateType.GetInterfaces())
            {
                if (iface.IsGenericType &&
                    ImplementsOpenGenericInterface(iface, openGenericInterfaceType, out genericTypeArgs))
                {
                    return true;
                }
            }

            genericTypeArgs = null;
            return false;
        }
    }
}
