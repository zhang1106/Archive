﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.EndPoints.File
{
    internal class OrderRecord
    {
        //Prt,Security,Side,Amount,Cust,TAlpha2,Manager
        public Portfolio Portfolio { get; set; }        
        public Security Security { get; set; }
        public SideType Side { get; set; }
        public decimal Quantity { get; set; }
        public string PrimeBroker { get; set; }
        public string PrimeBrokerAccount { get; set; }
        public string Fund { get; set; }
        public string GroupingKey { get; set; }
        public string ExecutionInstructions { get; set; }

        public Urgency Urgency { get; set; }

    }
}
