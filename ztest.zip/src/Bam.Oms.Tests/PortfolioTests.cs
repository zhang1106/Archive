﻿using System;
using Bam.Oms.Data;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using NUnit.Framework;

namespace Bam.Oms.Tests
{
    [TestFixture]
    public class PortfolioTests
    {
        [TestFixtureSetUp]
        public void Initialize()
        {
            
        }

        [Test]
        public void TestToString()
        {
            IPortfolio portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            string portfolioString = portfolio.ToString();
            Assert.AreEqual("MYPORT-MYSTRATEGY-MYSUBSTRATEGY", portfolioString);

            portfolio = new Portfolio("MYPORT", "MYSTRATEGY");
            portfolioString = portfolio.ToString();
            Assert.AreEqual("MYPORT-MYSTRATEGY", portfolioString);

            portfolio = new Portfolio("MYPORT");
            portfolioString = portfolio.ToString();
            Assert.AreEqual("MYPORT", portfolioString);
        }

        [Test]
        public void TestParse()
        {
            IPortfolio portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            string portfolioString = "MYPORT-MYSTRATEGY-MYSUBSTRATEGY";
            IPortfolio newPortfolio = Portfolio.Parse(portfolioString);
            Assert.AreEqual(portfolio, newPortfolio);

            portfolio = new Portfolio("MYPORT", "MYSTRATEGY");
            portfolioString = "MYPORT-MYSTRATEGY";
            newPortfolio = Portfolio.Parse(portfolioString);
            Assert.AreEqual(portfolio, newPortfolio);

            portfolio = new Portfolio("MYPORT");
            portfolioString = "MYPORT";
            newPortfolio = Portfolio.Parse(portfolioString);
            Assert.AreEqual(portfolio, newPortfolio);

            Assert.AreEqual(portfolio, portfolio);

            Assert.IsNull(Portfolio.Parse(null));
            Assert.IsNull(Portfolio.Parse(""));
        }
     

        [Test]
        public void VerifyHashCode()
        {
            // arrange
            IPortfolio portfolio2 = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");

            IPortfolio portfolio = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");

            // act
            var unit = portfolio.GetHashCode().Equals(portfolio2.GetHashCode());

            // assert
            Assert.That(unit, Is.True);
        }

        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "TRAT", "SUB", false)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "MYSTRAT", "MYSUB", false)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "MYSTRAT*", "MYSUB*", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "*", "*", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "?YSTRATEGY", "*", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "", "", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "PORT", "", "", false)]
        public void TestIsMatch(string pmCode1, string strategy1, string substrategy1, string pmCode2, string strategy2, string substrategy2, bool expected)
        {
            // arrange
            IPortfolio portfolio1 = new Portfolio(pmCode1, strategy1, substrategy1);
            IPortfolio portfolio2 = new Portfolio(pmCode2, strategy2, substrategy2);            

            bool isMatch = portfolio1.IsMatch(portfolio2);
            Assert.IsTrue(isMatch == expected);            
        }

        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "TRAT", "SUB", false)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "MYSTRAT", "MYSUB", false)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "MYSTRAT*", "MYSUB*", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "*", "*", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "?YSTRATEGY", "*", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "", "", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "PORT", "", "", false)]
        public void TestCompareTo(string pmCode1, string strategy1, string substrategy1, string pmCode2, string strategy2, string substrategy2, bool expected)
        {
            // arrange
            IPortfolio portfolio1 = new Portfolio(pmCode1, strategy1, substrategy1);
            IPortfolio portfolio2 = new Portfolio(pmCode2, strategy2, substrategy2);

            var isMatch = portfolio1.CompareTo(portfolio2);
            Assert.IsTrue( expected == (isMatch == 0));
        }

        [TestCase("MYPORT", null, null, "MYPORT", null, null, true)]
        [TestCase("MYPORT", "MYSTRATEGY", null, "MYPORT", "MYSTRATEGY", null, true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", true)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", "MYSTRATEGY", null, false)]
        [TestCase("MYPORT", "MYSTRATEGY", null, "MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", false)]
        [TestCase("MYPORT", null, null, "MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", false)]
        [TestCase("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY", "MYPORT", null, null, false)]
        [TestCase("MYPORT", null, null, "MYPORT", "MYSTRATEGY", null, false)]
        [TestCase("MYPORT", "MYSTRATEGY", null, "MYPORT", null, null, false)]
        public void TestEquals(string pmCode1, string strategy1, string substrategy1, string pmCode2, 
            string strategy2, string substrategy2, bool expected)
        {
            // arrange
            IPortfolio portfolio1 = new Portfolio(pmCode1, strategy1, substrategy1);
            IPortfolio portfolio2 = new Portfolio(pmCode2, strategy2, substrategy2);

            var unit = portfolio1.Equals(portfolio2);
            Assert.That(unit, Is.EqualTo(expected));
        }


        [Test]
        public void TestTupleEquals()
        {
            // arrange
            IPortfolio portfolio1 = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            ISecurity security1 = new Security() {BamSymbol = "MYSYMBOL"};

            IPortfolio portfolio2 = new Portfolio("MYPORT", "MYSTRATEGY", "MYSUBSTRATEGY");
            ISecurity security2 = new Security() { BamSymbol = "MYSYMBOL" };

            Tuple<IPortfolio, ISecurity> key1 = new Tuple<IPortfolio, ISecurity>(portfolio1, security1);
            Tuple<IPortfolio, ISecurity> key2 = new Tuple<IPortfolio, ISecurity>(portfolio2, security2);

            Assert.AreEqual(key1, key2);
        }
    }
}
