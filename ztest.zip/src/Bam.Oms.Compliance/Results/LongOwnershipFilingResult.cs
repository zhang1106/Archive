﻿using Newtonsoft.Json;
using Bam.Oms.Data.Compliance;

namespace Bam.Oms.Compliance.Results
{
    [JsonObject(MemberSerialization.OptIn)]
    public class LongOwnershipFilingResult : RuleResult 
    {
        [JsonProperty]
        public decimal? Ratio { get; set; }
        [JsonProperty]
        public decimal? LowLimit { get; set; }
        [JsonProperty]
        public decimal? SharesOutstanding { get; set; }
        public override string ToString()
        {
            return
                $"Policly:{PolicyId},RuleName:{RuleName},Ratio:{Ratio},LowLimit:{LowLimit},PositionQty:{PositionQty},SharesOutstanding:{SharesOutstanding}";
        }
    }
}
