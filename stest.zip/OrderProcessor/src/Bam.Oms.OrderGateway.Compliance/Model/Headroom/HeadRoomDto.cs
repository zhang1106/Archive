﻿namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    public class HeadRoomDto
    {
        public int RuleId { get; set; }
        public string Identifier { get; set; }
        public string RuleName { get; set; }
        public string IdentifierType { get; set; }
        public bool IsExempt { get; set; }
        public string Direction { get; set; }
        public string ReportingEntity { get; set; }
        public decimal Threshold { get; set; }
        public long Headroom { get; set; }
        public string AlertLevel { get; set; }
        public bool FireOnce { get; set; }
        public long IntradayQuantity { get; set; }
    }
}