﻿using System;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class Portfolio : ICloneable
    {
        public string PMCode { get; set; }
        public string Strategy { get; set; }
        public string SubStrategy { get; set; }
        public string AggregationUnit { get; set; }
        public string ComplianceGroup { get; set; }
        public string AllocationScheme { get; set; }

        public override string ToString()
        {
            return SubStrategy == null
                ? $"{PMCode}-{Strategy}"
                : $"{PMCode}-{Strategy}-{SubStrategy}";
        }

        public object Clone()
        {
            return new Portfolio
            {
                Strategy = Strategy,
                PMCode = PMCode,
                SubStrategy = SubStrategy,
                ComplianceGroup = ComplianceGroup,
                AggregationUnit = AggregationUnit,
                AllocationScheme = AllocationScheme
            };
        }

        public static Portfolio Parse(string portfolioString)
        {
            string pmCode, strategy, subStrategy;
            if (!Infrastructure.Portfolio.TryParse(
                portfolioString, out pmCode, out strategy, out subStrategy))
            {
                return null;
            }

            return new Portfolio
            {
                PMCode = pmCode,
                Strategy = strategy,
                SubStrategy = subStrategy
            };
        }

        public bool Matches(Portfolio portfolio)
        {
            return portfolio != null &&
                   PMCode == portfolio.PMCode &&
                   (string.IsNullOrEmpty(portfolio.Strategy) ||
                    Strategy == portfolio.Strategy) &&
                   (string.IsNullOrEmpty(portfolio.SubStrategy) ||
                    SubStrategy == portfolio.SubStrategy);
        }
    }
}
