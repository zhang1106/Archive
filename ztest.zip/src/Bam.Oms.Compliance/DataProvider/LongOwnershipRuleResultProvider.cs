﻿using Newtonsoft.Json;
using Bam.Oms.Persistence.Compliance;
using Bam.Oms.Data.Compliance;
using Bam.Oms.Compliance.Results;

namespace Bam.Oms.Compliance.DataProvider
{
    public class LongOwnershipRuleResultProvider : ILongOwnershipRuleResultProvider
    {
        readonly IRuleResultRepository _resultResultRepository;
        public LongOwnershipRuleResultProvider(IRuleResultRepository resultResultRepository)
        {
            _resultResultRepository = resultResultRepository;
        }
        public IRuleResult GetRuleResult(int policyId, int ruleId, string bamSymbol)
        {
            RuleResult result = _resultResultRepository.Get(RuleResult.FormatKey(policyId, ruleId, bamSymbol));
            return result;
        }
        public decimal? GetRatio(int policyId, int ruleId, string bamSymbol)
        {
            var lResult = GetLongOwnershipRuleResult(policyId, ruleId, bamSymbol);
            return lResult?.Ratio;
        }
        public decimal? GetLowLimit(int policyId, int ruleId, string bamSymbol)
        {
            var lResult = GetLongOwnershipRuleResult(policyId, ruleId, bamSymbol);
            return lResult?.LowLimit;
        }
        public bool GetIsRuleOverriden(int policyId, int ruleId, string bamSymbol)
        {
            var result = _resultResultRepository.Get(RuleResult.FormatKey(policyId, ruleId, bamSymbol));
            return result?.IsViolationOverriden ?? true;
        }
        private LongOwnershipFilingResult GetLongOwnershipRuleResult(int policyId, int ruleId, string bamSymbol)
        {
            var result = _resultResultRepository.Get(RuleResult.FormatKey(policyId, ruleId, bamSymbol));
            if (result == null) { return null; }
            var lResult = new LongOwnershipFilingResult();
            JsonConvert.PopulateObject(result.ParamsInJson, lResult);
            return lResult;
        }
    }
}
