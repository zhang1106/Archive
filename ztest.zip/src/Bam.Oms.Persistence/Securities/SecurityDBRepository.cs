﻿using System;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using Dapper;
using BAM.Infrastructure.Ioc;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Filtering;

namespace Bam.Oms.Persistence.Securities
{
    public class SecurityDBRepository: DBRepository<Security>, ISecurityDBRepository
    {
        internal static readonly Func<dynamic, Security> ResultMap = item => new Security
        {
            BamSymbol = item.DisplayCode,
            Country = item.Countrycode,
            Currency = item.TradingCurrencyCode,
            UnderlyingSymbol = item.UnderlyingSymbol ,
            Isin = item.ISIN,
            Cusip = item.Cusip,
            Industry = item.Gics_Industry,
            ContractSize = item.ContractSize,
            SecurityType =
                   Enum.IsDefined(typeof(SecurityType), item.AssetTypeCode)
                       ? Data.Utility.ConvertEnum<SecurityType>(item.AssetTypeCode)
                       : default(SecurityType),
            OptionType = item.OptionType == null ? OptionType.None : Data.Utility.ConvertEnum<OptionType>(item.OptionType?"Put":"Call"),
            InvestmentType = item.InvestmentTypeCode
        };

        private readonly string _securitiesQuery = @"Select * From
                                                      OpenQuery([dw-db],
                                                      'SELECT 
                                                      s0.[DisplayCode]
                                                     ,AssetTypeCode = Case 
                                                                      When s0.AssetTypeCode = ''Option'' and s1.AssetTypeCode = ''Equity'' Then ''EquityOption''
                                                                      When s0.AssetTypeCode = ''Swap'' and s1.AssetTypeCode = ''Equity'' Then ''EquitySwap''
                                                                      Else s0.AssetTypeCode
                                                                      End
                                                     ,s0.[Countrycode]
	                                                 ,UnderlyingSymbol = isnull(s1.[displaycode], s0.[displaycode])
                                                     ,s0.TradingCurrencyCode
                                                     ,s0.ContractSize
                                                     ,OptionType = s0.[Option_PutCall]
                                                     ,s0.ISIN
                                                     ,s0.Cusip
                                                     ,s0.GICS_Industry
                                                     ,s0.InvestmentTypeCode
                                                  FROM [BamCoreLite].[sm].[Security] s0
                                                  Left Join [BamCoreLite].[sm].[Security] (nolock) s1 on  s0.underLyINGsecurityid = s1.securityid
                                                  ')";
            
        private readonly ISettings _settings;
        
        public SecurityDBRepository(ISettings settings, ILogger logger) : base(settings, logger, "sm", "[Security]", ResultMap, null)
        {
            _settings = settings;
        }

        protected override IDbConnection Connection => new SqlConnection(_settings.OrderGatewayConnectionString);

        public IEnumerable<Security> GetSecurities(IFilter<ISecurity> filter)
            {
            try
            {
                using (var cn = Connection)
                {
                    cn.Open();
                    var result = cn.Query<dynamic>(_securitiesQuery).Select(ResultMap);
                    return result.Where(s=>filter.ApplyFilter(string.Empty,s));
                }
            }
            catch (Exception e)
            {
                _log.Error("Error occurred while retrieving records from BamCorelite Security", e);
                throw;
            }
        }
    }
}
