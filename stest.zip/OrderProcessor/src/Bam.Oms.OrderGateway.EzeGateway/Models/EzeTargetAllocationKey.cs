﻿using System;

namespace Bam.Oms.OrderGateway.EzeGateway.Models
{
    public struct EzeTargetAllocationKey : IEquatable<EzeTargetAllocationKey>
    {
        public bool Equals(EzeTargetAllocationKey other)
        {
            return FundId == other.FundId && 
                   CustodianId == other.CustodianId &&
                   string.Equals(Portfolio, other.Portfolio);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (obj.GetType() != GetType()) return false;
            return Equals((EzeTargetAllocationKey) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = Portfolio?.GetHashCode() ?? 0;
                hashCode = (hashCode*397) ^ FundId;
                hashCode = (hashCode*397) ^ CustodianId;
                return hashCode;
            }
        }

        public static bool operator ==(EzeTargetAllocationKey left, EzeTargetAllocationKey right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(EzeTargetAllocationKey left, EzeTargetAllocationKey right)
        {
            return !Equals(left, right);
        }

        public string Portfolio { get; set; }
        public int FundId { get; set; }
        public int CustodianId { get; set; }
    }
}
