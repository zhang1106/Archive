﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Bam.Oms.Persistence.Serialization;

namespace Bam.Oms.Persistence.Journal
{
    public class FlatFileEventJournal : IEventJournal, IDisposable
    {
        private readonly string _path;
        private readonly ISerializer _serializer;
        private readonly SemaphoreSlim _lock = new SemaphoreSlim(1, 1);
        private FileStream _writeStream;
        private volatile bool _disposed;
        private readonly byte[] _writeBuffer = new byte[1024];

        private const int MaxLength = 100 * 1024; // 100kb

        public FlatFileEventJournal(string path, ISerializer serializer)
        {
            _path = path;
            _serializer = serializer;
        }

        public Task AppendAsync(object item)
        {
            EnsureWriteStream();

            var buffer = _serializer.Serialize(item);
            if (buffer.Length > MaxLength)
            {
                throw new ArgumentException("item exceeds 100kb size limit.");
            }

            _lock.Wait();
            try
            {
                WriteItem(_writeStream, DateTime.UtcNow, item.GetType().AssemblyQualifiedName, buffer);
                _writeStream.Flush();
            }
            finally
            {
                _lock.Release();
            }

            return Task.FromResult(0);
        }

        public Task AppendAsync(IReadOnlyList<object> items)
        {
            EnsureWriteStream();

            var buffers = new byte[items.Count][];
            Parallel.For(0, items.Count, i =>
            {
                buffers[i] = _serializer.Serialize(items[i]);
            });

            if (buffers.Any(b => b.Length > MaxLength))
            {
                throw new ArgumentException("item exceeds 100kb size limit.");
            }

            _lock.Wait();
            try
            {
                var now = DateTime.UtcNow;
                for (int i = 0; i < items.Count; i++)
                {
                    WriteItem(_writeStream, now, items[i].GetType().AssemblyQualifiedName, buffers[i]);
                }

                _writeStream.Flush();
            }
            finally
            {
                _lock.Release();
            }

            return Task.FromResult(0);
        }

        public Task TruncateAsync()
        {
            return TruncateAsync(DateTime.MaxValue);
        }

        public Task TruncateAsync(DateTime beforeUtc)
        {
            EnsureWriteStream();

            _lock.Wait();
            try
            {
                _writeStream.Seek(0, SeekOrigin.Begin);

                var toKeep = new LinkedList<KeyValuePair<DateTime, object>>();
                foreach (var item in ReadFromStream(_writeStream))
                {
                    if (item.Key > beforeUtc)
                    {
                        toKeep.AddLast(item);
                    }
                }

                _writeStream.SetLength(0);
                foreach (var item in toKeep)
                {
                    WriteItem(_writeStream, item.Key, item.Value.GetType().AssemblyQualifiedName, _serializer.Serialize(item.Value));
                }

                _writeStream.Flush();
            }
            finally
            {
                _lock.Release();
            }

            return Task.FromResult(0);
        }

        public Task<IReadOnlyList<KeyValuePair<DateTime, object>>> RetrieveAsync()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException("Event Journal");
            }

            var items = new LinkedList<KeyValuePair<DateTime, object>>();
            using (var stream = new FileStream(_path, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite))
            {
                foreach (var item in ReadFromStream(stream))
                {
                    items.AddLast(item);
                }
            }

            var result = new KeyValuePair<DateTime, object>[items.Count];
            items.CopyTo(result, 0);

            return Task.FromResult<IReadOnlyList<KeyValuePair<DateTime, object>>>(result);
        }

        public void Dispose()
        {
            _lock.Wait();
            try
            {
                _writeStream?.Dispose();
                _writeStream = null;
                _disposed = true;
            }
            finally
            {
                _lock.Release();
            }
        }

        private void GuardRead(FileStream stream, byte[] buffer, int bytesToRead)
        {
            if (stream.Position + bytesToRead > stream.Length)
                throw new InvalidDataException();
            stream.Read(buffer, 0, bytesToRead);
        }

        private void EnsureWriteStream()
        {
            if (_writeStream == null)
            {
                _lock.Wait();
                try
                {
                    if (_disposed)
                    {
                        throw new ObjectDisposedException("Event Journal");
                    }

                    if (_writeStream == null)
                    {
                        _writeStream = new FileStream(_path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
                        PerformSanityCheck(_writeStream);
                    }
                }
                finally
                {
                    _lock.Release();
                }
            }
        }

        private void PerformSanityCheck(FileStream stream)
        {
            foreach (var kvp in ReadFromStream(stream))
            {
                // nothing, just read and move the file cursor to last
                // good position for appending new items
            }
        }

        private KeyValuePair<DateTime, object> ReadItem(FileStream stream, byte[] buffer)
        {
            GuardRead(stream, buffer, 8);
            long ticks = BitConverter.ToInt64(buffer, 0);
            var dateTime = new DateTime(ticks);

            GuardRead(stream, buffer, 4);
            int typeNameLength = BitConverter.ToInt32(buffer, 0);
            if (typeNameLength > MaxLength)
                throw new InvalidDataException();

            GuardRead(stream, buffer, typeNameLength);
            string typeName = Encoding.UTF8.GetString(buffer, 0, typeNameLength);
            var type = Type.GetType(typeName);

            GuardRead(stream, buffer, 4);
            int dataLength = BitConverter.ToInt32(buffer, 0);
            if (dataLength > MaxLength)
                throw new InvalidDataException();

            GuardRead(stream, buffer, dataLength);

            return new KeyValuePair<DateTime, object>(
                dateTime, _serializer.Deserialize(buffer, 0, dataLength, type));
        }

        private IEnumerable<KeyValuePair<DateTime, object>> ReadFromStream(FileStream stream)
        {
            byte[] buffer = new byte[MaxLength];
            long lastGood = 0;
            while (stream.Position < stream.Length)
            {
                KeyValuePair<DateTime, object> item;
                try
                {
                    item = ReadItem(stream, buffer);
                    lastGood = stream.Position;
                }
                catch (SerializationException)
                {
                    // file corrupted from this point on
                    stream.Seek(lastGood, SeekOrigin.Begin);
                    break;
                }
                catch (InvalidDataException)
                {
                    // file corrupted from this point on
                    stream.Seek(lastGood, SeekOrigin.Begin);
                    break;
                }
                
                yield return item;
            }
        }

        private void WriteItem(FileStream stream, DateTime eventTime, string typeName, byte[] data)
        {
            //have one copy each day
            eventTime = eventTime.Date;

            var buffer = _writeBuffer;

            new LongByte { LongVal = eventTime.Ticks }.CopyTo(buffer, 0);
            int index = Encoding.UTF8.GetBytes(typeName, 0, typeName.Length, buffer, 12);
            new IntByte { IntVal = index }.CopyTo(buffer, 8);
            new IntByte { IntVal = data.Length }.CopyTo(buffer, 12 + index);

            stream.Write(buffer, 0, 12 + index + 4);
            stream.Write(data, 0, data.Length);
        }

        [StructLayout(LayoutKind.Explicit)]
        struct IntByte
        {
            [FieldOffset(0)]
            public int IntVal;

            public void CopyTo(byte[] buffer, int index)
            {
                GCHandle h = default(GCHandle);
                try
                {
                    h = GCHandle.Alloc(buffer, GCHandleType.Pinned);
                    Marshal.StructureToPtr(this, h.AddrOfPinnedObject() + index, false);
                }
                finally
                {
                    if (h.IsAllocated)
                    {
                        h.Free();
                    }
                }
            }
        }

        [StructLayout(LayoutKind.Explicit)]
        struct LongByte
        {
            [FieldOffset(0)]
            public long LongVal;

            public void CopyTo(byte[] buffer, int index)
            {
                GCHandle h = default(GCHandle);
                try
                {
                    h = GCHandle.Alloc(buffer, GCHandleType.Pinned);
                    Marshal.StructureToPtr(this, h.AddrOfPinnedObject() + index, false);
                }
                finally
                {
                    if (h.IsAllocated)
                    {
                        h.Free();
                    }
                }
            }
        }
    }
}
