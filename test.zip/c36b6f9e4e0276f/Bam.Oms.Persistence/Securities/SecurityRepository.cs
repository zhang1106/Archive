﻿using BAM.Infrastructure.Ioc;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Securities;

namespace Bam.Oms.Persistence.Securities
{
    public class SecurityRepository : PersistentRepository<Security>, ISecurityRepository
    {        
        public SecurityRepository(ILogger log, ISettings settings) : base("SecurityCache", log)
        {            
        }        
    }
}
