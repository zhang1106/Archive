﻿using System;
using System.Collections.Generic;

namespace Bam.EventQ.Journal
{
    public interface IJournal : IDisposable
    {
        string Path { get; }
        void Append(byte[] buffer, int index, int count);
        void AppendMarker(int marker);
        void Flush();
        void Truncate();
        void Truncate(string archivePath);
        IEnumerable<int> RetrieveMarkers();
        IEnumerable<byte[]> Retrieve();
    }
}
