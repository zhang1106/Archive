﻿using System;
using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.Compliance.Services.Allocation
{
    public abstract class AllocationServiceBase
    {
        protected void FixProRatedRoundingIssues<TKey, TItem>(
            List<TItem> items, 
            Func<TItem, TKey> keyFunc,
            Func<TItem, long> valueFunc,
            Dictionary<TKey, long> proRated,
            Dictionary<TKey, long> targets,
            IComparer<TItem> descendingSorter,
            Func<TItem, long, TItem> adjustmentFunc) 
        {
            proRated.Clear();
            foreach (var item in items)
            {
                long current;
                var key = keyFunc(item);
                var value = valueFunc(item);
                if (!proRated.TryGetValue(key, out current))
                {
                    proRated.Add(key, value);
                }
                else
                {
                    proRated[key] = current + value;
                }
            }

            items.Sort(descendingSorter);
            foreach (var target in targets)
            {
                var actual = proRated[target.Key];
                if (actual != target.Value)
                {
                    for (int i = 0; i < items.Count; i++)
                    {
                        var item = items[i];

                        if (keyFunc(item).Equals(target.Key))
                        {
                            items[i] = adjustmentFunc(item, target.Value - actual);
                        }
                    }
                }
            }
        }

        protected void Allocate<TKey>(long total,
            List<KeyValuePair<TKey, double>> ratios,
            Dictionary<TKey, long> allocations)
        {
            // ensure biggest ratio is allocated last
            ratios.Sort(RatioSorter<TKey>.Instance);

            long sum = 0;
            for (int i = 0; i < ratios.Count; i++)
            {
                var item = ratios[i];
                long value = (long) Math.Floor(total*item.Value);
                value = i + 1 != ratios.Count ? value : total - sum;
                if (value > 0)
                    allocations[item.Key] = value;
                sum += value;
            }
        }

        protected class RatioSorter<TKey> : IComparer<KeyValuePair<TKey, double>>
        {
            public int Compare(KeyValuePair<TKey, double> x, KeyValuePair<TKey, double> y)
            {
                return x.Value.CompareTo(y.Value);
            }

            public static RatioSorter<TKey> Instance { get; } = new RatioSorter<TKey>();
        }
    }
}
