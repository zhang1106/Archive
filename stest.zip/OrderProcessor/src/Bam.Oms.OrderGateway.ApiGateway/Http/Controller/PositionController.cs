﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web.Http;
using Bam.EventQ.Diagnostics;
using Bam.Oms.OrderGateway.ApiGateway.Cache;
using Bam.Oms.OrderGateway.ApiGateway.Models.Shared;
using Bam.Oms.OrderGateway.ApiGateway.Services;
using Bam.Oms.OrderGateway.Infrastructure.Permissions;

namespace Bam.Oms.OrderGateway.ApiGateway.Http.Controller
{
    public class PositionController : BaseController
    {
        private readonly ICache<long, Position> _positionCache;
        private readonly ICache<long, DetailedPosition> _detailedPositionCache;
        private readonly ICache<long, AggUnitPosition> _aggUnitPositionCache;
        private readonly ICache<long, ComplianceGroupPosition> _complianceGroupPositionCache;
        private readonly IDetailedPositionImportExport _importExport;
        private readonly IPositionSubmission _positionSubmission;
        private readonly ICache<string, Security> _securityCache;

        public PositionController(
            IPermissionedEntityFilter entityFilter, 
            ICache<long, Position> positionCache,
            ICache<long, DetailedPosition> detailedPositionCache,
            ICache<long, AggUnitPosition> aggUnitPositionCache,
            ICache<long, ComplianceGroupPosition> complianceGroupPositionCache, 
            IDetailedPositionImportExport importExport, 
            IPositionSubmission positionSubmission,
            ICache<string, Security> securityCache) : base(entityFilter)
        {
            _positionCache = positionCache;
            _detailedPositionCache = detailedPositionCache;
            _aggUnitPositionCache = aggUnitPositionCache;
            _complianceGroupPositionCache = complianceGroupPositionCache;
            _importExport = importExport;
            _positionSubmission = positionSubmission;
            _securityCache = securityCache;
        }

        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public List<DetailedPosition> GetDetailed()
        {
            using (_detailedPositionCache.AcquireReadAccess())
            {
                return _detailedPositionCache.GetItems()
                    .OrderBy(p => p.PositionId)
                    .ToList();
            }
        }

        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public List<DetailedPosition> GetDetailed(string bamSymbol)
        {
            if (string.IsNullOrEmpty(bamSymbol))
                return new List<DetailedPosition>();

            bamSymbol = bamSymbol.ToUpper();
            using (_detailedPositionCache.AcquireReadAccess())
            {
                return _detailedPositionCache.GetItems()
                    .Where(p => p.BamSymbol.Equals(bamSymbol))
                    .OrderBy(p => p.PositionId)
                    .ToList();
            }
        }

        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public List<DetailedPosition> GetDetailedByUnderlying(string underlyingSymbol)
        {
            if (string.IsNullOrEmpty(underlyingSymbol))
                return new List<DetailedPosition>();

            underlyingSymbol = underlyingSymbol.ToUpper();
            var securities = new HashSet<string>();
            using (_securityCache.AcquireReadAccess())
            {
                securities.UnionWith(_securityCache.GetItems()
                    .Where(s => s.UltimateUnderlyingSymbol.Equals(underlyingSymbol))
                    .Select(s => s.BamSymbol));
            }

            if (!securities.Any())
                return new List<DetailedPosition>();

            using (_detailedPositionCache.AcquireReadAccess())
            {
                return _detailedPositionCache.GetItems()
                    .Where(p => securities.Contains(p.BamSymbol))
                    .OrderBy(p => p.PositionId)
                    .ToList();
            }
        }

        [RequiredPermissions("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public Task<List<Position>> Get()
        {
            using (_positionCache.AcquireReadAccess())
            {
                var positions = _positionCache.GetItems()
                    .OrderBy(p => p.PositionId);

                return FilterEntitiesAsync(positions);
            }
        }

        [RequiredPermissions("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public Task<List<Position>> Get([FromUri(Name = "cutoffTime")] DateTime modifiedSince)
        {
            using (_positionCache.AcquireReadAccess())
            {
                var positions = _positionCache.GetItems()
                    .Where(p => p.LastUpdated >= modifiedSince)
                    .OrderBy(p => p.PositionId);

                return FilterEntitiesAsync(positions);
            }
        }

        [RequiredPermissions("Function.OrderGateway.Position.Read, Function.OrderGateway.Position.Write")]
        public Task<List<Position>> Get(string bamSymbol)
        {
            if (string.IsNullOrEmpty(bamSymbol))
                return Task.FromResult(new List<Position>());

            bamSymbol = bamSymbol.ToUpper();
            using (_positionCache.AcquireReadAccess())
            {
                var positions = _positionCache.GetItems()
                    .Where(p => p.Security.BamSymbol.Equals(bamSymbol))
                    .OrderBy(p => p.PositionId);

                return FilterEntitiesAsync(positions);
            }
        }

        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public List<ComplianceGroupPosition> GetCompliancePositions()
        {
            using (_complianceGroupPositionCache.AcquireReadAccess())
            {
                return _complianceGroupPositionCache.GetItems()
                    .OrderBy(p => p.PositionId)
                    .ToList();
            }
        }
        
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public List<ComplianceGroupPosition> GetCompliancePositions(string bamSymbol)
        {
            if (string.IsNullOrEmpty(bamSymbol))
                return new List<ComplianceGroupPosition>();

            bamSymbol = bamSymbol.ToUpper();

            using (_complianceGroupPositionCache.AcquireReadAccess())
            {
                return _complianceGroupPositionCache.GetItems()
                    .Where(p => p.BamSymbol.Equals(bamSymbol))
                    .OrderBy(p => p.PositionId)
                    .ToList();
            }
        }

        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public List<AggUnitPosition> GetAggUnitPositions()
        {
            using (_aggUnitPositionCache.AcquireReadAccess())
            {
                return _aggUnitPositionCache.GetItems()
                    .OrderBy(p => p.PositionId)
                    .ToList();
            }
        }

        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Read")]
        public List<AggUnitPosition> GetAggUnitPositions(string bamSymbol)
        {
            if (string.IsNullOrEmpty(bamSymbol))
                return new List<AggUnitPosition>();

            bamSymbol = bamSymbol.ToUpper();

            using (_aggUnitPositionCache.AcquireReadAccess())
            {
                return _aggUnitPositionCache.GetItems()
                    .Where(p => p.BamSymbol.Equals(bamSymbol))
                    .OrderBy(p => p.PositionId)
                    .ToList();
            }
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public List<DetailedPosition> Replace(string path)
        {
            Logger?.LogInformation($"{User.GetLogin()} request to replace positions with '{path}'");
            var replacement = _importExport.Import(path).ToList();
            _positionSubmission.ReplacePositions(replacement, User.GetLogin());
            return replacement;
        }

        [HttpGet]
        [RequiredPermissions("Function.OrderGateway.Admin, Function.OrderGateway.Admin.Write")]
        public string Dump(string path)
        {
            Logger?.LogInformation($"{User.GetLogin()} request to dump positions to '{path}'");
            using (_detailedPositionCache.AcquireReadAccess())
            {
                _importExport.Export(_detailedPositionCache.GetItems(), path);
                return $"Exported to {Path.GetFullPath(path)}";
            }
        }
    }
}