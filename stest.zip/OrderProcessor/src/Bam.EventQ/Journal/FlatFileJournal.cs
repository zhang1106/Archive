﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;

namespace Bam.EventQ.Journal
{
    public class FlatFileJournal : IJournal
    {
        private const byte ItemPrefix = 1;
        private const byte MarkerPrefix = 2;

        private readonly int _maximumMessageSize;
        private readonly byte[] _writeBuffer = new byte[5];
        private FileStream _writeStream;

        public FlatFileJournal(string path, int maximumMessageSize)
        {
            Path = path;
            _maximumMessageSize = maximumMessageSize;
        }

        public void Append(byte[] buffer, int index, int count)
        {
            EnsureWriteStream();

            if (count > _maximumMessageSize)
            {
                throw new ArgumentException($"item exceeds {_maximumMessageSize} bytes size limit.");
            }

            WriteItem(_writeStream, buffer, index, count);
        }

        public void AppendMarker(int marker)
        {
            EnsureWriteStream();
            WriteMarker(_writeStream, marker);
        }

        public void Flush()
        {
            _writeStream.Flush(true);
        }

        public void Truncate(string archivePath)
        {
            EnsureWriteStream();

            string folder = System.IO.Path.GetDirectoryName(archivePath);
            if (folder != null && !Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            _writeStream.Flush(true);
            _writeStream.Close();
            _writeStream = null;
            File.Move(Path, archivePath);
        }

        public void Truncate()
        {
            EnsureWriteStream();
            _writeStream.Flush(true);
            _writeStream.Close();
            _writeStream = null;
            File.Delete(Path);
        }
        
        public IEnumerable<byte[]> Retrieve()
        {
            using (var stream = OpenForRead())
            {
                foreach (var item in ReadFromStream(stream, false))
                {
                    if (item.Key == ItemPrefix)
                    {
                        yield return item.Value;
                    }
                }
            }
        }

        public IEnumerable<int> RetrieveMarkers()
        {
            using (var stream = OpenForRead())
            {
                foreach (var item in ReadFromStream(stream, false))
                {
                    if (item.Key == MarkerPrefix)
                    {
                        yield return item.Value.ToInt32(0);
                    }
                }
            }
        }

        public string Path { get; }

        public void Dispose()
        {
            _writeStream?.Flush(true);
            _writeStream?.Dispose();
            _writeStream = null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void EnsureWriteStream()
        {
            if (_writeStream == null)
            {
                _writeStream = new FileStream(Path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
                PerformSanityCheck(_writeStream);
            }
        }

        private void PerformSanityCheck(FileStream stream)
        {
            using (var enumerator = ReadFromStream(stream, true).GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    // no op
                }
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void GuardRead(FileStream stream, byte[] buffer, int bytesToRead)
        {
            if (stream.Position + bytesToRead > stream.Length)
                throw new InvalidDataException();
            stream.Read(buffer, 0, bytesToRead);
        }

        private KeyValuePair<byte, byte[]> ReadItem(FileStream stream, byte[] readBuffer, bool skipData)
        {
            GuardRead(stream, readBuffer, 5);
            byte type = readBuffer[0];

            byte[] data = null;
            if (type == MarkerPrefix)
            {
                if (!skipData)
                {
                    data = new byte[4];
                    Buffer.BlockCopy(readBuffer, 1, data, 0, data.Length);
                }
            }
            else if (type == ItemPrefix)
            {
                int dataLength = readBuffer.ToInt32(1);
                if (dataLength > _maximumMessageSize)
                    throw new InvalidDataException();

                if (skipData)
                {
                    if (stream.Position + dataLength > stream.Length)
                        throw new InvalidDataException();
                    stream.Seek(dataLength, SeekOrigin.Current);
                }
                else
                {
                    data = new byte[dataLength];
                    GuardRead(stream, data, dataLength);
                }
            }
            else
            {
                throw new InvalidDataException();
            }

            return new KeyValuePair<byte, byte[]>(type, data);
        }

        private IEnumerable<KeyValuePair<byte, byte[]>> ReadFromStream(FileStream stream, bool skipData)
        {
            long lastGood = 0;
            byte[] readBuffer = new byte[32];
            while (stream.Position < stream.Length)
            {
                KeyValuePair<byte, byte[]> item;
                try
                {
                    item = ReadItem(stream, readBuffer, skipData);
                    lastGood = stream.Position;
                }
                catch (InvalidDataException)
                {
                    // file corrupted from this point on
                    stream.Seek(lastGood, SeekOrigin.Begin);
                    break;
                }

                yield return item;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void WriteItem(FileStream stream, byte[] data, int index, int count)
        {
            _writeBuffer[0] = ItemPrefix;
            count.CopyToBuffer(_writeBuffer, 1);
            stream.Write(_writeBuffer, 0, 5);
            stream.Write(data, index, count);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void WriteMarker(FileStream stream, int marker)
        {
            _writeBuffer[0] = MarkerPrefix;
            marker.CopyToBuffer(_writeBuffer, 1);
            stream.Write(_writeBuffer, 0, 5);
        }

        private FileStream OpenForRead()
        {
            return new FileStream(Path, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite);
        }
    }
}
