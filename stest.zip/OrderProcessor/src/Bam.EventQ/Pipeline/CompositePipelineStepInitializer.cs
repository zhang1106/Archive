﻿using System.Threading;
using Bam.EventQ.Queue;

namespace Bam.EventQ.Pipeline
{
    public class CompositePipelineStepInitializer<TItem> : IPipelineStepInitializer<TItem>
    {
        private readonly IPipelineStepInitializer<TItem>[] _steps;

        public CompositePipelineStepInitializer(params IPipelineStepInitializer<TItem>[] steps)
        {
            _steps = steps;
        }

        public void Execute(IQueue<PipelineQueueItem<TItem>> queue, CancellationToken cancellationToken)
        {
            foreach (var step in _steps)
            {
                step.Execute(queue, cancellationToken);
                if (cancellationToken.IsCancellationRequested)
                    break;
            }
        }
    }
}
