﻿using System;
using Bam.Oms.OrderGateway.ApiGateway.Http;
using Bam.Oms.OrderGateway.ApiGateway.Http.SignalR;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.Configuration;

namespace Bam.Oms.OrderGateway.ApiGateway
{
    public class ApiGatewaySettings : SettingsBase
    {
        public ApiGatewaySettings()
            : base("ApiGateway.")
        {
            
        }

        public bool DisableAuthorization
        {
            get { return GetValue(() => DisableAuthorization, GetGlobalValue(() => DisableAuthorization)); }
        }

        public string[] PermissionedApplications
        {
            get { return GetValue(() => PermissionedApplications, new[] { "PMUI", "OrderGateway" }); }
        }

        public TimeSpan PermissionRefreshInterval
        {
            get { return GetValue(() => PermissionRefreshInterval, TimeSpan.FromMinutes(30)); }
        }

        public RabbitMqSettings RabbitMq { get; } = new RabbitMqSettings();
        public HttpSettings Http { get; } = new HttpSettings();
        public SignalRSettings SignalR { get; } = new SignalRSettings();
        public SolaceSettings Solace { get; } = new SolaceSettings();
        public OrderFileListenerSettings OrderFileListener { get; } = new OrderFileListenerSettings();
        public SecurityFileListenerSettings SecurityFileListener { get; } = new SecurityFileListenerSettings();
        public HeadroomFileListenerSettings HeadroomFileListener { get; } = new HeadroomFileListenerSettings();
        public RingBufferSettings Queue { get; } = new RingBufferSettings("ApiGateway.Queue.");

        public override string SelfPubSub => Endpoints.ApiGatewayPubSub;
        public override string SelfRpc => Endpoints.ApiGatewayRpc;
        public override Source SelfSource => Source.ApiGateway;

        public TimeSpan RollTime { get { return GetValue(() => RollTime); } }

        public string ContingencyConnectionString
        {
            get { return GetValue(() => ContingencyConnectionString); }
        }
    }
}
