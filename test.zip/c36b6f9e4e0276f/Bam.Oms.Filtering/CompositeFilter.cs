﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Bam.Oms.Filtering
{
    public class CompositeFilter<T> : ICompositeFilter<T>
    {
        private IFilter<T> _userFilter;
        private IFilter<T> _permissionedFilter;
        private bool _isAndFitler;

        public CompositeFilter()
        {
            _userFilter = new Filter<T>();
            _permissionedFilter = new Filter<T>();
            _isAndFitler = true;
        }

        public void AddToFilter(string id, IEnumerable<Parameter> userCriteria, bool isUserFilterAnd
                        , IEnumerable<Parameter> permissionedCriteria, bool isPermissionFilterAnd)
        {
            _userFilter.AddToFilter(id, userCriteria, isUserFilterAnd);
            //or filter for permissions restriction
            _permissionedFilter.AddToFilter(id, permissionedCriteria, isPermissionFilterAnd);

            FilterChanged?.Invoke(id);
        }

        /// <summary>
        /// Applies the saved filters to the item and indicates whether or not it should be filtered out
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public IEnumerable<string> ApplyFilter(T item)
        {
            return _userFilter.ApplyFilter(item).Intersect(_permissionedFilter.ApplyFilter(item));
        }

        /// <summary>
        /// Checks to see a given item passes the filter for a given consumer
        /// </summary>
        /// <param name="id"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool ApplyFilter(string id, T item)
        {
            if (_isAndFitler)
            {
                return _userFilter.ApplyFilter(id, item) && _permissionedFilter.ApplyFilter(id, item);
            }
            return _userFilter.ApplyFilter(id, item) || _permissionedFilter.ApplyFilter(id, item);
        }

        /// <summary>
        /// clear filter
        /// </summary>
        /// <param name="id"></param>
        public void ClearFilter(string id)
        {
             
            _userFilter.ClearFilter(id);
            _permissionedFilter.ClearFilter(id);
            
            FilterChanged?.Invoke(id);
        }


        public event Action<string> FilterChanged;

        public IList<string> ClientConnectionIds => _userFilter.ClientConnectionIds.Union(_permissionedFilter.ClientConnectionIds).ToList();
    }
}
