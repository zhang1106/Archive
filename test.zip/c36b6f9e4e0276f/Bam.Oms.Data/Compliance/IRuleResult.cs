﻿using System;
using System.Security.Cryptography.X509Certificates;
using Bam.Oms.Data.Enumerators;

namespace Bam.Oms.Data.Compliance
{
    public interface IRuleResult: IExtensible
    {
        string Key { get; }
        int PolicyId { get; set; }
        int RuleId { get; set; }
        string RuleName { get; set; }
        string BamSymbol { get; set; }
        string Description { get; set; }
        ComplianceAlertLevel AlertLevel { get; set; }
        bool IsViolationOverriden { get; set; }
        decimal? PositionQty { get; set; }
        bool Same(object obj);
        DateTime BusinessDate { get; set;}
        HeadRoom HeadRoom { get; set; }
    }
}
