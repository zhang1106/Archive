﻿using System;

namespace Bam.Oms.Data.Portfolios
{
    public interface IPortfolio : IPersistentItem, IComparable<IPortfolio>, IComparable
    {        
        string PMCode { get; }
        string Strategy { get; }
        string SubStrategy { get; }

        string AggregationUnit { get; }

        string ComplianceGroup { get; }

        bool IsMatch(IPortfolio portfolio);
    }
}
