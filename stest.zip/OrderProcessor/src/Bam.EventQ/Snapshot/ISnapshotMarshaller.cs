﻿using System.Collections.Generic;
using System.IO;

namespace Bam.EventQ.Snapshot
{
    public interface ISnapshotMarshaller
    {
        IEnumerable<ISnapshot> Read(Stream stream);
        void Write(IEnumerable<ISnapshot> snapshots, Stream stream);
    }
}