﻿using System;
using System.Threading;

namespace Bam.EventQ
{
    public class CasLock
    {
        private long _lock;
        private readonly SpinWait _spinWait;
        private readonly IDisposable _lockRelease;

        public CasLock()
        {
            _spinWait = new SpinWait();
            _lockRelease = new CasLockRelease(this);
        }

        public IDisposable Acquire()
        {
            // see https://en.wikipedia.org/wiki/Test_and_test-and-set
            while (Interlocked.CompareExchange(ref _lock, 1, 0) == 1)
            {
                while (Volatile.Read(ref _lock) == 1)
                {
                    // ReSharper disable once ImpureMethodCallOnReadonlyValueField
                    _spinWait.SpinOnce();
                }
            }

            return _lockRelease;
        }

        internal void Release()
        {
            Volatile.Write(ref _lock, 0);
        }

        private class CasLockRelease : IDisposable
        {
            private readonly CasLock _lock;

            public CasLockRelease(CasLock @lock)
            {
                _lock = @lock;
            }

            public void Dispose()
            {
                _lock.Release();
            }
        }
    }
}
