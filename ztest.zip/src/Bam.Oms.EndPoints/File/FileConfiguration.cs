namespace Bam.Oms.EndPoints.File
{
    public class FileConfiguration : IFileConfiguration
    {
        public string Path
        {
            get;
            set;
        }
    }
}