﻿using System.Web.Http.ExceptionHandling;
using Bam.Compliance.Infrastructure.Logger;
using BAM.Infrastructure.Ioc;

namespace Bam.Oms.Compliance.ApiGateway.Http
{
    public class LoggingExceptionHandler : ExceptionHandler
    {
        private readonly ILogger _logger;

        public LoggingExceptionHandler(ILogger logger)
        {
            _logger = logger;
        }

        public override void Handle(ExceptionHandlerContext context)
        {
            _logger.Error(context.Request?.RequestUri?.ToString(), context.Exception);
            base.Handle(context);
        }
    }
}
