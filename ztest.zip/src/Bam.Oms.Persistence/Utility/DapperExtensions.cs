﻿using System;
using Dapper;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Bam.Oms.Persistence.Utility
{
    /// <summary>
    /// Extension methods for the Dapper.net plugin.
    /// </summary>
    public static class DapperExtensions
    {
        /// <summary>
        /// Inserts the specified connection.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="connection">The connection.</param>
        /// <param name="tableName">Name of the table.</param>
        /// <param name="idColumnName">Id column name</param>
        /// <param name="param">The param.</param>
        /// <param name="resultMap">Performs custom result mapping if defined post insert operation</param>
        /// <returns></returns>
        public static T Insert<T>(this IDbConnection connection, string tableName, string idColumnName, dynamic param, Func<string, bool> includeColumnPredicate = null,
            Func<dynamic, T> resultMap = null)
        {
            string sql = DynamicQuery.GetInsertQuery(tableName, idColumnName, param, includeColumnPredicate);

            IEnumerable<T> result = InsertAndMapResult(connection, sql, param, resultMap);

            return result.First();
        }

        private static IEnumerable<T> InsertAndMapResult<T>(IDbConnection connection, string sql, dynamic param, Func<dynamic, T> resultMap, IDbTransaction transaction = null)
        {
            IEnumerable<T> result = null;
            if (resultMap == null)
            {
                // Use dapper's default mapping
                result = connection.Query<T>(sql, (object)param, transaction);
            }
            else
            {
                // Skip Dapper's default mapping and apply custom mapping on results.
                result = connection.Query<dynamic>(sql, (object)param, transaction).Select(resultMap);
            }
            return result;
        }

        /// <summary>
        /// We are using a workaround to perform bulk insert and populate the identity field in memory as it's not supported 
        /// by dapper out of the box.
        /// 
        /// Create a temp table with the same structure as of the table in which we need to insert data
        /// Insert records into temp table (without having to worry about auto-incremented identity values
        /// Insert records into the target table from temp table outputting all the records.
        /// The output records could be mapped to the target object.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="connection"></param>
        /// <param name="tableName"></param>
        /// <param name="idColumnName"></param>
        /// <param name="paramList"></param>
        /// <returns></returns>
        public static IEnumerable<T> InsertRange<T>(this IDbConnection connection, string tableName, string idColumnName, IList<dynamic> paramList, Func<string, bool> includeColumnPredicate = null, Func<dynamic, T> resultMap = null)
        {
            if (paramList != null && paramList.Count > 0)
            {
                IEnumerable<T> result = null;
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Creating  temp table of same structure as that of target table onto which we want to perform insert.
                        connection.Execute(@"IF OBJECT_ID('tempdb..#TEMP') IS NOT NULL
                                     DROP TABLE #TEMP
                                     SELECT TOP 0 * INTO #TEMP FROM " + tableName, null, transaction);

                        string insertIntoTempSql = DynamicQuery.GetInsertRangeQuery("#TEMP", idColumnName, paramList[0], includeColumnPredicate);

                        // Inserting into temp table.
                        connection.Execute(insertIntoTempSql, paramList, transaction);

                        var finalInsertQuery = GetFinalInsertQuery(tableName, idColumnName, paramList, includeColumnPredicate);

                        // Inserting into the target table from  temp and returning the results.
                        result = InsertAndMapResult(connection, finalInsertQuery, null, resultMap, transaction);

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }

                return result;
            }
            return Enumerable.Empty<T>();
        }

        private static string GetFinalInsertQuery(string tableName, string idColumnName, IList<dynamic> paramList, Func<string, bool> includeColumnPredicate = null)
        {
            includeColumnPredicate = includeColumnPredicate ?? (s => true);

            PropertyInfo[] props = paramList[0].GetType().GetProperties();

            string[] columns = props.Select(p => p.Name).Where(s => s != idColumnName && includeColumnPredicate.Invoke(s)).ToArray();

            string valuesSqlSection = $"SELECT {String.Join(",", columns)} FROM #TEMP";

            return DynamicQuery.GetInsertQuery(tableName, idColumnName, paramList[0], includeColumnPredicate, true, valuesSqlSection);
        }
    }
}
