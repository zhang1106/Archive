﻿namespace Bam.EventQ.Pooling
{
    public interface IObjectPool
    {
        T Get<T>();
        void Release(object instance);
    }
}