﻿using System;
using System.Collections.Generic;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.Filtering;

namespace Bam.Oms.OrderRouting.Contracts
{
    public interface IEmsSubscriptionAdapter : IEmsBaseAdapter
    {
        /// <summary>
        /// Subscribe for updates from EMS
        /// </summary>
        /// <param name="filter">Filter supports regular expressions</param>
        /// <returns>True indicates operation is successful. This is different from order acknowledgement</returns>
        bool Subscribe(IFilter<EmsSubscription> filter = null);

        bool Unsubscribe();
        bool RequestFullRefresh();
        event Action<IEnumerable<IBlockTrade>> TradeUpdated;
        event Action<Data.Securities.ISecurity> SecurityUpdated;
    }   
}
