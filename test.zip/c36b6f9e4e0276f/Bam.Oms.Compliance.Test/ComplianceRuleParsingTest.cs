﻿using Bam.Oms.Compliance.DataProvider;
using Bam.Oms.Compliance.Rules;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data;
using Bam.Oms.Data.Enumerators;
using BAM.Infrastructure.Ioc;
using NUnit.Framework;
using Moq;

namespace Bam.Oms.Compliance.Test
{
    [TestFixture]
    public class ComplianceRuleParsingTest
    {
        [SetUp]
        public void Setup()
        {
            Container.Instance.RegisterInstance<IFactProvider>(new Mock<IFactProvider>().Object);
        }

        [Test]
        [TestCase("Long", "{\"Ratio\":{\"Main\":0.75,\"AQTF\":0.25}, \"OwnershipType\":\"Long\",\"Threshholds\":{\"0\":{\"UpLimit\":0.04},\"0.04\":{\"LowLimit\":0.04,\"UpLimit\":0.05,\"AlertLevel\":\"Overrideable\", \"FireOnce\":true},\"0.05\":{\"LowLimit\":0.05,\"UpLimit\":0.09,\"AlertLevel\":\"ComplianceOverrideable\"},\"0.09\":{\"LowLimit\":0.09,\"UpLimit\":null,\"AlertLevel\":\"ComplianceOverrideable\"}},\"FilterParams\":[{\"Property\":\"Country\",\"Value\":\"US\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Equal\"}},{\"Property\":\"BamSymbol\",\"Value\":\"OIH\",\"Type\":null,\"Operator\":{\"OperatorType\":\"NotEqual\"}}]}")]
        [TestCase("Unknown", "{\"Threshholds\":{\"0\":{\"UpLimit\":0.04},\"0.04\":{\"LowLimit\":0.04,\"UpLimit\":0.05,\"AlertLevel\":\"Overrideable\", \"FireOnce\":true},\"0.05\":{\"LowLimit\":0.05,\"UpLimit\":0.09,\"AlertLevel\":\"ComplianceOverrideable\"},\"0.09\":{\"LowLimit\":0.09,\"UpLimit\":null,\"AlertLevel\":\"ComplianceOverrideable\"}},\"FilterParams\":[{\"Property\":\"Country\",\"Value\":\"US\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Equal\"}},{\"Property\":\"BamSymbol\",\"Value\":\"OIH\",\"Type\":null,\"Operator\":{\"OperatorType\":\"NotEqual\"}}]}")]
        [TestCase("Unknown", "{\"Threshholds\":{\"0\":{\"UpLimit\":0.045},\"0.045\":{\"LowLimit\":0.045, \"AlertLevel\":\"ComplianceOverrideable\"}}, \"FilterParams\":[{\"Property\":\"BamSymbol\",\"Value\":\"4.5%LongList\",\"Operator\":{\"OperatorType\":\"InTheList\"}}]}")]
        public void TestLongOwnerShipRuleParsing(string expected, string rule)
        {
            var longOwnershipFiling = new LongOwnerShipFiling() {ParamsInJson = rule};
            longOwnershipFiling.Init();

            Assert.IsTrue(longOwnershipFiling.OwnerShipType.ToString() == expected);
        }

        [Test]
        [TestCase("BAM", "{\"IncludeConstituent\":true,\"Entity\":\"BAM\",\"Threshholds\":{\"0\":{\"LowLimit\":null,\"UpLimit\":0.02},\"0.02\":{\"LowLimit\":0.02,\"UpLimit\":0.0485,\"FireOnce\":true,\"AlertLevel\":\"ComplianceOverrideable\"},\"0.0485\":{\"LowLimit\":0.0485,\"UpLimit\":null,\"AlertLevel\":\"ComplianceOverrideable\"}},\"FilterParams\":[{\"Property\":\"ISIN\",\"Value\":\"EuIsinList\",\"Type\":null,\"Operator\":{\"OperatorType\":\"InTheList\"}}]}")]
        public void TestShortOwnerShipRuleParsing(string expected, string rule)
        {
            var shortOwnershipFiling = new ShortOwnershipFiling()
            { ParamsInJson = rule };
            shortOwnershipFiling.Init();

            Assert.IsTrue(shortOwnershipFiling.Entity == expected);
        }

        [Test]
        [TestCase(true, "ETF", "{\"Threshholds\":{\"0\":{\"LowLimit\":null,\"UpLimit\":0.02},\"0.02\":{\"LowLimit\":0.02,\"UpLimit\":0.0299,\"AlertLevel\":\"Overrideable\"},\"0.0299\":{\"LowLimit\":0.0299}}, \"FilterParams\":[{\"Property\":\"InvestmentType\",\"Value\":\"ETF\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Equal\"}}]}")]
        [TestCase(false, "NON", "{\"Threshholds\":{\"0\":{\"LowLimit\":null,\"UpLimit\":0.02},\"0.02\":{\"LowLimit\":0.02,\"UpLimit\":0.0299,\"AlertLevel\":\"Overrideable\"},\"0.0299\":{\"LowLimit\":0.0299}}, \"FilterParams\":[{\"Property\":\"InvestmentType\",\"Value\":\"ETF\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Equal\"}}]}")]
        public void TestRuleFilterOnInvestmentType(bool expected, string investmentType, string rule)
        {
            var longOwnershipFiling = new LongOwnerShipFiling()
            { ParamsInJson = rule };
            longOwnershipFiling.Init();

            var security = new Security() {BamSymbol = "SIL", InvestmentType = Utility.ConvertEnum<InvestmentType>(investmentType) };

            var inFilter = longOwnershipFiling.SecurityFilter.ApplyFilter(longOwnershipFiling.GetType().FullName, security);

            Assert.IsTrue(inFilter==expected);
        }

        [Test]
        [TestCase(true, "REITs Test", "{\"Threshholds\":{\"0\":{\"LowLimit\":null,\"UpLimit\":0.03},\"0.03\":{\"LowLimit\":0.03,\"UpLimit\":0.045,\"AlertLevel\":\"Overrideable\"},\"0.045\":{\"LowLimit\":0.045}}, \"FilterParams\":[{\"Property\":\"Industry\",\"Value\":\"REIT\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Contains\"}}]}")]
        [TestCase(true, "REIT", "{\"Threshholds\":{\"0\":{\"LowLimit\":null,\"UpLimit\":0.03},\"0.03\":{\"LowLimit\":0.03,\"UpLimit\":0.045,\"AlertLevel\":\"Overrideable\"},\"0.045\":{\"LowLimit\":0.045}}, \"FilterParams\":[{\"Property\":\"Industry\",\"Value\":\"REIT\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Contains\"}}]}")]
        [TestCase(false, "Retails", "{\"Threshholds\":{\"0\":{\"LowLimit\":null,\"UpLimit\":0.03},\"0.03\":{\"LowLimit\":0.03,\"UpLimit\":0.045,\"AlertLevel\":\"Overrideable\"},\"0.045\":{\"LowLimit\":0.045}}, \"FilterParams\":[{\"Property\":\"Industry\",\"Value\":\"REIT\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Contains\"}}]}")]
        public void TestRuleFilterOnIndustry(bool expected, string industry, string rule)
        {
            var longOwnershipFiling = new LongOwnerShipFiling()
            { ParamsInJson = rule };
            longOwnershipFiling.Init();

            var security = new Security() { BamSymbol = "SIL", Industry = industry };

            var inFilter = longOwnershipFiling.SecurityFilter.ApplyFilter(longOwnershipFiling.GetType().FullName, security);

            Assert.IsTrue(inFilter==expected);
        }

        [Test]
        [TestCase(true, "Equity", "{\"Ratio\":{\"AQTF\":0.25,\"MAIN\":0.75}, \"OwnershipType\":\"LONG\",\"Threshholds\":{\"0\":{\"UpLimit\":0.04},\"0.04\":{\"LowLimit\":0.04,\"UpLimit\":0.05,\"AlertLevel\":\"Overrideable\"},\"0.05\":{\"LowLimit\":0.05,\"UpLimit\":0.09,\"AlertLevel\":\"ComplianceOverrideable\",\"FireOnce\":true},\"0.09\":{\"LowLimit\":0.09,\"UpLimit\":null,\"AlertLevel\":\"ComplianceOverrideable\"}},\"FilterParams\":[{\"Property\":\"SecurityType\",\"Value\":\"Equity\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Equal\"}},{\"Property\":\"Country\",\"Value\":\"US\",\"Type\":null,\"Operator\":{\"OperatorType\":\"Equal\"}},{\"Property\":\"BamSymbol\",\"Value\":\"OIH\",\"Type\":null,\"Operator\":{\"OperatorType\":\"NotEqual\"}}]}")]
        public void TestRuleFilterOnSecurityType(bool expected, string securityType, string rule)
        {
            var longOwnershipFiling = new LongOwnerShipFiling()
            { ParamsInJson = rule };
            longOwnershipFiling.Init();

            var security = new Security() { BamSymbol = "SIL", SecurityType = Utility.ConvertEnum<SecurityType>(securityType), Country="US" };

            var inFilter = longOwnershipFiling.SecurityFilter.ApplyFilter(longOwnershipFiling.GetType().FullName, security);

            Assert.IsTrue(inFilter == expected);
        }
 
    }
}
