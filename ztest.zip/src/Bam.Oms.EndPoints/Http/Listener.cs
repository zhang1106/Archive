﻿using System;
using System.Collections.Generic;
using System.Web;
using Bam.Oms.Data;
using Bam.Oms.Data.Orders;
using Bam.Oms.EndPoints.Orders;
using BAM.Infrastructure.Ioc;
using Microsoft.Owin.Hosting;

namespace Bam.Oms.EndPoints.Http
{
    public class Listener : IOrderSubmission, IDisposable, IOrderNotifier
    {
        private IDisposable _web;
        private readonly IHostConfiguration _hostConfiguration;

        public Listener(IHostConfiguration hostConfiguration)
        {
            if (hostConfiguration == null) throw new ArgumentNullException(nameof(hostConfiguration));

            _hostConfiguration = hostConfiguration;
            _web = WebApp.Start<StartUp>(hostConfiguration.BaseUrl);
        }

        public event Action<IList<IOrder>, string, bool> NewOrdersReady;
        public event Action<IList<string>> NewCancelOrdersReady;
        public event Action<IList<string>> NewDeleteOrdersReady;
        public event Action<IOrder> NewReplaceOrdersReady;
        public event Action<Tuple<IList<string>, string>> NewOrdersToRouteReady;
        public event Action<IList<string>> LocateRequestReceived;

        public void AcceptOrders()
        {
            //_web = WebApp.Start<StartUp>(_hostConfiguration.BaseUrl);
        }

        public void Dispose()
        {
            _web.Dispose();
        }

        public void NotifyNewOrders(IList<IOrder> orders)
        {
            if (NewOrdersReady != null)
            {
                NewOrdersReady.Invoke(orders, null, false); //todo: figure out batchid from api request
            }
            else
            {
                throw new HttpRequestValidationException("Order gateway is not yet ready to receive requests.");
            }
        }

        public void NotifyCancelOrders(IList<string> orderIds)
        {
            Utility.RaiseEvent(orderIds, NewCancelOrdersReady);
        }

        public void NotifyDeleteOrders(IList<string> orderIds)
        {
            Utility.RaiseEvent(orderIds, NewDeleteOrdersReady);
        }

        public void NotifyReplaceOrders(IOrder order)
        {
            Utility.RaiseEvent(order, NewReplaceOrdersReady);
        }
        
        public void NotifyOrdersToRoute(IList<string> orderIds, string entryUser)
        {
            Utility.RaiseEvent(new Tuple<IList<string>, string>(orderIds, entryUser), NewOrdersToRouteReady);
        }

        public void NotifyLocateRequestReceived(IList<string> orderIds)
        {
            Utility.RaiseEvent(orderIds, LocateRequestReceived);
        }
    }
}