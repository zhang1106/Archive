﻿using System;

namespace Bam.Oms.Compliance.ApiGateway.Services
{
    public interface ILogger
    {
        void Log(LogLevel logLevel, string message, Exception exception = null);
        void Archive();
    }
}
