﻿using System.Collections.Generic;

namespace Bam.EventQ.Queue
{
    public interface IQueueItemTransformer<in TIn, out TOut>
    {
        IReadOnlyList<TOut> Transform(TIn item, long sequence, bool isReplay);
    }
}
