﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bam.Oms.Data.Compliance
{
    public interface IFact
    {
        int FactId { get; }
        string Name { get; }
        string Value { get; }

        HashSet<string> GetList();
    }
}
