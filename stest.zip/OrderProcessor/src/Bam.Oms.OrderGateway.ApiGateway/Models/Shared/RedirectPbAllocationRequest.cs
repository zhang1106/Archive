﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.ApiGateway.Models.Shared
{
    public class RedirectPbAllocationRequest
    {
        public string OrderId { get; set; }
        public Dictionary<string, long> Allocations { get; set; }
    }
}