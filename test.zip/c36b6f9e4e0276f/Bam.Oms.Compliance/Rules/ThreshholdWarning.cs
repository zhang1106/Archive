﻿using System;
using Bam.Oms.Data.Enumerators;
 
namespace Bam.Oms.Compliance.Rules
{
    public struct ThreshholdWarning
    {
        public decimal? LowLimit { get; set; }
        public decimal? UpLimit { get; set; }
        public decimal? SubsequentChange { get; set; }
        public ComplianceAlertLevel? AlertLevel { get; set; }
        public bool FireOnce { get; set; }
        public bool IsInCurentWarningArea(decimal currentVal)
        {
            return ((!LowLimit.HasValue || currentVal >= LowLimit) && (!UpLimit.HasValue || currentVal < UpLimit));
        }
        public MovingDirection GetMovingDirection(decimal? lastLowLimit)
        {
            var direction = MovingDirection.NoChange;

            if (!lastLowLimit.HasValue) direction = MovingDirection.NoHistory;
            else if (lastLowLimit == LowLimit) direction = MovingDirection.NoChange;
            else if (lastLowLimit < LowLimit) direction = MovingDirection.Exceed;
            else direction = MovingDirection.FallBelow;

            return direction;
        }
        public ComplianceAlertLevel GetAlertlevel(decimal? currentVal, decimal? lastVal, decimal? lastLowLimit)
        {
            var alertLevel = AlertLevel==null?ComplianceAlertLevel.NoViolation : AlertLevel.Value;
            //nothing to check
            if (!(currentVal.HasValue))
            {
                return ComplianceAlertLevel.NoDataAvaiable;
            }
            //the logic applies only when the ratio is in current area
            if (!IsInCurentWarningArea(currentVal.Value))
            {
                alertLevel = ComplianceAlertLevel.NoViolation;
            }
            //if no lowlimit is set, consider the area is a no warning area
            else
            {
                var direction = GetMovingDirection(lastLowLimit);
                //no history data, 
                if (direction == MovingDirection.NoHistory)
                {
                    alertLevel = !LowLimit.HasValue ? ComplianceAlertLevel.NoViolation : ComplianceAlertLevel.ExceedWarning;
                }
                //in the same area
                else if (direction == MovingDirection.NoChange)
                {
                    alertLevel = ComplianceAlertLevel.NoAlertLevelChange;
                }
                //fall into current area
                else if (direction == MovingDirection.FallBelow)
                {
                    alertLevel = ComplianceAlertLevel.FallBelowWarning;
                }
                //exceed into current area
                else if (direction == MovingDirection.Exceed)
                {
                    alertLevel = ComplianceAlertLevel.ExceedWarning;
                }
            }

            return alertLevel;
        }
    }
}
