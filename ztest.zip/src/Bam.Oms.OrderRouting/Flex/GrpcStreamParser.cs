﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Grpc.Core;
using Grpc.Core.Utils;
using log4net;

namespace Bam.Oms.OrderRouting.Flex
{
    public class GrpcStreamParser : IStreamParser
    {
        private static readonly ILog Logger = LogManager.GetLogger("Bam.Oms.OrderRouting.Flex.GrpcStreamParser");
        public T ParseStreamReturnFirst<T>(AsyncServerStreamingCall<T> asynchCall) where T : class
        {
            var readTask = asynchCall?.ResponseStream.ToListAsync();
            try
            {
                var results = readTask?.Result;
                return results?.Count > 0 ? results[0] : null;
            }
            catch (AggregateException aex)
            {
                aex.Handle((ex) =>
                {
                    Logger.Error($"Exception while reading response from FLEX.", ex);
                    return false;
                });
            }
            return null;
        }

        public IEnumerable<T> ParseStream<T>(AsyncServerStreamingCall<T> asynchCall) where T : class
        {

            var readTask = asynchCall?.ResponseStream.ToListAsync();
            try
            {
                return readTask?.Result;                
            }
            catch (AggregateException aex)
            {
                aex.Handle((ex) =>
                {
                    Logger.Error($"Exception while reading response from FLEX.", ex);
                    return false;
                });
            }
            return null;            
        }
    }
}