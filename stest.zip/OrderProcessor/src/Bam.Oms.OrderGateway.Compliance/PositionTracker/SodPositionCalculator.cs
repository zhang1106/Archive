﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bam.EventQ.Lookup;
using Bam.EventQ.Sequencing;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Services;
using Bam.Oms.OrderGateway.Infrastructure;
using Bam.Oms.OrderGateway.Infrastructure.ReferenceData;

namespace Bam.Oms.OrderGateway.Compliance.PositionTracker
{
    public class SodPositionCalculator : EventRelay<IMessage>, ISodPositionCalculator
    {
        private readonly IReferenceDataService _referenceDataService;
        private readonly IPositionEffectCalculator _effectCalculator;
        private readonly IPositionIdGenerator _positionIdGenerator;
        private readonly IPositionEffectCache _effectCache;

        public SodPositionCalculator(
            IReferenceDataService referenceDataService,
            IPositionEffectCalculator effectCalculator, 
            IPositionIdGenerator positionIdGenerator,
            IPositionEffectCache effectCache)
        {
            _referenceDataService = referenceDataService;
            _effectCalculator = effectCalculator;
            _positionIdGenerator = positionIdGenerator;
            _effectCache = effectCache;
        }

        public IReadOnlyList<PositionSet> Adjust(
            IReadOnlyList<PositionSet> positionSets,
            IReadOnlyList<Position> newSodPositions,
            IList<OrderStrategyAllocation> orderAllocations)
        {
            var lookup = newSodPositions.ToDictionary(p => p.Key);

            var sets = new Dictionary<PositionKey, PositionSet>();
            foreach (var set in positionSets)
            {
                var pk = set.Key;
                Position replacement;
                if (!lookup.TryGetValue(pk, out replacement)) continue;

                using (Attach(set.Position))
                using (Attach(set.CompliancePosition))
                using (Attach(set.AggUnitPosition))
                {
                    ReplacePosition(set, replacement);
                }

                sets[pk] = set;
            }

            ResetEffects(orderAllocations);
            Replay(sets, orderAllocations);
            return sets.Values.ToList();
        }

        public IReadOnlyList<PositionSet> Calculate(
            IReadOnlyList<Position> sodPositions, 
            IList<Order> orders)
        {
            var sodPositionKeys =
                new HashSet<PositionKey>(sodPositions.Select(p => p.Key));

            var newPositionKeys = orders.SelectMany(o => o.Allocations)
                .Select(r => r.Key).Except(sodPositionKeys).ToList();
            var newPositions = new List<Position>(newPositionKeys.Count);

            foreach (var pk in newPositionKeys)
            {
                PortfolioDetails details;
                if (_referenceDataService.TryGetPortfolioDetails(pk.Portfolio, out details))
                {
                    newPositions.Add(new Position(_positionIdGenerator.GetNextPositionId(),
                        pk, details.AggregationUnit, details.ComplianceGroup));
                }
            }

            var positions = sodPositions.Concat(newPositions);

            var aggUnits = (
                from p in positions
                group p by p.AggregationUnitKey
                into g
                select new AggUnitPosition(g.Key,
                    _positionIdGenerator.GetNextPositionId(),
                    g.Sum(i => i.ShortMarkingQuantity))
            ).ToDictionary(i => i.Key);

            var complianceGroups = (
                from p in positions
                group p by p.ComplianceGroupKey into g
                select new CompliancePosition(g.Key, 
                    _positionIdGenerator.GetNextPositionId(),
                    g.Sum(i => i.ShortMarkingQuantity),
                    g.Sum(i => i.LongMarkingQuantity))
                ).ToDictionary(i => i.Key);
            
            var sets = positions.Select(
                p => new PositionSet
                {
                    Position = p,
                    CompliancePosition = complianceGroups[p.ComplianceGroupKey],
                    AggUnitPosition = aggUnits[p.AggregationUnitKey]
                })
                // ignore duplicate position keys here, this only really happens in DEV when the unit tests
                // insert trash data into the database table ...
                .GroupBy(s => s.Position.Key)
                .ToDictionary(g => g.Key, g => g.First());

            ResetEffects(orders.SelectMany(o => o.Allocations.Values));
            Replay(sets, orders.SelectMany(o => o.Allocations.Values));
            return sets.Values.ToArray();
        }

        private void ReplacePosition(PositionSet set, Position replacement)
        {
            var old = set.Position;

            var longMarkingDelta = replacement.LongMarkingQuantity - set.Position.LongMarkingQuantity;
            var shortMarkingDelta = replacement.ShortMarkingQuantity - set.Position.ShortMarkingQuantity;

            set.Position.ApplyLongMarkingEffect(longMarkingDelta);
            set.Position.ApplyShortMarkingEffect(shortMarkingDelta);

            set.CompliancePosition.ApplyShortMarkingEffect(shortMarkingDelta);
            set.CompliancePosition.ApplyLongMarkingEffect(longMarkingDelta);
            set.AggUnitPosition.ApplyShortMarkingEffect(shortMarkingDelta);
            
            var actualEffects = new Dictionary<PositionAllocationKey, long>();
            foreach (var alloc in replacement.ActualAllocations)
            {
                PositionAllocation oldAlloc;
                if (old.ActualAllocations.TryGetValue(alloc.Key, out oldAlloc))
                {
                    actualEffects[alloc.Key] = alloc.Value.Quantity - oldAlloc.Quantity;
                }
                else
                {
                    actualEffects[alloc.Key] = alloc.Value.Quantity;
                }
            }

            foreach (var alloc in old.ActualAllocations)
            {
                if (!replacement.ActualAllocations.ContainsKey(alloc.Key))
                {
                    actualEffects[alloc.Key] = alloc.Value.Quantity*-1;
                }
            }
            set.Position.ApplyActualQuantityEffect(actualEffects);

            var theoreticalEffects = new Dictionary<PositionAllocationKey, long>();
            foreach (var alloc in replacement.TheoreticalAllocations)
            {
                PositionAllocation oldAlloc;
                if (old.TheoreticalAllocations.TryGetValue(alloc.Key, out oldAlloc))
                {
                    theoreticalEffects[alloc.Key] = alloc.Value.Quantity - oldAlloc.Quantity;
                }
                else
                {
                    theoreticalEffects[alloc.Key] = alloc.Value.Quantity;
                }
            }

            foreach (var alloc in old.TheoreticalAllocations)
            {
                if (!replacement.TheoreticalAllocations.ContainsKey(alloc.Key))
                {
                    theoreticalEffects[alloc.Key] = alloc.Value.Quantity*-1;
                }
            }
            set.Position.ApplyTheoreticalQuantityEffect(theoreticalEffects);
        }

        private void ResetEffects(IEnumerable<OrderStrategyAllocation> orderAllocations)
        {
            foreach (var alloc in orderAllocations)
            {
                var effectKey = new EffectKey(alloc.Order.OrderId, alloc.Key);
                _effectCache.SetComplianceEffects(effectKey, default(ComplianceEffects));

                foreach (var key in alloc.ActualAllocations.Keys)
                {
                    _effectCache.SetActualEffects(effectKey, key, default(ActualEffects));
                }

                foreach (var key in alloc.TheoreticalAllocations.Keys)
                {
                    _effectCache.SetTheoreticalEffects(effectKey, key, default(TheoreticalEffects));
                }
            }
        }

        private void Replay(IDictionary<PositionKey, PositionSet> sets, IEnumerable<OrderStrategyAllocation> orderAllocations)
        {
            foreach (var alloc in orderAllocations)
            {
                PositionSet set;
                if (!sets.TryGetValue(alloc.Key, out set))
                {
                    throw new InvalidOperationException($"Missing position set for '{alloc.Key}'");
                }

                using (Attach(set.Position))
                using (Attach(set.CompliancePosition))
                using (Attach(set.AggUnitPosition))
                {
                    alloc.ApplyEffects(set, _effectCache, _effectCalculator);
                }
            }
        }
    }
}
