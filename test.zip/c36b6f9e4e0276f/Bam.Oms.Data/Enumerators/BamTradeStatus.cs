﻿namespace Bam.Oms.Data.Enumerators
{
    public enum BamTradeStatus
    {
        /// <summary>
        /// New trade.
        /// </summary>
        New,

        /// <summary>
        /// Modified Trade.
        /// </summary>
        Modified,

        /// <summary>
        /// Trade was cancelled.
        /// </summary>
        Deleted,

    }
}
