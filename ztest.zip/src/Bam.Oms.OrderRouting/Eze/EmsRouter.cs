﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Bam.Oms.Data;
using Bam.Oms.Data.Configuration;
using Bam.Oms.Data.Enumerators;
using Bam.Oms.Data.Orders;
using Bam.Oms.Data.Portfolios;
using Bam.Oms.Data.Positions;
using Bam.Oms.Data.Securities;
using Bam.Oms.Data.Trades;
using Bam.Oms.EMSAdapters.Contracts;
using Bam.Oms.Filtering;
using Bam.Oms.OrderRouting.Contracts;
using Bam.Oms.OrderRouting.EzePositionAPI;
using Bam.Oms.OrderRouting.EzeTradeAPI;
using Bam.Oms.Persistence.Positions;
using Bam.Oms.RefData;
using BAM.Infrastructure.Ioc;
using Microsoft.Practices.ObjectBuilder2;
using Microsoft.SqlServer.Server;
using ResponseType = Bam.Oms.OrderRouting.EzeTradeAPI.ResponseType;
using Trade = Bam.Oms.OrderRouting.EzeTradeAPI.Trade;

namespace Bam.Oms.OrderRouting.EZE
{
    public class EmsRouter : IEmsRouter
    {
        private EzeTradeAPI.UserCredentials _tradingUserCredentials;
        private EzePositionAPI.UserCredentials _positionUserCredentials;
        private EzeTradingServiceSyncClient _tradingClient;
        private EzePositionServiceSyncClient _positionClient;

        public event Action<string> Connected;
        public event Action<string> Disconnected;
        public event Action<IEnumerable<IOrder>> OrderStatusChanged;
        public event Action<string> RollCompleted;
        public event Action<string> RollStarted;
        public event Action<IEnumerable<IBlockTrade>> TradeUpdated;
        public event Action<ISecurity> SecurityUpdated;

        private readonly IAccountService _accountService;
        private readonly ISecurityMasterService _securityMasterService;
        private readonly IEodPositionRepository _eodPositionRepository;
        private readonly ILoggingSerializer _loggingSerializer;
        private readonly IInstructionToEmsTagMapper _instructionToEmsTagMapper;
        private readonly ILogger _logger;
        private readonly ISettings _settings;
        private readonly ISubscriptionHost _subscriptionHost;

        public EmsRouter(ISubscriptionHost subscriptionHost, ISettings settings, ILogger logger, IAccountService accountService, 
            ISecurityMasterService securityMasterService, IEodPositionRepository eodPositionRepository, ILoggingSerializer loggingSerializer,
            IInstructionToEmsTagMapper instructionToEmsTagMapper)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            if (accountService == null) throw new ArgumentNullException(nameof(accountService));
            if (securityMasterService == null) throw new ArgumentNullException(nameof(securityMasterService));
            if (loggingSerializer == null) throw new ArgumentNullException(nameof(loggingSerializer));
            if (instructionToEmsTagMapper == null) throw new ArgumentNullException(nameof(instructionToEmsTagMapper));
            if (logger == null) throw new ArgumentNullException(nameof(logger));
            if (subscriptionHost == null) throw new ArgumentNullException(nameof(subscriptionHost));

            _subscriptionHost = subscriptionHost;
            _settings = settings;
            _logger = logger;
            _accountService = accountService;
            _securityMasterService = securityMasterService;
            _eodPositionRepository = eodPositionRepository;
            _loggingSerializer = loggingSerializer;
            _instructionToEmsTagMapper = instructionToEmsTagMapper;

            _tradingUserCredentials = new EzeTradeAPI.UserCredentials()
            {
                userName = _settings.EzeUserName,
                password = _settings.EzePassword
            };

            _positionUserCredentials = new EzePositionAPI.UserCredentials()
            {
                userName = _settings.EzeUserName,
                password = _settings.EzePassword
            };
        }
        public IOrder AmendOrder(IOrder order, string originalClientOrderId, bool stageOrders = false)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IOrder> AmendOrders(IEnumerable<IOrder> orders)
        {
            throw new NotImplementedException();
        }

        public bool CancelOrders(IFilter<IOrder> orderFilter)
        {
            return false;
        }

        public IList<string> CancelOrders(IList<string> orderIds)
        {
            return new List<string>();
        }

        public bool Connect()
        {
            _tradingClient = new EzeTradingServiceSyncClient();
            _positionClient = new EzePositionServiceSyncClient();
            return true;
        }

        public void Disconnect()
        {
            _tradingClient = null;
        }

        public IList<IPosition> GetActualPositions(IPortfolio portfolio = null)
        {
            throw new NotImplementedException();
        }

        public DateTime GetBusinessDate()
        {
            var now = DateTime.Now;
            return now.TimeOfDay > _settings.SODDateTime.TimeOfDay 
                ? now.Date.AddDays(1) 
                : now.Date;
        }

        public void GetOpenOrders(out IReadOnlyList<IOrder> orders, out IReadOnlyList<IBlockTrade> trades)
        {
            orders = new List<IOrder>();
            trades = new List<IBlockTrade>();
        }

        public IList<IPosition> GetSodPositions(IPortfolio portfolio = null)
        {
            return _eodPositionRepository.Load(GetBusinessDate()).ToList();
        }

        public IEnumerable<IBlockTrade> GetTradesForTradeDate(DateTime tradeDate)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IOrder> SubmitOrders(IEnumerable<IOrder> orders, bool stageOrders = false)
        {
            var all = orders.ToList();
            var remainder = all.ToList();
            var failed = new List<IOrder>();

            int retryCount = _settings.EzeSubmissionRetryCount;
            int count = 0;

            var retryErrors = new[]
            {
                "Could not satisfy the holding's constraints",
                "All portfolios have a zero basis",
                "Potential Oversell",
                "Potential Overcover"
            };

            try
            {
                while (remainder.Any())
                {
                    EzeTradeAPI.Trade[] tradeList = remainder.Select(ToEzeOrder).Where(t => t != null).ToArray();
                    _logger.Info($"Eze Order(s) created: {_loggingSerializer.Serialize(tradeList)}");

                    var result = (TradeCreateResponse) _tradingClient.CreateTrade(new TradeCreateRequest
                    {
                        userCredentials = _tradingUserCredentials,
                        trades = tradeList,
                        isAllOrNothing = false,
                        runCompliance = true,
                    });

                    if (result.responseMap?.tradeResponses != null &&
                        result.responseMap.tradeResponses.Any())
                    {
                        foreach (IOrder order in remainder)
                        {
                            TradeMap tradeResponse = result.responseMap.tradeResponses
                                .FirstOrDefault(tr => tr.ExternalId == order.ClientOrderId);
                            if (tradeResponse != null)
                            {
                                order.ExternalId = tradeResponse.TradeId;
                                switch (tradeResponse.ErrorCode)
                                {
                                    case ErrorCode.Success:
                                        order.OrderStatus = BamOrderStatus.New;
                                        break;
                                    case ErrorCode.AuthorizationFailure:
                                    case ErrorCode.IdNotFound:
                                    case ErrorCode.ServiceInternalError:
                                    default:
                                        if (count < retryCount &&
                                            retryErrors.Any(msg => tradeResponse.ErrorMessage?.Contains(msg) ?? false))
                                        {
                                            _logger.Warn($"[OrderId {order.ClientOrderId}] - {tradeResponse.ErrorMessage}, retrying");
                                            failed.Add(order);
                                        }
                                        else
                                        {
                                            _logger.Error($"[OrderId {order.ClientOrderId}] - {tradeResponse.ErrorMessage}");
                                            order.OrderStatus = BamOrderStatus.Error;
                                            order.StatusMessages.Add(
                                                $"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}: {Enum.GetName(typeof(ErrorCode), tradeResponse.ErrorCode)}. {tradeResponse.ErrorMessage}");
                                        }
                                        break;
                                }
                            }
                            else
                            {
                                if (result.responseMap.tradeResponses.Any(tr => !string.IsNullOrEmpty(tr.ErrorMessage) && tr.ErrorMessage.Contains("security does not exist")))
                                {
                                    order.OrderStatus = BamOrderStatus.Error;
                                }
                                var errorMsg = $"{DateTime.UtcNow:yyyyMMddHHmmss}: No response received from EZE for this order.";

                                _logger.Error($"[OrderId {order.ClientOrderId}] - {errorMsg}");

                                order.StatusMessages.Add($"{errorMsg}");
                            }
                        }
                    }
                    else // If no response for each order, use the global response
                    {
                        switch (result.responseType)
                        {
                            case ResponseType.Success:
                                remainder.ForEach(o => o.OrderStatus = BamOrderStatus.New);
                                break;
                            case ResponseType.SuccessWithWarning:
                                if (result.CreatedTradeIds != null && result.CreatedTradeIds.Any())
                                {
                                    var createdOrders =
                                        remainder.Where(o => result.CreatedTradeIds.Contains(o.ClientOrderId)).ToList();
                                    createdOrders.ForEach(o => o.OrderStatus = BamOrderStatus.New);

                                    var failedOrders =
                                        remainder.Where(o => !result.CreatedTradeIds.Contains(o.ClientOrderId)).ToList();
                                    failedOrders.ForEach(o => o.OrderStatus = BamOrderStatus.Error);
                                    remainder.ForEach(
                                        o =>
                                            o.StatusMessages.Add(
                                                $"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}: {result.message}"));

                                    _logger.Error($"{result.message}");
                                }
                                else
                                {
                                    remainder.ForEach(o => o.OrderStatus = BamOrderStatus.Error);
                                    remainder.ForEach(
                                        o =>
                                            o.StatusMessages.Add(
                                                $"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}: {result.message}"));

                                    _logger.Error($"{result.message}");
                                }
                                break;
                            case ResponseType.Failure:
                                remainder.ForEach(o => o.OrderStatus = BamOrderStatus.Error);
                                remainder.ForEach(
                                    o =>
                                        o.StatusMessages.Add(
                                            $"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}: {result.message}"));

                                _logger.Error($"{result.message}");
                                break;
                        }
                    }

                    remainder.Clear();
                    remainder.AddRange(failed);
                    failed.Clear();
                    count++;

                    if (remainder.Any())
                        Thread.Sleep(100);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Exception submitting orders.", ex);
                remainder.ForEach(o => o.OrderStatus = BamOrderStatus.Error);
            }
            finally
            {
                _logger.Info(
                    $"OrderStatusChanged raised with Ids {string.Join(", ", all.Select(o => o.ClientOrderId))}");
                Utility.RaiseEvent(all, OrderStatusChanged);
            }

            return all;
        }

        public bool Subscribe(IFilter<EmsSubscription> filter = null)
        {
            //TODO:
            _logger.Info($"Subscribing for Order/Trade updates....");
            _subscriptionHost.Subscribe();
            _subscriptionHost.OrderStatusChanged += OrderStatusChanged;
            _subscriptionHost.TradeUpdated += TradeUpdated;
            _logger.Info($"Successfully subscribed for Order/Trade updates.");
            return true;
        }

        public bool Unsubscribe()
        {
            //TODO:
            return true;
        }

        public bool RequestFullRefresh()
        {
            return _subscriptionHost.RequestFullRefresh();
        }

        private EzeTradeAPI.Trade ToEzeOrder(IOrder bamOrder)
        {
            try
            {
                var traderCode = _accountService.GetEzeTraderCode(bamOrder.TraderId);
                bamOrder.Trader = traderCode;

                EzeTradeAPI.Trade trade = new EzeTradeAPI.Trade()
                {
                    ExternalBlockID = bamOrder.ClientOrderId,
                    Trader = traderCode,
                    TraderCode = traderCode,
                    Action = ConvertAction(bamOrder.Side),
                    Symbol = bamOrder.Security.BamSymbol,
                    Quantity = bamOrder.RoutedSize,
                    Note = bamOrder.Note,
                    LimitPrice = bamOrder.Price,
                    Duration =  bamOrder.Price.HasValue ? Duration.LMT : Duration.MKT,
                    ComplianceCheck = true
                };

                try
                {
                    trade.Manager = _accountService.GetManagerCode(bamOrder.Portfolio, bamOrder.Security.Currency, bamOrder.Custodian);

                    if (trade.Manager == null)
                    {
                        _logger.Error($"[OrderId:{bamOrder.ClientOrderId}] - Error while fetching Manager code for portfolio {bamOrder.Portfolio}");
                        trade.Manager = bamOrder.Portfolio.PMCode;
                    }
                 }
                catch (Exception ex)
                {
                    _logger.Error($"[OrderId:{bamOrder.ClientOrderId}] - Error while fetching Manager code for portfolio {bamOrder.Portfolio}", ex);
                    trade.Manager = bamOrder.Portfolio.PMCode;
                }

                EzeTradeAPI.Allocation[] allocations = bamOrder.Allocations?.Select(allocationInfo => new EzeTradeAPI.Allocation()
                {
                    Account = allocationInfo.AllocationId,
                    Quantity = allocationInfo.Quantity
                }).ToArray();
                trade.allocations = allocations;

                var udfs = new List<string>();
                AddUdf("Urgency", bamOrder.Urgency, udfs);

                if (bamOrder.Side == SideType.SellShort)
                    AddShortOrderUdfs(bamOrder, trade, udfs);

                //add any key value pair execution instructions
                foreach (var inst in bamOrder.ExecutionInstructions)
                   AddUdf(inst.Code,inst.Value,udfs);

                trade.UserDefinedFields = udfs.ToArray();

                return trade;
            }
            catch (Exception ex)
            {
                _logger.Error($"Error while transforming to Eze format for order {bamOrder}.", ex);
                bamOrder.OrderStatus = BamOrderStatus.Error;
                bamOrder.StatusMessages.Add($"{DateTime.UtcNow.ToString("yyyyMMddHHmmss")}: {ex.Message}");
            }
            return null;
        }

        private void AddUdf(string key, object value, List<string> udfs)
        {
            var udfKey = _instructionToEmsTagMapper.GetTag(key);
            if (udfKey != null)
                udfs.Add($"{udfKey} = {value}");
        }

        private void AddShortOrderUdfs(IOrder bamOrder, Trade trade, List<string> udfs)
        {
            if (bamOrder.LocateStatus == LocateStatus.Approved && bamOrder.Locate != null && bamOrder.Locate.Any())
            {
                var locateBrokers = new HashSet<string>();

                trade.ManagerNote = "OGLoc:Done";

                var avgRate = bamOrder.Locate.Sum(r => r.Size) == 0 ? 0 : bamOrder.Locate.Sum(r => r.Size*r.Rate)/bamOrder.Locate.Sum(r => r.Size);
                AddUdf("ActualBorrowRate", avgRate, udfs);
                AddUdf("IsFullyLocated", 1, udfs);

                foreach (var locateInfo in bamOrder.Locate)
                {
                    if (locateInfo.Size <= 0) continue;
                    trade.ManagerNote += $";{locateInfo.PrimeBroker}:{locateInfo.AssignmentId},Qty={locateInfo.Size},Rate={locateInfo.Rate},Time={locateInfo.TimeReceived?.ToString("HH:mm:ss") ?? DateTime.Now.ToString("HH:mm:ss")};";
                    locateBrokers.Add(locateInfo.PrimeBroker);
                }

                //create comma delimited broker list
                if (locateBrokers.Any())
                {
                    var brokerList = new StringBuilder();
                    foreach (var broker in locateBrokers)
                    {
                        string overrideMpid;
                        brokerList.Append(_settings.LocateBrokerMpidOverrides.TryGetValue(broker, out overrideMpid) ? overrideMpid : broker);
                        brokerList.Append(",");
                    }

                    brokerList.Remove(brokerList.Length - 1, 1);

                    AddUdf("LocateBrokers", brokerList, udfs);
                }
            }
        }

        private Bam.Oms.Data.Positions.IPosition FromEzePosition(EzePositionAPI.Position ezePosition)
        {
            try
            {
                int allocationPart = ezePosition.portfolio.LastIndexOf(' ');
                var portfolioString = allocationPart >= 0 ? ezePosition.portfolio.Substring(0, ezePosition.portfolio.LastIndexOf(' ')) : ezePosition.portfolio;

                IPortfolio portfolio = Portfolio.Parse(portfolioString);
                ISecurity security = new Security() { BamSymbol = ezePosition.securityIdentifier };
                string custodian = ezePosition.custodian;

                Bam.Oms.Data.Positions.IPosition position = new Bam.Oms.Data.Positions.Position(portfolio, security, custodian)
                {
                    ActualQuantity = ezePosition.amount,
                    TheoreticalQuantity = ezePosition.amount,
                    LongMarkingQuantity = ezePosition.amount,
                    ShortMarkingQuantity = ezePosition.amount,
                    Cost = ezePosition.localNetCost,
                };
                return position;
            }
            catch (Exception ex)
            {
                _logger.Error($"Error while transforming position from EZE. Position {ezePosition}", ex);
                return null;
            }
        }
        private EzeTradeAPI.TradeAction ConvertAction(SideType side)
        {
            switch (side)
            {
                case SideType.Buy:
                    return EzeTradeAPI.TradeAction.Buy;
                case SideType.Cover:
                    return EzeTradeAPI.TradeAction.Cover;
                case SideType.Sell:
                    return EzeTradeAPI.TradeAction.Sell;
                case SideType.SellShort:
                    return EzeTradeAPI.TradeAction.Short;
                default:
                    throw new ArgumentOutOfRangeException(nameof(side), "Must be Buy, Sell, Cover, or SellShort");
            }
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~EmsRouter() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}
