﻿using System;
using System.Collections.Generic;
using Bam.EventQ.Lookup;
using Bam.Oms.OrderGateway.Compliance.Model;
using Bam.Oms.OrderGateway.Compliance.Model.Headroom;
using Bam.Oms.OrderGateway.Compliance.PositionTracker;
using Bam.Oms.OrderGateway.Compliance.Services.Headroom;

namespace Bam.Oms.OrderGateway.Compliance.Services
{
    public class OrderEffectMediator : IOrderEffectMediator
    {
        private readonly IComplianceCache _complianceCache;
        private readonly IPositionEffectCache _positionEffectCache;
        private readonly IPositionEffectCalculator _positionEffectCalculator;
        private readonly IHeadroomEffectCache _headroomEffectCache;
        private readonly IHeadroomEffectCalculator _headroomEffectCalculator;
        private readonly IModelIndex<HeadroomRule> _headroomRules;
        private readonly Func<PositionKey, PositionSet> _setAccessor;
        private readonly HashSet<string> _securityTypesCoveredByOwnershipRules;

        public OrderEffectMediator(
            IComplianceCache complianceCache, IIndexFactory index,
            IPositionEffectCache positionEffectCache, IPositionEffectCalculator positionEffectCalculator,
            IHeadroomEffectCache headroomEffectCache, IHeadroomEffectCalculator headroomEffectCalculator,
            params string[] securityTypesCoveredByOwnershipRules)
        {
            _headroomRules = index.For<HeadroomRule>();
            _complianceCache = complianceCache;
            _positionEffectCache = positionEffectCache;
            _positionEffectCalculator = positionEffectCalculator;
            _headroomEffectCache = headroomEffectCache;
            _headroomEffectCalculator = headroomEffectCalculator;
            _setAccessor = SetByKey;
            _securityTypesCoveredByOwnershipRules = new HashSet<string>(
                securityTypesCoveredByOwnershipRules, StringComparer.OrdinalIgnoreCase);
        }

        private PositionSet SetByKey(PositionKey key)
        {
            return _complianceCache.GetPositionSet(key);
        }

        public void ApplyEffects(Order order)
        {
            order.ApplyPositionEffects(_setAccessor, 
                _positionEffectCache, _positionEffectCalculator);

            if (_securityTypesCoveredByOwnershipRules.Contains(order.Security.SecurityType))
            {
                var rules = _headroomRules.GetAll();

                // ReSharper disable once ForCanBeConvertedToForeach
                for (int i = 0; i < rules.Count; i++)
                {
                    order.ApplyHeadroomEffects(rules[i],
                        _headroomEffectCache, _headroomEffectCalculator);
                }
            }
        }
    }
}