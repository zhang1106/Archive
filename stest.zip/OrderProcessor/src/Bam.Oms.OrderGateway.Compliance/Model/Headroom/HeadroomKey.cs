﻿using System;

namespace Bam.Oms.OrderGateway.Compliance.Model.Headroom
{
    public struct HeadroomKey : IEquatable<HeadroomKey>
    {
        public bool Equals(HeadroomKey other)
        {
            return RuleId == other.RuleId && string.Equals(Identifier, other.Identifier);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is HeadroomKey && Equals((HeadroomKey) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (RuleId*397) ^ (Identifier?.GetHashCode() ?? 0);
            }
        }

        public static bool operator ==(HeadroomKey left, HeadroomKey right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(HeadroomKey left, HeadroomKey right)
        {
            return !left.Equals(right);
        }

        public int RuleId { get; set; }
        public string Identifier { get; set; }

        public HeadroomKey(int ruleId, string identifier)
        {
            RuleId = ruleId;
            Identifier = identifier;
        }
    }
}
