﻿using System.Collections.Generic;

namespace Bam.Oms.OrderGateway.Compliance.Services.Rules
{
    public class CompositeRuleRepository : IRuleRepository
    {
        private readonly IEnumerable<IRuleRepository> _repositories;
        private readonly List<IRule> _rules;

        public CompositeRuleRepository(IEnumerable<IRuleRepository> repositories)
        {
            _repositories = repositories;
            _rules = new List<IRule>();
        }

        public List<IRule> GetAll()
        {
            if (_rules.Count == 0)
            {
                foreach (var repo in _repositories)
                {
                    _rules.AddRange(repo.GetAll());
                }
            }

            return _rules;
        }
    }
}
